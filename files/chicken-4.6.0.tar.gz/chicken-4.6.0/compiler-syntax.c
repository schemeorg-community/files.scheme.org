/* Generated from compiler-syntax.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: compiler-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file compiler-syntax.c
   unit: compiler_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[74];
static double C_possibly_force_alignment;


C_noret_decl(C_compiler_syntax_toplevel)
C_externexport void C_ccall C_compiler_syntax_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_720)
static void C_ccall f_720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_723)
static void C_ccall f_723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2628)
static void C_fcall f_2628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_fcall f_3062(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_fcall f_3005(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3018)
static void C_fcall f_3018(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2929)
static void C_fcall f_2929(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_fcall f_2880(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_fcall f_2893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2836)
static void C_fcall f_2836(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2863)
static C_word C_fcall f_2863(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_fcall f_2780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_fcall f_2724(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_814)
static void C_ccall f_814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_fcall f_1966(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_fcall f_2532(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_fcall f_2459(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_fcall f_2472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_fcall f_2367(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_fcall f_2318(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_fcall f_2331(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_fcall f_2274(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2301)
static C_word C_fcall f_2301(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_fcall f_2218(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_fcall f_2082(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_817)
static void C_ccall f_817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_820)
static void C_ccall f_820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_823)
static void C_ccall f_823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1701)
static void C_ccall f_1701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1677)
static void C_ccall f_1677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1602)
static void C_ccall f_1602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_826)
static void C_ccall f_826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_829)
static void C_ccall f_829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_859)
static void C_fcall f_859(C_word t0,C_word t1) C_noret;
C_noret_decl(f_862)
static void C_ccall f_862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_933)
static void C_ccall f_933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_936)
static void C_ccall f_936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_942)
static void C_ccall f_942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_fcall f_1045(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1106)
static void C_ccall f_1106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1410)
static void C_fcall f_1410(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1158)
static void C_ccall f_1158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1112)
static void C_ccall f_1112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1035)
static C_word C_fcall f_1035(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_982)
static void C_fcall f_982(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_fcall f_963(C_word t0,C_word t1) C_noret;
C_noret_decl(f_953)
static C_word C_fcall f_953(C_word t0);
C_noret_decl(f_867)
static void C_fcall f_867(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_871)
static void C_ccall f_871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_884)
static void C_ccall f_884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_887)
static void C_ccall f_887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_896)
static void C_ccall f_896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_915)
static void C_ccall f_915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_924)
static void C_ccall f_924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_912)
static void C_ccall f_912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_905)
static void C_ccall f_905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_874)
static void C_ccall f_874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_744)
static void C_ccall f_744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_792)
static void C_ccall f_792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_756)
static void C_fcall f_756(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_771)
static void C_ccall f_771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_764)
static void C_fcall f_764(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_726)
static void C_ccall f_726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_730)
static void C_ccall f_730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2628)
static void C_fcall trf_2628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2628(t0,t1);}

C_noret_decl(trf_3062)
static void C_fcall trf_3062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3062(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3062(t0,t1,t2);}

C_noret_decl(trf_3005)
static void C_fcall trf_3005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3005(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3005(t0,t1,t2,t3);}

C_noret_decl(trf_3018)
static void C_fcall trf_3018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3018(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3018(t0,t1);}

C_noret_decl(trf_2929)
static void C_fcall trf_2929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2929(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2929(t0,t1,t2);}

C_noret_decl(trf_2880)
static void C_fcall trf_2880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2880(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2880(t0,t1,t2,t3);}

C_noret_decl(trf_2893)
static void C_fcall trf_2893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2893(t0,t1);}

C_noret_decl(trf_2836)
static void C_fcall trf_2836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2836(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2836(t0,t1,t2);}

C_noret_decl(trf_2780)
static void C_fcall trf_2780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2780(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2780(t0,t1,t2);}

C_noret_decl(trf_2724)
static void C_fcall trf_2724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2724(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2724(t0,t1,t2);}

C_noret_decl(trf_1966)
static void C_fcall trf_1966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1966(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1966(t0,t1);}

C_noret_decl(trf_2532)
static void C_fcall trf_2532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2532(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2532(t0,t1,t2);}

C_noret_decl(trf_2459)
static void C_fcall trf_2459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2459(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2459(t0,t1,t2,t3);}

C_noret_decl(trf_2472)
static void C_fcall trf_2472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2472(t0,t1);}

C_noret_decl(trf_2367)
static void C_fcall trf_2367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2367(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2367(t0,t1,t2);}

C_noret_decl(trf_2318)
static void C_fcall trf_2318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2318(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2318(t0,t1,t2,t3);}

C_noret_decl(trf_2331)
static void C_fcall trf_2331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2331(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2331(t0,t1);}

C_noret_decl(trf_2274)
static void C_fcall trf_2274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2274(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2274(t0,t1,t2);}

C_noret_decl(trf_2218)
static void C_fcall trf_2218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2218(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2218(t0,t1,t2);}

C_noret_decl(trf_2082)
static void C_fcall trf_2082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2082(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2082(t0,t1,t2);}

C_noret_decl(trf_859)
static void C_fcall trf_859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_859(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_859(t0,t1);}

C_noret_decl(trf_1045)
static void C_fcall trf_1045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1045(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1045(t0,t1,t2);}

C_noret_decl(trf_1410)
static void C_fcall trf_1410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1410(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1410(t0,t1,t2);}

C_noret_decl(trf_982)
static void C_fcall trf_982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_982(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_982(t0,t1,t2);}

C_noret_decl(trf_963)
static void C_fcall trf_963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_963(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_963(t0,t1);}

C_noret_decl(trf_867)
static void C_fcall trf_867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_867(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_867(t0,t1,t2,t3,t4);}

C_noret_decl(trf_756)
static void C_fcall trf_756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_756(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_756(t0,t1,t2);}

C_noret_decl(trf_764)
static void C_fcall trf_764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_764(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_764(t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_syntax_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_syntax_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_syntax_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(834)){
C_save(t1);
C_rereclaim2(834*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,74);
lf[0]=C_h_intern(&lf[0],35,"\010compilercompiler-syntax-statistics");
lf[1]=C_h_intern(&lf[1],24,"\003syscompiler-syntax-hook");
lf[2]=C_h_intern(&lf[2],13,"alist-update!");
lf[3]=C_h_intern(&lf[3],9,"alist-ref");
lf[4]=C_h_intern(&lf[4],3,"eq\077");
lf[5]=C_h_intern(&lf[5],14,"\010compilerr-c-s");
lf[6]=C_h_intern(&lf[6],8,"\003sysput!");
lf[7]=C_h_intern(&lf[7],24,"\010compilercompiler-syntax");
lf[8]=C_h_intern(&lf[8],18,"\003syser-transformer");
lf[9]=C_h_intern(&lf[9],9,"\003syserror");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[11]=C_h_intern(&lf[11],30,"\010compilercompile-format-string");
lf[12]=C_h_intern(&lf[12],17,"extended-bindings");
lf[13]=C_h_intern(&lf[13],7,"warning");
lf[14]=C_h_intern(&lf[14],17,"get-output-string");
lf[15]=C_h_intern(&lf[15],7,"fprintf");
lf[16]=C_h_intern(&lf[16],7,"display");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[18]=C_h_intern(&lf[18],19,"\003syswrite-char/port");
lf[19]=C_h_intern(&lf[19],18,"open-output-string");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[21]=C_h_intern(&lf[21],5,"write");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\024\047, in format string ");
lf[23]=C_h_intern(&lf[23],17,"\010compilerget-line");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[25]=C_h_intern(&lf[25],20,"reverse-list->string");
lf[26]=C_h_intern(&lf[26],10,"\003sysappend");
lf[27]=C_h_intern(&lf[27],7,"reverse");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\0000too many arguments to formatted output procedure");
lf[29]=C_h_intern(&lf[29],16,"\003sysflush-output");
lf[30]=C_h_intern(&lf[30],9,"\003sysapply");
lf[31]=C_h_intern(&lf[31],10,"write-char");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000$illegal format-string character `~c\047");
lf[33]=C_h_intern(&lf[33],14,"number->string");
lf[34]=C_h_intern(&lf[34],3,"let");
lf[35]=C_h_intern(&lf[35],3,"out");
lf[36]=C_h_intern(&lf[36],5,"cadar");
lf[37]=C_h_intern(&lf[37],4,"caar");
lf[38]=C_h_intern(&lf[38],5,"quote");
lf[39]=C_h_intern(&lf[39],7,"call/cc");
lf[40]=C_h_intern(&lf[40],6,"printf");
lf[41]=C_h_intern(&lf[41],19,"\003sysstandard-output");
lf[42]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006printf\376\003\000\000\002\376\001\000\000\010#%printf\376\377\016");
lf[43]=C_h_intern(&lf[43],19,"\003sysprimitive-alias");
lf[44]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007fprintf\376\003\000\000\002\376\001\000\000\011#%fprintf\376\377\016");
lf[45]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\377\016");
lf[46]=C_h_intern(&lf[46],7,"sprintf");
lf[47]=C_h_intern(&lf[47],6,"format");
lf[48]=C_h_intern(&lf[48],6,"gensym");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\003\000\000\002\376\001\000\000\006format\376\003\000\000\002\376\001\000\000\010#%format\376\377\016");
lf[50]=C_h_intern(&lf[50],1,"o");
lf[51]=C_h_intern(&lf[51],10,"fold-right");
lf[52]=C_h_intern(&lf[52],4,"list");
lf[53]=C_h_intern(&lf[53],6,"lambda");
lf[54]=C_h_intern(&lf[54],3,"tmp");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\003#%o\376\377\016");
lf[56]=C_h_intern(&lf[56],11,"\003syssetslot");
lf[57]=C_h_intern(&lf[57],8,"\004coreapp");
lf[58]=C_h_intern(&lf[58],8,"\003sysslot");
lf[59]=C_h_intern(&lf[59],3,"map");
lf[60]=C_h_intern(&lf[60],14,"\003syscheck-list");
lf[61]=C_h_intern(&lf[61],10,"\004corecheck");
lf[62]=C_h_intern(&lf[62],17,"standard-bindings");
lf[63]=C_h_intern(&lf[63],7,"length+");
lf[64]=C_h_intern(&lf[64],5,"pair\077");
lf[65]=C_h_intern(&lf[65],3,"and");
lf[66]=C_h_intern(&lf[66],5,"begin");
lf[67]=C_h_intern(&lf[67],4,"set!");
lf[68]=C_h_intern(&lf[68],4,"cons");
lf[69]=C_h_intern(&lf[69],4,"loop");
lf[70]=C_h_intern(&lf[70],2,"if");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\007\003sysmap\376\003\000\000\002\376\001\000\000\005#%map\376\377\016");
lf[72]=C_h_intern(&lf[72],8,"for-each");
lf[73]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\014\003sysfor-each\376\003\000\000\002\376\001\000\000\012#%for-each\376\377\016");
C_register_lf2(lf,74,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_720,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k718 */
static void C_ccall f_720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_723,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k721 in k718 */
static void C_ccall f_723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_723,2,t0,t1);}
t2=C_set_block_item(lf[0] /* compiler-syntax-statistics */,0,C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[1]+1 /* (set! ##sys#compiler-syntax-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_726,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[5]+1 /* (set! ##compiler#r-c-s ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_740,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_814,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2594,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3122,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
t8=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[64]);}

/* k3120 in k721 in k718 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3122,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[64],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##compiler#r-c-s */
t4=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[73],((C_word*)t0)[2],t3);}

/* a2593 in k721 in k718 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2594,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2598,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:61: r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[34]);}

/* k2596 in a2593 in k721 in k718 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:62: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[70]);}

/* k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2604,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:63: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[69]);}

/* k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:64: gensym */
t3=*((C_word*)lf[48]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:65: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[66]);}

/* k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm:66: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm:67: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[64]);}

/* k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2619,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm:68: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[53]);}

/* k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2619,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2628,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_memq(lf[72],*((C_word*)lf[62]+1)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3110,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler-syntax.scm:71: length+ */
t5=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t4=t3;
f_2628(t4,C_SCHEME_FALSE);}}

/* k3108 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2628(t2,C_i_greaterp(t1,C_fix(2)));}

/* k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_fcall f_2628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2628,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3062,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3062(t10,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[11];
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop105 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_fcall f_3062(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3062,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3096,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,t4);
/* compiler-syntax.scm:72: gensym */
t6=*((C_word*)lf[48]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3094 in loop105 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3096,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop105118 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3062(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop105118 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3062(t6,((C_word*)t0)[3],t5);}}

/* k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2631,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[11]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[10],t3);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2999,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3003,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3005,a[2]=t7,a[3]=t12,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_3005(t14,t10,t1,((C_word*)t0)[2]);}

/* loop132 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_fcall f_3005(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3005,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[52]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3038,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g151152 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3036 in loop132 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3038,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_3018(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_3018(t5,t4);}}

/* k3016 in k3036 in loop132 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_fcall f_3018(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop132146 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3005(t5,((C_word*)t0)[2],t3,t4);}

/* k3001 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2999,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[11],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2929,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_2929(t12,t8,((C_word*)t0)[3]);}

/* loop158 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_fcall f_2929(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(24);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2929,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,lf[72],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[38],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,t3,t6);
t8=C_a_i_cons(&a,2,lf[60],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,lf[61],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t12=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11);
t13=C_mutate(((C_word *)((C_word*)t0)[4])+1,t11);
t14=C_slot(t2,C_fix(1));
/* loop158171 */
t20=t1;
t21=t14;
t1=t20;
t2=t21;
goto loop;}
else{
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=C_mutate(((C_word *)((C_word*)t0)[4])+1,t11);
t14=C_slot(t2,C_fix(1));
/* loop158171 */
t20=t1;
t21=t14;
t1=t20;
t2=t21;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2880,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2880(t10,t6,((C_word*)t0)[3],((C_word*)t0)[3]);}

/* loop185 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_fcall f_2880(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2880,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[52]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g204205 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2911 in loop185 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_2893(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_2893(t5,t4);}}

/* k2891 in k2911 in loop185 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_fcall f_2893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop185199 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2880(t5,((C_word*)t0)[2],t3,t4);}

/* k2668 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2834,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2836,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2836(t11,t7,((C_word*)t0)[3]);}

/* loop211 in k2668 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_fcall f_2836(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2836,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2863,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_2863(C_a_i(&a,6),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop211224 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop211224 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g227 in loop211 in k2668 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static C_word C_fcall f_2863(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
return(C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2832 in k2668 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2828 in k2668 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[11],t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2778,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2780,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_2780(t12,t8,((C_word*)t0)[2]);}

/* loop238 in k2828 in k2668 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_fcall f_2780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2780,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_a_i_cons(&a,2,lf[58],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop238251 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop238251 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2776 in k2828 in k2668 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2772 in k2828 in k2668 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2774,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[11],t1);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t2,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2722,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2724,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_2724(t12,t8,((C_word*)t0)[2]);}

/* loop265 in k2772 in k2828 in k2668 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_fcall f_2724(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2724,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_a_i_cons(&a,2,lf[58],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop265278 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop265278 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2720 in k2772 in k2828 in k2668 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2716 in k2772 in k2828 in k2668 in k2648 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=C_a_i_cons(&a,2,lf[57],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,((C_word*)t0)[5],t10);
t12=C_a_i_cons(&a,2,((C_word*)t0)[10],t11);
t13=C_a_i_cons(&a,2,((C_word*)t0)[4],t12);
t14=C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t15=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,((C_word*)t0)[3],((C_word*)t0)[2],t14);}

/* k2644 in k2997 in k2629 in k2626 in k2617 in k2614 in k2611 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k721 in k718 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k812 in k721 in k718 */
static void C_ccall f_814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_817,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1914,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2592,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
t5=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[64]);}

/* k2590 in k812 in k721 in k718 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2592,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[64],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##compiler#r-c-s */
t4=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[71],((C_word*)t0)[2],t3);}

/* a1913 in k812 in k721 in k718 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1914,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1918,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:90: r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[34]);}

/* k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:91: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[70]);}

/* k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1924,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:92: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[69]);}

/* k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:93: gensym */
t3=*((C_word*)lf[48]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:94: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[68]);}

/* k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm:95: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[67]);}

/* k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm:96: gensym */
t3=*((C_word*)lf[48]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler-syntax.scm:97: gensym */
t3=*((C_word*)lf[48]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler-syntax.scm:98: gensym */
t3=*((C_word*)lf[48]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler-syntax.scm:99: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[38]);}

/* k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm:100: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[66]);}

/* k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm:101: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[53]);}

/* k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm:102: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm:103: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[64]);}

/* k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1957,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1966,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word*)t0)[13],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_i_memq(lf[59],*((C_word*)lf[62]+1)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2580,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler-syntax.scm:106: length+ */
t5=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t4=t3;
f_1966(t4,C_SCHEME_FALSE);}}

/* k2578 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1966(t2,C_i_greaterp(t1,C_fix(2)));}

/* k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_fcall f_1966(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1966,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2532,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2532(t10,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[13];
t3=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop320 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_fcall f_2532(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2532,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,t4);
/* compiler-syntax.scm:107: gensym */
t6=*((C_word*)lf[48]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2564 in loop320 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop320333 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2532(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop320333 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2532(t6,((C_word*)t0)[3],t5);}}

/* k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1969,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[16],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[15],t4);
t6=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[14],t6);
t8=C_i_cadr(((C_word*)t0)[13]);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,((C_word*)t0)[12],t9);
t11=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2453,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[16],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=t5,a[17]=t7,a[18]=t10,tmp=(C_word)a,a+=19,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2457,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2459,a[2]=t13,a[3]=t18,a[4]=t15,tmp=(C_word)a,a+=5,tmp));
t20=((C_word*)t18)[1];
f_2459(t20,t16,t1,((C_word*)t0)[2]);}

/* loop347 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_fcall f_2459(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2459,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[52]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g366367 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2490 in loop347 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2492,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2472,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_2472(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_2472(t5,t4);}}

/* k2470 in k2490 in loop347 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_fcall f_2472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop347361 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2459(t5,((C_word*)t0)[2],t3,t4);}

/* k2455 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2453,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[18],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[17],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[16],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2367,a[2]=t7,a[3]=t12,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_2367(t14,t10,((C_word*)t0)[3]);}

/* loop373 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_fcall f_2367(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(24);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2367,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,lf[59],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[38],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,t3,t6);
t8=C_a_i_cons(&a,2,lf[60],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,lf[61],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t12=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11);
t13=C_mutate(((C_word *)((C_word*)t0)[4])+1,t11);
t14=C_slot(t2,C_fix(1));
/* loop373386 */
t20=t1;
t21=t14;
t1=t20;
t2=t21;
goto loop;}
else{
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=C_mutate(((C_word *)((C_word*)t0)[4])+1,t11);
t14=C_slot(t2,C_fix(1));
/* loop373386 */
t20=t1;
t21=t14;
t1=t20;
t2=t21;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2318,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2318(t10,t6,((C_word*)t0)[3],((C_word*)t0)[3]);}

/* loop400 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_fcall f_2318(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2318,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[52]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g419420 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2349 in loop400 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_2331(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_2331(t5,t4);}}

/* k2329 in k2349 in loop400 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_fcall f_2331(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop400414 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2318(t5,((C_word*)t0)[2],t3,t4);}

/* k2006 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2272,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2274,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2274(t11,t7,((C_word*)t0)[3]);}

/* loop426 in k2006 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_fcall f_2274(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2274,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2301,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_2301(C_a_i(&a,6),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop426439 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop426439 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g442 in loop426 in k2006 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static C_word C_fcall f_2301(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
return(C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2270 in k2006 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2266 in k2006 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[16],t1);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2216,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2218,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_2218(t12,t8,((C_word*)t0)[2]);}

/* loop453 in k2266 in k2006 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_fcall f_2218(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2218,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_a_i_cons(&a,2,lf[58],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop453466 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop453466 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2214 in k2266 in k2006 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2210 in k2266 in k2006 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[16],t1);
t3=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[15],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t2,t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[14],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[13],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,C_fix(1),t11);
t13=C_a_i_cons(&a,2,((C_word*)t0)[12],t12);
t14=C_a_i_cons(&a,2,lf[56],t13);
t15=C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,((C_word*)t0)[11],t15);
t17=C_a_i_cons(&a,2,((C_word*)t0)[10],t16);
t18=C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=C_a_i_cons(&a,2,t14,t18);
t20=C_a_i_cons(&a,2,((C_word*)t0)[12],t19);
t21=C_a_i_cons(&a,2,((C_word*)t0)[9],t20);
t22=C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t23=C_a_i_cons(&a,2,((C_word*)t0)[12],t22);
t24=C_a_i_cons(&a,2,((C_word*)t0)[10],t23);
t25=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t10,a[10]=t21,a[11]=t24,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
t26=C_SCHEME_END_OF_LIST;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_FALSE;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2080,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_set_block_item(t32,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2082,a[2]=t27,a[3]=t32,a[4]=t29,tmp=(C_word)a,a+=5,tmp));
t34=((C_word*)t32)[1];
f_2082(t34,t30,((C_word*)t0)[2]);}

/* loop480 in k2210 in k2266 in k2006 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_fcall f_2082(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2082,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_a_i_cons(&a,2,lf[58],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop480493 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop480493 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2078 in k2210 in k2266 in k2006 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2074 in k2210 in k2266 in k2006 in k1986 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2076,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[12],t1);
t3=C_a_i_cons(&a,2,lf[57],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[11],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[10],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[9],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[8],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t8,t9);
t11=C_a_i_cons(&a,2,((C_word*)t0)[6],t10);
t12=C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=C_a_i_cons(&a,2,((C_word*)t0)[12],t14);
t16=C_a_i_cons(&a,2,((C_word*)t0)[8],t15);
t17=C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t18=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,((C_word*)t0)[3],((C_word*)t0)[2],t17);}

/* k1982 in k2451 in k1967 in k1964 in k1955 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1934 in k1931 in k1928 in k1925 in k1922 in k1919 in k1916 in a1913 in k812 in k721 in k718 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1984,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k815 in k812 in k721 in k718 */
static void C_ccall f_817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_820,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1865,tmp=(C_word)a,a+=2,tmp);
/* ##compiler#r-c-s */
t4=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[55],t3,C_SCHEME_END_OF_LIST);}

/* a1864 in k815 in k812 in k721 in k718 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1865,5,t0,t1,t2,t3,t4);}
t5=C_i_length(t2);
t6=C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?C_i_memq(lf[50],*((C_word*)lf[12]+1)):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1875,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:135: r */
t9=t3;
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[54]);}
else{
t8=t2;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* k1873 in a1864 in k815 in k812 in k721 in k718 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:136: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[53]);}

/* k1880 in k1873 in a1864 in k815 in k812 in k721 in k718 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1898,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
/* compiler-syntax.scm:136: fold-right */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,*((C_word*)lf[52]+1),((C_word*)t0)[4],t4);}

/* k1896 in k1880 in k1873 in a1864 in k815 in k812 in k721 in k718 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_823,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1703,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1863,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
t5=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[16]);}

/* k1861 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1863,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[16],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[21]);}

/* k1857 in k1861 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1859,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[21],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[15]);}

/* k1853 in k1857 in k1861 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[15],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[33]);}

/* k1849 in k1853 in k1857 in k1861 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[33],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[31]);}

/* k1845 in k1849 in k1853 in k1857 in k1861 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1847,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[19]);}

/* k1841 in k1845 in k1849 in k1853 in k1857 in k1861 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[19],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[14]);}

/* k1837 in k1841 in k1845 in k1849 in k1853 in k1857 in k1861 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[14],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
/* ##compiler#r-c-s */
t10=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[3],lf[49],((C_word*)t0)[2],t9);}

/* a1702 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1703,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1707,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:141: gensym */
t6=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[35]);}

/* k1705 in a1702 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1710,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[3]);
t4=C_i_memq(t3,lf[45]);
t5=(C_truep(t4)?lf[46]:lf[47]);
t6=C_i_cdr(((C_word*)t0)[3]);
/* compiler-syntax.scm:142: compile-format-string */
t7=*((C_word*)lf[11]+1);
((C_proc8)(void*)(*((C_word*)t7+1)))(8,t7,t2,t5,t1,((C_word*)t0)[3],t6,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1708 in k1705 in a1702 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1710,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:151: r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[34]);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1718 in k1708 in k1705 in a1702 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:151: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[19]);}

/* k1762 in k1718 in k1708 in k1705 in a1702 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1744,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:153: r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[14]);}

/* k1742 in k1762 in k1718 in k1708 in k1705 in a1702 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1744,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_826,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1592,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1701,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
t5=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[16]);}

/* k1699 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1701,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[16],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[21]);}

/* k1695 in k1699 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1697,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[21],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[15]);}

/* k1691 in k1695 in k1699 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1693,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[15],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[33]);}

/* k1687 in k1691 in k1695 in k1699 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[33],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[31]);}

/* k1683 in k1687 in k1691 in k1695 in k1699 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[19]);}

/* k1679 in k1683 in k1687 in k1691 in k1695 in k1699 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1681,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[19],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[14]);}

/* k1675 in k1679 in k1683 in k1687 in k1691 in k1695 in k1699 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1677,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[14],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
/* ##compiler#r-c-s */
t10=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[3],lf[44],((C_word*)t0)[2],t9);}

/* a1591 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1592,5,t0,t1,t2,t3,t4);}
t5=C_i_length(t2);
if(C_truep(C_i_greater_or_equalp(t5,C_fix(3)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1602,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cadr(t2);
t8=C_i_cddr(t2);
/* compiler-syntax.scm:159: compile-format-string */
t9=*((C_word*)lf[11]+1);
((C_proc8)(void*)(*((C_word*)t9+1)))(8,t9,t6,lf[15],t7,t2,t8,t3,t4);}
else{
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k1600 in a1591 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_829,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1495,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1590,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
t5=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[16]);}

/* k1588 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1590,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[16],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[21]);}

/* k1584 in k1588 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[21],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[15]);}

/* k1580 in k1584 in k1588 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[15],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[33]);}

/* k1576 in k1580 in k1584 in k1588 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[33],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[31]);}

/* k1572 in k1576 in k1580 in k1584 in k1588 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1574,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[19]);}

/* k1568 in k1572 in k1576 in k1580 in k1584 in k1588 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1570,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[19],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#primitive-alias */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[14]);}

/* k1564 in k1568 in k1572 in k1576 in k1580 in k1584 in k1588 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1566,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[14],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
/* ##compiler#r-c-s */
t10=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[3],lf[42],((C_word*)t0)[2],t9);}

/* a1494 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1495,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1499,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t2);
/* compiler-syntax.scm:168: compile-format-string */
t7=*((C_word*)lf[11]+1);
((C_proc8)(void*)(*((C_word*)t7+1)))(8,t7,t5,lf[40],lf[41],t2,t6,t3,t4);}

/* k1497 in a1494 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_829,2,t0,t1);}
t2=C_mutate((C_word*)lf[11]+1 /* (set! ##compiler#compile-format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_831,tmp=(C_word)a,a+=2,tmp));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_831,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_837,a[2]=t7,a[3]=t6,a[4]=t3,a[5]=t4,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:175: call/cc */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_837,3,t0,t1,t2);}
t3=C_i_length(((C_word*)t0)[7]);
if(C_truep(C_i_greater_or_equalp(t3,C_fix(1)))){
if(C_truep(C_i_memq(((C_word*)t0)[6],*((C_word*)lf[12]+1)))){
t4=C_i_car(((C_word*)t0)[7]);
t5=C_i_stringp(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_859,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_859(t7,t5);}
else{
t7=C_i_car(((C_word*)t0)[7]);
if(C_truep(C_i_listp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1466,a[2]=((C_word*)t0)[7],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[7],a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:181: r */
t10=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[38]);}
else{
t8=t6;
f_859(t8,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1475 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1481,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:181: caar */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1479 in k1475 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm:181: c */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1464 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1466,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1473,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler-syntax.scm:182: cadar */
t3=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_859(t2,C_SCHEME_FALSE);}}

/* k1471 in k1464 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_859(t2,C_i_stringp(t1));}

/* k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_fcall f_859(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_859,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_i_car(((C_word*)t0)[8]);
if(C_truep(C_i_stringp(t3))){
t4=t2;
f_862(2,t4,C_i_car(((C_word*)t0)[8]));}
else{
/* compiler-syntax.scm:183: cadar */
t4=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,((C_word*)t0)[8]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_862,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[8]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_867,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_i_string_length(t1);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t10,a[6]=t7,a[7]=t5,a[8]=t4,a[9]=t9,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm:196: r */
t12=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,lf[16]);}

/* k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler-syntax.scm:197: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[21]);}

/* k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler-syntax.scm:198: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[31]);}

/* k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler-syntax.scm:199: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[35]);}

/* k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm:200: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[15]);}

/* k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* compiler-syntax.scm:201: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[34]);}

/* k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* compiler-syntax.scm:202: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[33]);}

/* k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[47],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_953,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp));
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_982,a[2]=((C_word*)t0)[9],a[3]=t9,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1035,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=t5,a[7]=t9,a[8]=((C_word*)t0)[4],a[9]=t15,a[10]=t3,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t7,a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[5],a[16]=((C_word*)t0)[11],a[17]=((C_word*)t0)[6],a[18]=((C_word*)t0)[7],a[19]=((C_word*)t0)[14],tmp=(C_word)a,a+=20,tmp));
t17=((C_word*)t15)[1];
f_1045(t17,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_fcall f_1045(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1045,NULL,3,t0,t1,t2);}
if(C_truep(C_i_greater_or_equalp(((C_word*)((C_word*)t0)[19])[1],((C_word*)t0)[18]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1055,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t1,a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[12])[1]))){
t4=t3;
f_1055(2,t4,C_SCHEME_UNDEFINED);}
else{
/* compiler-syntax.scm:224: fail */
t4=((C_word*)t0)[11];
f_867(t4,t3,C_SCHEME_FALSE,lf[28],C_SCHEME_END_OF_LIST);}}
else{
t3=f_953(((C_word*)((C_word*)t0)[10])[1]);
t4=C_eqp(t3,C_make_character(126));
if(C_truep(t4)){
t5=f_953(((C_word*)((C_word*)t0)[10])[1]);
t6=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1106,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[19],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[16],a[13]=t1,a[14]=((C_word*)t0)[9],a[15]=t5,tmp=(C_word)a,a+=16,tmp);
/* compiler-syntax.scm:232: endchunk */
t7=((C_word*)((C_word*)t0)[13])[1];
f_982(t7,t6,t2);}
else{
t5=C_a_i_cons(&a,2,t3,t2);
/* compiler-syntax.scm:255: loop */
t10=t1;
t11=t5;
t1=t10;
t2=t11;
goto loop;}}}

/* k1104 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1106,2,t0,t1);}
t2=C_u_i_char_upcase(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1112,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
switch(t2){
case C_make_character(83):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1133,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:234: next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_963(t5,t4);
case C_make_character(65):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1158,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:235: next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_963(t5,t4);
case C_make_character(67):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1183,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:236: next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_963(t5,t4);
case C_make_character(66):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1220,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:237: next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_963(t5,t4);
case C_make_character(79):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1257,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:238: next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_963(t5,t4);
case C_make_character(88):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:239: next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_963(t5,t4);
case C_make_character(33):
t4=C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[29],t4);
t6=f_1035(C_a_i(&a,3),((C_word*)((C_word*)t0)[10])[1],t5);
/* compiler-syntax.scm:254: loop */
t7=((C_word*)((C_word*)t0)[14])[1];
f_1045(t7,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
case C_make_character(63):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1324,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:242: next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_963(t5,t4);
case C_make_character(126):
t4=C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,C_make_character(126),t4);
t6=C_a_i_cons(&a,2,*((C_word*)lf[31]+1),t5);
t7=f_1035(C_a_i(&a,3),((C_word*)((C_word*)t0)[10])[1],t6);
/* compiler-syntax.scm:254: loop */
t8=((C_word*)((C_word*)t0)[14])[1];
f_1045(t8,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
default:
t4=C_eqp(t2,C_make_character(37));
t5=(C_truep(t4)?t4:C_eqp(t2,C_make_character(78)));
if(C_truep(t5)){
t6=C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,C_make_character(10),t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=f_1035(C_a_i(&a,3),((C_word*)((C_word*)t0)[10])[1],t8);
/* compiler-syntax.scm:254: loop */
t10=((C_word*)((C_word*)t0)[14])[1];
f_1045(t10,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_u_i_char_whitespacep(((C_word*)t0)[15]))){
t6=f_953(((C_word*)((C_word*)t0)[4])[1]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1410,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_1410(t10,t3,t6);}
else{
/* compiler-syntax.scm:253: fail */
t6=((C_word*)t0)[2];
f_867(t6,t3,C_SCHEME_TRUE,lf[32],C_a_i_list(&a,1,((C_word*)t0)[15]));}}}}

/* skip in k1104 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_fcall f_1410(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1410,NULL,3,t0,t1,t2);}
if(C_truep(C_u_i_char_whitespacep(t2))){
t3=f_953(((C_word*)((C_word*)t0)[4])[1]);
/* compiler-syntax.scm:251: skip */
t7=t1;
t8=t3;
t1=t7;
t2=t8;
goto loop;}
else{
t3=C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1322 in k1104 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:243: next */
t3=((C_word*)((C_word*)t0)[2])[1];
f_963(t3,t2);}

/* k1325 in k1322 in k1104 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1327,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,lf[30],t5);
t7=f_1035(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t6);
/* compiler-syntax.scm:254: loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_1045(t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1292 in k1104 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_fix(16),C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=f_1035(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t7);
/* compiler-syntax.scm:254: loop */
t9=((C_word*)((C_word*)t0)[3])[1];
f_1045(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1255 in k1104 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1257,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_fix(8),C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=f_1035(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t7);
/* compiler-syntax.scm:254: loop */
t9=((C_word*)((C_word*)t0)[3])[1];
f_1045(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1218 in k1104 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1220,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_fix(2),C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=f_1035(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t7);
/* compiler-syntax.scm:254: loop */
t9=((C_word*)((C_word*)t0)[3])[1];
f_1045(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1181 in k1104 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1183,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=f_1035(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t4);
/* compiler-syntax.scm:254: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1045(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1156 in k1104 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1158,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=f_1035(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t4);
/* compiler-syntax.scm:254: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1045(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1131 in k1104 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1133,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=f_1035(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t4);
/* compiler-syntax.scm:254: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1045(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1110 in k1104 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm:254: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1045(t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1053 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1058,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:225: endchunk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_982(t3,t2,((C_word*)t0)[2]);}

/* k1056 in k1053 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1073,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1077,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler-syntax.scm:227: reverse */
t7=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)((C_word*)t0)[2])[1]);}

/* k1075 in k1056 in k1053 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1071 in k1056 in k1053 in loop in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1073,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* push in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static C_word C_fcall f_1035(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}

/* endchunk in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_fcall f_982(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_982,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_i_length(t2);
if(C_truep(C_i_nequalp(C_fix(1),t3))){
t4=C_i_car(t2);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
/* compiler-syntax.scm:215: push */
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_1035(C_a_i(&a,3),((C_word*)((C_word*)t0)[3])[1],t7));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:218: reverse-list->string */
t5=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1023 in endchunk in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
/* compiler-syntax.scm:215: push */
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1035(C_a_i(&a,3),((C_word*)((C_word*)t0)[2])[1],t4));}

/* next in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_fcall f_963(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_963,NULL,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* compiler-syntax.scm:209: fail */
t2=((C_word*)t0)[2];
f_867(t2,t1,C_SCHEME_TRUE,lf[24],C_SCHEME_END_OF_LIST);}
else{
t2=C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static C_word C_fcall f_953(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=C_i_string_ref(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_fcall f_867(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_867,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_871,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:186: get-line */
t6=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_874,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* open-output-string */
t4=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* write-char/port */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(96),t1);}

/* k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k888 in k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[22],((C_word*)t0)[6]);}

/* k891 in k888 in k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* write */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k894 in k891 in k888 in k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_912,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_915,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t5=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* display */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[20],((C_word*)t0)[5]);}}

/* k913 in k894 in k891 in k888 in k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_918,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(40),t1);}

/* k916 in k913 in k894 in k891 in k888 in k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_921,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k919 in k916 in k913 in k894 in k891 in k888 in k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[2]);}

/* k922 in k919 in k916 in k913 in k894 in k891 in k888 in k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k910 in k894 in k891 in k888 in k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k897 in k894 in k891 in k888 in k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[17],((C_word*)t0)[4]);}

/* k900 in k897 in k894 in k891 in k888 in k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_905,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t2,*((C_word*)lf[15]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k903 in k900 in k897 in k894 in k891 in k888 in k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_908,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
t3=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k906 in k903 in k900 in k897 in k894 in k891 in k888 in k885 in k882 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm:187: warning */
t2=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k872 in k869 in fail in k860 in k857 in a836 in ##compiler#compile-format-string in k827 in k824 in k821 in k818 in k815 in k812 in k721 in k718 */
static void C_ccall f_874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* compiler-syntax.scm:192: return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#r-c-s in k721 in k718 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_740r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_740r(t0,t1,t2,t3,t4);}}

static void C_ccall f_740r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_744,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_744(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_744(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[10],t4);}}}

/* k742 in ##compiler#r-c-s in k721 in k718 */
static void C_ccall f_744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:46: ##sys#er-transformer */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k790 in k742 in ##compiler#r-c-s in k721 in k718 */
static void C_ccall f_792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_792,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=C_i_symbolp(((C_word*)t0)[3]);
t4=(C_truep(t3)?C_a_i_list(&a,1,((C_word*)t0)[3]):((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_756,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_756(t8,((C_word*)t0)[2],t4);}

/* loop36 in k790 in k742 in ##compiler#r-c-s in k721 in k718 */
static void C_fcall f_756(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_756,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_764,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_771,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g4344 */
t6=t3;
f_764(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k769 in loop36 in k790 in k742 in ##compiler#r-c-s in k721 in k718 */
static void C_ccall f_771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_756(t3,((C_word*)t0)[2],t2);}

/* g43 in loop36 in k790 in k742 in ##compiler#r-c-s in k721 in k718 */
static void C_fcall f_764(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_764,NULL,3,t0,t1,t2);}
/* compiler-syntax.scm:49: ##sys#put! */
t3=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[7],((C_word*)t0)[2]);}

/* ##sys#compiler-syntax-hook in k721 in k718 */
static void C_ccall f_726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_726,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_730,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm:41: alist-ref */
t5=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t2,*((C_word*)lf[0]+1),*((C_word*)lf[4]+1),C_fix(0));}

/* k728 in ##sys#compiler-syntax-hook in k721 in k718 */
static void C_ccall f_730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_734,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_plus(&a,2,t1,C_fix(1));
/* compiler-syntax.scm:43: alist-update! */
t4=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],t3,*((C_word*)lf[0]+1));}

/* k732 in k728 in ##sys#compiler-syntax-hook in k721 in k718 */
static void C_ccall f_734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[0]+1 /* (set! ##compiler#compiler-syntax-statistics ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[187] = {
{"toplevel:compiler_syntax_scm",(void*)C_compiler_syntax_toplevel},
{"f_720:compiler_syntax_scm",(void*)f_720},
{"f_723:compiler_syntax_scm",(void*)f_723},
{"f_3122:compiler_syntax_scm",(void*)f_3122},
{"f_2594:compiler_syntax_scm",(void*)f_2594},
{"f_2598:compiler_syntax_scm",(void*)f_2598},
{"f_2601:compiler_syntax_scm",(void*)f_2601},
{"f_2604:compiler_syntax_scm",(void*)f_2604},
{"f_2607:compiler_syntax_scm",(void*)f_2607},
{"f_2610:compiler_syntax_scm",(void*)f_2610},
{"f_2613:compiler_syntax_scm",(void*)f_2613},
{"f_2616:compiler_syntax_scm",(void*)f_2616},
{"f_2619:compiler_syntax_scm",(void*)f_2619},
{"f_3110:compiler_syntax_scm",(void*)f_3110},
{"f_2628:compiler_syntax_scm",(void*)f_2628},
{"f_3062:compiler_syntax_scm",(void*)f_3062},
{"f_3096:compiler_syntax_scm",(void*)f_3096},
{"f_2631:compiler_syntax_scm",(void*)f_2631},
{"f_3005:compiler_syntax_scm",(void*)f_3005},
{"f_3038:compiler_syntax_scm",(void*)f_3038},
{"f_3018:compiler_syntax_scm",(void*)f_3018},
{"f_3003:compiler_syntax_scm",(void*)f_3003},
{"f_2999:compiler_syntax_scm",(void*)f_2999},
{"f_2929:compiler_syntax_scm",(void*)f_2929},
{"f_2650:compiler_syntax_scm",(void*)f_2650},
{"f_2880:compiler_syntax_scm",(void*)f_2880},
{"f_2913:compiler_syntax_scm",(void*)f_2913},
{"f_2893:compiler_syntax_scm",(void*)f_2893},
{"f_2670:compiler_syntax_scm",(void*)f_2670},
{"f_2836:compiler_syntax_scm",(void*)f_2836},
{"f_2863:compiler_syntax_scm",(void*)f_2863},
{"f_2834:compiler_syntax_scm",(void*)f_2834},
{"f_2830:compiler_syntax_scm",(void*)f_2830},
{"f_2780:compiler_syntax_scm",(void*)f_2780},
{"f_2778:compiler_syntax_scm",(void*)f_2778},
{"f_2774:compiler_syntax_scm",(void*)f_2774},
{"f_2724:compiler_syntax_scm",(void*)f_2724},
{"f_2722:compiler_syntax_scm",(void*)f_2722},
{"f_2718:compiler_syntax_scm",(void*)f_2718},
{"f_2646:compiler_syntax_scm",(void*)f_2646},
{"f_814:compiler_syntax_scm",(void*)f_814},
{"f_2592:compiler_syntax_scm",(void*)f_2592},
{"f_1914:compiler_syntax_scm",(void*)f_1914},
{"f_1918:compiler_syntax_scm",(void*)f_1918},
{"f_1921:compiler_syntax_scm",(void*)f_1921},
{"f_1924:compiler_syntax_scm",(void*)f_1924},
{"f_1927:compiler_syntax_scm",(void*)f_1927},
{"f_1930:compiler_syntax_scm",(void*)f_1930},
{"f_1933:compiler_syntax_scm",(void*)f_1933},
{"f_1936:compiler_syntax_scm",(void*)f_1936},
{"f_1939:compiler_syntax_scm",(void*)f_1939},
{"f_1942:compiler_syntax_scm",(void*)f_1942},
{"f_1945:compiler_syntax_scm",(void*)f_1945},
{"f_1948:compiler_syntax_scm",(void*)f_1948},
{"f_1951:compiler_syntax_scm",(void*)f_1951},
{"f_1954:compiler_syntax_scm",(void*)f_1954},
{"f_1957:compiler_syntax_scm",(void*)f_1957},
{"f_2580:compiler_syntax_scm",(void*)f_2580},
{"f_1966:compiler_syntax_scm",(void*)f_1966},
{"f_2532:compiler_syntax_scm",(void*)f_2532},
{"f_2566:compiler_syntax_scm",(void*)f_2566},
{"f_1969:compiler_syntax_scm",(void*)f_1969},
{"f_2459:compiler_syntax_scm",(void*)f_2459},
{"f_2492:compiler_syntax_scm",(void*)f_2492},
{"f_2472:compiler_syntax_scm",(void*)f_2472},
{"f_2457:compiler_syntax_scm",(void*)f_2457},
{"f_2453:compiler_syntax_scm",(void*)f_2453},
{"f_2367:compiler_syntax_scm",(void*)f_2367},
{"f_1988:compiler_syntax_scm",(void*)f_1988},
{"f_2318:compiler_syntax_scm",(void*)f_2318},
{"f_2351:compiler_syntax_scm",(void*)f_2351},
{"f_2331:compiler_syntax_scm",(void*)f_2331},
{"f_2008:compiler_syntax_scm",(void*)f_2008},
{"f_2274:compiler_syntax_scm",(void*)f_2274},
{"f_2301:compiler_syntax_scm",(void*)f_2301},
{"f_2272:compiler_syntax_scm",(void*)f_2272},
{"f_2268:compiler_syntax_scm",(void*)f_2268},
{"f_2218:compiler_syntax_scm",(void*)f_2218},
{"f_2216:compiler_syntax_scm",(void*)f_2216},
{"f_2212:compiler_syntax_scm",(void*)f_2212},
{"f_2082:compiler_syntax_scm",(void*)f_2082},
{"f_2080:compiler_syntax_scm",(void*)f_2080},
{"f_2076:compiler_syntax_scm",(void*)f_2076},
{"f_1984:compiler_syntax_scm",(void*)f_1984},
{"f_817:compiler_syntax_scm",(void*)f_817},
{"f_1865:compiler_syntax_scm",(void*)f_1865},
{"f_1875:compiler_syntax_scm",(void*)f_1875},
{"f_1882:compiler_syntax_scm",(void*)f_1882},
{"f_1898:compiler_syntax_scm",(void*)f_1898},
{"f_820:compiler_syntax_scm",(void*)f_820},
{"f_1863:compiler_syntax_scm",(void*)f_1863},
{"f_1859:compiler_syntax_scm",(void*)f_1859},
{"f_1855:compiler_syntax_scm",(void*)f_1855},
{"f_1851:compiler_syntax_scm",(void*)f_1851},
{"f_1847:compiler_syntax_scm",(void*)f_1847},
{"f_1843:compiler_syntax_scm",(void*)f_1843},
{"f_1839:compiler_syntax_scm",(void*)f_1839},
{"f_1703:compiler_syntax_scm",(void*)f_1703},
{"f_1707:compiler_syntax_scm",(void*)f_1707},
{"f_1710:compiler_syntax_scm",(void*)f_1710},
{"f_1720:compiler_syntax_scm",(void*)f_1720},
{"f_1764:compiler_syntax_scm",(void*)f_1764},
{"f_1744:compiler_syntax_scm",(void*)f_1744},
{"f_823:compiler_syntax_scm",(void*)f_823},
{"f_1701:compiler_syntax_scm",(void*)f_1701},
{"f_1697:compiler_syntax_scm",(void*)f_1697},
{"f_1693:compiler_syntax_scm",(void*)f_1693},
{"f_1689:compiler_syntax_scm",(void*)f_1689},
{"f_1685:compiler_syntax_scm",(void*)f_1685},
{"f_1681:compiler_syntax_scm",(void*)f_1681},
{"f_1677:compiler_syntax_scm",(void*)f_1677},
{"f_1592:compiler_syntax_scm",(void*)f_1592},
{"f_1602:compiler_syntax_scm",(void*)f_1602},
{"f_826:compiler_syntax_scm",(void*)f_826},
{"f_1590:compiler_syntax_scm",(void*)f_1590},
{"f_1586:compiler_syntax_scm",(void*)f_1586},
{"f_1582:compiler_syntax_scm",(void*)f_1582},
{"f_1578:compiler_syntax_scm",(void*)f_1578},
{"f_1574:compiler_syntax_scm",(void*)f_1574},
{"f_1570:compiler_syntax_scm",(void*)f_1570},
{"f_1566:compiler_syntax_scm",(void*)f_1566},
{"f_1495:compiler_syntax_scm",(void*)f_1495},
{"f_1499:compiler_syntax_scm",(void*)f_1499},
{"f_829:compiler_syntax_scm",(void*)f_829},
{"f_831:compiler_syntax_scm",(void*)f_831},
{"f_837:compiler_syntax_scm",(void*)f_837},
{"f_1477:compiler_syntax_scm",(void*)f_1477},
{"f_1481:compiler_syntax_scm",(void*)f_1481},
{"f_1466:compiler_syntax_scm",(void*)f_1466},
{"f_1473:compiler_syntax_scm",(void*)f_1473},
{"f_859:compiler_syntax_scm",(void*)f_859},
{"f_862:compiler_syntax_scm",(void*)f_862},
{"f_933:compiler_syntax_scm",(void*)f_933},
{"f_936:compiler_syntax_scm",(void*)f_936},
{"f_939:compiler_syntax_scm",(void*)f_939},
{"f_942:compiler_syntax_scm",(void*)f_942},
{"f_945:compiler_syntax_scm",(void*)f_945},
{"f_948:compiler_syntax_scm",(void*)f_948},
{"f_951:compiler_syntax_scm",(void*)f_951},
{"f_1045:compiler_syntax_scm",(void*)f_1045},
{"f_1106:compiler_syntax_scm",(void*)f_1106},
{"f_1410:compiler_syntax_scm",(void*)f_1410},
{"f_1324:compiler_syntax_scm",(void*)f_1324},
{"f_1327:compiler_syntax_scm",(void*)f_1327},
{"f_1294:compiler_syntax_scm",(void*)f_1294},
{"f_1257:compiler_syntax_scm",(void*)f_1257},
{"f_1220:compiler_syntax_scm",(void*)f_1220},
{"f_1183:compiler_syntax_scm",(void*)f_1183},
{"f_1158:compiler_syntax_scm",(void*)f_1158},
{"f_1133:compiler_syntax_scm",(void*)f_1133},
{"f_1112:compiler_syntax_scm",(void*)f_1112},
{"f_1055:compiler_syntax_scm",(void*)f_1055},
{"f_1058:compiler_syntax_scm",(void*)f_1058},
{"f_1077:compiler_syntax_scm",(void*)f_1077},
{"f_1073:compiler_syntax_scm",(void*)f_1073},
{"f_1035:compiler_syntax_scm",(void*)f_1035},
{"f_982:compiler_syntax_scm",(void*)f_982},
{"f_1025:compiler_syntax_scm",(void*)f_1025},
{"f_963:compiler_syntax_scm",(void*)f_963},
{"f_953:compiler_syntax_scm",(void*)f_953},
{"f_867:compiler_syntax_scm",(void*)f_867},
{"f_871:compiler_syntax_scm",(void*)f_871},
{"f_884:compiler_syntax_scm",(void*)f_884},
{"f_887:compiler_syntax_scm",(void*)f_887},
{"f_890:compiler_syntax_scm",(void*)f_890},
{"f_893:compiler_syntax_scm",(void*)f_893},
{"f_896:compiler_syntax_scm",(void*)f_896},
{"f_915:compiler_syntax_scm",(void*)f_915},
{"f_918:compiler_syntax_scm",(void*)f_918},
{"f_921:compiler_syntax_scm",(void*)f_921},
{"f_924:compiler_syntax_scm",(void*)f_924},
{"f_912:compiler_syntax_scm",(void*)f_912},
{"f_899:compiler_syntax_scm",(void*)f_899},
{"f_902:compiler_syntax_scm",(void*)f_902},
{"f_905:compiler_syntax_scm",(void*)f_905},
{"f_908:compiler_syntax_scm",(void*)f_908},
{"f_874:compiler_syntax_scm",(void*)f_874},
{"f_740:compiler_syntax_scm",(void*)f_740},
{"f_744:compiler_syntax_scm",(void*)f_744},
{"f_792:compiler_syntax_scm",(void*)f_792},
{"f_756:compiler_syntax_scm",(void*)f_756},
{"f_771:compiler_syntax_scm",(void*)f_771},
{"f_764:compiler_syntax_scm",(void*)f_764},
{"f_726:compiler_syntax_scm",(void*)f_726},
{"f_730:compiler_syntax_scm",(void*)f_730},
{"f_734:compiler_syntax_scm",(void*)f_734},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
