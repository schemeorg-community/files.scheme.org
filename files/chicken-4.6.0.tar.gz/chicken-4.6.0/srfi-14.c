/* Generated from srfi-14.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:49
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: srfi-14.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -explicit-use -no-trace -output-file srfi-14.c
   unit: srfi_14
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[102];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,19),40,37,108,97,116,105,110,49,45,62,99,104,97,114,32,110,54,49,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,19),40,109,97,107,101,45,99,104,97,114,45,115,101,116,32,115,54,51,41,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,17),40,99,104,97,114,45,115,101,116,58,115,32,99,115,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,15),40,99,104,97,114,45,115,101,116,63,32,120,54,53,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,37,100,101,102,97,117,108,116,45,98,97,115,101,32,109,97,121,98,101,45,98,97,115,101,54,55,32,112,114,111,99,54,56,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,9),40,108,112,32,99,115,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,31),40,37,99,104,97,114,45,115,101,116,58,115,47,99,104,101,99,107,32,99,115,55,49,32,112,114,111,99,55,50,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,20),40,99,104,97,114,45,115,101,116,45,99,111,112,121,32,99,115,55,54,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,11),40,108,112,32,114,101,115,116,56,53,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,20),40,99,104,97,114,45,115,101,116,61,32,46,32,114,101,115,116,55,55,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,10),40,108,112,50,32,105,49,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,16),40,108,112,32,115,49,57,56,32,114,101,115,116,57,57,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,21),40,99,104,97,114,45,115,101,116,60,61,32,46,32,114,101,115,116,57,49,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,4),40,108,112,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,16),40,108,112,32,105,49,51,48,32,97,110,115,49,51,49,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,38),40,99,104,97,114,45,115,101,116,45,104,97,115,104,32,99,115,49,49,56,32,46,32,109,97,121,98,101,45,98,111,117,110,100,49,49,57,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,99,111,110,116,97,105,110,115,63,32,99,115,49,51,57,32,99,104,97,114,49,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,12),40,108,112,32,115,105,122,101,49,53,52,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,21),40,99,104,97,114,45,115,101,116,45,115,105,122,101,32,99,115,49,53,48,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,18),40,108,112,32,105,49,54,52,32,99,111,117,110,116,49,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,32),40,99,104,97,114,45,115,101,116,45,99,111,117,110,116,32,112,114,101,100,49,54,48,32,99,115,101,116,49,54,49,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,11),40,103,49,57,48,32,99,49,57,50,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,49,56,51,32,103,49,56,55,49,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,45),40,37,115,101,116,45,99,104,97,114,45,115,101,116,32,115,101,116,49,55,54,32,112,114,111,99,49,55,55,32,99,115,49,55,56,32,99,104,97,114,115,49,55,57,41,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,11),40,103,50,49,48,32,99,50,49,50,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,48,51,32,103,50,48,55,50,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,46),40,37,115,101,116,45,99,104,97,114,45,115,101,116,33,32,115,101,116,49,57,54,32,112,114,111,99,49,57,55,32,99,115,49,57,56,32,99,104,97,114,115,49,57,57,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,17),40,97,49,54,48,53,32,115,50,49,56,32,105,50,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,97,100,106,111,105,110,32,99,115,50,49,54,32,46,32,99,104,97,114,115,50,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,17),40,97,49,54,49,55,32,115,50,50,50,32,105,50,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,35),40,99,104,97,114,45,115,101,116,45,97,100,106,111,105,110,33,32,99,115,50,50,48,32,46,32,99,104,97,114,115,50,50,49,41,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,17),40,97,49,54,50,57,32,115,50,50,54,32,105,50,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,100,101,108,101,116,101,32,99,115,50,50,52,32,46,32,99,104,97,114,115,50,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,17),40,97,49,54,52,49,32,115,50,51,48,32,105,50,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,35),40,99,104,97,114,45,115,101,116,45,100,101,108,101,116,101,33,32,99,115,50,50,56,32,46,32,99,104,97,114,115,50,50,57,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,25),40,99,104,97,114,45,115,101,116,45,99,117,114,115,111,114,32,99,115,101,116,50,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,28),40,101,110,100,45,111,102,45,99,104,97,114,45,115,101,116,63,32,99,117,114,115,111,114,50,51,51,41,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,32),40,99,104,97,114,45,115,101,116,45,114,101,102,32,99,115,101,116,50,51,52,32,99,117,114,115,111,114,50,51,53,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,40),40,99,104,97,114,45,115,101,116,45,99,117,114,115,111,114,45,110,101,120,116,32,99,115,101,116,50,51,54,32,99,117,114,115,111,114,50,51,55,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,4),40,108,112,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,49),40,37,99,104,97,114,45,115,101,116,45,99,117,114,115,111,114,45,110,101,120,116,32,99,115,101,116,50,51,57,32,99,117,114,115,111,114,50,52,48,32,112,114,111,99,50,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,50,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,33),40,99,104,97,114,45,115,101,116,45,102,111,114,45,101,97,99,104,32,112,114,111,99,50,53,56,32,99,115,50,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,50,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,28),40,99,104,97,114,45,115,101,116,45,109,97,112,32,112,114,111,99,50,55,54,32,99,115,50,55,55,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,16),40,108,112,32,105,51,48,53,32,97,110,115,51,48,54,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,37),40,99,104,97,114,45,115,101,116,45,102,111,108,100,32,107,111,110,115,51,48,48,32,107,110,105,108,51,48,49,32,99,115,51,48,50,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,51,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,30),40,99,104,97,114,45,115,101,116,45,101,118,101,114,121,32,112,114,101,100,51,49,50,32,99,115,51,49,51,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,51,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,28),40,99,104,97,114,45,115,101,116,45,97,110,121,32,112,114,101,100,51,50,57,32,99,115,51,51,48,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,12),40,108,112,32,115,101,101,100,51,53,53,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,47),40,37,99,104,97,114,45,115,101,116,45,117,110,102,111,108,100,33,32,112,51,52,57,32,102,51,53,48,32,103,51,53,49,32,115,51,53,50,32,115,101,101,100,51,53,51,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,56),40,99,104,97,114,45,115,101,116,45,117,110,102,111,108,100,32,112,51,54,53,32,102,51,54,54,32,103,51,54,55,32,115,101,101,100,51,54,56,32,46,32,109,97,121,98,101,45,98,97,115,101,51,54,57,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,54),40,99,104,97,114,45,115,101,116,45,117,110,102,111,108,100,33,32,112,51,55,50,32,102,51,55,51,32,103,51,55,52,32,115,101,101,100,51,55,53,32,98,97,115,101,45,99,115,101,116,51,55,54,41,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,6),40,103,51,56,57,41,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,51,56,50,32,103,51,56,54,51,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,32),40,37,108,105,115,116,45,62,99,104,97,114,45,115,101,116,33,32,99,104,97,114,115,51,55,56,32,115,51,55,57,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,21),40,99,104,97,114,45,115,101,116,32,46,32,99,104,97,114,115,51,57,56,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,41),40,108,105,115,116,45,62,99,104,97,114,45,115,101,116,32,99,104,97,114,115,52,48,49,32,46,32,109,97,121,98,101,45,98,97,115,101,52,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,37),40,108,105,115,116,45,62,99,104,97,114,45,115,101,116,33,32,99,104,97,114,115,52,48,53,32,98,97,115,101,45,99,115,52,48,54,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,16),40,108,112,32,105,52,49,49,32,97,110,115,52,49,50,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,22),40,99,104,97,114,45,115,101,116,45,62,108,105,115,116,32,99,115,52,48,56,41,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,50,49,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,41),40,37,115,116,114,105,110,103,45,62,99,104,97,114,45,115,101,116,33,32,115,116,114,52,49,56,32,98,115,52,49,57,32,112,114,111,99,52,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,41),40,115,116,114,105,110,103,45,62,99,104,97,114,45,115,101,116,32,115,116,114,52,51,49,32,46,32,109,97,121,98,101,45,98,97,115,101,52,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,37),40,115,116,114,105,110,103,45,62,99,104,97,114,45,115,101,116,33,32,115,116,114,52,51,53,32,98,97,115,101,45,99,115,52,51,54,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,9),40,108,112,32,106,52,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,24),40,99,104,97,114,45,115,101,116,45,62,115,116,114,105,110,103,32,99,115,52,51,56,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,4),40,108,112,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,65),40,37,117,99,115,45,114,97,110,103,101,45,62,99,104,97,114,45,115,101,116,33,32,108,111,119,101,114,52,53,49,32,117,112,112,101,114,52,53,50,32,101,114,114,111,114,63,52,53,51,32,98,115,52,53,52,32,112,114,111,99,52,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,49),40,117,99,115,45,114,97,110,103,101,45,62,99,104,97,114,45,115,101,116,32,108,111,119,101,114,52,55,50,32,117,112,112,101,114,52,55,51,32,46,32,114,101,115,116,52,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,61),40,117,99,115,45,114,97,110,103,101,45,62,99,104,97,114,45,115,101,116,33,32,108,111,119,101,114,52,56,53,32,117,112,112,101,114,52,56,54,32,101,114,114,111,114,63,52,56,55,32,98,97,115,101,45,99,115,52,56,56,41,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,52,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,39),40,37,99,104,97,114,45,115,101,116,45,102,105,108,116,101,114,33,32,112,114,101,100,52,57,48,32,100,115,52,57,49,32,98,115,52,57,50,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,56),40,99,104,97,114,45,115,101,116,45,102,105,108,116,101,114,32,112,114,101,100,105,99,97,116,101,53,49,52,32,100,111,109,97,105,110,53,49,53,32,46,32,109,97,121,98,101,45,98,97,115,101,53,49,54,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,52),40,99,104,97,114,45,115,101,116,45,102,105,108,116,101,114,33,32,112,114,101,100,105,99,97,116,101,53,49,57,32,100,111,109,97,105,110,53,50,48,32,98,97,115,101,45,99,115,53,50,49,41,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,17),40,45,62,99,104,97,114,45,115,101,116,32,120,53,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,53,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,24),40,37,115,116,114,105,110,103,45,105,116,101,114,32,112,53,50,55,32,115,53,50,56,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,9),40,108,112,32,105,53,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,14),40,103,53,52,57,32,99,115,101,116,53,53,49,41,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,53,52,50,32,103,53,52,54,53,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,47),40,37,99,104,97,114,45,115,101,116,45,97,108,103,101,98,114,97,32,115,53,51,54,32,99,115,101,116,115,53,51,55,32,111,112,53,51,56,32,112,114,111,99,53,51,57,41,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,17),40,97,50,55,49,52,32,105,53,54,57,32,118,53,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,27),40,99,104,97,114,45,115,101,116,45,99,111,109,112,108,101,109,101,110,116,32,99,115,53,54,54,41,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,17),40,97,50,55,52,55,32,105,53,56,52,32,118,53,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,30),40,99,104,97,114,45,115,101,116,45,99,111,109,112,108,101,109,101,110,116,33,32,99,115,101,116,53,56,50,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,22),40,97,50,55,56,49,32,115,53,57,57,32,105,54,48,48,32,118,54,48,49,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,37),40,99,104,97,114,45,115,101,116,45,117,110,105,111,110,33,32,99,115,101,116,49,53,57,55,32,46,32,99,115,101,116,115,53,57,56,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,22),40,97,50,56,50,52,32,115,54,48,57,32,105,54,49,48,32,118,54,49,49,41,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,27),40,99,104,97,114,45,115,101,116,45,117,110,105,111,110,32,46,32,99,115,101,116,115,54,48,55,41,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,22),40,97,50,56,54,54,32,115,54,49,57,32,105,54,50,48,32,118,54,50,49,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,44),40,99,104,97,114,45,115,101,116,45,105,110,116,101,114,115,101,99,116,105,111,110,33,32,99,115,101,116,49,54,49,55,32,46,32,99,115,101,116,115,54,49,56,41,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,22),40,97,50,57,48,53,32,115,54,50,57,32,105,54,51,48,32,118,54,51,49,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,34),40,99,104,97,114,45,115,101,116,45,105,110,116,101,114,115,101,99,116,105,111,110,32,46,32,99,115,101,116,115,54,50,55,41,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,22),40,97,50,57,52,51,32,115,54,51,57,32,105,54,52,48,32,118,54,52,49,41,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,42),40,99,104,97,114,45,115,101,116,45,100,105,102,102,101,114,101,110,99,101,33,32,99,115,101,116,49,54,51,55,32,46,32,99,115,101,116,115,54,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,22),40,97,50,57,56,50,32,115,54,53,48,32,105,54,53,49,32,118,54,53,50,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,39),40,99,104,97,114,45,115,101,116,45,100,105,102,102,101,114,101,110,99,101,32,99,115,49,54,52,55,32,46,32,99,115,101,116,115,54,52,56,41,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,22),40,97,51,48,50,48,32,115,54,54,48,32,105,54,54,49,32,118,54,54,50,41,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,35),40,99,104,97,114,45,115,101,116,45,120,111,114,33,32,99,115,101,116,49,54,53,56,32,46,32,99,115,101,116,115,54,53,57,41,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,22),40,97,51,48,56,52,32,115,54,55,53,32,105,54,55,54,32,118,54,55,55,41,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,25),40,99,104,97,114,45,115,101,116,45,120,111,114,32,46,32,99,115,101,116,115,54,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,17),40,97,51,49,53,55,32,105,55,48,52,32,118,55,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,12),40,103,55,48,49,32,99,115,55,48,51,41,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,54,57,52,32,103,54,57,56,55,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,62),40,37,99,104,97,114,45,115,101,116,45,100,105,102,102,43,105,110,116,101,114,115,101,99,116,105,111,110,33,32,100,105,102,102,54,56,56,32,105,110,116,54,56,57,32,99,115,101,116,115,54,57,48,32,112,114,111,99,54,57,49,41,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,17),40,97,51,50,53,48,32,105,55,51,51,32,118,55,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,54),40,99,104,97,114,45,115,101,116,45,100,105,102,102,43,105,110,116,101,114,115,101,99,116,105,111,110,33,32,99,115,49,55,50,56,32,99,115,50,55,50,57,32,46,32,99,115,101,116,115,55,51,48,41,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,46),40,99,104,97,114,45,115,101,116,45,100,105,102,102,43,105,110,116,101,114,115,101,99,116,105,111,110,32,99,115,49,55,53,51,32,46,32,99,115,101,116,115,55,53,52,41,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,56,51,56,32,103,56,52,56,56,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,56,49,53,32,103,56,50,53,56,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,55,57,50,32,103,56,48,50,56,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,55,54,55,32,103,55,55,55,55,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_14_toplevel)
C_externexport void C_ccall C_srfi_14_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_fcall f_3540(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_fcall f_3505(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_fcall f_3470(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_fcall f_3431(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3138)
static void C_fcall f_3138(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3144)
static void C_fcall f_3144(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_fcall f_3152(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_fcall f_2631(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2637)
static void C_fcall f_2637(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2687)
static void C_ccall f_2687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_fcall f_2645(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_fcall f_2654(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_fcall f_2590(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2600)
static void C_fcall f_2600(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_fcall f_2462(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2468)
static void C_fcall f_2468(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_fcall f_2360(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2408)
static void C_fcall f_2408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static C_word C_fcall f_2379(C_word t0,C_word t1);
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2311)
static C_word C_fcall f_2311(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_fcall f_2228(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2241)
static C_word C_fcall f_2241(C_word t0,C_word t1);
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_fcall f_2185(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_fcall f_2099(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2105)
static void C_fcall f_2105(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2113)
static C_word C_fcall f_2113(C_word t0,C_word t1);
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_fcall f_2035(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2041)
static void C_fcall f_2041(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_fcall f_1981(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_fcall f_1927(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_fcall f_1875(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_fcall f_1802(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1727)
static void C_ccall f_1727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1736)
static void C_fcall f_1736(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_fcall f_1675(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static C_word C_fcall f_1684(C_word t0,C_word t1);
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1559)
static void C_fcall f_1559(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_fcall f_1568(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_fcall f_1576(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_fcall f_1511(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_fcall f_1523(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_fcall f_1531(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_fcall f_1453(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_ccall f_1402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static C_word C_fcall f_1411(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1250)
static void C_ccall f_1250(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1250)
static void C_ccall f_1250r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_fcall f_1257(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1271)
static void C_fcall f_1271(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1321)
static C_word C_fcall f_1321(C_word t0,C_word t1);
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1162)
static void C_ccall f_1162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1164)
static void C_fcall f_1164(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1191)
static void C_fcall f_1191(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1108)
static void C_fcall f_1108(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1040)
static void C_fcall f_1040(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1046)
static void C_fcall f_1046(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1053)
static void C_ccall f_1053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_993)
static void C_fcall f_993(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_953)
static void C_ccall f_953(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_3540)
static void C_fcall trf_3540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3540(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3540(t0,t1,t2);}

C_noret_decl(trf_3505)
static void C_fcall trf_3505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3505(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3505(t0,t1,t2);}

C_noret_decl(trf_3470)
static void C_fcall trf_3470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3470(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3470(t0,t1,t2);}

C_noret_decl(trf_3431)
static void C_fcall trf_3431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3431(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3431(t0,t1,t2);}

C_noret_decl(trf_3138)
static void C_fcall trf_3138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3138(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3138(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3144)
static void C_fcall trf_3144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3144(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3144(t0,t1,t2);}

C_noret_decl(trf_3152)
static void C_fcall trf_3152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3152(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3152(t0,t1,t2);}

C_noret_decl(trf_2631)
static void C_fcall trf_2631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2631(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2631(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2637)
static void C_fcall trf_2637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2637(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2637(t0,t1,t2);}

C_noret_decl(trf_2645)
static void C_fcall trf_2645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2645(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2645(t0,t1,t2);}

C_noret_decl(trf_2654)
static void C_fcall trf_2654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2654(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2654(t0,t1,t2);}

C_noret_decl(trf_2590)
static void C_fcall trf_2590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2590(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2590(t0,t1,t2);}

C_noret_decl(trf_2600)
static void C_fcall trf_2600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2600(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2600(t0,t1,t2);}

C_noret_decl(trf_2462)
static void C_fcall trf_2462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2462(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2462(t0,t1,t2,t3);}

C_noret_decl(trf_2468)
static void C_fcall trf_2468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2468(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2468(t0,t1,t2);}

C_noret_decl(trf_2360)
static void C_fcall trf_2360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2360(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2360(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2408)
static void C_fcall trf_2408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2408(t0,t1);}

C_noret_decl(trf_2228)
static void C_fcall trf_2228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2228(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2228(t0,t1,t2,t3);}

C_noret_decl(trf_2185)
static void C_fcall trf_2185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2185(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2185(t0,t1,t2,t3);}

C_noret_decl(trf_2099)
static void C_fcall trf_2099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2099(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2099(t0,t1,t2);}

C_noret_decl(trf_2105)
static void C_fcall trf_2105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2105(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2105(t0,t1,t2);}

C_noret_decl(trf_2035)
static void C_fcall trf_2035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2035(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2035(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2041)
static void C_fcall trf_2041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2041(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2041(t0,t1,t2);}

C_noret_decl(trf_1981)
static void C_fcall trf_1981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1981(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1981(t0,t1,t2);}

C_noret_decl(trf_1927)
static void C_fcall trf_1927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1927(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1927(t0,t1,t2);}

C_noret_decl(trf_1875)
static void C_fcall trf_1875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1875(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1875(t0,t1,t2,t3);}

C_noret_decl(trf_1802)
static void C_fcall trf_1802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1802(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1802(t0,t1,t2);}

C_noret_decl(trf_1736)
static void C_fcall trf_1736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1736(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1736(t0,t1,t2);}

C_noret_decl(trf_1675)
static void C_fcall trf_1675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1675(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1675(t0,t1,t2,t3);}

C_noret_decl(trf_1559)
static void C_fcall trf_1559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1559(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1559(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1568)
static void C_fcall trf_1568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1568(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1568(t0,t1,t2);}

C_noret_decl(trf_1576)
static void C_fcall trf_1576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1576(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1576(t0,t1,t2);}

C_noret_decl(trf_1511)
static void C_fcall trf_1511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1511(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1511(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1523)
static void C_fcall trf_1523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1523(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1523(t0,t1,t2);}

C_noret_decl(trf_1531)
static void C_fcall trf_1531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1531(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1531(t0,t1,t2);}

C_noret_decl(trf_1453)
static void C_fcall trf_1453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1453(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1453(t0,t1,t2,t3);}

C_noret_decl(trf_1257)
static void C_fcall trf_1257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1257(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1257(t0,t1);}

C_noret_decl(trf_1271)
static void C_fcall trf_1271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1271(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1271(t0,t1,t2,t3);}

C_noret_decl(trf_1164)
static void C_fcall trf_1164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1164(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1164(t0,t1,t2,t3);}

C_noret_decl(trf_1191)
static void C_fcall trf_1191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1191(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1191(t0,t1,t2);}

C_noret_decl(trf_1108)
static void C_fcall trf_1108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1108(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1108(t0,t1,t2);}

C_noret_decl(trf_1040)
static void C_fcall trf_1040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1040(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1040(t0,t1,t2);}

C_noret_decl(trf_1046)
static void C_fcall trf_1046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1046(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1046(t0,t1,t2);}

C_noret_decl(trf_993)
static void C_fcall trf_993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_993(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_993(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_14_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_14_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(842)){
C_save(t1);
C_rereclaim2(842*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,102);
lf[1]=C_h_intern(&lf[1],13,"make-char-set");
lf[2]=C_h_intern(&lf[2],8,"char-set");
lf[3]=C_h_intern(&lf[3],10,"char-set:s");
lf[4]=C_h_intern(&lf[4],9,"char-set\077");
lf[6]=C_h_intern(&lf[6],9,"substring");
lf[7]=C_h_intern(&lf[7],9,"\003syserror");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000 BASE-CS parameter not a char-set");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\0003Expected final base char set -- too many parameters");
lf[10]=C_h_intern(&lf[10],11,"make-string");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\016Not a char-set");
lf[13]=C_h_intern(&lf[13],13,"char-set-copy");
lf[14]=C_h_intern(&lf[14],9,"char-set=");
lf[15]=C_h_intern(&lf[15],10,"char-set<=");
lf[16]=C_h_intern(&lf[16],13,"char-set-hash");
lf[17]=C_h_intern(&lf[17],6,"modulo");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[19]=C_h_intern(&lf[19],18,"char-set-contains\077");
lf[20]=C_h_intern(&lf[20],13,"char-set-size");
lf[21]=C_h_intern(&lf[21],14,"char-set-count");
lf[24]=C_h_intern(&lf[24],15,"char-set-adjoin");
lf[25]=C_h_intern(&lf[25],16,"char-set-adjoin!");
lf[26]=C_h_intern(&lf[26],15,"char-set-delete");
lf[27]=C_h_intern(&lf[27],16,"char-set-delete!");
lf[28]=C_h_intern(&lf[28],15,"char-set-cursor");
lf[30]=C_h_intern(&lf[30],16,"end-of-char-set\077");
lf[31]=C_h_intern(&lf[31],12,"char-set-ref");
lf[32]=C_h_intern(&lf[32],20,"char-set-cursor-next");
lf[33]=C_h_intern(&lf[33],17,"char-set-for-each");
lf[34]=C_h_intern(&lf[34],12,"char-set-map");
lf[35]=C_h_intern(&lf[35],13,"char-set-fold");
lf[36]=C_h_intern(&lf[36],14,"char-set-every");
lf[37]=C_h_intern(&lf[37],12,"char-set-any");
lf[39]=C_h_intern(&lf[39],15,"char-set-unfold");
lf[40]=C_h_intern(&lf[40],16,"char-set-unfold!");
lf[42]=C_h_intern(&lf[42],14,"list->char-set");
lf[43]=C_h_intern(&lf[43],15,"list->char-set!");
lf[44]=C_h_intern(&lf[44],14,"char-set->list");
lf[46]=C_h_intern(&lf[46],16,"string->char-set");
lf[47]=C_h_intern(&lf[47],17,"string->char-set!");
lf[48]=C_h_intern(&lf[48],16,"char-set->string");
lf[50]=C_h_intern(&lf[50],3,"min");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000`Requested UCS range contains unavailable characters -- this implementation "
"only supports Latin-1");
lf[52]=C_h_intern(&lf[52],19,"ucs-range->char-set");
lf[53]=C_h_intern(&lf[53],20,"ucs-range->char-set!");
lf[55]=C_h_intern(&lf[55],15,"char-set-filter");
lf[56]=C_h_intern(&lf[56],16,"char-set-filter!");
lf[57]=C_h_intern(&lf[57],10,"->char-set");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\036Not a charset, string or char.");
lf[61]=C_h_intern(&lf[61],19,"char-set-complement");
lf[62]=C_h_intern(&lf[62],20,"char-set-complement!");
lf[63]=C_h_intern(&lf[63],15,"char-set-union!");
lf[64]=C_h_intern(&lf[64],14,"char-set-union");
lf[65]=C_h_intern(&lf[65],14,"char-set:empty");
lf[66]=C_h_intern(&lf[66],22,"char-set-intersection!");
lf[67]=C_h_intern(&lf[67],21,"char-set-intersection");
lf[68]=C_h_intern(&lf[68],13,"char-set:full");
lf[69]=C_h_intern(&lf[69],20,"char-set-difference!");
lf[70]=C_h_intern(&lf[70],19,"char-set-difference");
lf[71]=C_h_intern(&lf[71],13,"char-set-xor!");
lf[72]=C_h_intern(&lf[72],12,"char-set-xor");
lf[74]=C_h_intern(&lf[74],27,"char-set-diff+intersection!");
lf[75]=C_h_intern(&lf[75],26,"char-set-diff+intersection");
lf[76]=C_h_intern(&lf[76],11,"string-copy");
lf[77]=C_h_intern(&lf[77],19,"char-set:lower-case");
lf[78]=C_h_intern(&lf[78],19,"char-set:upper-case");
lf[79]=C_h_intern(&lf[79],19,"char-set:title-case");
lf[80]=C_h_intern(&lf[80],15,"char-set:letter");
lf[81]=C_h_intern(&lf[81],14,"char-set:digit");
lf[82]=C_h_intern(&lf[82],18,"char-set:hex-digit");
lf[83]=C_h_intern(&lf[83],21,"char-set:letter+digit");
lf[84]=C_h_intern(&lf[84],20,"char-set:punctuation");
lf[85]=C_h_intern(&lf[85],15,"char-set:symbol");
lf[86]=C_h_intern(&lf[86],16,"char-set:graphic");
lf[87]=C_h_intern(&lf[87],19,"char-set:whitespace");
lf[88]=C_h_intern(&lf[88],17,"char-set:printing");
lf[89]=C_h_intern(&lf[89],14,"char-set:blank");
lf[90]=C_h_intern(&lf[90],20,"char-set:iso-control");
lf[91]=C_h_intern(&lf[91],14,"char-set:ascii");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\011\376\003\000\000\002\376\377\001\000\000\000 \376\003\000\000\002\376\377\001\000\000\000\240\376\377\016");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\011\376\003\000\000\002\376\377\001\000\000\000\012\376\003\000\000\002\376\377\001\000\000\000\013\376\003\000\000\002\376\377\001\000\000\000\014\376\003\000\000\002\376\377\001\000\000\000\015\376\003\000\000\002\376\377\001\000\000\000 \376\003\000\000\002\376\377\001"
"\000\000\000\240\376\377\016");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\242\376\003\000\000\002\376\377\001\000\000\000\243\376\003\000\000\002\376\377\001\000\000\000\244\376\003\000\000\002\376\377\001\000\000\000\245\376\003\000\000\002\376\377\001\000\000\000\246\376\003\000\000\002\376\377\001\000\000\000\247\376\003\000\000\002\376\377\001"
"\000\000\000\250\376\003\000\000\002\376\377\001\000\000\000\251\376\003\000\000\002\376\377\001\000\000\000\254\376\003\000\000\002\376\377\001\000\000\000\256\376\003\000\000\002\376\377\001\000\000\000\257\376\003\000\000\002\376\377\001\000\000\000\260\376\003\000\000\002\376\377\001\000\000\000\261\376\003\000\000"
"\002\376\377\001\000\000\000\264\376\003\000\000\002\376\377\001\000\000\000\266\376\003\000\000\002\376\377\001\000\000\000\270\376\003\000\000\002\376\377\001\000\000\000\327\376\003\000\000\002\376\377\001\000\000\000\367\376\377\016");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\011$+<=>^`|~");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\241\376\003\000\000\002\376\377\001\000\000\000\253\376\003\000\000\002\376\377\001\000\000\000\255\376\003\000\000\002\376\377\001\000\000\000\267\376\003\000\000\002\376\377\001\000\000\000\273\376\003\000\000\002\376\377\001\000\000\000\277\376\377\016");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\027!\042#%&\047()*,-./:;\077@[\134]_{}");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\0260123456789abcdefABCDEF");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\0120123456789");
lf[100]=C_h_intern(&lf[100],17,"register-feature!");
lf[101]=C_h_intern(&lf[101],7,"srfi-14");
C_register_lf2(lf,102,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_951,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:15: register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[100]+1)))(3,*((C_word*)lf[100]+1),t2,lf[101]);}

/* k949 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word ab[192],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! %latin1->char ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_953,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[1]+1 /* (set! make-char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_965,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[3]+1 /* (set! char-set:s ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_971,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[4]+1 /* (set! char-set? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_977,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[5] /* (set! %default-base ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_993,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[11] /* (set! %char-set:s/check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1040,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[13]+1 /* (set! char-set-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1073,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[14]+1 /* (set! char-set= ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1087,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[15]+1 /* (set! char-set<= ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1142,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[16]+1 /* (set! char-set-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1250,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[19]+1 /* (set! char-set-contains? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1363,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[20]+1 /* (set! char-set-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1402,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[21]+1 /* (set! char-set-count ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1444,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[22] /* (set! %set-char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1511,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[23] /* (set! %set-char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1559,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[24]+1 /* (set! char-set-adjoin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1600,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[25]+1 /* (set! char-set-adjoin! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1612,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[26]+1 /* (set! char-set-delete ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1624,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[27]+1 /* (set! char-set-delete! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1636,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[28]+1 /* (set! char-set-cursor ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1648,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[30]+1 /* (set! end-of-char-set? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1654,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[31]+1 /* (set! char-set-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1660,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[32]+1 /* (set! char-set-cursor-next ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1666,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate(&lf[29] /* (set! %char-set-cursor-next ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1675,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[33]+1 /* (set! char-set-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1727,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[34]+1 /* (set! char-set-map ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1787,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[35]+1 /* (set! char-set-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1866,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[36]+1 /* (set! char-set-every ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1918,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[37]+1 /* (set! char-set-any ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1972,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate(&lf[38] /* (set! %char-set-unfold! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2035,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[39]+1 /* (set! char-set-unfold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2077,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[40]+1 /* (set! char-set-unfold! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2089,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate(&lf[41] /* (set! %list->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2099,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[2]+1 /* (set! char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2142,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[42]+1 /* (set! list->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2154,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[43]+1 /* (set! list->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2166,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[44]+1 /* (set! char-set->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2176,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate(&lf[45] /* (set! %string->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[46]+1 /* (set! string->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2277,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[47]+1 /* (set! string->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2289,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[48]+1 /* (set! char-set->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2299,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate(&lf[49] /* (set! %ucs-range->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2360,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[52]+1 /* (set! ucs-range->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2422,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[53]+1 /* (set! ucs-range->char-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2452,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate(&lf[54] /* (set! %char-set-filter! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2462,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[55]+1 /* (set! char-set-filter ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2530,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[56]+1 /* (set! char-set-filter! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[57]+1 /* (set! ->char-set ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2560,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate(&lf[59] /* (set! %string-iter ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2590,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate(&lf[60] /* (set! %char-set-algebra ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2631,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[61]+1 /* (set! char-set-complement ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2700,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[62]+1 /* (set! char-set-complement! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2739,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[63]+1 /* (set! char-set-union! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2772,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[64]+1 /* (set! char-set-union ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2803,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[66]+1 /* (set! char-set-intersection! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2857,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[67]+1 /* (set! char-set-intersection ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2884,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[69]+1 /* (set! char-set-difference! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2934,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[70]+1 /* (set! char-set-difference ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2965,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[71]+1 /* (set! char-set-xor! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3011,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[72]+1 /* (set! char-set-xor ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3063,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate(&lf[73] /* (set! %char-set-diff+intersection! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3138,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[74]+1 /* (set! char-set-diff+intersection! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3233,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[75]+1 /* (set! char-set-diff+intersection ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3304,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t65=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:630: char-set */
t66=*((C_word*)lf[2]+1);
((C_proc2)(void*)(*((C_word*)t66+1)))(2,t66,t65);}

/* k3331 in k949 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3333,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! char-set:empty ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:631: char-set-complement */
t4=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[65]+1));}

/* k3335 in k3331 in k949 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3337,2,t0,t1);}
t2=C_mutate((C_word*)lf[68]+1 /* (set! char-set:full ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:634: ucs-range->char-set */
t4=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(97),C_fix(123));}

/* k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:635: ucs-range->char-set! */
t3=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(223),C_fix(247),C_SCHEME_TRUE,t1);}

/* k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:636: ucs-range->char-set! */
t3=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(248),C_fix(256),C_SCHEME_TRUE,t1);}

/* k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:637: char-set-adjoin! */
t3=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_make_character(181));}

/* k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3350,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! char-set:lower-case ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3354,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:640: ucs-range->char-set */
t4=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(65),C_fix(91));}

/* k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3585,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:643: ucs-range->char-set! */
t4=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,C_fix(192),C_fix(215),C_SCHEME_TRUE,t1);}

/* k3583 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:642: ucs-range->char-set! */
t2=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(216),C_fix(223),C_SCHEME_TRUE,t1);}

/* k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3357,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! char-set:upper-case ...) */,t1);
t3=C_mutate((C_word*)lf[79]+1 /* (set! char-set:title-case ...) */,*((C_word*)lf[65]+1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:648: char-set-union */
t5=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[78]+1),*((C_word*)lf[77]+1));}

/* k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3365,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:649: char-set-adjoin! */
t3=*((C_word*)lf[25]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_make_character(170),C_make_character(186));}

/* k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3365,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! char-set:letter ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:653: string->char-set */
t4=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[99]);}

/* k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3369,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1 /* (set! char-set:digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:654: string->char-set */
t4=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[98]);}

/* k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3373,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1 /* (set! char-set:hex-digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:657: char-set-union */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[80]+1),*((C_word*)lf[81]+1));}

/* k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3377,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1 /* (set! char-set:letter+digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:660: string->char-set */
t4=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[97]);}

/* k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3384,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3540,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li114),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3540(t10,t6,lf[96]);}

/* loop767 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_fcall f_3540(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3540,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=lf[0];
t4=C_slot(t2,C_fix(0));
t5=C_make_character(C_unfix(t4));
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop767780 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop767780 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:667: list->char-set! */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3387,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1 /* (set! char-set:punctuation ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:670: string->char-set */
t4=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[95]);}

/* k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3391,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3394,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3505,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li113),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3505(t10,t6,lf[94]);}

/* loop792 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_fcall f_3505(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3505,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=lf[0];
t4=C_slot(t2,C_fix(0));
t5=C_make_character(C_unfix(t4));
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop792805 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop792805 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3397,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:689: list->char-set! */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k3395 in k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3397,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! char-set:symbol ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3401,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:693: char-set-union */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[83]+1),*((C_word*)lf[84]+1),*((C_word*)lf[85]+1));}

/* k3399 in k3395 in k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3401,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* (set! char-set:graphic ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3468,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3470,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=((C_word)li112),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_3470(t12,t8,lf[93]);}

/* loop815 in k3399 in k3395 in k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_fcall f_3470(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3470,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=lf[0];
t4=C_slot(t2,C_fix(0));
t5=C_make_character(C_unfix(t4));
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop815828 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop815828 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3466 in k3399 in k3395 in k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:696: list->char-set */
t2=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3403 in k3399 in k3395 in k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3405,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! char-set:whitespace ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:704: char-set-union */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[87]+1),*((C_word*)lf[86]+1));}

/* k3407 in k3403 in k3399 in k3395 in k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3409,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1 /* (set! char-set:printing ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3429,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3431,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=((C_word)li111),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_3431(t12,t8,lf[92]);}

/* loop838 in k3407 in k3403 in k3399 in k3395 in k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_fcall f_3431(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3431,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=lf[0];
t4=C_slot(t2,C_fix(0));
t5=C_make_character(C_unfix(t4));
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop838851 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop838851 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3427 in k3407 in k3403 in k3399 in k3395 in k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:707: list->char-set */
t2=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3411 in k3407 in k3403 in k3399 in k3395 in k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3413,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* (set! char-set:blank ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3425,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:713: ucs-range->char-set */
t5=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(0),C_fix(32));}

/* k3423 in k3411 in k3407 in k3403 in k3399 in k3395 in k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:713: ucs-range->char-set! */
t2=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(127),C_fix(160),C_SCHEME_TRUE,t1);}

/* k3415 in k3411 in k3407 in k3403 in k3399 in k3395 in k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3417,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* (set! char-set:iso-control ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:715: ucs-range->char-set */
t4=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(0),C_fix(128));}

/* k3419 in k3415 in k3411 in k3407 in k3403 in k3399 in k3395 in k3392 in k3389 in k3385 in k3382 in k3379 in k3375 in k3371 in k3367 in k3363 in k3360 in k3355 in k3352 in k3348 in k3345 in k3342 in k3339 in k3335 in k3331 in k949 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[91]+1 /* (set! char-set:ascii ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* char-set-diff+intersection in k949 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3304r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3304r(t0,t1,t2,t3);}}

static void C_ccall f_3304r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3308,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3329,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:616: %char-set:s/check */
f_1040(t5,t2,lf[75]);}

/* k3327 in char-set-diff+intersection in k949 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:616: string-copy */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k3306 in char-set-diff+intersection in k949 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:617: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t2,C_fix(256),C_make_character(0));}

/* k3309 in k3306 in char-set-diff+intersection in k949 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:618: %char-set-diff+intersection! */
f_3138(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[75]);}

/* k3312 in k3309 in k3306 in char-set-diff+intersection in k949 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3321,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:619: make-char-set */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3319 in k3312 in k3309 in k3306 in char-set-diff+intersection in k949 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3325,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:619: make-char-set */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3323 in k3319 in k3312 in k3309 in k3306 in char-set-diff+intersection in k949 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:619: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-diff+intersection! in k949 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3233r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3233r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3233r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3237,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm:606: %char-set:s/check */
f_1040(t5,t2,lf[74]);}

/* k3235 in char-set-diff+intersection! in k949 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm:607: %char-set:s/check */
f_1040(t2,((C_word*)t0)[3],lf[74]);}

/* k3238 in k3235 in char-set-diff+intersection! in k949 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li108),tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:608: %string-iter */
f_2590(t2,t3,((C_word*)t0)[3]);}

/* a3250 in k3238 in k3235 in char-set-diff+intersection! in k949 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3251,4,t0,t1,t2,t3);}
t4=C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[3];
t7=t2;
t8=t5;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_i_string_set(t6,t7,C_make_character(0)));}
else{
t5=((C_word*)t0)[3];
t6=t2;
t7=C_i_string_ref(t5,t6);
t8=C_fix(C_character_code(t7));
t9=C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}
else{
t10=t1;
t11=((C_word*)t0)[2];
t12=t2;
t13=t10;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_i_string_set(t11,t12,C_make_character(0)));}}}

/* k3241 in k3238 in k3235 in char-set-diff+intersection! in k949 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3246,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:612: %char-set-diff+intersection! */
f_3138(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[74]);}

/* k3244 in k3241 in k3238 in k3235 in char-set-diff+intersection! in k949 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:613: values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-diff+intersection! in k949 */
static void C_fcall f_3138(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3138,NULL,5,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3144,a[2]=t7,a[3]=t5,a[4]=t3,a[5]=t2,a[6]=((C_word)li106),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_3144(t9,t1,t4);}

/* loop694 in %char-set-diff+intersection! in k949 */
static void C_fcall f_3144(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3144,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3152,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li105),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3220,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g701702 */
t6=t3;
f_3152(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3218 in loop694 in %char-set-diff+intersection! in k949 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3144(t3,((C_word*)t0)[2],t2);}

/* g701 in loop694 in %char-set-diff+intersection! in k949 */
static void C_fcall f_3152(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3152,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li104),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3217,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:602: %char-set:s/check */
f_1040(t4,t2,((C_word*)t0)[2]);}

/* k3215 in g701 in loop694 in %char-set-diff+intersection! in k949 */
static void C_ccall f_3217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:597: %string-iter */
f_2590(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3157 in g701 in loop694 in %char-set-diff+intersection! in k949 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3158,4,t0,t1,t2,t3);}
t4=C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=((C_word*)t0)[3];
t6=t2;
t7=C_i_string_ref(t5,t6);
t8=C_fix(C_character_code(t7));
t9=C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}
else{
t10=((C_word*)t0)[3];
t11=t2;
t12=C_i_string_set(t10,t11,C_make_character(0));
t13=t1;
t14=((C_word*)t0)[2];
t15=t2;
t16=t13;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_i_string_set(t14,t15,C_make_character(1)));}}}

/* char-set-xor in k949 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_3063r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3063r(t0,t1,t2);}}

static void C_ccall f_3063r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3073,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_car(t2);
/* srfi-14.scm:587: %char-set:s/check */
f_1040(t4,t5,lf[72]);}
else{
/* srfi-14.scm:590: char-set-copy */
t3=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[65]+1));}}

/* k3127 in char-set-xor in k949 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_string_length(t1);
/* srfi-14.scm:102: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[6]+1)))(5,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_fix(0),t2);}

/* k3071 in char-set-xor in k949 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3076,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3085,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:588: %char-set-algebra */
f_2631(t2,t1,t3,t4,lf[72]);}

/* a3084 in k3071 in char-set-xor in k949 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3085,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t2;
t7=t3;
t8=C_i_string_ref(t6,t7);
t9=C_fix(C_character_code(t8));
t10=C_fixnum_difference(C_fix(1),t9);
t11=t1;
t12=t2;
t13=t3;
t14=C_make_character(C_unfix(t10));
t15=t11;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_i_string_set(t12,t13,t14));}}

/* k3074 in k3071 in char-set-xor in k949 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:589: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-xor! in k949 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_3011r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3011r(t0,t1,t2,t3);}}

static void C_ccall f_3011r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3015,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3019,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:581: %char-set:s/check */
f_1040(t5,t2,lf[71]);}

/* k3017 in char-set-xor! in k949 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3021,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:581: %char-set-algebra */
f_2631(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[71]);}

/* a3020 in k3017 in char-set-xor! in k949 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3021,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t2;
t7=t3;
t8=C_i_string_ref(t6,t7);
t9=C_fix(C_character_code(t8));
t10=C_fixnum_difference(C_fix(1),t9);
t11=t1;
t12=t2;
t13=t3;
t14=C_make_character(C_unfix(t10));
t15=t11;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_i_string_set(t12,t13,t14));}}

/* k3013 in char-set-xor! in k949 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-difference in k949 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2965r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2965r(t0,t1,t2,t3);}}

static void C_ccall f_2965r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep(C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2975,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3006,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:572: %char-set:s/check */
f_1040(t5,t2,lf[70]);}
else{
/* srfi-14.scm:575: char-set-copy */
t4=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k3004 in char-set-difference in k949 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_string_length(t1);
/* srfi-14.scm:102: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[6]+1)))(5,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_fix(0),t2);}

/* k2973 in char-set-difference in k949 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2978,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:573: %char-set-algebra */
f_2631(t2,t1,((C_word*)t0)[2],t3,lf[70]);}

/* a2982 in k2973 in char-set-difference in k949 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2983,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_string_set(t2,t3,C_make_character(0)));}}

/* k2976 in k2973 in char-set-difference in k949 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:574: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-difference! in k949 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2934r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2934r(t0,t1,t2,t3);}}

static void C_ccall f_2934r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2938,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2942,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:566: %char-set:s/check */
f_1040(t5,t2,lf[69]);}

/* k2940 in char-set-difference! in k949 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2944,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:566: %char-set-algebra */
f_2631(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[69]);}

/* a2943 in k2940 in char-set-difference! in k949 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2944,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_string_set(t2,t3,C_make_character(0)));}}

/* k2936 in char-set-difference! in k949 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-intersection in k949 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2884r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2884r(t0,t1,t2);}}

static void C_ccall f_2884r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2894,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2925,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_car(t2);
/* srfi-14.scm:557: %char-set:s/check */
f_1040(t4,t5,lf[67]);}
else{
/* srfi-14.scm:560: char-set-copy */
t3=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[68]+1));}}

/* k2923 in char-set-intersection in k949 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_string_length(t1);
/* srfi-14.scm:102: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[6]+1)))(5,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_fix(0),t2);}

/* k2892 in char-set-intersection in k949 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2897,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2906,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:558: %char-set-algebra */
f_2631(t2,t1,t3,t4,lf[67]);}

/* a2905 in k2892 in char-set-intersection in k949 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2906,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_string_set(t2,t3,C_make_character(0)));}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2895 in k2892 in char-set-intersection in k949 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:559: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-intersection! in k949 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2857r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2857r(t0,t1,t2,t3);}}

static void C_ccall f_2857r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2861,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2865,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:551: %char-set:s/check */
f_1040(t5,t2,lf[66]);}

/* k2863 in char-set-intersection! in k949 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2867,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:551: %char-set-algebra */
f_2631(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[66]);}

/* a2866 in k2863 in char-set-intersection! in k949 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2867,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_string_set(t2,t3,C_make_character(0)));}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2859 in char-set-intersection! in k949 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-union in k949 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2803r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2803r(t0,t1,t2);}}

static void C_ccall f_2803r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2813,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2848,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_car(t2);
/* srfi-14.scm:542: %char-set:s/check */
f_1040(t4,t5,lf[64]);}
else{
/* srfi-14.scm:545: char-set-copy */
t3=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[65]+1));}}

/* k2846 in char-set-union in k949 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_string_length(t1);
/* srfi-14.scm:102: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[6]+1)))(5,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_fix(0),t2);}

/* k2811 in char-set-union in k949 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2816,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2825,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:543: %char-set-algebra */
f_2631(t2,t1,t3,t4,lf[64]);}

/* a2824 in k2811 in char-set-union in k949 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2825,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_string_set(t2,t3,C_make_character(1)));}}

/* k2814 in k2811 in char-set-union in k949 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:544: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-union! in k949 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2772r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2772r(t0,t1,t2,t3);}}

static void C_ccall f_2772r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2776,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2780,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:536: %char-set:s/check */
f_1040(t5,t2,lf[63]);}

/* k2778 in char-set-union! in k949 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2782,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:536: %char-set-algebra */
f_2631(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[63]);}

/* a2781 in k2778 in char-set-union! in k949 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2782,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_string_set(t2,t3,C_make_character(1)));}}

/* k2774 in char-set-union! in k949 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement! in k949 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2739,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2743,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:528: %char-set:s/check */
f_1040(t3,t2,lf[62]);}

/* k2741 in char-set-complement! in k949 */
static void C_ccall f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2748,a[2]=t1,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:529: %string-iter */
f_2590(t2,t3,t1);}

/* a2747 in k2741 in char-set-complement! in k949 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2748,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
t5=C_fixnum_difference(C_fix(1),t3);
t6=C_make_character(C_unfix(t5));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_string_set(t4,t2,t6));}

/* k2744 in k2741 in char-set-complement! in k949 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement in k949 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2700,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2704,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:522: %char-set:s/check */
f_1040(t3,t2,lf[61]);}

/* k2702 in char-set-complement in k949 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2707,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:523: make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,C_fix(256));}

/* k2705 in k2702 in char-set-complement in k949 */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2710,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2715,a[2]=t1,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:524: %string-iter */
f_2590(t2,t3,((C_word*)t0)[2]);}

/* a2714 in k2705 in k2702 in char-set-complement in k949 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2715,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
t5=C_fixnum_difference(C_fix(1),t3);
t6=C_make_character(C_unfix(t5));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_string_set(t4,t2,t6));}

/* k2708 in k2705 in k2702 in char-set-complement in k949 */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:525: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-algebra in k949 */
static void C_fcall f_2631(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2631,NULL,5,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2637,a[2]=t7,a[3]=t5,a[4]=t2,a[5]=t4,a[6]=((C_word)li82),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2637(t9,t1,t3);}

/* loop542 in %char-set-algebra in k949 */
static void C_fcall f_2637(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2637,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li81),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2687,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g549550 */
t6=t3;
f_2645(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2685 in loop542 in %char-set-algebra in k949 */
static void C_ccall f_2687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2637(t3,((C_word*)t0)[2],t2);}

/* g549 in loop542 in %char-set-algebra in k949 */
static void C_fcall f_2645(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2645,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2649,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:511: %char-set:s/check */
f_1040(t3,t2,((C_word*)t0)[2]);}

/* k2647 in g549 in loop542 in %char-set-algebra in k949 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2649,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2654,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,a[6]=((C_word)li80),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2654(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2647 in g549 in loop542 in %char-set-algebra in k949 */
static void C_fcall f_2654(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2654,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2664,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[4];
t6=t2;
t7=C_i_string_ref(t5,t6);
t8=C_fix(C_character_code(t7));
/* srfi-14.scm:514: op */
t9=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,((C_word*)t0)[2],t2,t8);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2662 in lp in k2647 in g549 in loop542 in %char-set-algebra in k949 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm:515: lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2654(t3,((C_word*)t0)[2],t2);}

/* %string-iter in k949 */
static void C_fcall f_2590(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2590,NULL,3,t1,t2,t3);}
t4=C_i_string_length(t3);
t5=C_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2600,a[2]=t2,a[3]=t3,a[4]=t7,a[5]=((C_word)li78),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2600(t9,t1,t5);}

/* lp in %string-iter in k949 */
static void C_fcall f_2600(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2600,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2610,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_i_string_ref(((C_word*)t0)[3],t2);
t6=C_fix(C_character_code(t5));
/* srfi-14.scm:500: p */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t2,t6);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2608 in lp in %string-iter in k949 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm:501: lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2600(t3,((C_word*)t0)[2],t2);}

/* ->char-set in k949 */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2560,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2567,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:477: char-set? */
t4=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2565 in ->char-set in k949 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
/* srfi-14.scm:478: string->char-set */
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
if(C_truep(C_charp(((C_word*)t0)[3]))){
/* srfi-14.scm:479: char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
/* srfi-14.scm:480: ##sys#error */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[57],lf[58],((C_word*)t0)[3]);}}}}

/* char-set-filter! in k949 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2546,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2550,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2554,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:468: %char-set:s/check */
f_1040(t6,t3,lf[56]);}

/* k2552 in char-set-filter! in k949 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2558,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:469: %char-set:s/check */
f_1040(t2,((C_word*)t0)[2],lf[56]);}

/* k2556 in k2552 in char-set-filter! in k949 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:467: %char-set-filter! */
f_2462(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2548 in char-set-filter! in k949 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-filter in k949 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2530r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2530r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2530r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2534,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:459: %default-base */
f_993(t5,t4,*((C_word*)lf[55]+1));}

/* k2532 in char-set-filter in k949 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2537,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2544,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:461: %char-set:s/check */
f_1040(t3,((C_word*)t0)[2],lf[56]);}

/* k2542 in k2532 in char-set-filter in k949 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:460: %char-set-filter! */
f_2462(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2535 in k2532 in char-set-filter in k949 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:464: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-filter! in k949 */
static void C_fcall f_2462(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2462,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2468,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t4,a[6]=((C_word)li73),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2468(t8,t1,C_fix(255));}

/* lp in %char-set-filter! in k949 */
static void C_fcall f_2468(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2468,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2488,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[3];
t6=t2;
t7=C_i_string_ref(t5,t6);
t8=C_fix(C_character_code(t7));
t9=C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t4;
f_2488(2,t10,C_SCHEME_FALSE);}
else{
t10=t2;
t11=C_make_character(C_unfix(t10));
/* srfi-14.scm:454: pred */
t12=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t12))(3,t12,t4,t11);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2486 in lp in %char-set-filter! in k949 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=C_i_string_set(t2,t3,C_make_character(1));
t5=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm:456: lp */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2468(t6,((C_word*)t0)[2],t5);}
else{
t2=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm:456: lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2468(t3,((C_word*)t0)[2],t2);}}

/* ucs-range->char-set! in k949 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2452,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2456,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2460,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm:443: %char-set:s/check */
f_1040(t7,t5,lf[53]);}

/* k2458 in ucs-range->char-set! in k949 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:442: %ucs-range->char-set! */
f_2360(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[52]);}

/* k2454 in ucs-range->char-set! in k949 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ucs-range->char-set in k949 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2422r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2422r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2422r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2432,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm:437: %default-base */
f_993(t9,t8,*((C_word*)lf[52]+1));}

/* k2430 in ucs-range->char-set in k949 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2435,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:438: %ucs-range->char-set! */
f_2360(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[52]);}

/* k2433 in k2430 in ucs-range->char-set in k949 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:439: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %ucs-range->char-set! in k949 */
static void C_fcall f_2360(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2360,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_i_check_exact_2(t2,t6);
t8=C_i_check_exact_2(t3,t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2370,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2408,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=t2;
t12=t3;
if(C_truep(C_fixnum_lessp(t11,t12))){
t13=t3;
t14=t10;
f_2408(t14,(C_truep(C_fixnum_lessp(C_fix(256),t13))?t4:C_SCHEME_FALSE));}
else{
t13=t10;
f_2408(t13,C_SCHEME_FALSE);}}

/* k2406 in %ucs-range->char-set! in k949 */
static void C_fcall f_2408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-14.scm:429: ##sys#error */
t2=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[51],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_2370(2,t2,C_SCHEME_UNDEFINED);}}

/* k2368 in %ucs-range->char-set! in k949 */
static void C_ccall f_2370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:432: min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t2,((C_word*)t0)[2],C_fix(256));}

/* k2403 in k2368 in %ucs-range->char-set! in k949 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2405,2,t0,t1);}
t2=C_fixnum_difference(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2379(t3,t2));}

/* lp in k2403 in k2368 in %ucs-range->char-set! in k949 */
static C_word C_fcall f_2379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
t2=((C_word*)t0)[3];
t3=t1;
if(C_truep(C_fixnum_less_or_equal_p(t2,t3))){
t4=((C_word*)t0)[2];
t5=t1;
t6=C_i_string_set(t4,t5,C_make_character(1));
t7=C_fixnum_difference(t1,C_fix(1));
t10=t7;
t1=t10;
goto loop;}
else{
t4=C_SCHEME_UNDEFINED;
return(t4);}}

/* char-set->string in k949 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2299,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2303,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:410: %char-set:s/check */
f_1040(t3,t2,lf[48]);}

/* k2301 in char-set->string in k949 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2358,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:411: char-set-size */
t4=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2356 in k2301 in char-set->string in k949 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:411: make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1);}

/* k2304 in k2301 in char-set->string in k949 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2311,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2311(t2,C_fix(255),C_fix(0)));}

/* lp in k2304 in k2301 in char-set->string in k949 */
static C_word C_fcall f_2311(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
loop:
C_stack_check;
t3=t1;
if(C_truep(C_fixnum_lessp(t3,C_fix(0)))){
t4=((C_word*)t0)[3];
return(t4);}
else{
t4=((C_word*)t0)[2];
t5=t1;
t6=C_i_string_ref(t4,t5);
t7=C_fix(C_character_code(t6));
t8=C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t2;
t10=C_fixnum_difference(t1,C_fix(1));
t18=t10;
t19=t9;
t1=t18;
t2=t19;
goto loop;}
else{
t9=t1;
t10=C_make_character(C_unfix(t9));
t11=C_i_string_set(((C_word*)t0)[3],t2,t10);
t12=C_fixnum_plus(t2,C_fix(1));
t13=C_fixnum_difference(t1,C_fix(1));
t18=t13;
t19=t12;
t1=t18;
t2=t19;
goto loop;}}}

/* string->char-set! in k949 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2289,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2293,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2297,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:404: %char-set:s/check */
f_1040(t5,t3,lf[47]);}

/* k2295 in string->char-set! in k949 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:404: %string->char-set! */
f_2228(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[47]);}

/* k2291 in string->char-set! in k949 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string->char-set in k949 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2277r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2277r(t0,t1,t2,t3);}}

static void C_ccall f_2277r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2281,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:399: %default-base */
f_993(t4,t3,*((C_word*)lf[46]+1));}

/* k2279 in string->char-set in k949 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2284,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:400: %string->char-set! */
f_2228(t2,((C_word*)t0)[2],t1,lf[46]);}

/* k2282 in k2279 in string->char-set in k949 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:401: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string->char-set! in k949 */
static void C_fcall f_2228(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2228,NULL,4,t1,t2,t3,t4);}
t5=C_i_check_string_2(t2,t4);
t6=C_i_string_length(t2);
t7=C_fixnum_difference(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2241,a[2]=t3,a[3]=t2,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,f_2241(t8,t7));}

/* doloop421 in %string->char-set! in k949 */
static C_word C_fcall f_2241(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
t2=t1;
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
t3=C_SCHEME_UNDEFINED;
return(t3);}
else{
t3=C_i_string_ref(((C_word*)t0)[3],t1);
t4=C_fix(C_character_code(t3));
t5=((C_word*)t0)[2];
t6=C_i_string_set(t5,t4,C_make_character(1));
t7=C_fixnum_difference(t1,C_fix(1));
t10=t7;
t1=t10;
goto loop;}}

/* char-set->list in k949 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2176,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2180,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:380: %char-set:s/check */
f_1040(t3,t2,lf[44]);}

/* k2178 in char-set->list in k949 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2185,a[2]=t3,a[3]=t1,a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2185(t5,((C_word*)t0)[2],C_fix(255),C_SCHEME_END_OF_LIST);}

/* lp in k2178 in char-set->list in k949 */
static void C_fcall f_2185(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2185,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_fixnum_difference(t2,C_fix(1));
t6=((C_word*)t0)[3];
t7=t2;
t8=C_i_string_ref(t6,t7);
t9=C_fix(C_character_code(t8));
t10=C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t3;
/* srfi-14.scm:383: lp */
t17=t1;
t18=t5;
t19=t11;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t11=t2;
t12=C_make_character(C_unfix(t11));
t13=C_a_i_cons(&a,2,t12,t3);
/* srfi-14.scm:383: lp */
t17=t1;
t18=t5;
t19=t13;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* list->char-set! in k949 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2166,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2170,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2174,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:375: %char-set:s/check */
f_1040(t5,t3,lf[43]);}

/* k2172 in list->char-set! in k949 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:375: %list->char-set! */
f_2099(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2168 in list->char-set! in k949 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* list->char-set in k949 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2154r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2154r(t0,t1,t2,t3);}}

static void C_ccall f_2154r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2158,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:370: %default-base */
f_993(t4,t3,*((C_word*)lf[42]+1));}

/* k2156 in list->char-set in k949 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2161,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:371: %list->char-set! */
f_2099(t2,((C_word*)t0)[2],t1);}

/* k2159 in k2156 in list->char-set in k949 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:372: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set in k949 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2142r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2142r(t0,t1,t2);}}

static void C_ccall f_2142r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2146,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:365: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t3,C_fix(256),C_make_character(0));}

/* k2144 in char-set in k949 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2149,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:366: %list->char-set! */
f_2099(t2,((C_word*)t0)[2],t1);}

/* k2147 in k2144 in char-set in k949 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:367: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %list->char-set! in k949 */
static void C_fcall f_2099(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2099,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2105,a[2]=t5,a[3]=t3,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2105(t7,t1,t2);}

/* loop382 in %list->char-set! in k949 */
static void C_fcall f_2105(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2105,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[3],a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_2113(t3,t4);
t6=C_slot(t2,C_fix(1));
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g389 in loop382 in %list->char-set! in k949 */
static C_word C_fcall f_2113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=C_fix(C_character_code(t1));
t3=((C_word*)t0)[2];
return(C_i_string_set(t3,t2,C_make_character(1)));}

/* char-set-unfold! in k949 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2089,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2093,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2097,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm:352: %char-set:s/check */
f_1040(t8,t6,lf[40]);}

/* k2095 in char-set-unfold! in k949 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:351: %char-set-unfold! */
f_2035(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2091 in char-set-unfold! in k949 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-unfold in k949 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_2077r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_2077r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_2077r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2081,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm:346: %default-base */
f_993(t7,t6,*((C_word*)lf[39]+1));}

/* k2079 in char-set-unfold in k949 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2084,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:347: %char-set-unfold! */
f_2035(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2082 in k2079 in char-set-unfold in k949 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:348: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-unfold! in k949 */
static void C_fcall f_2035(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2035,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2041,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t8,a[6]=t5,a[7]=((C_word)li51),tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_2041(t10,t1,t6);}

/* lp in %char-set-unfold! in k949 */
static void C_fcall f_2041(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2041,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2075,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-14.scm:341: p */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2073 in lp in %char-set-unfold! in k949 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2075,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm:342: f */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k2069 in k2073 in lp in %char-set-unfold! in k949 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2071,2,t0,t1);}
t2=C_fix(C_character_code(t1));
t3=((C_word*)t0)[6];
t4=C_i_string_set(t3,t2,C_make_character(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:343: g */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k2061 in k2069 in k2073 in lp in %char-set-unfold! in k949 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:343: lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2041(t2,((C_word*)t0)[2],t1);}

/* char-set-any in k949 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1972,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1976,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:329: %char-set:s/check */
f_1040(t4,t3,lf[37]);}

/* k1974 in char-set-any in k949 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1981,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=((C_word)li49),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1981(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1974 in char-set-any in k949 */
static void C_fcall f_1981(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1981,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[3];
t6=t2;
t7=C_i_string_ref(t5,t6);
t8=C_fix(C_character_code(t7));
t9=C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=C_fixnum_difference(t2,C_fix(1));
/* srfi-14.scm:333: lp */
t14=t1;
t15=t10;
t1=t14;
t2=t15;
goto loop;}
else{
t10=t2;
t11=C_make_character(C_unfix(t10));
/* srfi-14.scm:332: pred */
t12=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t12))(3,t12,t4,t11);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1989 in lp in k1974 in char-set-any in k949 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-14.scm:333: lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1981(t3,((C_word*)t0)[4],t2);}}

/* char-set-every in k949 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1918,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1922,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:321: %char-set:s/check */
f_1040(t4,t3,lf[36]);}

/* k1920 in char-set-every in k949 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li47),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1927(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1920 in char-set-every in k949 */
static void C_fcall f_1927(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1927,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_fixnum_lessp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)t0)[4];
t6=t2;
t7=C_i_string_ref(t5,t6);
t8=C_fix(C_character_code(t7));
t9=C_eqp(t8,C_fix(0));
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1956,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
if(C_truep(t9)){
t11=C_fixnum_difference(t2,C_fix(1));
/* srfi-14.scm:325: lp */
t15=t1;
t16=t11;
t1=t15;
t2=t16;
goto loop;}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t2;
t12=C_make_character(C_unfix(t11));
/* srfi-14.scm:324: pred */
t13=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t13))(3,t13,t10,t12);}}}

/* k1954 in lp in k1920 in char-set-every in k949 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm:325: lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1927(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-fold in k949 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1866,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1870,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:312: %char-set:s/check */
f_1040(t5,t4,lf[35]);}

/* k1868 in char-set-fold in k949 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1875,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word)li45),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1875(t5,((C_word*)t0)[3],C_fix(255),((C_word*)t0)[2]);}

/* lp in k1868 in char-set-fold in k949 */
static void C_fcall f_1875(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1875,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1893,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)t0)[3];
t8=t2;
t9=C_i_string_ref(t7,t8);
t10=C_fix(C_character_code(t9));
t11=C_eqp(t10,C_fix(0));
if(C_truep(t11)){
t12=t3;
/* srfi-14.scm:315: lp */
t17=t1;
t18=t5;
t19=t12;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t12=t2;
t13=C_make_character(C_unfix(t12));
/* srfi-14.scm:317: kons */
t14=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t14))(4,t14,t6,t13,t3);}}}

/* k1891 in lp in k1868 in char-set-fold in k949 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:315: lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1875(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-map in k949 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1787,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1791,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:301: %char-set:s/check */
f_1040(t4,t3,lf[34]);}

/* k1789 in char-set-map in k949 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1794,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:302: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t2,C_fix(256),C_make_character(0));}

/* k1792 in k1789 in char-set-map in k949 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1797,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1802,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word)li43),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1802(t6,t2,C_fix(255));}

/* lp in k1792 in k1789 in char-set-map in k949 */
static void C_fcall f_1802(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1802,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=((C_word*)t0)[5];
t5=t2;
t6=C_i_string_ref(t4,t5);
t7=C_fix(C_character_code(t6));
t8=C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=C_fixnum_difference(t2,C_fix(1));
/* srfi-14.scm:307: lp */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1860,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=t2;
t11=C_make_character(C_unfix(t10));
/* srfi-14.scm:306: proc */
t12=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t12))(3,t12,t9,t11);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1858 in lp in k1792 in k1789 in char-set-map in k949 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_fix(C_character_code(t1));
t3=((C_word*)t0)[5];
t4=C_i_string_set(t3,t2,C_make_character(1));
t5=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm:307: lp */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1802(t6,((C_word*)t0)[2],t5);}

/* k1795 in k1792 in k1789 in char-set-map in k949 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:308: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-for-each in k949 */
static void C_ccall f_1727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1727,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1731,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:293: %char-set:s/check */
f_1040(t4,t3,lf[33]);}

/* k1729 in char-set-for-each in k949 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1731,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1736,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=((C_word)li41),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1736(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1729 in char-set-for-each in k949 */
static void C_fcall f_1736(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1736,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1746,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[3];
t6=t2;
t7=C_i_string_ref(t5,t6);
t8=C_fix(C_character_code(t7));
t9=C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=C_fixnum_difference(t2,C_fix(1));
/* srfi-14.scm:297: lp */
t15=t1;
t16=t10;
t1=t15;
t2=t16;
goto loop;}
else{
t10=t2;
t11=C_make_character(C_unfix(t10));
/* srfi-14.scm:296: proc */
t12=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t12))(3,t12,t4,t11);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1744 in lp in k1729 in char-set-for-each in k949 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm:297: lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1736(t3,((C_word*)t0)[2],t2);}

/* %char-set-cursor-next in k949 */
static void C_fcall f_1675(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1675,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1679,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:282: %char-set:s/check */
f_1040(t5,t2,t4);}

/* k1677 in %char-set-cursor-next in k949 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1684,a[2]=t1,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1684(t2,((C_word*)t0)[2]));}

/* lp in k1677 in %char-set-cursor-next in k949 */
static C_word C_fcall f_1684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
t2=C_fixnum_difference(t1,C_fix(1));
t3=C_fixnum_lessp(t2,C_fix(0));
if(C_truep(t3)){
if(C_truep(t3)){
return(t2);}
else{
t9=t2;
t1=t9;
goto loop;}}
else{
t4=((C_word*)t0)[2];
t5=C_i_string_ref(t4,t2);
t6=C_fix(C_character_code(t5));
t7=C_eqp(t6,C_fix(0));
if(C_truep(t7)){
t9=t2;
t1=t9;
goto loop;}
else{
return(t2);}}}

/* char-set-cursor-next in k949 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1666,4,t0,t1,t2,t3);}
t4=C_i_check_exact_2(t3,lf[32]);
/* srfi-14.scm:279: %char-set-cursor-next */
f_1675(t1,t2,t3,lf[32]);}

/* char-set-ref in k949 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1660,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_make_character(C_unfix(t3)));}

/* end-of-char-set? in k949 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1654,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fixnum_lessp(t2,C_fix(0)));}

/* char-set-cursor in k949 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1648,3,t0,t1,t2);}
/* srfi-14.scm:269: %char-set-cursor-next */
f_1675(t1,t2,C_fix(256),lf[28]);}

/* char-set-delete! in k949 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1636r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1636r(t0,t1,t2,t3);}}

static void C_ccall f_1636r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1642,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:255: %set-char-set! */
f_1559(t1,t4,lf[27],t2,t3);}

/* a1641 in char-set-delete! in k949 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1642,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_string_set(t2,t3,C_make_character(0)));}

/* char-set-delete in k949 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1624r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1624r(t0,t1,t2,t3);}}

static void C_ccall f_1624r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1630,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:253: %set-char-set */
f_1511(t1,t4,lf[26],t2,t3);}

/* a1629 in char-set-delete in k949 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1630,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_string_set(t2,t3,C_make_character(0)));}

/* char-set-adjoin! in k949 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1612r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1612r(t0,t1,t2,t3);}}

static void C_ccall f_1612r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1618,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:251: %set-char-set! */
f_1559(t1,t4,lf[25],t2,t3);}

/* a1617 in char-set-adjoin! in k949 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1618,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_string_set(t2,t3,C_make_character(1)));}

/* char-set-adjoin in k949 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1600r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1600r(t0,t1,t2,t3);}}

static void C_ccall f_1600r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1606,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:249: %set-char-set */
f_1511(t1,t4,lf[24],t2,t3);}

/* a1605 in char-set-adjoin in k949 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1606,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_string_set(t2,t3,C_make_character(1)));}

/* %set-char-set! in k949 */
static void C_fcall f_1559(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1559,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1563,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm:243: %char-set:s/check */
f_1040(t6,t4,t3);}

/* k1561 in %set-char-set! in k949 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1566,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1568,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word)li25),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1568(t6,t2,((C_word*)t0)[2]);}

/* loop203 in k1561 in %set-char-set! in k949 */
static void C_fcall f_1568(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1568,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li24),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1587,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g210211 */
t6=t3;
f_1576(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1585 in loop203 in k1561 in %set-char-set! in k949 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1568(t3,((C_word*)t0)[2],t2);}

/* g210 in loop203 in k1561 in %set-char-set! in k949 */
static void C_fcall f_1576(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1576,NULL,3,t0,t1,t2);}
t3=C_fix(C_character_code(t2));
/* srfi-14.scm:244: set */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1564 in k1561 in %set-char-set! in k949 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* %set-char-set in k949 */
static void C_fcall f_1511(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1511,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1515,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1557,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:237: %char-set:s/check */
f_1040(t7,t4,t3);}

/* k1555 in %set-char-set in k949 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_string_length(t1);
/* srfi-14.scm:102: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[6]+1)))(5,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_fix(0),t2);}

/* k1513 in %set-char-set in k949 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1518,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1523,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word)li22),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1523(t6,t2,((C_word*)t0)[2]);}

/* loop183 in k1513 in %set-char-set in k949 */
static void C_fcall f_1523(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1523,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1531,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1542,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g190191 */
t6=t3;
f_1531(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1540 in loop183 in k1513 in %set-char-set in k949 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1523(t3,((C_word*)t0)[2],t2);}

/* g190 in loop183 in k1513 in %set-char-set in k949 */
static void C_fcall f_1531(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1531,NULL,3,t0,t1,t2);}
t3=C_fix(C_character_code(t2));
/* srfi-14.scm:238: set */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1516 in k1513 in %set-char-set in k949 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:240: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-count in k949 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1444,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1448,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:225: %char-set:s/check */
f_1040(t4,t3,lf[21]);}

/* k1446 in char-set-count in k949 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1448,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=((C_word)li19),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1453(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1446 in char-set-count in k949 */
static void C_fcall f_1453(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1453,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1474,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=((C_word*)t0)[3];
t8=t2;
t9=C_i_string_ref(t7,t8);
t10=C_fix(C_character_code(t9));
t11=C_eqp(t10,C_fix(0));
if(C_truep(t11)){
t12=t6;
f_1474(2,t12,C_SCHEME_FALSE);}
else{
t12=t2;
t13=C_make_character(C_unfix(t12));
/* srfi-14.scm:229: pred */
t14=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t14))(3,t14,t6,t13);}}}

/* k1472 in lp in k1446 in char-set-count in k949 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-14.scm:228: lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1453(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[5];
/* srfi-14.scm:228: lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1453(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* char-set-size in k949 */
static void C_ccall f_1402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1402,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1406,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:218: %char-set:s/check */
f_1040(t3,t2,lf[20]);}

/* k1404 in char-set-size in k949 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1411,a[2]=t1,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1411(t2,C_fix(255),C_fix(0)));}

/* lp in k1404 in char-set-size in k949 */
static C_word C_fcall f_1411(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
C_stack_check;
t3=t1;
if(C_truep(C_fixnum_lessp(t3,C_fix(0)))){
t4=t2;
return(t4);}
else{
t4=C_fixnum_difference(t1,C_fix(1));
t5=((C_word*)t0)[2];
t6=t1;
t7=C_i_string_ref(t5,t6);
t8=C_fix(C_character_code(t7));
t9=C_fixnum_plus(t2,t8);
t12=t4;
t13=t9;
t1=t12;
t2=t13;
goto loop;}}

/* char-set-contains? in k949 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1363,4,t0,t1,t2,t3);}
t4=C_i_check_char_2(t3,lf[19]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1396,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:213: %char-set:s/check */
f_1040(t5,t2,lf[19]);}

/* k1394 in char-set-contains? in k949 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[3];
t3=C_fix(C_character_code(t2));
t4=((C_word*)t0)[2];
t5=C_i_string_ref(t1,t3);
t6=C_fix(C_character_code(t5));
t7=C_eqp(t6,C_fix(0));
t8=t4;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_i_not(t7));}

/* char-set-hash in k949 */
static void C_ccall f_1250(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1250r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1250r(t0,t1,t2,t3);}}

static void C_ccall f_1250r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1254,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1254(2,t5,C_fix(4194304));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1254(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[18],t3);}}}

/* k1252 in char-set-hash in k949 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1254,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_eqp(((C_word*)t3)[1],C_fix(0));
if(C_truep(t5)){
t6=C_set_block_item(t3,0,C_fix(4194304));
t7=t4;
f_1257(t7,t6);}
else{
t6=t4;
f_1257(t6,C_SCHEME_UNDEFINED);}}

/* k1255 in k1252 in char-set-hash in k949 */
static void C_fcall f_1257(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1257,NULL,2,t0,t1);}
t2=C_i_check_exact_2(((C_word*)((C_word*)t0)[4])[1],lf[16]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:200: %char-set:s/check */
f_1040(t3,((C_word*)t0)[2],lf[16]);}

/* k1261 in k1255 in k1252 in char-set-hash in k949 */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[3],a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
t3=f_1321(t2,C_fix(65536));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1271,a[2]=t3,a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word)li14),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1271(t7,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1261 in k1255 in k1252 in char-set-hash in k949 */
static void C_fcall f_1271(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1271,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
/* srfi-14.scm:205: modulo */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t1,t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t5=C_fixnum_difference(t2,C_fix(1));
t6=((C_word*)t0)[4];
t7=t2;
t8=C_i_string_ref(t6,t7);
t9=C_fix(C_character_code(t8));
t10=C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t3;
/* srfi-14.scm:206: lp */
t16=t1;
t17=t5;
t18=t11;
t1=t16;
t2=t17;
t3=t18;
goto loop;}
else{
t11=C_fixnum_times(C_fix(37),t3);
t12=C_fixnum_plus(t11,t2);
t13=C_fixnum_and(((C_word*)t0)[2],t12);
/* srfi-14.scm:206: lp */
t16=t1;
t17=t5;
t18=t13;
t1=t16;
t2=t17;
t3=t18;
goto loop;}}}

/* lp in k1261 in k1255 in k1252 in char-set-hash in k949 */
static C_word C_fcall f_1321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(C_fixnum_greater_or_equal_p(t2,t3))){
return(C_fixnum_difference(t1,C_fix(1)));}
else{
t4=C_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* char-set<= in k949 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1142r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1142r(t0,t1,t2);}}

static void C_ccall f_1142r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_i_car(t2);
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1162,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:173: %char-set:s/check */
f_1040(t6,t4,lf[15]);}}

/* k1160 in char-set<= in k949 */
static void C_ccall f_1162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1162,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1164,a[2]=t3,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1164(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* lp in k1160 in char-set<= in k949 */
static void C_fcall f_1164(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1164,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t3);
t5=C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1174,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=C_i_car(t3);
/* srfi-14.scm:175: %char-set:s/check */
f_1040(t6,t7,lf[15]);}}

/* k1172 in lp in k1160 in char-set<= in k949 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1174,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
/* srfi-14.scm:177: lp */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1164(t4,((C_word*)t0)[2],t1,t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1191,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word)li10),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_1191(t7,((C_word*)t0)[2],C_fix(255));}}

/* lp2 in k1172 in lp in k1160 in char-set<= in k949 */
static void C_fcall f_1191(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1191,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep(C_fixnum_lessp(t3,C_fix(0)))){
/* srfi-14.scm:179: lp */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1164(t4,t1,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=((C_word*)t0)[3];
t5=t2;
t6=C_i_string_ref(t4,t5);
t7=C_fix(C_character_code(t6));
t8=((C_word*)t0)[5];
t9=t2;
t10=C_i_string_ref(t8,t9);
t11=C_fix(C_character_code(t10));
if(C_truep(C_fixnum_less_or_equal_p(t7,t11))){
t12=C_fixnum_difference(t2,C_fix(1));
/* srfi-14.scm:181: lp2 */
t14=t1;
t15=t12;
t1=t14;
t2=t15;
goto loop;}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}}

/* char-set= in k949 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1087r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1087r(t0,t1,t2);}}

static void C_ccall f_1087r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_i_car(t2);
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1103,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:162: %char-set:s/check */
f_1040(t6,t4,lf[14]);}}

/* k1101 in char-set= in k949 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1103,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1108,a[2]=t3,a[3]=t1,a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1108(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k1101 in char-set= in k949 */
static void C_fcall f_1108(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1108,NULL,3,t0,t1,t2);}
t3=C_i_pairp(t2);
t4=C_i_not(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1132,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=C_i_car(t2);
/* srfi-14.scm:165: %char-set:s/check */
f_1040(t5,t6,lf[14]);}}

/* k1130 in lp in k1101 in char-set= in k949 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_string_equal_p(((C_word*)t0)[5],t1))){
t2=C_i_cdr(((C_word*)t0)[4]);
/* srfi-14.scm:166: lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1108(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-copy in k949 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1073,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1081,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1085,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:155: %char-set:s/check */
f_1040(t4,t2,lf[13]);}

/* k1083 in char-set-copy in k949 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_string_length(t1);
/* srfi-14.scm:102: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[6]+1)))(5,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_fix(0),t2);}

/* k1079 in char-set-copy in k949 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:155: make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* %char-set:s/check in k949 */
static void C_fcall f_1040(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1040,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1046,a[2]=t3,a[3]=t5,a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1046(t7,t1,t2);}

/* lp in %char-set:s/check in k949 */
static void C_fcall f_1046(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1046,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm:126: char-set? */
t4=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1051 in lp in %char-set:s/check in k949 */
static void C_ccall f_1053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1053,2,t0,t1);}
if(C_truep(t1)){
/* srfi-14.scm:126: char-set:s */
t2=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1063,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm:127: ##sys#error */
t3=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[12],((C_word*)t0)[4]);}}

/* k1061 in k1051 in lp in %char-set:s/check in k949 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm:127: lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1046(t2,((C_word*)t0)[2],t1);}

/* %default-base in k949 */
static void C_fcall f_993(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_993,NULL,3,t1,t2,t3);}
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=C_i_cdr(t2);
if(C_truep(C_i_nullp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1018,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm:114: char-set? */
t7=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
/* srfi-14.scm:116: ##sys#error */
t6=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,lf[9],t3,t2);}}
else{
/* srfi-14.scm:118: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t1,C_fix(256),C_make_character(0));}}

/* k1016 in %default-base in k949 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1018,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm:114: char-set:s */
t3=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* srfi-14.scm:115: ##sys#error */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[8],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k1023 in k1016 in %default-base in k949 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_i_string_length(t1);
/* srfi-14.scm:102: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[6]+1)))(5,*((C_word*)lf[6]+1),t2,t1,C_fix(0),t3);}

/* char-set? in k949 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_977,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[2]));}

/* char-set:s in k949 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_971,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* make-char-set in k949 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_965,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,2,lf[2],t2));}

/* %latin1->char in k949 */
static void C_ccall f_953(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_953,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_make_character(C_unfix(t2)));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[261] = {
{"toplevel:srfi_14_scm",(void*)C_srfi_14_toplevel},
{"f_951:srfi_14_scm",(void*)f_951},
{"f_3333:srfi_14_scm",(void*)f_3333},
{"f_3337:srfi_14_scm",(void*)f_3337},
{"f_3341:srfi_14_scm",(void*)f_3341},
{"f_3344:srfi_14_scm",(void*)f_3344},
{"f_3347:srfi_14_scm",(void*)f_3347},
{"f_3350:srfi_14_scm",(void*)f_3350},
{"f_3354:srfi_14_scm",(void*)f_3354},
{"f_3585:srfi_14_scm",(void*)f_3585},
{"f_3357:srfi_14_scm",(void*)f_3357},
{"f_3362:srfi_14_scm",(void*)f_3362},
{"f_3365:srfi_14_scm",(void*)f_3365},
{"f_3369:srfi_14_scm",(void*)f_3369},
{"f_3373:srfi_14_scm",(void*)f_3373},
{"f_3377:srfi_14_scm",(void*)f_3377},
{"f_3381:srfi_14_scm",(void*)f_3381},
{"f_3540:srfi_14_scm",(void*)f_3540},
{"f_3384:srfi_14_scm",(void*)f_3384},
{"f_3387:srfi_14_scm",(void*)f_3387},
{"f_3391:srfi_14_scm",(void*)f_3391},
{"f_3505:srfi_14_scm",(void*)f_3505},
{"f_3394:srfi_14_scm",(void*)f_3394},
{"f_3397:srfi_14_scm",(void*)f_3397},
{"f_3401:srfi_14_scm",(void*)f_3401},
{"f_3470:srfi_14_scm",(void*)f_3470},
{"f_3468:srfi_14_scm",(void*)f_3468},
{"f_3405:srfi_14_scm",(void*)f_3405},
{"f_3409:srfi_14_scm",(void*)f_3409},
{"f_3431:srfi_14_scm",(void*)f_3431},
{"f_3429:srfi_14_scm",(void*)f_3429},
{"f_3413:srfi_14_scm",(void*)f_3413},
{"f_3425:srfi_14_scm",(void*)f_3425},
{"f_3417:srfi_14_scm",(void*)f_3417},
{"f_3421:srfi_14_scm",(void*)f_3421},
{"f_3304:srfi_14_scm",(void*)f_3304},
{"f_3329:srfi_14_scm",(void*)f_3329},
{"f_3308:srfi_14_scm",(void*)f_3308},
{"f_3311:srfi_14_scm",(void*)f_3311},
{"f_3314:srfi_14_scm",(void*)f_3314},
{"f_3321:srfi_14_scm",(void*)f_3321},
{"f_3325:srfi_14_scm",(void*)f_3325},
{"f_3233:srfi_14_scm",(void*)f_3233},
{"f_3237:srfi_14_scm",(void*)f_3237},
{"f_3240:srfi_14_scm",(void*)f_3240},
{"f_3251:srfi_14_scm",(void*)f_3251},
{"f_3243:srfi_14_scm",(void*)f_3243},
{"f_3246:srfi_14_scm",(void*)f_3246},
{"f_3138:srfi_14_scm",(void*)f_3138},
{"f_3144:srfi_14_scm",(void*)f_3144},
{"f_3220:srfi_14_scm",(void*)f_3220},
{"f_3152:srfi_14_scm",(void*)f_3152},
{"f_3217:srfi_14_scm",(void*)f_3217},
{"f_3158:srfi_14_scm",(void*)f_3158},
{"f_3063:srfi_14_scm",(void*)f_3063},
{"f_3129:srfi_14_scm",(void*)f_3129},
{"f_3073:srfi_14_scm",(void*)f_3073},
{"f_3085:srfi_14_scm",(void*)f_3085},
{"f_3076:srfi_14_scm",(void*)f_3076},
{"f_3011:srfi_14_scm",(void*)f_3011},
{"f_3019:srfi_14_scm",(void*)f_3019},
{"f_3021:srfi_14_scm",(void*)f_3021},
{"f_3015:srfi_14_scm",(void*)f_3015},
{"f_2965:srfi_14_scm",(void*)f_2965},
{"f_3006:srfi_14_scm",(void*)f_3006},
{"f_2975:srfi_14_scm",(void*)f_2975},
{"f_2983:srfi_14_scm",(void*)f_2983},
{"f_2978:srfi_14_scm",(void*)f_2978},
{"f_2934:srfi_14_scm",(void*)f_2934},
{"f_2942:srfi_14_scm",(void*)f_2942},
{"f_2944:srfi_14_scm",(void*)f_2944},
{"f_2938:srfi_14_scm",(void*)f_2938},
{"f_2884:srfi_14_scm",(void*)f_2884},
{"f_2925:srfi_14_scm",(void*)f_2925},
{"f_2894:srfi_14_scm",(void*)f_2894},
{"f_2906:srfi_14_scm",(void*)f_2906},
{"f_2897:srfi_14_scm",(void*)f_2897},
{"f_2857:srfi_14_scm",(void*)f_2857},
{"f_2865:srfi_14_scm",(void*)f_2865},
{"f_2867:srfi_14_scm",(void*)f_2867},
{"f_2861:srfi_14_scm",(void*)f_2861},
{"f_2803:srfi_14_scm",(void*)f_2803},
{"f_2848:srfi_14_scm",(void*)f_2848},
{"f_2813:srfi_14_scm",(void*)f_2813},
{"f_2825:srfi_14_scm",(void*)f_2825},
{"f_2816:srfi_14_scm",(void*)f_2816},
{"f_2772:srfi_14_scm",(void*)f_2772},
{"f_2780:srfi_14_scm",(void*)f_2780},
{"f_2782:srfi_14_scm",(void*)f_2782},
{"f_2776:srfi_14_scm",(void*)f_2776},
{"f_2739:srfi_14_scm",(void*)f_2739},
{"f_2743:srfi_14_scm",(void*)f_2743},
{"f_2748:srfi_14_scm",(void*)f_2748},
{"f_2746:srfi_14_scm",(void*)f_2746},
{"f_2700:srfi_14_scm",(void*)f_2700},
{"f_2704:srfi_14_scm",(void*)f_2704},
{"f_2707:srfi_14_scm",(void*)f_2707},
{"f_2715:srfi_14_scm",(void*)f_2715},
{"f_2710:srfi_14_scm",(void*)f_2710},
{"f_2631:srfi_14_scm",(void*)f_2631},
{"f_2637:srfi_14_scm",(void*)f_2637},
{"f_2687:srfi_14_scm",(void*)f_2687},
{"f_2645:srfi_14_scm",(void*)f_2645},
{"f_2649:srfi_14_scm",(void*)f_2649},
{"f_2654:srfi_14_scm",(void*)f_2654},
{"f_2664:srfi_14_scm",(void*)f_2664},
{"f_2590:srfi_14_scm",(void*)f_2590},
{"f_2600:srfi_14_scm",(void*)f_2600},
{"f_2610:srfi_14_scm",(void*)f_2610},
{"f_2560:srfi_14_scm",(void*)f_2560},
{"f_2567:srfi_14_scm",(void*)f_2567},
{"f_2546:srfi_14_scm",(void*)f_2546},
{"f_2554:srfi_14_scm",(void*)f_2554},
{"f_2558:srfi_14_scm",(void*)f_2558},
{"f_2550:srfi_14_scm",(void*)f_2550},
{"f_2530:srfi_14_scm",(void*)f_2530},
{"f_2534:srfi_14_scm",(void*)f_2534},
{"f_2544:srfi_14_scm",(void*)f_2544},
{"f_2537:srfi_14_scm",(void*)f_2537},
{"f_2462:srfi_14_scm",(void*)f_2462},
{"f_2468:srfi_14_scm",(void*)f_2468},
{"f_2488:srfi_14_scm",(void*)f_2488},
{"f_2452:srfi_14_scm",(void*)f_2452},
{"f_2460:srfi_14_scm",(void*)f_2460},
{"f_2456:srfi_14_scm",(void*)f_2456},
{"f_2422:srfi_14_scm",(void*)f_2422},
{"f_2432:srfi_14_scm",(void*)f_2432},
{"f_2435:srfi_14_scm",(void*)f_2435},
{"f_2360:srfi_14_scm",(void*)f_2360},
{"f_2408:srfi_14_scm",(void*)f_2408},
{"f_2370:srfi_14_scm",(void*)f_2370},
{"f_2405:srfi_14_scm",(void*)f_2405},
{"f_2379:srfi_14_scm",(void*)f_2379},
{"f_2299:srfi_14_scm",(void*)f_2299},
{"f_2303:srfi_14_scm",(void*)f_2303},
{"f_2358:srfi_14_scm",(void*)f_2358},
{"f_2306:srfi_14_scm",(void*)f_2306},
{"f_2311:srfi_14_scm",(void*)f_2311},
{"f_2289:srfi_14_scm",(void*)f_2289},
{"f_2297:srfi_14_scm",(void*)f_2297},
{"f_2293:srfi_14_scm",(void*)f_2293},
{"f_2277:srfi_14_scm",(void*)f_2277},
{"f_2281:srfi_14_scm",(void*)f_2281},
{"f_2284:srfi_14_scm",(void*)f_2284},
{"f_2228:srfi_14_scm",(void*)f_2228},
{"f_2241:srfi_14_scm",(void*)f_2241},
{"f_2176:srfi_14_scm",(void*)f_2176},
{"f_2180:srfi_14_scm",(void*)f_2180},
{"f_2185:srfi_14_scm",(void*)f_2185},
{"f_2166:srfi_14_scm",(void*)f_2166},
{"f_2174:srfi_14_scm",(void*)f_2174},
{"f_2170:srfi_14_scm",(void*)f_2170},
{"f_2154:srfi_14_scm",(void*)f_2154},
{"f_2158:srfi_14_scm",(void*)f_2158},
{"f_2161:srfi_14_scm",(void*)f_2161},
{"f_2142:srfi_14_scm",(void*)f_2142},
{"f_2146:srfi_14_scm",(void*)f_2146},
{"f_2149:srfi_14_scm",(void*)f_2149},
{"f_2099:srfi_14_scm",(void*)f_2099},
{"f_2105:srfi_14_scm",(void*)f_2105},
{"f_2113:srfi_14_scm",(void*)f_2113},
{"f_2089:srfi_14_scm",(void*)f_2089},
{"f_2097:srfi_14_scm",(void*)f_2097},
{"f_2093:srfi_14_scm",(void*)f_2093},
{"f_2077:srfi_14_scm",(void*)f_2077},
{"f_2081:srfi_14_scm",(void*)f_2081},
{"f_2084:srfi_14_scm",(void*)f_2084},
{"f_2035:srfi_14_scm",(void*)f_2035},
{"f_2041:srfi_14_scm",(void*)f_2041},
{"f_2075:srfi_14_scm",(void*)f_2075},
{"f_2071:srfi_14_scm",(void*)f_2071},
{"f_2063:srfi_14_scm",(void*)f_2063},
{"f_1972:srfi_14_scm",(void*)f_1972},
{"f_1976:srfi_14_scm",(void*)f_1976},
{"f_1981:srfi_14_scm",(void*)f_1981},
{"f_1991:srfi_14_scm",(void*)f_1991},
{"f_1918:srfi_14_scm",(void*)f_1918},
{"f_1922:srfi_14_scm",(void*)f_1922},
{"f_1927:srfi_14_scm",(void*)f_1927},
{"f_1956:srfi_14_scm",(void*)f_1956},
{"f_1866:srfi_14_scm",(void*)f_1866},
{"f_1870:srfi_14_scm",(void*)f_1870},
{"f_1875:srfi_14_scm",(void*)f_1875},
{"f_1893:srfi_14_scm",(void*)f_1893},
{"f_1787:srfi_14_scm",(void*)f_1787},
{"f_1791:srfi_14_scm",(void*)f_1791},
{"f_1794:srfi_14_scm",(void*)f_1794},
{"f_1802:srfi_14_scm",(void*)f_1802},
{"f_1860:srfi_14_scm",(void*)f_1860},
{"f_1797:srfi_14_scm",(void*)f_1797},
{"f_1727:srfi_14_scm",(void*)f_1727},
{"f_1731:srfi_14_scm",(void*)f_1731},
{"f_1736:srfi_14_scm",(void*)f_1736},
{"f_1746:srfi_14_scm",(void*)f_1746},
{"f_1675:srfi_14_scm",(void*)f_1675},
{"f_1679:srfi_14_scm",(void*)f_1679},
{"f_1684:srfi_14_scm",(void*)f_1684},
{"f_1666:srfi_14_scm",(void*)f_1666},
{"f_1660:srfi_14_scm",(void*)f_1660},
{"f_1654:srfi_14_scm",(void*)f_1654},
{"f_1648:srfi_14_scm",(void*)f_1648},
{"f_1636:srfi_14_scm",(void*)f_1636},
{"f_1642:srfi_14_scm",(void*)f_1642},
{"f_1624:srfi_14_scm",(void*)f_1624},
{"f_1630:srfi_14_scm",(void*)f_1630},
{"f_1612:srfi_14_scm",(void*)f_1612},
{"f_1618:srfi_14_scm",(void*)f_1618},
{"f_1600:srfi_14_scm",(void*)f_1600},
{"f_1606:srfi_14_scm",(void*)f_1606},
{"f_1559:srfi_14_scm",(void*)f_1559},
{"f_1563:srfi_14_scm",(void*)f_1563},
{"f_1568:srfi_14_scm",(void*)f_1568},
{"f_1587:srfi_14_scm",(void*)f_1587},
{"f_1576:srfi_14_scm",(void*)f_1576},
{"f_1566:srfi_14_scm",(void*)f_1566},
{"f_1511:srfi_14_scm",(void*)f_1511},
{"f_1557:srfi_14_scm",(void*)f_1557},
{"f_1515:srfi_14_scm",(void*)f_1515},
{"f_1523:srfi_14_scm",(void*)f_1523},
{"f_1542:srfi_14_scm",(void*)f_1542},
{"f_1531:srfi_14_scm",(void*)f_1531},
{"f_1518:srfi_14_scm",(void*)f_1518},
{"f_1444:srfi_14_scm",(void*)f_1444},
{"f_1448:srfi_14_scm",(void*)f_1448},
{"f_1453:srfi_14_scm",(void*)f_1453},
{"f_1474:srfi_14_scm",(void*)f_1474},
{"f_1402:srfi_14_scm",(void*)f_1402},
{"f_1406:srfi_14_scm",(void*)f_1406},
{"f_1411:srfi_14_scm",(void*)f_1411},
{"f_1363:srfi_14_scm",(void*)f_1363},
{"f_1396:srfi_14_scm",(void*)f_1396},
{"f_1250:srfi_14_scm",(void*)f_1250},
{"f_1254:srfi_14_scm",(void*)f_1254},
{"f_1257:srfi_14_scm",(void*)f_1257},
{"f_1263:srfi_14_scm",(void*)f_1263},
{"f_1271:srfi_14_scm",(void*)f_1271},
{"f_1321:srfi_14_scm",(void*)f_1321},
{"f_1142:srfi_14_scm",(void*)f_1142},
{"f_1162:srfi_14_scm",(void*)f_1162},
{"f_1164:srfi_14_scm",(void*)f_1164},
{"f_1174:srfi_14_scm",(void*)f_1174},
{"f_1191:srfi_14_scm",(void*)f_1191},
{"f_1087:srfi_14_scm",(void*)f_1087},
{"f_1103:srfi_14_scm",(void*)f_1103},
{"f_1108:srfi_14_scm",(void*)f_1108},
{"f_1132:srfi_14_scm",(void*)f_1132},
{"f_1073:srfi_14_scm",(void*)f_1073},
{"f_1085:srfi_14_scm",(void*)f_1085},
{"f_1081:srfi_14_scm",(void*)f_1081},
{"f_1040:srfi_14_scm",(void*)f_1040},
{"f_1046:srfi_14_scm",(void*)f_1046},
{"f_1053:srfi_14_scm",(void*)f_1053},
{"f_1063:srfi_14_scm",(void*)f_1063},
{"f_993:srfi_14_scm",(void*)f_993},
{"f_1018:srfi_14_scm",(void*)f_1018},
{"f_1025:srfi_14_scm",(void*)f_1025},
{"f_977:srfi_14_scm",(void*)f_977},
{"f_971:srfi_14_scm",(void*)f_971},
{"f_965:srfi_14_scm",(void*)f_965},
{"f_953:srfi_14_scm",(void*)f_953},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
