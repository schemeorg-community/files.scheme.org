/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: batch-driver.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[405];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1204)
static void C_ccall f_1204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_fcall f_4443(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_fcall f_4402(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_fcall f_1291(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4381)
static void C_ccall f_4381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4377)
static void C_ccall f_4377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_fcall f_1702(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1705)
static void C_fcall f_1705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_fcall f_4312(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4254)
static void C_fcall f_4254(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_fcall f_1723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_fcall f_1730(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_fcall f_1733(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_fcall f_1739(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_fcall f_1745(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1748)
static void C_fcall f_1748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_fcall f_1751(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1754)
static void C_fcall f_1754(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1757)
static void C_fcall f_1757(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1760)
static void C_fcall f_1760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1763)
static void C_fcall f_1763(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_fcall f_1766(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_fcall f_1769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_fcall f_1772(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_fcall f_1775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_fcall f_1778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_fcall f_1781(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_fcall f_1784(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_fcall f_1787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_fcall f_1793(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_fcall f_1799(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4119)
static void C_ccall f_4119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_fcall f_4011(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3956)
static void C_fcall f_3956(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_fcall f_1830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1833)
static void C_fcall f_1833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_fcall f_1836(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_fcall f_1839(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_fcall f_1842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_fcall f_3847(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_fcall f_3762(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3776)
static void C_ccall f_3776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3801)
static void C_ccall f_3801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_fcall f_3720(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_fcall f_3683(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_fcall f_3644(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_fcall f_3609(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3570)
static void C_fcall f_3570(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3599)
static void C_ccall f_3599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3510)
static void C_fcall f_3510(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3504)
static void C_ccall f_3504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_fcall f_1897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_fcall f_1931(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_fcall f_1961(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_fcall f_3218(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3340)
static void C_fcall f_3340(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3278)
static void C_fcall f_3278(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_fcall f_3243(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_fcall f_3173(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_fcall f_2043(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_fcall f_2052(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3104)
static void C_fcall f_3104(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_fcall f_3036(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_fcall f_2992(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_fcall f_2850(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_fcall f_2869(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_fcall f_2786(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_fcall f_2705(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_fcall f_2110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2605)
static void C_ccall f_2605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_fcall f_2113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_fcall f_2556(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_fcall f_2501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_fcall f_2509(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_fcall f_2463(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_fcall f_2471(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_fcall f_2151(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2373)
static void C_ccall f_2373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static void C_ccall f_2308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4798)
static void C_ccall f4798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_fcall f_1623(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1653)
static void C_fcall f_1653(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_fcall f_1648(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1625)
static void C_fcall f_1625(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_fcall f_1594(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1584)
static void C_fcall f_1584(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_fcall f_1549(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1555)
static void C_fcall f_1555(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1563)
static void C_fcall f_1563(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_fcall f_1469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1479)
static void C_ccall f_1479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1426)
static void C_fcall f_1426(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1438)
static void C_fcall f_1438(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_fcall f_1402(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1412)
static void C_ccall f_1412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1380)
static void C_fcall f_1380(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1400)
static void C_ccall f_1400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1356)
static void C_fcall f_1356(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1360)
static void C_ccall f_1360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1341)
static void C_fcall f_1341(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1351)
static void C_ccall f_1351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_fcall f_1233(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_4443)
static void C_fcall trf_4443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4443(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4443(t0,t1,t2);}

C_noret_decl(trf_4402)
static void C_fcall trf_4402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4402(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4402(t0,t1,t2);}

C_noret_decl(trf_1291)
static void C_fcall trf_1291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1291(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1291(t0,t1);}

C_noret_decl(trf_1702)
static void C_fcall trf_1702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1702(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1702(t0,t1);}

C_noret_decl(trf_1705)
static void C_fcall trf_1705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1705(t0,t1);}

C_noret_decl(trf_4312)
static void C_fcall trf_4312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4312(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4312(t0,t1,t2);}

C_noret_decl(trf_4254)
static void C_fcall trf_4254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4254(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4254(t0,t1,t2);}

C_noret_decl(trf_1723)
static void C_fcall trf_1723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1723(t0,t1);}

C_noret_decl(trf_1730)
static void C_fcall trf_1730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1730(t0,t1);}

C_noret_decl(trf_1733)
static void C_fcall trf_1733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1733(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1733(t0,t1);}

C_noret_decl(trf_1739)
static void C_fcall trf_1739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1739(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1739(t0,t1);}

C_noret_decl(trf_1745)
static void C_fcall trf_1745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1745(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1745(t0,t1);}

C_noret_decl(trf_1748)
static void C_fcall trf_1748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1748(t0,t1);}

C_noret_decl(trf_1751)
static void C_fcall trf_1751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1751(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1751(t0,t1);}

C_noret_decl(trf_1754)
static void C_fcall trf_1754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1754(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1754(t0,t1);}

C_noret_decl(trf_1757)
static void C_fcall trf_1757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1757(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1757(t0,t1);}

C_noret_decl(trf_1760)
static void C_fcall trf_1760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1760(t0,t1);}

C_noret_decl(trf_1763)
static void C_fcall trf_1763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1763(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1763(t0,t1);}

C_noret_decl(trf_1766)
static void C_fcall trf_1766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1766(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1766(t0,t1);}

C_noret_decl(trf_1769)
static void C_fcall trf_1769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1769(t0,t1);}

C_noret_decl(trf_1772)
static void C_fcall trf_1772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1772(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1772(t0,t1);}

C_noret_decl(trf_1775)
static void C_fcall trf_1775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1775(t0,t1);}

C_noret_decl(trf_1778)
static void C_fcall trf_1778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1778(t0,t1);}

C_noret_decl(trf_1781)
static void C_fcall trf_1781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1781(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1781(t0,t1);}

C_noret_decl(trf_1784)
static void C_fcall trf_1784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1784(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1784(t0,t1);}

C_noret_decl(trf_1787)
static void C_fcall trf_1787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1787(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1787(t0,t1);}

C_noret_decl(trf_1793)
static void C_fcall trf_1793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1793(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1793(t0,t1);}

C_noret_decl(trf_1799)
static void C_fcall trf_1799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1799(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1799(t0,t1);}

C_noret_decl(trf_4011)
static void C_fcall trf_4011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4011(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4011(t0,t1,t2);}

C_noret_decl(trf_3956)
static void C_fcall trf_3956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3956(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3956(t0,t1,t2);}

C_noret_decl(trf_1830)
static void C_fcall trf_1830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1830(t0,t1);}

C_noret_decl(trf_1833)
static void C_fcall trf_1833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1833(t0,t1);}

C_noret_decl(trf_1836)
static void C_fcall trf_1836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1836(t0,t1);}

C_noret_decl(trf_1839)
static void C_fcall trf_1839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1839(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1839(t0,t1);}

C_noret_decl(trf_1842)
static void C_fcall trf_1842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1842(t0,t1);}

C_noret_decl(trf_3847)
static void C_fcall trf_3847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3847(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3847(t0,t1,t2);}

C_noret_decl(trf_3762)
static void C_fcall trf_3762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3762(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3762(t0,t1,t2);}

C_noret_decl(trf_3720)
static void C_fcall trf_3720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3720(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3720(t0,t1,t2);}

C_noret_decl(trf_3683)
static void C_fcall trf_3683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3683(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3683(t0,t1,t2);}

C_noret_decl(trf_3644)
static void C_fcall trf_3644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3644(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3644(t0,t1,t2);}

C_noret_decl(trf_3609)
static void C_fcall trf_3609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3609(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3609(t0,t1,t2);}

C_noret_decl(trf_3570)
static void C_fcall trf_3570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3570(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3570(t0,t1,t2);}

C_noret_decl(trf_3510)
static void C_fcall trf_3510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3510(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3510(t0,t1,t2);}

C_noret_decl(trf_1897)
static void C_fcall trf_1897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1897(t0,t1);}

C_noret_decl(trf_1931)
static void C_fcall trf_1931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1931(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1931(t0,t1);}

C_noret_decl(trf_1961)
static void C_fcall trf_1961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1961(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1961(t0,t1);}

C_noret_decl(trf_3218)
static void C_fcall trf_3218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3218(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3218(t0,t1,t2);}

C_noret_decl(trf_3340)
static void C_fcall trf_3340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3340(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3340(t0,t1);}

C_noret_decl(trf_3278)
static void C_fcall trf_3278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3278(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3278(t0,t1,t2);}

C_noret_decl(trf_3243)
static void C_fcall trf_3243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3243(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3243(t0,t1,t2);}

C_noret_decl(trf_3173)
static void C_fcall trf_3173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3173(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3173(t0,t1,t2);}

C_noret_decl(trf_2043)
static void C_fcall trf_2043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2043(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2043(t0,t1);}

C_noret_decl(trf_2052)
static void C_fcall trf_2052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2052(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2052(t0,t1);}

C_noret_decl(trf_3104)
static void C_fcall trf_3104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3104(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3104(t0,t1,t2);}

C_noret_decl(trf_3036)
static void C_fcall trf_3036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3036(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3036(t0,t1,t2);}

C_noret_decl(trf_2992)
static void C_fcall trf_2992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2992(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2992(t0,t1,t2);}

C_noret_decl(trf_2850)
static void C_fcall trf_2850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2850(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2850(t0,t1);}

C_noret_decl(trf_2869)
static void C_fcall trf_2869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2869(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2869(t0,t1,t2);}

C_noret_decl(trf_2786)
static void C_fcall trf_2786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2786(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2786(t0,t1,t2);}

C_noret_decl(trf_2705)
static void C_fcall trf_2705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2705(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2705(t0,t1,t2);}

C_noret_decl(trf_2110)
static void C_fcall trf_2110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2110(t0,t1);}

C_noret_decl(trf_2113)
static void C_fcall trf_2113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2113(t0,t1);}

C_noret_decl(trf_2556)
static void C_fcall trf_2556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2556(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2556(t0,t1,t2);}

C_noret_decl(trf_2501)
static void C_fcall trf_2501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2501(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2501(t0,t1,t2);}

C_noret_decl(trf_2509)
static void C_fcall trf_2509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2509(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2509(t0,t1,t2);}

C_noret_decl(trf_2463)
static void C_fcall trf_2463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2463(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2463(t0,t1,t2);}

C_noret_decl(trf_2471)
static void C_fcall trf_2471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2471(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2471(t0,t1,t2);}

C_noret_decl(trf_2151)
static void C_fcall trf_2151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2151(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2151(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1623)
static void C_fcall trf_1623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1623(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1623(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1653)
static void C_fcall trf_1653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1653(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1653(t0,t1);}

C_noret_decl(trf_1648)
static void C_fcall trf_1648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1648(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1648(t0,t1,t2);}

C_noret_decl(trf_1625)
static void C_fcall trf_1625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1625(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1625(t0,t1,t2,t3);}

C_noret_decl(trf_1594)
static void C_fcall trf_1594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1594(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1594(t0,t1,t2);}

C_noret_decl(trf_1584)
static void C_fcall trf_1584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1584(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1584(t0,t1);}

C_noret_decl(trf_1549)
static void C_fcall trf_1549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1549(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1549(t0,t1,t2);}

C_noret_decl(trf_1555)
static void C_fcall trf_1555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1555(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1555(t0,t1,t2);}

C_noret_decl(trf_1563)
static void C_fcall trf_1563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1563(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1563(t0,t1,t2);}

C_noret_decl(trf_1469)
static void C_fcall trf_1469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1469(t0,t1);}

C_noret_decl(trf_1426)
static void C_fcall trf_1426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1426(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1426(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1438)
static void C_fcall trf_1438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1438(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1438(t0,t1,t2);}

C_noret_decl(trf_1402)
static void C_fcall trf_1402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1402(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1402(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1380)
static void C_fcall trf_1380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1380(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1380(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1356)
static void C_fcall trf_1356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1356(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1356(t0,t1,t2,t3);}

C_noret_decl(trf_1341)
static void C_fcall trf_1341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1341(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1341(t0,t1,t2,t3);}

C_noret_decl(trf_1233)
static void C_fcall trf_1233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1233(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1233(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3103)){
C_save(t1);
C_rereclaim2(3103*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,405);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],17,"user-options-pass");
lf[3]=C_h_intern(&lf[3],14,"user-read-pass");
lf[4]=C_h_intern(&lf[4],22,"user-preprocessor-pass");
lf[5]=C_h_intern(&lf[5],9,"user-pass");
lf[6]=C_h_intern(&lf[6],23,"user-post-analysis-pass");
lf[7]=C_h_intern(&lf[7],19,"compile-source-file");
lf[8]=C_h_intern(&lf[8],4,"quit");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[11]=C_h_intern(&lf[11],12,"explicit-use");
lf[12]=C_h_intern(&lf[12],26,"\010compilerexplicit-use-flag");
lf[13]=C_h_intern(&lf[13],12,"\004coredeclare");
lf[14]=C_h_intern(&lf[14],7,"verbose");
lf[15]=C_h_intern(&lf[15],11,"output-file");
lf[16]=C_h_intern(&lf[16],36,"\010compilerdefault-optimization-passes");
lf[17]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[18]=C_h_intern(&lf[18],7,"profile");
lf[19]=C_h_intern(&lf[19],12,"profile-name");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[21]=C_h_intern(&lf[21],9,"heap-size");
lf[22]=C_h_intern(&lf[22],17,"heap-initial-size");
lf[23]=C_h_intern(&lf[23],11,"heap-growth");
lf[24]=C_h_intern(&lf[24],14,"heap-shrinkage");
lf[25]=C_h_intern(&lf[25],13,"keyword-style");
lf[26]=C_h_intern(&lf[26],4,"unit");
lf[27]=C_h_intern(&lf[27],12,"analyze-only");
lf[28]=C_h_intern(&lf[28],7,"dynamic");
lf[29]=C_h_intern(&lf[29],8,"unboxing");
lf[30]=C_h_intern(&lf[30],7,"nursery");
lf[31]=C_h_intern(&lf[31],10,"stack-size");
lf[32]=C_h_intern(&lf[32],19,"\003sysstandard-output");
lf[33]=C_h_intern(&lf[33],16,"\003sysflush-output");
lf[34]=C_h_intern(&lf[34],19,"\003syswrite-char/port");
lf[35]=C_h_intern(&lf[35],7,"fprintf");
lf[36]=C_h_intern(&lf[36],26,"\010compilerdebugging-chicken");
lf[37]=C_h_intern(&lf[37],7,"display");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\010pass: ~a");
lf[39]=C_h_intern(&lf[39],19,"\010compilerdump-nodes");
lf[40]=C_h_intern(&lf[40],12,"pretty-print");
lf[41]=C_h_intern(&lf[41],30,"\010compilerbuild-expression-tree");
lf[42]=C_h_intern(&lf[42],34,"\010compilerdisplay-analysis-database");
lf[43]=C_h_intern(&lf[43],5,"write");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\013(iteration ");
lf[45]=C_h_intern(&lf[45],7,"newline");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[47]=C_h_intern(&lf[47],9,"substring");
lf[48]=C_h_intern(&lf[48],20,"current-milliseconds");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\003: \011");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\030milliseconds needed for ");
lf[51]=C_h_intern(&lf[51],12,"\010compilerget");
lf[52]=C_h_intern(&lf[52],13,"\010compilerput!");
lf[53]=C_h_intern(&lf[53],27,"\010compileranalyze-expression");
lf[54]=C_h_intern(&lf[54],9,"\003syserror");
lf[55]=C_h_intern(&lf[55],1,"D");
lf[56]=C_h_intern(&lf[56],25,"\010compilerimport-libraries");
lf[57]=C_h_intern(&lf[57],22,"no-module-registration");
lf[58]=C_h_intern(&lf[58],35,"\010compilerenable-module-registration");
lf[59]=C_h_intern(&lf[59],16,"emit-inline-file");
lf[60]=C_h_intern(&lf[60],12,"inline-limit");
lf[61]=C_h_intern(&lf[61],21,"\010compilerverbose-mode");
lf[62]=C_h_intern(&lf[62],31,"\003sysread-error-with-line-number");
lf[63]=C_h_intern(&lf[63],21,"\003sysinclude-pathnames");
lf[64]=C_h_intern(&lf[64],19,"\000compiler-extension");
lf[65]=C_h_intern(&lf[65],12,"\003sysfeatures");
lf[66]=C_h_intern(&lf[66],10,"\000compiling");
lf[67]=C_h_intern(&lf[67],28,"\003sysexplicit-library-modules");
lf[68]=C_h_intern(&lf[68],25,"\010compilertarget-heap-size");
lf[69]=C_h_intern(&lf[69],33,"\010compilertarget-initial-heap-size");
lf[70]=C_h_intern(&lf[70],27,"\010compilertarget-heap-growth");
lf[71]=C_h_intern(&lf[71],30,"\010compilertarget-heap-shrinkage");
lf[72]=C_h_intern(&lf[72],26,"\010compilertarget-stack-size");
lf[73]=C_h_intern(&lf[73],8,"no-trace");
lf[74]=C_h_intern(&lf[74],24,"\010compileremit-trace-info");
lf[75]=C_h_intern(&lf[75],29,"disable-stack-overflow-checks");
lf[76]=C_h_intern(&lf[76],40,"\010compilerdisable-stack-overflow-checking");
lf[77]=C_h_intern(&lf[77],7,"version");
lf[78]=C_h_intern(&lf[78],22,"\010compilerprint-version");
lf[79]=C_h_intern(&lf[79],4,"help");
lf[80]=C_h_intern(&lf[80],20,"\010compilerprint-usage");
lf[81]=C_h_intern(&lf[81],7,"release");
lf[82]=C_h_intern(&lf[82],15,"chicken-version");
lf[83]=C_h_intern(&lf[83],24,"\010compilersource-filename");
lf[84]=C_h_intern(&lf[84],24,"\003sysline-number-database");
lf[85]=C_h_intern(&lf[85],28,"\010compilerprofile-lambda-list");
lf[86]=C_h_intern(&lf[86],31,"\010compilerline-number-database-2");
lf[87]=C_h_intern(&lf[87],4,"node");
lf[88]=C_h_intern(&lf[88],6,"lambda");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[90]=C_h_intern(&lf[90],23,"\010compilerconstant-table");
lf[91]=C_h_intern(&lf[91],21,"\010compilerinline-table");
lf[92]=C_h_intern(&lf[92],23,"\010compilerfirst-analysis");
lf[93]=C_h_intern(&lf[93],41,"\010compilerperform-high-level-optimizations");
lf[94]=C_h_intern(&lf[94],37,"\010compilerinline-substitutions-enabled");
lf[95]=C_h_intern(&lf[95],22,"optimize-leaf-routines");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[97]=C_h_intern(&lf[97],34,"\010compilertransform-direct-lambdas!");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[99]=C_h_intern(&lf[99],4,"leaf");
lf[100]=C_h_intern(&lf[100],18,"\010compilerdebugging");
lf[101]=C_h_intern(&lf[101],1,"p");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[104]=C_h_intern(&lf[104],1,"5");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[107]=C_h_intern(&lf[107],36,"\010compilerprepare-for-code-generation");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\025compilation finished.");
lf[109]=C_h_intern(&lf[109],30,"\010compilercompiler-cleanup-hook");
lf[110]=C_h_intern(&lf[110],1,"t");
lf[111]=C_h_intern(&lf[111],17,"\003sysdisplay-times");
lf[112]=C_h_intern(&lf[112],14,"\003sysstop-timer");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[114]=C_h_intern(&lf[114],17,"close-output-port");
lf[115]=C_h_intern(&lf[115],22,"\010compilergenerate-code");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\023generating `~A\047 ...");
lf[117]=C_h_intern(&lf[117],16,"open-output-file");
lf[118]=C_h_intern(&lf[118],19,"current-output-port");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[120]=C_h_intern(&lf[120],4,"exit");
lf[121]=C_h_intern(&lf[121],6,"unsafe");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\010unboxing");
lf[123]=C_h_intern(&lf[123],1,"U");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\010unboxing");
lf[125]=C_h_intern(&lf[125],26,"\010compilerperform-unboxing!");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\023performing unboxing");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[128]=C_h_intern(&lf[128],1,"9");
lf[129]=C_h_intern(&lf[129],20,"\003syswarnings-enabled");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[132]=C_h_intern(&lf[132],1,"8");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[134]=C_h_intern(&lf[134],35,"\010compilerperform-closure-conversion");
lf[135]=C_h_intern(&lf[135],50,"\010compilercheck-for-unsafe-toplevel-procedure-calls");
lf[136]=C_h_intern(&lf[136],27,"\010compilerinline-output-file");
lf[137]=C_h_intern(&lf[137],28,"\010compilerinsert-timer-checks");
lf[138]=C_h_intern(&lf[138],32,"\010compileremit-global-inline-file");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000&Generating global inline file `~a\047 ...");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[141]=C_h_intern(&lf[141],1,"7");
lf[142]=C_h_intern(&lf[142],1,"s");
lf[143]=C_h_intern(&lf[143],33,"\010compilerprint-program-statistics");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[145]=C_h_intern(&lf[145],1,"4");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[147]=C_h_intern(&lf[147],1,"v");
lf[148]=C_h_intern(&lf[148],25,"\010compilerdump-global-refs");
lf[149]=C_h_intern(&lf[149],1,"d");
lf[150]=C_h_intern(&lf[150],29,"\010compilerdump-defined-globals");
lf[151]=C_h_intern(&lf[151],1,"u");
lf[152]=C_h_intern(&lf[152],31,"\010compilerdump-undefined-globals");
lf[153]=C_h_intern(&lf[153],3,"opt");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[155]=C_h_intern(&lf[155],1,"3");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[157]=C_h_intern(&lf[157],31,"\010compilerperform-cps-conversion");
lf[158]=C_h_intern(&lf[158],34,"\010compilerscan-toplevel-assignments");
lf[159]=C_h_intern(&lf[159],23,"\010compilerinline-locally");
lf[160]=C_h_intern(&lf[160],25,"\010compilerload-inline-file");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[162]=C_h_intern(&lf[162],19,"consult-inline-file");
lf[163]=C_h_intern(&lf[163],28,"\010compilerenable-inline-files");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[165]=C_h_intern(&lf[165],12,"file-exists\077");
lf[166]=C_h_intern(&lf[166],28,"\003sysresolve-include-filename");
lf[167]=C_h_intern(&lf[167],13,"make-pathname");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[169]=C_h_intern(&lf[169],14,"symbol->string");
lf[170]=C_h_intern(&lf[170],11,"concatenate");
lf[171]=C_h_intern(&lf[171],3,"cdr");
lf[172]=C_h_intern(&lf[172],2,"pp");
lf[173]=C_h_intern(&lf[173],1,"M");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[175]=C_h_intern(&lf[175],12,"vector->list");
lf[176]=C_h_intern(&lf[176],26,"\010compilerfile-requirements");
lf[177]=C_h_intern(&lf[177],26,"\010compilerdo-lambda-lifting");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[179]=C_h_intern(&lf[179],1,"L");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[181]=C_h_intern(&lf[181],32,"\010compilerperform-lambda-lifting!");
lf[182]=C_h_intern(&lf[182],22,"\010compilerdo-scrutinize");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\032pre-analysis (lambda-lift)");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[185]=C_h_intern(&lf[185],1,"0");
lf[186]=C_h_intern(&lf[186],4,"lift");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\010scrutiny");
lf[188]=C_h_intern(&lf[188],19,"\010compilerscrutinize");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\023performing scrutiny");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[192]=C_h_intern(&lf[192],8,"scrutiny");
lf[193]=C_h_intern(&lf[193],27,"\010compilerload-type-database");
lf[194]=C_h_intern(&lf[194],12,"\003sysfor-each");
lf[195]=C_h_intern(&lf[195],5,"types");
lf[196]=C_h_intern(&lf[196],17,"ignore-repository");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\010types.db");
lf[198]=C_h_intern(&lf[198],37,"\010compilerinitialize-analysis-database");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\021initial node tree");
lf[200]=C_h_intern(&lf[200],1,"T");
lf[201]=C_h_intern(&lf[201],25,"\010compilerbuild-node-graph");
lf[202]=C_h_intern(&lf[202],32,"\010compilercanonicalize-begin-body");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\014User pass...");
lf[205]=C_h_intern(&lf[205],12,"check-syntax");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[207]=C_h_intern(&lf[207],1,"2");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[209]=C_h_intern(&lf[209],18,"\010compilerunit-name");
lf[210]=C_h_intern(&lf[210],10,"\003sysnotice");
lf[211]=C_h_intern(&lf[211],17,"get-output-string");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\032\047 compiled in dynamic mode");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\016library unit `");
lf[214]=C_h_intern(&lf[214],18,"open-output-string");
lf[215]=C_h_intern(&lf[215],37,"\010compilerdisplay-line-number-database");
lf[216]=C_h_intern(&lf[216],1,"n");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[218]=C_h_intern(&lf[218],32,"\010compilerdisplay-real-name-table");
lf[219]=C_h_intern(&lf[219],1,"N");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\002\011\011");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[223]=C_h_intern(&lf[223],35,"\010compilercompiler-syntax-statistics");
lf[224]=C_h_intern(&lf[224],1,"S");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\030applied compiler syntax:");
lf[226]=C_h_intern(&lf[226],6,"append");
lf[227]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[228]=C_h_intern(&lf[228],5,"quote");
lf[229]=C_h_intern(&lf[229],33,"\010compilerprofile-info-vector-name");
lf[230]=C_h_intern(&lf[230],28,"\003sysset-profile-info-vector!");
lf[231]=C_h_intern(&lf[231],21,"\010compileremit-profile");
lf[232]=C_h_intern(&lf[232],25,"\003sysregister-profile-info");
lf[233]=C_h_intern(&lf[233],4,"set!");
lf[234]=C_h_intern(&lf[234],13,"\004corecallunit");
lf[235]=C_h_intern(&lf[235],19,"\010compilerused-units");
lf[236]=C_h_intern(&lf[236],28,"\010compilerimmutable-constants");
lf[237]=C_h_intern(&lf[237],6,"gensym");
lf[238]=C_h_intern(&lf[238],32,"\010compilercanonicalize-expression");
lf[239]=C_h_intern(&lf[239],4,"uses");
lf[240]=C_h_intern(&lf[240],7,"declare");
lf[241]=C_h_intern(&lf[241],10,"\003sysappend");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[243]=C_h_intern(&lf[243],1,"1");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\032User preprocessing pass...");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\021User read pass...");
lf[246]=C_h_intern(&lf[246],21,"\010compilerstring->expr");
lf[247]=C_h_intern(&lf[247],7,"reverse");
lf[248]=C_h_intern(&lf[248],27,"\003syscurrent-source-filename");
lf[249]=C_h_intern(&lf[249],33,"\010compilerclose-checked-input-file");
lf[250]=C_h_intern(&lf[250],25,"\010compilerread/source-info");
lf[251]=C_h_intern(&lf[251],16,"\003sysdynamic-wind");
lf[252]=C_h_intern(&lf[252],34,"\010compilercheck-and-open-input-file");
lf[253]=C_h_intern(&lf[253],8,"epilogue");
lf[254]=C_h_intern(&lf[254],8,"prologue");
lf[255]=C_h_intern(&lf[255],8,"postlude");
lf[256]=C_h_intern(&lf[256],7,"prelude");
lf[257]=C_h_intern(&lf[257],11,"make-vector");
lf[258]=C_h_intern(&lf[258],34,"\010compilerline-number-database-size");
lf[259]=C_h_intern(&lf[259],1,"r");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\022compiling `~a\047 ...");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\0001\012Run `csi\047 to start the interactive interpreter.\012");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000.or try `csc\047 for a more convenient interface.\012");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000C\012Enter `chicken -help\047 for information on how to use the compiler,\012");
lf[268]=C_h_intern(&lf[268],5,"-help");
lf[269]=C_h_intern(&lf[269],1,"h");
lf[270]=C_h_intern(&lf[270],2,"-h");
lf[271]=C_h_intern(&lf[271],33,"\010compilerload-identifier-database");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[273]=C_h_intern(&lf[273],18,"accumulate-profile");
lf[274]=C_h_intern(&lf[274],28,"\010compilerprofiled-procedures");
lf[275]=C_h_intern(&lf[275],3,"all");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\024Generating ~aprofile");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[279]=C_h_intern(&lf[279],39,"\010compilerdefault-profiling-declarations");
lf[280]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\022debugging info: ~A");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[284]=C_h_intern(&lf[284],21,"no-usual-integrations");
lf[285]=C_h_intern(&lf[285],17,"standard-bindings");
lf[286]=C_h_intern(&lf[286],34,"\010compilerdefault-standard-bindings");
lf[287]=C_h_intern(&lf[287],17,"extended-bindings");
lf[288]=C_h_intern(&lf[288],34,"\010compilerdefault-extended-bindings");
lf[289]=C_h_intern(&lf[289],1,"m");
lf[290]=C_h_intern(&lf[290],14,"set-gc-report!");
lf[291]=C_h_intern(&lf[291],42,"\010compilerdefault-default-target-stack-size");
lf[292]=C_h_intern(&lf[292],41,"\010compilerdefault-default-target-heap-size");
lf[293]=C_h_intern(&lf[293],14,"compile-syntax");
lf[294]=C_h_intern(&lf[294],25,"\003sysenable-runtime-macros");
lf[295]=C_h_intern(&lf[295],22,"\004corerequire-extension");
lf[296]=C_h_intern(&lf[296],14,"string->symbol");
lf[297]=C_h_intern(&lf[297],17,"require-extension");
lf[298]=C_h_intern(&lf[298],16,"static-extension");
lf[299]=C_h_intern(&lf[299],28,"\010compilerpostponed-initforms");
lf[300]=C_h_intern(&lf[300],6,"delete");
lf[301]=C_h_intern(&lf[301],3,"eq\077");
lf[302]=C_h_intern(&lf[302],4,"load");
lf[303]=C_h_intern(&lf[303],12,"load-verbose");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\036Loading compiler extensions...");
lf[305]=C_h_intern(&lf[305],6,"extend");
lf[306]=C_h_intern(&lf[306],19,"unregister-feature!");
lf[307]=C_h_intern(&lf[307],12,"string-split");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[309]=C_h_intern(&lf[309],10,"append-map");
lf[310]=C_h_intern(&lf[310],10,"no-feature");
lf[311]=C_h_intern(&lf[311],17,"register-feature!");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[313]=C_h_intern(&lf[313],7,"feature");
lf[314]=C_h_intern(&lf[314],38,"no-procedure-checks-for-usual-bindings");
lf[315]=C_h_intern(&lf[315],8,"\003sysput!");
lf[316]=C_h_intern(&lf[316],21,"\010compileralways-bound");
lf[317]=C_h_intern(&lf[317],34,"\010compileralways-bound-to-procedure");
lf[318]=C_h_intern(&lf[318],41,"no-procedure-checks-for-toplevel-bindings");
lf[319]=C_h_intern(&lf[319],35,"\010compilerno-global-procedure-checks");
lf[320]=C_h_intern(&lf[320],19,"no-procedure-checks");
lf[321]=C_h_intern(&lf[321],28,"\010compilerno-procedure-checks");
lf[322]=C_h_intern(&lf[322],15,"no-bound-checks");
lf[323]=C_h_intern(&lf[323],24,"\010compilerno-bound-checks");
lf[324]=C_h_intern(&lf[324],14,"no-argc-checks");
lf[325]=C_h_intern(&lf[325],23,"\010compilerno-argc-checks");
lf[326]=C_h_intern(&lf[326],20,"keep-shadowed-macros");
lf[327]=C_h_intern(&lf[327],33,"\010compilerundefine-shadowed-macros");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[329]=C_h_intern(&lf[329],23,"\010compilerchop-separator");
lf[330]=C_h_intern(&lf[330],12,"include-path");
lf[331]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[332]=C_h_intern(&lf[332],13,"symbol-escape");
lf[333]=C_h_intern(&lf[333],20,"parentheses-synonyms");
lf[334]=C_h_intern(&lf[334],5,"\000none");
lf[335]=C_h_intern(&lf[335],14,"case-sensitive");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000.Disabled the Chicken extensions to R5RS syntax");
lf[337]=C_h_intern(&lf[337],16,"no-symbol-escape");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000$Disabled support for escaped symbols");
lf[339]=C_h_intern(&lf[339],23,"no-parenthesis-synonyms");
lf[340]=C_h_intern(&lf[340],20,"parenthesis-synonyms");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000)Disabled support for parenthesis synonyms");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[343]=C_h_intern(&lf[343],7,"\000prefix");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[346]=C_h_intern(&lf[346],7,"\000suffix");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[348]=C_h_intern(&lf[348],16,"case-insensitive");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000,Identifiers and symbols are case insensitive");
lf[350]=C_h_intern(&lf[350],24,"\010compilerinline-max-size");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[352]=C_h_intern(&lf[352],26,"\010compilerlocal-definitions");
lf[353]=C_h_intern(&lf[353],6,"inline");
lf[354]=C_h_intern(&lf[354],30,"emit-external-prototypes-first");
lf[355]=C_h_intern(&lf[355],30,"\010compilerexternal-protos-first");
lf[356]=C_h_intern(&lf[356],5,"block");
lf[357]=C_h_intern(&lf[357],26,"\010compilerblock-compilation");
lf[358]=C_h_intern(&lf[358],17,"fixnum-arithmetic");
lf[359]=C_h_intern(&lf[359],11,"number-type");
lf[360]=C_h_intern(&lf[360],6,"fixnum");
lf[361]=C_h_intern(&lf[361],18,"disable-interrupts");
lf[362]=C_h_intern(&lf[362],10,"setup-mode");
lf[363]=C_h_intern(&lf[363],14,"\003syssetup-mode");
lf[364]=C_h_intern(&lf[364],11,"no-warnings");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\025Warnings are disabled");
lf[366]=C_h_intern(&lf[366],19,"\003sysnotices-enabled");
lf[367]=C_h_intern(&lf[367],13,"inline-global");
lf[368]=C_h_intern(&lf[368],5,"local");
lf[369]=C_h_intern(&lf[369],18,"no-compiler-syntax");
lf[370]=C_h_intern(&lf[370],32,"\010compilercompiler-syntax-enabled");
lf[371]=C_h_intern(&lf[371],14,"no-lambda-info");
lf[372]=C_h_intern(&lf[372],26,"\010compileremit-closure-info");
lf[373]=C_h_intern(&lf[373],3,"raw");
lf[374]=C_h_intern(&lf[374],12,"emit-exports");
lf[375]=C_h_intern(&lf[375],7,"warning");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[377]=C_h_intern(&lf[377],1,"b");
lf[378]=C_h_intern(&lf[378],15,"\003sysstart-timer");
lf[379]=C_h_intern(&lf[379],10,"scrutinize");
lf[380]=C_h_intern(&lf[380],11,"lambda-lift");
lf[381]=C_h_intern(&lf[381],25,"emit-all-import-libraries");
lf[382]=C_h_intern(&lf[382],29,"\010compilerall-import-libraries");
lf[383]=C_h_intern(&lf[383],13,"string-append");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[385]=C_h_intern(&lf[385],19,"emit-import-library");
lf[386]=C_h_intern(&lf[386],16,"\003sysstring->list");
lf[387]=C_h_intern(&lf[387],5,"debug");
lf[388]=C_h_intern(&lf[388],18,"\003sysdload-disabled");
lf[389]=C_h_intern(&lf[389],15,"repository-path");
lf[390]=C_h_intern(&lf[390],30,"\010compilerstandalone-executable");
lf[391]=C_h_intern(&lf[391],29,"\010compilerstring->c-identifier");
lf[392]=C_h_intern(&lf[392],18,"\010compilerstringify");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[395]=C_h_intern(&lf[395],24,"get-environment-variable");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[397]=C_h_intern(&lf[397],9,"to-stdout");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[399]=C_h_intern(&lf[399],13,"pathname-file");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[401]=C_h_intern(&lf[401],29,"\010compilerdefault-declarations");
lf[402]=C_h_intern(&lf[402],30,"\010compilerunits-used-by-default");
lf[403]=C_h_intern(&lf[403],28,"\010compilerinitialize-compiler");
lf[404]=C_h_intern(&lf[404],14,"make-parameter");
C_register_lf2(lf,405,create_ptable());
t2=C_mutate(&lf[0] /* (set! c247 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1204,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1202 */
static void C_ccall f_1204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1207,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1205 in k1202 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1212,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:37: make-parameter */
t3=*((C_word*)lf[404]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_FALSE);}

/* k1210 in k1205 in k1202 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:38: make-parameter */
t4=*((C_word*)lf[404]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_FALSE);}

/* k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1216,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:39: make-parameter */
t4=*((C_word*)lf[404]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_FALSE);}

/* k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1220,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:40: make-parameter */
t4=*((C_word*)lf[404]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_FALSE);}

/* k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1228,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:41: make-parameter */
t4=*((C_word*)lf[404]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_FALSE);}

/* k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1228,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate((C_word*)lf[7]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1230,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1230r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1230r(t0,t1,t2,t3);}}

static void C_ccall f_1230r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1233,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1266,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:54: initialize-compiler */
t6=*((C_word*)lf[403]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1266,2,t0,t1);}
t2=C_i_memq(lf[11],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[12]+1 /* (set! ##compiler#explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4487,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[12]+1))){
/* batch-driver.scm:57: append */
t6=*((C_word*)lf[226]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[401]+1),C_SCHEME_END_OF_LIST);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4502,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t7=*((C_word*)lf[241]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,*((C_word*)lf[402]+1),C_SCHEME_END_OF_LIST);}}

/* k4500 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4502,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[239],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* batch-driver.scm:57: append */
t4=*((C_word*)lf[226]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],*((C_word*)lf[401]+1),t3);}

/* k4485 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[241]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4483,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[13],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_i_memq(lf[14],((C_word*)t0)[5]);
t7=C_i_memq(lf[15],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* g5960 */
t10=t9;
f_4443(t10,t8,t7);}
else{
if(C_truep(C_i_memq(lf[397],((C_word*)t0)[5]))){
t9=t8;
f_1282(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4472,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm:70: pathname-file */
t10=*((C_word*)lf[399]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,((C_word*)t0)[2]);}
else{
/* batch-driver.scm:70: make-pathname */
t10=*((C_word*)lf[167]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t8,C_SCHEME_FALSE,lf[400],lf[398]);}}}}

/* k4470 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:70: make-pathname */
t2=*((C_word*)lf[167]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[398]);}

/* g59 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_4443(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4443,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4447,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:65: option-arg */
f_1233(t3,t2);}

/* k4445 in g59 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_symbolp(t1))){
/* batch-driver.scm:67: symbol->string */
t2=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1282,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1285,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4400,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4439,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:71: get-environment-variable */
t9=*((C_word*)lf[395]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[396]);}

/* k4437 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* batch-driver.scm:71: string-split */
t3=*((C_word*)lf[307]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[393]);}
else{
/* batch-driver.scm:71: string-split */
t2=*((C_word*)lf[307]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[394],lf[393]);}}

/* k4398 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4402,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4402(t5,((C_word*)t0)[2],t1);}

/* loop65 in k4398 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_4402(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4402,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[329]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4431,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g8182 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4429 in loop65 in k4398 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4431,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop6578 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4402(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop6578 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4402(t6,((C_word*)t0)[3],t5);}}

/* k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=*((C_word*)lf[16]+1);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[17];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_i_memq(lf[18],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1291,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1291(t13,t11);}
else{
t13=C_i_memq(lf[273],((C_word*)t0)[8]);
t14=t12;
f_1291(t14,(C_truep(t13)?t13:C_i_memq(lf[19],((C_word*)t0)[8])));}}

/* k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1291(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word ab[107],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1291,NULL,2,t0,t1);}
t2=C_i_memq(lf[19],((C_word*)t0)[13]);
t3=(C_truep(t2)?C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[20]);
t5=C_i_memq(lf[21],((C_word*)t0)[13]);
t6=C_i_memq(lf[22],((C_word*)t0)[13]);
t7=C_i_memq(lf[23],((C_word*)t0)[13]);
t8=C_i_memq(lf[24],((C_word*)t0)[13]);
t9=C_i_memq(lf[25],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_i_memq(lf[26],((C_word*)t0)[13]);
t13=C_i_memq(lf[27],((C_word*)t0)[13]);
t14=C_i_memq(lf[28],((C_word*)t0)[13]);
t15=C_i_memq(lf[29],((C_word*)t0)[13]);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_i_memq(lf[30],((C_word*)t0)[13]);
t23=(C_truep(t22)?t22:C_i_memq(lf[31],((C_word*)t0)[13]));
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_SCHEME_UNDEFINED;
t37=(*a=C_VECTOR_TYPE|1,a[1]=t36,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_SCHEME_UNDEFINED;
t41=(*a=C_VECTOR_TYPE|1,a[1]=t40,tmp=(C_word)a,a+=2,tmp);
t42=C_SCHEME_UNDEFINED;
t43=(*a=C_VECTOR_TYPE|1,a[1]=t42,tmp=(C_word)a,a+=2,tmp);
t44=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1341,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp));
t45=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1356,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t46=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1380,a[2]=t27,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t47=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1402,a[2]=t27,tmp=(C_word)a,a+=3,tmp));
t48=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1426,a[2]=t27,tmp=(C_word)a,a+=3,tmp));
t49=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1469,tmp=(C_word)a,a+=2,tmp));
t50=C_set_block_item(t37,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp));
t51=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1584,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp));
t52=C_set_block_item(t41,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp));
t53=C_set_block_item(t43,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1623,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t54=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1702,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t35,a[11]=t23,a[12]=t1,a[13]=((C_word*)t0)[3],a[14]=t4,a[15]=((C_word*)t0)[4],a[16]=t33,a[17]=t37,a[18]=t31,a[19]=t15,a[20]=t13,a[21]=t14,a[22]=((C_word*)t0)[5],a[23]=t25,a[24]=t29,a[25]=t43,a[26]=t39,a[27]=t41,a[28]=t19,a[29]=((C_word*)t0)[6],a[30]=((C_word*)t0)[7],a[31]=((C_word*)t0)[8],a[32]=t21,a[33]=t11,a[34]=((C_word*)t0)[12],a[35]=((C_word*)t0)[13],a[36]=t17,tmp=(C_word)a,a+=37,tmp);
if(C_truep(t12)){
t55=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4373,a[2]=t54,tmp=(C_word)a,a+=3,tmp);
t56=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4377,a[2]=t55,tmp=(C_word)a,a+=3,tmp);
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4381,a[2]=t56,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:159: option-arg */
f_1233(t57,t12);}
else{
t55=t54;
f_1702(t55,C_SCHEME_UNDEFINED);}}

/* k4379 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:159: stringify */
t2=*((C_word*)lf[392]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4375 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:159: string->c-identifier */
t2=*((C_word*)lf[391]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4371 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[209]+1 /* (set! ##compiler#unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1702(t3,t2);}

/* k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1702(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1702,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=*((C_word*)lf[209]+1);
if(C_truep(t3)){
if(C_truep(t3)){
t4=C_set_block_item(lf[390] /* standalone-executable */,0,C_SCHEME_FALSE);
t5=t2;
f_1705(t5,t4);}
else{
t4=t2;
f_1705(t4,C_SCHEME_UNDEFINED);}}
else{
if(C_truep(((C_word*)t0)[21])){
t4=C_set_block_item(lf[390] /* standalone-executable */,0,C_SCHEME_FALSE);
t5=t2;
f_1705(t5,t4);}
else{
t4=t2;
f_1705(t4,C_SCHEME_UNDEFINED);}}}

/* k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1705,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep(C_i_memq(lf[196],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[388] /* dload-disabled */,0,C_SCHEME_TRUE);
/* batch-driver.scm:164: repository-path */
t4=*((C_word*)lf[389]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,C_SCHEME_FALSE);}
else{
t3=t2;
f_1708(2,t3,C_SCHEME_UNDEFINED);}}

/* k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4302,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4358,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:170: collect-options */
t5=((C_word*)((C_word*)t0)[17])[1];
f_1549(t5,t4,lf[387]);}

/* k4356 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:166: append-map */
t2=*((C_word*)lf[309]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4301 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4302,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4310,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* string->list */
t8=*((C_word*)lf[386]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4308 in a4301 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4312,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4312(t5,((C_word*)t0)[2],t1);}

/* loop255 in k4308 in a4301 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_4312(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4312,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4350,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_string(&a,1,t4);
/* batch-driver.scm:168: string->symbol */
t6=*((C_word*)lf[296]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t3,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4348 in loop255 in k4308 in a4301 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4350,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop255268 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4312(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop255268 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4312(t6,((C_word*)t0)[3],t5);}}

/* k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1712,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1 /* (set! ##compiler#debugging-chicken ...) */,t1);
t3=C_i_memq(lf[55],*((C_word*)lf[36]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[36])+1,t3);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4252,a[2]=t9,a[3]=t6,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:176: collect-options */
t11=((C_word*)((C_word*)t0)[17])[1];
f_1549(t11,t10,lf[385]);}

/* k4250 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4252,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4254,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4254(t5,((C_word*)t0)[2],t1);}

/* loop279 in k4250 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_4254(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4254,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4289,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:174: string->symbol */
t5=*((C_word*)lf[296]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4287 in loop279 in k4250 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:175: string-append */
t3=*((C_word*)lf[383]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[384]);}

/* k4291 in k4287 in loop279 in k4250 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4293,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t4=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t6=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop279292 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_4254(t7,((C_word*)t0)[3],t6);}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t6=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop279292 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_4254(t7,((C_word*)t0)[3],t6);}}

/* k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1720,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1 /* (set! ##compiler#import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(C_i_memq(lf[381],((C_word*)t0)[35]))){
if(C_truep(((C_word*)t0)[20])){
t4=t3;
f_1723(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_set_block_item(lf[382] /* all-import-libraries */,0,C_SCHEME_TRUE);
t5=t3;
f_1723(t5,t4);}}
else{
t4=t3;
f_1723(t4,C_SCHEME_UNDEFINED);}}

/* k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1723,NULL,2,t0,t1);}
t2=C_i_memq(lf[57],((C_word*)t0)[35]);
t3=C_i_not(t2);
t4=C_mutate((C_word*)lf[58]+1 /* (set! ##compiler#enable-module-registration ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(C_i_memq(lf[380],((C_word*)t0)[35]))){
t6=C_set_block_item(lf[177] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t7=t5;
f_1730(t7,t6);}
else{
t6=t5;
f_1730(t6,C_SCHEME_UNDEFINED);}}

/* k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1730(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1730,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(C_i_memq(lf[379],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[182] /* do-scrutinize */,0,C_SCHEME_TRUE);
t4=t2;
f_1733(t4,t3);}
else{
t3=t2;
f_1733(t3,C_SCHEME_UNDEFINED);}}

/* k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1733(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1733,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(C_i_memq(lf[110],*((C_word*)lf[36]+1)))){
/* batch-driver.scm:183: ##sys#start-timer */
t3=*((C_word*)lf[378]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_1736(2,t3,C_SCHEME_UNDEFINED);}}

/* k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1739,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[377],*((C_word*)lf[36]+1)))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_1739(t4,t3);}
else{
t3=t2;
f_1739(t3,C_SCHEME_UNDEFINED);}}

/* k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1739(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1739,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[374],((C_word*)t0)[34]))){
/* batch-driver.scm:186: warning */
t3=*((C_word*)lf[375]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[376]);}
else{
t3=t2;
f_1742(2,t3,C_SCHEME_UNDEFINED);}}

/* k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[373],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[12] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[14],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[30],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_1745(t6,t5);}
else{
t3=t2;
f_1745(t3,C_SCHEME_UNDEFINED);}}

/* k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1745,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[371],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[372] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_1748(t4,t3);}
else{
t3=t2;
f_1748(t3,C_SCHEME_UNDEFINED);}}

/* k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1748,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[369],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[370] /* compiler-syntax-enabled */,0,C_SCHEME_FALSE);
t4=t2;
f_1751(t4,t3);}
else{
t3=t2;
f_1751(t3,C_SCHEME_UNDEFINED);}}

/* k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1751(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1751,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[368],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[352] /* local-definitions */,0,C_SCHEME_TRUE);
t4=t2;
f_1754(t4,t3);}
else{
t3=t2;
f_1754(t3,C_SCHEME_UNDEFINED);}}

/* k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1754(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1754,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[367],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[163] /* enable-inline-files */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[159] /* inline-locally */,0,C_SCHEME_TRUE);
t5=t2;
f_1757(t5,t4);}
else{
t3=t2;
f_1757(t3,C_SCHEME_UNDEFINED);}}

/* k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1757(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1757,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[33])){
if(C_truep(((C_word*)t0)[33])){
t3=C_set_block_item(lf[366] /* notices-enabled */,0,C_SCHEME_TRUE);
t4=t2;
f_1760(t4,t3);}
else{
t3=t2;
f_1760(t3,C_SCHEME_UNDEFINED);}}
else{
t3=*((C_word*)lf[182]+1);
if(C_truep(t3)){
t4=C_set_block_item(lf[366] /* notices-enabled */,0,C_SCHEME_TRUE);
t5=t2;
f_1760(t5,t4);}
else{
t4=t2;
f_1760(t4,C_SCHEME_UNDEFINED);}}}

/* k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1760,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[364],((C_word*)t0)[34]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4182,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:203: dribble */
t4=((C_word*)((C_word*)t0)[22])[1];
f_1341(t4,t3,lf[365],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1763(t3,C_SCHEME_UNDEFINED);}}

/* k4180 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[129] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_1763(t3,t2);}

/* k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1763(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1763,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[95],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[95] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_1766(t4,t3);}
else{
t3=t2;
f_1766(t3,C_SCHEME_UNDEFINED);}}

/* k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1766(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1766,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[121],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[121] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_1769(t4,t3);}
else{
t3=t2;
f_1769(t3,C_SCHEME_UNDEFINED);}}

/* k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1769,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[362],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[363] /* setup-mode */,0,C_SCHEME_TRUE);
t4=t2;
f_1772(t4,t3);}
else{
t3=t2;
f_1772(t3,C_SCHEME_UNDEFINED);}}

/* k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1772(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1772,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[361],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[137] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_1775(t4,t3);}
else{
t3=t2;
f_1775(t3,C_SCHEME_UNDEFINED);}}

/* k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1775,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[358],((C_word*)t0)[34]))){
t3=C_mutate((C_word*)lf[359]+1 /* (set! number-type ...) */,lf[360]);
t4=t2;
f_1778(t4,t3);}
else{
t3=t2;
f_1778(t3,C_SCHEME_UNDEFINED);}}

/* k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1778,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[356],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[357] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_1781(t4,t3);}
else{
t3=t2;
f_1781(t3,C_SCHEME_UNDEFINED);}}

/* k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1781(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1781,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[354],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[355] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_1784(t4,t3);}
else{
t3=t2;
f_1784(t3,C_SCHEME_UNDEFINED);}}

/* k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1784(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1784,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[353],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[159] /* inline-locally */,0,C_SCHEME_TRUE);
t4=t2;
f_1787(t4,t3);}
else{
t3=t2;
f_1787(t3,C_SCHEME_UNDEFINED);}}

/* k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1787(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1787,NULL,2,t0,t1);}
t2=C_i_memq(lf[59],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=C_set_block_item(lf[159] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[352] /* local-definitions */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4144,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:219: option-arg */
f_1233(t6,t2);}
else{
t4=t3;
f_1793(t4,C_SCHEME_FALSE);}}

/* k4142 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[136]+1 /* (set! ##compiler#inline-output-file ...) */,t1);
t3=((C_word*)t0)[2];
f_1793(t3,t2);}

/* k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1793(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1793,NULL,2,t0,t1);}
t2=C_i_memq(lf[60],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[34],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4129,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:222: option-arg */
f_1233(t4,t2);}
else{
t4=t3;
f_1799(t4,C_SCHEME_FALSE);}}

/* k4127 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4132,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:223: string->number */
C_string_to_number(3,0,t2,t1);}

/* k4130 in k4127 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t1;
t4=C_mutate((C_word*)lf[350]+1 /* (set! ##compiler#inline-max-size ...) */,t3);
t5=((C_word*)t0)[3];
f_1799(t5,t4);}
else{
/* batch-driver.scm:224: quit */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[351],((C_word*)t0)[2]);}}

/* k4133 in k4130 in k4127 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[350]+1 /* (set! ##compiler#inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_1799(t3,t2);}

/* k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1799(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1799,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[348],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4119,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:226: dribble */
t4=((C_word*)((C_word*)t0)[22])[1];
f_1341(t4,t3,lf[349],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1802(2,t3,C_SCHEME_UNDEFINED);}}

/* k4117 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:227: register-feature! */
t3=*((C_word*)lf[311]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[348]);}

/* k4120 in k4117 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:228: case-sensitive */
t2=*((C_word*)lf[335]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4083,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:230: option-arg */
f_1233(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_1805(2,t3,C_SCHEME_UNDEFINED);}}

/* k4081 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_string_equal_p(lf[342],t1))){
/* batch-driver.scm:231: keyword-style */
t2=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[343]);}
else{
if(C_truep(C_i_string_equal_p(lf[344],t1))){
/* batch-driver.scm:232: keyword-style */
t2=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[334]);}
else{
if(C_truep(C_i_string_equal_p(lf[345],t1))){
/* batch-driver.scm:233: keyword-style */
t2=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[346]);}
else{
/* batch-driver.scm:234: quit */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[347]);}}}}

/* k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep(C_i_memq(lf[339],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4077,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:236: dribble */
t4=((C_word*)((C_word*)t0)[21])[1];
f_1341(t4,t3,lf[341],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1808(2,t3,C_SCHEME_UNDEFINED);}}

/* k4075 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:237: parenthesis-synonyms */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep(C_i_memq(lf[337],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4068,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:239: dribble */
t4=((C_word*)((C_word*)t0)[21])[1];
f_1341(t4,t3,lf[338],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1811(2,t3,C_SCHEME_UNDEFINED);}}

/* k4066 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:240: symbol-escape */
t2=*((C_word*)lf[332]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep(C_i_memq(lf[331],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4050,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:242: dribble */
t4=((C_word*)((C_word*)t0)[21])[1];
f_1341(t4,t3,lf[336],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1814(2,t3,C_SCHEME_UNDEFINED);}}

/* k4048 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:243: case-sensitive */
t3=*((C_word*)lf[335]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_FALSE);}

/* k4051 in k4048 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4056,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:244: keyword-style */
t3=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[334]);}

/* k4054 in k4051 in k4048 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4059,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:245: parentheses-synonyms */
t3=*((C_word*)lf[333]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_FALSE);}

/* k4057 in k4054 in k4051 in k4048 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:246: symbol-escape */
t2=*((C_word*)lf[332]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! ##compiler#verbose-mode ...) */,((C_word*)t0)[33]);
t3=C_set_block_item(lf[62] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[33],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4005,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4009,a[2]=t9,a[3]=t6,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:250: collect-options */
t11=((C_word*)((C_word*)t0)[15])[1];
f_1549(t11,t10,lf[330]);}

/* k4007 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4011,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4011(t5,((C_word*)t0)[2],t1);}

/* loop331 in k4007 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_4011(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4011,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[329]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4040,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g347348 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4038 in loop331 in k4007 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4040,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop331344 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4011(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop331344 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4011(t6,((C_word*)t0)[3],t5);}}

/* k4003 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:250: append */
t2=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,*((C_word*)lf[63]+1),((C_word*)t0)[2]);}

/* k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! ##sys#include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[20])){
if(C_truep(((C_word*)t0)[27])){
if(C_truep(C_i_string_equal_p(((C_word*)t0)[20],((C_word*)t0)[27]))){
/* batch-driver.scm:254: quit */
t4=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[328]);}
else{
t4=t3;
f_1823(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1823(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1823(2,t4,C_SCHEME_UNDEFINED);}}

/* k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1823,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3954,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:255: collect-options */
t8=((C_word*)((C_word*)t0)[15])[1];
f_1549(t8,t7,lf[239]);}

/* k3952 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3954,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3956,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3956(t5,((C_word*)t0)[2],t1);}

/* loop356 in k3952 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3956(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3956,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[296]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g372373 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3983 in loop356 in k3952 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3985,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop356369 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3956(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop356369 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3956(t6,((C_word*)t0)[3],t5);}}

/* k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1827,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[32],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[326],((C_word*)t0)[29]))){
t4=C_set_block_item(lf[327] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_1830(t5,t4);}
else{
t4=t3;
f_1830(t4,C_SCHEME_UNDEFINED);}}

/* k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1830,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1833,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[324],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[325] /* no-argc-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1833(t4,t3);}
else{
t3=t2;
f_1833(t3,C_SCHEME_UNDEFINED);}}

/* k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1833,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[322],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[323] /* no-bound-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1836(t4,t3);}
else{
t3=t2;
f_1836(t3,C_SCHEME_UNDEFINED);}}

/* k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1836,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[320],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[321] /* no-procedure-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1839(t4,t3);}
else{
t3=t2;
f_1839(t3,C_SCHEME_UNDEFINED);}}

/* k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1839,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[318],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[319] /* no-global-procedure-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1842(t4,t3);}
else{
t3=t2;
f_1842(t3,C_SCHEME_UNDEFINED);}}

/* k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1842,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[314],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3847,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3847(t7,t3,*((C_word*)lf[286]+1));}
else{
t3=t2;
f_1845(2,t3,C_SCHEME_UNDEFINED);}}

/* loop379 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3847(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3847,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3919,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3886,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3861,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t6))){
/* tweaks.scm:50: ##sys#put! */
t8=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,t4,lf[317],C_SCHEME_TRUE);}
else{
t8=C_i_cdr(t6);
if(C_truep(C_i_nullp(t8))){
t9=C_i_car(t6);
/* tweaks.scm:50: ##sys#put! */
t10=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t5,t4,lf[317],t9);}
else{
/* ##sys#error */
t9=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[0],t6);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3859 in loop379 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[317],t1);}

/* k3884 in loop379 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:50: ##sys#put! */
t4=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[316],C_SCHEME_TRUE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_i_car(t2);
/* tweaks.scm:50: ##sys#put! */
t6=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[3],((C_word*)t0)[2],lf[316],t5);}
else{
/* ##sys#error */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3889 in k3884 in loop379 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[316],t1);}

/* k3917 in loop379 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3847(t3,((C_word*)t0)[2],t2);}

/* k3755 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3757,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3762,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3762(t5,((C_word*)t0)[2],*((C_word*)lf[288]+1));}

/* loop422 in k3755 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3762(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3762,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3834,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3801,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3776,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t6))){
/* tweaks.scm:50: ##sys#put! */
t8=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,t4,lf[317],C_SCHEME_TRUE);}
else{
t8=C_i_cdr(t6);
if(C_truep(C_i_nullp(t8))){
t9=C_i_car(t6);
/* tweaks.scm:50: ##sys#put! */
t10=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t5,t4,lf[317],t9);}
else{
/* ##sys#error */
t9=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[0],t6);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3774 in loop422 in k3755 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[317],t1);}

/* k3799 in loop422 in k3755 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3801,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:50: ##sys#put! */
t4=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[316],C_SCHEME_TRUE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_i_car(t2);
/* tweaks.scm:50: ##sys#put! */
t6=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[3],((C_word*)t0)[2],lf[316],t5);}
else{
/* ##sys#error */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3804 in k3799 in loop422 in k3755 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[316],t1);}

/* k3832 in loop422 in k3755 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3762(t3,((C_word*)t0)[2],t2);}

/* k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3718,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3743,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3751,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:281: collect-options */
t6=((C_word*)((C_word*)t0)[16])[1];
f_1549(t6,t5,lf[313]);}

/* k3749 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:281: append-map */
t2=*((C_word*)lf[309]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3742 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3743,3,t0,t1,t2);}
t3=*((C_word*)lf[307]+1);
/* g482483 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,lf[312]);}

/* k3716 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3718,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3720,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3720(t5,((C_word*)t0)[2],t1);}

/* loop466 in k3716 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3720(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3720,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[311]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3730,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g473474 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3728 in loop466 in k3716 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3720(t3,((C_word*)t0)[2],t2);}

/* k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3681,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3706,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3714,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:284: collect-options */
t6=((C_word*)((C_word*)t0)[16])[1];
f_1549(t6,t5,lf[310]);}

/* k3712 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:284: append-map */
t2=*((C_word*)lf[309]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3705 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3706,3,t0,t1,t2);}
t3=*((C_word*)lf[307]+1);
/* g502503 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,lf[308]);}

/* k3679 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3681,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3683,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3683(t5,((C_word*)t0)[2],t1);}

/* loop486 in k3679 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3683(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3683,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[306]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3693,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g493494 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3691 in loop486 in k3679 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3683(t3,((C_word*)t0)[2],t2);}

/* k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[64],*((C_word*)lf[65]+1));
t3=C_mutate((C_word*)lf[65]+1 /* (set! ##sys#features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm:288: collect-options */
t5=((C_word*)((C_word*)t0)[16])[1];
f_1549(t5,t4,lf[305]);}

/* k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm:289: dribble */
t3=((C_word*)((C_word*)t0)[22])[1];
f_1341(t3,t2,lf[304],C_SCHEME_END_OF_LIST);}

/* k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm:290: load-verbose */
t3=*((C_word*)lf[303]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_TRUE);}
else{
t3=t2;
f_1864(2,t3,C_SCHEME_UNDEFINED);}}

/* k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3644,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3644(t6,t2,((C_word*)t0)[2]);}

/* loop507 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3644(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3644,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3663,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3660,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:292: ##sys#resolve-include-filename */
t6=*((C_word*)lf[166]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,t4,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3658 in loop507 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:292: load */
t2=*((C_word*)lf[302]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3661 in loop507 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3644(t3,((C_word*)t0)[2],t2);}

/* k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm:294: delete */
t3=*((C_word*)lf[300]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[64],*((C_word*)lf[65]+1),*((C_word*)lf[301]+1));}

/* k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1871,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! ##sys#features ...) */,t1);
t3=C_a_i_cons(&a,2,lf[66],*((C_word*)lf[65]+1));
t4=C_mutate((C_word*)lf[65]+1 /* (set! ##sys#features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm:297: user-post-analysis-pass */
t6=*((C_word*)lf[6]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm:300: append */
t4=*((C_word*)lf[226]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[30])[1],*((C_word*)lf[299]+1));}

/* k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[30])+1,t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3607,a[2]=t7,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:302: collect-options */
t9=((C_word*)((C_word*)t0)[15])[1];
f_1549(t9,t8,lf[298]);}

/* k3605 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3609(t5,((C_word*)t0)[2],t1);}

/* loop524 in k3605 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3609(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3609,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[296]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3638,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g540541 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3636 in loop524 in k3605 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3638,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop524537 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3609(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop524537 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3609(t6,((C_word*)t0)[3],t5);}}

/* k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1890,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],tmp=(C_word)a,a+=32,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3504,a[2]=((C_word*)t0)[30],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3508,a[2]=t7,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3564,a[2]=t1,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3568,a[2]=t13,a[3]=t10,a[4]=t12,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:308: collect-options */
t15=((C_word*)((C_word*)t0)[15])[1];
f_1549(t15,t14,lf[297]);}

/* k3566 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3568,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3570,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3570(t5,((C_word*)t0)[2],t1);}

/* loop574 in k3566 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3570(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3570,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[296]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3599,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g590591 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3597 in loop574 in k3566 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3599,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop574587 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3570(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop574587 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3570(t6,((C_word*)t0)[3],t5);}}

/* k3562 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:308: append */
t2=*((C_word*)lf[226]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3506 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3508,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3510,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3510(t5,((C_word*)t0)[2],t1);}

/* loop547 in k3506 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3510(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3510,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,lf[295],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t9=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t8);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t11=C_slot(t2,C_fix(1));
/* loop547560 */
t17=t1;
t18=t11;
t1=t17;
t2=t18;
goto loop;}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[2])+1,t8);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t11=C_slot(t2,C_fix(1));
/* loop547560 */
t17=t1;
t18=t11;
t1=t17;
t2=t18;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3502 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:305: append */
t2=*((C_word*)lf[226]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1890,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[31],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm:312: append */
t4=*((C_word*)lf[226]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[67]+1),((C_word*)t0)[2]);}

/* k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! ##sys#explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
if(C_truep(C_i_memq(lf[293],((C_word*)t0)[30]))){
t4=C_set_block_item(lf[294] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_1897(t5,t4);}
else{
t4=t3;
f_1897(t4,C_SCHEME_UNDEFINED);}}

/* k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1897,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3483,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:318: option-arg */
f_1233(t3,((C_word*)t0)[2]);}
else{
t3=*((C_word*)lf[292]+1);
if(C_truep(t3)){
t4=C_i_zerop(t3);
t5=t2;
f_1901(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1901(2,t4,C_SCHEME_FALSE);}}}

/* k3481 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:318: arg-val */
f_1469(((C_word*)t0)[2],t1);}

/* k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=C_mutate((C_word*)lf[68]+1 /* (set! ##compiler#target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3476,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:322: option-arg */
f_1233(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1905(2,t4,C_SCHEME_FALSE);}}

/* k3474 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:322: arg-val */
f_1469(((C_word*)t0)[2],t1);}

/* k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1 /* (set! ##compiler#target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3469,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:323: option-arg */
f_1233(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1909(2,t4,C_SCHEME_FALSE);}}

/* k3467 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:323: arg-val */
f_1469(((C_word*)t0)[2],t1);}

/* k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! ##compiler#target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3462,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:324: option-arg */
f_1233(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1913(2,t4,C_SCHEME_FALSE);}}

/* k3460 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:324: arg-val */
f_1469(((C_word*)t0)[2],t1);}

/* k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* (set! ##compiler#target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1917,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3442,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:327: option-arg */
f_1233(t4,((C_word*)t0)[4]);}
else{
t4=*((C_word*)lf[291]+1);
if(C_truep(t4)){
t5=C_i_zerop(t4);
t6=t3;
f_1917(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1917(2,t5,C_SCHEME_FALSE);}}}

/* k3440 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:327: arg-val */
f_1469(((C_word*)t0)[2],t1);}

/* k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1917,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1 /* (set! ##compiler#target-stack-size ...) */,t1);
t3=C_i_memq(lf[73],((C_word*)t0)[23]);
t4=C_i_not(t3);
t5=C_mutate((C_word*)lf[74]+1 /* (set! ##compiler#emit-trace-info ...) */,t4);
t6=C_i_memq(lf[75],((C_word*)t0)[23]);
t7=C_mutate((C_word*)lf[76]+1 /* (set! ##compiler#disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(C_i_memq(lf[289],*((C_word*)lf[36]+1)))){
/* batch-driver.scm:333: set-gc-report! */
t9=*((C_word*)lf[290]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1928(2,t9,C_SCHEME_UNDEFINED);}}

/* k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(C_i_memq(lf[284],((C_word*)t0)[23]))){
t3=t2;
f_1931(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[285]+1 /* (set! standard-bindings ...) */,*((C_word*)lf[286]+1));
t4=C_mutate((C_word*)lf[287]+1 /* (set! extended-bindings ...) */,*((C_word*)lf[288]+1));
t5=t2;
f_1931(t5,t4);}}

/* k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1931(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1931,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(*((C_word*)lf[74]+1))){
/* batch-driver.scm:337: dribble */
t3=((C_word*)((C_word*)t0)[15])[1];
f_1341(t3,t2,lf[281],C_a_i_list(&a,1,lf[282]));}
else{
/* batch-driver.scm:337: dribble */
t3=((C_word*)((C_word*)t0)[15])[1];
f_1341(t3,t2,lf[281],C_a_i_list(&a,1,lf[283]));}}

/* k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_i_car(((C_word*)t0)[2]);
t4=C_eqp(lf[273],t3);
t5=C_set_block_item(lf[231] /* emit-profile */,0,C_SCHEME_TRUE);
t6=C_mutate((C_word*)lf[274]+1 /* (set! ##compiler#profiled-procedures ...) */,lf[275]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3401,a[2]=t2,a[3]=((C_word*)t0)[15],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
/* batch-driver.scm:346: append */
t8=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)((C_word*)t0)[5])[1],*((C_word*)lf[279]+1),lf[280]);}
else{
/* batch-driver.scm:346: append */
t8=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)((C_word*)t0)[5])[1],*((C_word*)lf[279]+1),C_SCHEME_END_OF_LIST);}}
else{
t3=t2;
f_1937(2,t3,C_SCHEME_UNDEFINED);}}

/* k3399 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3401,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
/* batch-driver.scm:352: dribble */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1341(t3,((C_word*)t0)[2],lf[276],C_a_i_list(&a,1,lf[277]));}
else{
/* batch-driver.scm:352: dribble */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1341(t3,((C_word*)t0)[2],lf[276],C_a_i_list(&a,1,lf[278]));}}

/* k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:355: load-identifier-database */
t3=*((C_word*)lf[271]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[272]);}

/* k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
if(C_truep(C_i_memq(lf[77],((C_word*)t0)[22]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[21],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:358: print-version */
t3=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_TRUE);}
else{
t2=C_i_memq(lf[79],((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t2)){
t4=t3;
f_1961(t4,t2);}
else{
t4=C_i_memq(lf[268],((C_word*)t0)[22]);
if(C_truep(t4)){
t5=t3;
f_1961(t5,t4);}
else{
t5=C_i_memq(lf[269],((C_word*)t0)[22]);
t6=t3;
f_1961(t6,(C_truep(t5)?t5:C_i_memq(lf[270],((C_word*)t0)[22])));}}}}

/* k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1961(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1961,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm:361: print-usage */
t2=*((C_word*)lf[80]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[22]);}
else{
if(C_truep(C_i_memq(lf[81],((C_word*)t0)[21]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1980,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:363: chicken-version */
t4=*((C_word*)lf[82]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[20];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[21],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[22],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:373: dribble */
t4=((C_word*)((C_word*)t0)[14])[1];
f_1341(t4,t3,lf[264],C_a_i_list(&a,1,((C_word*)t0)[20]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1989,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:366: print-version */
t4=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}}}}

/* k1987 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:367: display */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[267]);}

/* k1990 in k1987 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1995,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:368: display */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[266]);}

/* k1993 in k1990 in k1987 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:369: display */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[265]);}

/* k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2001,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1 /* (set! ##compiler#source-filename ...) */,((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[22],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:375: debugging */
t4=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[259],lf[263],((C_word*)t0)[8]);}

/* k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:376: debugging */
t3=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[259],lf[262],*((C_word*)lf[36]+1));}

/* k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:377: debugging */
t3=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[259],lf[261],*((C_word*)lf[68]+1));}

/* k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:378: debugging */
t3=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[259],lf[260],*((C_word*)lf[72]+1));}

/* k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:94: current-milliseconds */
t3=*((C_word*)lf[48]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[22])+1,t1);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[22],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:382: make-vector */
t4=*((C_word*)lf[257]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[258]+1),C_SCHEME_END_OF_LIST);}

/* k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2022,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1 /* (set! ##sys#line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:383: collect-options */
t4=((C_word*)((C_word*)t0)[9])[1];
f_1549(t4,t3,lf[256]);}

/* k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_2028,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm:384: collect-options */
t3=((C_word*)((C_word*)t0)[9])[1];
f_1549(t3,t2,lf[255]);}

/* k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_2031,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3369,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=((C_word*)t0)[17],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:386: collect-options */
t4=((C_word*)((C_word*)t0)[10])[1];
f_1549(t4,t3,lf[254]);}

/* k3367 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3369,2,t0,t1);}
t2=C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3377,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:388: collect-options */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1549(t4,t3,lf[253]);}

/* k3375 in k3367 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:385: append */
t2=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
/* batch-driver.scm:390: user-read-pass */
t3=*((C_word*)lf[3]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2037,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:392: dribble */
t4=((C_word*)((C_word*)t0)[21])[1];
f_1341(t4,t3,lf[245],C_SCHEME_END_OF_LIST);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3218,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3218(t6,t2,((C_word*)t0)[3]);}}

/* doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3218(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3218,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3229,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3233,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3278,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3278(t12,t8,((C_word*)t0)[3]);}
else{
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:402: check-and-open-input-file */
t5=*((C_word*)lf[252]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k3315 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3317,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3329,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3362,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[251]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a3361 in k3315 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3362,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[248]+1));
t3=C_mutate((C_word*)lf[248]+1 /* (set! ##sys#current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a3333 in k3315 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3334,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3340,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3340(t5,t1);}

/* loop in a3333 in k3315 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3340(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3340,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:405: read/source-info */
t3=*((C_word*)lf[250]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k3342 in loop in a3333 in k3315 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3344,2,t0,t1);}
if(C_truep(C_eofp(t1))){
/* batch-driver.scm:407: close-checked-input-file */
t2=*((C_word*)lf[249]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
/* batch-driver.scm:410: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3340(t4,((C_word*)t0)[6]);}}

/* a3328 in k3315 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3329,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[248]+1));
t3=C_mutate((C_word*)lf[248]+1 /* (set! ##sys#current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k3318 in k3315 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3218(t3,((C_word*)t0)[2],t2);}

/* loop636 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3278(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3278,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[246]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g652653 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3305 in loop636 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop636649 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3278(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop636649 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3278(t6,((C_word*)t0)[3],t5);}}

/* k3231 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:399: reverse */
t3=*((C_word*)lf[247]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3235 in k3231 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3241,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3243,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3243(t10,t6,((C_word*)t0)[2]);}

/* loop659 in k3235 in k3231 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3243(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3243,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[246]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3272,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g675676 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3270 in loop659 in k3235 in k3231 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3272,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop659672 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3243(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop659672 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3243(t6,((C_word*)t0)[3],t5);}}

/* k3239 in k3235 in k3231 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:398: append */
t2=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3227 in doloop631 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3207 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3213,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:393: proc */
t3=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3211 in k3207 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2037(2,t3,t2);}

/* k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:413: user-preprocessor-pass */
t3=*((C_word*)lf[4]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3167,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:415: dribble */
t4=((C_word*)((C_word*)t0)[18])[1];
f_1341(t4,t3,lf[244],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_2043(t3,C_SCHEME_UNDEFINED);}}

/* k3165 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3167,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3173,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3173(t10,t6,((C_word*)((C_word*)t0)[4])[1]);}

/* loop704 in k3165 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3173(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3173,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3202,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g720721 */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3200 in loop704 in k3165 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3202,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop704717 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3173(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop704717 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3173(t6,((C_word*)t0)[3],t5);}}

/* k3169 in k3165 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2043(t3,t2);}

/* k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2043(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2043,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:418: print-expr */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1426(t3,t2,lf[242],lf[243],((C_word*)((C_word*)t0)[3])[1]);}

/* k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm:419: begin-time */
t3=((C_word*)((C_word*)t0)[21])[1];
f_1584(t3,t2);}

/* k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_2052(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:422: append */
t4=*((C_word*)lf[226]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[67]+1),((C_word*)((C_word*)t0)[2])[1]);}}

/* k3142 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3144,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! ##sys#explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3164,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[241]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k3162 in k3142 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3164,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[239],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[240],t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_2052(t7,t6);}

/* k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2052(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2052,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],tmp=(C_word)a,a+=20,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3102,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:424: append */
t8=*((C_word*)lf[226]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k3100 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3102,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3104,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3104(t5,((C_word*)t0)[2],t1);}

/* loop733 in k3100 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3104(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3104,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[238]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3133,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g749750 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3131 in loop733 in k3100 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop733746 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3104(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop733746 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3104(t6,((C_word*)t0)[3],t5);}}

/* k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm:425: gensym */
t3=*((C_word*)lf[237]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2058,2,t0,t1);}
t2=C_i_length(*((C_word*)lf[85]+1));
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],tmp=(C_word)a,a+=18,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3036,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3036(t12,t8,*((C_word*)lf[236]+1));}

/* loop759 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_3036(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3036,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_i_car(t3);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[228],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t4,t8);
t10=C_a_i_cons(&a,2,lf[233],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t12=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11);
t13=C_mutate(((C_word *)((C_word*)t0)[4])+1,t11);
t14=C_slot(t2,C_fix(1));
/* loop759772 */
t20=t1;
t21=t14;
t1=t20;
t2=t21;
goto loop;}
else{
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=C_mutate(((C_word *)((C_word*)t0)[4])+1,t11);
t14=C_slot(t2,C_fix(1));
/* loop759772 */
t20=t1;
t21=t14;
t1=t20;
t2=t21;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2840 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2992,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2992(t10,t6,*((C_word*)lf[235]+1));}

/* loop786 in k2840 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2992(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2992,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[234],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop786799 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop786799 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2844 in k2840 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(*((C_word*)lf[231]+1))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[228],t3);
t5=(C_truep(*((C_word*)lf[209]+1))?C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST):C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST));
t6=C_a_i_cons(&a,2,lf[228],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t4,t7);
t9=C_a_i_cons(&a,2,lf[232],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,*((C_word*)lf[229]+1),t10);
t12=C_a_i_cons(&a,2,lf[233],t11);
t13=t2;
f_2850(t13,C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_2850(t3,C_SCHEME_END_OF_LIST);}}

/* k2848 in k2844 in k2840 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2850(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2850,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2869,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2869(t10,t6,*((C_word*)lf[85]+1));}

/* loop816 in k2848 in k2844 in k2840 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2869(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
loop:
a=C_alloc(27);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2869,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[228],t5);
t7=C_i_cdr(t3);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,lf[228],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t6,t10);
t12=C_a_i_cons(&a,2,*((C_word*)lf[229]+1),t11);
t13=C_a_i_cons(&a,2,lf[230],t12);
t14=C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t15=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t14);
t16=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t17=C_slot(t2,C_fix(1));
/* loop816829 */
t23=t1;
t24=t17;
t1=t23;
t2=t24;
goto loop;}
else{
t15=C_mutate(((C_word *)((C_word*)t0)[2])+1,t14);
t16=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t17=C_slot(t2,C_fix(1));
/* loop816829 */
t23=t1;
t24=t17;
t1=t23;
t2=t24;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2852 in k2848 in k2844 in k2840 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=*((C_word*)lf[209]+1);
if(C_truep(t2)){
/* batch-driver.scm:427: append */
t3=*((C_word*)lf[226]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,lf[227]);}
else{
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm:427: append */
t3=*((C_word*)lf[226]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,lf[227]);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
/* batch-driver.scm:427: append */
t4=*((C_word*)lf[226]+1);
((C_proc9)(void*)(*((C_word*)t4+1)))(9,t4,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,lf[227]);}}}

/* k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2781,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(*((C_word*)lf[223]+1)))){
/* batch-driver.scm:449: debugging */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,lf[224],lf[225]);}
else{
t6=t5;
f_2781(2,t6,C_SCHEME_FALSE);}}

/* k2779 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2786,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2786(t5,((C_word*)t0)[2],*((C_word*)lf[223]+1));}
else{
t2=((C_word*)t0)[2];
f_2067(2,t2,C_SCHEME_UNDEFINED);}}

/* loop845 in k2779 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2786(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2786,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2821,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[32]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2798,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* display */
t7=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,lf[222],t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2796 in loop845 in k2779 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* display */
t4=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* k2799 in k2796 in loop845 in k2779 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[221],((C_word*)t0)[3]);}

/* k2802 in k2799 in k2796 in loop845 in k2779 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2807,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* display */
t4=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* k2805 in k2802 in k2799 in k2796 in loop845 in k2779 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k2819 in loop845 in k2779 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2786(t3,((C_word*)t0)[2],t2);}

/* k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2775,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:453: debugging */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[219],lf[220]);}

/* k2773 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm:454: display-real-name-table */
t2=*((C_word*)lf[218]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_2070(2,t2,C_SCHEME_UNDEFINED);}}

/* k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2769,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:455: debugging */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[216],lf[217]);}

/* k2767 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm:456: display-line-number-database */
t2=*((C_word*)lf[215]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_2073(2,t2,C_SCHEME_UNDEFINED);}}

/* k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(*((C_word*)lf[209]+1))?((C_word*)t0)[11]:C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2754,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* open-output-string */
t5=*((C_word*)lf[214]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2076(2,t4,C_SCHEME_UNDEFINED);}}

/* k2752 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2757,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[213],t1);}

/* k2755 in k2752 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[209]+1),((C_word*)t0)[2]);}

/* k2758 in k2755 in k2752 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[212],((C_word*)t0)[2]);}

/* k2761 in k2758 in k2755 in k2752 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
t3=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2764 in k2761 in k2758 in k2755 in k2752 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:459: ##sys#notice */
t2=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2076,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1 /* (set! ##sys#line-number-database ...) */,*((C_word*)lf[86]+1));
t3=C_set_block_item(lf[86] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm:465: end-time */
t5=((C_word*)((C_word*)t0)[18])[1];
f_1594(t5,t4,lf[208]);}

/* k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2084,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm:466: print-expr */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1426(t3,t2,lf[206],lf[207],((C_word*)((C_word*)t0)[3])[1]);}

/* k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(C_i_memq(lf[205],((C_word*)t0)[3]))){
/* batch-driver.scm:468: exit */
t3=*((C_word*)lf[120]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_2087(2,t3,C_SCHEME_UNDEFINED);}}

/* k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm:470: user-pass */
t3=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2693,a[2]=((C_word*)t0)[16],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:472: dribble */
t4=((C_word*)((C_word*)t0)[13])[1];
f_1341(t4,t3,lf[204],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_2093(2,t3,C_SCHEME_UNDEFINED);}}

/* k2691 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:473: begin-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1584(t3,t2);}

/* k2694 in k2691 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2696,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2705,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_2705(t10,t6,((C_word*)((C_word*)t0)[5])[1]);}

/* loop876 in k2694 in k2691 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2705(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2705,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g892893 */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2732 in loop876 in k2694 in k2691 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2734,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop876889 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2705(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop876889 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2705(t6,((C_word*)t0)[3],t5);}}

/* k2698 in k2694 in k2691 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm:475: end-time */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1594(t3,((C_word*)t0)[2],lf[203]);}

/* k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2690,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:480: canonicalize-begin-body */
t4=*((C_word*)lf[202]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2688 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:479: build-node-graph */
t2=*((C_word*)lf[201]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2686,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=C_a_i_record(&a,4,lf[87],lf[88],lf[89],t2);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm:483: print-node */
t7=((C_word*)((C_word*)t0)[13])[1];
f_1380(t7,t6,lf[199],lf[200],t3);}

/* k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm:484: initialize-analysis-database */
t3=*((C_word*)lf[198]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
if(C_truep(*((C_word*)lf[182]+1))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2632,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[18],a[8]=t2,a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_memq(lf[196],((C_word*)t0)[2]))){
t4=t3;
f_2632(2,t4,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm:489: load-type-database */
t4=*((C_word*)lf[193]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[197]);}}
else{
t3=t2;
f_2110(t3,C_SCHEME_UNDEFINED);}}

/* k2630 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2664,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2672,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:490: collect-options */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1549(t5,t4,lf[195]);}

/* k2670 in k2630 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[194]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2663 in k2630 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2664,3,t0,t1,t2);}
t3=*((C_word*)lf[193]+1);
/* g918919 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* k2633 in k2630 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:491: begin-time */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1584(t3,t2);}

/* k2636 in k2633 in k2630 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=C_set_block_item(lf[92] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2643,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:493: analyze */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1623(t4,t3,lf[192],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k2641 in k2636 in k2633 in k2630 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2643,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:494: print-db */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1402(t4,t3,lf[191],lf[185],((C_word*)((C_word*)t0)[7])[1],C_fix(0));}

/* k2644 in k2641 in k2636 in k2633 in k2630 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:495: end-time */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1594(t3,t2,lf[190]);}

/* k2647 in k2644 in k2641 in k2636 in k2633 in k2630 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:496: begin-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1584(t3,t2);}

/* k2650 in k2647 in k2644 in k2641 in k2636 in k2633 in k2630 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:497: debugging */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[101],lf[189]);}

/* k2653 in k2650 in k2647 in k2644 in k2641 in k2636 in k2633 in k2630 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2658,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:498: scrutinize */
t3=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2656 in k2653 in k2650 in k2647 in k2644 in k2641 in k2636 in k2633 in k2630 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:499: end-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1594(t3,t2,lf[187]);}

/* k2659 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 in k2636 in k2633 in k2630 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[92] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_2110(t3,t2);}

/* k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2110,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(*((C_word*)lf[177]+1))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[17],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[14],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:503: begin-time */
t4=((C_word*)((C_word*)t0)[16])[1];
f_1584(t4,t3);}
else{
t3=t2;
f_2113(t3,C_SCHEME_UNDEFINED);}}

/* k2600 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2605,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(*((C_word*)lf[182]+1))){
t3=t2;
f_2605(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(lf[92] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:506: analyze */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1623(t5,t4,lf[186],((C_word*)t0)[7],C_SCHEME_END_OF_LIST);}}

/* k2621 in k2600 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2623,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:507: print-db */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1402(t4,t3,lf[184],lf[185],((C_word*)((C_word*)t0)[5])[1],C_fix(0));}

/* k2624 in k2621 in k2600 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:508: end-time */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1594(t2,((C_word*)t0)[2],lf[183]);}

/* k2603 in k2600 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:509: begin-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1584(t3,t2);}

/* k2606 in k2603 in k2600 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:510: perform-lambda-lifting! */
t3=*((C_word*)lf[181]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2609 in k2606 in k2603 in k2600 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:511: end-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1594(t3,t2,lf[180]);}

/* k2612 in k2609 in k2606 in k2603 in k2600 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2617,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:512: print-node */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1380(t3,t2,lf[178],lf[179],((C_word*)t0)[2]);}

/* k2615 in k2612 in k2609 in k2606 in k2603 in k2600 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[92] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_2113(t3,t2);}

/* k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2113,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:515: vector->list */
t4=*((C_word*)lf[175]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[176]+1));}

/* k2597 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:515: concatenate */
t2=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2119,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2592,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:516: debugging */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[173],lf[174]);}

/* k2590 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm:517: pp */
t2=*((C_word*)lf[172]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2119(2,t2,C_SCHEME_UNDEFINED);}}

/* k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2122,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(*((C_word*)lf[163]+1))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2499,a[2]=t2,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2554,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2556,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_2556(t12,t8,((C_word*)t0)[2]);}
else{
t3=t2;
f_2122(2,t3,C_SCHEME_UNDEFINED);}}

/* loop959 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2556(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2556,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[171]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g975976 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2583 in loop959 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2585,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop959972 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2556(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop959972 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2556(t6,((C_word*)t0)[3],t5);}}

/* k2552 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:527: concatenate */
t2=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2497 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2501,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2501(t5,((C_word*)t0)[2],t1);}

/* loop943 in k2497 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2501,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2539,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g950951 */
t6=t3;
f_2509(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2537 in loop943 in k2497 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2501(t3,((C_word*)t0)[2],t2);}

/* g950 in loop943 in k2497 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2509(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2509,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2532,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2536,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:522: symbol->string */
t6=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2534 in g950 in loop943 in k2497 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:522: make-pathname */
t2=*((C_word*)lf[167]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[168]);}

/* k2530 in g950 in loop943 in k2497 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:521: ##sys#resolve-include-filename */
t2=*((C_word*)lf[166]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2511 in g950 in loop943 in k2497 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2513,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:524: file-exists? */
t3=*((C_word*)lf[165]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2520 in k2511 in g950 in loop943 in k2497 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2522,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:525: dribble */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1341(t3,t2,lf[164],C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2523 in k2520 in k2511 in g950 in loop943 in k2497 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:526: load-inline-file */
t2=*((C_word*)lf[160]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm:528: collect-options */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1549(t3,t2,lf[162]);}

/* k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_i_nullp(t1))){
t3=t2;
f_2128(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(lf[159] /* inline-locally */,0,C_SCHEME_TRUE);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2463,a[2]=t5,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_2463(t7,t2,t1);}}

/* loop983 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2463(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2463,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2471,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2481,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g990991 */
t6=t3;
f_2471(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2479 in loop983 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2463(t3,((C_word*)t0)[2],t2);}

/* g990 in loop983 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2471(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2471,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2475,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:533: dribble */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1341(t4,t3,lf[161],C_a_i_list(&a,1,t2));}

/* k2473 in g990 in loop983 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:534: load-inline-file */
t2=*((C_word*)lf[160]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2128,2,t0,t1);}
t2=C_set_block_item(lf[84] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[90] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[91] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(*((C_word*)lf[121]+1))){
t6=t5;
f_2134(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=C_slot(((C_word*)t0)[2],C_fix(3));
t7=C_i_car(t6);
/* batch-driver.scm:541: scan-toplevel-assignments */
t8=*((C_word*)lf[158]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}}

/* k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm:543: begin-time */
t3=((C_word*)((C_word*)t0)[14])[1];
f_1584(t3,t2);}

/* k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm:544: perform-cps-conversion */
t3=*((C_word*)lf[157]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2143,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm:545: end-time */
t3=((C_word*)((C_word*)t0)[14])[1];
f_1594(t3,t2,lf[156]);}

/* k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm:546: print-node */
t3=((C_word*)((C_word*)t0)[12])[1];
f_1380(t3,t2,lf[154],lf[155],((C_word*)t0)[2]);}

/* k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=t3,tmp=(C_word)a,a+=15,tmp));
t5=((C_word*)t3)[1];
f_2151(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_2151(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2151,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=t2,a[17]=t5,a[18]=t4,tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm:551: begin-time */
t7=((C_word*)((C_word*)t0)[12])[1];
f_1584(t7,t6);}

/* k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm:552: analyze */
t3=((C_word*)((C_word*)t0)[12])[1];
f_1623(t3,t2,lf[153],((C_word*)((C_word*)t0)[17])[1],C_a_i_list(&a,2,((C_word*)t0)[16],((C_word*)t0)[18]));}

/* k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t1,a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
if(C_truep(*((C_word*)lf[92]+1))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2414,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_memq(lf[151],*((C_word*)lf[36]+1)))){
/* batch-driver.scm:555: dump-undefined-globals */
t4=*((C_word*)lf[152]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}
else{
t4=t3;
f_2414(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2161(2,t3,C_SCHEME_UNDEFINED);}}

/* k2412 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_memq(lf[149],*((C_word*)lf[36]+1)))){
/* batch-driver.scm:557: dump-defined-globals */
t3=*((C_word*)lf[150]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2417(2,t3,C_SCHEME_UNDEFINED);}}

/* k2415 in k2412 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_memq(lf[147],*((C_word*)lf[36]+1)))){
/* batch-driver.scm:559: dump-global-refs */
t2=*((C_word*)lf[148]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_2161(2,t3,t2);}}

/* k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2161,2,t0,t1);}
t2=C_set_block_item(lf[92] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm:561: end-time */
t4=((C_word*)((C_word*)t0)[14])[1];
f_1594(t4,t3,lf[146]);}

/* k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm:562: print-db */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1402(t3,t2,lf[144],lf[145],((C_word*)t0)[17],((C_word*)t0)[16]);}

/* k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
if(C_truep(C_i_memq(lf[142],*((C_word*)lf[36]+1)))){
/* batch-driver.scm:564: print-program-statistics */
t3=*((C_word*)lf[143]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[17]);}
else{
t3=t2;
f_2171(2,t3,C_SCHEME_UNDEFINED);}}

/* k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2171,2,t0,t1);}
if(C_truep(((C_word*)t0)[19])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:567: debugging */
t3=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[101],lf[106],((C_word*)t0)[16]);}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm:589: print-node */
t3=((C_word*)((C_word*)t0)[11])[1];
f_1380(t3,t2,lf[140],lf[141],((C_word*)((C_word*)t0)[18])[1]);}}

/* k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(*((C_word*)lf[136]+1))?*((C_word*)lf[137]+1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=*((C_word*)lf[136]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[15],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:594: dribble */
t6=((C_word*)((C_word*)t0)[14])[1];
f_1341(t6,t5,lf[139],C_a_i_list(&a,1,t4));}
else{
t4=t2;
f_2266(2,t4,C_SCHEME_UNDEFINED);}}

/* k2400 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:595: emit-global-inline-file */
t2=*((C_word*)lf[138]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm:596: check-for-unsafe-toplevel-procedure-calls */
t3=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[16])[1],((C_word*)t0)[15]);}

/* k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm:597: begin-time */
t3=((C_word*)((C_word*)t0)[9])[1];
f_1584(t3,t2);}

/* k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm:598: perform-closure-conversion */
t3=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[16])[1],((C_word*)t0)[15]);}

/* k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2276,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[16])+1,t1);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm:599: end-time */
t4=((C_word*)((C_word*)t0)[13])[1];
f_1594(t4,t3,lf[133]);}

/* k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm:600: print-db */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1402(t3,t2,lf[131],lf[132],((C_word*)t0)[15],((C_word*)t0)[2]);}

/* k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(*((C_word*)lf[129]+1))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2396,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:94: current-milliseconds */
t4=*((C_word*)lf[48]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2285(2,t3,C_SCHEME_UNDEFINED);}}

/* k2394 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2396,2,t0,t1);}
t2=C_a_i_minus(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(C_i_greaterp(t2,C_fix(60000)))){
/* batch-driver.scm:603: display */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],lf[130]);}
else{
t3=((C_word*)t0)[2];
f_2285(2,t3,C_SCHEME_UNDEFINED);}}

/* k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm:604: print-node */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1380(t3,t2,lf[127],lf[128],((C_word*)((C_word*)t0)[13])[1]);}

/* k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(C_truep(((C_word*)t0)[3])?*((C_word*)lf[121]+1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2367,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[13],a[5]=t2,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:606: debugging */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[101],lf[126]);}
else{
t4=t2;
f_2291(2,t4,C_SCHEME_UNDEFINED);}}

/* k2365 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:607: begin-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1584(t3,t2);}

/* k2368 in k2365 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:608: perform-unboxing! */
t3=*((C_word*)lf[125]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k2371 in k2368 in k2365 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:609: end-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1594(t3,t2,lf[124]);}

/* k2374 in k2371 in k2368 in k2365 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:610: print-node */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1380(t2,((C_word*)t0)[3],lf[122],lf[123],((C_word*)((C_word*)t0)[2])[1]);}

/* k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2294,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm:611: exit */
t3=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(0));}
else{
t3=t2;
f_2294(2,t3,C_SCHEME_UNDEFINED);}}

/* k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:612: begin-time */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1584(t3,t2);}

/* k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2302,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2307 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2308,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=t1,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm:616: end-time */
t7=((C_word*)((C_word*)t0)[7])[1];
f_1594(t7,t6,lf[119]);}

/* k2310 in a2307 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm:617: begin-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1584(t3,t2);}

/* k2313 in k2310 in a2307 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[8])){
/* batch-driver.scm:618: open-output-file */
t3=*((C_word*)lf[117]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}
else{
/* batch-driver.scm:618: current-output-port */
t3=*((C_word*)lf[118]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2316 in k2313 in k2310 in a2307 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm:619: dribble */
t3=((C_word*)((C_word*)t0)[11])[1];
f_1341(t3,t2,lf[116],C_a_i_list(&a,1,((C_word*)t0)[8]));}

/* k2319 in k2316 in k2313 in k2310 in a2307 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:620: generate-code */
t3=*((C_word*)lf[115]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2322 in k2319 in k2316 in k2313 in k2310 in a2307 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2327,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm:621: close-output-port */
t3=*((C_word*)lf[114]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2327(2,t3,C_SCHEME_UNDEFINED);}}

/* k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in a2307 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2330,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:622: end-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1594(t3,t2,lf[113]);}

/* k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in a2307 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_memq(lf[110],*((C_word*)lf[36]+1)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2349,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:624: ##sys#stop-timer */
t4=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f4798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:625: compiler-cleanup-hook */
t4=*((C_word*)lf[109]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f4798 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in a2307 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f4798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:626: dribble */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1341(t2,((C_word*)t0)[2],lf[108],C_SCHEME_END_OF_LIST);}

/* k2347 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in a2307 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:624: ##sys#display-times */
t2=*((C_word*)lf[111]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in a2307 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:625: compiler-cleanup-hook */
t3=*((C_word*)lf[109]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2334 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in a2307 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:626: dribble */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1341(t2,((C_word*)t0)[2],lf[108],C_SCHEME_END_OF_LIST);}

/* a2301 in k2295 in k2292 in k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2270 in k2267 in k2264 in k2261 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2302,2,t0,t1);}
/* batch-driver.scm:615: prepare-for-code-generation */
t2=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:568: begin-time */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1584(t3,t2);}

/* k2178 in k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2190 in k2178 in k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2191,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm:571: end-time */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1594(t5,t4,lf[105]);}

/* k2193 in a2190 in k2178 in k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm:572: print-node */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1380(t3,t2,lf[103],lf[104],((C_word*)t0)[6]);}

/* k2196 in k2193 in a2190 in k2178 in k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2198,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1));
/* batch-driver.scm:573: loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2151(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=*((C_word*)lf[94]+1);
if(C_truep(t2)){
if(C_truep(*((C_word*)lf[95]+1))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:579: begin-time */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1584(t4,t3);}
else{
t3=C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1));
/* batch-driver.scm:586: loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2151(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm:575: debugging */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[101],lf[102]);}}}

/* k2215 in k2196 in k2193 in a2190 in k2178 in k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2217,2,t0,t1);}
t2=C_set_block_item(lf[94] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
/* batch-driver.scm:577: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2151(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2229 in k2196 in k2193 in a2190 in k2178 in k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:580: analyze */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1623(t3,t2,lf[99],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k2232 in k2229 in k2196 in k2193 in a2190 in k2178 in k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm:581: end-time */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1594(t3,t2,lf[98]);}

/* k2235 in k2232 in k2229 in k2196 in k2193 in a2190 in k2178 in k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:582: begin-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1584(t3,t2);}

/* k2238 in k2235 in k2232 in k2229 in k2196 in k2193 in a2190 in k2178 in k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:583: transform-direct-lambdas! */
t3=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2241 in k2238 in k2235 in k2232 in k2229 in k2196 in k2193 in a2190 in k2178 in k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2246,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm:584: end-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1594(t3,t2,lf[96]);}

/* k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2196 in k2193 in a2190 in k2178 in k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* batch-driver.scm:585: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2151(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2184 in k2178 in k2175 in k2169 in k2166 in k2163 in k2159 in k2156 in k2153 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2120 in k2117 in k2114 in k2111 in k2108 in k2105 in k2102 in k2684 in k2091 in k2088 in k2085 in k2082 in k2079 in k2074 in k2071 in k2068 in k2065 in k2062 in k2056 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2016 in k2012 in k2009 in k2006 in k2003 in k1999 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2185,2,t0,t1);}
/* batch-driver.scm:570: perform-high-level-optimizations */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k1978 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:363: display */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1971 in k1959 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:364: newline */
t2=*((C_word*)lf[45]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1947 in k1938 in k1935 in k1932 in k1929 in k1926 in k1915 in k1911 in k1907 in k1903 in k1899 in k1895 in k1892 in k1888 in k1884 in k1881 in k1877 in k1869 in k1865 in k1862 in k1859 in k1856 in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in k1831 in k1828 in k1825 in k1821 in k1818 in k1812 in k1809 in k1806 in k1803 in k1800 in k1797 in k1791 in k1785 in k1782 in k1779 in k1776 in k1773 in k1770 in k1767 in k1764 in k1761 in k1758 in k1755 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1731 in k1728 in k1721 in k1718 in k1710 in k1706 in k1703 in k1700 in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:359: newline */
t2=*((C_word*)lf[45]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* analyze in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1623(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1623,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1625,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1648,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1653,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-no207242 */
t8=t7;
f_1653(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* def-contf208240 */
t10=t6;
f_1648(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* body205212 */
t12=t5;
f_1625(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-no207 in analyze in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1653(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1653,NULL,2,t0,t1);}
/* def-contf208240 */
t2=((C_word*)t0)[2];
f_1648(t2,t1,C_fix(0));}

/* def-contf208 in analyze in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1648(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1648,NULL,3,t0,t1,t2);}
/* body205212 */
t3=((C_word*)t0)[2];
f_1625(t3,t1,t2,C_SCHEME_TRUE);}

/* body205 in analyze in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1625(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1625,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1629,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm:150: analyze-expression */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k1627 in body205 in analyze in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1632,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1637,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1643,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:152: upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)(void*)(*((C_word*)t5+1)))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* a1642 in k1627 in body205 in analyze in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1643,5,t0,t1,t2,t3,t4);}
t5=*((C_word*)lf[52]+1);
/* g237238 */
t6=t5;
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1636 in k1627 in body205 in analyze in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1637,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[51]+1);
/* g224225 */
t5=t4;
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* k1630 in k1627 in body205 in analyze in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* end-time in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1594(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1594,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=*((C_word*)lf[32]+1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1601,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* display */
t5=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[50],t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1599 in end-time in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1604,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k1602 in k1599 in end-time in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[49],((C_word*)t0)[3]);}

/* k1605 in k1602 in k1599 in end-time in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:94: current-milliseconds */
t4=*((C_word*)lf[48]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1619 in k1605 in k1602 in k1599 in end-time in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1621,2,t0,t1);}
t2=C_a_i_minus(&a,2,t1,((C_word*)((C_word*)t0)[4])[1]);
/* write */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1608 in k1605 in k1602 in k1599 in end-time in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* begin-time in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1584(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1584,NULL,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1592,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:94: current-milliseconds */
t3=*((C_word*)lf[48]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1590 in begin-time in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* collect-options in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1549(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1549,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1555(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1555(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1555,NULL,3,t0,t1,t2);}
t3=C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* g188189 */
t5=t4;
f_1563(t5,t1,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* g188 in loop in collect-options in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1563(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1563,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:138: option-arg */
f_1233(t3,t2);}

/* k1569 in g188 in loop in collect-options in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1575,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm:138: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1555(t4,t2,t3);}

/* k1573 in k1569 in g188 in loop in collect-options in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1575,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1469(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1469,NULL,2,t1,t2);}
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1479,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_lessp(t3,C_fix(2)))){
/* batch-driver.scm:129: string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=C_i_string_ref(t2,t4);
t7=C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1510,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1518,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:131: substring */
t11=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t10,t2,C_fix(0),t4);}
else{
t9=C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1534,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1538,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:132: substring */
t13=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm:133: string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k1536 in arg-val in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:132: string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1532 in arg-val in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1534,2,t0,t1);}
t2=C_a_i_times(&a,2,t1,C_fix(1024));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* batch-driver.scm:134: quit */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],lf[46],((C_word*)t0)[2]);}}

/* k1516 in arg-val in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:131: string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1508 in arg-val in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1510,2,t0,t1);}
t2=C_a_i_times(&a,2,t1,C_fix(1048576));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* batch-driver.scm:134: quit */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],lf[46],((C_word*)t0)[2]);}}

/* k1477 in arg-val in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* batch-driver.scm:134: quit */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[46],((C_word*)t0)[2]);}}

/* print-expr in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1426(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1426,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1433,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm:118: print-header */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1356(t6,t5,t2,t3);}

/* k1431 in print-expr in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1433,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1438,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1438(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop150 in k1431 in print-expr in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1438(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1438,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1456,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1450,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:121: pretty-print */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1448 in loop150 in k1431 in print-expr in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:122: newline */
t2=*((C_word*)lf[45]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1454 in loop150 in k1431 in print-expr in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1438(t3,((C_word*)t0)[2],t2);}

/* print-db in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1402(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1402,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1409,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:113: print-header */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1356(t7,t6,t2,t3);}

/* k1407 in print-db in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1409,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[32]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1412,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* display */
t4=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[44],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1410 in k1407 in print-db in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1413 in k1410 in k1407 in print-db in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[2]);}

/* k1416 in k1413 in k1410 in k1407 in print-db in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1419 in k1416 in k1413 in k1410 in k1407 in print-db in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:115: display-analysis-database */
t2=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1380(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1380,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1387,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:107: print-header */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1356(t6,t5,t2,t3);}

/* k1385 in print-node in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1387,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm:109: dump-nodes */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1400,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm:110: build-expression-tree */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1398 in k1385 in print-node in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm:110: pretty-print */
t2=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* print-header in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1356(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1356,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1360,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm:100: dribble */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1341(t5,t4,lf[38],C_a_i_list(&a,1,t2));}

/* k1358 in print-header in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1360,2,t0,t1);}
if(C_truep(C_i_memq(((C_word*)t0)[4],*((C_word*)lf[36]+1)))){
t2=*((C_word*)lf[32]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(91),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1367 in k1358 in print-header in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1372,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1370 in k1367 in k1358 in print-header in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(93),((C_word*)t0)[2]);}

/* k1373 in k1370 in k1367 in k1358 in print-header in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1378,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1376 in k1373 in k1370 in k1367 in k1358 in print-header in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* dribble in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1341(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1341,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
t4=*((C_word*)lf[32]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1348,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t5,*((C_word*)lf[35]+1),t4,t2,t3);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1346 in dribble in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1349 in k1346 in dribble in k1289 in k1283 in k1280 in k4481 in k1264 in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_ccall f_1351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#flush-output */
t2=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* option-arg in compile-source-file in k1226 in k1222 in k1218 in k1214 in k1210 in k1205 in k1202 */
static void C_fcall f_1233(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1233,NULL,2,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
t4=C_i_car(t2);
/* batch-driver.scm:49: quit */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[9],t4);}
else{
t4=C_i_cadr(t2);
if(C_truep(C_i_symbolp(t4))){
/* batch-driver.scm:52: quit */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[10],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[411] = {
{"toplevel:batch_driver_scm",(void*)C_driver_toplevel},
{"f_1204:batch_driver_scm",(void*)f_1204},
{"f_1207:batch_driver_scm",(void*)f_1207},
{"f_1212:batch_driver_scm",(void*)f_1212},
{"f_1216:batch_driver_scm",(void*)f_1216},
{"f_1220:batch_driver_scm",(void*)f_1220},
{"f_1224:batch_driver_scm",(void*)f_1224},
{"f_1228:batch_driver_scm",(void*)f_1228},
{"f_1230:batch_driver_scm",(void*)f_1230},
{"f_1266:batch_driver_scm",(void*)f_1266},
{"f_4502:batch_driver_scm",(void*)f_4502},
{"f_4487:batch_driver_scm",(void*)f_4487},
{"f_4483:batch_driver_scm",(void*)f_4483},
{"f_4472:batch_driver_scm",(void*)f_4472},
{"f_4443:batch_driver_scm",(void*)f_4443},
{"f_4447:batch_driver_scm",(void*)f_4447},
{"f_1282:batch_driver_scm",(void*)f_1282},
{"f_4439:batch_driver_scm",(void*)f_4439},
{"f_4400:batch_driver_scm",(void*)f_4400},
{"f_4402:batch_driver_scm",(void*)f_4402},
{"f_4431:batch_driver_scm",(void*)f_4431},
{"f_1285:batch_driver_scm",(void*)f_1285},
{"f_1291:batch_driver_scm",(void*)f_1291},
{"f_4381:batch_driver_scm",(void*)f_4381},
{"f_4377:batch_driver_scm",(void*)f_4377},
{"f_4373:batch_driver_scm",(void*)f_4373},
{"f_1702:batch_driver_scm",(void*)f_1702},
{"f_1705:batch_driver_scm",(void*)f_1705},
{"f_1708:batch_driver_scm",(void*)f_1708},
{"f_4358:batch_driver_scm",(void*)f_4358},
{"f_4302:batch_driver_scm",(void*)f_4302},
{"f_4310:batch_driver_scm",(void*)f_4310},
{"f_4312:batch_driver_scm",(void*)f_4312},
{"f_4350:batch_driver_scm",(void*)f_4350},
{"f_1712:batch_driver_scm",(void*)f_1712},
{"f_4252:batch_driver_scm",(void*)f_4252},
{"f_4254:batch_driver_scm",(void*)f_4254},
{"f_4289:batch_driver_scm",(void*)f_4289},
{"f_4293:batch_driver_scm",(void*)f_4293},
{"f_1720:batch_driver_scm",(void*)f_1720},
{"f_1723:batch_driver_scm",(void*)f_1723},
{"f_1730:batch_driver_scm",(void*)f_1730},
{"f_1733:batch_driver_scm",(void*)f_1733},
{"f_1736:batch_driver_scm",(void*)f_1736},
{"f_1739:batch_driver_scm",(void*)f_1739},
{"f_1742:batch_driver_scm",(void*)f_1742},
{"f_1745:batch_driver_scm",(void*)f_1745},
{"f_1748:batch_driver_scm",(void*)f_1748},
{"f_1751:batch_driver_scm",(void*)f_1751},
{"f_1754:batch_driver_scm",(void*)f_1754},
{"f_1757:batch_driver_scm",(void*)f_1757},
{"f_1760:batch_driver_scm",(void*)f_1760},
{"f_4182:batch_driver_scm",(void*)f_4182},
{"f_1763:batch_driver_scm",(void*)f_1763},
{"f_1766:batch_driver_scm",(void*)f_1766},
{"f_1769:batch_driver_scm",(void*)f_1769},
{"f_1772:batch_driver_scm",(void*)f_1772},
{"f_1775:batch_driver_scm",(void*)f_1775},
{"f_1778:batch_driver_scm",(void*)f_1778},
{"f_1781:batch_driver_scm",(void*)f_1781},
{"f_1784:batch_driver_scm",(void*)f_1784},
{"f_1787:batch_driver_scm",(void*)f_1787},
{"f_4144:batch_driver_scm",(void*)f_4144},
{"f_1793:batch_driver_scm",(void*)f_1793},
{"f_4129:batch_driver_scm",(void*)f_4129},
{"f_4132:batch_driver_scm",(void*)f_4132},
{"f_4135:batch_driver_scm",(void*)f_4135},
{"f_1799:batch_driver_scm",(void*)f_1799},
{"f_4119:batch_driver_scm",(void*)f_4119},
{"f_4122:batch_driver_scm",(void*)f_4122},
{"f_1802:batch_driver_scm",(void*)f_1802},
{"f_4083:batch_driver_scm",(void*)f_4083},
{"f_1805:batch_driver_scm",(void*)f_1805},
{"f_4077:batch_driver_scm",(void*)f_4077},
{"f_1808:batch_driver_scm",(void*)f_1808},
{"f_4068:batch_driver_scm",(void*)f_4068},
{"f_1811:batch_driver_scm",(void*)f_1811},
{"f_4050:batch_driver_scm",(void*)f_4050},
{"f_4053:batch_driver_scm",(void*)f_4053},
{"f_4056:batch_driver_scm",(void*)f_4056},
{"f_4059:batch_driver_scm",(void*)f_4059},
{"f_1814:batch_driver_scm",(void*)f_1814},
{"f_4009:batch_driver_scm",(void*)f_4009},
{"f_4011:batch_driver_scm",(void*)f_4011},
{"f_4040:batch_driver_scm",(void*)f_4040},
{"f_4005:batch_driver_scm",(void*)f_4005},
{"f_1820:batch_driver_scm",(void*)f_1820},
{"f_1823:batch_driver_scm",(void*)f_1823},
{"f_3954:batch_driver_scm",(void*)f_3954},
{"f_3956:batch_driver_scm",(void*)f_3956},
{"f_3985:batch_driver_scm",(void*)f_3985},
{"f_1827:batch_driver_scm",(void*)f_1827},
{"f_1830:batch_driver_scm",(void*)f_1830},
{"f_1833:batch_driver_scm",(void*)f_1833},
{"f_1836:batch_driver_scm",(void*)f_1836},
{"f_1839:batch_driver_scm",(void*)f_1839},
{"f_1842:batch_driver_scm",(void*)f_1842},
{"f_3847:batch_driver_scm",(void*)f_3847},
{"f_3861:batch_driver_scm",(void*)f_3861},
{"f_3886:batch_driver_scm",(void*)f_3886},
{"f_3891:batch_driver_scm",(void*)f_3891},
{"f_3919:batch_driver_scm",(void*)f_3919},
{"f_3757:batch_driver_scm",(void*)f_3757},
{"f_3762:batch_driver_scm",(void*)f_3762},
{"f_3776:batch_driver_scm",(void*)f_3776},
{"f_3801:batch_driver_scm",(void*)f_3801},
{"f_3806:batch_driver_scm",(void*)f_3806},
{"f_3834:batch_driver_scm",(void*)f_3834},
{"f_1845:batch_driver_scm",(void*)f_1845},
{"f_3751:batch_driver_scm",(void*)f_3751},
{"f_3743:batch_driver_scm",(void*)f_3743},
{"f_3718:batch_driver_scm",(void*)f_3718},
{"f_3720:batch_driver_scm",(void*)f_3720},
{"f_3730:batch_driver_scm",(void*)f_3730},
{"f_1848:batch_driver_scm",(void*)f_1848},
{"f_3714:batch_driver_scm",(void*)f_3714},
{"f_3706:batch_driver_scm",(void*)f_3706},
{"f_3681:batch_driver_scm",(void*)f_3681},
{"f_3683:batch_driver_scm",(void*)f_3683},
{"f_3693:batch_driver_scm",(void*)f_3693},
{"f_1851:batch_driver_scm",(void*)f_1851},
{"f_1858:batch_driver_scm",(void*)f_1858},
{"f_1861:batch_driver_scm",(void*)f_1861},
{"f_1864:batch_driver_scm",(void*)f_1864},
{"f_3644:batch_driver_scm",(void*)f_3644},
{"f_3660:batch_driver_scm",(void*)f_3660},
{"f_3663:batch_driver_scm",(void*)f_3663},
{"f_1867:batch_driver_scm",(void*)f_1867},
{"f_1871:batch_driver_scm",(void*)f_1871},
{"f_1879:batch_driver_scm",(void*)f_1879},
{"f_1883:batch_driver_scm",(void*)f_1883},
{"f_3607:batch_driver_scm",(void*)f_3607},
{"f_3609:batch_driver_scm",(void*)f_3609},
{"f_3638:batch_driver_scm",(void*)f_3638},
{"f_1886:batch_driver_scm",(void*)f_1886},
{"f_3568:batch_driver_scm",(void*)f_3568},
{"f_3570:batch_driver_scm",(void*)f_3570},
{"f_3599:batch_driver_scm",(void*)f_3599},
{"f_3564:batch_driver_scm",(void*)f_3564},
{"f_3508:batch_driver_scm",(void*)f_3508},
{"f_3510:batch_driver_scm",(void*)f_3510},
{"f_3504:batch_driver_scm",(void*)f_3504},
{"f_1890:batch_driver_scm",(void*)f_1890},
{"f_1894:batch_driver_scm",(void*)f_1894},
{"f_1897:batch_driver_scm",(void*)f_1897},
{"f_3483:batch_driver_scm",(void*)f_3483},
{"f_1901:batch_driver_scm",(void*)f_1901},
{"f_3476:batch_driver_scm",(void*)f_3476},
{"f_1905:batch_driver_scm",(void*)f_1905},
{"f_3469:batch_driver_scm",(void*)f_3469},
{"f_1909:batch_driver_scm",(void*)f_1909},
{"f_3462:batch_driver_scm",(void*)f_3462},
{"f_1913:batch_driver_scm",(void*)f_1913},
{"f_3442:batch_driver_scm",(void*)f_3442},
{"f_1917:batch_driver_scm",(void*)f_1917},
{"f_1928:batch_driver_scm",(void*)f_1928},
{"f_1931:batch_driver_scm",(void*)f_1931},
{"f_1934:batch_driver_scm",(void*)f_1934},
{"f_3401:batch_driver_scm",(void*)f_3401},
{"f_1937:batch_driver_scm",(void*)f_1937},
{"f_1940:batch_driver_scm",(void*)f_1940},
{"f_1961:batch_driver_scm",(void*)f_1961},
{"f_1989:batch_driver_scm",(void*)f_1989},
{"f_1992:batch_driver_scm",(void*)f_1992},
{"f_1995:batch_driver_scm",(void*)f_1995},
{"f_2001:batch_driver_scm",(void*)f_2001},
{"f_2005:batch_driver_scm",(void*)f_2005},
{"f_2008:batch_driver_scm",(void*)f_2008},
{"f_2011:batch_driver_scm",(void*)f_2011},
{"f_2014:batch_driver_scm",(void*)f_2014},
{"f_2018:batch_driver_scm",(void*)f_2018},
{"f_2022:batch_driver_scm",(void*)f_2022},
{"f_2025:batch_driver_scm",(void*)f_2025},
{"f_2028:batch_driver_scm",(void*)f_2028},
{"f_3369:batch_driver_scm",(void*)f_3369},
{"f_3377:batch_driver_scm",(void*)f_3377},
{"f_2031:batch_driver_scm",(void*)f_2031},
{"f_2034:batch_driver_scm",(void*)f_2034},
{"f_3218:batch_driver_scm",(void*)f_3218},
{"f_3317:batch_driver_scm",(void*)f_3317},
{"f_3362:batch_driver_scm",(void*)f_3362},
{"f_3334:batch_driver_scm",(void*)f_3334},
{"f_3340:batch_driver_scm",(void*)f_3340},
{"f_3344:batch_driver_scm",(void*)f_3344},
{"f_3329:batch_driver_scm",(void*)f_3329},
{"f_3320:batch_driver_scm",(void*)f_3320},
{"f_3278:batch_driver_scm",(void*)f_3278},
{"f_3307:batch_driver_scm",(void*)f_3307},
{"f_3233:batch_driver_scm",(void*)f_3233},
{"f_3237:batch_driver_scm",(void*)f_3237},
{"f_3243:batch_driver_scm",(void*)f_3243},
{"f_3272:batch_driver_scm",(void*)f_3272},
{"f_3241:batch_driver_scm",(void*)f_3241},
{"f_3229:batch_driver_scm",(void*)f_3229},
{"f_3209:batch_driver_scm",(void*)f_3209},
{"f_3213:batch_driver_scm",(void*)f_3213},
{"f_2037:batch_driver_scm",(void*)f_2037},
{"f_2040:batch_driver_scm",(void*)f_2040},
{"f_3167:batch_driver_scm",(void*)f_3167},
{"f_3173:batch_driver_scm",(void*)f_3173},
{"f_3202:batch_driver_scm",(void*)f_3202},
{"f_3171:batch_driver_scm",(void*)f_3171},
{"f_2043:batch_driver_scm",(void*)f_2043},
{"f_2046:batch_driver_scm",(void*)f_2046},
{"f_2049:batch_driver_scm",(void*)f_2049},
{"f_3144:batch_driver_scm",(void*)f_3144},
{"f_3164:batch_driver_scm",(void*)f_3164},
{"f_2052:batch_driver_scm",(void*)f_2052},
{"f_3102:batch_driver_scm",(void*)f_3102},
{"f_3104:batch_driver_scm",(void*)f_3104},
{"f_3133:batch_driver_scm",(void*)f_3133},
{"f_2055:batch_driver_scm",(void*)f_2055},
{"f_2058:batch_driver_scm",(void*)f_2058},
{"f_3036:batch_driver_scm",(void*)f_3036},
{"f_2842:batch_driver_scm",(void*)f_2842},
{"f_2992:batch_driver_scm",(void*)f_2992},
{"f_2846:batch_driver_scm",(void*)f_2846},
{"f_2850:batch_driver_scm",(void*)f_2850},
{"f_2869:batch_driver_scm",(void*)f_2869},
{"f_2854:batch_driver_scm",(void*)f_2854},
{"f_2064:batch_driver_scm",(void*)f_2064},
{"f_2781:batch_driver_scm",(void*)f_2781},
{"f_2786:batch_driver_scm",(void*)f_2786},
{"f_2798:batch_driver_scm",(void*)f_2798},
{"f_2801:batch_driver_scm",(void*)f_2801},
{"f_2804:batch_driver_scm",(void*)f_2804},
{"f_2807:batch_driver_scm",(void*)f_2807},
{"f_2821:batch_driver_scm",(void*)f_2821},
{"f_2067:batch_driver_scm",(void*)f_2067},
{"f_2775:batch_driver_scm",(void*)f_2775},
{"f_2070:batch_driver_scm",(void*)f_2070},
{"f_2769:batch_driver_scm",(void*)f_2769},
{"f_2073:batch_driver_scm",(void*)f_2073},
{"f_2754:batch_driver_scm",(void*)f_2754},
{"f_2757:batch_driver_scm",(void*)f_2757},
{"f_2760:batch_driver_scm",(void*)f_2760},
{"f_2763:batch_driver_scm",(void*)f_2763},
{"f_2766:batch_driver_scm",(void*)f_2766},
{"f_2076:batch_driver_scm",(void*)f_2076},
{"f_2081:batch_driver_scm",(void*)f_2081},
{"f_2084:batch_driver_scm",(void*)f_2084},
{"f_2087:batch_driver_scm",(void*)f_2087},
{"f_2090:batch_driver_scm",(void*)f_2090},
{"f_2693:batch_driver_scm",(void*)f_2693},
{"f_2696:batch_driver_scm",(void*)f_2696},
{"f_2705:batch_driver_scm",(void*)f_2705},
{"f_2734:batch_driver_scm",(void*)f_2734},
{"f_2700:batch_driver_scm",(void*)f_2700},
{"f_2093:batch_driver_scm",(void*)f_2093},
{"f_2690:batch_driver_scm",(void*)f_2690},
{"f_2686:batch_driver_scm",(void*)f_2686},
{"f_2104:batch_driver_scm",(void*)f_2104},
{"f_2107:batch_driver_scm",(void*)f_2107},
{"f_2632:batch_driver_scm",(void*)f_2632},
{"f_2672:batch_driver_scm",(void*)f_2672},
{"f_2664:batch_driver_scm",(void*)f_2664},
{"f_2635:batch_driver_scm",(void*)f_2635},
{"f_2638:batch_driver_scm",(void*)f_2638},
{"f_2643:batch_driver_scm",(void*)f_2643},
{"f_2646:batch_driver_scm",(void*)f_2646},
{"f_2649:batch_driver_scm",(void*)f_2649},
{"f_2652:batch_driver_scm",(void*)f_2652},
{"f_2655:batch_driver_scm",(void*)f_2655},
{"f_2658:batch_driver_scm",(void*)f_2658},
{"f_2661:batch_driver_scm",(void*)f_2661},
{"f_2110:batch_driver_scm",(void*)f_2110},
{"f_2602:batch_driver_scm",(void*)f_2602},
{"f_2623:batch_driver_scm",(void*)f_2623},
{"f_2626:batch_driver_scm",(void*)f_2626},
{"f_2605:batch_driver_scm",(void*)f_2605},
{"f_2608:batch_driver_scm",(void*)f_2608},
{"f_2611:batch_driver_scm",(void*)f_2611},
{"f_2614:batch_driver_scm",(void*)f_2614},
{"f_2617:batch_driver_scm",(void*)f_2617},
{"f_2113:batch_driver_scm",(void*)f_2113},
{"f_2599:batch_driver_scm",(void*)f_2599},
{"f_2116:batch_driver_scm",(void*)f_2116},
{"f_2592:batch_driver_scm",(void*)f_2592},
{"f_2119:batch_driver_scm",(void*)f_2119},
{"f_2556:batch_driver_scm",(void*)f_2556},
{"f_2585:batch_driver_scm",(void*)f_2585},
{"f_2554:batch_driver_scm",(void*)f_2554},
{"f_2499:batch_driver_scm",(void*)f_2499},
{"f_2501:batch_driver_scm",(void*)f_2501},
{"f_2539:batch_driver_scm",(void*)f_2539},
{"f_2509:batch_driver_scm",(void*)f_2509},
{"f_2536:batch_driver_scm",(void*)f_2536},
{"f_2532:batch_driver_scm",(void*)f_2532},
{"f_2513:batch_driver_scm",(void*)f_2513},
{"f_2522:batch_driver_scm",(void*)f_2522},
{"f_2525:batch_driver_scm",(void*)f_2525},
{"f_2122:batch_driver_scm",(void*)f_2122},
{"f_2125:batch_driver_scm",(void*)f_2125},
{"f_2463:batch_driver_scm",(void*)f_2463},
{"f_2481:batch_driver_scm",(void*)f_2481},
{"f_2471:batch_driver_scm",(void*)f_2471},
{"f_2475:batch_driver_scm",(void*)f_2475},
{"f_2128:batch_driver_scm",(void*)f_2128},
{"f_2134:batch_driver_scm",(void*)f_2134},
{"f_2137:batch_driver_scm",(void*)f_2137},
{"f_2140:batch_driver_scm",(void*)f_2140},
{"f_2143:batch_driver_scm",(void*)f_2143},
{"f_2146:batch_driver_scm",(void*)f_2146},
{"f_2151:batch_driver_scm",(void*)f_2151},
{"f_2155:batch_driver_scm",(void*)f_2155},
{"f_2158:batch_driver_scm",(void*)f_2158},
{"f_2414:batch_driver_scm",(void*)f_2414},
{"f_2417:batch_driver_scm",(void*)f_2417},
{"f_2161:batch_driver_scm",(void*)f_2161},
{"f_2165:batch_driver_scm",(void*)f_2165},
{"f_2168:batch_driver_scm",(void*)f_2168},
{"f_2171:batch_driver_scm",(void*)f_2171},
{"f_2263:batch_driver_scm",(void*)f_2263},
{"f_2402:batch_driver_scm",(void*)f_2402},
{"f_2266:batch_driver_scm",(void*)f_2266},
{"f_2269:batch_driver_scm",(void*)f_2269},
{"f_2272:batch_driver_scm",(void*)f_2272},
{"f_2276:batch_driver_scm",(void*)f_2276},
{"f_2279:batch_driver_scm",(void*)f_2279},
{"f_2282:batch_driver_scm",(void*)f_2282},
{"f_2396:batch_driver_scm",(void*)f_2396},
{"f_2285:batch_driver_scm",(void*)f_2285},
{"f_2288:batch_driver_scm",(void*)f_2288},
{"f_2367:batch_driver_scm",(void*)f_2367},
{"f_2370:batch_driver_scm",(void*)f_2370},
{"f_2373:batch_driver_scm",(void*)f_2373},
{"f_2376:batch_driver_scm",(void*)f_2376},
{"f_2291:batch_driver_scm",(void*)f_2291},
{"f_2294:batch_driver_scm",(void*)f_2294},
{"f_2297:batch_driver_scm",(void*)f_2297},
{"f_2308:batch_driver_scm",(void*)f_2308},
{"f_2312:batch_driver_scm",(void*)f_2312},
{"f_2315:batch_driver_scm",(void*)f_2315},
{"f_2318:batch_driver_scm",(void*)f_2318},
{"f_2321:batch_driver_scm",(void*)f_2321},
{"f_2324:batch_driver_scm",(void*)f_2324},
{"f_2327:batch_driver_scm",(void*)f_2327},
{"f_2330:batch_driver_scm",(void*)f_2330},
{"f4798:batch_driver_scm",(void*)f4798},
{"f_2349:batch_driver_scm",(void*)f_2349},
{"f_2333:batch_driver_scm",(void*)f_2333},
{"f_2336:batch_driver_scm",(void*)f_2336},
{"f_2302:batch_driver_scm",(void*)f_2302},
{"f_2177:batch_driver_scm",(void*)f_2177},
{"f_2180:batch_driver_scm",(void*)f_2180},
{"f_2191:batch_driver_scm",(void*)f_2191},
{"f_2195:batch_driver_scm",(void*)f_2195},
{"f_2198:batch_driver_scm",(void*)f_2198},
{"f_2217:batch_driver_scm",(void*)f_2217},
{"f_2231:batch_driver_scm",(void*)f_2231},
{"f_2234:batch_driver_scm",(void*)f_2234},
{"f_2237:batch_driver_scm",(void*)f_2237},
{"f_2240:batch_driver_scm",(void*)f_2240},
{"f_2243:batch_driver_scm",(void*)f_2243},
{"f_2246:batch_driver_scm",(void*)f_2246},
{"f_2185:batch_driver_scm",(void*)f_2185},
{"f_1980:batch_driver_scm",(void*)f_1980},
{"f_1973:batch_driver_scm",(void*)f_1973},
{"f_1949:batch_driver_scm",(void*)f_1949},
{"f_1623:batch_driver_scm",(void*)f_1623},
{"f_1653:batch_driver_scm",(void*)f_1653},
{"f_1648:batch_driver_scm",(void*)f_1648},
{"f_1625:batch_driver_scm",(void*)f_1625},
{"f_1629:batch_driver_scm",(void*)f_1629},
{"f_1643:batch_driver_scm",(void*)f_1643},
{"f_1637:batch_driver_scm",(void*)f_1637},
{"f_1632:batch_driver_scm",(void*)f_1632},
{"f_1594:batch_driver_scm",(void*)f_1594},
{"f_1601:batch_driver_scm",(void*)f_1601},
{"f_1604:batch_driver_scm",(void*)f_1604},
{"f_1607:batch_driver_scm",(void*)f_1607},
{"f_1621:batch_driver_scm",(void*)f_1621},
{"f_1610:batch_driver_scm",(void*)f_1610},
{"f_1584:batch_driver_scm",(void*)f_1584},
{"f_1592:batch_driver_scm",(void*)f_1592},
{"f_1549:batch_driver_scm",(void*)f_1549},
{"f_1555:batch_driver_scm",(void*)f_1555},
{"f_1563:batch_driver_scm",(void*)f_1563},
{"f_1571:batch_driver_scm",(void*)f_1571},
{"f_1575:batch_driver_scm",(void*)f_1575},
{"f_1469:batch_driver_scm",(void*)f_1469},
{"f_1538:batch_driver_scm",(void*)f_1538},
{"f_1534:batch_driver_scm",(void*)f_1534},
{"f_1518:batch_driver_scm",(void*)f_1518},
{"f_1510:batch_driver_scm",(void*)f_1510},
{"f_1479:batch_driver_scm",(void*)f_1479},
{"f_1426:batch_driver_scm",(void*)f_1426},
{"f_1433:batch_driver_scm",(void*)f_1433},
{"f_1438:batch_driver_scm",(void*)f_1438},
{"f_1450:batch_driver_scm",(void*)f_1450},
{"f_1456:batch_driver_scm",(void*)f_1456},
{"f_1402:batch_driver_scm",(void*)f_1402},
{"f_1409:batch_driver_scm",(void*)f_1409},
{"f_1412:batch_driver_scm",(void*)f_1412},
{"f_1415:batch_driver_scm",(void*)f_1415},
{"f_1418:batch_driver_scm",(void*)f_1418},
{"f_1421:batch_driver_scm",(void*)f_1421},
{"f_1380:batch_driver_scm",(void*)f_1380},
{"f_1387:batch_driver_scm",(void*)f_1387},
{"f_1400:batch_driver_scm",(void*)f_1400},
{"f_1356:batch_driver_scm",(void*)f_1356},
{"f_1360:batch_driver_scm",(void*)f_1360},
{"f_1369:batch_driver_scm",(void*)f_1369},
{"f_1372:batch_driver_scm",(void*)f_1372},
{"f_1375:batch_driver_scm",(void*)f_1375},
{"f_1378:batch_driver_scm",(void*)f_1378},
{"f_1341:batch_driver_scm",(void*)f_1341},
{"f_1348:batch_driver_scm",(void*)f_1348},
{"f_1351:batch_driver_scm",(void*)f_1351},
{"f_1233:batch_driver_scm",(void*)f_1233},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
