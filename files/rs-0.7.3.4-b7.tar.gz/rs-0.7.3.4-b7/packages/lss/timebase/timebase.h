
typedef long long timebase_t;

timebase_t read_timebase();
long timebase_diff_usec( timebase_t t1, timebase_t t0 );

