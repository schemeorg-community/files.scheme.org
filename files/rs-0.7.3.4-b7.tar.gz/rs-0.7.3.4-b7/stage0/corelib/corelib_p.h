/**********************************************
THIS FILE WAS AUTOMATICALLY GENERATED, AND MAY
BE AUTOMATICALLY RE-GENERATED WHEN THE COMPILER
OR SOURCE CHANGES.  DO NOT MODIFY THIS FILE BY HAND!
RScheme Build (v0.7.3.4-b7u, 2007-05-30)
**********************************************/


#ifndef _H_CORELIB_P
#define _H_CORELIB_P

/***************** Private Interface for Module `corelib' *****************/
#include "corelib.h"
#include <rscheme/scheme.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <rscheme/osglue.h>
#include <rscheme/allocns.h>
#include <rscheme/intrs.h>
#include <signal.h>
#include "strnnum.h"
#include "corelib_r.h"
#endif /* _H_CORELIB_P */
