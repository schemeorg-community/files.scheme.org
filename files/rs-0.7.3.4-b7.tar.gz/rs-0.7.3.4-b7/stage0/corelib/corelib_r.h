/**********************************************
THIS FILE WAS AUTOMATICALLY GENERATED, AND MAY
BE AUTOMATICALLY RE-GENERATED WHEN THE COMPILER
OR SOURCE CHANGES.  DO NOT MODIFY THIS FILE BY HAND!
RScheme Build (v0.7.3.4-b7u, 2007-05-30)
**********************************************/


#ifndef _H_CORELIB_R
#define _H_CORELIB_R

/***************** Root declarations for module `corelib' *****************/
#endif /* _H_CORELIB_R */
