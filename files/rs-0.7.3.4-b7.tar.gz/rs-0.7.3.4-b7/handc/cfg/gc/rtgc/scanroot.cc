#include <rtgc/inlines.hh>
#include <rtgc/scanroot.hh>

int abstract_root_set::stable_id;
int abstract_root_set::quasistable_id;
int abstract_root_set::unstable_id;

#ifndef INLINES
#include <rtgc/scanroot.ci>
#endif
