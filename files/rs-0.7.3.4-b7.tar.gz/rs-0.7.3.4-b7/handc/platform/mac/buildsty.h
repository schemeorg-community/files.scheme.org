/*-----------------------------------------------------------------*-C-*---
 * File:    handc/platform/mac/buildsty.h
 *
 *          Copyright (C)1997 Donovan Kolbly <d.kolbly@rscheme.org>
 *          as part of the RScheme project, licensed for free use.
 *          See <http://www.rscheme.org/> for the latest information.
 *
 * File version:     1.3
 * File mod date:    1997-11-29 23:10:47
 * System build:     v0.7.3.4-b7u, 2007-05-30
 *
 *------------------------------------------------------------------------*/

#define STACK_CACHE
#define _rs_volatile /* empty */
#define _rs_inline /* empty */
#define PLATFORM_TYPE "mac"
