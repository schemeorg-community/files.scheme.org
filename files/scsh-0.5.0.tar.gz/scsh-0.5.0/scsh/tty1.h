/* Exports from tty1.c. */

int scheme_tcgetattr(int fd,	     char *control_chars,
		     int *iflag_hi8, int *iflag_lo24,
		     int *oflag_hi8, int *oflag_lo24,
		     int *cflag_hi8, int *cflag_lo24,
		     int *lflag_hi8, int *lflag_lo24,
		     int *ispeed,    int *ospeed);

int scheme_tcsetattr(int fd,	    int option,
		     const char *control_chars,
		     int iflag_hi8, int iflag_lo24,
		     int oflag_hi8, int oflag_lo24,
		     int cflag_hi8, int cflag_lo24,
		     int lflag_hi8, int lflag_lo24,
		     int ispeed,    int ospeed,
		     int min,	    int time);

int open_ctty(const char *ttyname, int flags);

char *scm_ctermid(void);
