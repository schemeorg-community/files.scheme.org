/* Exports from stdio_dep.h. */

scheme_value char_ready_fdes(int fd);

scheme_value stream_char_readyp(FILE *f);

void setfileno(FILE *fs, int fd);

int fbufcount(FILE* fs);

int ibuf_empty(FILE *fs);

int obuf_full(FILE *fs);
