extern scheme_value scheme_time(int *hi_secs, int *lo_secs);

extern scheme_value time_plus_ticks(int *hi_secs,  int *lo_secs,
				    int *hi_ticks, int *lo_ticks);

extern scheme_value time2date(int hi_secs, int lo_secs, scheme_value zone,
			      int *sec, int *min, int *hour,
			      int *mday, int *month, int *year,
			      const char **tz_name, int *tz_secs,
			      int *summer,
			      int *wday, int *yday);

extern scheme_value date2time(int sec, int min, int hour,
			      int mday, int month, int year,
			      scheme_value tz_name, scheme_value tz_secs,
			      int summer,
			      int *hi_secs, int *lo_secs);

extern scheme_value format_date(const char *fmt, int sec, int min, int hour,
				int mday, int month, int year,
				scheme_value tz, int summer,
				int week_day, int year_day,
				const char **ans);
