/* OS-dependent support for what is supposed to be the standard ANSI C Library.
** Copyright (c) 1996 by Brian D. Carlstrom.
*/

/* Bogus hack so we don't have to add another file to the Makefile list. */
#include "fix_stdio.c"
