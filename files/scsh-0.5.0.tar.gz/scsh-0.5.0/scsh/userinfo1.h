/* Exports from userinfo1.c. */

char *my_username(void);

int user_info_uid(uid_t uid, 
		  char **name, gid_t *gid, char **dir, char **shell);

int user_info_name(const char *name,
		   uid_t *uid, gid_t *gid, char **dir, char **shell);

int group_info_gid (int gid,  char **name, char ***members, int *nmembers);

int group_info_name (const char *name,
		     int *gid, char ***members, int *nmembers);
