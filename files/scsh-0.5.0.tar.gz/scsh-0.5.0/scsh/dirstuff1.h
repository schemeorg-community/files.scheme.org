/* Exports from dirstuff1.c. */

int open_dir(const char *dirname, char ***fnames, int *len);
void scm_sort_filevec(const char **dirvec, int nelts);
