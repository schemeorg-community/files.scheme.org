/* Exports from signals1.c */

extern const int sig2int[];
extern const int max_sig;
