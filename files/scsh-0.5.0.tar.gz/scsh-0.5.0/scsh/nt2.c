fillin_date(scheme_value sec0, scheme_value min0, scheme_value hour0,
	    scheme_value mday0, scheme_value month0, scheme_value year0,
	    scheme_value tz_name0, scheme_value tz_secs0, scheme_value summer0,
	    scheme_value wday0, scheme_value yday0,

	    scheme_value *sec1, scheme_value *min1, scheme_value *hour1,
	    scheme_value *mday1, scheme_value *month1, scheme_value *year1,
	    scheme_value *tz_name1, scheme_value *tz_secs1,
	    scheme_value *summer1,
	    scheme_value *wday1, scheme_value *yday1,

	    ...)
{
    }

	    
