#undef HAVE_NLIST
#undef USCORE
