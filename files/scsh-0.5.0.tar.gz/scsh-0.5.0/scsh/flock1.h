/* Exports from flock1.c. */

int set_lock(int fd, int cmd, int type, int whence, int start, int len);
int get_lock(int fd, int cmd, int type, int whence, int start, int len,
	     int *rtype, int *rwhence, int *rstart, int *rlen, int *rpid);
