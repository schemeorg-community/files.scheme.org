/* Exports from re1.c */

char *re_byte_len(const char *re, int *len);
char *re_compile(const char *re, scheme_value target);

char *re_exec(scheme_value cr, const char *string, int start,
	      scheme_value start_vec, scheme_value end_vec,  int *hit);

char *re_match(const char *re, const char *string, int start,
	       scheme_value start_vec, scheme_value end_vec,
	       int *hit);
