/* Exports from fdports1.c. */

void init_fdports(void);

scheme_value maybe_fdes2port(int fd);

scheme_value fdport_getchar(scheme_value data);

int fdport_putchar(scheme_value data, char c);

scheme_value fdport_char_readyp(scheme_value data);

int flush_fdport(scheme_value data);

int flush_all_ports(void);

int seek_fdport(scheme_value data, off_t offset, int whence, int *newpos);

int tell_fdport( scheme_value data, int *newpos );

int set_fdbuf( scheme_value data, int policy, int bufsize );

int close_fdport(scheme_value port_data);

int install_port(int fd, scheme_value port, int revealed);

FILE *fdes2fstar(int fd);

int move_fdport(int fd, scheme_value port, int new_revealed);

void post_gc_fdports(void);

int read_fdport_substring(scheme_value buf, int start, int end, scheme_value data);

int write_fdport_substring(scheme_value buf, int start, int end, scheme_value data);

scheme_value read_delim(const char *delims, char *buf, int gobble,
			scheme_value port, int start, int end,
			int *nread);

scheme_value skip_chars(const char *skipchars, scheme_value port,  int *nread);
