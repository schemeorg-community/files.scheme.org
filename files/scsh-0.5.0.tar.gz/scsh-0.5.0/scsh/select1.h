/* Exports from select1.c. */

scheme_value select_copyback(scheme_value rvec, scheme_value wvec,
			     scheme_value evec, scheme_value nsecs,
			     int *r_numrdy, int *w_numrdy, int *e_numrdy);

scheme_value select_filter(scheme_value rvec, scheme_value wvec,
			   scheme_value evec, scheme_value nsecs,
			   int *r_numrdy, int *w_numrdy, int *e_numrdy);
