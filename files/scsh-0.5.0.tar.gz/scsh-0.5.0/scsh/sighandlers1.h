/* Exports from sighandlers1.c */

int sig2interrupt(int signal);

int set_procmask(int hi, int lo, int *old_lo_p);
int get_procmask(int *old_lo_p);

scheme_value scsh_set_sig(int sig, int handler_code, int flags,
			  int *ohc, int *oflags);
scheme_value scsh_get_sig(int signal, int *handler_code, int *flags);

void do_default_sigaction(int signal);

void install_scsh_handlers(void);

scheme_value get_int_handlers(void);
