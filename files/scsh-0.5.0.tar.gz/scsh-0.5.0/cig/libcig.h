#include "scheme48.h"

/* StobData is used by fdports.c. It should be changed over to STOB_REF
** by removing the extra indirection. */
#define StobData(x) (ADDRESS_AFTER_HEADER(x, scheme_value))

#define IsChar(x) ((((long) x) & 0xff) == SCHCHAR)

#define StrByte(x, i)  ((i) + ADDRESS_AFTER_HEADER((x), char))
#define cig_string_body(x) (ADDRESS_AFTER_HEADER((x), char))

#define AlienVal(x) (STOB_REF((x),0))

extern char *scheme2c_strcpy(scheme_value sstr);

extern scheme_value strlen_or_false(const char *s);

extern char *copystring_or_die(const char *);
extern char *copystring(char *, const char *);

extern scheme_value strlen_or_false(const char *);

extern void cig_check_nargs(int arity, int nargs, const char *fn);
