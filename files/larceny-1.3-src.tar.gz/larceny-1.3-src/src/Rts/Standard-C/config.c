/* Copyright 1998 Lars T Hansen
 *
 * $Id$
 *
 * config.c -- configuration-dependent values.
 */

#include "larceny.h"

char *larceny_system_name = "Petit Larceny";
char *larceny_heap_name = "petit.heap";
char *larceny_architecture = "Standard-C";

/* eof */
