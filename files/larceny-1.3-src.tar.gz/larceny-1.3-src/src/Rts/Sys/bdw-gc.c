/* Copyright 1998 Lars T Hansen.
 * 
 * $Id$
 *
 * Larceny run-time system -- wrapper for gc.c, with Boehm collector.
 */

#define BDW_GC
#include "gc.c"

/* eof */
