/* $Id$ 
 */

#define BDW_GC
#include "heapio.c"

/* eof */
