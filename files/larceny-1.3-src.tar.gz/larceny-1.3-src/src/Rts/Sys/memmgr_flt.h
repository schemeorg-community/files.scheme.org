/* Copyright 2010 Felix S Klock II.
 * 
 * $Id$ 
 * 
 */
void print_float_stats( char *caller_name, gc_t *gc ); /* from memmgr_flt.c */
