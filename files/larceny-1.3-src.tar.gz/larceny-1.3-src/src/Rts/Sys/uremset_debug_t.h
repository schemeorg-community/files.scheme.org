/* Copyright 2010 Felix S Klock II.              -*- indent-tabs-mode: nil -*-
 *
 * $Id$
 *
 */

#ifndef INCLUDED_UREMSET_DEBUG_T_H
#define INCLUDED_UREMSET_DEBUG_T_H

uremset_t *alloc_uremset_debug( uremset_t *backing_urs );

#endif /* INCLUDED_UREMSET_DEBUG_T_H */
