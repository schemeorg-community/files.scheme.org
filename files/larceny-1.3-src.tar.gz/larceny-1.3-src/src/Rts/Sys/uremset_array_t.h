/* Copyright 2009 Felix S Klock II.              -*- indent-tabs-mode: nil -*-
 *
 * $Id$
 *
 */

#ifndef INCLUDED_UREMSET_ARRAY_T_H
#define INCLUDED_UREMSET_ARRAY_T_H

uremset_t *alloc_uremset_array( gc_t *gc, gc_param_t *info );

#endif /* INCLUDED_UREMSET_ARRAY_T_H */
