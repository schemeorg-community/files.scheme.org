/* Copyright 1998 Lars T Hansen.
 * 
 * $Id$
 *
 * Larceny run-time system -- wrapper for ffi.c, with Boehm collector.
 */

#define BDW_GC
#include "ffi.c"

/* eof */
