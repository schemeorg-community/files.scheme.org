/* Copyright 1998 Lars T Hansen.
 * 
 * $Id$
 *
 * Wrapper for Sparc/cglue.c, with Boehm collector.
 */

#define BDW_GC
#include "cglue.c"

/* eof */
