./mosh work.scm 2>&1|grep who |cut -d ':' -f2
