/*
 * ProcedureMacro.h - 
 *
 *   Copyright (c) 2008  Higepon(Taro Minowa)  <higepon@users.sourceforge.jp>
 *
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 *
 *   1. Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 *   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 *   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  $Id: ProcedureMacro.h 261 2008-07-25 06:16:44Z higepon $
 */

#ifndef __SCHEME_PROCEDURE_MACRO__
#define __SCHEME_PROCEDURE_MACRO__

#include "scheme.h"
#include "ErrorProcedures.h"
#include "VM.h"

#define checkType(index, variableName, pred, required) \
    const Object variableName = argv[index]; \
    if (!variableName.pred()) { \
        callWrongTypeOfArgumentViolationAfter(procedureName, #required, variableName); \
        return Object::Undef; \
    } \

#define castArgument(index, variableName, pred, required, type, castFunction)    \
    const Object obj ## variableName = argv[index]; \
    if (!obj ## variableName.pred()) { \
        callWrongTypeOfArgumentViolationAfter(procedureName, #required, obj ## variableName); \
        return Object::Undef; \
    } \
    type variableName = obj ## variableName.castFunction();


#define checkTypeOrFalse(index, variableName, pred, required) \
    const Object variableName = argv[index]; \
    if (!variableName.pred() && !variableName.isFalse()) { \
        callWrongTypeOfArgumentViolationAfter(procedureName, #required " or #f", variableName); \
        return Object::Undef; \
    } \

#define checkTypeOr(index, variableName, pred1, pred2, required1, required2)  \
    const Object variableName = argv[index]; \
    if (!variableName.pred1() && !variableName.pred2()) { \
        callWrongTypeOfArgumentViolationAfter(procedureName, #required1 " or " #required2, variableName); \
        printf("%s %s:%d\n", __func__, __FILE__, __LINE__);fflush(stdout);\
        return Object::Undef; \
    } \

#define argumentCheckList(index, variableName) checkTypeOr(index, variableName, isPair, isNil, pair, ())
#define argumentAsSymbol(index, variableName) castArgument(index, variableName, isSymbol, symbol, Symbol*, toSymbol)
#define argumentAsVector(index, variableName) castArgument(index, variableName, isVector, vector, Vector*, toVector)
#define argumentAsCodeBuilder(index, variableName) castArgument(index, variableName, isCodeBuilder, code-builder, CodeBuilder*, toCodeBuilder)


#define argumentAsInt(index, variableName) castArgument(index, variableName, isInt, number, int, toInt)
#define argumentAsHashTable(index, variableName) castArgument(index, variableName, isHashTable, hashtable, HashTable*, toHashTable)
#define argumentCheckInt(index, variableName) checkType(index, variableName, isInt, number)
#define argumentAsRecord(index, variableName) castArgument(index, variableName, isRecord, record, Record*, toRecord)
#define argumentCheckRecord(index, variableName) checkType(index, variableName, isRecord, record)

#define argumentCheckProcedure(index, variableName) checkType(index, variableName, isProcedure, procedure)

#define argumentCheckVector(index, variableName) checkType(index, variableName, isVector, vector)

#define argumentCheckString(index, variableName) checkType(index, variableName, isString, string)
#define argumentCheckSymbol(index, variableName) checkType(index, variableName, isSymbol, symbol)
#define argumentCheckSymbolOrFalse(index, variableName) checkTypeOrFalse(index, variableName, isSymbol, symbol)
#define argumentCheckRecordOrCompoundConditon(index, variableName) checkTypeOr(index, variableName, isRecord, isCompoundCondition, symbol, compound-condition)

#define argumentCheckBoolean(index, variableName) checkType(index, variableName, isBoolean, boolean)
#define argumentCheckClosure(index, variableName) checkType(index, variableName, isClosure, closure)
#define argumentCheckClosureOrFalse(index, variableName) checkTypeOrFalse(index, variableName, isClosure, closure)
#define argumentCheckRecordTypeDescriptorOrFalse(index, variableName) checkTypeOrFalse(index, variableName, isRecordTypeDescriptor, record-type-descriptor)

#define argumentCheckRecordTypeDescriptor(index, variableName) checkType(index, variableName, isRecordTypeDescriptor, record-type-descriptor)
#define argumentAsRecordTypeDescriptor(index, variableName) castArgument(index, variableName, isRecordTypeDescriptor, record-type-descriptor, RecordTypeDescriptor*, toRecordTypeDescriptor)

#define argumentAsRecordConstructorDescriptor(index, variableName) castArgument(index, variableName, isRecordConstructorDescriptor, record-constructor-descriptor, RecordConstructorDescriptor*, toRecordConstructorDescriptor)
#define argumentCheckRecordConstructorDescriptor(index, variableName) checkType(index, variableName, isRecordConstructorDescriptor, record-constructor-descriptor)
#define argumentCheckRecordConstructorDescriptorOrFalse(index, variableName) checkTypeOrFalse(index, variableName, isRecordConstructorDescriptor, record-constructor-descriptor)

#define argumentCheckPair(index, variableName) checkType(index, variableName, isPair, pair)

#define argumentAsTextualOutputPort(index, variableName) castArgument(index, variableName, isTextualOutputPort, textual-output-port, TextualOutputPort*, toTextualOutputPort)

#define argumentAsRegexp(index, variableName) castArgument(index, variableName, isRegexp, regexp, Regexp*, toRegexp)
#define argumentAsRegMatch(index, variableName) castArgument(index, variableName, isRegMatch, regexp, RegMatch*, toRegMatch)
#define argumentAsString(index, variableName) castArgument(index, variableName, isString, regexp, String*, toString)


#define argumentAsChar(index, variableName) castArgument(index, variableName, isChar, charcter, ucs4char, toChar)

#define argumentCheckProcedure(index, variableName) checkType(index, variableName, isProcedure, procedure)
#define argumentCheckProcedureOrFalse(index, variableName) checkTypeOrFalse(index, variableName, isProcedure, procedure)
#define argumentAsBinaryInputPort(index, variableName) castArgument(index, variableName, isBinaryInputPort, binary-input-port, BinaryInputPort*, toBinaryInputPort)
#define argumentAsByteVector(index, variableName) castArgument(index, variableName, isByteVector, bytevector, ByteVector*, toByteVector)
#define argumentAsTranscoder(index, variableName) castArgument(index, variableName, isTranscoder, transcoder, Transcoder*, toTranscoder)
#define argumentAsCodec(index, variableName) castArgument(index, variableName, isCodec, codec, Codec*, toCodec)
#define argumentCheckTextualInputPort(index, variableName) checkType(index, variableName, isTextualInputPort, textual-input-port)
#define argumentCheckTextualOutputPort(index, variableName) checkType(index, variableName, isTextualOutputPort, textual-output-port)


#define DeclareProcedureName(name) const ucs4char* procedureName = UC(name);

#define checkArgumentLength(required)   \
    if (argc != required) { \
        callWrongNumberOfArgumentsViolationAfter(procedureName, required, argc); \
        return Object::Undef;\
    } \

#define checkArgumentLengthBetween(start, end)             \
    if (argc < start || argc > end) { \
        callWrongNumberOfArgumentsBetweenViolationAfter(procedureName, start, end, argc); \
        return Object::Undef;\
    } \

#define argumentAsTextualInputPort(index, variableName) castArgument(index, variableName, isTextualInputPort, textual-input-port, TextualInputPort*, toTextualInputPort)

#define checkArgumentLengthAtLeast(required)             \
    if (argc < required) { \
        callWrongNumberOfArgumentsAtLeastViolationAfter(procedureName, required, argc); \
        return Object::Undef;\
    } \

extern scheme::VM* theVM;

#endif // __SCHEME_PROCEDURE_MACRO__
