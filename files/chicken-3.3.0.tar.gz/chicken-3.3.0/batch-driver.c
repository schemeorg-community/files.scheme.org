/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-06-28 12:10
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10664	compiled 2008-06-28 on galinha (Linux)
   command line: batch-driver.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[346];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_425)
static void C_ccall f_425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_428)
static void C_ccall f_428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_431)
static void C_ccall f_431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_434)
static void C_ccall f_434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_437)
static void C_ccall f_437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_479)
static void C_ccall f_479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_fcall f_2458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_495)
static void C_ccall f_495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_504)
static void C_fcall f_504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_892)
static void C_fcall f_892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_896)
static void C_ccall f_896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_903)
static void C_fcall f_903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_906)
static void C_fcall f_906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_909)
static void C_ccall f_909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_912)
static void C_fcall f_912(C_word t0,C_word t1) C_noret;
C_noret_decl(f_918)
static void C_fcall f_918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_921)
static void C_fcall f_921(C_word t0,C_word t1) C_noret;
C_noret_decl(f_924)
static void C_fcall f_924(C_word t0,C_word t1) C_noret;
C_noret_decl(f_931)
static void C_ccall f_931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_938)
static void C_ccall f_938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_941)
static void C_fcall f_941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_944)
static void C_fcall f_944(C_word t0,C_word t1) C_noret;
C_noret_decl(f_947)
static void C_ccall f_947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_950)
static void C_fcall f_950(C_word t0,C_word t1) C_noret;
C_noret_decl(f_953)
static void C_fcall f_953(C_word t0,C_word t1) C_noret;
C_noret_decl(f_956)
static void C_fcall f_956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_fcall f_959(C_word t0,C_word t1) C_noret;
C_noret_decl(f_962)
static void C_fcall f_962(C_word t0,C_word t1) C_noret;
C_noret_decl(f_965)
static void C_fcall f_965(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_971)
static void C_fcall f_971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_993)
static void C_ccall f_993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_996)
static void C_fcall f_996(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_fcall f_1038(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static void C_fcall f_1048(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1056)
static void C_ccall f_1056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1082)
static void C_fcall f_1082(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1109)
static void C_fcall f_1109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1170)
static void C_ccall f_1170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1176)
static void C_ccall f_1176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_fcall f_1823(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_fcall f_1881(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1188)
static void C_fcall f_1188(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_fcall f_1197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_fcall f_1689(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_ccall f_1674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1215)
static void C_ccall f_1215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1250)
static void C_ccall f_1250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1256)
static void C_fcall f_1256(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1556)
static void C_ccall f_1556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1259)
static void C_fcall f_1259(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1265)
static void C_ccall f_1265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_fcall f_1282(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1289)
static void C_ccall f_1289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static void C_ccall f_1520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1292)
static void C_ccall f_1292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1296)
static void C_ccall f_1296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1299)
static void C_ccall f_1299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1400)
static void C_ccall f_1400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_fcall f_1497(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1412)
static void C_ccall f_1412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1432)
static void C_ccall f_1432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1308)
static void C_ccall f_1308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_ccall f_1322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1374)
static void C_ccall f_1374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_813)
static void C_fcall f_813(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_843)
static void C_fcall f_843(C_word t0,C_word t1) C_noret;
C_noret_decl(f_838)
static void C_fcall f_838(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_815)
static void C_fcall f_815(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_819)
static void C_ccall f_819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_833)
static void C_ccall f_833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_827)
static void C_ccall f_827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_822)
static void C_ccall f_822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_807)
static void C_fcall f_807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_790)
static void C_fcall f_790(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_780)
static C_word C_fcall f_780(C_word t0);
C_noret_decl(f_750)
static void C_fcall f_750(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_756)
static void C_fcall f_756(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_770)
static void C_ccall f_770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_774)
static void C_ccall f_774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_670)
static void C_fcall f_670(C_word t0,C_word t1) C_noret;
C_noret_decl(f_739)
static void C_ccall f_739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_735)
static void C_ccall f_735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_719)
static void C_ccall f_719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_711)
static void C_ccall f_711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_680)
static void C_ccall f_680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_621)
static void C_ccall f_621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_667)
static void C_ccall f_667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_625)
static void C_ccall f_625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_631)
static void C_fcall f_631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_646)
static void C_ccall f_646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_642)
static void C_ccall f_642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_628)
static void C_ccall f_628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_609)
static void C_fcall f_609(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_616)
static void C_ccall f_616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_594)
static void C_fcall f_594(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_601)
static void C_ccall f_601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_604)
static void C_ccall f_604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_572)
static void C_fcall f_572(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_579)
static void C_ccall f_579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_592)
static void C_ccall f_592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_554)
static void C_fcall f_554(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_558)
static void C_ccall f_558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_567)
static void C_ccall f_567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_548)
static C_word C_fcall f_548();
C_noret_decl(f_446)
static void C_fcall f_446(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2458)
static void C_fcall trf_2458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2458(t0,t1);}

C_noret_decl(trf_504)
static void C_fcall trf_504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_504(t0,t1);}

C_noret_decl(trf_892)
static void C_fcall trf_892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_892(t0,t1);}

C_noret_decl(trf_903)
static void C_fcall trf_903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_903(t0,t1);}

C_noret_decl(trf_906)
static void C_fcall trf_906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_906(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_906(t0,t1);}

C_noret_decl(trf_912)
static void C_fcall trf_912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_912(t0,t1);}

C_noret_decl(trf_918)
static void C_fcall trf_918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_918(t0,t1);}

C_noret_decl(trf_921)
static void C_fcall trf_921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_921(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_921(t0,t1);}

C_noret_decl(trf_924)
static void C_fcall trf_924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_924(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_924(t0,t1);}

C_noret_decl(trf_941)
static void C_fcall trf_941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_941(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_941(t0,t1);}

C_noret_decl(trf_944)
static void C_fcall trf_944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_944(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_944(t0,t1);}

C_noret_decl(trf_950)
static void C_fcall trf_950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_950(t0,t1);}

C_noret_decl(trf_953)
static void C_fcall trf_953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_953(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_953(t0,t1);}

C_noret_decl(trf_956)
static void C_fcall trf_956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_956(t0,t1);}

C_noret_decl(trf_959)
static void C_fcall trf_959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_959(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_959(t0,t1);}

C_noret_decl(trf_962)
static void C_fcall trf_962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_962(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_962(t0,t1);}

C_noret_decl(trf_965)
static void C_fcall trf_965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_965(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_965(t0,t1);}

C_noret_decl(trf_971)
static void C_fcall trf_971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_971(t0,t1);}

C_noret_decl(trf_996)
static void C_fcall trf_996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_996(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_996(t0,t1);}

C_noret_decl(trf_1038)
static void C_fcall trf_1038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1038(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1038(t0,t1);}

C_noret_decl(trf_1048)
static void C_fcall trf_1048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1048(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1048(t0,t1);}

C_noret_decl(trf_1082)
static void C_fcall trf_1082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1082(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1082(t0,t1);}

C_noret_decl(trf_1109)
static void C_fcall trf_1109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1109(t0,t1);}

C_noret_decl(trf_1823)
static void C_fcall trf_1823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1823(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1823(t0,t1,t2);}

C_noret_decl(trf_1881)
static void C_fcall trf_1881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1881(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1881(t0,t1,t2);}

C_noret_decl(trf_1188)
static void C_fcall trf_1188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1188(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1188(t0,t1);}

C_noret_decl(trf_1197)
static void C_fcall trf_1197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1197(t0,t1);}

C_noret_decl(trf_1689)
static void C_fcall trf_1689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1689(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1689(t0,t1);}

C_noret_decl(trf_1256)
static void C_fcall trf_1256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1256(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1256(t0,t1);}

C_noret_decl(trf_1259)
static void C_fcall trf_1259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1259(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1259(t0,t1);}

C_noret_decl(trf_1282)
static void C_fcall trf_1282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1282(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1282(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1497)
static void C_fcall trf_1497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1497(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1497(t0,t1);}

C_noret_decl(trf_813)
static void C_fcall trf_813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_813(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_813(t0,t1,t2,t3,t4);}

C_noret_decl(trf_843)
static void C_fcall trf_843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_843(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_843(t0,t1);}

C_noret_decl(trf_838)
static void C_fcall trf_838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_838(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_838(t0,t1,t2);}

C_noret_decl(trf_815)
static void C_fcall trf_815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_815(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_815(t0,t1,t2,t3);}

C_noret_decl(trf_807)
static void C_fcall trf_807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_807(t0,t1,t2);}

C_noret_decl(trf_790)
static void C_fcall trf_790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_790(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_790(t0,t1,t2);}

C_noret_decl(trf_750)
static void C_fcall trf_750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_750(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_750(t0,t1,t2);}

C_noret_decl(trf_756)
static void C_fcall trf_756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_756(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_756(t0,t1,t2);}

C_noret_decl(trf_670)
static void C_fcall trf_670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_670(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_670(t0,t1);}

C_noret_decl(trf_631)
static void C_fcall trf_631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_631(t0,t1);}

C_noret_decl(trf_609)
static void C_fcall trf_609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_609(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_609(t0,t1,t2,t3,t4);}

C_noret_decl(trf_594)
static void C_fcall trf_594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_594(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_594(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_572)
static void C_fcall trf_572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_572(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_572(t0,t1,t2,t3,t4);}

C_noret_decl(trf_554)
static void C_fcall trf_554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_554(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_554(t0,t1,t2,t3);}

C_noret_decl(trf_446)
static void C_fcall trf_446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_446(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2660)){
C_save(t1);
C_rereclaim2(2660*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,346);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[5]=C_h_intern(&lf[5],19,"compile-source-file");
lf[6]=C_h_intern(&lf[6],4,"quit");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[9]=C_h_intern(&lf[9],12,"explicit-use");
lf[10]=C_h_intern(&lf[10],26,"\010compilerexplicit-use-flag");
lf[11]=C_h_intern(&lf[11],12,"\004coredeclare");
lf[12]=C_h_intern(&lf[12],7,"verbose");
lf[13]=C_h_intern(&lf[13],11,"output-file");
lf[14]=C_h_intern(&lf[14],36,"\010compilerdefault-optimization-passes");
lf[15]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[16]=C_h_intern(&lf[16],7,"profile");
lf[17]=C_h_intern(&lf[17],12,"profile-name");
lf[18]=C_h_intern(&lf[18],9,"heap-size");
lf[19]=C_h_intern(&lf[19],17,"heap-initial-size");
lf[20]=C_h_intern(&lf[20],11,"heap-growth");
lf[21]=C_h_intern(&lf[21],14,"heap-shrinkage");
lf[22]=C_h_intern(&lf[22],13,"keyword-style");
lf[23]=C_h_intern(&lf[23],4,"unit");
lf[24]=C_h_intern(&lf[24],12,"analyze-only");
lf[25]=C_h_intern(&lf[25],7,"dynamic");
lf[26]=C_h_intern(&lf[26],5,"quiet");
lf[27]=C_h_intern(&lf[27],7,"nursery");
lf[28]=C_h_intern(&lf[28],10,"stack-size");
lf[29]=C_h_intern(&lf[29],26,"\010compilerdebugging-chicken");
lf[30]=C_h_intern(&lf[30],6,"printf");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\006[~a]~%");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\014pass: ~a~%~!");
lf[33]=C_h_intern(&lf[33],19,"\010compilerdump-nodes");
lf[34]=C_h_intern(&lf[34],12,"pretty-print");
lf[35]=C_h_intern(&lf[35],30,"\010compilerbuild-expression-tree");
lf[36]=C_h_intern(&lf[36],34,"\010compilerdisplay-analysis-database");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\020(iteration ~s)~%");
lf[38]=C_h_intern(&lf[38],12,"\003sysfor-each");
lf[39]=C_h_intern(&lf[39],19,"\003syshash-table-set!");
lf[40]=C_h_intern(&lf[40],24,"\003sysline-number-database");
lf[41]=C_h_intern(&lf[41],10,"alist-cons");
lf[42]=C_h_intern(&lf[42],18,"\003syshash-table-ref");
lf[43]=C_h_intern(&lf[43],9,"list-info");
lf[44]=C_h_intern(&lf[44],26,"\003sysdefault-read-info-hook");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[46]=C_h_intern(&lf[46],9,"substring");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000!milliseconds needed for ~a: \011~s~%");
lf[48]=C_h_intern(&lf[48],8,"\003sysread");
lf[49]=C_h_intern(&lf[49],12,"\010compilerget");
lf[50]=C_h_intern(&lf[50],13,"\010compilerput!");
lf[51]=C_h_intern(&lf[51],27,"\010compileranalyze-expression");
lf[52]=C_h_intern(&lf[52],9,"\003syserror");
lf[53]=C_h_intern(&lf[53],1,"D");
lf[54]=C_h_intern(&lf[54],12,"emit-exports");
lf[55]=C_h_intern(&lf[55],13,"check-imports");
lf[56]=C_h_intern(&lf[56],25,"\010compileruse-import-table");
lf[57]=C_h_intern(&lf[57],26,"\010compilerdisabled-warnings");
lf[58]=C_h_intern(&lf[58],12,"inline-limit");
lf[59]=C_h_intern(&lf[59],21,"\010compilerverbose-mode");
lf[60]=C_h_intern(&lf[60],31,"\003sysread-error-with-line-number");
lf[61]=C_h_intern(&lf[61],21,"\003sysinclude-pathnames");
lf[62]=C_h_intern(&lf[62],19,"\000compiler-extension");
lf[63]=C_h_intern(&lf[63],12,"\003sysfeatures");
lf[64]=C_h_intern(&lf[64],10,"\000compiling");
lf[65]=C_h_intern(&lf[65],6,"\000match");
lf[66]=C_h_intern(&lf[66],25,"\010compilertarget-heap-size");
lf[67]=C_h_intern(&lf[67],33,"\010compilertarget-initial-heap-size");
lf[68]=C_h_intern(&lf[68],27,"\010compilertarget-heap-growth");
lf[69]=C_h_intern(&lf[69],30,"\010compilertarget-heap-shrinkage");
lf[70]=C_h_intern(&lf[70],26,"\010compilertarget-stack-size");
lf[71]=C_h_intern(&lf[71],8,"no-trace");
lf[72]=C_h_intern(&lf[72],24,"\010compileremit-trace-info");
lf[73]=C_h_intern(&lf[73],29,"disable-stack-overflow-checks");
lf[74]=C_h_intern(&lf[74],40,"\010compilerdisable-stack-overflow-checking");
lf[75]=C_h_intern(&lf[75],7,"version");
lf[76]=C_h_intern(&lf[76],7,"newline");
lf[77]=C_h_intern(&lf[77],22,"\010compilerprint-version");
lf[78]=C_h_intern(&lf[78],4,"help");
lf[79]=C_h_intern(&lf[79],20,"\010compilerprint-usage");
lf[80]=C_h_intern(&lf[80],7,"release");
lf[81]=C_h_intern(&lf[81],7,"display");
lf[82]=C_h_intern(&lf[82],15,"chicken-version");
lf[83]=C_h_intern(&lf[83],24,"\010compilersource-filename");
lf[84]=C_h_intern(&lf[84],28,"\010compilerprofile-lambda-list");
lf[85]=C_h_intern(&lf[85],31,"\010compilerline-number-database-2");
lf[86]=C_h_intern(&lf[86],4,"node");
lf[87]=C_h_intern(&lf[87],6,"lambda");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[89]=C_h_intern(&lf[89],23,"\010compilerconstant-table");
lf[90]=C_h_intern(&lf[90],21,"\010compilerinline-table");
lf[91]=C_h_intern(&lf[91],23,"\010compilerfirst-analysis");
lf[92]=C_h_intern(&lf[92],41,"\010compilerperform-high-level-optimizations");
lf[93]=C_h_intern(&lf[93],37,"\010compilerinline-substitutions-enabled");
lf[94]=C_h_intern(&lf[94],22,"optimize-leaf-routines");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[96]=C_h_intern(&lf[96],34,"\010compilertransform-direct-lambdas!");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[98]=C_h_intern(&lf[98],4,"leaf");
lf[99]=C_h_intern(&lf[99],18,"\010compilerdebugging");
lf[100]=C_h_intern(&lf[100],1,"p");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[103]=C_h_intern(&lf[103],1,"5");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[106]=C_h_intern(&lf[106],36,"\010compilerprepare-for-code-generation");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\031compilation finished.~%~!");
lf[108]=C_h_intern(&lf[108],30,"\010compilercompiler-cleanup-hook");
lf[109]=C_h_intern(&lf[109],1,"t");
lf[110]=C_h_intern(&lf[110],17,"\003sysdisplay-times");
lf[111]=C_h_intern(&lf[111],14,"\003sysstop-timer");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[113]=C_h_intern(&lf[113],17,"close-output-port");
lf[114]=C_h_intern(&lf[114],22,"\010compilergenerate-code");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\025generating `~A\047 ...~%");
lf[116]=C_h_intern(&lf[116],16,"open-output-file");
lf[117]=C_h_intern(&lf[117],19,"current-output-port");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[120]=C_h_intern(&lf[120],1,"9");
lf[121]=C_h_intern(&lf[121],4,"exit");
lf[122]=C_h_intern(&lf[122],25,"\010compilerexport-file-name");
lf[123]=C_h_intern(&lf[123],30,"\010compilerdump-exported-globals");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000$(do not worry - still compiling...)\012");
lf[125]=C_h_intern(&lf[125],20,"\003syswarnings-enabled");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[127]=C_h_intern(&lf[127],1,"8");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[129]=C_h_intern(&lf[129],35,"\010compilerperform-closure-conversion");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[131]=C_h_intern(&lf[131],1,"7");
lf[132]=C_h_intern(&lf[132],1,"s");
lf[133]=C_h_intern(&lf[133],33,"\010compilerprint-program-statistics");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[135]=C_h_intern(&lf[135],1,"4");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[137]=C_h_intern(&lf[137],1,"u");
lf[138]=C_h_intern(&lf[138],31,"\010compilerdump-undefined-globals");
lf[139]=C_h_intern(&lf[139],29,"\010compilercheck-global-exports");
lf[140]=C_h_intern(&lf[140],29,"\010compilercheck-global-imports");
lf[141]=C_h_intern(&lf[141],3,"opt");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[143]=C_h_intern(&lf[143],1,"3");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[145]=C_h_intern(&lf[145],31,"\010compilerperform-cps-conversion");
lf[146]=C_h_intern(&lf[146],6,"unsafe");
lf[147]=C_h_intern(&lf[147],34,"\010compilerscan-toplevel-assignments");
lf[148]=C_h_intern(&lf[148],26,"\010compilerdo-lambda-lifting");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[150]=C_h_intern(&lf[150],1,"L");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[152]=C_h_intern(&lf[152],32,"\010compilerperform-lambda-lifting!");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[155]=C_h_intern(&lf[155],1,"0");
lf[156]=C_h_intern(&lf[156],4,"lift");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[158]=C_h_intern(&lf[158],1,"U");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\020pre-analysis (u)");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\014analysis (u)");
lf[162]=C_h_intern(&lf[162],4,"user");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\030Secondary user pass...~%");
lf[164]=C_h_intern(&lf[164],21,"\003syshash-table->alist");
lf[165]=C_h_intern(&lf[165],26,"\010compilerfile-requirements");
lf[166]=C_h_intern(&lf[166],1,"M");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[168]=C_h_intern(&lf[168],11,"user-pass-2");
lf[169]=C_h_intern(&lf[169],25,"\010compilerbuild-node-graph");
lf[170]=C_h_intern(&lf[170],32,"\010compilercanonicalize-begin-body");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[172]=C_h_intern(&lf[172],7,"\003sysmap");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\020User pass...~%~!");
lf[174]=C_h_intern(&lf[174],9,"user-pass");
lf[175]=C_h_intern(&lf[175],12,"check-syntax");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[177]=C_h_intern(&lf[177],1,"2");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[179]=C_h_intern(&lf[179],25,"\010compilercompiler-warning");
lf[180]=C_h_intern(&lf[180],5,"style");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000ycompiling extensions in unsafe mode is bad practice and should be avoided a"
"s it may be surprising to an unsuspecting user");
lf[182]=C_h_intern(&lf[182],8,"feature\077");
lf[183]=C_h_intern(&lf[183],19,"compiling-extension");
lf[184]=C_h_intern(&lf[184],18,"\010compilerunit-name");
lf[185]=C_h_intern(&lf[185],5,"usage");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[187]=C_h_intern(&lf[187],26,"\010compilerblock-compilation");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000`compilation of library unit `~a\047 in block-mode - globals may not be accessi"
"ble outside this unit");
lf[189]=C_h_intern(&lf[189],37,"\010compilerdisplay-line-number-database");
lf[190]=C_h_intern(&lf[190],1,"n");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[192]=C_h_intern(&lf[192],32,"\010compilerdisplay-real-name-table");
lf[193]=C_h_intern(&lf[193],1,"N");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[195]=C_h_intern(&lf[195],6,"append");
lf[196]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[197]=C_h_intern(&lf[197],5,"quote");
lf[198]=C_h_intern(&lf[198],28,"\003sysset-profile-info-vector!");
lf[199]=C_h_intern(&lf[199],33,"\010compilerprofile-info-vector-name");
lf[200]=C_h_intern(&lf[200],21,"\010compileremit-profile");
lf[201]=C_h_intern(&lf[201],25,"\003sysregister-profile-info");
lf[202]=C_h_intern(&lf[202],4,"set!");
lf[203]=C_h_intern(&lf[203],13,"\004corecallunit");
lf[204]=C_h_intern(&lf[204],19,"\010compilerused-units");
lf[205]=C_h_intern(&lf[205],28,"\010compilerimmutable-constants");
lf[206]=C_h_intern(&lf[206],6,"gensym");
lf[207]=C_h_intern(&lf[207],32,"\010compilercanonicalize-expression");
lf[208]=C_h_intern(&lf[208],28,"\003sysexplicit-library-modules");
lf[209]=C_h_intern(&lf[209],4,"uses");
lf[210]=C_h_intern(&lf[210],7,"declare");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[212]=C_h_intern(&lf[212],1,"1");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\036User preprocessing pass...~%~!");
lf[214]=C_h_intern(&lf[214],22,"user-preprocessor-pass");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\025User read pass...~%~!");
lf[216]=C_h_intern(&lf[216],21,"\010compilerstring->expr");
lf[217]=C_h_intern(&lf[217],7,"reverse");
lf[218]=C_h_intern(&lf[218],27,"\003syscurrent-source-filename");
lf[219]=C_h_intern(&lf[219],33,"\010compilerclose-checked-input-file");
lf[220]=C_h_intern(&lf[220],16,"\003sysdynamic-wind");
lf[221]=C_h_intern(&lf[221],34,"\010compilercheck-and-open-input-file");
lf[222]=C_h_intern(&lf[222],14,"user-read-pass");
lf[223]=C_h_intern(&lf[223],8,"epilogue");
lf[224]=C_h_intern(&lf[224],8,"prologue");
lf[225]=C_h_intern(&lf[225],8,"postlude");
lf[226]=C_h_intern(&lf[226],7,"prelude");
lf[227]=C_h_intern(&lf[227],11,"make-vector");
lf[228]=C_h_intern(&lf[228],34,"\010compilerline-number-database-size");
lf[229]=C_h_intern(&lf[229],1,"r");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\024compiling `~a\047 ...~%");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[236]=C_h_intern(&lf[236],5,"-help");
lf[237]=C_h_intern(&lf[237],1,"h");
lf[238]=C_h_intern(&lf[238],2,"-h");
lf[239]=C_h_intern(&lf[239],18,"accumulate-profile");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\030Generating ~aprofile~%~!");
lf[243]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[244]=C_h_intern(&lf[244],39,"\010compilerdefault-profiling-declarations");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\012stacktrace");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\026debugging info: ~A~%~!");
lf[248]=C_h_intern(&lf[248],21,"no-usual-integrations");
lf[249]=C_h_intern(&lf[249],17,"standard-bindings");
lf[250]=C_h_intern(&lf[250],34,"\010compilerdefault-standard-bindings");
lf[251]=C_h_intern(&lf[251],17,"extended-bindings");
lf[252]=C_h_intern(&lf[252],34,"\010compilerdefault-extended-bindings");
lf[253]=C_h_intern(&lf[253],1,"m");
lf[254]=C_h_intern(&lf[254],14,"set-gc-report!");
lf[255]=C_h_intern(&lf[255],42,"\010compilerdefault-default-target-stack-size");
lf[256]=C_h_intern(&lf[256],41,"\010compilerdefault-default-target-heap-size");
lf[257]=C_h_intern(&lf[257],15,"run-time-macros");
lf[258]=C_h_intern(&lf[258],25,"\003sysenable-runtime-macros");
lf[259]=C_h_intern(&lf[259],22,"\004corerequire-extension");
lf[260]=C_h_intern(&lf[260],15,"lset-difference");
lf[261]=C_h_intern(&lf[261],3,"eq\077");
lf[262]=C_h_intern(&lf[262],14,"string->symbol");
lf[263]=C_h_intern(&lf[263],12,"string-split");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[265]=C_h_intern(&lf[265],10,"append-map");
lf[266]=C_h_intern(&lf[266],17,"require-extension");
lf[267]=C_h_intern(&lf[267],9,"extension");
lf[268]=C_h_intern(&lf[268],16,"define-extension");
lf[269]=C_h_intern(&lf[269],13,"pathname-file");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000-no filename available for `-extension\047 option");
lf[271]=C_h_intern(&lf[271],28,"\010compilerpostponed-initforms");
lf[272]=C_h_intern(&lf[272],23,"user-post-analysis-pass");
lf[273]=C_h_intern(&lf[273],11,"\003sysprovide");
lf[274]=C_h_intern(&lf[274],5,"match");
lf[275]=C_h_intern(&lf[275],6,"delete");
lf[276]=C_h_intern(&lf[276],4,"load");
lf[277]=C_h_intern(&lf[277],28,"\003sysresolve-include-filename");
lf[278]=C_h_intern(&lf[278],12,"load-verbose");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\042Loading compiler extensions...~%~!");
lf[280]=C_h_intern(&lf[280],6,"extend");
lf[281]=C_h_intern(&lf[281],17,"register-feature!");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[283]=C_h_intern(&lf[283],7,"feature");
lf[284]=C_h_intern(&lf[284],20,"keep-shadowed-macros");
lf[285]=C_h_intern(&lf[285],33,"\010compilerundefine-shadowed-macros");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[288]=C_h_intern(&lf[288],23,"\010compilerchop-separator");
lf[289]=C_h_intern(&lf[289],12,"include-path");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[291]=C_h_intern(&lf[291],7,"\000prefix");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[293]=C_h_intern(&lf[293],5,"\000none");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[295]=C_h_intern(&lf[295],7,"\000suffix");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[297]=C_h_intern(&lf[297],17,"compress-literals");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[299]=C_h_intern(&lf[299],16,"case-insensitive");
lf[300]=C_h_intern(&lf[300],14,"case-sensitive");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\0000Identifiers and symbols are case insensitive~%~!");
lf[302]=C_h_intern(&lf[302],24,"\010compilerinline-max-size");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[304]=C_h_intern(&lf[304],6,"inline");
lf[305]=C_h_intern(&lf[305],30,"emit-external-prototypes-first");
lf[306]=C_h_intern(&lf[306],30,"\010compilerexternal-protos-first");
lf[307]=C_h_intern(&lf[307],5,"block");
lf[308]=C_h_intern(&lf[308],17,"fixnum-arithmetic");
lf[309]=C_h_intern(&lf[309],11,"number-type");
lf[310]=C_h_intern(&lf[310],6,"fixnum");
lf[311]=C_h_intern(&lf[311],18,"disable-interrupts");
lf[312]=C_h_intern(&lf[312],28,"\010compilerinsert-timer-checks");
lf[313]=C_h_intern(&lf[313],16,"unsafe-libraries");
lf[314]=C_h_intern(&lf[314],27,"\010compileremit-unsafe-marker");
lf[315]=C_h_intern(&lf[315],23,"\005matchset-error-control");
lf[316]=C_h_intern(&lf[316],5,"\000fail");
lf[317]=C_h_intern(&lf[317],11,"no-warnings");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\031Warnings are disabled~%~!");
lf[319]=C_h_intern(&lf[319],15,"disable-warning");
lf[320]=C_h_intern(&lf[320],28,"\010compilerlookup-exports-file");
lf[321]=C_h_intern(&lf[321],6,"import");
lf[322]=C_h_intern(&lf[322],14,"no-lambda-info");
lf[323]=C_h_intern(&lf[323],26,"\010compileremit-closure-info");
lf[324]=C_h_intern(&lf[324],3,"raw");
lf[325]=C_h_intern(&lf[325],1,"b");
lf[326]=C_h_intern(&lf[326],15,"\003sysstart-timer");
lf[327]=C_h_intern(&lf[327],23,"disable-compiler-macros");
lf[328]=C_h_intern(&lf[328],32,"\010compilercompiler-macros-enabled");
lf[329]=C_h_intern(&lf[329],11,"lambda-lift");
lf[330]=C_h_intern(&lf[330],16,"\003sysstring->list");
lf[331]=C_h_intern(&lf[331],5,"debug");
lf[332]=C_h_intern(&lf[332],29,"\010compilerstring->c-identifier");
lf[333]=C_h_intern(&lf[333],18,"\010compilerstringify");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[336]=C_h_intern(&lf[336],6,"getenv");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[338]=C_h_intern(&lf[338],14,"symbol->string");
lf[339]=C_h_intern(&lf[339],9,"to-stdout");
lf[340]=C_h_intern(&lf[340],13,"make-pathname");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[343]=C_h_intern(&lf[343],29,"\010compilerdefault-declarations");
lf[344]=C_h_intern(&lf[344],30,"\010compilerunits-used-by-default");
lf[345]=C_h_intern(&lf[345],28,"\010compilerinitialize-compiler");
C_register_lf2(lf,346,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_425,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k423 */
static void C_ccall f_425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_428,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k426 in k423 */
static void C_ccall f_428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_431,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k429 in k426 in k423 */
static void C_ccall f_431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_434,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k432 in k429 in k426 in k423 */
static void C_ccall f_434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_437,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=C_mutate(&lf[3],lf[4]);
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_443,tmp=(C_word)a,a+=2,tmp));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_443(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_443r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_443r(t0,t1,t2,t3);}}

static void C_ccall f_443r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_446,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_479,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 93   initialize-compiler */
t6=C_retrieve(lf[345]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_479,2,t0,t1);}
t2=(C_word)C_i_memq(lf[9],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[10]+1,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2446,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2454,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2458,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[10]))){
t8=t7;
f_2458(t8,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_a_i_cons(&a,2,lf[209],C_retrieve(lf[344]));
t9=t7;
f_2458(t9,(C_word)C_a_i_list(&a,1,t8));}}

/* k2456 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_2458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 97   append */
t2=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[343]),t1);}

/* k2452 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2445 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2446,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[197],t2));}

/* k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[11],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[12],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[13],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2411,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 105  option-arg */
f_446(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[339],((C_word*)t0)[5]))){
t9=t8;
f_495(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2433,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 110  pathname-file */
t10=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_2433(2,t10,lf[342]);}}}}

/* k2431 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 110  make-pathname */
t2=C_retrieve(lf[340]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[341]);}

/* k2409 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
/* batch-driver.scm: 107  symbol->string */
t2=*((C_word*)lf[338]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_495(2,t2,t1);}}

/* k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_498,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2401,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2405,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 111  getenv */
t5=C_retrieve(lf[336]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[337]);}

/* k2403 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[334]);
/* batch-driver.scm: 111  string-split */
t3=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[335]);}

/* k2399 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[288]),t1);}

/* k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_498,2,t0,t1);}
t2=C_retrieve(lf[14]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[15];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[16],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_504,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_504(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[239],((C_word*)t0)[8]);
t14=t12;
f_504(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[17],((C_word*)t0)[8])));}}

/* k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[94],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_504,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[17],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[4]);
t5=(C_word)C_i_memq(lf[18],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[19],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[20],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t23=(C_truep(t22)?t22:(C_word)C_i_memq(lf[28],((C_word*)t0)[13]));
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_548,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_554,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_572,a[2]=t25,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_594,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_609,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_621,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_670,tmp=(C_word)a,a+=2,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_750,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_780,a[2]=((C_word*)t0)[9],a[3]=t24,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_790,a[2]=((C_word*)t0)[9],a[3]=t24,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_807,a[2]=t29,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_813,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_892,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t30,a[11]=t23,a[12]=t1,a[13]=t31,a[14]=t34,a[15]=((C_word*)t0)[3],a[16]=t4,a[17]=((C_word*)t0)[4],a[18]=t28,a[19]=t27,a[20]=t13,a[21]=t17,a[22]=t14,a[23]=((C_word*)t0)[5],a[24]=t26,a[25]=t35,a[26]=t33,a[27]=t32,a[28]=t19,a[29]=t24,a[30]=((C_word*)t0)[6],a[31]=((C_word*)t0)[7],a[32]=((C_word*)t0)[8],a[33]=t21,a[34]=t11,a[35]=((C_word*)t0)[12],a[36]=((C_word*)t0)[13],a[37]=t16,tmp=(C_word)a,a+=38,tmp);
if(C_truep(t12)){
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2374,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2378,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2382,a[2]=t38,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 206  option-arg */
f_446(t39,t12);}
else{
t37=t36;
f_892(t37,C_SCHEME_UNDEFINED);}}

/* k2380 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 206  stringify */
t2=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2376 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 206  string->c-identifier */
t2=C_retrieve(lf[332]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2372 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[184]+1,t1);
t3=((C_word*)t0)[2];
f_892(t3,t2);}

/* k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_892,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2348,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2370,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 212  collect-options */
t5=((C_word*)t0)[13];
f_750(t5,t4,lf[331]);}

/* k2368 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 208  append-map */
t2=C_retrieve(lf[265]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2347 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2348,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2354,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2366,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t5=C_retrieve(lf[330]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2364 in a2347 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2353 in a2347 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2354,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* batch-driver.scm: 210  string->symbol */
t4=*((C_word*)lf[262]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_896,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1,t1);
t3=(C_word)C_i_memq(lf[53],C_retrieve(lf[29]));
t4=C_mutate(((C_word *)((C_word*)t0)[37])+1,t3);
t5=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[329],((C_word*)t0)[36]))){
t6=C_set_block_item(lf[148],0,C_SCHEME_TRUE);
t7=t5;
f_903(t7,t6);}
else{
t6=t5;
f_903(t6,C_SCHEME_UNDEFINED);}}

/* k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_903,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[327],((C_word*)t0)[36]))){
t3=C_set_block_item(lf[328],0,C_SCHEME_FALSE);
t4=t2;
f_906(t4,t3);}
else{
t3=t2;
f_906(t3,C_SCHEME_UNDEFINED);}}

/* k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_906,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[109],C_retrieve(lf[29])))){
/* batch-driver.scm: 216  ##sys#start-timer */
t3=*((C_word*)lf[326]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_909(2,t3,C_SCHEME_UNDEFINED);}}

/* k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[325],C_retrieve(lf[29])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_912(t4,t3);}
else{
t3=t2;
f_912(t3,C_SCHEME_UNDEFINED);}}

/* k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_912,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[54],((C_word*)t0)[35]);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cadr(t2);
t5=C_mutate((C_word*)lf[122]+1,t4);
t6=t3;
f_918(t6,t5);}
else{
t4=t3;
f_918(t4,C_SCHEME_FALSE);}}

/* k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_918,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[324],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[10],0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[16],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[31],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_921(t6,t5);}
else{
t3=t2;
f_921(t3,C_SCHEME_UNDEFINED);}}

/* k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_921(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_921,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[322],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[323],0,C_SCHEME_FALSE);
t4=t2;
f_924(t4,t3);}
else{
t3=t2;
f_924(t3,C_SCHEME_UNDEFINED);}}

/* k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_924(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_924,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[55],((C_word*)t0)[35]);
t3=C_mutate((C_word*)lf[56]+1,t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
/* batch-driver.scm: 227  collect-options */
t5=((C_word*)t0)[12];
f_750(t5,t4,lf[321]);}

/* k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=C_set_block_item(lf[56],0,C_SCHEME_TRUE);
/* for-each */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,C_retrieve(lf[320]),t1);}
else{
t3=t2;
f_934(2,t3,C_SCHEME_UNDEFINED);}}

/* k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2307,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 231  collect-options */
t4=((C_word*)t0)[12];
f_750(t4,t3,lf[319]);}

/* k2305 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[262]+1),t1);}

/* k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_938,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[317],((C_word*)t0)[35]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2299,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[34])){
/* batch-driver.scm: 233  printf */
t5=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[318]);}
else{
t5=t4;
f_2299(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_941(t4,C_SCHEME_UNDEFINED);}}

/* k2297 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[125],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_941(t3,t2);}

/* k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_941,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[94],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[94],0,C_SCHEME_TRUE);
t4=t2;
f_944(t4,t3);}
else{
t3=t2;
f_944(t3,C_SCHEME_UNDEFINED);}}

/* k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_944,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[146],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[146],0,C_SCHEME_TRUE);
/* batch-driver.scm: 238  ##match#set-error-control */
t4=C_retrieve(lf[315]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[316]);}
else{
t3=t2;
f_947(2,t3,C_SCHEME_UNDEFINED);}}

/* k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(C_truep(((C_word*)t0)[21])?(C_word)C_i_memq(lf[313],((C_word*)t0)[35]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[314],0,C_SCHEME_TRUE);
t5=t2;
f_950(t5,t4);}
else{
t4=t2;
f_950(t4,C_SCHEME_UNDEFINED);}}

/* k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_950,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[311],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[312],0,C_SCHEME_FALSE);
t4=t2;
f_953(t4,t3);}
else{
t3=t2;
f_953(t3,C_SCHEME_UNDEFINED);}}

/* k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_953,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[308],((C_word*)t0)[35]))){
t3=C_mutate((C_word*)lf[309]+1,lf[310]);
t4=t2;
f_956(t4,t3);}
else{
t3=t2;
f_956(t3,C_SCHEME_UNDEFINED);}}

/* k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_956,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[307],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[187],0,C_SCHEME_TRUE);
t4=t2;
f_959(t4,t3);}
else{
t3=t2;
f_959(t3,C_SCHEME_UNDEFINED);}}

/* k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_959(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_959,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[305],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[306],0,C_SCHEME_TRUE);
t4=t2;
f_962(t4,t3);}
else{
t3=t2;
f_962(t3,C_SCHEME_UNDEFINED);}}

/* k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_962(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_962,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[304],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[302],0,C_fix(10));
t4=t2;
f_965(t4,t3);}
else{
t3=t2;
f_965(t3,C_SCHEME_UNDEFINED);}}

/* k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_965,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[58],((C_word*)t0)[35]);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[35],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2246,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 248  option-arg */
f_446(t4,t2);}
else{
t4=t3;
f_971(t4,C_SCHEME_FALSE);}}

/* k2244 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2249,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 249  string->number */
C_string_to_number(3,0,t2,t1);}

/* k2247 in k2244 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2252,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_2252(2,t3,t1);}
else{
/* batch-driver.scm: 250  quit */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[303],((C_word*)t0)[2]);}}

/* k2250 in k2247 in k2244 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[302]+1,t1);
t3=((C_word*)t0)[2];
f_971(t3,t2);}

/* k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_971,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[299],((C_word*)t0)[31]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2233,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[35])){
/* batch-driver.scm: 252  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[301]);}
else{
t4=t3;
f_2233(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_974(2,t3,C_SCHEME_UNDEFINED);}}

/* k2231 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 253  register-feature! */
t3=C_retrieve(lf[281]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[299]);}

/* k2234 in k2231 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 254  case-sensitive */
t2=C_retrieve(lf[300]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[297],((C_word*)t0)[31]))){
/* batch-driver.scm: 256  compiler-warning */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[185],lf[298]);}
else{
t3=t2;
f_977(2,t3,C_SCHEME_UNDEFINED);}}

/* k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2191,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 258  option-arg */
f_446(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_980(2,t3,C_SCHEME_UNDEFINED);}}

/* k2189 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[290],t1))){
/* batch-driver.scm: 259  keyword-style */
t2=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[291]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[292],t1))){
/* batch-driver.scm: 260  keyword-style */
t2=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[293]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[294],t1))){
/* batch-driver.scm: 261  keyword-style */
t2=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[295]);}
else{
/* batch-driver.scm: 262  quit */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[296]);}}}}

/* k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_980,2,t0,t1);}
t2=C_mutate((C_word*)lf[59]+1,((C_word*)t0)[34]);
t3=C_set_block_item(lf[60],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[34],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2184,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2188,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 266  collect-options */
t7=((C_word*)t0)[11];
f_750(t7,t6,lf[289]);}

/* k2186 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[288]),t1);}

/* k2182 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 266  append */
t2=*((C_word*)lf[195]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,C_retrieve(lf[61]),((C_word*)t0)[2]);}

/* k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_986,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1,t1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t4=(C_truep(((C_word*)t0)[20])?(C_truep(((C_word*)t0)[28])?(C_word)C_i_string_equal_p(((C_word*)t0)[20],((C_word*)t0)[28]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
/* batch-driver.scm: 270  quit */
t5=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,lf[287]);}
else{
t5=t3;
f_989(2,t5,C_SCHEME_UNDEFINED);}}

/* k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2158,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2160,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2168,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 275  collect-options */
t6=((C_word*)t0)[10];
f_750(t6,t5,lf[209]);}

/* k2166 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 273  append-map */
t2=C_retrieve(lf[265]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2159 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2160,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[286]);}

/* k2156 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[262]+1),t1);}

/* k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_993,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[33])+1,t1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[33],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[284],((C_word*)t0)[30]))){
t4=C_set_block_item(lf[285],0,C_SCHEME_FALSE);
t5=t3;
f_996(t5,t4);}
else{
t4=t3;
f_996(t4,C_SCHEME_UNDEFINED);}}

/* k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_996(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_996,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2142,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2150,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 282  collect-options */
t6=((C_word*)t0)[10];
f_750(t6,t5,lf[283]);}

/* k2148 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 282  append-map */
t2=C_retrieve(lf[265]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2141 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2142,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[282]);}

/* k2138 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[281]),t1);}

/* k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[62],C_retrieve(lf[63]));
t3=C_mutate((C_word*)lf[63]+1,t2);
t4=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 286  collect-options */
t5=((C_word*)t0)[10];
f_750(t5,t4,lf[280]);}

/* k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1009,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[22])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2133,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 288  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[279]);}
else{
t3=t2;
f_1009(2,t3,C_SCHEME_UNDEFINED);}}

/* k2131 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 289  load-verbose */
t2=C_retrieve(lf[278]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2122,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2121 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2122,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2130,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 290  ##sys#resolve-include-filename */
t4=C_retrieve(lf[277]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2128 in a2121 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 290  load */
t2=C_retrieve(lf[276]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 291  delete */
t3=C_retrieve(lf[275]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[62],C_retrieve(lf[63]),*((C_word*)lf[261]+1));}

/* k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[64],C_retrieve(lf[63]));
t4=C_mutate((C_word*)lf[63]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[65],C_retrieve(lf[63]));
t6=C_mutate((C_word*)lf[63]+1,t5);
t7=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 295  ##sys#provide */
t8=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[274]);}

/* k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 296  user-post-analysis-pass */
t3=C_retrieve(lf[272]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1031,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[33])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 299  append */
t4=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[32])[1],C_retrieve(lf[271]));}

/* k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1035,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[267],((C_word*)t0)[31]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2092,a[2]=t3,a[3]=((C_word*)t0)[32],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[32],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2108,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[21])){
/* batch-driver.scm: 308  pathname-file */
t7=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[21]);}
else{
if(C_truep(((C_word*)t0)[29])){
/* batch-driver.scm: 309  pathname-file */
t7=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[29]);}
else{
/* batch-driver.scm: 310  quit */
t7=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[270]);}}}
else{
t4=t3;
f_1038(t4,C_SCHEME_UNDEFINED);}}

/* k2106 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 307  string->symbol */
t2=*((C_word*)lf[262]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2102 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[268],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* batch-driver.scm: 304  append */
t4=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t3);}

/* k2090 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1038(t3,t2);}

/* k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1038(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1038,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[12],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2075,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2077,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2085,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 318  collect-options */
t7=((C_word*)t0)[10];
f_750(t7,t6,lf[266]);}

/* k2083 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 316  append-map */
t2=C_retrieve(lf[265]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2076 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2077,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[264]);}

/* k2073 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[262]+1),t1);}

/* k2069 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 313  lset-difference */
t2=C_retrieve(lf[260]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[261]+1),t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2057,a[2]=((C_word*)t0)[32],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2059,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a2058 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2059,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[197],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[259],t3));}

/* k2055 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 321  append */
t2=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[32],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[257],((C_word*)t0)[31]))){
t4=C_set_block_item(lf[258],0,C_SCHEME_TRUE);
t5=t3;
f_1048(t5,t4);}
else{
t4=t3;
f_1048(t4,C_SCHEME_UNDEFINED);}}

/* k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1048(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1048,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2036,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 327  option-arg */
f_446(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[256]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1052(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1052(2,t4,C_SCHEME_FALSE);}}}

/* k2034 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 327  arg-val */
f_670(((C_word*)t0)[2],t1);}

/* k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1052,2,t0,t1);}
t2=C_mutate((C_word*)lf[66]+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1056,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],tmp=(C_word)a,a+=31,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2029,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 331  option-arg */
f_446(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1056(2,t4,C_SCHEME_FALSE);}}

/* k2027 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 331  arg-val */
f_670(((C_word*)t0)[2],t1);}

/* k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1056,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1,t1);
t3=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2022,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 332  option-arg */
f_446(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1060(2,t4,C_SCHEME_FALSE);}}

/* k2020 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 332  arg-val */
f_670(((C_word*)t0)[2],t1);}

/* k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1060,2,t0,t1);}
t2=C_mutate((C_word*)lf[68]+1,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2015,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 333  option-arg */
f_446(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1064(2,t4,C_SCHEME_FALSE);}}

/* k2013 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 333  arg-val */
f_670(((C_word*)t0)[2],t1);}

/* k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1064,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1,t1);
t3=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1068,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],a[25]=((C_word*)t0)[28],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1995,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 336  option-arg */
f_446(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[255]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1068(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1068(2,t5,C_SCHEME_FALSE);}}}

/* k1993 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 336  arg-val */
f_670(((C_word*)t0)[2],t1);}

/* k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1068,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1,t1);
t3=(C_word)C_i_memq(lf[71],((C_word*)t0)[25]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[72]+1,t4);
t6=(C_word)C_i_memq(lf[73],((C_word*)t0)[25]);
t7=C_mutate((C_word*)lf[74]+1,t6);
t8=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep((C_word)C_i_memq(lf[253],C_retrieve(lf[29])))){
/* batch-driver.scm: 342  set-gc-report! */
t9=C_retrieve(lf[254]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1079(2,t9,C_SCHEME_UNDEFINED);}}

/* k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep((C_word)C_i_memq(lf[248],((C_word*)t0)[25]))){
t3=t2;
f_1082(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[249]+1,C_retrieve(lf[250]));
t4=C_mutate((C_word*)lf[251]+1,C_retrieve(lf[252]));
t5=t2;
f_1082(t5,t4);}}

/* k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1082(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1082,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_truep(C_retrieve(lf[72]))?lf[245]:lf[246]);
/* batch-driver.scm: 347  printf */
t4=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[247],t3);}
else{
t3=t2;
f_1085(2,t3,C_SCHEME_UNDEFINED);}}

/* k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1088,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[239],t3);
t5=C_set_block_item(lf[200],0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1948,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t7=(C_truep(t4)?lf[243]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 355  append */
t8=*((C_word*)lf[195]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[244]),t7);}
else{
t3=t2;
f_1088(2,t3,C_SCHEME_UNDEFINED);}}

/* k1946 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
t3=(C_truep(((C_word*)t0)[3])?lf[240]:lf[241]);
/* batch-driver.scm: 362  printf */
t4=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[242],t3,C_retrieve(lf[200]));}
else{
t3=((C_word*)t0)[2];
f_1088(2,t3,C_SCHEME_UNDEFINED);}}

/* k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1088,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[75],((C_word*)t0)[24]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1097,a[2]=((C_word*)t0)[23],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 365  print-version */
t3=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[78],((C_word*)t0)[24]);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
if(C_truep(t2)){
t4=t3;
f_1109(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[236],((C_word*)t0)[24]);
if(C_truep(t4)){
t5=t3;
f_1109(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[237],((C_word*)t0)[24]);
t6=t3;
f_1109(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[238],((C_word*)t0)[24])));}}}}

/* k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1109,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 368  print-usage */
t2=C_retrieve(lf[79]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[24]);}
else{
if(C_truep((C_word)C_i_memq(lf[80],((C_word*)t0)[23]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1121,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1128,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 370  chicken-version */
t4=C_retrieve(lf[82]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=((C_word*)t0)[22];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[23],a[11]=((C_word*)t0)[24],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=t3;
f_1146(2,t4,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 380  printf */
t4=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[234],((C_word*)t0)[22]);}}
else{
if(C_truep(((C_word*)t0)[12])){
t3=((C_word*)t0)[24];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 374  print-version */
t4=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}}}}

/* k1138 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 375  display */
t2=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[235]);}

/* k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1146,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1,((C_word*)t0)[24]);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[24],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 382  debugging */
t4=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[229],lf[233],((C_word*)t0)[10]);}

/* k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 383  debugging */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[229],lf[232],C_retrieve(lf[29]));}

/* k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 384  debugging */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[229],lf[231],C_retrieve(lf[66]));}

/* k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 385  debugging */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[229],lf[230],C_retrieve(lf[70]));}

/* k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1159,2,t0,t1);}
t2=f_548();
t3=C_mutate(((C_word *)((C_word*)t0)[23])+1,t2);
t4=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[23],a[14]=((C_word*)t0)[24],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 389  make-vector */
t5=*((C_word*)lf[227]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[228]),C_SCHEME_END_OF_LIST);}

/* k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1167,2,t0,t1);}
t2=C_mutate((C_word*)lf[40]+1,t1);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 390  collect-options */
t4=((C_word*)t0)[2];
f_750(t4,t3,lf[226]);}

/* k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
/* batch-driver.scm: 391  collect-options */
t3=((C_word*)t0)[2];
f_750(t3,t2,lf[225]);}

/* k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1176,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[19],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 393  collect-options */
t4=((C_word*)t0)[2];
f_750(t4,t3,lf[224]);}

/* k1912 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1914,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1922,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 395  collect-options */
t4=((C_word*)t0)[2];
f_750(t4,t3,lf[223]);}

/* k1920 in k1912 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 392  append */
t2=*((C_word*)lf[195]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm: 397  user-read-pass */
t3=C_retrieve(lf[222]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1182,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],a[21]=((C_word*)t0)[25],a[22]=((C_word*)t0)[26],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1811,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[22])){
/* batch-driver.scm: 399  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[215]);}
else{
t4=t3;
f_1811(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1823,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1823(t6,t2,((C_word*)t0)[4]);}}

/* do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1823(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1823,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1834,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1838,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[216]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 409  check-and-open-input-file */
t5=C_retrieve(lf[221]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k1850 in do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1864,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1904,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[220]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a1903 in k1850 in do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1904,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[218]));
t3=C_mutate((C_word*)lf[218]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* a1871 in k1850 in do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1876,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 411  read-form */
t3=((C_word*)t0)[2];
f_807(t3,t2,((C_word*)t0)[5]);}

/* k1874 in a1871 in k1850 in do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1881(t5,((C_word*)t0)[2],t1);}

/* do206 in k1874 in a1871 in k1850 in do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1881(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1881,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* batch-driver.scm: 414  close-checked-input-file */
t3=C_retrieve(lf[219]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1902,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 412  read-form */
t6=((C_word*)t0)[2];
f_807(t6,t5,((C_word*)t0)[6]);}}

/* k1900 in do206 in k1874 in a1871 in k1850 in do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1881(t2,((C_word*)t0)[2],t1);}

/* a1863 in k1850 in do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[218]));
t3=C_mutate((C_word*)lf[218]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* k1853 in k1850 in do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_1823(t3,((C_word*)t0)[2],t2);}

/* k1836 in do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 406  reverse */
t3=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1840 in k1836 in do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1846,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[216]),((C_word*)t0)[2]);}

/* k1844 in k1840 in k1836 in do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 405  append */
t2=*((C_word*)lf[195]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1832 in do194 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1809 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 400  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1813 in k1809 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1182(2,t3,t2);}

/* k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 418  user-preprocessor-pass */
t3=C_retrieve(lf[214]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1801,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[18])){
/* batch-driver.scm: 420  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[213]);}
else{
t4=t3;
f_1801(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1188(t3,C_SCHEME_UNDEFINED);}}

/* k1799 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1803 in k1799 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1188(t3,t2);}

/* k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1188(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1188,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 423  print-expr */
t3=((C_word*)t0)[7];
f_609(t3,t2,lf[211],lf[212],((C_word*)((C_word*)t0)[3])[1]);}

/* k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1191,2,t0,t1);}
t2=f_780(((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1197,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],tmp=(C_word)a,a+=22,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1197(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1786,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 426  append */
t5=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[208]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k1784 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1786,2,t0,t1);}
t2=C_mutate((C_word*)lf[208]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[209],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,2,lf[210],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1197(t7,t6);}

/* k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1197,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1200,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],tmp=(C_word)a,a+=20,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 428  append */
t4=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1777 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[207]),t1);}

/* k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 429  gensym */
t3=C_retrieve(lf[206]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[84]));
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1209,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],tmp=(C_word)a,a+=18,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1681,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1759,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[205]));}

/* a1758 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1759,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,2,lf[197],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[202],t3,t5));}

/* k1679 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1753,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[204]));}

/* a1752 in k1679 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1753,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[203],t2));}

/* k1683 in k1679 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[200]))){
t3=(C_word)C_a_i_list(&a,2,lf[197],((C_word*)t0)[3]);
t4=(C_truep(C_retrieve(lf[184]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[197],t4);
t6=(C_word)C_a_i_list(&a,3,lf[201],t3,t5);
t7=(C_word)C_a_i_list(&a,3,lf[202],C_retrieve(lf[199]),t6);
t8=t2;
f_1689(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t3=t2;
f_1689(t3,C_SCHEME_END_OF_LIST);}}

/* k1687 in k1683 in k1679 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1689(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1689,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1708,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[84]));}

/* a1707 in k1687 in k1683 in k1679 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1708,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,2,lf[197],t3);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_list(&a,2,lf[197],t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,4,lf[198],C_retrieve(lf[199]),t4,t6));}

/* k1691 in k1687 in k1683 in k1679 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[184]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 431  append */
t5=*((C_word*)lf[195]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[196]);}

/* k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1209,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1674,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 452  debugging */
t6=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[193],lf[194]);}

/* k1672 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 453  display-real-name-table */
t2=C_retrieve(lf[192]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1212(2,t2,C_SCHEME_UNDEFINED);}}

/* k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1668,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 454  debugging */
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[190],lf[191]);}

/* k1666 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 455  display-line-number-database */
t2=C_retrieve(lf[189]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1215(2,t2,C_SCHEME_UNDEFINED);}}

/* k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[187]))?C_retrieve(lf[184]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 458  compiler-warning */
t4=C_retrieve(lf[179]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[185],lf[188],C_retrieve(lf[184]));}
else{
t4=t2;
f_1218(2,t4,C_SCHEME_UNDEFINED);}}

/* k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[184]))?((C_word*)t0)[11]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 464  compiler-warning */
t4=C_retrieve(lf[179]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[185],lf[186],C_retrieve(lf[184]));}
else{
t4=t2;
f_1221(2,t4,C_SCHEME_UNDEFINED);}}

/* k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1647,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[146]))){
/* batch-driver.scm: 466  feature? */
t4=C_retrieve(lf[182]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[183]);}
else{
t4=t3;
f_1647(2,t4,C_SCHEME_FALSE);}}

/* k1645 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 467  compiler-warning */
t2=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[180],lf[181]);}
else{
t2=((C_word*)t0)[2];
f_1224(2,t2,C_SCHEME_UNDEFINED);}}

/* k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=C_mutate((C_word*)lf[40]+1,C_retrieve(lf[85]));
t3=C_set_block_item(lf[85],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 474  end-time */
t5=((C_word*)t0)[17];
f_790(t5,t4,lf[178]);}

/* k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 475  print-expr */
t3=((C_word*)t0)[2];
f_609(t3,t2,lf[176],lf[177],((C_word*)((C_word*)t0)[4])[1]);}

/* k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1235,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep((C_word)C_i_memq(lf[175],((C_word*)t0)[2]))){
/* batch-driver.scm: 477  exit */
t3=C_retrieve(lf[121]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t3=t2;
f_1235(2,t3,C_SCHEME_UNDEFINED);}}

/* k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 479  user-pass */
t3=C_retrieve(lf[174]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1625,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[12])){
/* batch-driver.scm: 481  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[173]);}
else{
t4=t3;
f_1625(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1241(2,t3,C_SCHEME_UNDEFINED);}}

/* k1623 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1625,2,t0,t1);}
t2=f_780(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k1630 in k1623 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 484  end-time */
t3=((C_word*)t0)[3];
f_790(t3,((C_word*)t0)[2],lf[171]);}

/* k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1622,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 489  canonicalize-begin-body */
t4=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1620 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 488  build-node-graph */
t2=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1618,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[86],lf[87],lf[88],t2);
t4=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1250,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 490  user-pass-2 */
t5=C_retrieve(lf[168]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1253,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1607,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 491  debugging */
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[166],lf[167]);}

/* k1605 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1607,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 492  ##sys#hash-table->alist */
t3=C_retrieve(lf[164]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[165]));}
else{
t2=((C_word*)t0)[2];
f_1253(2,t2,C_SCHEME_UNDEFINED);}}

/* k1612 in k1605 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 492  pretty-print */
t2=C_retrieve(lf[34]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[14],a[8]=t2,a[9]=((C_word*)t0)[17],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[13])){
/* batch-driver.scm: 494  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[163]);}
else{
t4=t3;
f_1575(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1256(t3,C_SCHEME_UNDEFINED);}}

/* k1573 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1575,2,t0,t1);}
t2=f_780(((C_word*)t0)[9]);
t3=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 497  analyze */
t5=((C_word*)t0)[2];
f_813(t5,t4,lf[162],((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k1580 in k1573 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 498  print-db */
t3=((C_word*)t0)[2];
f_594(t3,t2,lf[161],lf[155],t1,C_fix(0));}

/* k1583 in k1580 in k1573 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 499  end-time */
t3=((C_word*)t0)[3];
f_790(t3,t2,lf[160]);}

/* k1586 in k1583 in k1580 in k1573 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1588,2,t0,t1);}
t2=f_780(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 501  proc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1592 in k1586 in k1583 in k1580 in k1573 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1597,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 502  end-time */
t3=((C_word*)t0)[2];
f_790(t3,t2,lf[159]);}

/* k1595 in k1592 in k1586 in k1583 in k1580 in k1573 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 503  print-node */
t3=((C_word*)t0)[3];
f_572(t3,t2,lf[157],lf[158],((C_word*)t0)[2]);}

/* k1598 in k1595 in k1592 in k1586 in k1583 in k1580 in k1573 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[91],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1256(t3,t2);}

/* k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1256(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1256,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1259,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[148]))){
t3=f_780(((C_word*)t0)[16]);
t4=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[13],a[6]=t2,a[7]=((C_word*)t0)[16],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 509  analyze */
t6=((C_word*)t0)[14];
f_813(t6,t5,lf[156],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1259(t3,C_SCHEME_UNDEFINED);}}

/* k1551 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1556,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 510  print-db */
t3=((C_word*)t0)[2];
f_594(t3,t2,lf[154],lf[155],t1,C_fix(0));}

/* k1554 in k1551 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 511  end-time */
t3=((C_word*)t0)[3];
f_790(t3,t2,lf[153]);}

/* k1557 in k1554 in k1551 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1559,2,t0,t1);}
t2=f_780(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 513  perform-lambda-lifting! */
t4=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1563 in k1557 in k1554 in k1551 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 514  end-time */
t3=((C_word*)t0)[2];
f_790(t3,t2,lf[151]);}

/* k1566 in k1563 in k1557 in k1554 in k1551 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 515  print-node */
t3=((C_word*)t0)[3];
f_572(t3,t2,lf[149],lf[150],((C_word*)t0)[2]);}

/* k1569 in k1566 in k1563 in k1557 in k1554 in k1551 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[91],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1259(t3,t2);}

/* k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1259(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1259,NULL,2,t0,t1);}
t2=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[89],0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[90],0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[146]))){
t6=t5;
f_1265(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
t7=(C_word)C_i_car(t6);
/* batch-driver.scm: 522  scan-toplevel-assignments */
t8=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t5,t7);}}

/* k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1265,2,t0,t1);}
t2=f_780(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 525  perform-cps-conversion */
t4=C_retrieve(lf[145]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1274,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 526  end-time */
t3=((C_word*)t0)[14];
f_790(t3,t2,lf[144]);}

/* k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 527  print-node */
t3=((C_word*)t0)[13];
f_572(t3,t2,lf[142],lf[143],((C_word*)t0)[2]);}

/* k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1277,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=t3,a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp));
t5=((C_word*)t3)[1];
f_1282(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1282(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1282,NULL,5,t0,t1,t2,t3,t4);}
t5=f_780(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=t2,a[17]=t3,a[18]=((C_word*)t0)[15],a[19]=t4,tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 533  analyze */
t7=((C_word*)t0)[12];
f_813(t7,t6,lf[141],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t1,a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep(C_retrieve(lf[91]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1520,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[56]))){
/* batch-driver.scm: 535  check-global-imports */
t4=C_retrieve(lf[140]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
t4=t3;
f_1520(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1292(2,t3,C_SCHEME_UNDEFINED);}}

/* k1518 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 536  check-global-exports */
t3=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1521 in k1518 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(lf[137],C_retrieve(lf[29])))){
/* batch-driver.scm: 538  dump-undefined-globals */
t2=C_retrieve(lf[138]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1292(2,t2,C_SCHEME_UNDEFINED);}}

/* k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1292,2,t0,t1);}
t2=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 540  end-time */
t4=((C_word*)t0)[14];
f_790(t4,t3,lf[136]);}

/* k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 541  print-db */
t3=((C_word*)t0)[2];
f_594(t3,t2,lf[134],lf[135],((C_word*)t0)[17],((C_word*)t0)[16]);}

/* k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_memq(lf[132],C_retrieve(lf[29])))){
/* batch-driver.scm: 543  print-program-statistics */
t3=C_retrieve(lf[133]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[17]);}
else{
t3=t2;
f_1302(2,t3,C_SCHEME_UNDEFINED);}}

/* k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1302,2,t0,t1);}
if(C_truep(((C_word*)t0)[20])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1308,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[18],a[10]=((C_word*)t0)[19],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 546  debugging */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[100],lf[105],((C_word*)t0)[16]);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1394,a[2]=((C_word*)t0)[18],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[19],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 569  print-node */
t3=((C_word*)t0)[12];
f_572(t3,t2,lf[130],lf[131],((C_word*)t0)[18]);}}

/* k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1394,2,t0,t1);}
t2=f_780(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1400,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 572  perform-closure-conversion */
t4=C_retrieve(lf[129]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[16]);}

/* k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 573  end-time */
t3=((C_word*)t0)[13];
f_790(t3,t2,lf[128]);}

/* k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1406,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 574  print-db */
t3=((C_word*)t0)[3];
f_594(t3,t2,lf[126],lf[127],((C_word*)t0)[15],((C_word*)t0)[2]);}

/* k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1409,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1497,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[125]))){
t4=f_548();
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_1497(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_1497(t4,C_SCHEME_FALSE);}}

/* k1495 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_1497(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 576  display */
t2=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[124]);}
else{
t2=((C_word*)t0)[2];
f_1409(2,t2,C_SCHEME_UNDEFINED);}}

/* k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_retrieve(lf[122]))){
/* batch-driver.scm: 578  dump-exported-globals */
t3=C_retrieve(lf[123]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[11],C_retrieve(lf[122]));}
else{
t3=t2;
f_1412(2,t3,C_SCHEME_UNDEFINED);}}

/* k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 579  exit */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(0));}
else{
t3=t2;
f_1415(2,t3,C_SCHEME_UNDEFINED);}}

/* k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1418,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm: 580  print-node */
t3=((C_word*)t0)[2];
f_572(t3,t2,lf[119],lf[120],((C_word*)t0)[11]);}

/* k1416 in k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1418,2,t0,t1);}
t2=f_780(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1426,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 583  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1431 in k1416 in k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1432,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=t1,a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 585  end-time */
t7=((C_word*)t0)[7];
f_790(t7,t6,lf[118]);}

/* k1434 in a1431 in k1416 in k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1436,2,t0,t1);}
t2=f_780(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[9])){
/* batch-driver.scm: 588  open-output-file */
t4=*((C_word*)lf[116]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
/* batch-driver.scm: 588  current-output-port */
t4=*((C_word*)lf[117]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k1440 in k1434 in a1431 in k1416 in k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_1445(2,t3,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 590  printf */
t3=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[115],((C_word*)t0)[9]);}}

/* k1443 in k1440 in k1434 in a1431 in k1416 in k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1448,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 591  generate-code */
t3=C_retrieve(lf[114]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1446 in k1443 in k1440 in k1434 in a1431 in k1416 in k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 592  close-output-port */
t3=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1451(2,t3,C_SCHEME_UNDEFINED);}}

/* k1449 in k1446 in k1443 in k1440 in k1434 in a1431 in k1416 in k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 593  end-time */
t3=((C_word*)t0)[2];
f_790(t3,t2,lf[112]);}

/* k1452 in k1449 in k1446 in k1443 in k1440 in k1434 in a1431 in k1416 in k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[109],C_retrieve(lf[29])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1476,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 594  ##sys#stop-timer */
t4=*((C_word*)lf[111]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1457(2,t3,C_SCHEME_UNDEFINED);}}

/* k1474 in k1452 in k1449 in k1446 in k1443 in k1440 in k1434 in a1431 in k1416 in k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 594  ##sys#display-times */
t2=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1455 in k1452 in k1449 in k1446 in k1443 in k1440 in k1434 in a1431 in k1416 in k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 595  compiler-cleanup-hook */
t3=C_retrieve(lf[108]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1458 in k1455 in k1452 in k1449 in k1446 in k1443 in k1440 in k1434 in a1431 in k1416 in k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 597  printf */
t2=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[107]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a1425 in k1416 in k1413 in k1410 in k1407 in k1404 in k1401 in k1398 in k1392 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1426,2,t0,t1);}
/* batch-driver.scm: 584  prepare-for-code-generation */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1306 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1308,2,t0,t1);}
t2=f_780(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1316,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1322,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 549  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1321 in k1306 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1322,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 550  end-time */
t5=((C_word*)t0)[4];
f_790(t5,t4,lf[104]);}

/* k1324 in a1321 in k1306 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 551  print-node */
t3=((C_word*)t0)[2];
f_572(t3,t2,lf[102],lf[103],((C_word*)t0)[6]);}

/* k1327 in k1324 in a1321 in k1306 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1329,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 553  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1282(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[93]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[94]))){
t3=f_780(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1365,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 560  analyze */
t5=((C_word*)t0)[2];
f_813(t5,t4,lf[98],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 566  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1282(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1348,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 555  debugging */
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[100],lf[101]);}}}

/* k1346 in k1327 in k1324 in a1321 in k1306 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[93],0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 557  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1282(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1363 in k1327 in k1324 in a1321 in k1306 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1368,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 561  end-time */
t3=((C_word*)t0)[2];
f_790(t3,t2,lf[97]);}

/* k1366 in k1363 in k1327 in k1324 in a1321 in k1306 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1368,2,t0,t1);}
t2=f_780(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1374,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 563  transform-direct-lambdas! */
t4=C_retrieve(lf[96]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1372 in k1366 in k1363 in k1327 in k1324 in a1321 in k1306 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1377,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 564  end-time */
t3=((C_word*)t0)[2];
f_790(t3,t2,lf[95]);}

/* k1375 in k1372 in k1366 in k1363 in k1327 in k1324 in a1321 in k1306 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 565  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1282(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1315 in k1306 in k1300 in k1297 in k1294 in k1290 in k1287 in loop in k1275 in k1272 in k1269 in k1263 in k1257 in k1254 in k1251 in k1248 in k1616 in k1239 in k1236 in k1233 in k1230 in k1227 in k1222 in k1219 in k1216 in k1213 in k1210 in k1207 in k1201 in k1198 in k1195 in k1189 in k1186 in k1183 in k1180 in k1177 in k1174 in k1171 in k1168 in k1165 in k1157 in k1154 in k1151 in k1148 in k1144 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1316,2,t0,t1);}
/* batch-driver.scm: 549  perform-high-level-optimizations */
t2=C_retrieve(lf[92]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1126 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 370  display */
t2=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1119 in k1107 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 371  newline */
t2=*((C_word*)lf[76]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1095 in k1086 in k1083 in k1080 in k1077 in k1066 in k1062 in k1058 in k1054 in k1050 in k1046 in k1043 in k1039 in k1036 in k1033 in k1029 in k1025 in k1014 in k1010 in k1007 in k1004 in k997 in k994 in k991 in k987 in k984 in k978 in k975 in k972 in k969 in k963 in k960 in k957 in k954 in k951 in k948 in k945 in k942 in k939 in k936 in k932 in k929 in k922 in k919 in k916 in k910 in k907 in k904 in k901 in k894 in k890 in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 366  newline */
t2=*((C_word*)lf[76]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* analyze in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_813(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_813,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_815,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_838,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_843,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-no120140 */
t8=t7;
f_843(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-contf121138 */
t10=t6;
f_838(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body118123 */
t12=t5;
f_815(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[1],t11);}}}}

/* def-no120 in analyze in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_843(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_843,NULL,2,t0,t1);}
/* def-contf121138 */
t2=((C_word*)t0)[2];
f_838(t2,t1,C_fix(0));}

/* def-contf121 in analyze in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_838(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_838,NULL,3,t0,t1,t2);}
/* body118123 */
t3=((C_word*)t0)[2];
f_815(t3,t1,t2,C_SCHEME_TRUE);}

/* body118 in analyze in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_815(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_815,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_819,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 197  analyze-expression */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k817 in body118 in analyze in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_822,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_827,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_833,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 199  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_822(2,t3,C_SCHEME_UNDEFINED);}}

/* a832 in k817 in body118 in analyze in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_833,5,t0,t1,t2,t3,t4);}
/* ##compiler#put! */
t5=C_retrieve(lf[50]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,((C_word*)t0)[2],t2,t3,t4);}

/* a826 in k817 in body118 in analyze in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_827,4,t0,t1,t2,t3);}
/* ##compiler#get */
t4=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* k820 in k817 in body118 in analyze in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_807,NULL,3,t0,t1,t2);}
/* batch-driver.scm: 193  ##sys#read */
t3=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* end-time in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_790(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_790,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=f_548();
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm: 190  printf */
t5=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,lf[47],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static C_word C_fcall f_780(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t1=f_548();
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_750(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_750,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_756,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_756(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_756(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_756,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_770,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 182  option-arg */
f_446(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k768 in loop in collect-options in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_774,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 182  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_756(t4,t2,t3);}

/* k772 in k768 in loop in collect-options in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_774,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_670(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_670,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_680,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 173  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_711,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_719,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 175  substring */
t11=*((C_word*)lf[46]+1);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_735,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_739,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 176  substring */
t13=*((C_word*)lf[46]+1);
((C_proc5)C_retrieve_proc(t13))(5,t13,t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 177  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k737 in arg-val in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 176  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k733 in arg-val in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_680(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k717 in arg-val in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 175  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k709 in arg-val in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_680(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k678 in arg-val in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* batch-driver.scm: 178  quit */
t2=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[45],((C_word*)t0)[2]);}}

/* infohook in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_621,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_625,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[44]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_667,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_667 in infohook in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_667,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k623 in infohook in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_628,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_631,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[43],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_631(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_631(t5,C_SCHEME_FALSE);}}

/* k629 in k623 in infohook in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_631,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_642,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm: 165  ##sys#hash-table-ref */
t6=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve(lf[40]),t5);}
else{
t2=((C_word*)t0)[3];
f_628(2,t2,C_SCHEME_UNDEFINED);}}

/* k644 in k629 in k623 in infohook in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 164  alist-cons */
t3=C_retrieve(lf[41]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k640 in k629 in k623 in infohook in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 161  ##sys#hash-table-set! */
t2=C_retrieve(lf[39]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[40]),((C_word*)t0)[2],t1);}

/* k626 in k623 in infohook in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_609(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_609,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_616,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 155  print-header */
t6=((C_word*)t0)[2];
f_554(t6,t5,t2,t3);}

/* k614 in print-expr in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* for-each */
t2=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[34]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_594(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_594,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_601,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 150  print-header */
t7=((C_word*)t0)[2];
f_554(t7,t6,t2,t3);}

/* k599 in print-db in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_601,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_604,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 151  printf */
t3=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[37],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k602 in k599 in print-db in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 152  display-analysis-database */
t2=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_572(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_572,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_579,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 144  print-header */
t6=((C_word*)t0)[2];
f_554(t6,t5,t2,t3);}

/* k577 in print-node in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_579,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 146  dump-nodes */
t2=C_retrieve(lf[33]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_592,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 147  build-expression-tree */
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k590 in k577 in print-node in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 147  pretty-print */
t2=C_retrieve(lf[34]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* print-header in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_554(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_554,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_558,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 137  printf */
t5=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[32],t2);}
else{
t5=t4;
f_558(2,t5,C_SCHEME_UNDEFINED);}}

/* k556 in print-header in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_558,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[29])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_567,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 140  printf */
t3=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[31],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k565 in k556 in print-header in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_ccall f_567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* cputime in k502 in k496 in k493 in k2442 in k477 in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static C_word C_fcall f_548(){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_fudge(C_fix(6)));}

/* option-arg in compile-source-file in k435 in k432 in k429 in k426 in k423 */
static void C_fcall f_446(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_446,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
/* batch-driver.scm: 88   quit */
t5=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[7],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
/* batch-driver.scm: 91   quit */
t5=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[8],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[281] = {
{"toplevelbatch-driver.scm",(void*)C_driver_toplevel},
{"f_425batch-driver.scm",(void*)f_425},
{"f_428batch-driver.scm",(void*)f_428},
{"f_431batch-driver.scm",(void*)f_431},
{"f_434batch-driver.scm",(void*)f_434},
{"f_437batch-driver.scm",(void*)f_437},
{"f_443batch-driver.scm",(void*)f_443},
{"f_479batch-driver.scm",(void*)f_479},
{"f_2458batch-driver.scm",(void*)f_2458},
{"f_2454batch-driver.scm",(void*)f_2454},
{"f_2446batch-driver.scm",(void*)f_2446},
{"f_2444batch-driver.scm",(void*)f_2444},
{"f_2433batch-driver.scm",(void*)f_2433},
{"f_2411batch-driver.scm",(void*)f_2411},
{"f_495batch-driver.scm",(void*)f_495},
{"f_2405batch-driver.scm",(void*)f_2405},
{"f_2401batch-driver.scm",(void*)f_2401},
{"f_498batch-driver.scm",(void*)f_498},
{"f_504batch-driver.scm",(void*)f_504},
{"f_2382batch-driver.scm",(void*)f_2382},
{"f_2378batch-driver.scm",(void*)f_2378},
{"f_2374batch-driver.scm",(void*)f_2374},
{"f_892batch-driver.scm",(void*)f_892},
{"f_2370batch-driver.scm",(void*)f_2370},
{"f_2348batch-driver.scm",(void*)f_2348},
{"f_2366batch-driver.scm",(void*)f_2366},
{"f_2354batch-driver.scm",(void*)f_2354},
{"f_896batch-driver.scm",(void*)f_896},
{"f_903batch-driver.scm",(void*)f_903},
{"f_906batch-driver.scm",(void*)f_906},
{"f_909batch-driver.scm",(void*)f_909},
{"f_912batch-driver.scm",(void*)f_912},
{"f_918batch-driver.scm",(void*)f_918},
{"f_921batch-driver.scm",(void*)f_921},
{"f_924batch-driver.scm",(void*)f_924},
{"f_931batch-driver.scm",(void*)f_931},
{"f_934batch-driver.scm",(void*)f_934},
{"f_2307batch-driver.scm",(void*)f_2307},
{"f_938batch-driver.scm",(void*)f_938},
{"f_2299batch-driver.scm",(void*)f_2299},
{"f_941batch-driver.scm",(void*)f_941},
{"f_944batch-driver.scm",(void*)f_944},
{"f_947batch-driver.scm",(void*)f_947},
{"f_950batch-driver.scm",(void*)f_950},
{"f_953batch-driver.scm",(void*)f_953},
{"f_956batch-driver.scm",(void*)f_956},
{"f_959batch-driver.scm",(void*)f_959},
{"f_962batch-driver.scm",(void*)f_962},
{"f_965batch-driver.scm",(void*)f_965},
{"f_2246batch-driver.scm",(void*)f_2246},
{"f_2249batch-driver.scm",(void*)f_2249},
{"f_2252batch-driver.scm",(void*)f_2252},
{"f_971batch-driver.scm",(void*)f_971},
{"f_2233batch-driver.scm",(void*)f_2233},
{"f_2236batch-driver.scm",(void*)f_2236},
{"f_974batch-driver.scm",(void*)f_974},
{"f_977batch-driver.scm",(void*)f_977},
{"f_2191batch-driver.scm",(void*)f_2191},
{"f_980batch-driver.scm",(void*)f_980},
{"f_2188batch-driver.scm",(void*)f_2188},
{"f_2184batch-driver.scm",(void*)f_2184},
{"f_986batch-driver.scm",(void*)f_986},
{"f_989batch-driver.scm",(void*)f_989},
{"f_2168batch-driver.scm",(void*)f_2168},
{"f_2160batch-driver.scm",(void*)f_2160},
{"f_2158batch-driver.scm",(void*)f_2158},
{"f_993batch-driver.scm",(void*)f_993},
{"f_996batch-driver.scm",(void*)f_996},
{"f_2150batch-driver.scm",(void*)f_2150},
{"f_2142batch-driver.scm",(void*)f_2142},
{"f_2140batch-driver.scm",(void*)f_2140},
{"f_999batch-driver.scm",(void*)f_999},
{"f_1006batch-driver.scm",(void*)f_1006},
{"f_2133batch-driver.scm",(void*)f_2133},
{"f_1009batch-driver.scm",(void*)f_1009},
{"f_2122batch-driver.scm",(void*)f_2122},
{"f_2130batch-driver.scm",(void*)f_2130},
{"f_1012batch-driver.scm",(void*)f_1012},
{"f_1016batch-driver.scm",(void*)f_1016},
{"f_1027batch-driver.scm",(void*)f_1027},
{"f_1031batch-driver.scm",(void*)f_1031},
{"f_1035batch-driver.scm",(void*)f_1035},
{"f_2108batch-driver.scm",(void*)f_2108},
{"f_2104batch-driver.scm",(void*)f_2104},
{"f_2092batch-driver.scm",(void*)f_2092},
{"f_1038batch-driver.scm",(void*)f_1038},
{"f_2085batch-driver.scm",(void*)f_2085},
{"f_2077batch-driver.scm",(void*)f_2077},
{"f_2075batch-driver.scm",(void*)f_2075},
{"f_2071batch-driver.scm",(void*)f_2071},
{"f_1041batch-driver.scm",(void*)f_1041},
{"f_2059batch-driver.scm",(void*)f_2059},
{"f_2057batch-driver.scm",(void*)f_2057},
{"f_1045batch-driver.scm",(void*)f_1045},
{"f_1048batch-driver.scm",(void*)f_1048},
{"f_2036batch-driver.scm",(void*)f_2036},
{"f_1052batch-driver.scm",(void*)f_1052},
{"f_2029batch-driver.scm",(void*)f_2029},
{"f_1056batch-driver.scm",(void*)f_1056},
{"f_2022batch-driver.scm",(void*)f_2022},
{"f_1060batch-driver.scm",(void*)f_1060},
{"f_2015batch-driver.scm",(void*)f_2015},
{"f_1064batch-driver.scm",(void*)f_1064},
{"f_1995batch-driver.scm",(void*)f_1995},
{"f_1068batch-driver.scm",(void*)f_1068},
{"f_1079batch-driver.scm",(void*)f_1079},
{"f_1082batch-driver.scm",(void*)f_1082},
{"f_1085batch-driver.scm",(void*)f_1085},
{"f_1948batch-driver.scm",(void*)f_1948},
{"f_1088batch-driver.scm",(void*)f_1088},
{"f_1109batch-driver.scm",(void*)f_1109},
{"f_1140batch-driver.scm",(void*)f_1140},
{"f_1146batch-driver.scm",(void*)f_1146},
{"f_1150batch-driver.scm",(void*)f_1150},
{"f_1153batch-driver.scm",(void*)f_1153},
{"f_1156batch-driver.scm",(void*)f_1156},
{"f_1159batch-driver.scm",(void*)f_1159},
{"f_1167batch-driver.scm",(void*)f_1167},
{"f_1170batch-driver.scm",(void*)f_1170},
{"f_1173batch-driver.scm",(void*)f_1173},
{"f_1914batch-driver.scm",(void*)f_1914},
{"f_1922batch-driver.scm",(void*)f_1922},
{"f_1176batch-driver.scm",(void*)f_1176},
{"f_1179batch-driver.scm",(void*)f_1179},
{"f_1823batch-driver.scm",(void*)f_1823},
{"f_1852batch-driver.scm",(void*)f_1852},
{"f_1904batch-driver.scm",(void*)f_1904},
{"f_1872batch-driver.scm",(void*)f_1872},
{"f_1876batch-driver.scm",(void*)f_1876},
{"f_1881batch-driver.scm",(void*)f_1881},
{"f_1902batch-driver.scm",(void*)f_1902},
{"f_1864batch-driver.scm",(void*)f_1864},
{"f_1855batch-driver.scm",(void*)f_1855},
{"f_1838batch-driver.scm",(void*)f_1838},
{"f_1842batch-driver.scm",(void*)f_1842},
{"f_1846batch-driver.scm",(void*)f_1846},
{"f_1834batch-driver.scm",(void*)f_1834},
{"f_1811batch-driver.scm",(void*)f_1811},
{"f_1815batch-driver.scm",(void*)f_1815},
{"f_1182batch-driver.scm",(void*)f_1182},
{"f_1185batch-driver.scm",(void*)f_1185},
{"f_1801batch-driver.scm",(void*)f_1801},
{"f_1805batch-driver.scm",(void*)f_1805},
{"f_1188batch-driver.scm",(void*)f_1188},
{"f_1191batch-driver.scm",(void*)f_1191},
{"f_1786batch-driver.scm",(void*)f_1786},
{"f_1197batch-driver.scm",(void*)f_1197},
{"f_1779batch-driver.scm",(void*)f_1779},
{"f_1200batch-driver.scm",(void*)f_1200},
{"f_1203batch-driver.scm",(void*)f_1203},
{"f_1759batch-driver.scm",(void*)f_1759},
{"f_1681batch-driver.scm",(void*)f_1681},
{"f_1753batch-driver.scm",(void*)f_1753},
{"f_1685batch-driver.scm",(void*)f_1685},
{"f_1689batch-driver.scm",(void*)f_1689},
{"f_1708batch-driver.scm",(void*)f_1708},
{"f_1693batch-driver.scm",(void*)f_1693},
{"f_1209batch-driver.scm",(void*)f_1209},
{"f_1674batch-driver.scm",(void*)f_1674},
{"f_1212batch-driver.scm",(void*)f_1212},
{"f_1668batch-driver.scm",(void*)f_1668},
{"f_1215batch-driver.scm",(void*)f_1215},
{"f_1218batch-driver.scm",(void*)f_1218},
{"f_1221batch-driver.scm",(void*)f_1221},
{"f_1647batch-driver.scm",(void*)f_1647},
{"f_1224batch-driver.scm",(void*)f_1224},
{"f_1229batch-driver.scm",(void*)f_1229},
{"f_1232batch-driver.scm",(void*)f_1232},
{"f_1235batch-driver.scm",(void*)f_1235},
{"f_1238batch-driver.scm",(void*)f_1238},
{"f_1625batch-driver.scm",(void*)f_1625},
{"f_1632batch-driver.scm",(void*)f_1632},
{"f_1241batch-driver.scm",(void*)f_1241},
{"f_1622batch-driver.scm",(void*)f_1622},
{"f_1618batch-driver.scm",(void*)f_1618},
{"f_1250batch-driver.scm",(void*)f_1250},
{"f_1607batch-driver.scm",(void*)f_1607},
{"f_1614batch-driver.scm",(void*)f_1614},
{"f_1253batch-driver.scm",(void*)f_1253},
{"f_1575batch-driver.scm",(void*)f_1575},
{"f_1582batch-driver.scm",(void*)f_1582},
{"f_1585batch-driver.scm",(void*)f_1585},
{"f_1588batch-driver.scm",(void*)f_1588},
{"f_1594batch-driver.scm",(void*)f_1594},
{"f_1597batch-driver.scm",(void*)f_1597},
{"f_1600batch-driver.scm",(void*)f_1600},
{"f_1256batch-driver.scm",(void*)f_1256},
{"f_1553batch-driver.scm",(void*)f_1553},
{"f_1556batch-driver.scm",(void*)f_1556},
{"f_1559batch-driver.scm",(void*)f_1559},
{"f_1565batch-driver.scm",(void*)f_1565},
{"f_1568batch-driver.scm",(void*)f_1568},
{"f_1571batch-driver.scm",(void*)f_1571},
{"f_1259batch-driver.scm",(void*)f_1259},
{"f_1265batch-driver.scm",(void*)f_1265},
{"f_1271batch-driver.scm",(void*)f_1271},
{"f_1274batch-driver.scm",(void*)f_1274},
{"f_1277batch-driver.scm",(void*)f_1277},
{"f_1282batch-driver.scm",(void*)f_1282},
{"f_1289batch-driver.scm",(void*)f_1289},
{"f_1520batch-driver.scm",(void*)f_1520},
{"f_1523batch-driver.scm",(void*)f_1523},
{"f_1292batch-driver.scm",(void*)f_1292},
{"f_1296batch-driver.scm",(void*)f_1296},
{"f_1299batch-driver.scm",(void*)f_1299},
{"f_1302batch-driver.scm",(void*)f_1302},
{"f_1394batch-driver.scm",(void*)f_1394},
{"f_1400batch-driver.scm",(void*)f_1400},
{"f_1403batch-driver.scm",(void*)f_1403},
{"f_1406batch-driver.scm",(void*)f_1406},
{"f_1497batch-driver.scm",(void*)f_1497},
{"f_1409batch-driver.scm",(void*)f_1409},
{"f_1412batch-driver.scm",(void*)f_1412},
{"f_1415batch-driver.scm",(void*)f_1415},
{"f_1418batch-driver.scm",(void*)f_1418},
{"f_1432batch-driver.scm",(void*)f_1432},
{"f_1436batch-driver.scm",(void*)f_1436},
{"f_1442batch-driver.scm",(void*)f_1442},
{"f_1445batch-driver.scm",(void*)f_1445},
{"f_1448batch-driver.scm",(void*)f_1448},
{"f_1451batch-driver.scm",(void*)f_1451},
{"f_1454batch-driver.scm",(void*)f_1454},
{"f_1476batch-driver.scm",(void*)f_1476},
{"f_1457batch-driver.scm",(void*)f_1457},
{"f_1460batch-driver.scm",(void*)f_1460},
{"f_1426batch-driver.scm",(void*)f_1426},
{"f_1308batch-driver.scm",(void*)f_1308},
{"f_1322batch-driver.scm",(void*)f_1322},
{"f_1326batch-driver.scm",(void*)f_1326},
{"f_1329batch-driver.scm",(void*)f_1329},
{"f_1348batch-driver.scm",(void*)f_1348},
{"f_1365batch-driver.scm",(void*)f_1365},
{"f_1368batch-driver.scm",(void*)f_1368},
{"f_1374batch-driver.scm",(void*)f_1374},
{"f_1377batch-driver.scm",(void*)f_1377},
{"f_1316batch-driver.scm",(void*)f_1316},
{"f_1128batch-driver.scm",(void*)f_1128},
{"f_1121batch-driver.scm",(void*)f_1121},
{"f_1097batch-driver.scm",(void*)f_1097},
{"f_813batch-driver.scm",(void*)f_813},
{"f_843batch-driver.scm",(void*)f_843},
{"f_838batch-driver.scm",(void*)f_838},
{"f_815batch-driver.scm",(void*)f_815},
{"f_819batch-driver.scm",(void*)f_819},
{"f_833batch-driver.scm",(void*)f_833},
{"f_827batch-driver.scm",(void*)f_827},
{"f_822batch-driver.scm",(void*)f_822},
{"f_807batch-driver.scm",(void*)f_807},
{"f_790batch-driver.scm",(void*)f_790},
{"f_780batch-driver.scm",(void*)f_780},
{"f_750batch-driver.scm",(void*)f_750},
{"f_756batch-driver.scm",(void*)f_756},
{"f_770batch-driver.scm",(void*)f_770},
{"f_774batch-driver.scm",(void*)f_774},
{"f_670batch-driver.scm",(void*)f_670},
{"f_739batch-driver.scm",(void*)f_739},
{"f_735batch-driver.scm",(void*)f_735},
{"f_719batch-driver.scm",(void*)f_719},
{"f_711batch-driver.scm",(void*)f_711},
{"f_680batch-driver.scm",(void*)f_680},
{"f_621batch-driver.scm",(void*)f_621},
{"f_667batch-driver.scm",(void*)f_667},
{"f_625batch-driver.scm",(void*)f_625},
{"f_631batch-driver.scm",(void*)f_631},
{"f_646batch-driver.scm",(void*)f_646},
{"f_642batch-driver.scm",(void*)f_642},
{"f_628batch-driver.scm",(void*)f_628},
{"f_609batch-driver.scm",(void*)f_609},
{"f_616batch-driver.scm",(void*)f_616},
{"f_594batch-driver.scm",(void*)f_594},
{"f_601batch-driver.scm",(void*)f_601},
{"f_604batch-driver.scm",(void*)f_604},
{"f_572batch-driver.scm",(void*)f_572},
{"f_579batch-driver.scm",(void*)f_579},
{"f_592batch-driver.scm",(void*)f_592},
{"f_554batch-driver.scm",(void*)f_554},
{"f_558batch-driver.scm",(void*)f_558},
{"f_567batch-driver.scm",(void*)f_567},
{"f_548batch-driver.scm",(void*)f_548},
{"f_446batch-driver.scm",(void*)f_446},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
