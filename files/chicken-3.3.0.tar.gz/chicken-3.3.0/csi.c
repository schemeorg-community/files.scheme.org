/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-06-28 12:19
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10664	compiled 2008-06-28 on galinha (Linux)
   command line: csi.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -output-file csi.c -extend private-namespace.scm
   used units: library eval data_structures extras srfi_69 match srfi_69 ports
*/

#include "chicken.h"

#if (defined(_MSC_VER) && defined(_WIN32)) || defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_match_toplevel)
C_externimport void C_ccall C_match_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[559];
static double C_possibly_force_alignment;


/* from k1499 */
static C_word C_fcall stub486(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub486(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1083)
static void C_ccall f_1083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1098)
static void C_ccall f_1098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8736)
static void C_ccall f_8736(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8736)
static void C_ccall f_8736r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8740)
static void C_ccall f_8740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8743)
static void C_ccall f_8743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8746)
static void C_ccall f_8746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8752)
static void C_ccall f_8752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8958)
static void C_ccall f_8958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8938)
static void C_ccall f_8938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8934)
static void C_ccall f_8934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8914)
static void C_ccall f_8914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8777)
static void C_fcall f_8777(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8787)
static void C_ccall f_8787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8906)
static void C_ccall f_8906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8790)
static void C_ccall f_8790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8902)
static void C_ccall f_8902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8793)
static void C_ccall f_8793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8824)
static void C_fcall f_8824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8804)
static void C_ccall f_8804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8775)
static void C_ccall f_8775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8648)
static void C_ccall f_8648(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8648)
static void C_ccall f_8648r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8665)
static void C_ccall f_8665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8668)
static void C_ccall f_8668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8674)
static void C_fcall f_8674(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8607)
static void C_ccall f_8607(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8607)
static void C_ccall f_8607r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8611)
static void C_ccall f_8611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8591)
static void C_ccall f_8591(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8591)
static void C_ccall f_8591r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8601)
static void C_ccall f_8601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8599)
static void C_ccall f_8599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1110)
static void C_ccall f_1110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8514)
static void C_ccall f_8514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8518)
static void C_ccall f_8518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8586)
static void C_ccall f_8586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8521)
static void C_ccall f_8521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8530)
static void C_ccall f_8530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8577)
static void C_ccall f_8577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8544)
static void C_ccall f_8544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8552)
static void C_ccall f_8552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8554)
static void C_fcall f_8554(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8571)
static void C_ccall f_8571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8536)
static void C_ccall f_8536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8528)
static void C_ccall f_8528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8454)
static void C_ccall f_8454(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8454)
static void C_ccall f_8454r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8458)
static void C_fcall f_8458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1116)
static void C_ccall f_1116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8395)
static void C_ccall f_8395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8395)
static void C_ccall f_8395r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8399)
static void C_ccall f_8399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8426)
static void C_fcall f_8426(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1119)
static void C_ccall f_1119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8221)
static void C_ccall f_8221(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8221)
static void C_ccall f_8221r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8225)
static void C_ccall f_8225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8228)
static void C_ccall f_8228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8389)
static void C_ccall f_8389(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8231)
static void C_ccall f_8231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8383)
static void C_ccall f_8383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8234)
static void C_ccall f_8234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8381)
static void C_ccall f_8381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8345)
static void C_ccall f_8345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8359)
static void C_fcall f_8359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8373)
static void C_ccall f_8373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8353)
static void C_ccall f_8353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8349)
static void C_ccall f_8349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8241)
static void C_ccall f_8241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8313)
static void C_ccall f_8313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8331)
static void C_ccall f_8331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8321)
static void C_ccall f_8321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8317)
static void C_ccall f_8317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8309)
static void C_ccall f_8309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8293)
static void C_ccall f_8293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8287)
static void C_ccall f_8287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8273)
static void C_ccall f_8273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8126)
static void C_ccall f_8126(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8126)
static void C_ccall f_8126r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8162)
static void C_fcall f_8162(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8175)
static void C_ccall f_8175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1125)
static void C_ccall f_1125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8016)
static void C_ccall f_8016(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8016)
static void C_ccall f_8016r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8020)
static void C_ccall f_8020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8023)
static void C_ccall f_8023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8026)
static void C_ccall f_8026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8029)
static void C_ccall f_8029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8120)
static void C_ccall f_8120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8032)
static void C_ccall f_8032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8114)
static void C_ccall f_8114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8035)
static void C_ccall f_8035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8108)
static void C_ccall f_8108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8112)
static void C_ccall f_8112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8042)
static void C_ccall f_8042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8080)
static void C_ccall f_8080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8078)
static void C_ccall f_8078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8006)
static void C_ccall f_8006(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8006)
static void C_ccall f_8006r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7992)
static void C_ccall f_7992(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7992)
static void C_ccall f_7992r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1134)
static void C_ccall f_1134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1211)
static void C_ccall f_1211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7730)
static void C_ccall f_7730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7734)
static void C_ccall f_7734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7743)
static void C_ccall f_7743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7952)
static void C_fcall f_7952(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7965)
static void C_ccall f_7965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7746)
static void C_ccall f_7746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7942)
static void C_ccall f_7942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7749)
static void C_ccall f_7749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_fcall f_7896(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7929)
static void C_ccall f_7929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7936)
static void C_ccall f_7936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7912)
static void C_fcall f_7912(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7761)
static void C_ccall f_7761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7768)
static void C_ccall f_7768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7770)
static void C_fcall f_7770(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7884)
static void C_ccall f_7884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7804)
static void C_fcall f_7804(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7858)
static void C_ccall f_7858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7815)
static void C_ccall f_7815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7790)
static void C_ccall f_7790(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7798)
static void C_ccall f_7798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7788)
static void C_ccall f_7788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7750)
static void C_ccall f_7750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7690)
static void C_fcall f_7690(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7713)
static void C_ccall f_7713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7659)
static void C_fcall f_7659(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7680)
static void C_ccall f_7680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7608)
static void C_ccall f_7608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7612)
static void C_ccall f_7612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7623)
static void C_fcall f_7623(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7648)
static void C_ccall f_7648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1217)
static void C_ccall f_1217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7488)
static void C_ccall f_7488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7492)
static void C_ccall f_7492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7602)
static void C_ccall f_7602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7501)
static void C_ccall f_7501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7588)
static void C_ccall f_7588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7596)
static void C_ccall f_7596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7504)
static void C_ccall f_7504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7582)
static void C_ccall f_7582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7524)
static void C_ccall f_7524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7534)
static void C_ccall f_7534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7554)
static void C_ccall f_7554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7560)
static void C_ccall f_7560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7568)
static void C_ccall f_7568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7532)
static void C_ccall f_7532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7528)
static void C_ccall f_7528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7471)
static void C_ccall f_7471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1223)
static void C_ccall f_1223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7457)
static void C_ccall f_7457(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_fcall f_1238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1254)
static void C_fcall f_1254(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7436)
static void C_ccall f_7436(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1305)
static void C_ccall f_1305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7320)
static void C_ccall f_7320(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7324)
static void C_ccall f_7324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7333)
static void C_fcall f_7333(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7347)
static void C_fcall f_7347(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7393)
static void C_ccall f_7393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7376)
static void C_ccall f_7376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1308)
static void C_ccall f_1308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7221)
static void C_ccall f_7221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7231)
static void C_ccall f_7231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7244)
static void C_fcall f_7244(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7260)
static void C_ccall f_7260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7298)
static void C_ccall f_7298(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7296)
static void C_ccall f_7296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7288)
static void C_ccall f_7288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7242)
static void C_ccall f_7242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7132)
static void C_ccall f_7132(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7142)
static void C_ccall f_7142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7155)
static void C_fcall f_7155(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7171)
static void C_ccall f_7171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7199)
static void C_ccall f_7199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7153)
static void C_ccall f_7153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6846)
static void C_ccall f_6846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6846)
static void C_ccall f_6846r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7043)
static void C_ccall f_7043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7122)
static void C_ccall f_7122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7130)
static void C_ccall f_7130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7065)
static void C_ccall f_7065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7068)
static void C_ccall f_7068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7077)
static void C_ccall f_7077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6861)
static void C_ccall f_6861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_fcall f_6867(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6920)
static void C_ccall f_6920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6888)
static void C_ccall f_6888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6940)
static void C_fcall f_6940(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7004)
static void C_ccall f_7004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7083)
static void C_ccall f_7083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7050)
static void C_fcall f_7050(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7062)
static void C_ccall f_7062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6783)
static void C_ccall f_6783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6630)
static void C_ccall f_6630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6630)
static void C_ccall f_6630r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6640)
static void C_ccall f_6640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6653)
static void C_fcall f_6653(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6651)
static void C_ccall f_6651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6388)
static void C_ccall f_6388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6617)
static void C_ccall f_6617(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6615)
static void C_ccall f_6615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6394)
static void C_ccall f_6394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_fcall f_6363(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6377)
static void C_ccall f_6377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6397)
static void C_ccall f_6397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6400)
static void C_ccall f_6400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6424)
static void C_ccall f_6424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6448)
static void C_fcall f_6448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6464)
static void C_ccall f_6464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6483)
static void C_fcall f_6483(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6481)
static void C_ccall f_6481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6462)
static void C_ccall f_6462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6337)
static void C_ccall f_6337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6307)
static void C_ccall f_6307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6228)
static void C_ccall f_6228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6187)
static void C_ccall f_6187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6183)
static void C_ccall f_6183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6046)
static void C_ccall f_6046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6132)
static void C_ccall f_6132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6102)
static void C_fcall f_6102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6069)
static void C_fcall f_6069(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5847)
static void C_ccall f_5847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5847)
static void C_ccall f_5847r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6026)
static void C_ccall f_6026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5879)
static void C_fcall f_5879(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5905)
static void C_fcall f_5905(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_fcall f_5933(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5838)
static void C_ccall f_5838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5842)
static void C_ccall f_5842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1344)
static void C_ccall f_1344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5832)
static void C_ccall f_5832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5830)
static void C_ccall f_5830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5811)
static void C_ccall f_5811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5678)
static void C_fcall f_5678(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5697)
static void C_ccall f_5697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5535)
static void C_fcall f_5535(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5647)
static void C_ccall f_5647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5545)
static void C_ccall f_5545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5565)
static void C_ccall f_5565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5581)
static void C_ccall f_5581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5305)
static void C_fcall f_5305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5379)
static void C_fcall f_5379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_ccall f_5382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5406)
static void C_ccall f_5406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5315)
static void C_fcall f_5315(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1362)
static void C_ccall f_1362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5198)
static void C_fcall f_5198(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5217)
static void C_ccall f_5217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1371)
static void C_ccall f_1371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1724)
static void C_ccall f_1724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_fcall f_5107(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5057)
static void C_ccall f_5057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_fcall f_4449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_fcall f_4455(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_fcall f_4616(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4622)
static void C_ccall f_4622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_fcall f_4628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4951)
static void C_ccall f_4951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4528)
static void C_ccall f_4528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_fcall f_4662(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4820)
static void C_fcall f_4820(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4846)
static void C_fcall f_4846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4771)
static void C_ccall f_4771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4719)
static void C_ccall f_4719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_fcall f_4546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4562)
static void C_fcall f_4562(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4466)
static void C_fcall f_4466(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4472)
static void C_fcall f_4472(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4290)
static void C_fcall f_4290(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_fcall f_4296(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4318)
static void C_fcall f_4318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4407)
static C_word C_fcall f_4407(C_word t0);
C_noret_decl(f_4233)
static void C_fcall f_4233(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4239)
static void C_fcall f_4239(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4251)
static void C_fcall f_4251(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_fcall f_4183(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3997)
static void C_fcall f_3997(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_fcall f_4082(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4119)
static void C_fcall f_4119(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_fcall f_4031(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_fcall f_3968(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3917)
static void C_fcall f_3917(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_fcall f_3912(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3806)
static void C_fcall f_3806(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_fcall f_3874(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3838)
static void C_ccall f_3838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_fcall f_3809(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3634)
static void C_fcall f_3634(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_fcall f_3473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3378)
static void C_fcall f_3378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_fcall f_3314(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_fcall f_3058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_fcall f_3090(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_fcall f_2866(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_fcall f_2809(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2750)
static void C_ccall f_2750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2384)
static void C_fcall f_2384(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2340)
static void C_fcall f_2340(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1813)
static void C_fcall f_1813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_fcall f_2630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_ccall f_2472(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_fcall f_1670(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_fcall f_1614(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1627)
static void C_ccall f_1627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1533)
static C_word C_fcall f_1533(C_word t0,C_word t1);
C_noret_decl(f_1506)
static void C_fcall f_1506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static C_word C_fcall f_1444(C_word t0);
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1422)
static void C_ccall f_1422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1395)
static void C_ccall f_1395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1176)
static void C_ccall f_1176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8777)
static void C_fcall trf_8777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8777(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8777(t0,t1,t2,t3);}

C_noret_decl(trf_8824)
static void C_fcall trf_8824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8824(t0,t1);}

C_noret_decl(trf_8674)
static void C_fcall trf_8674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8674(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8674(t0,t1);}

C_noret_decl(trf_8554)
static void C_fcall trf_8554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8554(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8554(t0,t1,t2,t3);}

C_noret_decl(trf_8458)
static void C_fcall trf_8458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8458(t0,t1);}

C_noret_decl(trf_8426)
static void C_fcall trf_8426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8426(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8426(t0,t1);}

C_noret_decl(trf_8359)
static void C_fcall trf_8359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8359(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8359(t0,t1,t2);}

C_noret_decl(trf_8162)
static void C_fcall trf_8162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8162(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8162(t0,t1,t2);}

C_noret_decl(trf_7952)
static void C_fcall trf_7952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7952(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7952(t0,t1,t2,t3);}

C_noret_decl(trf_7896)
static void C_fcall trf_7896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7896(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7896(t0,t1,t2,t3);}

C_noret_decl(trf_7912)
static void C_fcall trf_7912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7912(t0,t1);}

C_noret_decl(trf_7770)
static void C_fcall trf_7770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7770(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7770(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7804)
static void C_fcall trf_7804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7804(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7804(t0,t1);}

C_noret_decl(trf_7690)
static void C_fcall trf_7690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7690(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7690(t0,t1,t2,t3);}

C_noret_decl(trf_7659)
static void C_fcall trf_7659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7659(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7659(t0,t1,t2,t3);}

C_noret_decl(trf_7623)
static void C_fcall trf_7623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7623(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7623(t0,t1,t2);}

C_noret_decl(trf_1238)
static void C_fcall trf_1238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1238(t0,t1);}

C_noret_decl(trf_1254)
static void C_fcall trf_1254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1254(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1254(t0,t1);}

C_noret_decl(trf_7333)
static void C_fcall trf_7333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7333(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7333(t0,t1);}

C_noret_decl(trf_7347)
static void C_fcall trf_7347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7347(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7347(t0,t1,t2);}

C_noret_decl(trf_7244)
static void C_fcall trf_7244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7244(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7244(t0,t1,t2);}

C_noret_decl(trf_7155)
static void C_fcall trf_7155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7155(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7155(t0,t1,t2);}

C_noret_decl(trf_6867)
static void C_fcall trf_6867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6867(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6867(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6940)
static void C_fcall trf_6940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6940(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6940(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7050)
static void C_fcall trf_7050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7050(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7050(t0,t1,t2);}

C_noret_decl(trf_6653)
static void C_fcall trf_6653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6653(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6653(t0,t1,t2,t3);}

C_noret_decl(trf_6363)
static void C_fcall trf_6363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6363(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6363(t0,t1,t2);}

C_noret_decl(trf_6448)
static void C_fcall trf_6448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6448(t0,t1);}

C_noret_decl(trf_6483)
static void C_fcall trf_6483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6483(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6483(t0,t1,t2,t3);}

C_noret_decl(trf_6102)
static void C_fcall trf_6102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6102(t0,t1);}

C_noret_decl(trf_6069)
static void C_fcall trf_6069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6069(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6069(t0,t1);}

C_noret_decl(trf_5879)
static void C_fcall trf_5879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5879(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5879(t0,t1,t2,t3);}

C_noret_decl(trf_5905)
static void C_fcall trf_5905(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5905(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5905(t0,t1);}

C_noret_decl(trf_5933)
static void C_fcall trf_5933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5933(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5933(t0,t1);}

C_noret_decl(trf_5678)
static void C_fcall trf_5678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5678(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5678(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5535)
static void C_fcall trf_5535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5535(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5535(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5305)
static void C_fcall trf_5305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5305(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5305(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5379)
static void C_fcall trf_5379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5379(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5379(t0,t1);}

C_noret_decl(trf_5315)
static void C_fcall trf_5315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5315(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5315(t0,t1);}

C_noret_decl(trf_5198)
static void C_fcall trf_5198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5198(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5198(t0,t1);}

C_noret_decl(trf_5107)
static void C_fcall trf_5107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5107(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5107(t0,t1);}

C_noret_decl(trf_4449)
static void C_fcall trf_4449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4449(t0,t1);}

C_noret_decl(trf_4455)
static void C_fcall trf_4455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4455(t0,t1);}

C_noret_decl(trf_4616)
static void C_fcall trf_4616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4616(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4616(t0,t1);}

C_noret_decl(trf_4628)
static void C_fcall trf_4628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4628(t0,t1);}

C_noret_decl(trf_4662)
static void C_fcall trf_4662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4662(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4662(t0,t1,t2);}

C_noret_decl(trf_4820)
static void C_fcall trf_4820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4820(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4820(t0,t1);}

C_noret_decl(trf_4846)
static void C_fcall trf_4846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4846(t0,t1);}

C_noret_decl(trf_4546)
static void C_fcall trf_4546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4546(t0,t1,t2);}

C_noret_decl(trf_4562)
static void C_fcall trf_4562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4562(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4562(t0,t1,t2);}

C_noret_decl(trf_4466)
static void C_fcall trf_4466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4466(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4466(t0,t1,t2);}

C_noret_decl(trf_4472)
static void C_fcall trf_4472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4472(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4472(t0,t1,t2);}

C_noret_decl(trf_4290)
static void C_fcall trf_4290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4290(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4290(t0,t1);}

C_noret_decl(trf_4296)
static void C_fcall trf_4296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4296(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4296(t0,t1,t2);}

C_noret_decl(trf_4318)
static void C_fcall trf_4318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4318(t0,t1);}

C_noret_decl(trf_4233)
static void C_fcall trf_4233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4233(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4233(t0,t1,t2);}

C_noret_decl(trf_4239)
static void C_fcall trf_4239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4239(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4239(t0,t1,t2);}

C_noret_decl(trf_4251)
static void C_fcall trf_4251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4251(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4251(t0,t1,t2);}

C_noret_decl(trf_4183)
static void C_fcall trf_4183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4183(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4183(t0,t1,t2);}

C_noret_decl(trf_3997)
static void C_fcall trf_3997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3997(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3997(t0,t1,t2);}

C_noret_decl(trf_4082)
static void C_fcall trf_4082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4082(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4082(t0,t1,t2,t3);}

C_noret_decl(trf_4119)
static void C_fcall trf_4119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4119(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4119(t0,t1,t2);}

C_noret_decl(trf_4031)
static void C_fcall trf_4031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4031(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4031(t0,t1,t2,t3);}

C_noret_decl(trf_3968)
static void C_fcall trf_3968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3968(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3968(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3917)
static void C_fcall trf_3917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3917(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3917(t0,t1);}

C_noret_decl(trf_3912)
static void C_fcall trf_3912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3912(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3912(t0,t1,t2);}

C_noret_decl(trf_3806)
static void C_fcall trf_3806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3806(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3806(t0,t1,t2,t3);}

C_noret_decl(trf_3874)
static void C_fcall trf_3874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3874(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3874(t0,t1);}

C_noret_decl(trf_3809)
static void C_fcall trf_3809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3809(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3809(t0,t1,t2);}

C_noret_decl(trf_3634)
static void C_fcall trf_3634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3634(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3634(t0,t1,t2);}

C_noret_decl(trf_3473)
static void C_fcall trf_3473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3473(t0,t1);}

C_noret_decl(trf_3378)
static void C_fcall trf_3378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3378(t0,t1);}

C_noret_decl(trf_3314)
static void C_fcall trf_3314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3314(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3314(t0,t1);}

C_noret_decl(trf_3058)
static void C_fcall trf_3058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3058(t0,t1,t2);}

C_noret_decl(trf_3090)
static void C_fcall trf_3090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3090(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3090(t0,t1,t2,t3);}

C_noret_decl(trf_2866)
static void C_fcall trf_2866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2866(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2866(t0,t1);}

C_noret_decl(trf_2809)
static void C_fcall trf_2809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2809(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2809(t0,t1,t2,t3);}

C_noret_decl(trf_2384)
static void C_fcall trf_2384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2384(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2384(t0,t1,t2);}

C_noret_decl(trf_2340)
static void C_fcall trf_2340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2340(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2340(t0,t1,t2);}

C_noret_decl(trf_1813)
static void C_fcall trf_1813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1813(t0,t1);}

C_noret_decl(trf_2630)
static void C_fcall trf_2630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2630(t0,t1);}

C_noret_decl(trf_1670)
static void C_fcall trf_1670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1670(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1670(t0,t1);}

C_noret_decl(trf_1614)
static void C_fcall trf_1614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1614(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1614(t0,t1,t2);}

C_noret_decl(trf_1506)
static void C_fcall trf_1506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1506(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4678)){
C_save(t1);
C_rereclaim2(4678*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,559);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],3,"map");
lf[3]=C_h_intern(&lf[3],6,"lambda");
lf[4]=C_h_intern(&lf[4],14,"\004coreundefined");
lf[5]=C_h_intern(&lf[5],20,"\003syscall-with-values");
lf[6]=C_h_intern(&lf[6],9,"\004coreset!");
lf[7]=C_h_intern(&lf[7],6,"gensym");
lf[8]=C_h_intern(&lf[8],16,"\003syscheck-syntax");
lf[9]=C_h_intern(&lf[9],25,"set!-values/define-values");
lf[10]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000C\012CHICKEN\012(c)2008 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[13]=C_h_intern(&lf[13],19,"\003sysundefined-value");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[16]=C_h_intern(&lf[16],27,"\003sysrepl-print-length-limit");
lf[17]=C_h_intern(&lf[17],4,"\000csi");
lf[18]=C_h_intern(&lf[18],12,"\003sysfeatures");
lf[19]=C_h_intern(&lf[19],15,"\003csiprint-usage");
lf[20]=C_h_intern(&lf[20],7,"display");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\002\042\047\012    -b  -batch                  terminate after command-line processing\012 "
"   -w  -no-warnings            disable all warnings\012    -k  -keyword-style STYLE"
"    enable alternative keyword-syntax (none, prefix or suffix)\012    -s  -script P"
"ATHNAME        use interpreter for shell scripts\012        -ss PATHNAME           "
" shell script with `main\047 procedure\012    -R  -require-extension NAME require exte"
"nsion before executing code\012    -I  -include-path PATHNAME  add PATHNAME to incl"
"ude path\012    --                          ignore all following options\012\012");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\002\257Usage: csi {FILENAME | OPTION}\012\012  where OPTION may be one of the following:"
"\012\012    -h  -help  --help           display this text and exit\012    -v  -version   "
"             display version and exit\012        -release                print rele"
"ase number and exit\012    -i  -case-insensitive       enable case-insensitive read"
"ing\012    -e  -eval EXPRESSION        evaluate given expression\012    -p  -print EXP"
"RESSION       evaluate and print result(s)\012    -P  -pretty-print EXPRESSION  eva"
"luate and print result(s) prettily\012    -D  -feature SYMBOL         register feat"
"ure identifier\012    -q  -quiet                  do not print banner\012    -n  -no-i"
"nit                do not load initialization file `");
lf[23]=C_h_intern(&lf[23],16,"\003csiprint-banner");
lf[24]=C_h_intern(&lf[24],5,"print");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[26]=C_h_intern(&lf[26],15,"chicken-version");
lf[27]=C_h_intern(&lf[27],9,"read-char");
lf[28]=C_h_intern(&lf[28],4,"read");
lf[29]=C_h_intern(&lf[29],18,"\003sysuser-read-hook");
lf[30]=C_h_intern(&lf[30],5,"quote");
lf[31]=C_h_intern(&lf[31],17,"\003csihistory-count");
lf[32]=C_h_intern(&lf[32],15,"\003csihistory-ref");
lf[33]=C_h_intern(&lf[33],21,"\003syssharp-number-hook");
lf[35]=C_h_intern(&lf[35],9,"substring");
lf[36]=C_h_intern(&lf[36],18,"\003csichop-separator");
lf[37]=C_h_intern(&lf[37],4,"sub1");
lf[38]=C_h_intern(&lf[38],1,"@");
lf[39]=C_h_intern(&lf[39],12,"file-exists\077");
lf[40]=C_h_intern(&lf[40],13,"string-append");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[42]=C_h_intern(&lf[42],22,"\003csilookup-script-file");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[44]=C_h_intern(&lf[44],25,"\003syspeek-nonnull-c-string");
lf[45]=C_h_intern(&lf[45],12,"string-split");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[48]=C_h_intern(&lf[48],6,"getenv");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[50]=C_h_intern(&lf[50],16,"\003csihistory-list");
lf[51]=C_h_intern(&lf[51],13,"vector-resize");
lf[52]=C_h_intern(&lf[52],15,"\003csihistory-add");
lf[53]=C_h_intern(&lf[53],9,"\003syserror");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[55]=C_h_intern(&lf[55],14,"\003csitty-input\077");
lf[56]=C_h_intern(&lf[56],13,"\003systty-port\077");
lf[57]=C_h_intern(&lf[57],18,"\003sysstandard-input");
lf[58]=C_h_intern(&lf[58],18,"\003sysbreak-on-error");
lf[59]=C_h_intern(&lf[59],20,"\003sysread-prompt-hook");
lf[61]=C_h_intern(&lf[61],15,"hash-table-set!");
lf[62]=C_h_intern(&lf[62],16,"toplevel-command");
lf[63]=C_h_intern(&lf[63],4,"eval");
lf[64]=C_h_intern(&lf[64],12,"load-noisily");
lf[65]=C_h_intern(&lf[65],10,"singlestep");
lf[66]=C_h_intern(&lf[66],14,"hash-table-ref");
lf[67]=C_h_intern(&lf[67],15,"hash-table-walk");
lf[68]=C_h_intern(&lf[68],9,"read-line");
lf[69]=C_h_intern(&lf[69],6,"length");
lf[70]=C_h_intern(&lf[70],5,"write");
lf[71]=C_h_intern(&lf[71],6,"printf");
lf[72]=C_h_intern(&lf[72],12,"pretty-print");
lf[73]=C_h_intern(&lf[73],8,"integer\077");
lf[74]=C_h_intern(&lf[74],6,"values");
lf[75]=C_h_intern(&lf[75],18,"\003sysrepl-eval-hook");
lf[76]=C_h_intern(&lf[76],22,"\003csitrace-indent-level");
lf[77]=C_h_intern(&lf[77],4,"exit");
lf[78]=C_h_intern(&lf[78],1,"x");
lf[79]=C_h_intern(&lf[79],11,"macroexpand");
lf[80]=C_h_intern(&lf[80],1,"p");
lf[81]=C_h_intern(&lf[81],1,"d");
lf[82]=C_h_intern(&lf[82],12,"\003csidescribe");
lf[83]=C_h_intern(&lf[83],2,"du");
lf[84]=C_h_intern(&lf[84],8,"\003csidump");
lf[85]=C_h_intern(&lf[85],3,"dur");
lf[86]=C_h_intern(&lf[86],1,"r");
lf[87]=C_h_intern(&lf[87],10,"\003csireport");
lf[88]=C_h_intern(&lf[88],1,"q");
lf[89]=C_h_intern(&lf[89],1,"l");
lf[90]=C_h_intern(&lf[90],12,"\003sysfor-each");
lf[91]=C_h_intern(&lf[91],4,"load");
lf[92]=C_h_intern(&lf[92],2,"ln");
lf[93]=C_h_intern(&lf[93],6,"print*");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[95]=C_h_intern(&lf[95],8,"\000printer");
lf[96]=C_h_intern(&lf[96],1,"t");
lf[97]=C_h_intern(&lf[97],17,"\003sysdisplay-times");
lf[98]=C_h_intern(&lf[98],14,"\003sysstop-timer");
lf[99]=C_h_intern(&lf[99],15,"\003sysstart-timer");
lf[100]=C_h_intern(&lf[100],2,"tr");
lf[102]=C_h_intern(&lf[102],8,"\003syswarn");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure already traced");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000 procedure already has breakpoint");
lf[106]=C_h_intern(&lf[106],25,"\003csitraced-procedure-exit");
lf[107]=C_h_intern(&lf[107],26,"\003csitraced-procedure-entry");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\033can not trace non-procedure");
lf[109]=C_h_intern(&lf[109],7,"\003sysmap");
lf[110]=C_h_intern(&lf[110],14,"string->symbol");
lf[111]=C_h_intern(&lf[111],3,"utr");
lf[112]=C_h_intern(&lf[112],7,"\003csidel");
lf[113]=C_h_intern(&lf[113],3,"eq\077");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\024procedure not traced");
lf[115]=C_h_intern(&lf[115],2,"br");
lf[116]=C_h_intern(&lf[116],1,"a");
lf[117]=C_h_intern(&lf[117],15,"\003sysbreak-entry");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\047can not set breakpoint on non-procedure");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\024un-tracing procedure");
lf[120]=C_h_intern(&lf[120],3,"ubr");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\033procedure has no breakpoint");
lf[122]=C_h_intern(&lf[122],3,"uba");
lf[123]=C_h_intern(&lf[123],14,"do-unbreak-all");
lf[124]=C_h_intern(&lf[124],8,"breakall");
lf[125]=C_h_intern(&lf[125],19,"\003sysbreak-in-thread");
lf[126]=C_h_intern(&lf[126],9,"breakonly");
lf[127]=C_h_intern(&lf[127],4,"info");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\021Breakpoints: ~s~%");
lf[129]=C_h_intern(&lf[129],3,"car");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\014Traced: ~s~%");
lf[131]=C_h_intern(&lf[131],1,"c");
lf[132]=C_h_intern(&lf[132],19,"\003syslast-breakpoint");
lf[133]=C_h_intern(&lf[133],16,"\003sysbreak-resume");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\026no breakpoint pending\012");
lf[135]=C_h_intern(&lf[135],3,"exn");
lf[136]=C_h_intern(&lf[136],18,"\003syslast-exception");
lf[137]=C_h_intern(&lf[137],4,"step");
lf[138]=C_h_intern(&lf[138],1,"s");
lf[139]=C_h_intern(&lf[139],6,"system");
lf[140]=C_h_intern(&lf[140],1,"\077");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\004TToplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,s TEXT ...   "
"    Execute shell-command\012 ,tr NAME ...      Trace procedures\012 ,utr NAME ...    "
" Untrace procedures\012 ,br NAME ...      Set breakpoints\012 ,ubr NAME ...     Remove"
" breakpoints\012 ,uba              Remove all breakpoints\012 ,breakall         Break "
"in all threads (default)\012 ,breakonly THREAD Break only in specified thread\012 ,c  "
"              Continue from breakpoint\012 ,info             List traced procedures"
" and breakpoints\012 ,step EXPR        Execute EXPR in single-stepping mode\012 ,exn  "
"            Describe last exception\012 ,t EXP            Evaluate form and print e"
"lapsed time\012 ,x EXP            Pretty print macroexpanded expression EXP\012");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\0005Undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[144]=C_h_intern(&lf[144],22,"hash-table-ref/default");
lf[145]=C_h_intern(&lf[145],7,"unquote");
lf[146]=C_h_intern(&lf[146],16,"\003csitrace-indent");
lf[147]=C_h_intern(&lf[147],19,"\003syswrite-char/port");
lf[148]=C_h_intern(&lf[148],19,"\003sysstandard-output");
lf[149]=C_h_intern(&lf[149],12,"flush-output");
lf[150]=C_h_intern(&lf[150],16,"\003syswrite-char-0");
lf[151]=C_h_intern(&lf[151],4,"add1");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[153]=C_h_intern(&lf[153],23,"\003csiparse-option-string");
lf[154]=C_h_intern(&lf[154],17,"get-output-string");
lf[155]=C_h_intern(&lf[155],18,"open-output-string");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[157]=C_h_intern(&lf[157],7,"reverse");
lf[158]=C_h_intern(&lf[158],22,"with-exception-handler");
lf[159]=C_h_intern(&lf[159],30,"call-with-current-continuation");
lf[160]=C_h_intern(&lf[160],17,"open-input-string");
lf[161]=C_h_intern(&lf[161],4,"chop");
lf[162]=C_h_intern(&lf[162],4,"sort");
lf[163]=C_h_intern(&lf[163],19,"with-output-to-port");
lf[164]=C_h_intern(&lf[164],19,"current-output-port");
lf[165]=C_h_intern(&lf[165],8,"truncate");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\001\374~%~\012                   Machine type:    \011~A ~A~%~\012                   Softwa"
"re type:   \011~A~%~\012                   Software version:\011~A~%~\012                   "
"Build platform:  \011~A~%~\012                   Include path:    \011~A~%~\012             "
"      Symbol-table load:\011~S~%  ~\012                     Avg bucket length:\011~S~%  ~"
"\012                     Total symbols:\011~S~%~\012                   Memory:\011heap size "
"is ~S bytes~A with ~S bytes currently in use~%~  \012                     nursery s"
"ize is ~S bytes, stack grows ~A~%");
lf[175]=C_h_intern(&lf[175],21,"\003sysinclude-pathnames");
lf[176]=C_h_intern(&lf[176],14,"build-platform");
lf[177]=C_h_intern(&lf[177],16,"software-version");
lf[178]=C_h_intern(&lf[178],13,"software-type");
lf[179]=C_h_intern(&lf[179],12,"machine-type");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[181]=C_h_intern(&lf[181],11,"make-string");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[183]=C_h_intern(&lf[183],8,"string<\077");
lf[184]=C_h_intern(&lf[184],15,"keyword->string");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[186]=C_h_intern(&lf[186],17,"memory-statistics");
lf[187]=C_h_intern(&lf[187],21,"\003syssymbol-table-info");
lf[188]=C_h_intern(&lf[188],2,"gc");
lf[189]=C_h_intern(&lf[189],19,"\003csibytevector-data");
lf[190]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[192]=C_h_intern(&lf[192],7,"sprintf");
lf[193]=C_h_intern(&lf[193],7,"fprintf");
lf[194]=C_h_intern(&lf[194],8,"list-ref");
lf[195]=C_h_intern(&lf[195],10,"string-ref");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[200]=C_h_intern(&lf[200],7,"newline");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\042exact integer ~S, #x~X, #o~O, #b~B");
lf[211]=C_h_intern(&lf[211],28,"\003sysarbitrary-unbound-symbol");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[215]=C_h_intern(&lf[215],8,"\003syssize");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[217]=C_h_intern(&lf[217],8,"\003sysslot");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol with name ~S~%");
lf[219]=C_h_intern(&lf[219],18,"\003syssymbol->string");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\010keyword ");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[222]=C_h_intern(&lf[222],32,"\003syssymbol-has-toplevel-binding\077");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\035pair with car ~S and cdr ~S~%");
lf[225]=C_h_intern(&lf[225],15,"describe-object");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\036procedure with code pointer ~X");
lf[227]=C_h_intern(&lf[227],25,"\003syspeek-unsigned-integer");
lf[228]=C_h_intern(&lf[228],9,"\000tinyclos");
lf[229]=C_h_intern(&lf[229],19,"\010tinyclosentity-tag");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[245]=C_h_intern(&lf[245],11,"\003csihexdump");
lf[246]=C_h_intern(&lf[246],8,"\003sysbyte");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[249]=C_h_intern(&lf[249],23,"\003syslambda-info->string");
lf[250]=C_h_intern(&lf[250],10,"hash-table");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[256]=C_h_intern(&lf[256],9,"condition");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\011\011~s: ~s~%");
lf[258]=C_h_intern(&lf[258],4,"cdar");
lf[259]=C_h_intern(&lf[259],4,"caar");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[262]=C_h_intern(&lf[262],6,"unveil");
lf[263]=C_h_intern(&lf[263],6,"append");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[266]=C_h_intern(&lf[266],15,"meroon-instance");
lf[267]=C_h_intern(&lf[267],9,"provided\077");
lf[268]=C_h_intern(&lf[268],6,"meroon");
lf[269]=C_h_intern(&lf[269],15,"\003sysbytevector\077");
lf[270]=C_h_intern(&lf[270],13,"\003syslocative\077");
lf[271]=C_h_intern(&lf[271],9,"instance\077");
lf[272]=C_h_intern(&lf[272],5,"port\077");
lf[273]=C_h_intern(&lf[273],11,"\003sysnumber\077");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[275]=C_h_intern(&lf[275],17,"\003sysblock-address");
lf[276]=C_h_intern(&lf[276],14,"set-describer!");
lf[277]=C_h_intern(&lf[277],3,"min");
lf[278]=C_h_intern(&lf[278],4,"dump");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\035can not dump immediate object");
lf[280]=C_h_intern(&lf[280],13,"\003syspeek-byte");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\023can not dump object");
lf[282]=C_h_intern(&lf[282],10,"write-char");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[284]=C_h_intern(&lf[284],5,"fxmod");
lf[285]=C_h_intern(&lf[285],11,"\003csideldups");
lf[286]=C_h_intern(&lf[286],6,"equal\077");
lf[289]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000D\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000i\376\003\000"
"\000\002\376\377\012\000\000R\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000q\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000-\376\003\000\000\002\376\377\012\000\000I\376\003\000\000\002\376"
"\377\012\000\000p\376\003\000\000\002\376\377\012\000\000P\376\377\016");
lf[291]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\016-keyword-style\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376"
"B\000\000\006--help\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-case-insensiti"
"ve\376\003\000\000\002\376B\000\000\022-require-extension\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warn"
"ings\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\015-include-path\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000"
"\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-print\376\377\016");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[298]=C_h_intern(&lf[298],16,"\003sysstring->list");
lf[299]=C_h_intern(&lf[299],7,"\003csirun");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[301]=C_h_intern(&lf[301],8,"\003syslist");
lf[302]=C_h_intern(&lf[302],6,"\000match");
lf[303]=C_h_intern(&lf[303],4,"repl");
lf[304]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\014-no-warn"
"ings\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\002-"
"s\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\003\000\000\002\376B\000\000\003-ss\376\377\016");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[313]=C_h_intern(&lf[313],22,"\004corerequire-extension");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[318]=C_h_intern(&lf[318],8,"for-each");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[321]=C_h_intern(&lf[321],4,"main");
lf[322]=C_h_intern(&lf[322],22,"command-line-arguments");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[327]=C_h_intern(&lf[327],17,"\003sysstring-append");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[329]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[331]=C_h_intern(&lf[331],13,"keyword-style");
lf[332]=C_h_intern(&lf[332],7,"\000prefix");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[334]=C_h_intern(&lf[334],5,"\000none");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[336]=C_h_intern(&lf[336],7,"\000suffix");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[338]=C_h_intern(&lf[338],7,"provide");
lf[339]=C_h_intern(&lf[339],5,"match");
lf[340]=C_h_intern(&lf[340],8,"string=\077");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[343]=C_h_intern(&lf[343],17,"register-feature!");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[346]=C_h_intern(&lf[346],14,"case-sensitive");
lf[347]=C_h_intern(&lf[347],16,"case-insensitive");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[349]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[350]=C_h_intern(&lf[350],12,"load-verbose");
lf[351]=C_h_intern(&lf[351],20,"\003syswarnings-enabled");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[353]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[355]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-v\376\003\000\000\002\376B\000\000\010-version\376\377\016");
lf[356]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[357]=C_h_intern(&lf[357],20,"\003syseval-debug-level");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[362]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[364]=C_h_intern(&lf[364],20,"\003syswindows-platform");
lf[365]=C_h_intern(&lf[365],6,"script");
lf[366]=C_h_intern(&lf[366],12,"program-name");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-k\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[373]=C_h_intern(&lf[373],25,"\003sysimplicit-exit-handler");
lf[374]=C_h_intern(&lf[374],15,"make-hash-table");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\006#;~A> ");
lf[376]=C_h_intern(&lf[376],11,"repl-prompt");
lf[377]=C_h_intern(&lf[377],6,"srfi-8");
lf[378]=C_h_intern(&lf[378],7,"srfi-16");
lf[379]=C_h_intern(&lf[379],7,"srfi-26");
lf[380]=C_h_intern(&lf[380],7,"srfi-31");
lf[381]=C_h_intern(&lf[381],7,"srfi-15");
lf[382]=C_h_intern(&lf[382],7,"srfi-11");
lf[383]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004void\376\377\016\376\377\016");
lf[384]=C_h_intern(&lf[384],25,"\003sysenable-runtime-macros");
lf[385]=C_h_intern(&lf[385],6,"define");
lf[386]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[387]=C_h_intern(&lf[387],12,"syntax-error");
lf[388]=C_h_intern(&lf[388],17,"define-for-syntax");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[390]=C_h_intern(&lf[390],18,"\003sysregister-macro");
lf[391]=C_h_intern(&lf[391],6,"letrec");
lf[392]=C_h_intern(&lf[392],3,"rec");
lf[393]=C_h_intern(&lf[393],22,"chicken-compile-shared");
lf[394]=C_h_intern(&lf[394],3,"not");
lf[395]=C_h_intern(&lf[395],9,"compiling");
lf[396]=C_h_intern(&lf[396],4,"unit");
lf[397]=C_h_intern(&lf[397],7,"declare");
lf[398]=C_h_intern(&lf[398],4,"else");
lf[399]=C_h_intern(&lf[399],11,"cond-expand");
lf[400]=C_h_intern(&lf[400],6,"export");
lf[401]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[402]=C_h_intern(&lf[402],6,"static");
lf[403]=C_h_intern(&lf[403],5,"begin");
lf[404]=C_h_intern(&lf[404],7,"dynamic");
lf[405]=C_h_intern(&lf[405],16,"define-extension");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[408]=C_h_intern(&lf[408],22,"string-parse-start+end");
lf[409]=C_h_intern(&lf[409],7,"receive");
lf[410]=C_h_intern(&lf[410],28,"string-parse-final-start+end");
lf[411]=C_h_intern(&lf[411],20,"let-string-start+end");
lf[412]=C_h_intern(&lf[412],5,"apply");
lf[413]=C_h_intern(&lf[413],3,"let");
lf[414]=C_h_intern(&lf[414],10,"\003sysappend");
lf[415]=C_h_intern(&lf[415],2,"<>");
lf[416]=C_h_intern(&lf[416],5,"<...>");
lf[417]=C_h_intern(&lf[417],20,"\003sysregister-macro-2");
lf[418]=C_h_intern(&lf[418],4,"cute");
lf[419]=C_h_intern(&lf[419],3,"cut");
lf[420]=C_h_intern(&lf[420],3,"use");
lf[421]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[422]=C_h_intern(&lf[422],17,"require-extension");
lf[423]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[424]=C_h_intern(&lf[424],23,"\004corerequire-for-syntax");
lf[425]=C_h_intern(&lf[425],18,"require-for-syntax");
lf[426]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[427]=C_h_intern(&lf[427],18,"\003sysmake-structure");
lf[428]=C_h_intern(&lf[428],14,"\003sysstructure\077");
lf[429]=C_h_intern(&lf[429],15,"\000record-setters");
lf[430]=C_h_intern(&lf[430],19,"\003syscheck-structure");
lf[431]=C_h_intern(&lf[431],10,"\004corecheck");
lf[432]=C_h_intern(&lf[432],13,"\003sysblock-ref");
lf[433]=C_h_intern(&lf[433],18,"getter-with-setter");
lf[434]=C_h_intern(&lf[434],1,"y");
lf[435]=C_h_intern(&lf[435],14,"\003sysblock-set!");
lf[436]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[437]=C_h_intern(&lf[437],18,"define-record-type");
lf[438]=C_h_intern(&lf[438],3,"and");
lf[439]=C_h_intern(&lf[439],4,"memv");
lf[440]=C_h_intern(&lf[440],4,"cond");
lf[441]=C_h_intern(&lf[441],17,"handle-exceptions");
lf[442]=C_h_intern(&lf[442],10,"\003syssignal");
lf[443]=C_h_intern(&lf[443],14,"condition-case");
lf[444]=C_h_intern(&lf[444],9,"\003sysapply");
lf[445]=C_h_intern(&lf[445],10,"\003sysvalues");
lf[446]=C_h_intern(&lf[446],27,"\003sysregister-record-printer");
lf[447]=C_h_intern(&lf[447],21,"define-record-printer");
lf[448]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[449]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[450]=C_h_intern(&lf[450],2,"if");
lf[451]=C_h_intern(&lf[451],9,"split-at!");
lf[452]=C_h_intern(&lf[452],4,"take");
lf[453]=C_h_intern(&lf[453],4,"list");
lf[454]=C_h_intern(&lf[454],3,"cdr");
lf[455]=C_h_intern(&lf[455],4,"fx>=");
lf[456]=C_h_intern(&lf[456],3,"fx=");
lf[457]=C_h_intern(&lf[457],11,"case-lambda");
lf[458]=C_h_intern(&lf[458],11,"lambda-list");
lf[459]=C_h_intern(&lf[459],25,"\003sysdecompose-lambda-list");
lf[460]=C_h_intern(&lf[460],10,"fold-right");
lf[461]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[462]=C_h_intern(&lf[462],7,"require");
lf[463]=C_h_intern(&lf[463],6,"srfi-1");
lf[464]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[465]=C_h_intern(&lf[465],5,"null\077");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[467]=C_h_intern(&lf[467],14,"\004coreimmutable");
lf[468]=C_h_intern(&lf[468],14,"let-optionals*");
lf[469]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[470]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[471]=C_h_intern(&lf[471],8,"optional");
lf[472]=C_h_intern(&lf[472],9,":optional");
lf[473]=C_h_intern(&lf[473],14,"symbol->string");
lf[474]=C_h_intern(&lf[474],4,"let*");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[477]=C_h_intern(&lf[477],5,"%rest");
lf[478]=C_h_intern(&lf[478],4,"body");
lf[479]=C_h_intern(&lf[479],4,"cadr");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[481]=C_h_intern(&lf[481],13,"let-optionals");
lf[482]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[483]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[484]=C_h_intern(&lf[484],4,"eqv\077");
lf[485]=C_h_intern(&lf[485],6,"switch");
lf[486]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[487]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[488]=C_h_intern(&lf[488],2,"or");
lf[489]=C_h_intern(&lf[489],6,"select");
lf[490]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[491]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[492]=C_h_intern(&lf[492],21,"\003syssyntax-error-hook");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\037syntax error in \047and-let*\047 form");
lf[494]=C_h_intern(&lf[494],8,"and-let*");
lf[495]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[496]=C_h_intern(&lf[496],20,"\004coredefine-constant");
lf[497]=C_h_intern(&lf[497],15,"define-constant");
lf[498]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[499]=C_h_intern(&lf[499],18,"\004coredefine-inline");
lf[500]=C_h_intern(&lf[500],13,"define-inline");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[502]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[503]=C_h_intern(&lf[503],9,"nth-value");
lf[504]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[505]=C_h_intern(&lf[505],13,"letrec-values");
lf[506]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[507]=C_h_intern(&lf[507],10,"let-values");
lf[508]=C_h_intern(&lf[508],11,"let*-values");
lf[509]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[510]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[511]=C_h_intern(&lf[511],13,"define-values");
lf[512]=C_h_intern(&lf[512],11,"set!-values");
lf[513]=C_h_intern(&lf[513],6,"unless");
lf[514]=C_h_intern(&lf[514],4,"when");
lf[515]=C_h_intern(&lf[515],16,"\003sysdynamic-wind");
lf[516]=C_h_intern(&lf[516],12,"parameterize");
lf[517]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[518]=C_h_intern(&lf[518],10,"\000compiling");
lf[519]=C_h_intern(&lf[519],19,"\004corecompiletimetoo");
lf[520]=C_h_intern(&lf[520],20,"\004corecompiletimeonly");
lf[521]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[522]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[523]=C_h_intern(&lf[523],8,"run-time");
lf[524]=C_h_intern(&lf[524],7,"compile");
lf[525]=C_h_intern(&lf[525],12,"compile-time");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[527]=C_h_intern(&lf[527],9,"eval-when");
lf[528]=C_h_intern(&lf[528],8,"\003sysvoid");
lf[529]=C_h_intern(&lf[529],9,"fluid-let");
lf[530]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[531]=C_h_intern(&lf[531],11,"\000type-error");
lf[532]=C_h_intern(&lf[532],15,"\003syssignal-hook");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[534]=C_h_intern(&lf[534],6,"ensure");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[536]=C_h_intern(&lf[536],6,"assert");
lf[537]=C_h_intern(&lf[537],20,"with-input-from-file");
lf[538]=C_h_intern(&lf[538],27,"\003syscurrent-source-filename");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[541]=C_h_intern(&lf[541],28,"\003sysresolve-include-filename");
lf[542]=C_h_intern(&lf[542],7,"include");
lf[543]=C_h_intern(&lf[543],12,"\004coredeclare");
lf[544]=C_h_intern(&lf[544],4,"time");
lf[545]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[546]=C_h_intern(&lf[546],3,"val");
lf[547]=C_h_intern(&lf[547],28,"\003sysstring->qualified-symbol");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[553]=C_h_intern(&lf[553],27,"\003sysqualified-symbol-prefix");
lf[554]=C_h_intern(&lf[554],13,"define-record");
lf[555]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[556]=C_h_intern(&lf[556],6,"symbol");
lf[557]=C_h_intern(&lf[557],11,"\003sysprovide");
lf[558]=C_h_intern(&lf[558],19,"chicken-more-macros");
C_register_lf2(lf,559,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1074,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1072 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1075 in k1072 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1080,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1078 in k1075 in k1072 */
static void C_ccall f_1080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1083,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1086,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1089,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_match_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1092,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1095,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1098,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#provide */
t3=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[558]);}

/* k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1101,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[473]+1);
t4=*((C_word*)lf[110]+1);
t5=*((C_word*)lf[40]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8736,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#register-macro */
t7=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[554],t6);}

/* a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8736(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_8736r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8736r(t0,t1,t2,t3);}}

static void C_ccall f_8736r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[554],t2,lf[556]);}

/* k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[554],((C_word*)t0)[5],lf[555]);}

/* k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   symbol->string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8746,2,t0,t1);}
t2=(C_word)C_i_memq(lf[429],C_retrieve(lf[18]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8752,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 44   ##sys#qualified-symbol-prefix */
t4=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}

/* k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8958,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[552],((C_word*)t0)[3]);}

/* k8956 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8936 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8938,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,lf[427],t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_list(&a,3,lf[385],t1,t5);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8914,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t6,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8934,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[3],lf[551]);}

/* k8932 in k8936 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8912 in k8936 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8914,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[78]);
t3=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[10]);
t4=(C_word)C_a_i_list(&a,3,lf[428],lf[78],t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],t2,t4);
t6=(C_word)C_a_i_list(&a,3,lf[385],t1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8775,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8777,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t9,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_8777(t11,t7,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k8912 in k8936 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_8777(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8777,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t1,a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 44   symbol->string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k8785 in mapslots in k8912 in k8936 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8790,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8906,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[549],t1,lf[550]);}

/* k8904 in k8785 in mapslots in k8912 in k8936 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8788 in k8785 in mapslots in k8912 in k8936 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8793,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8902,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[548],((C_word*)t0)[2]);}

/* k8900 in k8788 in k8785 in mapslots in k8912 in k8936 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8791 in k8788 in k8785 in mapslots in k8912 in k8936 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[167],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8793,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[78],lf[546]);
t3=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t3);
t5=(C_word)C_a_i_list(&a,2,lf[431],t4);
t6=(C_word)C_a_i_list(&a,4,lf[435],lf[78],((C_word*)t0)[7],lf[546]);
t7=(C_word)C_a_i_list(&a,4,lf[3],t2,t5,t6);
t8=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[6],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t8,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t10=(C_word)C_a_i_list(&a,1,lf[78]);
t11=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t11);
t13=(C_word)C_a_i_list(&a,2,lf[431],t12);
t14=(C_word)C_a_i_list(&a,3,lf[432],lf[78],((C_word*)t0)[7]);
t15=(C_word)C_a_i_list(&a,4,lf[3],t10,t13,t14);
t16=t9;
f_8824(t16,(C_word)C_a_i_list(&a,3,lf[433],t15,((C_word*)t0)[6]));}
else{
t10=(C_word)C_a_i_list(&a,1,lf[78]);
t11=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t11);
t13=(C_word)C_a_i_list(&a,2,lf[431],t12);
t14=(C_word)C_a_i_list(&a,3,lf[432],lf[78],((C_word*)t0)[7]);
t15=t9;
f_8824(t15,(C_word)C_a_i_list(&a,4,lf[3],t10,t13,t14));}}

/* k8822 in k8791 in k8788 in k8785 in mapslots in k8912 in k8936 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_8824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8824,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[403],((C_word*)t0)[6],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8804,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 44   mapslots */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8777(t7,t4,t5,t6);}

/* k8802 in k8822 in k8791 in k8788 in k8785 in mapslots in k8912 in k8936 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8804,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8773 in k8912 in k8936 in k8750 in k8744 in k8741 in k8738 in a8735 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8775,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[403],t3));}

/* k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1104,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8648,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[409],t3);}

/* a8647 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8648(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr3r,(void*)f_8648r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8648r(t0,t1,t2,t3);}}

static void C_ccall f_8648r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(23);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t4,lf[301]));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8665,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[409],t2,lf[458]);}}

/* k8663 in a8647 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[409],((C_word*)t0)[3],lf[545]);}

/* k8666 in k8663 in a8647 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_8674(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_8674(t3,C_SCHEME_FALSE);}}

/* k8672 in k8666 in k8663 in a8647 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_8674(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8674,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[5],t3,t6));}}

/* k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1107,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8607,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro */
t5=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[544],t4);}

/* a8606 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8607(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_8607r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8607r(t0,t1,t2);}}

static void C_ccall f_8607r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8611,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   gensym */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[96]);}

/* k8609 in a8606 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8611,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[99]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[3],t3);
t5=(C_word)C_a_i_list(&a,1,lf[98]);
t6=(C_word)C_a_i_list(&a,2,lf[97],t5);
t7=(C_word)C_a_i_list(&a,3,lf[444],lf[445],t1);
t8=(C_word)C_a_i_list(&a,4,lf[3],t1,t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[5],t4,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[403],t2,t9));}

/* k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1110,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8591,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[397],t3);}

/* a8590 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8591(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_8591r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8591r(t0,t1,t2);}}

static void C_ccall f_8591r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8599,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8601,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a8600 in a8590 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8601,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[30],t2));}

/* k8597 in a8590 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8599,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[543],t1));}

/* k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1113,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[537]);
t4=*((C_word*)lf[28]+1);
t5=*((C_word*)lf[157]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8514,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#register-macro */
t7=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[542],t6);}

/* a8513 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8514,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#resolve-include-filename */
t4=C_retrieve(lf[541]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_SCHEME_TRUE);}

/* k8516 in a8513 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8586,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   load-verbose */
t4=C_retrieve(lf[350]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8584 in k8516 in a8513 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 44   print */
t2=*((C_word*)lf[24]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[539],((C_word*)t0)[2],lf[540]);}
else{
t2=((C_word*)t0)[3];
f_8521(2,t2,C_SCHEME_UNDEFINED);}}

/* k8519 in k8516 in a8513 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8528,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   with-input-from-file */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[5],t3);}

/* a8529 in k8519 in k8516 in a8513 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8530,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8536,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8577,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[515]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a8576 in a8529 in k8519 in k8516 in a8513 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8577,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[538]));
t3=C_mutate((C_word*)lf[538]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[13]));}

/* a8543 in a8529 in k8519 in k8516 in a8513 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8552,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8550 in a8543 in a8529 in k8519 in k8516 in a8513 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8552,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8554,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8554(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do38 in k8550 in a8543 in a8529 in k8519 in k8516 in a8513 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_8554(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8554,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 44   reverse */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8571,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k8569 in do38 in k8550 in a8543 in a8529 in k8519 in k8516 in a8513 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8571,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_8554(t3,((C_word*)t0)[2],t1,t2);}

/* a8535 in a8529 in k8519 in k8516 in a8513 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8536,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[538]));
t3=C_mutate((C_word*)lf[538]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[13]));}

/* k8526 in k8519 in k8516 in a8513 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8528,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[403],t1));}

/* k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1116,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8454,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[536],t3);}

/* a8453 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8454(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_8454r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8454r(t0,t1,t2,t3);}}

static void C_ccall f_8454r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8458,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t3);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[30],lf[535]);
t7=t4;
f_8458(t7,(C_word)C_a_i_list(&a,2,lf[467],t6));}
else{
t6=t4;
f_8458(t6,(C_word)C_slot(t3,C_fix(0)));}}

/* k8456 in a8453 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_8458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8458,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[431],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[4]);
t4=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,t1,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[53],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[450],t2,t3,t10));}

/* k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1119,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8395,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[534],t3);}

/* a8394 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_8395r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8395r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8395r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8399,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k8397 in a8394 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8399,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t5=(C_word)C_a_i_list(&a,2,lf[431],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8426,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t7=t6;
f_8426(t7,((C_word*)t0)[2]);}
else{
t7=(C_word)C_a_i_list(&a,2,lf[30],lf[533]);
t8=(C_word)C_a_i_list(&a,2,lf[467],t7);
t9=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t10=t6;
f_8426(t10,(C_word)C_a_i_list(&a,3,t8,t1,t9));}}

/* k8424 in k8397 in a8394 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_8426(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8426,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[531],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[532],t2);
t4=(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t4));}

/* k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1122,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8221,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro */
t5=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[529],t4);}

/* a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8221(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_8221r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8221r(t0,t1,t2,t3);}}

static void C_ccall f_8221r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8225,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[529],t2,lf[530]);}

/* k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[3]);}

/* k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8388 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8389(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8389,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8234,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8382 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8383,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8241,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8345,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8381,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[479]+1),((C_word*)t0)[2]);}

/* k8379 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   map */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[301]+1),((C_word*)t0)[2],t1);}

/* k8343 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8349,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8353,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8359,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_8359(t8,t3,t4);}

/* loop in k8343 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_8359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8359,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8373,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* csi.scm: 44   loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k8371 in loop in k8343 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8373,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k8351 in k8343 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   map */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[301]+1),((C_word*)t0)[2],t1);}

/* k8347 in k8343 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8337,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a8336 in k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8337,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8311 in k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8317,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8321,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8331,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8330 in k8311 in k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8331,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8319 in k8311 in k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8321,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[528]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8315 in k8311 in k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8307 in k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8309,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,lf[3],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8265,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8269,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8293,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t9=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a8292 in k8307 in k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8293,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8267 in k8307 in k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8273,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8277,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8287,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8286 in k8267 in k8307 in k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8287,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8275 in k8267 in k8307 in k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8277,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[528]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8271 in k8267 in k8307 in k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8263 in k8307 in k8239 in k8232 in k8229 in k8226 in k8223 in a8220 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8265,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_list(&a,4,lf[515],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t4));}

/* k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1125,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8126,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[527],t3);}

/* a8125 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8126(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr3r,(void*)f_8126r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8126r(t0,t1,t2,t3);}}

static void C_ccall f_8126r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(24);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8133,a[2]=t5,a[3]=t10,a[4]=t1,a[5]=t9,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8162,a[2]=t7,a[3]=t9,a[4]=t5,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_8162(t15,t11,t2);}

/* loop in a8125 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_8162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8162,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8175,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[63]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t7=t4;
f_8175(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[91]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[523]));
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t9=t4;
f_8175(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[524]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[525]));
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t11=t4;
f_8175(2,t11,t10);}
else{
t10=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 44   ##sys#error */
t11=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t4,lf[526],t10);}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8173 in loop in a8125 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* csi.scm: 44   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8162(t3,((C_word*)t0)[2],t2);}

/* k8131 in a8125 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8133,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[518],C_retrieve(lf[18])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_a_i_list(&a,2,lf[519],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_a_i_list(&a,2,lf[520],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[3]:lf[521]))));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[3]:lf[522]));}}

/* k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1128,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[129]+1);
t4=*((C_word*)lf[479]+1);
t5=*((C_word*)lf[2]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8016,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#register-macro */
t7=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[516],t6);}

/* a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8016(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_8016r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8016r(t0,t1,t2,t3);}}

static void C_ccall f_8016r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8020,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[516],t2,lf[517]);}

/* k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8021 in k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8026,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   ##sys#map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8024 in k8021 in k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8029,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8027 in k8024 in k8021 in k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8032,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8120,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8119 in k8027 in k8024 in k8021 in k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8120,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8030 in k8027 in k8024 in k8021 in k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8114,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8113 in k8030 in k8027 in k8024 in k8021 in k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8114,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8033 in k8030 in k8027 in k8024 in k8021 in k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8042,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8108,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   map */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[301]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k8106 in k8033 in k8030 in k8027 in k8024 in k8021 in k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8112,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   map */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[301]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8110 in k8106 in k8033 in k8030 in k8027 in k8024 in k8021 in k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8040 in k8033 in k8030 in k8027 in k8024 in k8021 in k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8078,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8080,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8079 in k8040 in k8033 in k8030 in k8027 in k8024 in k8021 in k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8080,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_list(&a,2,lf[96],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t3);
t8=(C_word)C_a_i_list(&a,3,lf[6],t3,lf[96]);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,4,lf[413],t6,t7,t8));}

/* k8076 in k8040 in k8033 in k8030 in k8027 in k8024 in k8021 in k8018 in a8015 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8078,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[3],t6);
t8=(C_word)C_a_i_list(&a,4,lf[515],((C_word*)t0)[5],t7,((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,3,lf[413],t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t9));}

/* k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8006,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[514],t3);}

/* a8005 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_8006(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_8006r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8006r(t0,t1,t2,t3);}}

static void C_ccall f_8006r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(12);
t4=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[450],t2,t4));}

/* k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1134,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7992,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[513],t3);}

/* a7991 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7992(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_7992r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7992r(t0,t1,t2,t3);}}

static void C_ccall f_7992r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(18);
t4=(C_word)C_a_i_list(&a,1,lf[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[450],t2,t4,t5));}

/* k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1134,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1135,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1208,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#register-macro */
t5=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[512],t3);}

/* k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1211,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro */
t3=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[511],((C_word*)t0)[2]);}

/* k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1214,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7659,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7690,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7730,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t10=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t2,lf[507],t9);}

/* a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7730,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[507],t2,lf[510]);}

/* k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7734,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[129]+1),t2);}

/* k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7746,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7952,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7952(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7952(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7952,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7965,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* csi.scm: 44   append */
t6=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* csi.scm: 44   append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7659(t6,t5,t4,t3);}
else{
t6=t5;
f_7965(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k7963 in loop in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 44   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7952(t3,((C_word*)t0)[2],t2,t1);}

/* k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7942,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7941 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7942,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7950,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   gensym */
t4=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7948 in a7941 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7950,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7750,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7761,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7896,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7896(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7896(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7896,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* csi.scm: 44   reverse */
t4=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7912,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7936,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7690(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7929,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   lookup */
t7=((C_word*)t0)[2];
f_7750(3,t7,t6,t4);}}}

/* k7927 in loop in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7929,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7912(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7934 in loop in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7936,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7912(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7910 in loop in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 44   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7896(t3,((C_word*)t0)[2],t2,t1);}

/* k7759 in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7768,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7890,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7889 in k7759 in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7890,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k7766 in k7759 in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7768,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7770,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7770(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k7766 in k7759 in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7770(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7770,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7788,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7790,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7804,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7884,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   cdar */
t8=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_7804(t7,C_SCHEME_FALSE);}}}

/* k7882 in fold in k7766 in k7759 in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7804(t2,(C_word)C_i_nullp(t1));}

/* k7802 in fold in k7766 in k7759 in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7804(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7804,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   caar */
t3=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7858,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 44   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_7770(t9,t5,t6,t7,t8);}}

/* k7856 in k7802 in fold in k7766 in k7759 in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7858,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t2));}

/* k7833 in k7802 in fold in k7766 in k7759 in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7835,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7815,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 44   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_7770(t9,t5,t6,t7,t8);}

/* k7813 in k7833 in k7802 in fold in k7766 in k7759 in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7815,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* a7789 in fold in k7766 in k7759 in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7790(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7790,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7798,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   lookup */
t4=((C_word*)t0)[2];
f_7750(3,t4,t3,t2);}

/* k7796 in a7789 in fold in k7766 in k7759 in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7798,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k7786 in fold in k7766 in k7759 in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7788,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[413],t2));}

/* lookup in k7747 in k7744 in k7741 in k7732 in a7657 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7750,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7690(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7690,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7713,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* csi.scm: 44   proc */
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* csi.scm: 44   proc */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k7711 in map* in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7717,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 44   map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7690(t4,t2,((C_word*)t0)[2],t3);}

/* k7715 in k7711 in map* in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7717,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7659(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7659,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7680,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* csi.scm: 44   append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k7678 in append* in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7680,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1217,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7608,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[508],t3);}

/* a7607 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7608,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7612,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[508],t2,lf[509]);}

/* k7610 in a7607 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7612,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7623,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7623(t7,((C_word*)t0)[2],t2);}

/* fold in k7610 in a7607 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7623(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7623,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[413],t3));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7648,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* csi.scm: 44   fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k7646 in fold in k7610 in a7607 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7648,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[507],((C_word*)t0)[2],t1));}

/* k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7488,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[505],t3);}

/* a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7488,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7492,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[505],t2,lf[506]);}

/* k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7492,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7501,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7600,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7602,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7601 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7602,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k7598 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[414]+1),t1);}

/* k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7504,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7588,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7587 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7588,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7596,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   gensym */
t4=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7594 in a7587 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7596,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7502 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7505,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7524,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7582,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7581 in k7502 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7582,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[504]));}

/* k7522 in k7502 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7528,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7532,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7534,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7533 in k7522 in k7502 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7534,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7554,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k7552 in a7533 in k7522 in k7502 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7558,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7560,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7559 in k7552 in a7533 in k7522 in k7502 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7560,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7568,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   lookup */
t4=((C_word*)t0)[2];
f_7505(3,t4,t3,t2);}

/* k7566 in a7559 in k7552 in a7533 in k7522 in k7502 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7568,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[6],((C_word*)t0)[2],t1));}

/* k7556 in k7552 in a7533 in k7522 in k7502 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7558,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t3));}

/* k7530 in k7522 in k7502 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7526 in k7522 in k7502 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7528,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[413],t2));}

/* lookup in k7502 in k7499 in k7490 in a7487 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7505,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1223,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7467,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[503],t3);}

/* a7466 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7467,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7471,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7469 in a7466 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7471,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,3,lf[194],t1,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[3],t1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t2,t4));}

/* k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1302,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7457,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[500],t3);}

/* a7456 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7457(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7457,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1229,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[500],t2,lf[502]);}

/* k1227 in a7456 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1229,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1238,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t5;
f_1238(t9,(C_word)C_a_i_cons(&a,2,lf[3],t8));}
else{
t6=t5;
f_1238(t6,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k1236 in k1227 in a7456 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1238,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1241,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1254,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_1254(t6,t4);}
else{
t6=(C_word)C_i_car(t1);
t7=(C_word)C_eqp(lf[3],t6);
t8=t5;
f_1254(t8,(C_word)C_i_not(t7));}}

/* k1252 in k1236 in k1227 in a7456 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1254(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 44   syntax-error */
t2=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[500],lf[501],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1241(2,t2,C_SCHEME_UNDEFINED);}}

/* k1239 in k1236 in k1227 in a7456 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1241,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[499],t3));}

/* k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1305,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7436,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[497],t3);}

/* a7435 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7436(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7436,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7440,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[497],t2,lf[498]);}

/* k7438 in a7435 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7440,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[30],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[496],t3,t4));}

/* k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1308,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7320,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[494],t3);}

/* a7319 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7320(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7320,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7324,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[494],t2,lf[495]);}

/* k7322 in a7319 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7324,2,t0,t1);}
t2=(C_word)C_i_listp(((C_word*)t0)[3]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7333,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_7333(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t4;
f_7333(t6,(C_word)C_fixnum_lessp(t5,C_fix(2)));}}

/* k7331 in k7322 in a7319 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7333(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7333,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 44   ##sys#syntax-error-hook */
t2=C_retrieve(lf[492]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[493],((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7347,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7347(t7,((C_word*)t0)[3],t2);}}

/* fold in k7331 in k7322 in a7319 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7347(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7347,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[403],((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_not_pair_p(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7376,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   fold */
t15=t5;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t5=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_slot(t3,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7393,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   fold */
t15=t7;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7411,a[2]=t9,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   fold */
t15=t10;
t16=t4;
t1=t15;
t2=t16;
goto loop;}}}}

/* k7409 in fold in k7331 in k7322 in a7319 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7411,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[4],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t2));}

/* k7391 in fold in k7331 in k7322 in a7319 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7393,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k7374 in fold in k7331 in k7322 in a7319 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7376,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1311,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7221,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t5=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[489],t4);}

/* a7220 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7221,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7231,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7229 in a7220 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7231,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7242,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7244,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7244(t8,t4,((C_word*)t0)[2]);}

/* expand in k7229 in a7220 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7244(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7244,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7260,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[489],t3,lf[490]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[491]);}}

/* k7258 in expand in k7229 in a7220 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7260,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[398],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[403],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7296,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7298,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a7297 in k7258 in expand in k7229 in a7220 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7298(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7298,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[484],((C_word*)t0)[2],t2));}

/* k7294 in k7258 in expand in k7229 in a7220 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7296,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[488],t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7288,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7244(t6,t5,((C_word*)t0)[2]);}

/* k7286 in k7294 in k7258 in expand in k7229 in a7220 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7288,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k7240 in k7229 in a7220 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7242,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7132,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t5=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[485],t4);}

/* a7131 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7132(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7132,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7142,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7140 in a7131 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7142,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7153,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7155,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7155(t8,t4,((C_word*)t0)[2]);}

/* expand in k7140 in a7131 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7155(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7155,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7171,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[485],t3,lf[486]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[487]);}}

/* k7169 in expand in k7140 in a7131 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7171,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[398],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[403],t4));}
else{
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,lf[484],((C_word*)t0)[4],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,lf[403],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7199,a[2]=t7,a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_7155(t9,t8,((C_word*)t0)[2]);}}

/* k7197 in k7169 in expand in k7140 in a7131 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7199,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k7151 in k7140 in a7131 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7153,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1317,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6846,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[481],t3);}

/* a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6846r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6846r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6846r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7043,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[481],t3,lf[483]);}

/* k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[481],((C_word*)t0)[4],lf[482]);}

/* k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[2]);}

/* k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7050,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7065,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7122,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a7121 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7122,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7130,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   prefix-sym */
f_7050(t3,lf[480],t2);}

/* k7128 in a7121 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   gensym */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7068,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[479]+1),((C_word*)t0)[2]);}

/* k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7071,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[478]);}

/* k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[477]);}

/* k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7077,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7112,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}

/* a7111 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7112,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7120,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   prefix-sym */
f_7050(t3,lf[476],t2);}

/* k7118 in a7111 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   gensym */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7080,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[5];
t5=t1;
t6=((C_word*)t0)[2];
t7=C_retrieve(lf[7]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6857,a[2]=t5,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t9=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k6855 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6859 in k6855 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6865,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6863 in k6859 in k6855 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6865,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6867,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6867(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k6863 in k6859 in k6855 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_6867(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6867,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6912,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 44   reverse */
t9=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k6910 in recur in k6863 in k6859 in k6855 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6924,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   reverse */
t4=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6922 in k6910 in recur in k6863 in k6859 in k6855 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6924,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6918 in k6910 in recur in k6863 in k6859 in k6855 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6920,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6888,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[5]);
/* csi.scm: 44   recur */
t9=((C_word*)((C_word*)t0)[3])[1];
f_6867(t9,t5,((C_word*)t0)[2],t6,t7,t8);}

/* k6886 in k6918 in k6910 in recur in k6863 in k6859 in k6855 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6888,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7078 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7083,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[9];
t7=C_retrieve(lf[7]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6940,a[2]=t9,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_6940(t11,t2,t3,t4,C_SCHEME_END_OF_LIST);}

/* recur in k7078 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_6940(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6940,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,lf[431],t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6974,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t8=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[4]);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7040,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t6,a[7]=t1,a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 44   reverse */
t9=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t4);}}

/* k7038 in recur in k7078 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7040,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,lf[129],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_list(&a,2,lf[454],((C_word*)t0)[9]);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7004,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[3]);
/* csi.scm: 44   recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_6940(t12,t8,t9,t10,t11);}

/* k7002 in k7038 in recur in k7078 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7004,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k6972 in recur in k7078 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6974,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,2,lf[30],lf[475]);
t4=(C_word)C_a_i_list(&a,2,lf[467],t3);
t5=(C_word)C_a_i_list(&a,3,lf[53],t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[2],t2,t5));}

/* k7081 in k7078 in k7075 in k7072 in k7069 in k7066 in k7063 in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7083,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[3],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[474],t7,t1));}

/* prefix-sym in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_7050(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7050,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7058,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7062,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   symbol->string */
t6=*((C_word*)lf[473]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k7060 in prefix-sym in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   string-append */
t2=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7056 in prefix-sym in k7047 in k7044 in k7041 in a6845 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   string->symbol */
t2=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6789,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[471],t3);}

/* a6788 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6789,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6793,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6791 in a6788 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6793,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[465],t1);
t5=(C_word)C_a_i_list(&a,2,lf[454],t1);
t6=(C_word)C_a_i_list(&a,2,lf[465],t5);
t7=(C_word)C_a_i_list(&a,2,lf[431],t6);
t8=(C_word)C_a_i_list(&a,2,lf[129],t1);
t9=(C_word)C_a_i_list(&a,2,lf[30],lf[1]);
t10=(C_word)C_a_i_list(&a,2,lf[467],t9);
t11=(C_word)C_a_i_list(&a,3,lf[53],t10,t1);
t12=(C_word)C_a_i_list(&a,4,lf[450],t7,t8,t11);
t13=(C_word)C_a_i_list(&a,4,lf[450],t4,((C_word*)t0)[3],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[413],t3,t13));}

/* k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1323,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6783,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[472],t3);}

/* a6782 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6783,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[471],t2));}

/* k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6630,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[468],t3);}

/* a6629 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6630r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6630r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6630r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6634,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[468],t3,lf[470]);}

/* k6632 in a6629 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[468],((C_word*)t0)[3],lf[469]);}

/* k6635 in k6632 in a6629 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6638 in k6635 in k6632 in a6629 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6640,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6651,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6653,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_6653(t8,t4,t1,((C_word*)t0)[2]);}

/* loop in k6638 in k6635 in k6632 in a6629 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_6653(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6653,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,2,lf[465],t2);
t5=(C_word)C_a_i_list(&a,2,lf[431],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,lf[413],t6);
t8=(C_word)C_a_i_list(&a,2,lf[30],lf[466]);
t9=(C_word)C_a_i_list(&a,2,lf[467],t8);
t10=(C_word)C_a_i_list(&a,3,lf[53],t9,t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[450],t5,t7,t10));}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6703,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_a_i_list(&a,2,t4,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}}}

/* k6701 in loop in k6638 in k6635 in k6632 in a6629 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6703,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[129],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,4,lf[450],t3,t4,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t6);
t8=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,2,lf[30],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_list(&a,2,lf[454],((C_word*)t0)[5]);
t11=(C_word)C_a_i_list(&a,4,lf[450],t8,t9,t10);
t12=(C_word)C_a_i_list(&a,2,t1,t11);
t13=(C_word)C_a_i_list(&a,2,t7,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6714,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 44   loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_6653(t16,t14,t1,t15);}

/* k6712 in k6701 in loop in k6638 in k6635 in k6632 in a6629 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6714,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k6649 in k6638 in k6635 in k6632 in a6629 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6651,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6354,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[457],t3);}

/* a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6354,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6388,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[457],t2,lf[464]);}

/* k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   require */
t3=C_retrieve(lf[462]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[463]);}

/* k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6615,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6617,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6616 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6617(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6617,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6627,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#decompose-lambda-list */
t5=C_retrieve(lf[459]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a6626 in a6616 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6627,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k6613 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[277]+1),t1);}

/* k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6397,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6363,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6363(t7,t2,C_fix(0));}

/* loop in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_6363(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6363,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6377,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t4=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k6375 in loop in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6381,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 44   loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6363(t4,t2,t3);}

/* k6379 in k6375 in loop in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6400,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   append */
t3=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6]);}

/* k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6410,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[69],((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6422,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6424,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   fold-right */
t7=C_retrieve(lf[460]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,lf[461],((C_word*)t0)[2]);}

/* a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6424,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   ##sys#decompose-lambda-list */
t6=C_retrieve(lf[459]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a6433 in a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6434,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* csi.scm: 44   ##sys#check-syntax */
t7=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[457],t6,lf[458]);}

/* k6436 in a6433 in a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6438,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6448,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(C_word)C_i_zerop(t2);
t5=t3;
f_6448(t5,(C_truep(t4)?C_SCHEME_TRUE:(C_word)C_a_i_list(&a,3,lf[455],((C_word*)t0)[2],t2)));}
else{
t4=t3;
f_6448(t4,(C_word)C_a_i_list(&a,3,lf[456],((C_word*)t0)[2],t2));}}

/* k6446 in k6436 in a6433 in a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_6448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6448,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6452,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6454,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a6463 in k6446 in k6436 in a6433 in a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6464,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6468,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6483,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_6483(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a6463 in k6446 in k6436 in a6433 in a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_6483(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6483,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[4])){
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[3]));}
else{
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[413],t6));}}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6539,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k6537 in build in a6463 in k6446 in k6436 in a6433 in a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6539,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[129],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,2,lf[454],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6550,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* csi.scm: 44   build */
t11=((C_word*)((C_word*)t0)[2])[1];
f_6483(t11,t8,t10,t1);}
else{
/* csi.scm: 44   build */
t10=((C_word*)((C_word*)t0)[2])[1];
f_6483(t10,t8,C_SCHEME_END_OF_LIST,t1);}}

/* k6548 in k6537 in build in a6463 in k6446 in k6436 in a6433 in a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6550,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k6466 in a6463 in k6446 in k6436 in a6433 in a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6468,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6481,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   map */
t3=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[453]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6479 in k6466 in a6463 in k6446 in k6436 in a6433 in a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6481,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],t1,((C_word*)t0)[2]));}

/* a6453 in k6446 in k6436 in a6433 in a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6462,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   take */
t3=C_retrieve(lf[452]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6460 in a6453 in k6446 in k6436 in a6433 in a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   split-at! */
t2=C_retrieve(lf[451]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6450 in k6446 in k6436 in a6433 in a6423 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6452,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k6420 in k6408 in k6401 in k6398 in k6395 in k6392 in k6389 in k6386 in a6353 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6422,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t2));}

/* k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6297,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[447],t3);}

/* a6296 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_6297r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6297r(t0,t1,t2,t3);}}

static void C_ccall f_6297r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(16);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6307,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[447],t5,lf[448]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6337,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[447],t5,lf[449]);}}

/* k6335 in a6296 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6337,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[446],t3));}

/* k6305 in a6296 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6307,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t3=(C_word)C_a_i_list(&a,2,lf[30],t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,lf[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[446],t3,t6));}

/* k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6221,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[441],t3);}

/* a6220 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6221r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6221r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6221r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6225,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6223 in a6220 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6226 in k6223 in a6220 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6228,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_list(&a,3,lf[3],t3,t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,lf[3],t7);
t9=(C_word)C_a_i_list(&a,3,lf[444],lf[445],t1);
t10=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_list(&a,3,lf[3],t1,t11);
t13=(C_word)C_a_i_list(&a,3,lf[5],t8,t12);
t14=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t13);
t15=(C_word)C_a_i_list(&a,3,lf[158],t6,t14);
t16=(C_word)C_a_i_list(&a,3,lf[3],t2,t15);
t17=(C_word)C_a_i_list(&a,2,lf[159],t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_list(&a,1,t17));}

/* k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6037,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[443],t3);}

/* a6036 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6037(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6037r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6037r(t0,t1,t2,t3);}}

static void C_ccall f_6037r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6041,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6039 in a6036 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6042 in k6039 in a6036 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6046,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[30],lf[256]);
t4=(C_word)C_a_i_list(&a,3,lf[428],((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,3,lf[217],((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_a_i_list(&a,3,lf[438],t4,t5);
t7=(C_word)C_a_i_list(&a,2,t1,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6187,a[2]=t9,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t2,((C_word*)t0)[2]);}

/* k6185 in k6042 in k6039 in a6036 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6187,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[442],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[398],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k6181 in k6042 in k6039 in a6036 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6183,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[440],t1);
t3=(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[5],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,4,lf[441],((C_word*)t0)[3],t3,((C_word*)t0)[2]));}

/* parse-clause in k6042 in k6039 in a6036 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6046,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6069,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,t7);
t12=t8;
f_6069(t12,(C_word)C_a_i_cons(&a,2,lf[413],t11));}
else{
t9=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t10=t8;
f_6069(t10,(C_word)C_a_i_cons(&a,2,lf[413],t9));}}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6132,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6134,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t10=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t6);}}

/* a6133 in parse-clause in k6042 in k6039 in a6036 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6134,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[30],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[439],t3,((C_word*)t0)[2]));}

/* k6130 in parse-clause in k6042 in k6039 in a6036 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6132,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[438],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6102,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[2]);
t8=t4;
f_6102(t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}
else{
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t6=t4;
f_6102(t6,(C_word)C_a_i_cons(&a,2,lf[413],t5));}}

/* k6100 in k6130 in parse-clause in k6042 in k6039 in a6036 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_6102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6102,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k6067 in parse-clause in k6042 in k6039 in a6036 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_6069(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6069,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[398],t1));}

/* k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5847,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[437],t3);}

/* a5846 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5847r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5847r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5847r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5854,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* map */
t8=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[129]+1),t5);}

/* k5852 in a5846 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5854,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6026,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a6027 in k5852 in a5846 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6028,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[436]));}

/* k6024 in k5852 in a5846 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_6026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6026,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[427],t2);
t4=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],lf[78]);
t6=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[428],lf[78],t6);
t8=(C_word)C_a_i_list(&a,3,lf[385],t5,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5877,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5879,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_5879(t13,t9,((C_word*)t0)[2],C_fix(1));}

/* loop in k6024 in k5852 in a5846 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_5879(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[112],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5879,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[429],C_retrieve(lf[18]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_list(&a,1,lf[78]);
t9=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t9);
t11=(C_word)C_a_i_list(&a,2,lf[431],t10);
t12=(C_word)C_a_i_list(&a,3,lf[432],lf[78],t3);
t13=(C_word)C_a_i_list(&a,4,lf[3],t8,t11,t12);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5905,a[2]=t13,a[3]=t5,a[4]=t7,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=t2,a[8]=t1,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t15=(C_word)C_i_caddr(t4);
t16=(C_word)C_a_i_list(&a,3,t15,lf[78],lf[434]);
t17=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[3]);
t18=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t17);
t19=(C_word)C_a_i_list(&a,2,lf[431],t18);
t20=(C_word)C_a_i_list(&a,4,lf[435],lf[78],t3,lf[434]);
t21=(C_word)C_a_i_list(&a,4,lf[385],t16,t19,t20);
t22=t14;
f_5905(t22,(C_word)C_a_i_list(&a,1,t21));}
else{
t15=t14;
f_5905(t15,C_SCHEME_END_OF_LIST);}}}

/* k5903 in loop in k6024 in k5852 in a5846 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_5905(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5905,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5933,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[9]);
t6=t3;
f_5933(t6,(C_word)C_a_i_list(&a,3,lf[433],((C_word*)t0)[2],t5));}
else{
t5=t3;
f_5933(t5,((C_word*)t0)[2]);}}

/* k5931 in k5903 in loop in k6024 in k5852 in a5846 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_5933(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5933,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5917,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5925,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   add1 */
t6=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5923 in k5931 in k5903 in loop in k6024 in k5852 in a5846 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5879(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5915 in k5931 in k5903 in loop in k6024 in k5852 in a5846 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5917,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5875 in k6024 in k5852 in a5846 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5877,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[403],t3));}

/* k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5838,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[425],t3);}

/* a5837 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5838,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5842,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[425],t2,lf[426]);}

/* k5840 in a5837 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5842,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[424],((C_word*)t0)[2]));}

/* k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5819,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[422],t3);}

/* a5818 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5819,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5823,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[422],t2,lf[423]);}

/* k5821 in a5818 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5830,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5832,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5831 in k5821 in a5818 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5832,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[30],t2));}

/* k5828 in k5821 in a5818 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5830,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[313],t1));}

/* k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5800,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[420],t3);}

/* a5799 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5800,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5804,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[420],t2,lf[421]);}

/* k5802 in a5799 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5811,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5813,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5812 in k5802 in a5799 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5813(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5813,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[30],t2));}

/* k5809 in k5802 in a5799 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5811,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[313],t1));}

/* k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5672,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[419],t3);}

/* a5671 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5672,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5678,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5678(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a5671 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_5678(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5678,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5688,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   reverse */
t7=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[415]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5759,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t9=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}
else{
t8=(C_word)C_eqp(t6,lf[416]);
if(C_truep(t8)){
/* csi.scm: 44   loop */
t15=t1;
t16=C_SCHEME_END_OF_LIST;
t17=t3;
t18=t4;
t19=C_SCHEME_TRUE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_car(t2);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
/* csi.scm: 44   loop */
t15=t1;
t16=t9;
t17=t3;
t18=t11;
t19=C_SCHEME_FALSE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}}}}

/* k5757 in loop in a5671 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5759,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* csi.scm: 44   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5678(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k5686 in loop in a5671 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5691,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5689 in k5686 in loop in a5671 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5691,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_list(&a,2,lf[403],t2);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t5));}}

/* k5695 in k5689 in k5686 in loop in a5671 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5704,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k5702 in k5695 in k5689 in k5686 in loop in a5671 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5704,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5720,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k5718 in k5702 in k5695 in k5689 in k5686 in loop in a5671 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5720,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[412],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t3));}

/* k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1356,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5529,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[418],t3);}

/* a5528 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5529,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5535,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5535(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a5528 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_5535(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5535,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5545,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t8=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[415]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5620,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   gensym */
t10=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t10))(2,t10,t9);}
else{
t9=(C_word)C_eqp(t7,lf[416]);
if(C_truep(t9)){
/* csi.scm: 44   loop */
t14=t1;
t15=C_SCHEME_END_OF_LIST;
t16=t3;
t17=t4;
t18=t5;
t19=C_SCHEME_TRUE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
t5=t18;
t6=t19;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5647,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   gensym */
t11=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}}}}

/* k5645 in loop in a5528 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5647,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* csi.scm: 44   loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5535(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k5618 in loop in a5528 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5620,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* csi.scm: 44   loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5535(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k5543 in loop in a5528 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5548,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5546 in k5543 in loop in a5528 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[3],t5));}}

/* k5552 in k5546 in k5543 in loop in a5528 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5565,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k5563 in k5552 in k5546 in k5543 in loop in a5528 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5565,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5581,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k5579 in k5563 in k5552 in k5546 in k5543 in loop in a5528 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5581,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[412],t2);
t4=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t4));}

/* k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1359,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5470,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[411],t3);}

/* a5469 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+51)){
C_save_and_reclaim((void*)tr6r,(void*)f_5470r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5470r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5470r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(51);
t7=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_caddr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,3,t8,t9,t10);
t12=(C_word)C_a_i_list(&a,4,lf[408],t3,t4,t5);
t13=(C_word)C_a_i_cons(&a,2,t12,t6);
t14=(C_word)C_a_i_cons(&a,2,t11,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[409],t14));}
else{
t8=(C_word)C_a_i_list(&a,4,lf[410],t3,t4,t5);
t9=(C_word)C_a_i_cons(&a,2,t8,t6);
t10=(C_word)C_a_i_cons(&a,2,t2,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[409],t10));}}

/* k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1362,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5299,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[405],t3);}

/* a5298 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5299r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5299r(t0,t1,t2,t3);}}

static void C_ccall f_5299r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5305,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5305(t7,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,C_SCHEME_FALSE);}

/* loop in a5298 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_5305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5305,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5315,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=(C_word)C_a_i_cons(&a,2,lf[400],t5);
t8=t6;
f_5315(t8,(C_word)C_a_i_list(&a,2,lf[397],t7));}
else{
t7=t6;
f_5315(t7,lf[401]);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5379,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_5379(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_5379(t7,C_SCHEME_FALSE);}}}

/* k5377 in loop in a5298 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_5379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5379,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   caar */
t3=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
/* csi.scm: 44   syntax-error */
t2=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[405],lf[407],((C_word*)t0)[7]);}}

/* k5380 in k5377 in loop in a5298 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5382,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(lf[402],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5406,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   cdar */
t5=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(lf[404],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5427,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   cdar */
t6=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(lf[400],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5440,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
t8=(C_truep(t7)?t7:C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5448,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   cdar */
t10=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[7]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5455,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   caar */
t7=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}}}}

/* k5453 in k5380 in k5377 in loop in a5298 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   syntax-error */
t2=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[405],lf[406],t1);}

/* k5446 in k5380 in k5377 in loop in a5298 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   append */
t2=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5438 in k5380 in k5377 in loop in a5298 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5305(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5425 in k5380 in k5377 in loop in a5298 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5427,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[403],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* csi.scm: 44   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5305(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5404 in k5380 in k5377 in loop in a5298 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5406,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[403],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* csi.scm: 44   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5305(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5313 in loop in a5298 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_5315(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5315,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[393],t2);
t4=(C_word)C_a_i_list(&a,2,lf[394],lf[395]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[396],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,2,lf[397],t6);
t8=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,2,lf[338],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t0)[3]);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[398],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,4,lf[399],t3,t5,t13));}

/* k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1365,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5248,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[392],t3);}

/* a5247 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5248(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+39)){
C_save_and_reclaim((void*)tr3r,(void*)f_5248r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5248r(t0,t1,t2,t3);}}

static void C_ccall f_5248r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(39);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
t7=(C_word)C_a_i_cons(&a,2,lf[3],t6);
t8=(C_word)C_a_i_list(&a,2,t4,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,3,lf[391],t9,t10));}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[391],t5,t2));}}

/* k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1368,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5188,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[388],t3);}

/* a5187 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_5188r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5188r(t0,t1,t2,t3);}}

static void C_ccall f_5188r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[383]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5198,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t5);
t11=t8;
f_5198(t11,(C_word)C_a_i_cons(&a,2,lf[3],t10));}
else{
t9=t8;
f_5198(t9,(C_word)C_i_car(t5));}}

/* k5196 in a5187 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_5198(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5198,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5201,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5217,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   eval */
t4=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
/* csi.scm: 44   syntax-error */
t3=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[388],lf[389],((C_word*)t0)[2]);}}

/* k5215 in k5196 in a5187 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5201(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k5199 in k5196 in a5187 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5201,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[384]))?(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[3],((C_word*)t0)[2]):lf[386]));}

/* k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1371,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   register-feature! */
t3=C_retrieve(lf[343]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,lf[377],lf[378],lf[379],lf[380],lf[381],lf[382]);}

/* k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1371,2,t0,t1);}
t2=C_mutate(&lf[11],lf[12]);
t3=C_retrieve(lf[13]);
t4=C_mutate(&lf[14],lf[15]);
t5=C_set_block_item(lf[16],0,C_fix(2048));
t6=(C_word)C_a_i_cons(&a,2,lf[17],C_retrieve(lf[18]));
t7=C_mutate((C_word*)lf[18]+1,t6);
t8=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1383,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1395,tmp=(C_word)a,a+=2,tmp));
t10=*((C_word*)lf[27]+1);
t11=*((C_word*)lf[28]+1);
t12=C_retrieve(lf[29]);
t13=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1405,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1434,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[34],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1444,tmp=(C_word)a,a+=2,tmp));
t16=*((C_word*)lf[35]+1);
t17=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1456,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t18=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 144  make-string */
t20=*((C_word*)lf[181]+1);
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,C_fix(256));}

/* k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1506,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1554,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(C_word)C_a_i_vector(&a,32,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4);
t6=C_mutate((C_word*)lf[50]+1,t5);
t7=C_set_block_item(lf[31],0,C_fix(1));
t8=C_retrieve(lf[51]);
t9=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1660,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1699,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1724,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=C_retrieve(lf[192]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5182,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 196  repl-prompt */
t14=C_retrieve(lf[376]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t11,t13);}

/* a5181 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5182,2,t0,t1);}
/* csi.scm: 199  sprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[375],C_retrieve(lf[31]));}

/* k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1724,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1726,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t4=C_retrieve(lf[59]);
t5=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1739,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 211  make-hash-table */
t7=C_retrieve(lf[374]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,*((C_word*)lf[113]+1));}

/* k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=C_mutate(&lf[60],t1);
t3=C_retrieve(lf[61]);
t4=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1755,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_retrieve(lf[63]);
t6=C_retrieve(lf[64]);
t7=*((C_word*)lf[28]+1);
t8=C_retrieve(lf[65]);
t9=*((C_word*)lf[66]+1);
t10=C_retrieve(lf[67]);
t11=C_retrieve(lf[68]);
t12=*((C_word*)lf[69]+1);
t13=*((C_word*)lf[20]+1);
t14=*((C_word*)lf[70]+1);
t15=C_retrieve(lf[45]);
t16=C_retrieve(lf[71]);
t17=C_retrieve(lf[72]);
t18=*((C_word*)lf[73]+1);
t19=*((C_word*)lf[74]+1);
t20=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1796,a[2]=t10,a[3]=t8,a[4]=t13,a[5]=t16,a[6]=t19,a[7]=t6,a[8]=t11,a[9]=t15,a[10]=t5,a[11]=t7,a[12]=t17,tmp=(C_word)a,a+=13,tmp));
t21=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2334,tmp=(C_word)a,a+=2,tmp));
t22=C_set_block_item(lf[76],0,C_fix(0));
t23=lf[101]=C_SCHEME_END_OF_LIST;;
t24=lf[104]=C_SCHEME_END_OF_LIST;;
t25=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2375,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[107]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2403,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2426,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2717,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[153]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2741,tmp=(C_word)a,a+=2,tmp));
t30=C_retrieve(lf[71]);
t31=C_retrieve(lf[161]);
t32=C_retrieve(lf[162]);
t33=C_retrieve(lf[163]);
t34=*((C_word*)lf[164]+1);
t35=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2844,a[2]=t34,a[3]=t33,a[4]=t32,a[5]=t31,a[6]=t30,tmp=(C_word)a,a+=7,tmp));
t36=C_mutate((C_word*)lf[189]+1,lf[190]);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3038,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 574  make-hash-table */
t38=C_retrieve(lf[374]);
((C_proc3)C_retrieve_proc(t38))(3,t38,t37,*((C_word*)lf[113]+1));}

/* k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3038,2,t0,t1);}
t2=C_mutate(&lf[191],t1);
t3=C_retrieve(lf[192]);
t4=C_retrieve(lf[71]);
t5=C_retrieve(lf[193]);
t6=*((C_word*)lf[69]+1);
t7=*((C_word*)lf[194]+1);
t8=*((C_word*)lf[195]+1);
t9=C_retrieve(lf[144]);
t10=C_retrieve(lf[67]);
t11=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3040,a[2]=t9,a[3]=t10,a[4]=t3,a[5]=t7,a[6]=t6,a[7]=t8,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t12=C_retrieve(lf[61]);
t13=C_mutate((C_word*)lf[276]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3798,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3804,tmp=(C_word)a,a+=2,tmp));
t15=*((C_word*)lf[20]+1);
t16=*((C_word*)lf[40]+1);
t17=*((C_word*)lf[181]+1);
t18=*((C_word*)lf[282]+1);
t19=C_mutate((C_word*)lf[245]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3965,a[2]=t15,a[3]=t18,a[4]=t17,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t20=C_mutate((C_word*)lf[285]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4174,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[287],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4233,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate(&lf[288],lf[289]);
t23=C_mutate(&lf[290],lf[291]);
t24=C_mutate(&lf[292],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4290,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[299]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4433,tmp=(C_word)a,a+=2,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5174,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 955  run */
t27=C_retrieve(lf[299]);
((C_proc2)C_retrieve_proc(t27))(2,t27,t26);}

/* k5172 in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5177,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5180,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[373]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5178 in k5172 in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5175 in k5172 in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4437,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5168,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 827  getenv */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[372]);}

/* k5166 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[371]);
/* csi.scm: 827  parse-option-string */
t3=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4440,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5164,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 828  command-line-arguments */
t4=C_retrieve(lf[322]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5162 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 828  canonicalize-args */
f_4290(((C_word*)t0)[2],t1);}

/* k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4440,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 829  member* */
f_4233(t4,lf[370],((C_word*)t3)[1]);}

/* k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 830  member* */
f_4233(t2,lf[369],((C_word*)((C_word*)t0)[4])[1]);}

/* k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4449,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5057,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_i_pairp(t4);
t6=(C_word)C_i_not(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5107,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_5107(t8,t6);}
else{
t8=(C_word)C_i_cadr(t1);
t9=(C_word)C_i_string_length(t8);
t10=(C_word)C_i_zerop(t9);
if(C_truep(t10)){
t11=t7;
f_5107(t11,t10);}
else{
t11=(C_word)C_i_cadr(t1);
t12=(C_word)C_i_string_ref(t11,C_fix(0));
t13=t7;
f_5107(t13,(C_word)C_eqp(C_make_character(45),t12));}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5147,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5160,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 844  canonicalize-args */
f_4290(t4,((C_word*)t0)[2]);}}

/* k5158 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 844  append */
t2=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5145 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_i_member(lf[368],((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
f_4449(t4,(C_truep(t3)?(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k5105 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_5107(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 835  ##sys#error */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[367]);}
else{
t2=((C_word*)t0)[2];
f_5057(2,t2,C_SCHEME_UNDEFINED);}}

/* k5055 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 836  program-name */
t4=C_retrieve(lf[366]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5058 in k5055 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* csi.scm: 837  command-line-arguments */
t4=C_retrieve(lf[322]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5061 in k5058 in k5055 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 838  register-feature! */
t3=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[365]);}

/* k5064 in k5061 in k5058 in k5055 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5066,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[364]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 841  lookup-script-file */
t6=C_retrieve(lf[42]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=((C_word*)t0)[2];
f_4449(t4,C_SCHEME_UNDEFINED);}}

/* k5073 in k5064 in k5061 in k5058 in k5055 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4449(t3,(C_word)C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[2];
f_4449(t2,C_SCHEME_FALSE);}}

/* k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4449,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 847  member* */
f_4233(t2,lf[363],((C_word*)((C_word*)t0)[4])[1]);}

/* k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4455(t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5051,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 848  member* */
f_4233(t3,lf[362],((C_word*)((C_word*)t0)[4])[1]);}}

/* k5049 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4455(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4455,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 849  member* */
f_4233(t2,lf[361],((C_word*)((C_word*)t0)[4])[1]);}

/* k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4458,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?((C_word*)t0)[7]:(C_truep(t1)?t1:((C_word*)t0)[6]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4464,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5038,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5042,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 851  getenv */
t6=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[360]);}

/* k5040 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[358]);
/* csi.scm: 851  string-split */
t3=C_retrieve(lf[45]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[359]);}

/* k5036 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[36]),t1);}

/* k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4466,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4546,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4616,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=C_set_block_item(lf[357],0,C_fix(0));
t6=t4;
f_4616(t6,t5);}
else{
t5=t4;
f_4616(t5,C_SCHEME_UNDEFINED);}}

/* k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4616,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5027,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 874  member* */
f_4233(t3,lf[356],((C_word*)((C_word*)t0)[6])[1]);}

/* k5025 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5027,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 875  print-usage */
t3=C_retrieve(lf[19]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_4619(2,t2,C_SCHEME_UNDEFINED);}}

/* k5028 in k5025 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 876  exit */
t2=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5018,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 877  member* */
f_4233(t3,lf[355],((C_word*)((C_word*)t0)[6])[1]);}

/* k5016 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 878  print-banner */
t3=C_retrieve(lf[23]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_4622(2,t2,C_SCHEME_UNDEFINED);}}

/* k5019 in k5016 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 879  exit */
t2=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[354],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5008,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5015,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 881  chicken-version */
t5=C_retrieve(lf[26]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=t2;
f_4625(2,t3,C_SCHEME_UNDEFINED);}}

/* k5013 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 881  print */
t2=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5006 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 882  exit */
t2=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 883  member* */
f_4233(t3,lf[353],((C_word*)((C_word*)t0)[6])[1]);}

/* k4993 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4995,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4998,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4998(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 884  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[352]);}}
else{
t2=((C_word*)t0)[3];
f_4628(t2,C_SCHEME_UNDEFINED);}}

/* k4996 in k4993 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[351],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_4628(t3,t2);}

/* k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4628,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4631(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4989,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 887  load-verbose */
t4=C_retrieve(lf[350]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}

/* k4987 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 888  print-banner */
t2=C_retrieve(lf[23]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 889  member* */
f_4233(t3,lf[349],((C_word*)((C_word*)t0)[6])[1]);}

/* k4972 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4977,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4977(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 890  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[348]);}}
else{
t2=((C_word*)t0)[3];
f_4634(2,t2,C_SCHEME_UNDEFINED);}}

/* k4975 in k4972 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 891  register-feature! */
t3=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[347]);}

/* k4978 in k4975 in k4972 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 892  case-sensitive */
t2=C_retrieve(lf[346]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4971,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 893  collect-options */
t4=((C_word*)t0)[2];
f_4466(t4,t3,lf[345]);}

/* k4969 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[343]),t1);}

/* k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4967,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 894  collect-options */
t4=((C_word*)t0)[2];
f_4466(t4,t3,lf[344]);}

/* k4965 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[343]),t1);}

/* k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4947,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4963,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 897  collect-options */
t6=((C_word*)t0)[2];
f_4466(t6,t5,lf[342]);}

/* k4961 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[36]),t1);}

/* k4949 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4955,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4959,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 898  collect-options */
t4=((C_word*)t0)[2];
f_4466(t4,t3,lf[341]);}

/* k4957 in k4949 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[36]),t1);}

/* k4953 in k4949 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 897  append */
t2=*((C_word*)lf[263]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,C_retrieve(lf[175]),((C_word*)t0)[2]);}

/* k4945 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 896  deldups */
t2=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[340]+1));}

/* k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4644,2,t0,t1);}
t2=C_mutate((C_word*)lf[175]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[302],C_retrieve(lf[18]));
t4=C_mutate((C_word*)lf[18]+1,t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 903  provide */
t6=C_retrieve(lf[338]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[339]);}

/* k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4654,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[330],t4))){
/* csi.scm: 908  keyword-style */
t5=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,lf[332]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[333],t5))){
/* csi.scm: 910  keyword-style */
t6=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,lf[334]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[335],t6))){
/* csi.scm: 912  keyword-style */
t7=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,lf[336]);}
else{
t7=t2;
f_4654(2,t7,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm: 906  ##sys#error */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,lf[337]);}}
else{
t3=t2;
f_4654(2,t3,C_SCHEME_UNDEFINED);}}

/* k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4881,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 913  member* */
f_4233(t3,lf[329],((C_word*)((C_word*)t0)[2])[1]);}

/* k4879 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4881,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_4657(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 861  ##sys#string-append */
t4=C_retrieve(lf[327]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[328],lf[14]);}}

/* k4511 in k4879 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4519,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 862  file-exists? */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4517 in k4511 in k4879 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 863  load */
t2=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4541,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 864  getenv */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[326]);}}

/* k4539 in k4517 in k4511 in k4879 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[325]);
/* csi.scm: 864  chop-separator */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4523 in k4517 in k4511 in k4879 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4528,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 865  string-append */
t3=*((C_word*)lf[40]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[324],lf[14]);}

/* k4526 in k4523 in k4517 in k4511 in k4879 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4534,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 866  file-exists? */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4532 in k4526 in k4523 in k4517 in k4511 in k4879 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 867  load */
t2=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4657(2,t2,C_SCHEME_UNDEFINED);}}

/* k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4662,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4662(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4662(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4662,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[5])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4675,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 917  repl */
t5=C_retrieve(lf[303]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}
else{
t4=(C_word)C_i_car(((C_word*)t3)[1]);
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_i_member(t4,lf[304]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4690,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_4690(2,t8,t6);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t4,lf[305]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[306]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[307]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[308]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[309]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[310]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t8=(C_word)C_i_cdr(((C_word*)t3)[1]);
t9=C_set_block_item(t3,0,t8);
t10=t7;
f_4690(2,t10,t9);}
else{
t8=(C_word)C_i_string_equal_p(lf[311],t4);
t9=(C_truep(t8)?t8:(C_word)C_i_string_equal_p(lf[312],t4));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4719,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4735,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 930  string->symbol */
t13=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t11,t12);}
else{
t10=(C_word)C_i_string_equal_p(lf[314],t4);
t11=(C_truep(t10)?t10:(C_word)C_i_string_equal_p(lf[315],t4));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4751,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 933  evalstring */
f_4546(t12,t13,C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_i_string_equal_p(lf[316],t4);
t13=(C_truep(t12)?t12:(C_word)C_i_string_equal_p(lf[317],t4));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4771,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cadr(((C_word*)t3)[1]);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4781,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 936  evalstring */
f_4546(t14,t15,(C_word)C_a_i_list(&a,1,t16));}
else{
t14=(C_word)C_i_string_equal_p(lf[319],t4);
t15=(C_truep(t14)?t14:(C_word)C_i_string_equal_p(lf[320],t4));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4797,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t17=(C_word)C_i_cadr(((C_word*)t3)[1]);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4807,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 941  evalstring */
f_4546(t16,t17,(C_word)C_a_i_list(&a,1,t18));}
else{
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4814,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 946  load */
t17=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,t4);}}}}}}}}

/* k4812 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4820,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=t2;
f_4820(t4,(C_word)C_i_string_equal_p(lf[323],t3));}
else{
t3=t2;
f_4820(t3,C_SCHEME_FALSE);}}

/* k4818 in k4812 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4820(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4820,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4825,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4835,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 948  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4690(2,t2,C_SCHEME_UNDEFINED);}}

/* a4834 in k4818 in k4812 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4835r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4835r(t0,t1,t2);}}

static void C_ccall f_4835r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4846,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_4846(t5,(C_word)C_fixnump(t4));}
else{
t4=t3;
f_4846(t4,C_SCHEME_FALSE);}}

/* k4844 in a4834 in k4818 in k4812 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_fix(0));
/* csi.scm: 950  exit */
t3=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* a4824 in k4818 in k4812 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4833,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 948  command-line-arguments */
t3=C_retrieve(lf[322]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4831 in a4824 in k4818 in k4812 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main */
t2=C_retrieve(lf[321]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* a4806 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4807r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4807r(t0,t1,t2);}}

static void C_ccall f_4807r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[318]+1),C_retrieve(lf[72]),t2);}

/* k4795 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4690(2,t4,t3);}

/* a4780 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4781r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4781r(t0,t1,t2);}}

static void C_ccall f_4781r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[318]+1),*((C_word*)lf[24]+1),t2);}

/* k4769 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4690(2,t4,t3);}

/* k4749 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4690(2,t4,t3);}

/* k4733 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],t1);
t3=(C_word)C_a_i_list(&a,2,lf[313],t2);
/* csi.scm: 930  eval */
t4=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* k4717 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4690(2,t4,t3);}

/* k4688 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4662(t3,((C_word*)t0)[2],t2);}

/* k4673 in do959 in k4655 in k4652 in k4649 in k4642 in k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 918  ##sys#write-char-0 */
t2=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[148]+1));}

/* evalstring in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4546(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4546,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4550,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4550(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4593,tmp=(C_word)a,a+=2,tmp));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4550(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* f_4593 in evalstring in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k4548 in evalstring in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4553,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 869  open-input-string */
t3=C_retrieve(lf[160]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4551 in k4548 in evalstring in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 870  read */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4558 in k4551 in k4548 in evalstring in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4560,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4562(t5,((C_word*)t0)[2],t1);}

/* do945 in k4558 in k4551 in k4548 in evalstring in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4562(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4562,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4572,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4583,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4585,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 872  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[301]+1));}}

/* a4584 in do945 in k4558 in k4551 in k4548 in evalstring in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4585,2,t0,t1);}
/* csi.scm: 872  eval */
t2=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k4581 in do945 in k4558 in k4551 in k4548 in evalstring in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 872  rec */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4570 in do945 in k4558 in k4551 in k4548 in evalstring in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 870  read */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4577 in k4570 in do945 in k4558 in k4551 in k4548 in evalstring in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4562(t2,((C_word*)t0)[2],t1);}

/* collect-options in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4466(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4466,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4472,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4472(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4472(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4472,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_member(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
/* csi.scm: 857  ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[300],((C_word*)t0)[3]);}
else{
t5=(C_word)C_i_cadr(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4499,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cddr(t3);
/* csi.scm: 858  loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k4497 in loop in collect-options in k4462 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in k4435 in ##csi#run in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4499,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* canonicalize-args in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4290(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4290,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4296,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4296(t6,t1,t2);}

/* loop in canonicalize-args in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4296(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4296,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[293]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[294]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[295]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[296]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4318,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(2)))){
t6=(C_word)C_eqp(C_make_character(45),(C_word)C_subchar(t3,C_fix(0)));
if(C_truep(t6)){
t7=(C_word)C_i_member(t3,lf[291]);
t8=t4;
f_4318(t8,(C_word)C_i_not(t7));}
else{
t7=t4;
f_4318(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_4318(t6,C_SCHEME_FALSE);}}}}

/* k4316 in loop in canonicalize-args in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4318,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(C_make_character(58),(C_word)C_subchar(((C_word*)t0)[5],C_fix(1)));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 813  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4296(t4,((C_word*)t0)[2],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4368,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 814  substring */
t5=*((C_word*)lf[35]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4375,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 818  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4296(t4,t2,t3);}}

/* k4373 in k4316 in loop in canonicalize-args in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4375,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4366 in k4316 in loop in canonicalize-args in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[298]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4332 in k4316 in loop in canonicalize-args in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4334,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4407,tmp=(C_word)a,a+=2,tmp);
t4=f_4407(t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4347,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4357,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
/* csi.scm: 817  ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[297],((C_word*)t0)[2]);}}

/* a4356 in k4332 in k4316 in loop in canonicalize-args in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4357,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k4345 in k4332 in k4316 in loop in canonicalize-args in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4351,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 816  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4296(t4,t2,t3);}

/* k4349 in k4345 in k4332 in k4316 in loop in canonicalize-args in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 816  append */
t2=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4332 in k4316 in loop in canonicalize-args in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static C_word C_fcall f_4407(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* member* in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4233(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4233,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4239,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4239(t7,t1,t3);}

/* loop in member* in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4239(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4239,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4251,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4251(t6,t1,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* find in loop in member* in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4251(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4251,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 788  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4239(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_i_cdr(t2);
/* csi.scm: 790  find */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##csi#deldups in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4174r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4174r(t0,t1,t2,t3);}}

static void C_ccall f_4174r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4178,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4178(2,t5,*((C_word*)lf[286]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4178(2,t6,(C_word)C_i_car(t3));}
else{
/* csi.scm: 776  ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4176 in ##csi#deldups in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4178,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4183,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4183(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* recur in k4176 in ##csi#deldups in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4183(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4183,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4199,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4212,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 781  del */
t7=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t3,t4,((C_word*)t0)[2]);}}

/* k4210 in recur in k4176 in ##csi#deldups in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 781  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4183(t2,((C_word*)t0)[2],t1);}

/* k4197 in recur in k4176 in ##csi#deldups in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4199,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3965,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3968,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3997,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t8,a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_3997(t10,t1,C_fix(0));}

/* do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3997(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3997,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 749  justify */
t5=((C_word*)t0)[2];
f_3968(t5,t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k4170 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 749  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 750  write-char */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(58),((C_word*)t0)[8]);}

/* k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4013,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4082,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_4082(t6,t2,C_fix(0),((C_word*)t0)[11]);}

/* do821 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4082(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4082,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]));
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4101,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 755  fxmod */
t7=*((C_word*)lf[284]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],C_fix(16));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 760  write-char */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_make_character(32),((C_word*)t0)[7]);}}

/* k4141 in do821 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4146,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4165,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 761  ref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[9]);}

/* k4163 in k4141 in do821 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 761  justify */
t2=((C_word*)t0)[3];
f_3968(t2,((C_word*)t0)[2],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k4159 in k4141 in do821 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 761  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4144 in k4141 in do821 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4082(t4,((C_word*)t0)[2],t2,t3);}

/* k4099 in do821 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4101,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_fixnum_difference(C_fix(16),t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4119(t7,((C_word*)t0)[4],t3);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* do828 in k4099 in do821 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4119(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4119,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4129,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 759  display */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[283],((C_word*)t0)[2]);}}

/* k4127 in do828 in k4099 in do821 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4119(t3,((C_word*)t0)[2],t2);}

/* k4011 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 762  write-char */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(32),((C_word*)t0)[6]);}

/* k4014 in k4011 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4031(t6,t2,C_fix(0),((C_word*)t0)[9]);}

/* do836 in k4014 in k4011 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4031(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4031,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[7]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4044,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 766  ref */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t3);}}

/* k4042 in do836 in k4014 in k4011 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_make_character((C_word)C_unfix(t1));
/* csi.scm: 768  write-char */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,t5,((C_word*)t0)[2]);}
else{
/* csi.scm: 769  write-char */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(46),((C_word*)t0)[2]);}}

/* k4045 in k4042 in do836 in k4014 in k4011 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4031(t4,((C_word*)t0)[2],t2,t3);}

/* k4017 in k4014 in k4011 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 770  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in do811 in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3997(t3,((C_word*)t0)[2],t2);}

/* justify in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3968(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3968,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3972,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 741  number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k3970 in justify in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3988,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[6],t2);
/* csi.scm: 744  make-string */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k3986 in k3970 in justify in ##csi#hexdump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 744  string-append */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##csi#dump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3804r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3804r(t0,t1,t2,t3);}}

static void C_ccall f_3804r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3806,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3912,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3917,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-len786798 */
t7=t6;
f_3917(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-out787796 */
t9=t5;
f_3912(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body784789 */
t11=t4;
f_3806(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-len786 in ##csi#dump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3917,NULL,2,t0,t1);}
/* def-out787796 */
t2=((C_word*)t0)[2];
f_3912(t2,t1,C_SCHEME_FALSE);}

/* def-out787 in ##csi#dump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3912(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3912,NULL,3,t0,t1,t2);}
/* body784789 */
t3=((C_word*)t0)[2];
f_3806(t3,t1,t2,*((C_word*)lf[148]+1));}

/* body784 in ##csi#dump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3806(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3806,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3809,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_immp(((C_word*)t0)[2]))){
/* csi.scm: 723  ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[278],lf[279],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3831,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 724  ##sys#bytevector? */
t6=*((C_word*)lf[269]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3829 in body784 in ##csi#dump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3831,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 724  bestlen */
t4=((C_word*)t0)[2];
f_3809(t4,t2,t3);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3855,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 725  bestlen */
t4=((C_word*)t0)[2];
f_3809(t4,t2,t3);}
else{
t2=(C_word)C_immp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_pointerp(((C_word*)t0)[4]));
if(C_truep(t3)){
/* csi.scm: 727  hexdump */
t4=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],C_fix(32),*((C_word*)lf[280]+1),((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t6=t4;
f_3874(t6,(C_word)C_i_assq(t5,C_retrieve(lf[189])));}
else{
t5=t4;
f_3874(t5,C_SCHEME_FALSE);}}}}}

/* k3872 in k3829 in body784 in ##csi#dump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3874,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3884,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 730  bestlen */
t5=((C_word*)t0)[2];
f_3809(t5,t3,t4);}
else{
/* csi.scm: 731  ##sys#error */
t2=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[278],lf[281],((C_word*)t0)[5]);}}

/* k3882 in k3872 in k3829 in body784 in ##csi#dump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 730  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* k3853 in k3829 in body784 in ##csi#dump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 725  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* k3836 in k3829 in body784 in ##csi#dump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 724  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* bestlen in body784 in ##csi#dump in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3809(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3809,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 722  min */
t3=*((C_word*)lf[277]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-describer! in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3798,4,t0,t1,t2,t3);}
/* csi.scm: 712  hash-table-set! */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve2(lf[191],"describer-table"),t2,t3);}

/* ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3040r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3040r(t0,t1,t2,t3);}}

static void C_ccall f_3040r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=t2,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3044(2,t5,*((C_word*)lf[148]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3044(2,t6,(C_word)C_i_car(t3));}
else{
/* csi.scm: 586  ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3777,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 610  ##sys#block-address */
t5=C_retrieve(lf[275]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[9]);}
else{
t4=t3;
f_3172(2,t4,C_SCHEME_UNDEFINED);}}

/* k3775 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 610  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[274],t1);}

/* k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3175,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_charp(((C_word*)t0)[11]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[11]));
/* csi.scm: 613  fprintf */
t4=((C_word*)t0)[10];
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,((C_word*)t0)[9],lf[203],((C_word*)t0)[11],t3,t3,t3);}
else{
switch(((C_word*)t0)[11]){
case C_SCHEME_TRUE:
/* csi.scm: 614  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[204]);
case C_SCHEME_FALSE:
/* csi.scm: 615  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[205]);
default:
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[11]))){
/* csi.scm: 616  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[206]);}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[11]))){
/* csi.scm: 617  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[207]);}
else{
t3=C_retrieve(lf[13]);
t4=(C_word)C_eqp(t3,((C_word*)t0)[11]);
if(C_truep(t4)){
/* csi.scm: 618  fprintf */
t5=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[9],lf[208]);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[11]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3241,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 620  fprintf */
t6=((C_word*)t0)[10];
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,((C_word*)t0)[9],lf[210],((C_word*)t0)[11],((C_word*)t0)[11],((C_word*)t0)[11],((C_word*)t0)[11]);}
else{
t5=(C_word)C_slot(lf[211],C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[11],t5);
if(C_truep(t6)){
/* csi.scm: 625  fprintf */
t7=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[9],lf[212]);}
else{
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
/* csi.scm: 626  ##sys#number? */
t8=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[11]);}}}}}}}}

/* k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 626  fprintf */
t2=((C_word*)t0)[12];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[11],((C_word*)t0)[10],lf[213],((C_word*)t0)[9]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[9]))){
/* csi.scm: 627  descseq */
t2=((C_word*)t0)[8];
f_3046(6,t2,((C_word*)t0)[11],lf[214],*((C_word*)lf[215]+1),((C_word*)t0)[7],C_fix(0));}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[9]))){
/* csi.scm: 628  descseq */
t2=((C_word*)t0)[8];
f_3046(6,t2,((C_word*)t0)[11],lf[216],*((C_word*)lf[215]+1),*((C_word*)lf[217]+1),C_fix(0));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[9]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 630  ##sys#symbol-has-toplevel-binding? */
t4=C_retrieve(lf[222]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[9]))){
/* csi.scm: 634  descseq */
t2=((C_word*)t0)[8];
f_3046(6,t2,((C_word*)t0)[11],lf[223],((C_word*)t0)[6],((C_word*)t0)[5],C_fix(0));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* csi.scm: 635  fprintf */
t4=((C_word*)t0)[12];
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[11],((C_word*)t0)[10],lf[224],t2,t3);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[9]))){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3378,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(3)))){
if(C_truep((C_word)C_i_memq(lf[228],C_retrieve(lf[18])))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[9],t4);
t6=t3;
f_3378(t6,(C_word)C_eqp(C_retrieve(lf[229]),t5));}
else{
t4=t3;
f_3378(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_3378(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 645  port? */
t3=C_retrieve(lf[272]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}}}}}}}}

/* k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3418,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_truep(t2)?lf[230]:lf[231]);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(7));
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3437,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 651  ##sys#peek-unsigned-integer */
t7=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_memq(lf[228],C_retrieve(lf[18])))){
/* csi.scm: 652  instance? */
t3=C_retrieve(lf[271]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t3=t2;
f_3446(2,t3,C_SCHEME_FALSE);}}}

/* k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3446,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 653  describe-object */
t2=C_retrieve(lf[225]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 654  ##sys#locative? */
t3=C_retrieve(lf[270]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3462,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 656  ##sys#peek-unsigned-integer */
t3=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_fix(0));}
else{
if(C_truep((C_word)C_pointerp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3543,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 669  ##sys#peek-unsigned-integer */
t3=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 670  ##sys#bytevector? */
t3=*((C_word*)lf[269]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}}}

/* k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3549,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3555,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 672  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],lf[247],t2);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3568,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 675  ##sys#lambda-info->string */
t3=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[250]))){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3580,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[253]:lf[254]);
t6=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
/* csi.scm: 678  fprintf */
t7=((C_word*)t0)[5];
((C_proc7)C_retrieve_proc(t7))(7,t7,t3,((C_word*)t0)[6],lf[255],t2,t5,t6);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[256]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* csi.scm: 685  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],lf[261],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[266]))){
/* csi.scm: 695  provided? */
t3=C_retrieve(lf[267]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[268]);}
else{
t3=t2;
f_3683(2,t3,C_SCHEME_FALSE);}}}}}}

/* k3681 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 696  unveil */
t2=C_retrieve(lf[262]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[6]))){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3698,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 699  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[191],"describer-table"),t2,C_SCHEME_FALSE);}
else{
/* csi.scm: 706  fprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[5],lf[265]);}}}

/* k3696 in k3681 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3698,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],t1);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[4],C_retrieve(lf[189]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3726,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* map */
t6=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[63]),t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3737,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
/* csi.scm: 704  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],lf[264],t4);}}}

/* k3735 in k3696 in k3681 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 705  descseq */
t2=((C_word*)t0)[3];
f_3046(6,t2,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[215]+1),*((C_word*)lf[217]+1),C_fix(1));}

/* k3724 in k3696 in k3681 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3726,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_fix(0));
/* csi.scm: 702  append */
t3=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k3720 in k3696 in k3681 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_3705 in k3696 in k3681 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3705,3,t0,t1,t2);}
/* g769770 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3614 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a3620 in k3614 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3621,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3625,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 688  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[260],t2);}

/* k3623 in a3620 in k3614 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3625,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3634(t6,((C_word*)t0)[2],t2);}

/* loop in k3623 in a3620 in k3614 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3634(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3634,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3644,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3669,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 691  caar */
t5=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k3667 in loop in k3623 in a3620 in k3614 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3669,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 692  cdar */
t4=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[3];
f_3644(2,t3,C_SCHEME_UNDEFINED);}}

/* k3659 in k3667 in loop in k3623 in a3620 in k3614 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* csi.scm: 692  fprintf */
t3=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[257],t1,t2);}

/* k3642 in loop in k3623 in a3620 in k3614 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* csi.scm: 693  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3634(t3,((C_word*)t0)[2],t2);}

/* k3578 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm: 680  fprintf */
t4=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],lf[252],t3);}

/* k3581 in k3578 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3588,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 681  hash-table-walk */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3587 in k3581 in k3578 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3588,4,t0,t1,t2,t3);}
/* csi.scm: 683  fprintf */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],lf[251],t2,t3);}

/* k3566 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 675  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[248],t1);}

/* k3553 in k3547 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 673  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* k3541 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 669  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[244],t1);}

/* k3460 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3462,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3473,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_3473(t5,lf[234]);
case C_fix(1):
t5=t4;
f_3473(t5,lf[235]);
case C_fix(2):
t5=t4;
f_3473(t5,lf[236]);
case C_fix(3):
t5=t4;
f_3473(t5,lf[237]);
case C_fix(4):
t5=t4;
f_3473(t5,lf[238]);
case C_fix(5):
t5=t4;
f_3473(t5,lf[239]);
case C_fix(6):
t5=t4;
f_3473(t5,lf[240]);
case C_fix(7):
t5=t4;
f_3473(t5,lf[241]);
case C_fix(8):
t5=t4;
f_3473(t5,lf[242]);
default:
t5=(C_word)C_eqp(t3,C_fix(9));
t6=t4;
f_3473(t6,(C_truep(t5)?lf[243]:C_SCHEME_UNDEFINED));}}

/* k3471 in k3460 in k3453 in k3444 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 655  fprintf */
t2=((C_word*)t0)[6];
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[233],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3435 in k3416 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 646  fprintf */
t2=((C_word*)t0)[7];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[232],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3376 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3378(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3378,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 641  describe-object */
t2=C_retrieve(lf[225]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3392,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 643  ##sys#peek-unsigned-integer */
t4=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[5],C_fix(0));}}

/* k3390 in k3376 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 643  sprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[226],t1);}

/* k3386 in k3376 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 642  descseq */
t2=((C_word*)t0)[3];
f_3046(6,t2,((C_word*)t0)[2],t1,*((C_word*)lf[215]+1),*((C_word*)lf[217]+1),C_fix(1));}

/* k3332 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3301(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 630  display */
t2=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[221],((C_word*)t0)[2]);}}

/* k3299 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_subbyte(t4,C_fix(0));
t6=t3;
f_3314(t6,(C_word)C_eqp(C_fix(0),t5));}
else{
t4=t3;
f_3314(t4,C_SCHEME_FALSE);}}

/* k3312 in k3299 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3314(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 632  display */
t2=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[220],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3304(2,t2,C_SCHEME_UNDEFINED);}}

/* k3302 in k3299 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 633  ##sys#symbol->string */
t3=C_retrieve(lf[219]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3309 in k3302 in k3299 in k3269 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 633  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[218],t1);}

/* k3239 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3241,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3247,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(65536)))){
/* csi.scm: 622  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[209],t2);}
else{
t4=t3;
f_3247(2,t4,C_SCHEME_UNDEFINED);}}

/* k3245 in k3239 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 623  ##sys#write-char-0 */
t2=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[148]+1));}

/* k3173 in k3170 in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* descseq in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3046,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3169,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 589  plen */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k3167 in descseq in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3169,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3053,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 590  fprintf */
t4=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[6],lf[202],((C_word*)t0)[2],t2);}
else{
t4=t3;
f_3053(2,t4,C_SCHEME_UNDEFINED);}}

/* k3051 in k3167 in descseq in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3053,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3058(t5,((C_word*)t0)[2],C_fix(0));}

/* loop1 in k3051 in k3167 in descseq in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3058,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[8],t2);
/* csi.scm: 594  fprintf */
t5=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[6],lf[196],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3081,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],t2);
/* csi.scm: 596  pref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k3079 in loop1 in k3051 in k3167 in descseq in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3081,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3090,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3090(t7,((C_word*)t0)[2],C_fix(1),t3);}

/* loop2 in k3079 in loop1 in k3051 in k3167 in descseq in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3090(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3090,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[10]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3100,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 599  fprintf */
t5=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[6],lf[201],((C_word*)t0)[9],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3154,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 606  pref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k3152 in loop2 in k3079 in loop1 in k3051 in k3167 in descseq in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* csi.scm: 606  loop2 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3090(t5,((C_word*)t0)[3],t3,t4);}
else{
/* csi.scm: 607  loop2 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3090(t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k3098 in loop2 in k3079 in loop1 in k3051 in k3167 in descseq in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3103,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],C_fix(1)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(2));
t5=(C_truep(t4)?lf[197]:lf[198]);
/* csi.scm: 601  fprintf */
t6=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,((C_word*)t0)[2],lf[199],t3,t5);}
else{
/* csi.scm: 604  newline */
t3=*((C_word*)lf[200]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3101 in k3098 in loop2 in k3079 in loop1 in k3051 in k3167 in descseq in k3042 in ##csi#describe in k3036 in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm: 605  loop1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3058(t3,((C_word*)t0)[2],t2);}

/* ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2844(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2844r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2844r(t0,t1,t2);}}

static void C_ccall f_2844r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2852,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_2852(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
/* csi.scm: 514  current-output-port */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 514  with-output-to-port */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 516  gc */
t3=C_retrieve(lf[188]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 517  ##sys#symbol-table-info */
t3=C_retrieve(lf[187]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 518  memory-statistics */
t3=C_retrieve(lf[186]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2866,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 520  printf */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[185]);}

/* k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3016,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3020,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3024,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[184]),C_retrieve(lf[18]));}

/* k3022 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 528  sort */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[183]+1));}

/* k3018 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 528  chop */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k3014 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2982 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2983,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2987,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 523  display */
t4=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[182]);}

/* k2985 in a2982 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2992,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2991 in k2985 in a2982 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2992,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3000,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* csi.scm: 526  make-string */
t7=*((C_word*)lf[181]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t6,C_make_character(32));}

/* k2998 in a2991 in k2985 in a2982 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 526  printf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[180],((C_word*)t0)[2],t1);}

/* k2882 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2887,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2912,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 540  machine-type */
t4=C_retrieve(lf[179]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2910 in k2882 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2912,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(3));
t3=(C_truep(t2)?lf[168]:lf[169]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 542  software-type */
t5=C_retrieve(lf[178]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2918 in k2910 in k2882 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 543  software-version */
t3=C_retrieve(lf[177]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2922 in k2918 in k2910 in k2882 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 544  build-platform */
t3=C_retrieve(lf[176]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2926 in k2922 in k2918 in k2910 in k2882 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2932,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
/* csi.scm: 546  shorten */
f_2866(t2,t3);}

/* k2930 in k2926 in k2922 in k2918 in k2910 in k2882 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2936,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(1));
/* csi.scm: 547  shorten */
f_2866(t2,t3);}

/* k2934 in k2930 in k2926 in k2922 in k2918 in k2910 in k2882 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(2));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
t4=(C_word)C_fudge(C_fix(17));
t5=(C_truep(t4)?lf[170]:lf[171]);
t6=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(2));
t8=(C_word)C_fudge(C_fix(18));
t9=(C_word)C_i_nequalp(C_fix(1),t8);
t10=(C_truep(t9)?lf[172]:lf[173]);
/* csi.scm: 529  printf */
t11=((C_word*)t0)[9];
((C_proc17)C_retrieve_proc(t11))(17,t11,((C_word*)t0)[8],lf[174],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_retrieve(lf[175]),((C_word*)t0)[2],t1,t2,t3,t5,t6,t7,t10);}

/* k2885 in k2882 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 554  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[148]+1));}

/* k2888 in k2885 in k2882 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(14)))){
/* csi.scm: 555  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[167]);}
else{
t3=t2;
f_2893(2,t3,C_SCHEME_UNDEFINED);}}

/* k2891 in k2888 in k2885 in k2882 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(15)))){
/* csi.scm: 556  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[166]);}
else{
t3=t2;
f_2896(2,t3,C_SCHEME_UNDEFINED);}}

/* k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* shorten in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2866(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2866,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2874,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm: 519  truncate */
t5=*((C_word*)lf[165]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2872 in shorten in k2862 in k2859 in k2856 in a2853 in k2850 in ##csi#report in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2874,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_divide(&a,2,t1,C_fix(100)));}

/* ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2741,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2745,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 492  open-input-string */
t4=C_retrieve(lf[160]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2750,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2773,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2775,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 499  call-with-current-continuation */
t6=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* a2774 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2775,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2781,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2793,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 499  with-exception-handler */
t5=C_retrieve(lf[158]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a2792 in a2774 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 499  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2831 in a2792 in a2774 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2832r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2832r(t0,t1,t2);}}

static void C_ccall f_2832r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2838,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 499  g679 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2837 in a2831 in a2792 in a2774 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2838,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2798 in a2792 in a2774 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2807,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 500  read */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2805 in a2798 in a2792 in a2774 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2807,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2809(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do683 in k2805 in a2798 in a2792 in a2774 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2809(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2809,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 502  reverse */
t4=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2826,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 500  read */
t5=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2824 in do683 in k2805 in a2798 in a2792 in a2774 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2809(t3,((C_word*)t0)[2],t1,t2);}

/* a2780 in a2774 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2781,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2787,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 499  g679 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2786 in a2780 in a2774 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2787,2,t0,t1);}
/* csi.scm: 499  ##sys#error */
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[156],((C_word*)t0)[2]);}

/* k2771 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2768 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2749 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2750,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2760,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 496  open-output-string */
t4=C_retrieve(lf[155]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2758 in a2749 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2763,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 497  write */
t3=*((C_word*)lf[70]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2761 in k2758 in a2749 in k2743 in ##csi#parse-option-string in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 498  get-output-string */
t2=C_retrieve(lf[154]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* do-unbreak-all in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2721,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2727,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[104],"broken-procedures"));}

/* a2726 in do-unbreak-all in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2727,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t3,C_fix(0),t4));}

/* k2719 in do-unbreak-all in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[104]=C_SCHEME_END_OF_LIST;;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve(lf[13]));}

/* ##csi#traced-procedure-exit in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2426,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2431,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 396  sub1 */
t5=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_retrieve(lf[76]));}

/* k2429 in ##csi#traced-procedure-exit in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2431,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 397  trace-indent */
t4=C_retrieve(lf[146]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2432 in k2429 in ##csi#traced-procedure-exit in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 398  write */
t3=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2435 in k2432 in k2429 in ##csi#traced-procedure-exit in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 399  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[152]);}

/* k2438 in k2435 in k2432 in k2429 in ##csi#traced-procedure-exit in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2443,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2451,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2450 in k2438 in k2435 in k2432 in k2429 in ##csi#traced-procedure-exit in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2451,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2455,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 402  write */
t4=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2453 in a2450 in k2438 in k2435 in k2432 in k2429 in ##csi#traced-procedure-exit in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(32),*((C_word*)lf[148]+1));}

/* k2441 in k2438 in k2435 in k2432 in k2429 in ##csi#traced-procedure-exit in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 405  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[148]+1));}

/* k2444 in k2441 in k2438 in k2435 in k2432 in k2429 in ##csi#traced-procedure-exit in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 406  flush-output */
t2=*((C_word*)lf[149]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##csi#traced-procedure-entry in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2403,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2407,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 388  trace-indent */
t5=C_retrieve(lf[146]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2405 in ##csi#traced-procedure-entry in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 389  add1 */
t3=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[76]));}

/* k2409 in k2405 in ##csi#traced-procedure-entry in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2411,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* csi.scm: 390  write */
t5=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2412 in k2409 in k2405 in ##csi#traced-procedure-entry in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 391  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[148]+1));}

/* k2415 in k2412 in k2409 in k2405 in ##csi#traced-procedure-entry in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 392  flush-output */
t2=*((C_word*)lf[149]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##csi#trace-indent in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2379,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(124),*((C_word*)lf[148]+1));}

/* k2377 in ##csi#trace-indent in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2384,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2384(t5,((C_word*)t0)[2],C_retrieve(lf[76]));}

/* do617 in k2377 in ##csi#trace-indent in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2384(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2384,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2394,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(32),*((C_word*)lf[148]+1));}}

/* k2392 in do617 in k2377 in ##csi#trace-indent in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 382  sub1 */
t3=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2399 in k2392 in do617 in k2377 in ##csi#trace-indent in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2384(t2,((C_word*)t0)[2],t1);}

/* ##csi#del in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2334,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2340,a[2]=t2,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2340(t8,t1,t3);}

/* loop in ##csi#del in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2340(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2340,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2356,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 371  tst */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k2354 in loop in ##csi#del in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2356,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 373  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2340(t4,t2,t3);}}

/* k2364 in k2354 in loop in ##csi#del in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2366,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1796,3,t0,t1,t2);}
t3=C_set_block_item(lf[76],0,C_fix(0));
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 239  exit */
t4=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=t4;
f_1813(t6,(C_word)C_eqp(lf[145],t5));}
else{
t5=t4;
f_1813(t5,C_SCHEME_FALSE);}}}

/* k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1813,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1819,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* csi.scm: 243  hash-table-ref/default */
t4=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[60],"command-table"),t2,C_SCHEME_FALSE);}
else{
t4=t3;
f_1819(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2309,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2315,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 359  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t2,t3);}}

/* a2314 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2315r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2315r(t0,t1,t2);}}

static void C_ccall f_2315r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2319,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 360  history-add */
t4=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2317 in a2314 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2308 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2309,2,t0,t1);}
/* csi.scm: 359  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[123],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1819,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1825,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(t1);
t4=t3;
((C_proc2)C_retrieve_proc(t4))(2,t4,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[78]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 250  read */
t4=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[80]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1859,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 254  read */
t5=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[81]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 259  read */
t6=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[83]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 263  read */
t7=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[85]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1907,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 267  read */
t8=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[86]);
if(C_truep(t7)){
/* csi.scm: 272  report */
t8=C_retrieve(lf[87]);
((C_proc2)C_retrieve_proc(t8))(2,t8,((C_word*)t0)[15]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[88]);
if(C_truep(t8)){
/* csi.scm: 273  exit */
t9=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t9))(2,t9,((C_word*)t0)[15]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[89]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1946,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1956,a[2]=t10,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 275  read-line */
t12=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[92]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1965,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1990,a[2]=t11,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 279  read-line */
t13=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[96]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 283  read */
t13=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[100]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2052,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2056,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2060,a[2]=t14,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 287  read-line */
t16=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t16))(2,t16,t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[111]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2077,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2081,a[2]=t15,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 288  read-line */
t17=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t17))(2,t17,t16);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[115]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2098,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2102,a[2]=t16,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 289  read-line */
t18=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t18))(2,t18,t17);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[120]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2115,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2119,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2123,a[2]=t17,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 290  read-line */
t19=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t19))(2,t19,t18);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[122]);
if(C_truep(t16)){
/* csi.scm: 291  do-unbreak-all */
t17=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t17))(2,t17,((C_word*)t0)[15]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[124]);
if(C_truep(t17)){
t18=C_set_block_item(lf[125],0,C_SCHEME_FALSE);
t19=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[126]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2153,a[2]=t19,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 295  read */
t21=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t21))(2,t21,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[14],lf[127]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2162,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[101],"traced-procedures")))){
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2185,a[2]=t20,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t22=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t21,*((C_word*)lf[129]+1),C_retrieve2(lf[101],"traced-procedures"));}
else{
t21=t20;
f_2162(2,t21,C_SCHEME_UNDEFINED);}}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[131]);
if(C_truep(t20)){
if(C_truep(C_retrieve(lf[132]))){
t21=C_retrieve(lf[132]);
t22=C_set_block_item(lf[132],0,C_SCHEME_FALSE);
/* csi.scm: 305  ##sys#break-resume */
t23=C_retrieve(lf[133]);
((C_proc3)C_retrieve_proc(t23))(3,t23,((C_word*)t0)[15],t21);}
else{
/* csi.scm: 306  display */
t21=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t21))(3,t21,((C_word*)t0)[15],lf[134]);}}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[135]);
if(C_truep(t21)){
if(C_truep(C_retrieve(lf[136]))){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2213,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_a_i_list(&a,1,C_retrieve(lf[136]));
/* csi.scm: 309  history-add */
t24=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t22,t23);}
else{
t22=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_UNDEFINED);}}
else{
t22=(C_word)C_eqp(((C_word*)t0)[14],lf[137]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 312  read */
t24=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t24))(2,t24,t23);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[138]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2252,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 316  read-line */
t25=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t25))(2,t25,t24);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[140]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 321  display */
t26=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,lf[142]);}
else{
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2295,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 356  printf */
t26=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t26))(4,t26,t25,lf[143],((C_word*)t0)[2]);}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2293 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k2269 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2279,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 347  hash-table-walk */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve2(lf[60],"command-table"),t3);}

/* a2278 in k2269 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2279,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep(t4)){
/* csi.scm: 352  print */
t5=*((C_word*)lf[24]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,C_make_character(32),t4);}
else{
/* csi.scm: 353  print */
t5=*((C_word*)lf[24]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[141],t2);}}

/* k2272 in k2269 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k2250 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 317  system */
t3=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2253 in k2250 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2258,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* csi.scm: 318  history-add */
t4=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2256 in k2253 in k2250 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2227 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2232,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 313  read-line */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2230 in k2227 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
/* csi.scm: 314  eval */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2237 in k2230 in k2227 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 314  singlestep */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2211 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 310  describe */
t2=C_retrieve(lf[82]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[136]));}

/* k2183 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 298  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[130],t1);}

/* k2160 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2162,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[104],"broken-procedures")))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[129]+1),C_retrieve2(lf[104],"broken-procedures"));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2173 in k2160 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 300  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[128],t1);}

/* k2151 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 295  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2147 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[125]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2121 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 290  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2117 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2113 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2115,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2688,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2687 in k2113 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2688,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2692,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 473  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2690 in a2687 in k2113 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2692,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[104],"broken-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 478  del */
t6=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,C_retrieve2(lf[104],"broken-procedures"),*((C_word*)lf[113]+1));}
else{
/* csi.scm: 475  ##sys#warn */
t3=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[121],t1);}}

/* k2709 in k2690 in a2687 in k2113 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[104],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2100 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 289  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2096 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2092 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2094,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2607,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[104],"broken-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2620,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2619 in k2092 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2620(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2620,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2624,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 452  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2622 in a2619 in k2092 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2624,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[101],"traced-procedures"));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2669,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 455  ##sys#warn */
t5=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[119],t1);}
else{
t4=t3;
f_2630(t4,C_SCHEME_UNDEFINED);}}

/* k2667 in k2622 in a2619 in k2092 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 457  del */
t5=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_retrieve2(lf[101],"traced-procedures"),*((C_word*)lf[113]+1));}

/* k2674 in k2667 in k2622 in a2619 in k2092 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[101],t1);
t3=((C_word*)t0)[2];
f_2630(t3,t2);}

/* k2628 in k2622 in a2619 in k2092 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2630,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[104],"broken-procedures"));
t5=C_mutate(&lf[104],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t6));}
else{
/* csi.scm: 459  ##sys#error */
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[118],((C_word*)t0)[3]);}}

/* a2650 in k2628 in k2622 in a2619 in k2092 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2651r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2651r(t0,t1,t2);}}

static void C_ccall f_2651r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2655,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 465  ##sys#break-entry */
t4=C_retrieve(lf[117]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2653 in a2650 in k2628 in k2622 in a2619 in k2092 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2606 in k2092 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2607,3,t0,t1,t2);}
t3=(C_word)C_i_car(C_retrieve(lf[116]));
/* csi.scm: 449  print */
t4=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k2079 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 288  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2075 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2071 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2073,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2566,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2565 in k2071 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2566,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2570,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 438  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2568 in a2565 in k2071 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[101],"traced-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 443  del */
t6=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,C_retrieve2(lf[101],"traced-procedures"),*((C_word*)lf[113]+1));}
else{
/* csi.scm: 440  ##sys#warn */
t3=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[114],t1);}}

/* k2587 in k2568 in a2565 in k2071 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[101],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2058 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 287  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2054 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2050 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2052,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2472,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[101],"traced-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2485,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2484 in k2050 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2485,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2489,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 414  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2487 in a2484 in k2050 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[101],"traced-procedures")))){
/* csi.scm: 416  ##sys#warn */
t2=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[103],t1);}
else{
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[104],"broken-procedures")))){
/* csi.scm: 418  ##sys#warn */
t2=C_retrieve(lf[102]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[105]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[101],"traced-procedures"));
t5=C_mutate(&lf[101],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2528,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t1,C_fix(0),t6));}
else{
/* csi.scm: 421  ##sys#error */
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[108],t1);}}}}

/* a2527 in k2487 in a2484 in k2050 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2528r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2528r(t0,t1,t2);}}

static void C_ccall f_2528r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2532,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 427  traced-procedure-entry */
t4=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2530 in a2527 in k2487 in a2484 in k2050 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2537,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2543,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 428  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2542 in k2530 in a2527 in k2487 in a2484 in k2050 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2543r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2543r(t0,t1,t2);}}

static void C_ccall f_2543r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2547,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 430  traced-procedure-exit */
t4=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2545 in a2542 in k2530 in a2527 in k2487 in a2484 in k2050 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2536 in k2530 in a2527 in k2487 in a2484 in k2050 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2537,2,t0,t1);}
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2471 in k2050 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2472(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2472,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* csi.scm: 411  print */
t4=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k1997 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2004,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2031 in k1997 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2032r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2032r(t0,t1,t2);}}

static void C_ccall f_2032r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2036,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 285  history-add */
t4=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2034 in a2031 in k1997 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2003 in k1997 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2008,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[99]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2006 in a2003 in k1997 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2019,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2018 in k2006 in a2003 in k1997 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2019r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2019r(t0,t1,t2);}}

static void C_ccall f_2019r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2023,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2030,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[98]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2028 in a2018 in k2006 in a2003 in k1997 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
t2=C_retrieve(lf[97]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2021 in a2018 in k2006 in a2003 in k1997 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2012 in k2006 in a2003 in k1997 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2013,2,t0,t1);}
/* csi.scm: 284  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1988 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 279  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1963 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a1972 in k1963 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1973,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* load-noisily542 */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,lf[95],t3);}

/* a1978 in a1972 in k1963 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1979,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1983,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 280  pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1981 in a1978 in a1972 in k1963 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 280  print* */
t2=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[94]);}

/* k1966 in k1963 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1954 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 275  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1944 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[91]),t1);}

/* k1947 in k1944 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1905 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1910,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 268  read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1908 in k1905 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1913,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 269  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1911 in k1908 in k1905 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1916,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 270  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1914 in k1911 in k1908 in k1905 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 271  dump */
t2=C_retrieve(lf[84]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1890 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 264  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1893 in k1890 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 265  dump */
t2=C_retrieve(lf[84]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1875 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 260  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1878 in k1875 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 261  describe */
t2=C_retrieve(lf[82]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1857 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 255  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1860 in k1857 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1865,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 256  pretty-print */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1863 in k1860 in k1857 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1838 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1850,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 251  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k1848 in k1838 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 251  pretty-print */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1841 in k1838 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1823 in k1817 in k1811 in ##sys#repl-eval-hook in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* toplevel-command in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1755r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1755r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1755r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1759,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1759(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1759(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1757 in toplevel-command in k1751 in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[5],lf[62]);
t3=(C_truep(t1)?(C_word)C_i_check_string_2(t1,lf[62]):C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* csi.scm: 218  hash-table-set! */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],C_retrieve2(lf[60],"command-table"),((C_word*)t0)[5],t4);}

/* ##sys#read-prompt-hook in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1746,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 209  tty-input? */
t3=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1744 in ##sys#read-prompt-hook in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 209  old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##csi#tty-input? in k1722 in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1726,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm: 202  ##sys#tty-port? */
t3=C_retrieve(lf[56]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,*((C_word*)lf[57]+1));}}

/* ##csi#history-ref in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1699,3,t0,t1,t2);}
t3=(C_word)C_i_inexact_to_exact(t2);
t4=(C_word)C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(t3,C_retrieve(lf[31])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_vector_ref(C_retrieve(lf[50]),t3));}
else{
/* csi.scm: 194  ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[54],t2);}}

/* ##csi#history-add in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1660,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_retrieve(lf[13]):(C_word)C_slot(t2,C_fix(0)));
t5=(C_word)C_block_size(C_retrieve(lf[50]));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1670,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_retrieve(lf[31]),t5))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1684,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_times(C_fix(2),t5);
/* csi.scm: 185  vector-resize */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve(lf[50]),t8);}
else{
t7=t6;
f_1670(t7,C_SCHEME_UNDEFINED);}}

/* k1682 in ##csi#history-add in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[50]+1,t1);
t3=((C_word*)t0)[2];
f_1670(t3,t2);}

/* k1668 in ##csi#history-add in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1670(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_vector_set(C_retrieve(lf[50]),C_retrieve(lf[31]),((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(C_retrieve(lf[31]),C_fix(1));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1554,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 158  getenv */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[49]);}

/* k1556 in ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1558,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t4=f_1444(t3);
if(C_truep(t4)){
/* csi.scm: 160  addext */
f_1506(((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t5=((C_word*)t0)[5];
t6=(C_word)C_block_size(t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1533,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=f_1533(t7,C_fix(0));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=((C_word*)t0)[2];
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t12=(C_truep(t10)?(C_word)C_i_foreign_block_argumentp(t10):C_SCHEME_FALSE);
t13=(C_word)C_i_foreign_fixnum_argumentp(C_fix(256));
t14=(C_word)stub486(t11,t12,t13);
/* ##sys#peek-nonnull-c-string */
t15=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t9,t14,C_fix(0));}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 164  addext */
f_1506(t9,((C_word*)t0)[5]);}}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1597 in k1556 in ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1599,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 166  string-append */
t3=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[47],((C_word*)t0)[2]);}}

/* k1603 in k1597 in k1556 in ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1612,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 167  string-split */
t3=C_retrieve(lf[45]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[46]);}

/* k1610 in k1603 in k1597 in k1556 in ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1612,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1614(t5,((C_word*)t0)[2],t1);}

/* loop in k1610 in k1603 in k1597 in k1556 in ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1614(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1614,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1641,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 169  chop-separator */
t6=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1639 in loop in k1610 in k1603 in k1597 in k1556 in ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 169  string-append */
t2=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1622 in loop in k1610 in k1603 in k1597 in k1556 in ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1627,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 170  addext */
f_1506(t2,t1);}

/* k1625 in k1622 in loop in k1610 in k1603 in k1597 in k1556 in ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 171  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1614(t3,((C_word*)t0)[4],t2);}}

/* k1580 in k1556 in ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 163  chop-separator */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1594 in k1580 in k1556 in ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 163  string-append */
t2=*((C_word*)lf[40]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[43],((C_word*)t0)[2]);}

/* k1590 in k1580 in k1556 in ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 163  addext */
f_1506(((C_word*)t0)[2],t1);}

/* loop in k1556 in ##csi#lookup-script-file in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static C_word C_fcall f_1533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(C_SCHEME_FALSE);}
else{
t2=f_1444((C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* addext in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1506(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1506,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1513,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 147  file-exists? */
t4=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1511 in addext in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1513,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 149  string-append */
t3=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k1514 in k1511 in addext in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1522,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 150  file-exists? */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1520 in k1514 in k1511 in addext in k1485 in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##csi#chop-separator in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1456,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1460,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 132  sub1 */
t5=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1458 in ##csi#chop-separator in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_string_ref(((C_word*)t0)[4],t1);
t3=(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(0)))?f_1444(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
/* csi.scm: 135  substring */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],((C_word*)t0)[4],C_fix(0),t1);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}}

/* dirseparator? in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static C_word C_fcall f_1444(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(t1,C_make_character(92));
return((C_truep(t2)?t2:(C_word)C_eqp(t1,C_make_character(47))));}

/* ##sys#sharp-number-hook in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1434,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1442,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 121  history-ref */
t5=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1440 in ##sys#sharp-number-hook in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1442,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[30],t1));}

/* ##sys#user-read-hook in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1405,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:(C_word)C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1422,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_difference(C_retrieve(lf[31]),C_fix(1));
/* csi.scm: 116  history-ref */
t8=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
/* csi.scm: 117  old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* k1420 in ##sys#user-read-hook in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1422,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[30],t1));}

/* ##csi#print-banner in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 105  chicken-version */
t3=C_retrieve(lf[26]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k1401 in ##csi#print-banner in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 105  print */
t2=*((C_word*)lf[24]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[12],t1,lf[25]);}

/* ##csi#print-usage in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1387,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 75   display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[22]);}

/* k1385 in ##csi#print-usage in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1390,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 90   display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[14]);}

/* k1388 in k1385 in ##csi#print-usage in k1369 in k1366 in k1363 in k1360 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1221 in k1218 in k1215 in k1212 in k1209 in k1206 in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 91   display */
t2=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[21]);}

/* assign in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1135,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1139,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[9],t2,lf[10]);}

/* k1137 in assign in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1139,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[4]);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t2,t4));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t3,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1176,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   map */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[7]),((C_word*)t0)[5]);}}}

/* k1174 in k1137 in assign in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1176,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1195,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1197,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a1196 in k1174 in k1137 in assign in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1197,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k1193 in k1174 in k1137 in assign in k1132 in k1129 in k1126 in k1123 in k1120 in k1117 in k1114 in k1111 in k1108 in k1105 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1195,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[768] = {
{"toplevelcsi.scm",(void*)C_toplevel},
{"f_1074csi.scm",(void*)f_1074},
{"f_1077csi.scm",(void*)f_1077},
{"f_1080csi.scm",(void*)f_1080},
{"f_1083csi.scm",(void*)f_1083},
{"f_1086csi.scm",(void*)f_1086},
{"f_1089csi.scm",(void*)f_1089},
{"f_1092csi.scm",(void*)f_1092},
{"f_1095csi.scm",(void*)f_1095},
{"f_1098csi.scm",(void*)f_1098},
{"f_8736csi.scm",(void*)f_8736},
{"f_8740csi.scm",(void*)f_8740},
{"f_8743csi.scm",(void*)f_8743},
{"f_8746csi.scm",(void*)f_8746},
{"f_8752csi.scm",(void*)f_8752},
{"f_8958csi.scm",(void*)f_8958},
{"f_8938csi.scm",(void*)f_8938},
{"f_8934csi.scm",(void*)f_8934},
{"f_8914csi.scm",(void*)f_8914},
{"f_8777csi.scm",(void*)f_8777},
{"f_8787csi.scm",(void*)f_8787},
{"f_8906csi.scm",(void*)f_8906},
{"f_8790csi.scm",(void*)f_8790},
{"f_8902csi.scm",(void*)f_8902},
{"f_8793csi.scm",(void*)f_8793},
{"f_8824csi.scm",(void*)f_8824},
{"f_8804csi.scm",(void*)f_8804},
{"f_8775csi.scm",(void*)f_8775},
{"f_1101csi.scm",(void*)f_1101},
{"f_8648csi.scm",(void*)f_8648},
{"f_8665csi.scm",(void*)f_8665},
{"f_8668csi.scm",(void*)f_8668},
{"f_8674csi.scm",(void*)f_8674},
{"f_1104csi.scm",(void*)f_1104},
{"f_8607csi.scm",(void*)f_8607},
{"f_8611csi.scm",(void*)f_8611},
{"f_1107csi.scm",(void*)f_1107},
{"f_8591csi.scm",(void*)f_8591},
{"f_8601csi.scm",(void*)f_8601},
{"f_8599csi.scm",(void*)f_8599},
{"f_1110csi.scm",(void*)f_1110},
{"f_8514csi.scm",(void*)f_8514},
{"f_8518csi.scm",(void*)f_8518},
{"f_8586csi.scm",(void*)f_8586},
{"f_8521csi.scm",(void*)f_8521},
{"f_8530csi.scm",(void*)f_8530},
{"f_8577csi.scm",(void*)f_8577},
{"f_8544csi.scm",(void*)f_8544},
{"f_8552csi.scm",(void*)f_8552},
{"f_8554csi.scm",(void*)f_8554},
{"f_8571csi.scm",(void*)f_8571},
{"f_8536csi.scm",(void*)f_8536},
{"f_8528csi.scm",(void*)f_8528},
{"f_1113csi.scm",(void*)f_1113},
{"f_8454csi.scm",(void*)f_8454},
{"f_8458csi.scm",(void*)f_8458},
{"f_1116csi.scm",(void*)f_1116},
{"f_8395csi.scm",(void*)f_8395},
{"f_8399csi.scm",(void*)f_8399},
{"f_8426csi.scm",(void*)f_8426},
{"f_1119csi.scm",(void*)f_1119},
{"f_8221csi.scm",(void*)f_8221},
{"f_8225csi.scm",(void*)f_8225},
{"f_8228csi.scm",(void*)f_8228},
{"f_8389csi.scm",(void*)f_8389},
{"f_8231csi.scm",(void*)f_8231},
{"f_8383csi.scm",(void*)f_8383},
{"f_8234csi.scm",(void*)f_8234},
{"f_8381csi.scm",(void*)f_8381},
{"f_8345csi.scm",(void*)f_8345},
{"f_8359csi.scm",(void*)f_8359},
{"f_8373csi.scm",(void*)f_8373},
{"f_8353csi.scm",(void*)f_8353},
{"f_8349csi.scm",(void*)f_8349},
{"f_8241csi.scm",(void*)f_8241},
{"f_8337csi.scm",(void*)f_8337},
{"f_8313csi.scm",(void*)f_8313},
{"f_8331csi.scm",(void*)f_8331},
{"f_8321csi.scm",(void*)f_8321},
{"f_8317csi.scm",(void*)f_8317},
{"f_8309csi.scm",(void*)f_8309},
{"f_8293csi.scm",(void*)f_8293},
{"f_8269csi.scm",(void*)f_8269},
{"f_8287csi.scm",(void*)f_8287},
{"f_8277csi.scm",(void*)f_8277},
{"f_8273csi.scm",(void*)f_8273},
{"f_8265csi.scm",(void*)f_8265},
{"f_1122csi.scm",(void*)f_1122},
{"f_8126csi.scm",(void*)f_8126},
{"f_8162csi.scm",(void*)f_8162},
{"f_8175csi.scm",(void*)f_8175},
{"f_8133csi.scm",(void*)f_8133},
{"f_1125csi.scm",(void*)f_1125},
{"f_8016csi.scm",(void*)f_8016},
{"f_8020csi.scm",(void*)f_8020},
{"f_8023csi.scm",(void*)f_8023},
{"f_8026csi.scm",(void*)f_8026},
{"f_8029csi.scm",(void*)f_8029},
{"f_8120csi.scm",(void*)f_8120},
{"f_8032csi.scm",(void*)f_8032},
{"f_8114csi.scm",(void*)f_8114},
{"f_8035csi.scm",(void*)f_8035},
{"f_8108csi.scm",(void*)f_8108},
{"f_8112csi.scm",(void*)f_8112},
{"f_8042csi.scm",(void*)f_8042},
{"f_8080csi.scm",(void*)f_8080},
{"f_8078csi.scm",(void*)f_8078},
{"f_1128csi.scm",(void*)f_1128},
{"f_8006csi.scm",(void*)f_8006},
{"f_1131csi.scm",(void*)f_1131},
{"f_7992csi.scm",(void*)f_7992},
{"f_1134csi.scm",(void*)f_1134},
{"f_1208csi.scm",(void*)f_1208},
{"f_1211csi.scm",(void*)f_1211},
{"f_7730csi.scm",(void*)f_7730},
{"f_7734csi.scm",(void*)f_7734},
{"f_7743csi.scm",(void*)f_7743},
{"f_7952csi.scm",(void*)f_7952},
{"f_7965csi.scm",(void*)f_7965},
{"f_7746csi.scm",(void*)f_7746},
{"f_7942csi.scm",(void*)f_7942},
{"f_7950csi.scm",(void*)f_7950},
{"f_7749csi.scm",(void*)f_7749},
{"f_7896csi.scm",(void*)f_7896},
{"f_7929csi.scm",(void*)f_7929},
{"f_7936csi.scm",(void*)f_7936},
{"f_7912csi.scm",(void*)f_7912},
{"f_7761csi.scm",(void*)f_7761},
{"f_7890csi.scm",(void*)f_7890},
{"f_7768csi.scm",(void*)f_7768},
{"f_7770csi.scm",(void*)f_7770},
{"f_7884csi.scm",(void*)f_7884},
{"f_7804csi.scm",(void*)f_7804},
{"f_7858csi.scm",(void*)f_7858},
{"f_7835csi.scm",(void*)f_7835},
{"f_7815csi.scm",(void*)f_7815},
{"f_7790csi.scm",(void*)f_7790},
{"f_7798csi.scm",(void*)f_7798},
{"f_7788csi.scm",(void*)f_7788},
{"f_7750csi.scm",(void*)f_7750},
{"f_7690csi.scm",(void*)f_7690},
{"f_7713csi.scm",(void*)f_7713},
{"f_7717csi.scm",(void*)f_7717},
{"f_7659csi.scm",(void*)f_7659},
{"f_7680csi.scm",(void*)f_7680},
{"f_1214csi.scm",(void*)f_1214},
{"f_7608csi.scm",(void*)f_7608},
{"f_7612csi.scm",(void*)f_7612},
{"f_7623csi.scm",(void*)f_7623},
{"f_7648csi.scm",(void*)f_7648},
{"f_1217csi.scm",(void*)f_1217},
{"f_7488csi.scm",(void*)f_7488},
{"f_7492csi.scm",(void*)f_7492},
{"f_7602csi.scm",(void*)f_7602},
{"f_7600csi.scm",(void*)f_7600},
{"f_7501csi.scm",(void*)f_7501},
{"f_7588csi.scm",(void*)f_7588},
{"f_7596csi.scm",(void*)f_7596},
{"f_7504csi.scm",(void*)f_7504},
{"f_7582csi.scm",(void*)f_7582},
{"f_7524csi.scm",(void*)f_7524},
{"f_7534csi.scm",(void*)f_7534},
{"f_7554csi.scm",(void*)f_7554},
{"f_7560csi.scm",(void*)f_7560},
{"f_7568csi.scm",(void*)f_7568},
{"f_7558csi.scm",(void*)f_7558},
{"f_7532csi.scm",(void*)f_7532},
{"f_7528csi.scm",(void*)f_7528},
{"f_7505csi.scm",(void*)f_7505},
{"f_1220csi.scm",(void*)f_1220},
{"f_7467csi.scm",(void*)f_7467},
{"f_7471csi.scm",(void*)f_7471},
{"f_1223csi.scm",(void*)f_1223},
{"f_7457csi.scm",(void*)f_7457},
{"f_1229csi.scm",(void*)f_1229},
{"f_1238csi.scm",(void*)f_1238},
{"f_1254csi.scm",(void*)f_1254},
{"f_1241csi.scm",(void*)f_1241},
{"f_1302csi.scm",(void*)f_1302},
{"f_7436csi.scm",(void*)f_7436},
{"f_7440csi.scm",(void*)f_7440},
{"f_1305csi.scm",(void*)f_1305},
{"f_7320csi.scm",(void*)f_7320},
{"f_7324csi.scm",(void*)f_7324},
{"f_7333csi.scm",(void*)f_7333},
{"f_7347csi.scm",(void*)f_7347},
{"f_7411csi.scm",(void*)f_7411},
{"f_7393csi.scm",(void*)f_7393},
{"f_7376csi.scm",(void*)f_7376},
{"f_1308csi.scm",(void*)f_1308},
{"f_7221csi.scm",(void*)f_7221},
{"f_7231csi.scm",(void*)f_7231},
{"f_7244csi.scm",(void*)f_7244},
{"f_7260csi.scm",(void*)f_7260},
{"f_7298csi.scm",(void*)f_7298},
{"f_7296csi.scm",(void*)f_7296},
{"f_7288csi.scm",(void*)f_7288},
{"f_7242csi.scm",(void*)f_7242},
{"f_1311csi.scm",(void*)f_1311},
{"f_7132csi.scm",(void*)f_7132},
{"f_7142csi.scm",(void*)f_7142},
{"f_7155csi.scm",(void*)f_7155},
{"f_7171csi.scm",(void*)f_7171},
{"f_7199csi.scm",(void*)f_7199},
{"f_7153csi.scm",(void*)f_7153},
{"f_1314csi.scm",(void*)f_1314},
{"f_6846csi.scm",(void*)f_6846},
{"f_7043csi.scm",(void*)f_7043},
{"f_7046csi.scm",(void*)f_7046},
{"f_7049csi.scm",(void*)f_7049},
{"f_7122csi.scm",(void*)f_7122},
{"f_7130csi.scm",(void*)f_7130},
{"f_7065csi.scm",(void*)f_7065},
{"f_7068csi.scm",(void*)f_7068},
{"f_7071csi.scm",(void*)f_7071},
{"f_7074csi.scm",(void*)f_7074},
{"f_7112csi.scm",(void*)f_7112},
{"f_7120csi.scm",(void*)f_7120},
{"f_7077csi.scm",(void*)f_7077},
{"f_6857csi.scm",(void*)f_6857},
{"f_6861csi.scm",(void*)f_6861},
{"f_6865csi.scm",(void*)f_6865},
{"f_6867csi.scm",(void*)f_6867},
{"f_6912csi.scm",(void*)f_6912},
{"f_6924csi.scm",(void*)f_6924},
{"f_6920csi.scm",(void*)f_6920},
{"f_6888csi.scm",(void*)f_6888},
{"f_7080csi.scm",(void*)f_7080},
{"f_6940csi.scm",(void*)f_6940},
{"f_7040csi.scm",(void*)f_7040},
{"f_7004csi.scm",(void*)f_7004},
{"f_6974csi.scm",(void*)f_6974},
{"f_7083csi.scm",(void*)f_7083},
{"f_7050csi.scm",(void*)f_7050},
{"f_7062csi.scm",(void*)f_7062},
{"f_7058csi.scm",(void*)f_7058},
{"f_1317csi.scm",(void*)f_1317},
{"f_6789csi.scm",(void*)f_6789},
{"f_6793csi.scm",(void*)f_6793},
{"f_1320csi.scm",(void*)f_1320},
{"f_6783csi.scm",(void*)f_6783},
{"f_1323csi.scm",(void*)f_1323},
{"f_6630csi.scm",(void*)f_6630},
{"f_6634csi.scm",(void*)f_6634},
{"f_6637csi.scm",(void*)f_6637},
{"f_6640csi.scm",(void*)f_6640},
{"f_6653csi.scm",(void*)f_6653},
{"f_6703csi.scm",(void*)f_6703},
{"f_6714csi.scm",(void*)f_6714},
{"f_6651csi.scm",(void*)f_6651},
{"f_1326csi.scm",(void*)f_1326},
{"f_6354csi.scm",(void*)f_6354},
{"f_6388csi.scm",(void*)f_6388},
{"f_6391csi.scm",(void*)f_6391},
{"f_6617csi.scm",(void*)f_6617},
{"f_6627csi.scm",(void*)f_6627},
{"f_6615csi.scm",(void*)f_6615},
{"f_6394csi.scm",(void*)f_6394},
{"f_6363csi.scm",(void*)f_6363},
{"f_6377csi.scm",(void*)f_6377},
{"f_6381csi.scm",(void*)f_6381},
{"f_6397csi.scm",(void*)f_6397},
{"f_6400csi.scm",(void*)f_6400},
{"f_6403csi.scm",(void*)f_6403},
{"f_6410csi.scm",(void*)f_6410},
{"f_6424csi.scm",(void*)f_6424},
{"f_6434csi.scm",(void*)f_6434},
{"f_6438csi.scm",(void*)f_6438},
{"f_6448csi.scm",(void*)f_6448},
{"f_6464csi.scm",(void*)f_6464},
{"f_6483csi.scm",(void*)f_6483},
{"f_6539csi.scm",(void*)f_6539},
{"f_6550csi.scm",(void*)f_6550},
{"f_6468csi.scm",(void*)f_6468},
{"f_6481csi.scm",(void*)f_6481},
{"f_6454csi.scm",(void*)f_6454},
{"f_6462csi.scm",(void*)f_6462},
{"f_6452csi.scm",(void*)f_6452},
{"f_6422csi.scm",(void*)f_6422},
{"f_1329csi.scm",(void*)f_1329},
{"f_6297csi.scm",(void*)f_6297},
{"f_6337csi.scm",(void*)f_6337},
{"f_6307csi.scm",(void*)f_6307},
{"f_1332csi.scm",(void*)f_1332},
{"f_6221csi.scm",(void*)f_6221},
{"f_6225csi.scm",(void*)f_6225},
{"f_6228csi.scm",(void*)f_6228},
{"f_1335csi.scm",(void*)f_1335},
{"f_6037csi.scm",(void*)f_6037},
{"f_6041csi.scm",(void*)f_6041},
{"f_6044csi.scm",(void*)f_6044},
{"f_6187csi.scm",(void*)f_6187},
{"f_6183csi.scm",(void*)f_6183},
{"f_6046csi.scm",(void*)f_6046},
{"f_6134csi.scm",(void*)f_6134},
{"f_6132csi.scm",(void*)f_6132},
{"f_6102csi.scm",(void*)f_6102},
{"f_6069csi.scm",(void*)f_6069},
{"f_1338csi.scm",(void*)f_1338},
{"f_5847csi.scm",(void*)f_5847},
{"f_5854csi.scm",(void*)f_5854},
{"f_6028csi.scm",(void*)f_6028},
{"f_6026csi.scm",(void*)f_6026},
{"f_5879csi.scm",(void*)f_5879},
{"f_5905csi.scm",(void*)f_5905},
{"f_5933csi.scm",(void*)f_5933},
{"f_5925csi.scm",(void*)f_5925},
{"f_5917csi.scm",(void*)f_5917},
{"f_5877csi.scm",(void*)f_5877},
{"f_1341csi.scm",(void*)f_1341},
{"f_5838csi.scm",(void*)f_5838},
{"f_5842csi.scm",(void*)f_5842},
{"f_1344csi.scm",(void*)f_1344},
{"f_5819csi.scm",(void*)f_5819},
{"f_5823csi.scm",(void*)f_5823},
{"f_5832csi.scm",(void*)f_5832},
{"f_5830csi.scm",(void*)f_5830},
{"f_1347csi.scm",(void*)f_1347},
{"f_5800csi.scm",(void*)f_5800},
{"f_5804csi.scm",(void*)f_5804},
{"f_5813csi.scm",(void*)f_5813},
{"f_5811csi.scm",(void*)f_5811},
{"f_1350csi.scm",(void*)f_1350},
{"f_5672csi.scm",(void*)f_5672},
{"f_5678csi.scm",(void*)f_5678},
{"f_5759csi.scm",(void*)f_5759},
{"f_5688csi.scm",(void*)f_5688},
{"f_5691csi.scm",(void*)f_5691},
{"f_5697csi.scm",(void*)f_5697},
{"f_5704csi.scm",(void*)f_5704},
{"f_5720csi.scm",(void*)f_5720},
{"f_1353csi.scm",(void*)f_1353},
{"f_5529csi.scm",(void*)f_5529},
{"f_5535csi.scm",(void*)f_5535},
{"f_5647csi.scm",(void*)f_5647},
{"f_5620csi.scm",(void*)f_5620},
{"f_5545csi.scm",(void*)f_5545},
{"f_5548csi.scm",(void*)f_5548},
{"f_5554csi.scm",(void*)f_5554},
{"f_5565csi.scm",(void*)f_5565},
{"f_5581csi.scm",(void*)f_5581},
{"f_1356csi.scm",(void*)f_1356},
{"f_5470csi.scm",(void*)f_5470},
{"f_1359csi.scm",(void*)f_1359},
{"f_5299csi.scm",(void*)f_5299},
{"f_5305csi.scm",(void*)f_5305},
{"f_5379csi.scm",(void*)f_5379},
{"f_5382csi.scm",(void*)f_5382},
{"f_5455csi.scm",(void*)f_5455},
{"f_5448csi.scm",(void*)f_5448},
{"f_5440csi.scm",(void*)f_5440},
{"f_5427csi.scm",(void*)f_5427},
{"f_5406csi.scm",(void*)f_5406},
{"f_5315csi.scm",(void*)f_5315},
{"f_1362csi.scm",(void*)f_1362},
{"f_5248csi.scm",(void*)f_5248},
{"f_1365csi.scm",(void*)f_1365},
{"f_5188csi.scm",(void*)f_5188},
{"f_5198csi.scm",(void*)f_5198},
{"f_5217csi.scm",(void*)f_5217},
{"f_5201csi.scm",(void*)f_5201},
{"f_1368csi.scm",(void*)f_1368},
{"f_1371csi.scm",(void*)f_1371},
{"f_1487csi.scm",(void*)f_1487},
{"f_5182csi.scm",(void*)f_5182},
{"f_1724csi.scm",(void*)f_1724},
{"f_1753csi.scm",(void*)f_1753},
{"f_3038csi.scm",(void*)f_3038},
{"f_5174csi.scm",(void*)f_5174},
{"f_5180csi.scm",(void*)f_5180},
{"f_5177csi.scm",(void*)f_5177},
{"f_4433csi.scm",(void*)f_4433},
{"f_5168csi.scm",(void*)f_5168},
{"f_4437csi.scm",(void*)f_4437},
{"f_5164csi.scm",(void*)f_5164},
{"f_4440csi.scm",(void*)f_4440},
{"f_4443csi.scm",(void*)f_4443},
{"f_4446csi.scm",(void*)f_4446},
{"f_5160csi.scm",(void*)f_5160},
{"f_5147csi.scm",(void*)f_5147},
{"f_5107csi.scm",(void*)f_5107},
{"f_5057csi.scm",(void*)f_5057},
{"f_5060csi.scm",(void*)f_5060},
{"f_5063csi.scm",(void*)f_5063},
{"f_5066csi.scm",(void*)f_5066},
{"f_5075csi.scm",(void*)f_5075},
{"f_4449csi.scm",(void*)f_4449},
{"f_4452csi.scm",(void*)f_4452},
{"f_5051csi.scm",(void*)f_5051},
{"f_4455csi.scm",(void*)f_4455},
{"f_4458csi.scm",(void*)f_4458},
{"f_5042csi.scm",(void*)f_5042},
{"f_5038csi.scm",(void*)f_5038},
{"f_4464csi.scm",(void*)f_4464},
{"f_4616csi.scm",(void*)f_4616},
{"f_5027csi.scm",(void*)f_5027},
{"f_5030csi.scm",(void*)f_5030},
{"f_4619csi.scm",(void*)f_4619},
{"f_5018csi.scm",(void*)f_5018},
{"f_5021csi.scm",(void*)f_5021},
{"f_4622csi.scm",(void*)f_4622},
{"f_5015csi.scm",(void*)f_5015},
{"f_5008csi.scm",(void*)f_5008},
{"f_4625csi.scm",(void*)f_4625},
{"f_4995csi.scm",(void*)f_4995},
{"f_4998csi.scm",(void*)f_4998},
{"f_4628csi.scm",(void*)f_4628},
{"f_4989csi.scm",(void*)f_4989},
{"f_4631csi.scm",(void*)f_4631},
{"f_4974csi.scm",(void*)f_4974},
{"f_4977csi.scm",(void*)f_4977},
{"f_4980csi.scm",(void*)f_4980},
{"f_4634csi.scm",(void*)f_4634},
{"f_4971csi.scm",(void*)f_4971},
{"f_4637csi.scm",(void*)f_4637},
{"f_4967csi.scm",(void*)f_4967},
{"f_4640csi.scm",(void*)f_4640},
{"f_4963csi.scm",(void*)f_4963},
{"f_4951csi.scm",(void*)f_4951},
{"f_4959csi.scm",(void*)f_4959},
{"f_4955csi.scm",(void*)f_4955},
{"f_4947csi.scm",(void*)f_4947},
{"f_4644csi.scm",(void*)f_4644},
{"f_4651csi.scm",(void*)f_4651},
{"f_4654csi.scm",(void*)f_4654},
{"f_4881csi.scm",(void*)f_4881},
{"f_4513csi.scm",(void*)f_4513},
{"f_4519csi.scm",(void*)f_4519},
{"f_4541csi.scm",(void*)f_4541},
{"f_4525csi.scm",(void*)f_4525},
{"f_4528csi.scm",(void*)f_4528},
{"f_4534csi.scm",(void*)f_4534},
{"f_4657csi.scm",(void*)f_4657},
{"f_4662csi.scm",(void*)f_4662},
{"f_4814csi.scm",(void*)f_4814},
{"f_4820csi.scm",(void*)f_4820},
{"f_4835csi.scm",(void*)f_4835},
{"f_4846csi.scm",(void*)f_4846},
{"f_4825csi.scm",(void*)f_4825},
{"f_4833csi.scm",(void*)f_4833},
{"f_4807csi.scm",(void*)f_4807},
{"f_4797csi.scm",(void*)f_4797},
{"f_4781csi.scm",(void*)f_4781},
{"f_4771csi.scm",(void*)f_4771},
{"f_4751csi.scm",(void*)f_4751},
{"f_4735csi.scm",(void*)f_4735},
{"f_4719csi.scm",(void*)f_4719},
{"f_4690csi.scm",(void*)f_4690},
{"f_4675csi.scm",(void*)f_4675},
{"f_4546csi.scm",(void*)f_4546},
{"f_4593csi.scm",(void*)f_4593},
{"f_4550csi.scm",(void*)f_4550},
{"f_4553csi.scm",(void*)f_4553},
{"f_4560csi.scm",(void*)f_4560},
{"f_4562csi.scm",(void*)f_4562},
{"f_4585csi.scm",(void*)f_4585},
{"f_4583csi.scm",(void*)f_4583},
{"f_4572csi.scm",(void*)f_4572},
{"f_4579csi.scm",(void*)f_4579},
{"f_4466csi.scm",(void*)f_4466},
{"f_4472csi.scm",(void*)f_4472},
{"f_4499csi.scm",(void*)f_4499},
{"f_4290csi.scm",(void*)f_4290},
{"f_4296csi.scm",(void*)f_4296},
{"f_4318csi.scm",(void*)f_4318},
{"f_4375csi.scm",(void*)f_4375},
{"f_4368csi.scm",(void*)f_4368},
{"f_4334csi.scm",(void*)f_4334},
{"f_4357csi.scm",(void*)f_4357},
{"f_4347csi.scm",(void*)f_4347},
{"f_4351csi.scm",(void*)f_4351},
{"f_4407csi.scm",(void*)f_4407},
{"f_4233csi.scm",(void*)f_4233},
{"f_4239csi.scm",(void*)f_4239},
{"f_4251csi.scm",(void*)f_4251},
{"f_4174csi.scm",(void*)f_4174},
{"f_4178csi.scm",(void*)f_4178},
{"f_4183csi.scm",(void*)f_4183},
{"f_4212csi.scm",(void*)f_4212},
{"f_4199csi.scm",(void*)f_4199},
{"f_3965csi.scm",(void*)f_3965},
{"f_3997csi.scm",(void*)f_3997},
{"f_4172csi.scm",(void*)f_4172},
{"f_4007csi.scm",(void*)f_4007},
{"f_4010csi.scm",(void*)f_4010},
{"f_4082csi.scm",(void*)f_4082},
{"f_4143csi.scm",(void*)f_4143},
{"f_4165csi.scm",(void*)f_4165},
{"f_4161csi.scm",(void*)f_4161},
{"f_4146csi.scm",(void*)f_4146},
{"f_4101csi.scm",(void*)f_4101},
{"f_4119csi.scm",(void*)f_4119},
{"f_4129csi.scm",(void*)f_4129},
{"f_4013csi.scm",(void*)f_4013},
{"f_4016csi.scm",(void*)f_4016},
{"f_4031csi.scm",(void*)f_4031},
{"f_4044csi.scm",(void*)f_4044},
{"f_4047csi.scm",(void*)f_4047},
{"f_4019csi.scm",(void*)f_4019},
{"f_4022csi.scm",(void*)f_4022},
{"f_3968csi.scm",(void*)f_3968},
{"f_3972csi.scm",(void*)f_3972},
{"f_3988csi.scm",(void*)f_3988},
{"f_3804csi.scm",(void*)f_3804},
{"f_3917csi.scm",(void*)f_3917},
{"f_3912csi.scm",(void*)f_3912},
{"f_3806csi.scm",(void*)f_3806},
{"f_3831csi.scm",(void*)f_3831},
{"f_3874csi.scm",(void*)f_3874},
{"f_3884csi.scm",(void*)f_3884},
{"f_3855csi.scm",(void*)f_3855},
{"f_3838csi.scm",(void*)f_3838},
{"f_3809csi.scm",(void*)f_3809},
{"f_3798csi.scm",(void*)f_3798},
{"f_3040csi.scm",(void*)f_3040},
{"f_3044csi.scm",(void*)f_3044},
{"f_3777csi.scm",(void*)f_3777},
{"f_3172csi.scm",(void*)f_3172},
{"f_3271csi.scm",(void*)f_3271},
{"f_3418csi.scm",(void*)f_3418},
{"f_3446csi.scm",(void*)f_3446},
{"f_3455csi.scm",(void*)f_3455},
{"f_3549csi.scm",(void*)f_3549},
{"f_3683csi.scm",(void*)f_3683},
{"f_3698csi.scm",(void*)f_3698},
{"f_3737csi.scm",(void*)f_3737},
{"f_3726csi.scm",(void*)f_3726},
{"f_3722csi.scm",(void*)f_3722},
{"f_3705csi.scm",(void*)f_3705},
{"f_3616csi.scm",(void*)f_3616},
{"f_3621csi.scm",(void*)f_3621},
{"f_3625csi.scm",(void*)f_3625},
{"f_3634csi.scm",(void*)f_3634},
{"f_3669csi.scm",(void*)f_3669},
{"f_3661csi.scm",(void*)f_3661},
{"f_3644csi.scm",(void*)f_3644},
{"f_3580csi.scm",(void*)f_3580},
{"f_3583csi.scm",(void*)f_3583},
{"f_3588csi.scm",(void*)f_3588},
{"f_3568csi.scm",(void*)f_3568},
{"f_3555csi.scm",(void*)f_3555},
{"f_3543csi.scm",(void*)f_3543},
{"f_3462csi.scm",(void*)f_3462},
{"f_3473csi.scm",(void*)f_3473},
{"f_3437csi.scm",(void*)f_3437},
{"f_3378csi.scm",(void*)f_3378},
{"f_3392csi.scm",(void*)f_3392},
{"f_3388csi.scm",(void*)f_3388},
{"f_3334csi.scm",(void*)f_3334},
{"f_3301csi.scm",(void*)f_3301},
{"f_3314csi.scm",(void*)f_3314},
{"f_3304csi.scm",(void*)f_3304},
{"f_3311csi.scm",(void*)f_3311},
{"f_3241csi.scm",(void*)f_3241},
{"f_3247csi.scm",(void*)f_3247},
{"f_3175csi.scm",(void*)f_3175},
{"f_3046csi.scm",(void*)f_3046},
{"f_3169csi.scm",(void*)f_3169},
{"f_3053csi.scm",(void*)f_3053},
{"f_3058csi.scm",(void*)f_3058},
{"f_3081csi.scm",(void*)f_3081},
{"f_3090csi.scm",(void*)f_3090},
{"f_3154csi.scm",(void*)f_3154},
{"f_3100csi.scm",(void*)f_3100},
{"f_3103csi.scm",(void*)f_3103},
{"f_2844csi.scm",(void*)f_2844},
{"f_2852csi.scm",(void*)f_2852},
{"f_2854csi.scm",(void*)f_2854},
{"f_2858csi.scm",(void*)f_2858},
{"f_2861csi.scm",(void*)f_2861},
{"f_2864csi.scm",(void*)f_2864},
{"f_2881csi.scm",(void*)f_2881},
{"f_3024csi.scm",(void*)f_3024},
{"f_3020csi.scm",(void*)f_3020},
{"f_3016csi.scm",(void*)f_3016},
{"f_2983csi.scm",(void*)f_2983},
{"f_2987csi.scm",(void*)f_2987},
{"f_2992csi.scm",(void*)f_2992},
{"f_3000csi.scm",(void*)f_3000},
{"f_2884csi.scm",(void*)f_2884},
{"f_2912csi.scm",(void*)f_2912},
{"f_2920csi.scm",(void*)f_2920},
{"f_2924csi.scm",(void*)f_2924},
{"f_2928csi.scm",(void*)f_2928},
{"f_2932csi.scm",(void*)f_2932},
{"f_2936csi.scm",(void*)f_2936},
{"f_2887csi.scm",(void*)f_2887},
{"f_2890csi.scm",(void*)f_2890},
{"f_2893csi.scm",(void*)f_2893},
{"f_2896csi.scm",(void*)f_2896},
{"f_2866csi.scm",(void*)f_2866},
{"f_2874csi.scm",(void*)f_2874},
{"f_2741csi.scm",(void*)f_2741},
{"f_2745csi.scm",(void*)f_2745},
{"f_2775csi.scm",(void*)f_2775},
{"f_2793csi.scm",(void*)f_2793},
{"f_2832csi.scm",(void*)f_2832},
{"f_2838csi.scm",(void*)f_2838},
{"f_2799csi.scm",(void*)f_2799},
{"f_2807csi.scm",(void*)f_2807},
{"f_2809csi.scm",(void*)f_2809},
{"f_2826csi.scm",(void*)f_2826},
{"f_2781csi.scm",(void*)f_2781},
{"f_2787csi.scm",(void*)f_2787},
{"f_2773csi.scm",(void*)f_2773},
{"f_2770csi.scm",(void*)f_2770},
{"f_2750csi.scm",(void*)f_2750},
{"f_2760csi.scm",(void*)f_2760},
{"f_2763csi.scm",(void*)f_2763},
{"f_2717csi.scm",(void*)f_2717},
{"f_2727csi.scm",(void*)f_2727},
{"f_2721csi.scm",(void*)f_2721},
{"f_2426csi.scm",(void*)f_2426},
{"f_2431csi.scm",(void*)f_2431},
{"f_2434csi.scm",(void*)f_2434},
{"f_2437csi.scm",(void*)f_2437},
{"f_2440csi.scm",(void*)f_2440},
{"f_2451csi.scm",(void*)f_2451},
{"f_2455csi.scm",(void*)f_2455},
{"f_2443csi.scm",(void*)f_2443},
{"f_2446csi.scm",(void*)f_2446},
{"f_2403csi.scm",(void*)f_2403},
{"f_2407csi.scm",(void*)f_2407},
{"f_2411csi.scm",(void*)f_2411},
{"f_2414csi.scm",(void*)f_2414},
{"f_2417csi.scm",(void*)f_2417},
{"f_2375csi.scm",(void*)f_2375},
{"f_2379csi.scm",(void*)f_2379},
{"f_2384csi.scm",(void*)f_2384},
{"f_2394csi.scm",(void*)f_2394},
{"f_2401csi.scm",(void*)f_2401},
{"f_2334csi.scm",(void*)f_2334},
{"f_2340csi.scm",(void*)f_2340},
{"f_2356csi.scm",(void*)f_2356},
{"f_2366csi.scm",(void*)f_2366},
{"f_1796csi.scm",(void*)f_1796},
{"f_1813csi.scm",(void*)f_1813},
{"f_2315csi.scm",(void*)f_2315},
{"f_2319csi.scm",(void*)f_2319},
{"f_2309csi.scm",(void*)f_2309},
{"f_1819csi.scm",(void*)f_1819},
{"f_2295csi.scm",(void*)f_2295},
{"f_2271csi.scm",(void*)f_2271},
{"f_2279csi.scm",(void*)f_2279},
{"f_2274csi.scm",(void*)f_2274},
{"f_2252csi.scm",(void*)f_2252},
{"f_2255csi.scm",(void*)f_2255},
{"f_2258csi.scm",(void*)f_2258},
{"f_2229csi.scm",(void*)f_2229},
{"f_2232csi.scm",(void*)f_2232},
{"f_2239csi.scm",(void*)f_2239},
{"f_2213csi.scm",(void*)f_2213},
{"f_2185csi.scm",(void*)f_2185},
{"f_2162csi.scm",(void*)f_2162},
{"f_2175csi.scm",(void*)f_2175},
{"f_2153csi.scm",(void*)f_2153},
{"f_2149csi.scm",(void*)f_2149},
{"f_2123csi.scm",(void*)f_2123},
{"f_2119csi.scm",(void*)f_2119},
{"f_2115csi.scm",(void*)f_2115},
{"f_2688csi.scm",(void*)f_2688},
{"f_2692csi.scm",(void*)f_2692},
{"f_2711csi.scm",(void*)f_2711},
{"f_2102csi.scm",(void*)f_2102},
{"f_2098csi.scm",(void*)f_2098},
{"f_2094csi.scm",(void*)f_2094},
{"f_2620csi.scm",(void*)f_2620},
{"f_2624csi.scm",(void*)f_2624},
{"f_2669csi.scm",(void*)f_2669},
{"f_2676csi.scm",(void*)f_2676},
{"f_2630csi.scm",(void*)f_2630},
{"f_2651csi.scm",(void*)f_2651},
{"f_2655csi.scm",(void*)f_2655},
{"f_2607csi.scm",(void*)f_2607},
{"f_2081csi.scm",(void*)f_2081},
{"f_2077csi.scm",(void*)f_2077},
{"f_2073csi.scm",(void*)f_2073},
{"f_2566csi.scm",(void*)f_2566},
{"f_2570csi.scm",(void*)f_2570},
{"f_2589csi.scm",(void*)f_2589},
{"f_2060csi.scm",(void*)f_2060},
{"f_2056csi.scm",(void*)f_2056},
{"f_2052csi.scm",(void*)f_2052},
{"f_2485csi.scm",(void*)f_2485},
{"f_2489csi.scm",(void*)f_2489},
{"f_2528csi.scm",(void*)f_2528},
{"f_2532csi.scm",(void*)f_2532},
{"f_2543csi.scm",(void*)f_2543},
{"f_2547csi.scm",(void*)f_2547},
{"f_2537csi.scm",(void*)f_2537},
{"f_2472csi.scm",(void*)f_2472},
{"f_1999csi.scm",(void*)f_1999},
{"f_2032csi.scm",(void*)f_2032},
{"f_2036csi.scm",(void*)f_2036},
{"f_2004csi.scm",(void*)f_2004},
{"f_2008csi.scm",(void*)f_2008},
{"f_2019csi.scm",(void*)f_2019},
{"f_2030csi.scm",(void*)f_2030},
{"f_2023csi.scm",(void*)f_2023},
{"f_2013csi.scm",(void*)f_2013},
{"f_1990csi.scm",(void*)f_1990},
{"f_1965csi.scm",(void*)f_1965},
{"f_1973csi.scm",(void*)f_1973},
{"f_1979csi.scm",(void*)f_1979},
{"f_1983csi.scm",(void*)f_1983},
{"f_1968csi.scm",(void*)f_1968},
{"f_1956csi.scm",(void*)f_1956},
{"f_1946csi.scm",(void*)f_1946},
{"f_1949csi.scm",(void*)f_1949},
{"f_1907csi.scm",(void*)f_1907},
{"f_1910csi.scm",(void*)f_1910},
{"f_1913csi.scm",(void*)f_1913},
{"f_1916csi.scm",(void*)f_1916},
{"f_1892csi.scm",(void*)f_1892},
{"f_1895csi.scm",(void*)f_1895},
{"f_1877csi.scm",(void*)f_1877},
{"f_1880csi.scm",(void*)f_1880},
{"f_1859csi.scm",(void*)f_1859},
{"f_1862csi.scm",(void*)f_1862},
{"f_1865csi.scm",(void*)f_1865},
{"f_1840csi.scm",(void*)f_1840},
{"f_1850csi.scm",(void*)f_1850},
{"f_1843csi.scm",(void*)f_1843},
{"f_1825csi.scm",(void*)f_1825},
{"f_1755csi.scm",(void*)f_1755},
{"f_1759csi.scm",(void*)f_1759},
{"f_1739csi.scm",(void*)f_1739},
{"f_1746csi.scm",(void*)f_1746},
{"f_1726csi.scm",(void*)f_1726},
{"f_1699csi.scm",(void*)f_1699},
{"f_1660csi.scm",(void*)f_1660},
{"f_1684csi.scm",(void*)f_1684},
{"f_1670csi.scm",(void*)f_1670},
{"f_1554csi.scm",(void*)f_1554},
{"f_1558csi.scm",(void*)f_1558},
{"f_1599csi.scm",(void*)f_1599},
{"f_1605csi.scm",(void*)f_1605},
{"f_1612csi.scm",(void*)f_1612},
{"f_1614csi.scm",(void*)f_1614},
{"f_1641csi.scm",(void*)f_1641},
{"f_1624csi.scm",(void*)f_1624},
{"f_1627csi.scm",(void*)f_1627},
{"f_1582csi.scm",(void*)f_1582},
{"f_1596csi.scm",(void*)f_1596},
{"f_1592csi.scm",(void*)f_1592},
{"f_1533csi.scm",(void*)f_1533},
{"f_1506csi.scm",(void*)f_1506},
{"f_1513csi.scm",(void*)f_1513},
{"f_1516csi.scm",(void*)f_1516},
{"f_1522csi.scm",(void*)f_1522},
{"f_1456csi.scm",(void*)f_1456},
{"f_1460csi.scm",(void*)f_1460},
{"f_1444csi.scm",(void*)f_1444},
{"f_1434csi.scm",(void*)f_1434},
{"f_1442csi.scm",(void*)f_1442},
{"f_1405csi.scm",(void*)f_1405},
{"f_1422csi.scm",(void*)f_1422},
{"f_1395csi.scm",(void*)f_1395},
{"f_1403csi.scm",(void*)f_1403},
{"f_1383csi.scm",(void*)f_1383},
{"f_1387csi.scm",(void*)f_1387},
{"f_1390csi.scm",(void*)f_1390},
{"f_1135csi.scm",(void*)f_1135},
{"f_1139csi.scm",(void*)f_1139},
{"f_1176csi.scm",(void*)f_1176},
{"f_1197csi.scm",(void*)f_1197},
{"f_1195csi.scm",(void*)f_1195},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
