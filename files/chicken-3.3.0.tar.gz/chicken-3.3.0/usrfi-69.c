/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-06-28 11:53
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10664	compiled 2008-06-28 on galinha (Linux)
   command line: srfi-69.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file usrfi-69.c -extend private-namespace.scm
   unit: srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[118];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_69_toplevel)
C_externexport void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_611)
static void C_ccall f_611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3307)
static void C_fcall f_3307(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3323)
static void C_fcall f_3323(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3258)
static void C_fcall f_3258(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3196)
static void C_fcall f_3196(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3212)
static void C_fcall f_3212(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3131)
static void C_fcall f_3131(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3147)
static void C_fcall f_3147(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3030)
static void C_fcall f_3030(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3046)
static void C_fcall f_3046(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2932)
static void C_fcall f_2932(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2955)
static void C_fcall f_2955(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_fcall f_2829(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2855)
static void C_fcall f_2855(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static C_word C_fcall f_2713(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_fcall f_2601(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_fcall f_2559(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2457)
static void C_fcall f_2457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_fcall f_2440(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_fcall f_2426(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2209)
static void C_fcall f_2209(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_fcall f_2231(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_fcall f_2332(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_fcall f_2269(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2121)
static void C_fcall f_2121(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2144)
static void C_fcall f_2144(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_fcall f_2003(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2065)
static void C_fcall f_2065(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_fcall f_1607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_fcall f_1610(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1613)
static void C_fcall f_1613(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_fcall f_1648(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1701)
static void C_ccall f_1701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1691)
static void C_ccall f_1691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_fcall f_1659(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_fcall f_1626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static C_word C_fcall f_1531(C_word t0);
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,...) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t11) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1481)
static C_word C_fcall f_1481(C_word t0,C_word t1);
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1177)
static void C_fcall f_1177(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1299)
static void C_ccall f_1299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1278)
static void C_ccall f_1278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1252)
static void C_ccall f_1252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_fcall f_1146(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1081)
static void C_fcall f_1081(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1098)
static void C_fcall f_1098(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_915)
static void C_ccall f_915(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_915)
static void C_ccall f_915r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_933)
static void C_ccall f_933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_854)
static void C_ccall f_854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_809)
static void C_ccall f_809(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_809)
static void C_ccall f_809r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_816)
static void C_ccall f_816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_783)
static void C_ccall f_783(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_783)
static void C_ccall f_783r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_790)
static void C_ccall f_790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_738)
static void C_ccall f_738(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_738)
static void C_ccall f_738r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_697)
static void C_ccall f_697(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_697)
static void C_ccall f_697r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_715)
static void C_ccall f_715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_691)
static void C_ccall f_691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_625)
static void C_ccall f_625(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_625)
static void C_ccall f_625r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_632)
static void C_ccall f_632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_671)
static void C_ccall f_671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_646)
static void C_fcall f_646(C_word t0,C_word t1) C_noret;
C_noret_decl(f_619)
static void C_ccall f_619(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_613)
static void C_ccall f_613(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3307)
static void C_fcall trf_3307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3307(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3307(t0,t1,t2,t3);}

C_noret_decl(trf_3323)
static void C_fcall trf_3323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3323(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3323(t0,t1,t2,t3);}

C_noret_decl(trf_3258)
static void C_fcall trf_3258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3258(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3258(t0,t1,t2);}

C_noret_decl(trf_3196)
static void C_fcall trf_3196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3196(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3196(t0,t1,t2,t3);}

C_noret_decl(trf_3212)
static void C_fcall trf_3212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3212(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3212(t0,t1,t2,t3);}

C_noret_decl(trf_3131)
static void C_fcall trf_3131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3131(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3131(t0,t1,t2,t3);}

C_noret_decl(trf_3147)
static void C_fcall trf_3147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3147(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3147(t0,t1,t2,t3);}

C_noret_decl(trf_3030)
static void C_fcall trf_3030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3030(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3030(t0,t1,t2,t3);}

C_noret_decl(trf_3046)
static void C_fcall trf_3046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3046(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3046(t0,t1,t2,t3);}

C_noret_decl(trf_2932)
static void C_fcall trf_2932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2932(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2932(t0,t1,t2);}

C_noret_decl(trf_2955)
static void C_fcall trf_2955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2955(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2955(t0,t1,t2);}

C_noret_decl(trf_2829)
static void C_fcall trf_2829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2829(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2829(t0,t1,t2);}

C_noret_decl(trf_2855)
static void C_fcall trf_2855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2855(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2855(t0,t1,t2,t3);}

C_noret_decl(trf_2760)
static void C_fcall trf_2760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2760(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2760(t0,t1,t2,t3);}

C_noret_decl(trf_2601)
static void C_fcall trf_2601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2601(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2601(t0,t1,t2);}

C_noret_decl(trf_2559)
static void C_fcall trf_2559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2559(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2559(t0,t1,t2);}

C_noret_decl(trf_2457)
static void C_fcall trf_2457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2457(t0,t1);}

C_noret_decl(trf_2440)
static void C_fcall trf_2440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2440(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2440(t0,t1,t2);}

C_noret_decl(trf_2426)
static void C_fcall trf_2426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2426(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2426(t0,t1,t2,t3);}

C_noret_decl(trf_2209)
static void C_fcall trf_2209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2209(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2209(t0,t1);}

C_noret_decl(trf_2231)
static void C_fcall trf_2231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2231(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2231(t0,t1);}

C_noret_decl(trf_2332)
static void C_fcall trf_2332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2332(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2332(t0,t1,t2);}

C_noret_decl(trf_2269)
static void C_fcall trf_2269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2269(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2269(t0,t1,t2);}

C_noret_decl(trf_2121)
static void C_fcall trf_2121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2121(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2121(t0,t1,t2);}

C_noret_decl(trf_2144)
static void C_fcall trf_2144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2144(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2144(t0,t1,t2);}

C_noret_decl(trf_2003)
static void C_fcall trf_2003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2003(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2003(t0,t1,t2);}

C_noret_decl(trf_2065)
static void C_fcall trf_2065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2065(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2065(t0,t1,t2);}

C_noret_decl(trf_1607)
static void C_fcall trf_1607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1607(t0,t1);}

C_noret_decl(trf_1610)
static void C_fcall trf_1610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1610(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1610(t0,t1);}

C_noret_decl(trf_1613)
static void C_fcall trf_1613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1613(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1613(t0,t1);}

C_noret_decl(trf_1648)
static void C_fcall trf_1648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1648(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1648(t0,t1,t2);}

C_noret_decl(trf_1659)
static void C_fcall trf_1659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1659(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1659(t0,t1,t2);}

C_noret_decl(trf_1626)
static void C_fcall trf_1626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1626(t0,t1);}

C_noret_decl(trf_1177)
static void C_fcall trf_1177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1177(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1177(t0,t1,t2,t3);}

C_noret_decl(trf_1146)
static void C_fcall trf_1146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1146(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1146(t0,t1,t2,t3);}

C_noret_decl(trf_1081)
static void C_fcall trf_1081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1081(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1081(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1098)
static void C_fcall trf_1098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1098(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1098(t0,t1,t2,t3,t4);}

C_noret_decl(trf_646)
static void C_fcall trf_646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_646(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_646(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr10rv)
static void C_fcall tr10rv(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10rv(C_proc10 k){
int n;
C_word *a,t10;
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
n=C_rest_count(0);
a=C_alloc(n+1);
t10=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_69_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1043)){
C_save(t1);
C_rereclaim2(1043*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,118);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],27,"\007srfi-69unbound-value-thunk");
lf[4]=C_h_intern(&lf[4],28,"\003sysarbitrary-unbound-symbol");
lf[5]=C_h_intern(&lf[5],20,"\003sysnumber-hash-hook");
lf[6]=C_h_intern(&lf[6],20,"\007srfi-69%equal\077-hash");
lf[7]=C_h_intern(&lf[7],11,"number-hash");
lf[8]=C_h_intern(&lf[8],4,"\077obj");
lf[9]=C_h_intern(&lf[9],15,"\003syssignal-hook");
lf[10]=C_h_intern(&lf[10],5,"\000type");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[12]=C_h_intern(&lf[12],24,"\007srfi-69%object-uid-hash");
lf[13]=C_h_intern(&lf[13],15,"object-uid-hash");
lf[14]=C_h_intern(&lf[14],11,"symbol-hash");
lf[15]=C_h_intern(&lf[15],11,"string-hash");
lf[16]=C_h_intern(&lf[16],17,"\003syscheck-keyword");
lf[17]=C_h_intern(&lf[17],11,"\000type-error");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[19]=C_h_intern(&lf[19],8,"keyword\077");
lf[20]=C_h_intern(&lf[20],12,"keyword-hash");
lf[21]=C_h_intern(&lf[21],17,"\007srfi-69%eq\077-hash");
lf[22]=C_h_intern(&lf[22],8,"eq\077-hash");
lf[23]=C_h_intern(&lf[23],16,"hash-by-identity");
lf[24]=C_h_intern(&lf[24],18,"\007srfi-69%eqv\077-hash");
lf[25]=C_h_intern(&lf[25],9,"eqv\077-hash");
lf[26]=C_h_intern(&lf[26],11,"input-port\077");
lf[27]=C_h_intern(&lf[27],11,"equal\077-hash");
lf[28]=C_h_intern(&lf[28],4,"hash");
lf[29]=C_h_intern(&lf[29],14,"string-ci-hash");
lf[31]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[32]=C_h_intern(&lf[32],35,"\007srfi-69hash-table-canonical-length");
lf[33]=C_h_intern(&lf[33],11,"make-vector");
lf[34]=C_h_intern(&lf[34],16,"%make-hash-table");
lf[35]=C_h_intern(&lf[35],10,"hash-table");
lf[36]=C_h_intern(&lf[36],3,"eq\077");
lf[37]=C_h_intern(&lf[37],4,"eqv\077");
lf[38]=C_h_intern(&lf[38],6,"equal\077");
lf[39]=C_h_intern(&lf[39],8,"string=\077");
lf[40]=C_h_intern(&lf[40],11,"string-ci=\077");
lf[41]=C_h_intern(&lf[41],1,"=");
lf[42]=C_h_intern(&lf[42],15,"make-hash-table");
lf[43]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[44]=C_decode_literal(C_heaptop,"\376U0.8\000");
lf[45]=C_h_intern(&lf[45],7,"warning");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[47]=C_h_intern(&lf[47],5,"error");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[49]=C_h_intern(&lf[49],5,"\000test");
lf[50]=C_h_intern(&lf[50],17,"\003syscheck-closure");
lf[51]=C_h_intern(&lf[51],5,"\000hash");
lf[52]=C_h_intern(&lf[52],5,"\000size");
lf[53]=C_h_intern(&lf[53],19,"hash-table-max-size");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[55]=C_h_intern(&lf[55],8,"\000initial");
lf[56]=C_h_intern(&lf[56],9,"\000min-load");
lf[57]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[58]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[60]=C_h_intern(&lf[60],17,"\003syscheck-inexact");
lf[61]=C_h_intern(&lf[61],9,"\000max-load");
lf[62]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[63]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[65]=C_h_intern(&lf[65],10,"\000weak-keys");
lf[66]=C_h_intern(&lf[66],12,"\000weak-values");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[71]=C_h_intern(&lf[71],11,"hash-table\077");
lf[72]=C_h_intern(&lf[72],15,"hash-table-size");
lf[73]=C_h_intern(&lf[73],31,"hash-table-equivalence-function");
lf[74]=C_h_intern(&lf[74],24,"hash-table-hash-function");
lf[75]=C_h_intern(&lf[75],19,"hash-table-min-load");
lf[76]=C_h_intern(&lf[76],19,"hash-table-max-load");
lf[77]=C_h_intern(&lf[77],20,"hash-table-weak-keys");
lf[78]=C_h_intern(&lf[78],22,"hash-table-weak-values");
lf[79]=C_h_intern(&lf[79],23,"hash-table-has-initial\077");
lf[80]=C_h_intern(&lf[80],18,"hash-table-initial");
lf[81]=C_h_intern(&lf[81],24,"\007srfi-69%hash-table-copy");
lf[82]=C_h_intern(&lf[82],15,"hash-table-copy");
lf[83]=C_h_intern(&lf[83],25,"\007srfi-69hash-table-rehash");
lf[84]=C_h_intern(&lf[84],5,"floor");
lf[85]=C_h_intern(&lf[85],27,"\007srfi-69%hash-table-update!");
lf[86]=C_h_intern(&lf[86],18,"hash-table-update!");
lf[87]=C_h_intern(&lf[87],13,"\000access-error");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[89]=C_h_intern(&lf[89],8,"identity");
lf[90]=C_h_intern(&lf[90],26,"hash-table-update!/default");
lf[91]=C_h_intern(&lf[91],15,"hash-table-set!");
lf[92]=C_h_intern(&lf[92],23,"\007srfi-69%hash-table-ref");
lf[93]=C_h_intern(&lf[93],14,"hash-table-ref");
lf[94]=C_h_intern(&lf[94],22,"hash-table-ref/default");
lf[95]=C_h_intern(&lf[95],18,"hash-table-exists\077");
lf[96]=C_h_intern(&lf[96],18,"hash-table-delete!");
lf[97]=C_h_intern(&lf[97],18,"hash-table-remove!");
lf[98]=C_h_intern(&lf[98],17,"hash-table-clear!");
lf[99]=C_h_intern(&lf[99],12,"vector-fill!");
lf[100]=C_h_intern(&lf[100],26,"\007srfi-69%hash-table-merge!");
lf[101]=C_h_intern(&lf[101],17,"hash-table-merge!");
lf[102]=C_h_intern(&lf[102],16,"hash-table-merge");
lf[103]=C_h_intern(&lf[103],17,"hash-table->alist");
lf[104]=C_h_intern(&lf[104],17,"alist->hash-table");
lf[105]=C_h_intern(&lf[105],12,"\003sysfor-each");
lf[106]=C_h_intern(&lf[106],15,"hash-table-keys");
lf[107]=C_h_intern(&lf[107],17,"hash-table-values");
lf[108]=C_h_intern(&lf[108],28,"\007srfi-69%hash-table-for-each");
lf[109]=C_h_intern(&lf[109],24,"\007srfi-69%hash-table-fold");
lf[110]=C_h_intern(&lf[110],15,"hash-table-fold");
lf[111]=C_h_intern(&lf[111],19,"hash-table-for-each");
lf[112]=C_h_intern(&lf[112],15,"hash-table-walk");
lf[113]=C_h_intern(&lf[113],14,"hash-table-map");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[115]=C_h_intern(&lf[115],18,"getter-with-setter");
lf[116]=C_h_intern(&lf[116],17,"register-feature!");
lf[117]=C_h_intern(&lf[117],7,"srfi-69");
C_register_lf2(lf,118,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=*((C_word*)lf[2]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_611,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 76   register-feature! */
t5=*((C_word*)lf[116]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[117]);}

/* k609 */
static void C_ccall f_611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[90],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_611,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_613,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_619,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_625,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[12]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_691,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_697,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[14]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_738,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_783,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_809,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_854,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_915,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[23]+1,*((C_word*)lf[22]+1));
t13=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_957,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1037,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1078,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[27]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1350,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[28]+1,*((C_word*)lf[27]+1));
t18=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1392,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1433,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[30],lf[31]);
t21=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1475,tmp=(C_word)a,a+=2,tmp));
t22=*((C_word*)lf[33]+1);
t23=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1505,a[2]=t22,tmp=(C_word)a,a+=3,tmp));
t24=*((C_word*)lf[36]+1);
t25=*((C_word*)lf[37]+1);
t26=*((C_word*)lf[38]+1);
t27=*((C_word*)lf[39]+1);
t28=*((C_word*)lf[40]+1);
t29=*((C_word*)lf[41]+1);
t30=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1529,a[2]=t29,a[3]=t28,a[4]=t27,a[5]=t26,a[6]=t25,a[7]=t24,tmp=(C_word)a,a+=8,tmp));
t31=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1892,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1898,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1907,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1916,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1925,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1934,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1943,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1952,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1961,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1973,tmp=(C_word)a,a+=2,tmp));
t41=*((C_word*)lf[33]+1);
t42=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1988,a[2]=t41,tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2100,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2109,tmp=(C_word)a,a+=2,tmp));
t45=*((C_word*)lf[36]+1);
t46=*((C_word*)lf[84]+1);
t47=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2188,a[2]=t46,a[3]=t45,tmp=(C_word)a,a+=4,tmp));
t48=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2424,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2502,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2517,tmp=(C_word)a,a+=2,tmp));
t51=*((C_word*)lf[36]+1);
t52=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2531,a[2]=t51,tmp=(C_word)a,a+=3,tmp));
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3419,tmp=(C_word)a,a+=2,tmp);
/* srfi-69.scm: 773  getter-with-setter */
t55=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t55+1)))(4,t55,t53,t54,*((C_word*)lf[91]+1));}

/* a3418 in k609 */
static void C_ccall f_3419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3419r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3419r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3419r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(10);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3436,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_structure_2(t2,lf[35],lf[93]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3429,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 779  ##sys#check-closure */
t9=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t6,lf[93]);}

/* k3427 in a3418 in k609 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 780  %hash-table-ref */
t2=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_3436 in a3418 in k609 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3436,2,t0,t1);}
/* srfi-69.scm: 775  ##sys#signal-hook */
t2=*((C_word*)lf[9]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[87],lf[93],lf[114],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2640 in k609 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[38],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1,t1);
t3=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2644,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2656,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[36]+1);
t6=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2677,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2808,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2904,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2920,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2987,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2999,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3015,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[42]+1);
t14=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3088,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3116,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[107]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3181,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3246,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3295,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3361,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3373,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3385,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[113]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3397,tmp=(C_word)a,a+=2,tmp));
t23=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_UNDEFINED);}

/* hash-table-map in k2640 in k609 */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3397,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[35],lf[113]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3404,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 992  ##sys#check-closure */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[113]);}

/* k3402 in hash-table-map in k2640 in k609 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 993  %hash-table-fold */
t3=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* a3408 in k3402 in hash-table-map in k2640 in k609 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3409,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3417,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 993  func */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k3415 in a3408 in k3402 in hash-table-map in k2640 in k609 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3417,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* hash-table-walk in k2640 in k609 */
static void C_ccall f_3385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3385,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[35],lf[112]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3392,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 987  ##sys#check-closure */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[112]);}

/* k3390 in hash-table-walk in k2640 in k609 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 988  %hash-table-for-each */
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-for-each in k2640 in k609 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3373,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[35],lf[111]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3380,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 982  ##sys#check-closure */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[111]);}

/* k3378 in hash-table-for-each in k2640 in k609 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 983  %hash-table-for-each */
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-fold in k2640 in k609 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3361,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[35],lf[110]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3368,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 977  ##sys#check-closure */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[110]);}

/* k3366 in hash-table-fold in k2640 in k609 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 978  %hash-table-fold */
t2=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##srfi-69#%hash-table-fold in k2640 in k609 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3295,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3307,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3307(t10,t1,C_fix(0),t4);}

/* loop in ##srfi-69#%hash-table-fold in k2640 in k609 */
static void C_fcall f_3307(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3307,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3323,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3323(t8,t1,t4,t3);}}

/* fold2 in loop in ##srfi-69#%hash-table-fold in k2640 in k609 */
static void C_fcall f_3323(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3323,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 970  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3307(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3351,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 973  func */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t6,t7,t8,t3);}}

/* k3349 in fold2 in loop in ##srfi-69#%hash-table-fold in k2640 in k609 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 972  fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3323(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##srfi-69#%hash-table-for-each in k2640 in k609 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3246,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3258,a[2]=t4,a[3]=t3,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_3258(t9,t1,C_fix(0));}

/* do500 in ##srfi-69#%hash-table-for-each in k2640 in k609 */
static void C_fcall f_3258(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3258,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3268,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* srfi-69.scm: 957  ##sys#for-each */
t6=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3276 in do500 in ##srfi-69#%hash-table-for-each in k2640 in k609 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3277,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 958  proc */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3266 in do500 in ##srfi-69#%hash-table-for-each in k2640 in k609 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3258(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k2640 in k609 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3181,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[107]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3196,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3196(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k2640 in k609 */
static void C_fcall f_3196(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3196,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3212,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3212(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k2640 in k609 */
static void C_fcall f_3212(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3212,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 940  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3196(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 941  loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k2640 in k609 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3116,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[106]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3131,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3131(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k2640 in k609 */
static void C_fcall f_3131(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3131,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3147,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3147(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k2640 in k609 */
static void C_fcall f_3147(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3147,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 925  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3131(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 926  loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k2640 in k609 */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3088r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3088r(t0,t1,t2,t3);}}

static void C_ccall f_3088r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_list_2(t2,lf[104]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3095,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,((C_word*)t0)[2],t3);}

/* k3093 in alist->hash-table in k2640 in k609 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3098,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3100,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3099 in k3093 in alist->hash-table in k2640 in k609 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3100,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3110,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 908  %hash-table-update! */
t5=*((C_word*)lf[85]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,((C_word*)t0)[2],t3,*((C_word*)lf[89]+1),t4);}

/* a3109 in a3099 in k3093 in alist->hash-table in k2640 in k609 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3110,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k3096 in k3093 in alist->hash-table in k2640 in k609 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k2640 in k609 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3015,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[103]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3030,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3030(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k2640 in k609 */
static void C_fcall f_3030(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3030,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3046,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3046(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k2640 in k609 */
static void C_fcall f_3046(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3046,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 897  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3030(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm: 898  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge in k2640 in k609 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2999,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[35],lf[102]);
t5=(C_word)C_i_check_structure_2(t3,lf[35],lf[102]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3013,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 883  %hash-table-copy */
t7=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k3011 in hash-table-merge in k2640 in k609 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 883  %hash-table-merge! */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* hash-table-merge! in k2640 in k609 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2987,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[35],lf[101]);
t5=(C_word)C_i_check_structure_2(t3,lf[35],lf[101]);
/* srfi-69.scm: 878  %hash-table-merge! */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}

/* ##srfi-69#%hash-table-merge! in k2640 in k609 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2920,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2932,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2932(t9,t1,C_fix(0));}

/* do431 in ##srfi-69#%hash-table-merge! in k2640 in k609 */
static void C_fcall f_2932(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2932,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2942,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2955,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2955(t8,t3,t4);}}

/* do434 in do431 in ##srfi-69#%hash-table-merge! in k2640 in k609 */
static void C_fcall f_2955(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2955,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2968,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2981,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 872  %hash-table-update! */
t7=*((C_word*)lf[85]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,((C_word*)t0)[2],t5,*((C_word*)lf[89]+1),t6);}}

/* a2980 in do434 in do431 in ##srfi-69#%hash-table-merge! in k2640 in k609 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2981,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k2966 in do434 in do431 in ##srfi-69#%hash-table-merge! in k2640 in k609 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2955(t3,((C_word*)t0)[2],t2);}

/* k2940 in do431 in ##srfi-69#%hash-table-merge! in k2640 in k609 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2932(t3,((C_word*)t0)[2],t2);}

/* hash-table-clear! in k2640 in k609 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2904,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[98]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2911,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 859  vector-fill! */
t6=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k2909 in hash-table-clear! in k2640 in k609 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_fix(0)));}

/* hash-table-remove! in k2640 in k609 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2808,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[35],lf[97]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2815,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 836  ##sys#check-closure */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[97]);}

/* k2813 in hash-table-remove! in k2640 in k609 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2829,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_2829(t10,((C_word*)t0)[2],C_fix(0));}

/* do409 in k2813 in hash-table-remove! in k2640 in k609 */
static void C_fcall f_2829(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2829,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2842,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2855,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2855(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in do409 in k2813 in hash-table-remove! in k2640 in k609 */
static void C_fcall f_2855(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2855,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2874,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 846  func */
t9=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}}

/* k2872 in loop in do409 in k2813 in hash-table-remove! in k2640 in k609 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_setslot(((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8]):(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]));
t3=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 853  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2855(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k2840 in do409 in k2813 in hash-table-remove! in k2640 in k609 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2829(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k2640 in k609 */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2677,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[35],lf[96]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2693,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 800  hash */
t9=t7;
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,t6);}

/* k2691 in hash-table-delete! in k2640 in k609 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2693,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[5],t1);
t6=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2713,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_2713(t7,C_SCHEME_FALSE,t5));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_2760(t10,((C_word*)t0)[2],C_SCHEME_FALSE,t5);}}

/* loop in k2691 in hash-table-delete! in k2640 in k609 */
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2760,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2779,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
/* srfi-69.scm: 823  test */
t8=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k2777 in loop in k2691 in hash-table-delete! in k2640 in k609 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_i_setslot(((C_word*)t0)[10],C_fix(1),((C_word*)t0)[9]):(C_word)C_i_setslot(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]));
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 830  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2760(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* loop in k2691 in hash-table-delete! in k2640 in k609 */
static C_word C_fcall f_2713(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[6],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?(C_word)C_i_setslot(t1,C_fix(1),t4):(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t4));
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* hash-table-exists? in k2640 in k609 */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2656,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[35],lf[95]);
t5=(C_word)C_slot(lf[4],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2675,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 789  %hash-table-ref */
t7=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t3,*((C_word*)lf[3]+1));}

/* k2673 in hash-table-exists? in k2640 in k609 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}

/* hash-table-ref/default in k2640 in k609 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2644,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[35],lf[94]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2653,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 785  %hash-table-ref */
t7=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,t3,t6);}

/* a2652 in hash-table-ref/default in k2640 in k609 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2653,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##srfi-69#%hash-table-ref in k609 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2531,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(3));
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2544,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_block_size(t5);
/* srfi-69.scm: 753  hash */
t10=t7;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t3,t9);}

/* k2542 in ##srfi-69#%hash-table-ref in k609 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2544,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2559,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2559(t7,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2601(t7,((C_word*)t0)[2],t3);}}

/* loop in k2542 in ##srfi-69#%hash-table-ref in k609 */
static void C_fcall f_2601(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2601,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 766  def */
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2620,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 768  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k2618 in loop in k2542 in ##srfi-69#%hash-table-ref in k609 */
static void C_ccall f_2620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 770  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2601(t3,((C_word*)t0)[5],t2);}}

/* loop in k2542 in ##srfi-69#%hash-table-ref in k609 */
static void C_fcall f_2559(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2559,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 758  def */
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 762  loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* hash-table-set! in k609 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2517,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[35],lf[91]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2522,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2526,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 742  %hash-table-update! */
t8=*((C_word*)lf[85]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t7,t2,t3,t6,t6);}

/* k2524 in hash-table-set! in k609 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[2]+1));}

/* thunk in hash-table-set! in k609 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2522,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table-update!/default in k609 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2502,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_structure_2(t2,lf[35],lf[90]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2509,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 736  ##sys#check-closure */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,lf[90]);}

/* k2507 in hash-table-update!/default in k609 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 737  %hash-table-update! */
t3=*((C_word*)lf[85]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a2513 in k2507 in hash-table-update!/default in k609 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table-update! in k609 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_2424r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2424r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2424r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(12);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2426,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2440,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2457,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-func313327 */
t8=t7;
f_2457(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-thunk314322 */
t10=t6;
f_2440(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body311316 */
t12=t5;
f_2426(t12,t1,t8,t10);}}}

/* def-func313 in hash-table-update! in k609 */
static void C_fcall f_2457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2457,NULL,2,t0,t1);}
/* def-thunk314322 */
t2=((C_word*)t0)[2];
f_2440(t2,t1,*((C_word*)lf[89]+1));}

/* def-thunk314 in hash-table-update! in k609 */
static void C_fcall f_2440(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2440,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(9));
t4=(C_truep(t3)?t3:(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
/* body311316 */
t5=((C_word*)t0)[2];
f_2426(t5,t1,t2,t4);}

/* f_2452 in def-thunk314 in hash-table-update! in k609 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
/* srfi-69.scm: 726  ##sys#signal-hook */
t2=*((C_word*)lf[9]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[87],lf[86],lf[88],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* body311 in hash-table-update! in k609 */
static void C_fcall f_2426(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2426,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[3],lf[35],lf[86]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2433,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 730  ##sys#check-closure */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[86]);}

/* k2431 in body311 in hash-table-update! in k609 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 731  ##sys#check-closure */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[86]);}

/* k2434 in k2431 in body311 in hash-table-update! in k609 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 732  %hash-table-update! */
t2=*((C_word*)lf[85]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2188,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_slot(t2,C_fix(4));
t7=(C_word)C_slot(t2,C_fix(3));
t8=(C_word)C_slot(t2,C_fix(2));
t9=(C_word)C_u_fixnum_plus(t8,C_fix(1));
t10=(C_word)C_slot(t2,C_fix(5));
t11=(C_word)C_slot(t2,C_fix(6));
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2209,a[2]=t10,a[3]=((C_word*)t0)[2],a[4]=t11,a[5]=t5,a[6]=t4,a[7]=t9,a[8]=t3,a[9]=t7,a[10]=((C_word*)t0)[3],a[11]=t6,a[12]=t13,a[13]=t2,tmp=(C_word)a,a+=14,tmp));
t15=((C_word*)t13)[1];
f_2209(t15,t1);}

/* re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_fcall f_2209(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2209,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_a_i_times(&a,2,t3,((C_word*)t0)[2]);
/* srfi-69.scm: 671  floor */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2414,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2406,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[10],((C_word*)t0)[3]);
/* srfi-69.scm: 672  floor */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2406,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2225,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* srfi-69.scm: 673  hash */
t4=((C_word*)t0)[10];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[9]);}

/* k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[10],C_fix(1073741823)))){
t3=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[6]);
t4=t2;
f_2231(t4,(C_truep(t3)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[6],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_2231(t3,C_SCHEME_FALSE);}}

/* k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_fcall f_2231(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[37],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2231,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2247,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fixnum_times(((C_word*)t0)[9],C_fix(2));
t5=(C_word)C_i_fixnum_min(C_fix(1073741823),t4);
/* srfi-69.scm: 679  hash-table-canonical-length */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[30],t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],((C_word*)t0)[8]);
t3=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2269,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_2269(t7,((C_word*)t0)[12],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2332,a[2]=((C_word*)t0)[6],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=((C_word*)t0)[5],tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_2332(t7,((C_word*)t0)[12],t2);}}}

/* loop in k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_fcall f_2332(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2332,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2342,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2360,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 707  thunk */
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2369,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 713  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k2367 in loop in k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2369,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2372,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 714  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 717  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2332(t3,((C_word*)t0)[5],t2);}}

/* k2370 in k2367 in loop in k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k2358 in loop in k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 707  func */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2340 in loop in k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2342,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_fcall f_2269(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2269,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2279,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2297,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 693  thunk */
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2309,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 700  func */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 703  loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}}

/* k2307 in loop in k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k2295 in loop in k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 693  func */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2277 in loop in k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2279,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k2245 in k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 678  make-vector */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2232 in k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 684  hash-table-rehash */
t3=*((C_word*)lf[83]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2235 in k2232 in k2229 in k2223 in k2404 in k2412 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]);
/* srfi-69.scm: 686  re-enter */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2209(t3,((C_word*)t0)[2]);}

/* ##srfi-69#hash-table-rehash in k609 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2109,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_block_size(t2);
t6=(C_word)C_block_size(t3);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2121,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t8,a[7]=t5,tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_2121(t10,t1,C_fix(0));}

/* do253 in ##srfi-69#hash-table-rehash in k609 */
static void C_fcall f_2121(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2121,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2131,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2144(t8,t3,t4);}}

/* loop in do253 in ##srfi-69#hash-table-rehash in k609 */
static void C_fcall f_2144(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2144,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2160,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 653  hash */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k2158 in loop in do253 in ##srfi-69#hash-table-rehash in k609 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2160,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 657  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_2144(t8,((C_word*)t0)[2],t7);}

/* k2129 in do253 in ##srfi-69#hash-table-rehash in k609 */
static void C_ccall f_2131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2121(t3,((C_word*)t0)[2],t2);}

/* hash-table-copy in k609 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2100,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[82]);
/* srfi-69.scm: 637  %hash-table-copy */
t4=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* ##srfi-69#%hash-table-copy in k609 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1988,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1998,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 617  make-vector */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k1996 in ##srfi-69#%hash-table-copy in k609 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1998,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2003(t5,((C_word*)t0)[2],C_fix(0));}

/* do237 in k1996 in ##srfi-69#%hash-table-copy in k609 */
static void C_fcall f_2003(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2003,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(6));
t8=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t9=(C_word)C_slot(((C_word*)t0)[5],C_fix(8));
t10=(C_word)C_slot(((C_word*)t0)[5],C_fix(9));
/* srfi-69.scm: 620  %make-hash-table */
t11=*((C_word*)lf[34]+1);
((C_proc11)(void*)(*((C_word*)t11+1)))(11,t11,t1,t3,t4,t5,t6,t7,t8,t9,t10,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2059,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2065,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_2065(t8,t3,t4);}}

/* copy-loop in do237 in k1996 in ##srfi-69#%hash-table-copy in k609 */
static void C_fcall f_2065(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2065,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2086,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 633  copy-loop */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k2084 in copy-loop in do237 in k1996 in ##srfi-69#%hash-table-copy in k609 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2086,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2057 in do237 in k1996 in ##srfi-69#%hash-table-copy in k609 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2003(t4,((C_word*)t0)[2],t3);}

/* hash-table-initial in k609 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1973,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[80]);
t4=(C_word)C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm: 608  thunk */
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* hash-table-has-initial? in k609 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1961,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[79]);
t4=(C_word)C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* hash-table-weak-values in k609 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1952,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[78]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(8)));}

/* hash-table-weak-keys in k609 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1943,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[77]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(7)));}

/* hash-table-max-load in k609 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1934,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[76]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* hash-table-min-load in k609 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1925,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(5)));}

/* hash-table-hash-function in k609 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1916,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[74]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k609 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1907,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[73]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-size in k609 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1898,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[35],lf[72]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(2)));}

/* hash-table? in k609 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1892,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[35]));}

/* make-hash-table in k609 */
static void C_ccall f_1529(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+47)){
C_save_and_reclaim((void*)tr2r,(void*)f_1529r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1529r(t0,t1,t2);}}

static void C_ccall f_1529r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a=C_alloc(47);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[38]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[43];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[44];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_FALSE;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t22=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1607,a[2]=t4,a[3]=t2,a[4]=t21,a[5]=t12,a[6]=t20,a[7]=t18,a[8]=t16,a[9]=t14,a[10]=t8,a[11]=t6,a[12]=t1,a[13]=t10,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t4)[1]))){
t23=t22;
f_1607(t23,C_SCHEME_UNDEFINED);}
else{
t23=(C_word)C_u_i_car(((C_word*)t4)[1]);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1882,a[2]=t4,a[3]=t23,a[4]=t6,a[5]=t22,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 487  keyword? */
t25=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t25+1)))(3,t25,t24,t23);}}

/* k1880 in make-hash-table in k609 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_1607(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 488  ##sys#check-closure */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[42]);}}

/* k1883 in k1880 in make-hash-table in k609 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1607(t5,t4);}

/* k1605 in make-hash-table in k609 */
static void C_fcall f_1607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1607,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_1610(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 493  keyword? */
t5=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k1860 in k1605 in make-hash-table in k609 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1862,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_1610(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1865,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 494  ##sys#check-closure */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[42]);}}

/* k1863 in k1860 in k1605 in make-hash-table in k609 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1610(t5,t4);}

/* k1608 in k1605 in make-hash-table in k609 */
static void C_fcall f_1610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1610,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_1613(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[13],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 499  keyword? */
t5=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k1828 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1830,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_1613(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[42]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1836,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)t0)[4]))){
t4=t3;
f_1836(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 502  error */
t4=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[42],lf[70],((C_word*)t0)[4]);}}}

/* k1834 in k1828 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[53]+1),((C_word*)t0)[5]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1613(t6,t5);}

/* k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_fcall f_1613(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1613,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t4,a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp));
t6=((C_word*)t4)[1];
f_1648(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_fcall f_1648(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1648,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[11],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1669,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[10],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
/* srfi-69.scm: 512  keyword? */
t6=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* k1667 in loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1669,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=t3;
f_1675(2,t4,(C_word)C_u_i_car(t2));}
else{
/* srfi-69.scm: 516  invarg-err */
t4=((C_word*)t0)[2];
f_1659(t4,t3,lf[68]);}}
else{
/* srfi-69.scm: 548  invarg-err */
t2=((C_word*)t0)[2];
f_1659(t2,((C_word*)t0)[12],lf[69]);}}

/* k1673 in k1667 in loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1678,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[49]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1691,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 519  ##sys#check-closure */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,lf[42]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[51]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1701,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 522  ##sys#check-closure */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t1,lf[42]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[52]);
if(C_truep(t5)){
t6=(C_word)C_i_check_exact_2(t1,lf[42]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1714,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),t1))){
t8=t7;
f_1714(2,t8,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 527  error */
t8=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[42],lf[54],t1);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[55]);
if(C_truep(t6)){
t7=C_mutate(((C_word *)((C_word*)t0)[7])+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1732,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t8=t2;
f_1678(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[56]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1742,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 532  ##sys#check-inexact */
t9=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t1,lf[42]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[61]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1767,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 537  ##sys#check-inexact */
t10=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t1,lf[42]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[65]);
if(C_truep(t9)){
t10=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t2;
f_1678(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[66]);
if(C_truep(t10)){
t11=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t12=C_mutate(((C_word *)((C_word*)t0)[3])+1,t11);
t13=t2;
f_1678(2,t13,t12);}
else{
/* srfi-69.scm: 546  invarg-err */
t11=((C_word*)t0)[2];
f_1659(t11,t2,lf[67]);}}}}}}}}}

/* k1765 in k1673 in k1667 in loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[62],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[63]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_1770(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 539  error */
t5=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[42],lf[64],((C_word*)t0)[3]);}}

/* k1768 in k1765 in k1673 in k1667 in loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1678(2,t3,t2);}

/* k1740 in k1673 in k1667 in loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[57],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[58]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_1745(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 534  error */
t5=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[42],lf[59],((C_word*)t0)[3]);}}

/* k1743 in k1740 in k1673 in k1667 in loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1678(2,t3,t2);}

/* f_1732 in k1673 in k1667 in loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1712 in k1673 in k1667 in loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[53]+1),((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1678(2,t4,t3);}

/* k1699 in k1673 in k1667 in loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1678(2,t3,t2);}

/* k1689 in k1673 in k1667 in loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1678(2,t3,t2);}

/* k1676 in k1673 in k1667 in loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 547  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1648(t3,((C_word*)t0)[2],t2);}

/* invarg-err in loop in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_fcall f_1659(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1659,NULL,3,t0,t1,t2);}
/* srfi-69.scm: 511  error */
t3=*((C_word*)lf[47]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[42],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1614 in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_flonum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]))){
/* srfi-69.scm: 551  error */
t3=*((C_word*)lf[47]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[42],lf[48],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]);}
else{
t3=t2;
f_1619(2,t3,C_SCHEME_UNDEFINED);}}

/* k1617 in k1614 in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* srfi-69.scm: 553  hash-table-canonical-length */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[30],((C_word*)((C_word*)t0)[11])[1]);}

/* k1621 in k1617 in k1614 in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1623,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t4=t3;
f_1626(t4,C_SCHEME_UNDEFINED);}
else{
t4=f_1531(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_mutate(((C_word *)((C_word*)t0)[8])+1,t4);
t6=t3;
f_1626(t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1639,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 560  warning */
t6=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,lf[42],lf[46]);}}}

/* k1637 in k1621 in k1617 in k1614 in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[27]+1));
t3=((C_word*)t0)[2];
f_1626(t3,t2);}

/* k1624 in k1621 in k1617 in k1614 in k1611 in k1608 in k1605 in make-hash-table in k609 */
static void C_fcall f_1626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 563  %make-hash-table */
t2=*((C_word*)lf[34]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* hash-for-test in make-hash-table in k609 */
static C_word C_fcall f_1531(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t1=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t2=(C_truep(t1)?t1:(C_word)C_eqp(*((C_word*)lf[36]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t2)){
return(*((C_word*)lf[22]+1));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(*((C_word*)lf[37]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t4)){
return(*((C_word*)lf[25]+1));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(*((C_word*)lf[38]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t6)){
return(*((C_word*)lf[27]+1));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(*((C_word*)lf[39]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t8)){
return(*((C_word*)lf[15]+1));}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)((C_word*)t0)[7])[1]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(*((C_word*)lf[40]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t10)){
return(*((C_word*)lf[29]+1));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(*((C_word*)lf[41]+1),((C_word*)((C_word*)t0)[7])[1]));
return((C_truep(t12)?*((C_word*)lf[7]+1):C_SCHEME_FALSE));}}}}}}

/* %make-hash-table in k609 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,...){
C_word tmp;
C_word t10;
va_list v;
C_word *a,c2=c;
C_save_rest(t9,c2,10);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr10rv,(void*)f_1505r,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
else{
a=C_alloc((c-10)*3);
t10=C_restore_rest_vector(a,C_rest_count(0));
f_1505r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}}

static void C_ccall f_1505r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1509,a[2]=t9,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_vemptyp(t10))){
/* srfi-69.scm: 435  make-vector */
t12=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,t4,C_SCHEME_END_OF_LIST);}
else{
t12=t11;
f_1509(2,t12,(C_word)C_slot(t10,C_fix(0)));}}

/* k1507 in %make-hash-table in k609 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1509,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,10,lf[35],t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* ##srfi-69#hash-table-canonical-length in k609 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1475,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1481,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1481(t4,t2));}

/* loop in ##srfi-69#hash-table-canonical-length in k609 */
static C_word C_fcall f_1481(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
return(t2);}
else{
t7=t3;
t1=t7;
goto loop;}}

/* string-ci-hash in k609 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1433r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1433r(t0,t1,t2,t3);}}

static void C_ccall f_1433r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[29]);
t7=(C_word)C_i_check_exact_2(t5,lf[29]);
t8=(C_word)C_hash_string_ci(t2);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?(C_word)C_u_fixnum_negate(t8):t8);
t11=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_fixnum_modulo(t11,t5));}

/* string-hash in k609 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1392r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1392r(t0,t1,t2,t3);}}

static void C_ccall f_1392r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[15]);
t7=(C_word)C_i_check_exact_2(t5,lf[15]);
t8=(C_word)C_hash_string(t2);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?(C_word)C_u_fixnum_negate(t8):t8);
t11=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_fixnum_modulo(t11,t5));}

/* equal?-hash in k609 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1350r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1350r(t0,t1,t2,t3);}}

static void C_ccall f_1350r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[28]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1368,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 375  %equal?-hash */
t8=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k1366 in equal?-hash in k609 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1078,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1081,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1146,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1177,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
/* srfi-69.scm: 371  recursive-hash */
t12=((C_word*)t8)[1];
f_1177(t12,t1,t2,C_fix(0));}

/* recursive-hash in ##srfi-69#%equal?-hash in k609 */
static void C_fcall f_1177(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1177,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(99));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_hash_string(t4));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_flonump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_times(C_fix(331804471),(C_word)C_quickflonumtruncate(t2)));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1252,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 361  ##sys#number-hash-hook */
t5=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hash_string(t2));}
else{
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1278,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* srfi-69.scm: 364  recursive-atomic-hash */
t7=((C_word*)((C_word*)t0)[3])[1];
f_1146(t7,t5,t6,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1307,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* srfi-69.scm: 365  recursive-atomic-hash */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1146(t6,t4,t5,t3);}
else{
if(C_truep((C_word)C_portp(t2))){
t4=(C_word)C_peek_fixnum(t2,C_fix(0));
t5=(C_word)C_fixnum_shift_left(t4,C_fix(4));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1328,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 366  input-port? */
t7=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_specialp(t2))){
t4=(C_word)C_peek_fixnum(t2,C_fix(0));
/* srfi-69.scm: 367  vector-hash */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1081(t5,t1,t2,t4,t3,C_fix(1));}
else{
/* srfi-69.scm: 368  vector-hash */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1081(t4,t1,t2,C_fix(0),t3,C_fix(0));}}}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(262));}}}}}}}}}}

/* k1326 in recursive-hash in ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?C_fix(260):C_fix(261));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2));}

/* k1305 in recursive-hash in ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
t2=(C_word)C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1299,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 365  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1146(t5,t3,t4,((C_word*)t0)[2]);}

/* k1297 in k1305 in recursive-hash in ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k1276 in recursive-hash in ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k1250 in recursive-hash in ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fix(t1));}

/* recursive-atomic-hash in ##srfi-69#%equal?-hash in k609 */
static void C_fcall f_1146(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1146,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(t2));
t6=(C_truep(t5)?t5:(C_word)C_i_numberp(t2));
t7=(C_truep(t6)?t6:(C_word)C_byteblockp(t2));
if(C_truep(t7)){
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* srfi-69.scm: 345  recursive-hash */
t9=((C_word*)((C_word*)t0)[2])[1];
f_1177(t9,t1,t2,t8);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(99));}}

/* vector-hash in ##srfi-69#%equal?-hash in k609 */
static void C_fcall f_1081(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1081,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(t6,t3);
t8=(C_word)C_i_fixnum_min(C_fix(4),t6);
t9=(C_word)C_u_fixnum_difference(t8,t5);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1098,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_1098(t13,t1,t7,t5,t9);}

/* loop in vector-hash in ##srfi-69#%equal?-hash in k609 */
static void C_fcall f_1098(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1098,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_fixnum_shift_left(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1132,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 337  recursive-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_1177(t10,t7,t8,t9);}}

/* k1130 in loop in vector-hash in ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 335  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1098(t6,((C_word*)t0)[2],t3,t4,t5);}

/* eqv?-hash in k609 */
static void C_ccall f_1037(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1037r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1037r(t0,t1,t2,t3);}}

static void C_ccall f_1037r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[25]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1055,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 297  %eqv?-hash */
t8=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k1053 in eqv?-hash in k609 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##srfi-69#%eqv?-hash in k609 */
static void C_ccall f_957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_957,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(256));
case C_SCHEME_FALSE:
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hash_string(t3));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_flonump(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_times(C_fix(331804471),(C_word)C_quickflonumtruncate(t2)));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1026,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 291  ##sys#number-hash-hook */
t4=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}
else{
if(C_truep((C_word)C_blockp(t2))){
/* srfi-69.scm: 293  %object-uid-hash */
t3=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(262));}}}}}}}}}

/* k1024 in ##srfi-69#%eqv?-hash in k609 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fix(t1));}

/* eq?-hash in k609 */
static void C_ccall f_915(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_915r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_915r(t0,t1,t2,t3);}}

static void C_ccall f_915r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[22]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_933,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 271  %eq?-hash */
t8=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k931 in eq?-hash in k609 */
static void C_ccall f_933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##srfi-69#%eq?-hash in k609 */
static void C_ccall f_854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_854,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(256));
case C_SCHEME_FALSE:
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hash_string(t3));}
else{
if(C_truep((C_word)C_blockp(t2))){
/* srfi-69.scm: 267  %object-uid-hash */
t3=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(262));}}}}}}}}

/* keyword-hash in k609 */
static void C_ccall f_809(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_809r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_809r(t0,t1,t2,t3);}}

static void C_ccall f_809r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_816,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 244  ##sys#check-keyword */
t7=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,lf[20]);}

/* k814 in keyword-hash in k609 */
static void C_ccall f_816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[20]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_hash_string(t3);
t5=(C_word)C_fixnum_lessp(t4,C_fix(0));
t6=(C_truep(t5)?(C_word)C_u_fixnum_negate(t4):t4);
t7=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_modulo(t7,((C_word*)t0)[4]));}

/* ##sys#check-keyword in k609 */
static void C_ccall f_783(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_783r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_783r(t0,t1,t2,t3);}}

static void C_ccall f_783r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_790,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 231  keyword? */
t5=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k788 in ##sys#check-keyword in k609 */
static void C_ccall f_790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_slot(((C_word*)t0)[3],C_fix(0)));
/* srfi-69.scm: 232  ##sys#signal-hook */
t4=*((C_word*)lf[9]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[17],t3,lf[18],((C_word*)t0)[2]);}}

/* symbol-hash in k609 */
static void C_ccall f_738(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_738r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_738r(t0,t1,t2,t3);}}

static void C_ccall f_738r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_symbol_2(t2,lf[14]);
t7=(C_word)C_i_check_exact_2(t5,lf[15]);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_hash_string(t8);
t10=(C_word)C_fixnum_lessp(t9,C_fix(0));
t11=(C_truep(t10)?(C_word)C_u_fixnum_negate(t9):t9);
t12=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_fixnum_modulo(t12,t5));}

/* object-uid-hash in k609 */
static void C_ccall f_697(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_697r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_697r(t0,t1,t2,t3);}}

static void C_ccall f_697r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[13]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_715,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 212  %object-uid-hash */
t8=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k713 in object-uid-hash in k609 */
static void C_ccall f_715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##srfi-69#%object-uid-hash in k609 */
static void C_ccall f_691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_691,3,t0,t1,t2);}
/* srfi-69.scm: 208  %equal?-hash */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* number-hash in k609 */
static void C_ccall f_625(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_625r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_625r(t0,t1,t2,t3);}}

static void C_ccall f_625r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_632,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t7=t6;
f_632(2,t7,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 197  ##sys#signal-hook */
t7=*((C_word*)lf[9]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[10],lf[7],lf[11],t2);}}

/* k630 in number-hash in k609 */
static void C_ccall f_632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_632,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_646,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t4=t3;
f_646(t4,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_flonump(((C_word*)t0)[2]))){
t4=t3;
f_646(t4,(C_word)C_fixnum_times(C_fix(331804471),(C_word)C_quickflonumtruncate(*((C_word*)lf[8]+1))));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_671,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 199  ##sys#number-hash-hook */
t5=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,*((C_word*)lf[8]+1));}}}

/* k669 in k630 in number-hash in k609 */
static void C_ccall f_671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_646(t2,(C_word)C_fix(t1));}

/* k644 in k630 in number-hash in k609 */
static void C_fcall f_646(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##sys#number-hash-hook in k609 */
static void C_ccall f_619(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_619,3,t0,t1,t2);}
/* srfi-69.scm: 185  %equal?-hash */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* ##srfi-69#unbound-value-thunk in k609 */
static void C_ccall f_613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_613,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(lf[4],C_fix(0)));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[192] = {
{"toplevelsrfi-69.scm",(void*)C_srfi_69_toplevel},
{"f_611srfi-69.scm",(void*)f_611},
{"f_3419srfi-69.scm",(void*)f_3419},
{"f_3429srfi-69.scm",(void*)f_3429},
{"f_3436srfi-69.scm",(void*)f_3436},
{"f_2642srfi-69.scm",(void*)f_2642},
{"f_3397srfi-69.scm",(void*)f_3397},
{"f_3404srfi-69.scm",(void*)f_3404},
{"f_3409srfi-69.scm",(void*)f_3409},
{"f_3417srfi-69.scm",(void*)f_3417},
{"f_3385srfi-69.scm",(void*)f_3385},
{"f_3392srfi-69.scm",(void*)f_3392},
{"f_3373srfi-69.scm",(void*)f_3373},
{"f_3380srfi-69.scm",(void*)f_3380},
{"f_3361srfi-69.scm",(void*)f_3361},
{"f_3368srfi-69.scm",(void*)f_3368},
{"f_3295srfi-69.scm",(void*)f_3295},
{"f_3307srfi-69.scm",(void*)f_3307},
{"f_3323srfi-69.scm",(void*)f_3323},
{"f_3351srfi-69.scm",(void*)f_3351},
{"f_3246srfi-69.scm",(void*)f_3246},
{"f_3258srfi-69.scm",(void*)f_3258},
{"f_3277srfi-69.scm",(void*)f_3277},
{"f_3268srfi-69.scm",(void*)f_3268},
{"f_3181srfi-69.scm",(void*)f_3181},
{"f_3196srfi-69.scm",(void*)f_3196},
{"f_3212srfi-69.scm",(void*)f_3212},
{"f_3116srfi-69.scm",(void*)f_3116},
{"f_3131srfi-69.scm",(void*)f_3131},
{"f_3147srfi-69.scm",(void*)f_3147},
{"f_3088srfi-69.scm",(void*)f_3088},
{"f_3095srfi-69.scm",(void*)f_3095},
{"f_3100srfi-69.scm",(void*)f_3100},
{"f_3110srfi-69.scm",(void*)f_3110},
{"f_3098srfi-69.scm",(void*)f_3098},
{"f_3015srfi-69.scm",(void*)f_3015},
{"f_3030srfi-69.scm",(void*)f_3030},
{"f_3046srfi-69.scm",(void*)f_3046},
{"f_2999srfi-69.scm",(void*)f_2999},
{"f_3013srfi-69.scm",(void*)f_3013},
{"f_2987srfi-69.scm",(void*)f_2987},
{"f_2920srfi-69.scm",(void*)f_2920},
{"f_2932srfi-69.scm",(void*)f_2932},
{"f_2955srfi-69.scm",(void*)f_2955},
{"f_2981srfi-69.scm",(void*)f_2981},
{"f_2968srfi-69.scm",(void*)f_2968},
{"f_2942srfi-69.scm",(void*)f_2942},
{"f_2904srfi-69.scm",(void*)f_2904},
{"f_2911srfi-69.scm",(void*)f_2911},
{"f_2808srfi-69.scm",(void*)f_2808},
{"f_2815srfi-69.scm",(void*)f_2815},
{"f_2829srfi-69.scm",(void*)f_2829},
{"f_2855srfi-69.scm",(void*)f_2855},
{"f_2874srfi-69.scm",(void*)f_2874},
{"f_2842srfi-69.scm",(void*)f_2842},
{"f_2677srfi-69.scm",(void*)f_2677},
{"f_2693srfi-69.scm",(void*)f_2693},
{"f_2760srfi-69.scm",(void*)f_2760},
{"f_2779srfi-69.scm",(void*)f_2779},
{"f_2713srfi-69.scm",(void*)f_2713},
{"f_2656srfi-69.scm",(void*)f_2656},
{"f_2675srfi-69.scm",(void*)f_2675},
{"f_2644srfi-69.scm",(void*)f_2644},
{"f_2653srfi-69.scm",(void*)f_2653},
{"f_2531srfi-69.scm",(void*)f_2531},
{"f_2544srfi-69.scm",(void*)f_2544},
{"f_2601srfi-69.scm",(void*)f_2601},
{"f_2620srfi-69.scm",(void*)f_2620},
{"f_2559srfi-69.scm",(void*)f_2559},
{"f_2517srfi-69.scm",(void*)f_2517},
{"f_2526srfi-69.scm",(void*)f_2526},
{"f_2522srfi-69.scm",(void*)f_2522},
{"f_2502srfi-69.scm",(void*)f_2502},
{"f_2509srfi-69.scm",(void*)f_2509},
{"f_2514srfi-69.scm",(void*)f_2514},
{"f_2424srfi-69.scm",(void*)f_2424},
{"f_2457srfi-69.scm",(void*)f_2457},
{"f_2440srfi-69.scm",(void*)f_2440},
{"f_2452srfi-69.scm",(void*)f_2452},
{"f_2426srfi-69.scm",(void*)f_2426},
{"f_2433srfi-69.scm",(void*)f_2433},
{"f_2436srfi-69.scm",(void*)f_2436},
{"f_2188srfi-69.scm",(void*)f_2188},
{"f_2209srfi-69.scm",(void*)f_2209},
{"f_2414srfi-69.scm",(void*)f_2414},
{"f_2406srfi-69.scm",(void*)f_2406},
{"f_2225srfi-69.scm",(void*)f_2225},
{"f_2231srfi-69.scm",(void*)f_2231},
{"f_2332srfi-69.scm",(void*)f_2332},
{"f_2369srfi-69.scm",(void*)f_2369},
{"f_2372srfi-69.scm",(void*)f_2372},
{"f_2360srfi-69.scm",(void*)f_2360},
{"f_2342srfi-69.scm",(void*)f_2342},
{"f_2269srfi-69.scm",(void*)f_2269},
{"f_2309srfi-69.scm",(void*)f_2309},
{"f_2297srfi-69.scm",(void*)f_2297},
{"f_2279srfi-69.scm",(void*)f_2279},
{"f_2247srfi-69.scm",(void*)f_2247},
{"f_2234srfi-69.scm",(void*)f_2234},
{"f_2237srfi-69.scm",(void*)f_2237},
{"f_2109srfi-69.scm",(void*)f_2109},
{"f_2121srfi-69.scm",(void*)f_2121},
{"f_2144srfi-69.scm",(void*)f_2144},
{"f_2160srfi-69.scm",(void*)f_2160},
{"f_2131srfi-69.scm",(void*)f_2131},
{"f_2100srfi-69.scm",(void*)f_2100},
{"f_1988srfi-69.scm",(void*)f_1988},
{"f_1998srfi-69.scm",(void*)f_1998},
{"f_2003srfi-69.scm",(void*)f_2003},
{"f_2065srfi-69.scm",(void*)f_2065},
{"f_2086srfi-69.scm",(void*)f_2086},
{"f_2059srfi-69.scm",(void*)f_2059},
{"f_1973srfi-69.scm",(void*)f_1973},
{"f_1961srfi-69.scm",(void*)f_1961},
{"f_1952srfi-69.scm",(void*)f_1952},
{"f_1943srfi-69.scm",(void*)f_1943},
{"f_1934srfi-69.scm",(void*)f_1934},
{"f_1925srfi-69.scm",(void*)f_1925},
{"f_1916srfi-69.scm",(void*)f_1916},
{"f_1907srfi-69.scm",(void*)f_1907},
{"f_1898srfi-69.scm",(void*)f_1898},
{"f_1892srfi-69.scm",(void*)f_1892},
{"f_1529srfi-69.scm",(void*)f_1529},
{"f_1882srfi-69.scm",(void*)f_1882},
{"f_1885srfi-69.scm",(void*)f_1885},
{"f_1607srfi-69.scm",(void*)f_1607},
{"f_1862srfi-69.scm",(void*)f_1862},
{"f_1865srfi-69.scm",(void*)f_1865},
{"f_1610srfi-69.scm",(void*)f_1610},
{"f_1830srfi-69.scm",(void*)f_1830},
{"f_1836srfi-69.scm",(void*)f_1836},
{"f_1613srfi-69.scm",(void*)f_1613},
{"f_1648srfi-69.scm",(void*)f_1648},
{"f_1669srfi-69.scm",(void*)f_1669},
{"f_1675srfi-69.scm",(void*)f_1675},
{"f_1767srfi-69.scm",(void*)f_1767},
{"f_1770srfi-69.scm",(void*)f_1770},
{"f_1742srfi-69.scm",(void*)f_1742},
{"f_1745srfi-69.scm",(void*)f_1745},
{"f_1732srfi-69.scm",(void*)f_1732},
{"f_1714srfi-69.scm",(void*)f_1714},
{"f_1701srfi-69.scm",(void*)f_1701},
{"f_1691srfi-69.scm",(void*)f_1691},
{"f_1678srfi-69.scm",(void*)f_1678},
{"f_1659srfi-69.scm",(void*)f_1659},
{"f_1616srfi-69.scm",(void*)f_1616},
{"f_1619srfi-69.scm",(void*)f_1619},
{"f_1623srfi-69.scm",(void*)f_1623},
{"f_1639srfi-69.scm",(void*)f_1639},
{"f_1626srfi-69.scm",(void*)f_1626},
{"f_1531srfi-69.scm",(void*)f_1531},
{"f_1505srfi-69.scm",(void*)f_1505},
{"f_1509srfi-69.scm",(void*)f_1509},
{"f_1475srfi-69.scm",(void*)f_1475},
{"f_1481srfi-69.scm",(void*)f_1481},
{"f_1433srfi-69.scm",(void*)f_1433},
{"f_1392srfi-69.scm",(void*)f_1392},
{"f_1350srfi-69.scm",(void*)f_1350},
{"f_1368srfi-69.scm",(void*)f_1368},
{"f_1078srfi-69.scm",(void*)f_1078},
{"f_1177srfi-69.scm",(void*)f_1177},
{"f_1328srfi-69.scm",(void*)f_1328},
{"f_1307srfi-69.scm",(void*)f_1307},
{"f_1299srfi-69.scm",(void*)f_1299},
{"f_1278srfi-69.scm",(void*)f_1278},
{"f_1252srfi-69.scm",(void*)f_1252},
{"f_1146srfi-69.scm",(void*)f_1146},
{"f_1081srfi-69.scm",(void*)f_1081},
{"f_1098srfi-69.scm",(void*)f_1098},
{"f_1132srfi-69.scm",(void*)f_1132},
{"f_1037srfi-69.scm",(void*)f_1037},
{"f_1055srfi-69.scm",(void*)f_1055},
{"f_957srfi-69.scm",(void*)f_957},
{"f_1026srfi-69.scm",(void*)f_1026},
{"f_915srfi-69.scm",(void*)f_915},
{"f_933srfi-69.scm",(void*)f_933},
{"f_854srfi-69.scm",(void*)f_854},
{"f_809srfi-69.scm",(void*)f_809},
{"f_816srfi-69.scm",(void*)f_816},
{"f_783srfi-69.scm",(void*)f_783},
{"f_790srfi-69.scm",(void*)f_790},
{"f_738srfi-69.scm",(void*)f_738},
{"f_697srfi-69.scm",(void*)f_697},
{"f_715srfi-69.scm",(void*)f_715},
{"f_691srfi-69.scm",(void*)f_691},
{"f_625srfi-69.scm",(void*)f_625},
{"f_632srfi-69.scm",(void*)f_632},
{"f_671srfi-69.scm",(void*)f_671},
{"f_646srfi-69.scm",(void*)f_646},
{"f_619srfi-69.scm",(void*)f_619},
{"f_613srfi-69.scm",(void*)f_613},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
