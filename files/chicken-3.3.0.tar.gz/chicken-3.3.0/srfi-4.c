/* Generated from srfi-4.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-06-28 11:41
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10664	compiled 2008-06-28 on galinha (Linux)
   command line: srfi-4.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file srfi-4.c
   unit: srfi_4
*/

#include "chicken.h"

#define C_u8peek(b, i)         C_fix(((unsigned char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s8peek(b, i)         C_fix(((char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_u16peek(b, i)        C_fix(((unsigned short *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s16peek(b, i)        C_fix(((short *)C_data_pointer(b))[ C_unfix(i) ])
#ifdef C_SIXTY_FOUR
# define C_a_u32peek(ptr, d, b, i) C_fix(((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_fix(((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#else
# define C_a_u32peek(ptr, d, b, i) C_unsigned_int_to_num(ptr, ((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_int_to_num(ptr, ((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#endif
#define C_f32peek(b, i)        (C_temporary_flonum = ((float *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_f64peek(b, i)        (C_temporary_flonum = ((double *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_u8poke(b, i, x)      ((((unsigned char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s8poke(b, i, x)      ((((char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u16poke(b, i, x)     ((((unsigned short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s16poke(b, i, x)     ((((short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u32poke(b, i, x)     ((((C_u32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_unsigned_int(x)), C_SCHEME_UNDEFINED)
#define C_s32poke(b, i, x)     ((((C_s32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_int(x)), C_SCHEME_UNDEFINED)
#define C_f32poke(b, i, x)     ((((float *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_f64poke(b, i, x)     ((((double *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_copy_subvector(to, from, start_to, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to) + C_unfix(start_to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[192];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,46),40,35,35,115,121,115,35,99,104,101,99,107,45,101,120,97,99,116,45,105,110,116,101,114,118,97,108,32,110,48,32,102,114,111,109,49,32,116,111,50,32,108,111,99,51,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,49),40,35,35,115,121,115,35,99,104,101,99,107,45,105,110,101,120,97,99,116,45,105,110,116,101,114,118,97,108,32,110,55,32,102,114,111,109,56,32,116,111,57,32,108,111,99,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,117,56,118,101,99,116,111,114,45,114,101,102,32,118,49,52,32,105,49,53,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,115,56,118,101,99,116,111,114,45,114,101,102,32,118,49,54,32,105,49,55,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,117,49,54,118,101,99,116,111,114,45,114,101,102,32,118,49,56,32,105,49,57,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,115,49,54,118,101,99,116,111,114,45,114,101,102,32,118,50,48,32,105,50,49,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,117,51,50,118,101,99,116,111,114,45,114,101,102,32,118,50,50,32,105,50,51,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,115,51,50,118,101,99,116,111,114,45,114,101,102,32,118,50,52,32,105,50,53,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,51,50,118,101,99,116,111,114,45,114,101,102,32,118,50,54,32,105,50,55,41,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,54,52,118,101,99,116,111,114,45,114,101,102,32,118,50,57,32,105,51,48,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,117,56,118,101,99,116,111,114,45,115,101,116,33,32,118,51,50,32,105,51,51,32,120,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,115,56,118,101,99,116,111,114,45,115,101,116,33,32,118,51,53,32,105,51,54,32,120,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,117,49,54,118,101,99,116,111,114,45,115,101,116,33,32,118,51,56,32,105,51,57,32,120,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,115,49,54,118,101,99,116,111,114,45,115,101,116,33,32,118,52,49,32,105,52,50,32,120,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,117,51,50,118,101,99,116,111,114,45,115,101,116,33,32,105,52,53,32,120,52,54,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,115,51,50,118,101,99,116,111,114,45,115,101,116,33,32,105,52,56,32,120,52,57,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,102,51,50,118,101,99,116,111,114,45,115,101,116,33,32,118,53,48,32,105,53,49,32,120,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,102,54,52,118,101,99,116,111,114,45,115,101,116,33,32,118,53,51,32,105,53,52,32,120,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,11),40,102,95,57,52,48,32,118,54,48,41,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,25),40,108,101,110,32,116,97,103,53,55,32,115,104,105,102,116,53,56,32,108,111,99,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,15),40,102,95,57,56,51,32,118,56,48,32,105,56,49,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,26),40,103,101,116,32,108,101,110,103,116,104,55,55,32,97,99,99,55,56,32,108,111,99,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,19),40,102,95,57,57,55,32,118,56,55,32,105,56,56,32,120,56,57,41,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,26),40,115,101,116,32,108,101,110,103,116,104,56,52,32,117,112,100,56,53,32,108,111,99,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,20),40,102,95,49,48,49,52,32,118,57,54,32,105,57,55,32,120,57,56,41,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,32,108,101,110,103,116,104,57,51,32,117,112,100,57,52,32,108,111,99,57,53,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,23),40,102,95,49,49,48,51,32,118,49,50,52,32,105,49,50,53,32,120,49,50,54,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,30),40,115,101,116,102,32,108,101,110,103,116,104,49,50,49,32,117,112,100,49,50,50,32,108,111,99,49,50,51,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,23),40,102,95,49,48,54,55,32,118,49,49,53,32,105,49,49,54,32,120,49,49,55,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,23),40,102,95,49,48,52,48,32,118,49,48,54,32,105,49,48,55,32,120,49,48,56,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,18),40,101,120,116,45,102,114,101,101,32,97,49,53,55,49,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,29),40,97,108,108,111,99,32,108,111,99,49,54,51,32,108,101,110,49,54,52,32,101,120,116,63,49,54,53,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,28),40,114,101,108,101,97,115,101,45,110,117,109,98,101,114,45,118,101,99,116,111,114,32,118,49,55,49,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,12),40,100,111,49,56,57,32,105,49,57,49,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,49,55,56,32,105,110,105,116,49,56,53,32,101,120,116,63,49,56,54,32,102,105,110,63,49,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,37),40,100,101,102,45,102,105,110,63,49,56,50,32,37,105,110,105,116,49,55,53,49,57,56,32,37,101,120,116,63,49,55,54,49,57,57,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,49,56,49,32,37,105,110,105,116,49,55,53,50,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,49,56,48,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,32),40,109,97,107,101,45,117,56,118,101,99,116,111,114,32,108,101,110,49,55,51,32,46,32,103,49,55,50,49,55,52,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,12),40,100,111,50,50,55,32,105,50,50,57,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,50,49,54,32,105,110,105,116,50,50,51,32,101,120,116,63,50,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,50,50,48,32,37,105,110,105,116,50,49,51,50,51,54,32,37,101,120,116,63,50,49,52,50,51,55,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,50,49,57,32,37,105,110,105,116,50,49,51,50,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,50,49,56,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,32),40,109,97,107,101,45,115,56,118,101,99,116,111,114,32,108,101,110,50,49,49,32,46,32,103,50,49,48,50,49,50,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,100,111,50,54,52,32,105,50,54,54,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,50,53,51,32,105,110,105,116,50,54,48,32,101,120,116,63,50,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,50,53,55,32,37,105,110,105,116,50,53,48,50,55,51,32,37,101,120,116,63,50,53,49,50,55,52,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,50,53,54,32,37,105,110,105,116,50,53,48,50,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,50,53,53,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,117,49,54,118,101,99,116,111,114,32,108,101,110,50,52,56,32,46,32,103,50,52,55,50,52,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,12),40,100,111,51,48,49,32,105,51,48,51,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,50,57,48,32,105,110,105,116,50,57,55,32,101,120,116,63,50,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,50,57,52,32,37,105,110,105,116,50,56,55,51,49,48,32,37,101,120,116,63,50,56,56,51,49,49,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,50,57,51,32,37,105,110,105,116,50,56,55,51,49,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,50,57,50,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,115,49,54,118,101,99,116,111,114,32,108,101,110,50,56,53,32,46,32,103,50,56,52,50,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,100,111,51,51,56,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,51,50,55,32,105,110,105,116,51,51,52,32,101,120,116,63,51,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,51,51,49,32,37,105,110,105,116,51,50,52,51,52,55,32,37,101,120,116,63,51,50,53,51,52,56,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,51,51,48,32,37,105,110,105,116,51,50,52,51,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,51,50,57,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,117,51,50,118,101,99,116,111,114,32,108,101,110,51,50,50,32,46,32,103,51,50,49,51,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,7),40,100,111,51,55,53,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,51,54,52,32,105,110,105,116,51,55,49,32,101,120,116,63,51,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,51,54,56,32,37,105,110,105,116,51,54,49,51,56,52,32,37,101,120,116,63,51,54,50,51,56,53,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,51,54,55,32,37,105,110,105,116,51,54,49,51,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,51,54,54,41,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,115,51,50,118,101,99,116,111,114,32,108,101,110,51,53,57,32,46,32,103,51,53,56,51,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,12),40,100,111,52,49,50,32,105,52,49,52,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,52,48,49,32,105,110,105,116,52,48,56,32,101,120,116,63,52,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,52,48,53,32,37,105,110,105,116,51,57,56,52,50,50,32,37,101,120,116,63,51,57,57,52,50,51,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,52,48,52,32,37,105,110,105,116,51,57,56,52,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,52,48,51,41,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,102,51,50,118,101,99,116,111,114,32,108,101,110,51,57,54,32,46,32,103,51,57,53,51,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,12),40,100,111,52,53,48,32,105,52,53,50,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,52,51,57,32,105,110,105,116,52,52,54,32,101,120,116,63,52,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,52,52,51,32,37,105,110,105,116,52,51,54,52,54,48,32,37,101,120,116,63,52,51,55,52,54,49,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,52,52,50,32,37,105,110,105,116,52,51,54,52,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,52,52,49,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,102,54,52,118,101,99,116,111,114,32,108,101,110,52,51,52,32,46,32,103,52,51,51,52,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,17),40,100,111,52,56,54,32,112,52,56,56,32,105,52,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,15),40,102,95,50,50,49,53,32,108,115,116,52,56,51,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,28),40,105,110,105,116,32,109,97,107,101,52,56,48,32,115,101,116,52,56,49,32,108,111,99,52,56,50,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,18),40,117,56,118,101,99,116,111,114,32,46,32,120,115,53,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,18),40,115,56,118,101,99,116,111,114,32,46,32,120,115,53,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,19),40,117,49,54,118,101,99,116,111,114,32,46,32,120,115,53,48,54,41,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,19),40,115,49,54,118,101,99,116,111,114,32,46,32,120,115,53,48,56,41,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,19),40,117,51,50,118,101,99,116,111,114,32,46,32,120,115,53,49,48,41,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,19),40,115,51,50,118,101,99,116,111,114,32,46,32,120,115,53,49,50,41,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,19),40,102,51,50,118,101,99,116,111,114,32,46,32,120,115,53,49,52,41,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,19),40,102,54,52,118,101,99,116,111,114,32,46,32,120,115,53,49,54,41,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,53,50,52,41,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,13),40,102,95,50,51,51,51,32,118,53,50,49,41,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,23),40,105,110,105,116,32,108,101,110,103,116,104,53,49,57,32,114,101,102,53,50,48,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,16),40,117,56,118,101,99,116,111,114,63,32,120,53,51,52,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,16),40,115,56,118,101,99,116,111,114,63,32,120,53,51,53,41};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,17),40,117,49,54,118,101,99,116,111,114,63,32,120,53,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,17),40,115,49,54,118,101,99,116,111,114,63,32,120,53,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,17),40,117,51,50,118,101,99,116,111,114,63,32,120,53,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,17),40,115,51,50,118,101,99,116,111,114,63,32,120,53,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,17),40,102,51,50,118,101,99,116,111,114,63,32,120,53,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,17),40,102,54,52,118,101,99,116,111,114,63,32,120,53,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,13),40,102,95,50,52,52,56,32,118,53,52,56,41,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,20),40,112,97,99,107,32,116,97,103,53,52,54,32,108,111,99,53,52,55,41,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,13),40,102,95,50,52,53,57,32,118,53,53,50,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,25),40,112,97,99,107,45,99,111,112,121,32,116,97,103,53,53,48,32,108,111,99,53,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,15),40,102,95,50,52,55,55,32,115,116,114,53,53,57,41,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,28),40,117,110,112,97,99,107,32,116,97,103,53,53,54,32,115,122,53,53,55,32,108,111,99,53,53,56,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,15),40,102,95,50,53,48,54,32,115,116,114,53,54,55,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,33),40,117,110,112,97,99,107,45,99,111,112,121,32,116,97,103,53,54,52,32,115,122,53,54,53,32,108,111,99,53,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,117,115,101,114,45,114,101,97,100,45,104,111,111,107,32,99,104,97,114,54,50,55,32,112,111,114,116,54,50,56,41,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,117,115,101,114,45,112,114,105,110,116,45,104,111,111,107,32,120,54,51,55,32,114,101,97,100,97,98,108,101,54,51,56,32,112,111,114,116,54,51,57,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,48),40,115,117,98,118,101,99,116,111,114,32,118,54,52,51,32,116,54,52,52,32,101,115,54,52,53,32,102,114,111,109,54,52,54,32,116,111,54,52,55,32,108,111,99,54,52,56,41};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,32),40,115,117,98,117,56,118,101,99,116,111,114,32,118,54,54,48,32,102,114,111,109,54,54,49,32,116,111,54,54,50,41};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,33),40,115,117,98,117,49,54,118,101,99,116,111,114,32,118,54,54,51,32,102,114,111,109,54,54,52,32,116,111,54,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,33),40,115,117,98,117,51,50,118,101,99,116,111,114,32,118,54,54,54,32,102,114,111,109,54,54,55,32,116,111,54,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,32),40,115,117,98,115,56,118,101,99,116,111,114,32,118,54,54,57,32,102,114,111,109,54,55,48,32,116,111,54,55,49,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,33),40,115,117,98,115,49,54,118,101,99,116,111,114,32,118,54,55,50,32,102,114,111,109,54,55,51,32,116,111,54,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,33),40,115,117,98,115,51,50,118,101,99,116,111,114,32,118,54,55,53,32,102,114,111,109,54,55,54,32,116,111,54,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,33),40,115,117,98,102,51,50,118,101,99,116,111,114,32,118,54,55,56,32,102,114,111,109,54,55,57,32,116,111,54,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,33),40,115,117,98,102,54,52,118,101,99,116,111,114,32,118,54,56,49,32,102,114,111,109,54,56,50,32,116,111,54,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,12),40,100,111,55,48,49,32,105,55,48,51,41,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,31),40,98,111,100,121,54,57,48,32,112,111,114,116,54,57,55,32,102,114,111,109,54,57,56,32,116,111,54,57,57,41,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,116,111,54,57,52,32,37,112,111,114,116,54,56,55,55,48,57,32,37,102,114,111,109,54,56,56,55,49,48,41,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,102,114,111,109,54,57,51,32,37,112,111,114,116,54,56,55,55,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,112,111,114,116,54,57,50,41,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,31),40,119,114,105,116,101,45,117,56,118,101,99,116,111,114,32,118,54,56,53,32,46,32,103,54,56,52,54,56,54,41,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,55,50,54,32,112,111,114,116,55,51,50,32,115,116,97,114,116,55,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,115,116,97,114,116,55,50,57,32,37,112,111,114,116,55,50,52,55,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,112,111,114,116,55,50,56,41,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,39),40,114,101,97,100,45,117,56,118,101,99,116,111,114,33,32,110,55,50,49,32,100,101,115,116,55,50,50,32,46,32,103,55,50,48,55,50,51,41,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,18),40,119,114,97,112,32,115,116,114,55,53,48,32,110,55,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,19),40,98,111,100,121,55,53,57,32,110,55,54,53,32,112,55,54,54,41,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,19),40,100,101,102,45,112,55,54,50,32,37,110,55,53,55,55,56,48,41,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,55,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,25),40,114,101,97,100,45,117,56,118,101,99,116,111,114,32,46,32,103,55,53,53,55,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from ext-free in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub158(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub158(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_ret:
#undef return

return C_r;}

/* from k1191 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub153(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub153(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) return(C_SCHEME_FALSE);C_block_header(buf) = C_make_header(C_BYTEVECTOR_TYPE, bytes);return(buf);
C_ret:
#undef return

return C_r;}

C_noret_decl(C_srfi_4_toplevel)
C_externexport void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_967)
static void C_ccall f_967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1151)
static void C_ccall f_1151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2384)
static void C_ccall f_2384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3241)
static void C_fcall f_3241(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_fcall f_3236(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3174)
static void C_fcall f_3174(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3205)
static void C_ccall f_3205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_fcall f_3210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3163)
static void C_fcall f_3163(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3114)
static void C_fcall f_3114(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_fcall f_3109(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3064)
static void C_fcall f_3064(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_fcall f_3080(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2999)
static void C_fcall f_2999(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_fcall f_2994(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2985)
static void C_fcall f_2985(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_fcall f_2948(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_fcall f_2963(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2855)
static void C_fcall f_2855(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_fcall f_2504(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_fcall f_2475(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2457)
static void C_fcall f_2457(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_fcall f_2446(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2331)
static void C_fcall f_2331(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_fcall f_2342(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2213)
static void C_fcall f_2213(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_fcall f_2230(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2150)
static void C_fcall f_2150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2145)
static void C_fcall f_2145(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2140)
static void C_fcall f_2140(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2088)
static void C_fcall f_2088(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_fcall f_2110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_fcall f_2115(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2023)
static void C_fcall f_2023(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_fcall f_2018(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2013)
static void C_fcall f_2013(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1961)
static void C_fcall f_1961(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_fcall f_1983(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_fcall f_1988(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1896)
static void C_fcall f_1896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_fcall f_1891(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1886)
static void C_fcall f_1886(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1841)
static void C_fcall f_1841(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static C_word C_fcall f_1865(C_word t0,C_word t1);
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1776)
static void C_fcall f_1776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_fcall f_1771(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1766)
static void C_fcall f_1766(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1721)
static void C_fcall f_1721(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static C_word C_fcall f_1745(C_word t0,C_word t1);
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1656)
static void C_fcall f_1656(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_fcall f_1651(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1646)
static void C_fcall f_1646(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1601)
static void C_fcall f_1601(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_fcall f_1625(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1479)
static void C_ccall f_1479(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1479)
static void C_ccall f_1479r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1536)
static void C_fcall f_1536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_fcall f_1531(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1526)
static void C_fcall f_1526(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1481)
static void C_fcall f_1481(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1491)
static void C_ccall f_1491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_fcall f_1505(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1416)
static void C_fcall f_1416(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_fcall f_1411(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1406)
static void C_fcall f_1406(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1361)
static void C_fcall f_1361(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1371)
static void C_ccall f_1371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_fcall f_1385(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1296)
static void C_fcall f_1296(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_fcall f_1291(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1286)
static void C_fcall f_1286(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1241)
static void C_fcall f_1241(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1265)
static void C_fcall f_1265(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1221)
static void C_fcall f_1221(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_fcall f_1196(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1194)
static void C_ccall f_1194(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1101)
static void C_fcall f_1101(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1012)
static void C_fcall f_1012(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_995)
static void C_fcall f_995(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_997)
static void C_ccall f_997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1001)
static void C_ccall f_1001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_981)
static void C_fcall f_981(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_938)
static void C_fcall f_938(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_940)
static void C_ccall f_940(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_932)
static void C_ccall f_932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_929)
static C_word C_fcall f_929(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_926)
static C_word C_fcall f_926(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_920)
static void C_ccall f_920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_914)
static void C_ccall f_914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_896)
static void C_ccall f_896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_887)
static void C_ccall f_887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_884)
static void C_ccall f_884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_848)
static void C_ccall f_848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;

C_noret_decl(trf_3241)
static void C_fcall trf_3241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3241(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3241(t0,t1);}

C_noret_decl(trf_3236)
static void C_fcall trf_3236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3236(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3236(t0,t1,t2);}

C_noret_decl(trf_3174)
static void C_fcall trf_3174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3174(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3174(t0,t1,t2,t3);}

C_noret_decl(trf_3210)
static void C_fcall trf_3210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3210(t0,t1);}

C_noret_decl(trf_3163)
static void C_fcall trf_3163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3163(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3163(t0,t1,t2);}

C_noret_decl(trf_3114)
static void C_fcall trf_3114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3114(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3114(t0,t1);}

C_noret_decl(trf_3109)
static void C_fcall trf_3109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3109(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3109(t0,t1,t2);}

C_noret_decl(trf_3064)
static void C_fcall trf_3064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3064(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3064(t0,t1,t2,t3);}

C_noret_decl(trf_3080)
static void C_fcall trf_3080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3080(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3080(t0,t1);}

C_noret_decl(trf_2999)
static void C_fcall trf_2999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2999(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2999(t0,t1);}

C_noret_decl(trf_2994)
static void C_fcall trf_2994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2994(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2994(t0,t1,t2);}

C_noret_decl(trf_2985)
static void C_fcall trf_2985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2985(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2985(t0,t1,t2,t3);}

C_noret_decl(trf_2948)
static void C_fcall trf_2948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2948(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2948(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2963)
static void C_fcall trf_2963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2963(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2963(t0,t1,t2);}

C_noret_decl(trf_2855)
static void C_fcall trf_2855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2855(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2855(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2504)
static void C_fcall trf_2504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2504(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2504(t0,t1,t2,t3);}

C_noret_decl(trf_2475)
static void C_fcall trf_2475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2475(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2475(t0,t1,t2,t3);}

C_noret_decl(trf_2457)
static void C_fcall trf_2457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2457(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2457(t0,t1,t2);}

C_noret_decl(trf_2446)
static void C_fcall trf_2446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2446(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2446(t0,t1,t2);}

C_noret_decl(trf_2331)
static void C_fcall trf_2331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2331(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2331(t0,t1,t2);}

C_noret_decl(trf_2342)
static void C_fcall trf_2342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2342(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2342(t0,t1,t2);}

C_noret_decl(trf_2213)
static void C_fcall trf_2213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2213(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2213(t0,t1,t2,t3);}

C_noret_decl(trf_2230)
static void C_fcall trf_2230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2230(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2230(t0,t1,t2,t3);}

C_noret_decl(trf_2150)
static void C_fcall trf_2150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2150(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2150(t0,t1);}

C_noret_decl(trf_2145)
static void C_fcall trf_2145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2145(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2145(t0,t1,t2);}

C_noret_decl(trf_2140)
static void C_fcall trf_2140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2140(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2140(t0,t1,t2,t3);}

C_noret_decl(trf_2088)
static void C_fcall trf_2088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2088(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2088(t0,t1,t2,t3);}

C_noret_decl(trf_2110)
static void C_fcall trf_2110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2110(t0,t1);}

C_noret_decl(trf_2115)
static void C_fcall trf_2115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2115(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2115(t0,t1,t2);}

C_noret_decl(trf_2023)
static void C_fcall trf_2023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2023(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2023(t0,t1);}

C_noret_decl(trf_2018)
static void C_fcall trf_2018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2018(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2018(t0,t1,t2);}

C_noret_decl(trf_2013)
static void C_fcall trf_2013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2013(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2013(t0,t1,t2,t3);}

C_noret_decl(trf_1961)
static void C_fcall trf_1961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1961(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1961(t0,t1,t2,t3);}

C_noret_decl(trf_1983)
static void C_fcall trf_1983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1983(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1983(t0,t1);}

C_noret_decl(trf_1988)
static void C_fcall trf_1988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1988(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1988(t0,t1,t2);}

C_noret_decl(trf_1896)
static void C_fcall trf_1896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1896(t0,t1);}

C_noret_decl(trf_1891)
static void C_fcall trf_1891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1891(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1891(t0,t1,t2);}

C_noret_decl(trf_1886)
static void C_fcall trf_1886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1886(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1886(t0,t1,t2,t3);}

C_noret_decl(trf_1841)
static void C_fcall trf_1841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1841(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1841(t0,t1,t2,t3);}

C_noret_decl(trf_1776)
static void C_fcall trf_1776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1776(t0,t1);}

C_noret_decl(trf_1771)
static void C_fcall trf_1771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1771(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1771(t0,t1,t2);}

C_noret_decl(trf_1766)
static void C_fcall trf_1766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1766(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1766(t0,t1,t2,t3);}

C_noret_decl(trf_1721)
static void C_fcall trf_1721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1721(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1721(t0,t1,t2,t3);}

C_noret_decl(trf_1656)
static void C_fcall trf_1656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1656(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1656(t0,t1);}

C_noret_decl(trf_1651)
static void C_fcall trf_1651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1651(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1651(t0,t1,t2);}

C_noret_decl(trf_1646)
static void C_fcall trf_1646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1646(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1646(t0,t1,t2,t3);}

C_noret_decl(trf_1601)
static void C_fcall trf_1601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1601(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1601(t0,t1,t2,t3);}

C_noret_decl(trf_1625)
static void C_fcall trf_1625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1625(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1625(t0,t1,t2);}

C_noret_decl(trf_1536)
static void C_fcall trf_1536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1536(t0,t1);}

C_noret_decl(trf_1531)
static void C_fcall trf_1531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1531(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1531(t0,t1,t2);}

C_noret_decl(trf_1526)
static void C_fcall trf_1526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1526(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1526(t0,t1,t2,t3);}

C_noret_decl(trf_1481)
static void C_fcall trf_1481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1481(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1481(t0,t1,t2,t3);}

C_noret_decl(trf_1505)
static void C_fcall trf_1505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1505(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1505(t0,t1,t2);}

C_noret_decl(trf_1416)
static void C_fcall trf_1416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1416(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1416(t0,t1);}

C_noret_decl(trf_1411)
static void C_fcall trf_1411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1411(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1411(t0,t1,t2);}

C_noret_decl(trf_1406)
static void C_fcall trf_1406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1406(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1406(t0,t1,t2,t3);}

C_noret_decl(trf_1361)
static void C_fcall trf_1361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1361(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1361(t0,t1,t2,t3);}

C_noret_decl(trf_1385)
static void C_fcall trf_1385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1385(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1385(t0,t1,t2);}

C_noret_decl(trf_1296)
static void C_fcall trf_1296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1296(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1296(t0,t1);}

C_noret_decl(trf_1291)
static void C_fcall trf_1291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1291(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1291(t0,t1,t2);}

C_noret_decl(trf_1286)
static void C_fcall trf_1286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1286(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1286(t0,t1,t2,t3);}

C_noret_decl(trf_1241)
static void C_fcall trf_1241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1241(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1241(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1265)
static void C_fcall trf_1265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1265(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1265(t0,t1,t2);}

C_noret_decl(trf_1221)
static void C_fcall trf_1221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1221(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1221(t0,t1);}

C_noret_decl(trf_1196)
static void C_fcall trf_1196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1196(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1196(t0,t1,t2,t3);}

C_noret_decl(trf_1101)
static void C_fcall trf_1101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1101(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1101(t0,t1,t2,t3);}

C_noret_decl(trf_1012)
static void C_fcall trf_1012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1012(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1012(t0,t1,t2,t3);}

C_noret_decl(trf_995)
static void C_fcall trf_995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_995(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_995(t0,t1,t2,t3);}

C_noret_decl(trf_981)
static void C_fcall trf_981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_981(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_981(t0,t1,t2,t3);}

C_noret_decl(trf_938)
static void C_fcall trf_938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_938(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_938(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_4_toplevel"));
C_check_nursery_minimum(61);
if(!C_demand(61)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1714)){
C_save(t1);
C_rereclaim2(1714*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(61);
C_initialize_lf(lf,192);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscheck-exact-interval");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[5]=C_h_intern(&lf[5],26,"\003syscheck-inexact-interval");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[14]=C_h_intern(&lf[14],15,"\003syscons-flonum");
lf[24]=C_h_intern(&lf[24],15,"u8vector-length");
lf[25]=C_h_intern(&lf[25],15,"s8vector-length");
lf[26]=C_h_intern(&lf[26],16,"u16vector-length");
lf[27]=C_h_intern(&lf[27],16,"s16vector-length");
lf[28]=C_h_intern(&lf[28],16,"u32vector-length");
lf[29]=C_h_intern(&lf[29],16,"s32vector-length");
lf[30]=C_h_intern(&lf[30],16,"f32vector-length");
lf[31]=C_h_intern(&lf[31],16,"f64vector-length");
lf[32]=C_h_intern(&lf[32],15,"\003syscheck-range");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[34]=C_h_intern(&lf[34],13,"u8vector-set!");
lf[35]=C_h_intern(&lf[35],13,"s8vector-set!");
lf[36]=C_h_intern(&lf[36],14,"u16vector-set!");
lf[37]=C_h_intern(&lf[37],14,"s16vector-set!");
lf[38]=C_h_intern(&lf[38],14,"u32vector-set!");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[41]=C_h_intern(&lf[41],14,"s32vector-set!");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[43]=C_h_intern(&lf[43],14,"f32vector-set!");
lf[44]=C_h_intern(&lf[44],14,"f64vector-set!");
lf[45]=C_h_intern(&lf[45],12,"u8vector-ref");
lf[46]=C_h_intern(&lf[46],12,"s8vector-ref");
lf[47]=C_h_intern(&lf[47],13,"u16vector-ref");
lf[48]=C_h_intern(&lf[48],13,"s16vector-ref");
lf[49]=C_h_intern(&lf[49],13,"u32vector-ref");
lf[50]=C_h_intern(&lf[50],13,"s32vector-ref");
lf[51]=C_h_intern(&lf[51],13,"f32vector-ref");
lf[52]=C_h_intern(&lf[52],13,"f64vector-ref");
lf[53]=C_h_intern(&lf[53],14,"set-finalizer!");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000;not enough memory - can not allocate external number vector");
lf[55]=C_h_intern(&lf[55],19,"\003sysallocate-vector");
lf[56]=C_h_intern(&lf[56],21,"release-number-vector");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\047bad argument type - not a number vector");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376"
"\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[59]=C_h_intern(&lf[59],13,"make-u8vector");
lf[60]=C_h_intern(&lf[60],8,"u8vector");
lf[61]=C_h_intern(&lf[61],13,"make-s8vector");
lf[62]=C_h_intern(&lf[62],8,"s8vector");
lf[63]=C_h_intern(&lf[63],4,"fin\077");
lf[64]=C_h_intern(&lf[64],14,"make-u16vector");
lf[65]=C_h_intern(&lf[65],9,"u16vector");
lf[66]=C_h_intern(&lf[66],14,"make-s16vector");
lf[67]=C_h_intern(&lf[67],9,"s16vector");
lf[68]=C_h_intern(&lf[68],14,"make-u32vector");
lf[69]=C_h_intern(&lf[69],9,"u32vector");
lf[70]=C_h_intern(&lf[70],14,"make-s32vector");
lf[71]=C_h_intern(&lf[71],9,"s32vector");
lf[72]=C_h_intern(&lf[72],14,"make-f32vector");
lf[73]=C_h_intern(&lf[73],9,"f32vector");
lf[74]=C_h_intern(&lf[74],14,"make-f64vector");
lf[75]=C_h_intern(&lf[75],9,"f64vector");
lf[76]=C_h_intern(&lf[76],27,"\003sysnot-a-proper-list-error");
lf[77]=C_h_intern(&lf[77],14,"list->u8vector");
lf[78]=C_h_intern(&lf[78],14,"list->s8vector");
lf[79]=C_h_intern(&lf[79],15,"list->u16vector");
lf[80]=C_h_intern(&lf[80],15,"list->s16vector");
lf[81]=C_h_intern(&lf[81],15,"list->u32vector");
lf[82]=C_h_intern(&lf[82],15,"list->s32vector");
lf[83]=C_h_intern(&lf[83],15,"list->f32vector");
lf[84]=C_h_intern(&lf[84],15,"list->f64vector");
lf[85]=C_h_intern(&lf[85],14,"u8vector->list");
lf[86]=C_h_intern(&lf[86],14,"s8vector->list");
lf[87]=C_h_intern(&lf[87],15,"u16vector->list");
lf[88]=C_h_intern(&lf[88],15,"s16vector->list");
lf[89]=C_h_intern(&lf[89],15,"u32vector->list");
lf[90]=C_h_intern(&lf[90],15,"s32vector->list");
lf[91]=C_h_intern(&lf[91],15,"f32vector->list");
lf[92]=C_h_intern(&lf[92],15,"f64vector->list");
lf[93]=C_h_intern(&lf[93],9,"u8vector\077");
lf[94]=C_h_intern(&lf[94],9,"s8vector\077");
lf[95]=C_h_intern(&lf[95],10,"u16vector\077");
lf[96]=C_h_intern(&lf[96],10,"s16vector\077");
lf[97]=C_h_intern(&lf[97],10,"u32vector\077");
lf[98]=C_h_intern(&lf[98],10,"s32vector\077");
lf[99]=C_h_intern(&lf[99],10,"f32vector\077");
lf[100]=C_h_intern(&lf[100],10,"f64vector\077");
lf[101]=C_h_intern(&lf[101],13,"\003sysmake-blob");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[104]=C_h_intern(&lf[104],21,"u8vector->byte-vector");
lf[105]=C_h_intern(&lf[105],21,"s8vector->byte-vector");
lf[106]=C_h_intern(&lf[106],22,"u16vector->byte-vector");
lf[107]=C_h_intern(&lf[107],22,"s16vector->byte-vector");
lf[108]=C_h_intern(&lf[108],22,"u32vector->byte-vector");
lf[109]=C_h_intern(&lf[109],22,"s32vector->byte-vector");
lf[110]=C_h_intern(&lf[110],22,"f32vector->byte-vector");
lf[111]=C_h_intern(&lf[111],22,"f64vector->byte-vector");
lf[112]=C_h_intern(&lf[112],21,"u8vector->blob/shared");
lf[113]=C_h_intern(&lf[113],21,"s8vector->blob/shared");
lf[114]=C_h_intern(&lf[114],22,"u16vector->blob/shared");
lf[115]=C_h_intern(&lf[115],22,"s16vector->blob/shared");
lf[116]=C_h_intern(&lf[116],22,"u32vector->blob/shared");
lf[117]=C_h_intern(&lf[117],22,"s32vector->blob/shared");
lf[118]=C_h_intern(&lf[118],22,"f32vector->blob/shared");
lf[119]=C_h_intern(&lf[119],22,"f64vector->blob/shared");
lf[120]=C_h_intern(&lf[120],14,"u8vector->blob");
lf[121]=C_h_intern(&lf[121],14,"s8vector->blob");
lf[122]=C_h_intern(&lf[122],15,"u16vector->blob");
lf[123]=C_h_intern(&lf[123],15,"s16vector->blob");
lf[124]=C_h_intern(&lf[124],15,"u32vector->blob");
lf[125]=C_h_intern(&lf[125],15,"s32vector->blob");
lf[126]=C_h_intern(&lf[126],15,"f32vector->blob");
lf[127]=C_h_intern(&lf[127],15,"f64vector->blob");
lf[128]=C_h_intern(&lf[128],21,"byte-vector->u8vector");
lf[129]=C_h_intern(&lf[129],21,"byte-vector->s8vector");
lf[130]=C_h_intern(&lf[130],22,"byte-vector->u16vector");
lf[131]=C_h_intern(&lf[131],22,"byte-vector->s16vector");
lf[132]=C_h_intern(&lf[132],22,"byte-vector->u32vector");
lf[133]=C_h_intern(&lf[133],22,"byte-vector->s32vector");
lf[134]=C_h_intern(&lf[134],22,"byte-vector->f32vector");
lf[135]=C_h_intern(&lf[135],22,"byte-vector->f64vector");
lf[136]=C_h_intern(&lf[136],21,"blob->u8vector/shared");
lf[137]=C_h_intern(&lf[137],21,"blob->s8vector/shared");
lf[138]=C_h_intern(&lf[138],22,"blob->u16vector/shared");
lf[139]=C_h_intern(&lf[139],22,"blob->s16vector/shared");
lf[140]=C_h_intern(&lf[140],22,"blob->u32vector/shared");
lf[141]=C_h_intern(&lf[141],22,"blob->s32vector/shared");
lf[142]=C_h_intern(&lf[142],22,"blob->f32vector/shared");
lf[143]=C_h_intern(&lf[143],22,"blob->f64vector/shared");
lf[144]=C_h_intern(&lf[144],14,"blob->u8vector");
lf[145]=C_h_intern(&lf[145],14,"blob->s8vector");
lf[146]=C_h_intern(&lf[146],15,"blob->u16vector");
lf[147]=C_h_intern(&lf[147],15,"blob->s16vector");
lf[148]=C_h_intern(&lf[148],15,"blob->u32vector");
lf[149]=C_h_intern(&lf[149],15,"blob->s32vector");
lf[150]=C_h_intern(&lf[150],15,"blob->f32vector");
lf[151]=C_h_intern(&lf[151],15,"blob->f64vector");
lf[152]=C_h_intern(&lf[152],18,"\003sysuser-read-hook");
lf[153]=C_h_intern(&lf[153],4,"read");
lf[154]=C_h_intern(&lf[154],2,"u8");
lf[155]=C_h_intern(&lf[155],2,"s8");
lf[156]=C_h_intern(&lf[156],3,"u16");
lf[157]=C_h_intern(&lf[157],3,"s16");
lf[158]=C_h_intern(&lf[158],3,"u32");
lf[159]=C_h_intern(&lf[159],3,"s32");
lf[160]=C_h_intern(&lf[160],3,"f32");
lf[161]=C_h_intern(&lf[161],3,"f64");
lf[162]=C_h_intern(&lf[162],1,"f");
lf[163]=C_h_intern(&lf[163],1,"F");
lf[164]=C_h_intern(&lf[164],14,"\003sysread-error");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal bytevector syntax");
lf[166]=C_h_intern(&lf[166],19,"\003sysuser-print-hook");
lf[167]=C_h_intern(&lf[167],9,"\003sysprint");
lf[169]=C_h_intern(&lf[169],11,"subu8vector");
lf[170]=C_h_intern(&lf[170],12,"subu16vector");
lf[171]=C_h_intern(&lf[171],12,"subu32vector");
lf[172]=C_h_intern(&lf[172],11,"subs8vector");
lf[173]=C_h_intern(&lf[173],12,"subs16vector");
lf[174]=C_h_intern(&lf[174],12,"subs32vector");
lf[175]=C_h_intern(&lf[175],12,"subf32vector");
lf[176]=C_h_intern(&lf[176],12,"subf64vector");
lf[177]=C_h_intern(&lf[177],14,"write-u8vector");
lf[178]=C_h_intern(&lf[178],16,"\003syswrite-char-0");
lf[179]=C_h_intern(&lf[179],14,"\003syscheck-port");
lf[180]=C_h_intern(&lf[180],19,"\003sysstandard-output");
lf[181]=C_h_intern(&lf[181],14,"read-u8vector!");
lf[182]=C_h_intern(&lf[182],16,"\003sysread-string!");
lf[183]=C_h_intern(&lf[183],18,"\003sysstandard-input");
lf[184]=C_h_intern(&lf[184],18,"open-output-string");
lf[185]=C_h_intern(&lf[185],17,"get-output-string");
lf[186]=C_h_intern(&lf[186],13,"read-u8vector");
lf[187]=C_h_intern(&lf[187],19,"\003syswrite-char/port");
lf[188]=C_h_intern(&lf[188],15,"\003sysread-char-0");
lf[189]=C_h_intern(&lf[189],17,"register-feature!");
lf[190]=C_h_intern(&lf[190],6,"srfi-4");
lf[191]=C_h_intern(&lf[191],18,"getter-with-setter");
C_register_lf2(lf,192,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_848,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_863,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[7],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_884,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[8],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_887,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_890,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[10],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_893,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[11],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_896,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[12],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_899,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[13],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_902,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[15],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_908,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[16],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_914,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[17],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_917,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[18],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_920,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[19],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_923,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[20],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_926,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_929,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[22],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_932,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[23],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_935,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_938,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_951,a[2]=t21,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 155  len */
f_938(t22,lf[60],C_SCHEME_FALSE,lf[24]);}

/* k949 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 156  len */
f_938(t3,lf[62],C_SCHEME_FALSE,lf[25]);}

/* k953 in k949 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_955,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 157  len */
f_938(t3,lf[65],C_fix(1),lf[26]);}

/* k957 in k953 in k949 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 158  len */
f_938(t3,lf[67],C_fix(1),lf[27]);}

/* k961 in k957 in k953 in k949 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 159  len */
f_938(t3,lf[69],C_fix(2),lf[28]);}

/* k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_967,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 160  len */
f_938(t3,lf[71],C_fix(2),lf[29]);}

/* k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_971,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 161  len */
f_938(t3,lf[73],C_fix(2),lf[30]);}

/* k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_975,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_979,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 162  len */
f_938(t3,lf[75],C_fix(3),lf[31]);}

/* k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_981,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_995,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1012,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1101,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1127,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 218  setu */
f_1012(t7,*((C_word*)lf[24]+1),lf[16],lf[34]);}

/* k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1127,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 219  set */
f_995(t3,*((C_word*)lf[25]+1),lf[17],lf[35]);}

/* k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1131,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 220  setu */
f_1012(t3,*((C_word*)lf[26]+1),lf[18],lf[36]);}

/* k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 221  set */
f_995(t3,*((C_word*)lf[27]+1),lf[19],lf[37]);}

/* k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1139,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1,t1);
t3=*((C_word*)lf[28]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1067,a[2]=t3,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
t5=C_mutate((C_word*)lf[38]+1,t4);
t6=*((C_word*)lf[29]+1);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1040,a[2]=t6,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t8=C_mutate((C_word*)lf[41]+1,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 224  setf */
f_1101(t9,*((C_word*)lf[30]+1),lf[22],lf[43]);}

/* k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1151,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1155,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 225  setf */
f_1101(t3,*((C_word*)lf[31]+1),lf[23],lf[44]);}

/* k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1155,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3322,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 228  get */
f_981(t4,*((C_word*)lf[24]+1),lf[7],lf[45]);}

/* k3320 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 228  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[34]+1));}

/* k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1159,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3318,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 231  get */
f_981(t4,*((C_word*)lf[25]+1),lf[8],lf[46]);}

/* k3316 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 231  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[35]+1));}

/* k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1163,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3314,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 234  get */
f_981(t4,*((C_word*)lf[26]+1),lf[9],lf[47]);}

/* k3312 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 234  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[36]+1));}

/* k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1167,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3310,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 237  get */
f_981(t4,*((C_word*)lf[27]+1),lf[10],lf[48]);}

/* k3308 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 237  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[37]+1));}

/* k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1171,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3306,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 241  get */
f_981(t4,*((C_word*)lf[28]+1),lf[11],lf[49]);}

/* k3304 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 240  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[38]+1));}

/* k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1175,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3302,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 245  get */
f_981(t4,*((C_word*)lf[29]+1),lf[12],lf[50]);}

/* k3300 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 244  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[41]+1));}

/* k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1179,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3298,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 249  get */
f_981(t4,*((C_word*)lf[30]+1),lf[13],lf[51]);}

/* k3296 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 248  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[43]+1));}

/* k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1183,2,t0,t1);}
t2=C_mutate((C_word*)lf[51]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3294,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 253  get */
f_981(t4,*((C_word*)lf[31]+1),lf[15],lf[52]);}

/* k3292 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 252  getter-with-setter */
t2=*((C_word*)lf[191]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[44]+1));}

/* k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1187,2,t0,t1);}
t2=C_mutate((C_word*)lf[52]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1194,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[53]+1);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1196,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
t6=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1214,a[2]=t3,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1239,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li38),tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1359,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li44),tmp=(C_word)a,a+=6,tmp));
t9=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1479,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t10=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1599,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li56),tmp=(C_word)a,a+=6,tmp));
t11=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1719,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp));
t12=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1839,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t13=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1959,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp));
t14=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2086,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li80),tmp=(C_word)a,a+=6,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2213,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2253,a[2]=t15,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 412  init */
f_2213(t16,*((C_word*)lf[59]+1),*((C_word*)lf[34]+1),lf[77]);}

/* k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 413  init */
f_2213(t3,*((C_word*)lf[61]+1),*((C_word*)lf[35]+1),lf[78]);}

/* k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2257,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 414  init */
f_2213(t3,*((C_word*)lf[64]+1),*((C_word*)lf[36]+1),lf[79]);}

/* k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 415  init */
f_2213(t3,*((C_word*)lf[66]+1),*((C_word*)lf[37]+1),lf[80]);}

/* k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2265,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 416  init */
f_2213(t3,*((C_word*)lf[68]+1),*((C_word*)lf[38]+1),lf[81]);}

/* k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2269,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 417  init */
f_2213(t3,*((C_word*)lf[70]+1),*((C_word*)lf[41]+1),lf[82]);}

/* k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2273,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 418  init */
f_2213(t3,*((C_word*)lf[72]+1),*((C_word*)lf[43]+1),lf[83]);}

/* k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2277,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 419  init */
f_2213(t3,*((C_word*)lf[74]+1),*((C_word*)lf[44]+1),lf[84]);}

/* k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2281,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1,t1);
t3=*((C_word*)lf[77]+1);
t4=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2283,a[2]=t3,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[78]+1);
t6=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2289,a[2]=t5,a[3]=((C_word)li85),tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[79]+1);
t8=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2295,a[2]=t7,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp));
t9=*((C_word*)lf[80]+1);
t10=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2301,a[2]=t9,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp));
t11=*((C_word*)lf[81]+1);
t12=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2307,a[2]=t11,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[82]+1);
t14=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2313,a[2]=t13,a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp));
t15=*((C_word*)lf[83]+1);
t16=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2319,a[2]=t15,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp));
t17=*((C_word*)lf[84]+1);
t18=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2325,a[2]=t17,a[3]=((C_word)li91),tmp=(C_word)a,a+=4,tmp));
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2331,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2368,a[2]=t19,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 470  init */
f_2331(t20,*((C_word*)lf[24]+1),lf[7]);}

/* k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 471  init */
f_2331(t3,*((C_word*)lf[25]+1),lf[8]);}

/* k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2372,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 472  init */
f_2331(t3,*((C_word*)lf[26]+1),lf[9]);}

/* k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 473  init */
f_2331(t3,*((C_word*)lf[27]+1),lf[10]);}

/* k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2380,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 474  init */
f_2331(t3,*((C_word*)lf[28]+1),lf[11]);}

/* k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2384,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 475  init */
f_2331(t3,*((C_word*)lf[29]+1),lf[12]);}

/* k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 476  init */
f_2331(t3,*((C_word*)lf[30]+1),lf[13]);}

/* k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2396,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 477  init */
f_2331(t3,*((C_word*)lf[31]+1),lf[15]);}

/* k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2396,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1,t1);
t3=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2398,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2404,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2410,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2422,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2428,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2434,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2440,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2446,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2457,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2475,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2504,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2538,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t14,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 529  pack */
f_2446(t15,lf[60],lf[104]);}

/* k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
t2=C_mutate((C_word*)lf[104]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 530  pack */
f_2446(t3,lf[62],lf[105]);}

/* k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2542,2,t0,t1);}
t2=C_mutate((C_word*)lf[105]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 531  pack */
f_2446(t3,lf[65],lf[106]);}

/* k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2546,2,t0,t1);}
t2=C_mutate((C_word*)lf[106]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 532  pack */
f_2446(t3,lf[67],lf[107]);}

/* k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=C_mutate((C_word*)lf[107]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 533  pack */
f_2446(t3,lf[69],lf[108]);}

/* k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=C_mutate((C_word*)lf[108]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 534  pack */
f_2446(t3,lf[71],lf[109]);}

/* k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=C_mutate((C_word*)lf[109]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 535  pack */
f_2446(t3,lf[73],lf[110]);}

/* k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2562,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 536  pack */
f_2446(t3,lf[75],lf[111]);}

/* k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 538  pack */
f_2446(t3,lf[60],lf[112]);}

/* k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 539  pack */
f_2446(t3,lf[62],lf[113]);}

/* k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2574,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 540  pack */
f_2446(t3,lf[65],lf[114]);}

/* k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2578,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 541  pack */
f_2446(t3,lf[67],lf[115]);}

/* k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 542  pack */
f_2446(t3,lf[69],lf[116]);}

/* k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2586,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 543  pack */
f_2446(t3,lf[71],lf[117]);}

/* k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2590,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 544  pack */
f_2446(t3,lf[73],lf[118]);}

/* k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=C_mutate((C_word*)lf[118]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 545  pack */
f_2446(t3,lf[75],lf[119]);}

/* k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2598,2,t0,t1);}
t2=C_mutate((C_word*)lf[119]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 547  pack-copy */
f_2457(t3,lf[60],lf[120]);}

/* k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
t2=C_mutate((C_word*)lf[120]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 548  pack-copy */
f_2457(t3,lf[62],lf[121]);}

/* k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=C_mutate((C_word*)lf[121]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 549  pack-copy */
f_2457(t3,lf[65],lf[122]);}

/* k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2610,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 550  pack-copy */
f_2457(t3,lf[67],lf[123]);}

/* k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2614,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 551  pack-copy */
f_2457(t3,lf[69],lf[124]);}

/* k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2618,2,t0,t1);}
t2=C_mutate((C_word*)lf[124]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 552  pack-copy */
f_2457(t3,lf[71],lf[125]);}

/* k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2622,2,t0,t1);}
t2=C_mutate((C_word*)lf[125]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 553  pack-copy */
f_2457(t3,lf[73],lf[126]);}

/* k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
t2=C_mutate((C_word*)lf[126]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 554  pack-copy */
f_2457(t3,lf[75],lf[127]);}

/* k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2630,2,t0,t1);}
t2=C_mutate((C_word*)lf[127]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 556  unpack */
f_2475(t3,lf[60],C_SCHEME_TRUE,lf[128]);}

/* k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
t2=C_mutate((C_word*)lf[128]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 557  unpack */
f_2475(t3,lf[62],C_SCHEME_TRUE,lf[129]);}

/* k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=C_mutate((C_word*)lf[129]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 558  unpack */
f_2475(t3,lf[65],C_fix(2),lf[130]);}

/* k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 559  unpack */
f_2475(t3,lf[67],C_fix(2),lf[131]);}

/* k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=C_mutate((C_word*)lf[131]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 560  unpack */
f_2475(t3,lf[69],C_fix(4),lf[132]);}

/* k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=C_mutate((C_word*)lf[132]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 561  unpack */
f_2475(t3,lf[71],C_fix(4),lf[133]);}

/* k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2654,2,t0,t1);}
t2=C_mutate((C_word*)lf[133]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 562  unpack */
f_2475(t3,lf[73],C_fix(4),lf[134]);}

/* k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=C_mutate((C_word*)lf[134]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 563  unpack */
f_2475(t3,lf[75],C_fix(8),lf[135]);}

/* k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=C_mutate((C_word*)lf[135]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 565  unpack */
f_2475(t3,lf[60],C_SCHEME_TRUE,lf[136]);}

/* k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=C_mutate((C_word*)lf[136]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 566  unpack */
f_2475(t3,lf[62],C_SCHEME_TRUE,lf[137]);}

/* k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=C_mutate((C_word*)lf[137]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 567  unpack */
f_2475(t3,lf[65],C_fix(2),lf[138]);}

/* k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2674,2,t0,t1);}
t2=C_mutate((C_word*)lf[138]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 568  unpack */
f_2475(t3,lf[67],C_fix(2),lf[139]);}

/* k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=C_mutate((C_word*)lf[139]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 569  unpack */
f_2475(t3,lf[69],C_fix(4),lf[140]);}

/* k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=C_mutate((C_word*)lf[140]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 570  unpack */
f_2475(t3,lf[71],C_fix(4),lf[141]);}

/* k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2686,2,t0,t1);}
t2=C_mutate((C_word*)lf[141]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 571  unpack */
f_2475(t3,lf[73],C_fix(4),lf[142]);}

/* k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2690,2,t0,t1);}
t2=C_mutate((C_word*)lf[142]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 572  unpack */
f_2475(t3,lf[75],C_fix(8),lf[143]);}

/* k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2694,2,t0,t1);}
t2=C_mutate((C_word*)lf[143]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 574  unpack-copy */
f_2504(t3,lf[60],C_SCHEME_TRUE,lf[144]);}

/* k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2698,2,t0,t1);}
t2=C_mutate((C_word*)lf[144]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 575  unpack-copy */
f_2504(t3,lf[62],C_SCHEME_TRUE,lf[145]);}

/* k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2702,2,t0,t1);}
t2=C_mutate((C_word*)lf[145]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 576  unpack-copy */
f_2504(t3,lf[65],C_fix(2),lf[146]);}

/* k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2706,2,t0,t1);}
t2=C_mutate((C_word*)lf[146]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 577  unpack-copy */
f_2504(t3,lf[67],C_fix(2),lf[147]);}

/* k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2710,2,t0,t1);}
t2=C_mutate((C_word*)lf[147]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 578  unpack-copy */
f_2504(t3,lf[69],C_fix(4),lf[148]);}

/* k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2714,2,t0,t1);}
t2=C_mutate((C_word*)lf[148]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 579  unpack-copy */
f_2504(t3,lf[71],C_fix(4),lf[149]);}

/* k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=C_mutate((C_word*)lf[149]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 580  unpack-copy */
f_2504(t3,lf[73],C_fix(4),lf[150]);}

/* k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2722,2,t0,t1);}
t2=C_mutate((C_word*)lf[150]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2726,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 581  unpack-copy */
f_2504(t3,lf[75],C_fix(8),lf[151]);}

/* k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[103],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2726,2,t0,t1);}
t2=C_mutate((C_word*)lf[151]+1,t1);
t3=*((C_word*)lf[152]+1);
t4=*((C_word*)lf[153]+1);
t5=(C_word)C_a_i_list(&a,16,lf[154],*((C_word*)lf[77]+1),lf[155],*((C_word*)lf[78]+1),lf[156],*((C_word*)lf[79]+1),lf[157],*((C_word*)lf[80]+1),lf[158],*((C_word*)lf[81]+1),lf[159],*((C_word*)lf[82]+1),lf[160],*((C_word*)lf[83]+1),lf[161],*((C_word*)lf[84]+1));
t6=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2731,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word)li111),tmp=(C_word)a,a+=6,tmp));
t7=*((C_word*)lf[166]+1);
t8=C_mutate((C_word*)lf[166]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2787,a[2]=t7,a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate(&lf[168],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2855,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[169]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2898,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[170]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2904,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[171]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2910,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2916,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[173]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2922,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[174]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2928,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[175]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2934,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2940,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[177]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2946,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[181]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3062,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t20=*((C_word*)lf[184]+1);
t21=*((C_word*)lf[185]+1);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3163,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp);
t23=C_mutate((C_word*)lf[186]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3172,a[2]=t20,a[3]=t21,a[4]=t22,a[5]=((C_word)li137),tmp=(C_word)a,a+=6,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 703  register-feature! */
t25=*((C_word*)lf[189]+1);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,lf[190]);}

/* k3288 in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* read-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr2r,(void*)f_3172r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3172r(t0,t1,t2);}}

static void C_ccall f_3172r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(14);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li134),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3236,a[2]=t3,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3241,a[2]=t4,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n761781 */
t6=t5;
f_3241(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-p762779 */
t8=t4;
f_3236(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body759764 */
t10=t3;
f_3174(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-n761 in read-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3241(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3241,NULL,2,t0,t1);}
/* def-p762779 */
t2=((C_word*)t0)[2];
f_3236(t2,t1,C_SCHEME_FALSE);}

/* def-p762 in read-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3236(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3236,NULL,3,t0,t1,t2);}
/* body759764 */
t3=((C_word*)t0)[2];
f_3174(t3,t1,t2,*((C_word*)lf[183]+1));}

/* body759 in read-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3174(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3174,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 683  ##sys#check-port */
t5=*((C_word*)lf[179]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[186]);}

/* k3176 in body759 in read-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3178,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],lf[186]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3187,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 685  ##sys#allocate-vector */
t4=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[7],C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3205,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 692  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k3203 in k3176 in body759 in read-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3205,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3210,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li133),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3210(t5,((C_word*)t0)[2]);}

/* loop in k3203 in k3176 in body759 in read-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3210,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 694  ##sys#read-char-0 */
t3=*((C_word*)lf[188]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3212 in loop in k3203 in k3176 in body759 in read-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 696  get-output-string */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3232,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 700  ##sys#write-char/port */
t3=*((C_word*)lf[187]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[3]);}}

/* k3230 in k3212 in loop in k3203 in k3176 in body759 in read-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 701  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3210(t2,((C_word*)t0)[2]);}

/* k3221 in k3212 in loop in k3203 in k3176 in body759 in read-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(t1);
/* srfi-4.scm: 698  wrap */
f_3163(((C_word*)t0)[2],t1,t2);}

/* k3185 in k3176 in body759 in read-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 686  ##sys#read-string! */
t3=*((C_word*)lf[182]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],t1,((C_word*)t0)[2],C_fix(0));}

/* k3188 in k3185 in k3176 in body759 in read-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3190,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[60],((C_word*)t0)[5]));}
else{
/* srfi-4.scm: 690  wrap */
f_3163(((C_word*)t0)[3],((C_word*)t0)[5],t1);}}

/* wrap in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3163(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3163,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3171,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 678  ##sys#allocate-vector */
t5=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3169 in wrap in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3171,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_substring_copy(((C_word*)t0)[4],t1,C_fix(0),((C_word*)t0)[3],C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[60],t1));}

/* read-u8vector! in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_3062r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3062r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3062r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(15);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3064,a[2]=t5,a[3]=t3,a[4]=((C_word)li128),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3109,a[2]=t6,a[3]=((C_word)li129),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3114,a[2]=t7,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port728742 */
t9=t8;
f_3114(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start729740 */
t11=t7;
f_3109(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body726731 */
t13=t6;
f_3064(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-port728 in read-u8vector! in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3114(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3114,NULL,2,t0,t1);}
/* def-start729740 */
t2=((C_word*)t0)[2];
f_3109(t2,t1,*((C_word*)lf[183]+1));}

/* def-start729 in read-u8vector! in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3109(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3109,NULL,3,t0,t1,t2);}
/* body726731 */
t3=((C_word*)t0)[2];
f_3064(t3,t1,t2,C_fix(0));}

/* body726 in read-u8vector! in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3064(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3064,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3068,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 662  ##sys#check-port */
t5=*((C_word*)lf[179]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[181]);}

/* k3066 in body726 in read-u8vector! in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3068,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[181]);
t3=(C_word)C_i_check_structure_2(((C_word*)t0)[5],lf[60],lf[181]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3080,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[3])[1],lf[181]);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_word)C_block_size(t4);
if(C_truep((C_word)C_fixnum_greaterp(t7,t8))){
t9=(C_word)C_block_size(t4);
t10=(C_word)C_fixnum_difference(t9,((C_word*)t0)[6]);
t11=C_mutate(((C_word *)((C_word*)t0)[3])+1,t10);
t12=t5;
f_3080(t12,t11);}
else{
t9=t5;
f_3080(t9,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_3080(t6,C_SCHEME_UNDEFINED);}}

/* k3078 in k3066 in body726 in read-u8vector! in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_3080(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 670  ##sys#read-string! */
t2=*((C_word*)lf[182]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_2946r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2946r(t0,t1,t2,t3);}}

static void C_ccall f_2946r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2948,a[2]=t2,a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2985,a[2]=t2,a[3]=t4,a[4]=((C_word)li124),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2994,a[2]=t5,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2999,a[2]=t6,a[3]=((C_word)li126),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-port692713 */
t8=t7;
f_2999(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-from693711 */
t10=t6;
f_2994(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-to694708 */
t12=t5;
f_2985(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body690696 */
t14=t4;
f_2948(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-port692 in write-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2999(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2999,NULL,2,t0,t1);}
/* def-from693711 */
t2=((C_word*)t0)[2];
f_2994(t2,t1,*((C_word*)lf[180]+1));}

/* def-from693 in write-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2994(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2994,NULL,3,t0,t1,t2);}
/* def-to694708 */
t3=((C_word*)t0)[2];
f_2985(t3,t1,t2,C_fix(0));}

/* def-to694 in write-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2985(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2985,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2993,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 653  u8vector-length */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k2991 in def-to694 in write-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body690696 */
t2=((C_word*)t0)[5];
f_2948(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body690 in write-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2948(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2948,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(((C_word*)t0)[2],lf[60],lf[177]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2955,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 655  ##sys#check-port */
t7=*((C_word*)lf[179]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,lf[177]);}

/* k2953 in body690 in write-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2955,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word)li122),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2963(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* do701 in k2953 in body690 in write-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2963(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2963,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2973,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_make_character((C_word)C_unfix((C_word)C_u8peek(((C_word*)t0)[3],t2)));
/* srfi-4.scm: 659  ##sys#write-char-0 */
t5=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* k2971 in do701 in k2953 in body690 in write-u8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2963(t3,((C_word*)t0)[2],t2);}

/* subf64vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2940,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 651  subvector */
f_2855(t1,t2,lf[75],C_fix(8),t3,t4,lf[176]);}

/* subf32vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2934,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 650  subvector */
f_2855(t1,t2,lf[73],C_fix(4),t3,t4,lf[175]);}

/* subs32vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2928,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 649  subvector */
f_2855(t1,t2,lf[71],C_fix(4),t3,t4,lf[174]);}

/* subs16vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2922,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 648  subvector */
f_2855(t1,t2,lf[67],C_fix(2),t3,t4,lf[173]);}

/* subs8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2916,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 647  subvector */
f_2855(t1,t2,lf[62],C_fix(1),t3,t4,lf[172]);}

/* subu32vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2910,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 646  subvector */
f_2855(t1,t2,lf[69],C_fix(4),t3,t4,lf[171]);}

/* subu16vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2904,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 645  subvector */
f_2855(t1,t2,lf[65],C_fix(2),t3,t4,lf[170]);}

/* subu8vector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2898,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 644  subvector */
f_2855(t1,t2,lf[60],C_fix(1),t3,t4,lf[169]);}

/* subvector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2855(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2855,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(C_word)C_i_check_structure_2(t2,t3,t7);
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_block_size(t9);
t11=(C_word)C_fixnum_divide(t10,t4);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2868,a[2]=t7,a[3]=t11,a[4]=t1,a[5]=t9,a[6]=t3,a[7]=t4,a[8]=t5,a[9]=t6,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_fixnum_plus(t11,C_fix(1));
/* srfi-4.scm: 635  ##sys#check-range */
t14=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t12,t5,C_fix(0),t13,t7);}

/* k2866 in subvector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 636  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[9],C_fix(0),t3,((C_word*)t0)[2]);}

/* k2869 in k2866 in subvector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_fixnum_times(((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 638  ##sys#allocate-vector */
t5=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2875 in k2869 in k2866 in subvector in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_a_i_record(&a,2,((C_word*)t0)[7],t1);
t4=(C_word)C_fixnum_times(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_copy_subvector(t1,((C_word*)t0)[4],C_fix(0),t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* ##sys#user-print-hook in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[102],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2787,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,3,lf[60],lf[154],*((C_word*)lf[85]+1));
t6=(C_word)C_a_i_list(&a,3,lf[62],lf[155],*((C_word*)lf[86]+1));
t7=(C_word)C_a_i_list(&a,3,lf[65],lf[156],*((C_word*)lf[87]+1));
t8=(C_word)C_a_i_list(&a,3,lf[67],lf[157],*((C_word*)lf[88]+1));
t9=(C_word)C_a_i_list(&a,3,lf[69],lf[158],*((C_word*)lf[89]+1));
t10=(C_word)C_a_i_list(&a,3,lf[71],lf[159],*((C_word*)lf[90]+1));
t11=(C_word)C_a_i_list(&a,3,lf[73],lf[160],*((C_word*)lf[91]+1));
t12=(C_word)C_a_i_list(&a,3,lf[75],lf[161],*((C_word*)lf[92]+1));
t13=(C_word)C_a_i_list(&a,8,t5,t6,t7,t8,t9,t10,t11,t12);
t14=(C_word)C_i_assq((C_word)C_slot(t2,C_fix(0)),t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2797,a[2]=t2,a[3]=t14,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 622  ##sys#print */
t16=*((C_word*)lf[167]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t15,C_make_character(35),C_SCHEME_FALSE,t4);}
else{
/* srfi-4.scm: 625  old-hook */
t15=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t15))(5,t15,t1,t2,t3,t4);}}

/* k2795 in ##sys#user-print-hook in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* srfi-4.scm: 623  ##sys#print */
t4=*((C_word*)lf[167]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k2798 in k2795 in ##sys#user-print-hook in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2807,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,((C_word*)t0)[2]);}

/* k2805 in k2798 in k2795 in ##sys#user-print-hook in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 624  ##sys#print */
t2=*((C_word*)lf[167]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2731,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2741,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 599  read */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
/* srfi-4.scm: 604  old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k2739 in ##sys#user-read-hook in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2741,2,t0,t1);}
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=(C_word)C_eqp(t3,lf[162]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[163]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_memq(t3,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 602  read */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 603  ##sys#read-error */
t7=*((C_word*)lf[164]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,((C_word*)t0)[5],((C_word*)t0)[2],lf[165],t3);}}}

/* k2764 in k2739 in ##sys#user-read-hook in k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2696 in k2692 in k2688 in k2684 in k2680 in k2676 in k2672 in k2668 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t1);}

/* unpack-copy in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2504(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2504,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2506,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li109),tmp=(C_word)a,a+=6,tmp));}

/* f_2506 in unpack-copy in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2506,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2516,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 521  ##sys#make-blob */
t6=*((C_word*)lf[101]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2514 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2516,2,t0,t1);}
t2=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(((C_word*)t0)[6],((C_word*)t0)[7])));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,((C_word*)t0)[4],(C_word)C_copy_block(((C_word*)t0)[3],t1)));}
else{
/* srfi-4.scm: 527  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[5],((C_word*)t0)[2],lf[103],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* unpack in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2475(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2475,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2477,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li107),tmp=(C_word)a,a+=6,tmp));}

/* f_2477 in unpack in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2477,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(t4,((C_word*)t0)[3])));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,2,((C_word*)t0)[2],t2));}
else{
/* srfi-4.scm: 515  ##sys#error */
t7=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,((C_word*)t0)[4],lf[102],((C_word*)t0)[2],t4,((C_word*)t0)[3]);}}

/* pack-copy in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2457(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2457,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2459,a[2]=t3,a[3]=t2,a[4]=((C_word)li105),tmp=(C_word)a,a+=5,tmp));}

/* f_2459 in pack-copy in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2459,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2469,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_block_size(t4);
/* srfi-4.scm: 505  ##sys#make-blob */
t7=*((C_word*)lf[101]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* k2467 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_copy_block(((C_word*)t0)[2],t1));}

/* pack in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2446(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2446,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2448,a[2]=t3,a[3]=t2,a[4]=((C_word)li103),tmp=(C_word)a,a+=5,tmp));}

/* f_2448 in pack in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2448,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f64vector? in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2440,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[75]));}

/* f32vector? in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2434,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[73]));}

/* s32vector? in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2428,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[71]));}

/* u32vector? in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2422,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[69]));}

/* s16vector? in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2416,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[67]));}

/* u16vector? in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2410,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[65]));}

/* s8vector? in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2404,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[62]));}

/* u8vector? in k2394 in k2390 in k2386 in k2382 in k2378 in k2374 in k2370 in k2366 in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2398,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[60]));}

/* init in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2331(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2331,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2333,a[2]=t2,a[3]=t3,a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));}

/* f_2333 in init in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2333,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2337,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 463  length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2335 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2342,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li92),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2342(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2335 */
static void C_fcall f_2342(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2342,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2356,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 467  ref */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}}

/* k2354 in loop in k2335 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2360,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 468  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2342(t4,t2,t3);}

/* k2358 in k2354 in loop in k2335 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f64vector in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2325r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2325r(t0,t1,t2);}}

static void C_ccall f_2325r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 454  list->f64vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* f32vector in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2319r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2319r(t0,t1,t2);}}

static void C_ccall f_2319r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 450  list->f32vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s32vector in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2313r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2313r(t0,t1,t2);}}

static void C_ccall f_2313r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 446  list->s32vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u32vector in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2307r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2307r(t0,t1,t2);}}

static void C_ccall f_2307r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 442  list->u32vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s16vector in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2301r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2301r(t0,t1,t2);}}

static void C_ccall f_2301r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 438  list->s16vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u16vector in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2295(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2295r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2295r(t0,t1,t2);}}

static void C_ccall f_2295r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 434  list->u16vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s8vector in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2289r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2289r(t0,t1,t2);}}

static void C_ccall f_2289r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 430  list->s8vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u8vector in k2279 in k2275 in k2271 in k2267 in k2263 in k2259 in k2255 in k2251 in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2283r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2283r(t0,t1,t2);}}

static void C_ccall f_2283r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 426  list->u8vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* init in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2213(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2213,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2215,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));}

/* f_2215 in init in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2215,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2225,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 404  make */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2223 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li81),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2230(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do486 in k2223 */
static void C_fcall f_2230(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2230,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2237,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* srfi-4.scm: 409  set */
t6=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[5],t3,(C_word)C_slot(t2,C_fix(0)));}
else{
/* srfi-4.scm: 410  ##sys#not-a-proper-list-error */
t6=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}}

/* k2235 in do486 in k2223 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2230(t2,((C_word*)t0)[4],(C_word)C_slot(((C_word*)t0)[3],C_fix(1)),(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_2086r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2086r(t0,t1,t2,t3);}}

static void C_ccall f_2086r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li76),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2140,a[2]=t4,a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2145,a[2]=t5,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2150,a[2]=t6,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init441464 */
t8=t7;
f_2150(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?442462 */
t10=t6;
f_2145(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin443459 */
t12=t5;
f_2140(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body439445 */
t14=t4;
f_2088(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init441 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2150,NULL,2,t0,t1);}
/* def-ext?442462 */
t2=((C_word*)t0)[2];
f_2145(t2,t1,C_SCHEME_FALSE);}

/* def-ext?442 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2145(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2145,NULL,3,t0,t1,t2);}
/* def-fin443459 */
t3=((C_word*)t0)[2];
f_2140(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin443 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2140(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2140,NULL,4,t0,t1,t2,t3);}
/* body439445 */
t4=((C_word*)t0)[2];
f_2088(t4,t1,t2,t3);}

/* body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2088(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2088,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[74]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 383  alloc */
f_1196(t6,lf[74],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(3)),t3);}

/* k2137 in body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2139,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[75],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 384  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2098(2,t5,C_SCHEME_UNDEFINED);}}

/* k2096 in k2137 in body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[74]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2110(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2129,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 390  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2127 in k2096 in k2137 in body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2110(t3,t2);}

/* k2108 in k2096 in k2137 in body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2110,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2115,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li75),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2115(t5,((C_word*)t0)[2],C_fix(0));}

/* do450 in k2108 in k2096 in k2137 in body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2115(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2115,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2122,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 393  ##sys#f64vector-set! */
t4=lf[23];
f_935(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k2120 in do450 in k2108 in k2096 in k2137 in body439 in make-f64vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2115(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1959r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1959r(t0,t1,t2,t3);}}

static void C_ccall f_1959r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li70),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2013,a[2]=t4,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2018,a[2]=t5,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2023,a[2]=t6,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init403426 */
t8=t7;
f_2023(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?404424 */
t10=t6;
f_2018(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin405421 */
t12=t5;
f_2013(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body401407 */
t14=t4;
f_1961(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init403 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2023(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2023,NULL,2,t0,t1);}
/* def-ext?404424 */
t2=((C_word*)t0)[2];
f_2018(t2,t1,C_SCHEME_FALSE);}

/* def-ext?404 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2018(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2018,NULL,3,t0,t1,t2);}
/* def-fin405421 */
t3=((C_word*)t0)[2];
f_2013(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin405 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_2013(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2013,NULL,4,t0,t1,t2,t3);}
/* body401407 */
t4=((C_word*)t0)[2];
f_1961(t4,t1,t2,t3);}

/* body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1961(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1961,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[72]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 368  alloc */
f_1196(t6,lf[72],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2010 in body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 369  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1971(2,t5,C_SCHEME_UNDEFINED);}}

/* k1969 in k2010 in body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1971,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[72]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_1983(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2002,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 375  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2000 in k1969 in k2010 in body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1983(t3,t2);}

/* k1981 in k1969 in k2010 in body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1983(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1983,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li69),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1988(t5,((C_word*)t0)[2],C_fix(0));}

/* do412 in k1981 in k1969 in k2010 in body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1988(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1988,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1995,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 378  ##sys#f32vector-set! */
t4=lf[22];
f_932(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k1993 in do412 in k1981 in k1969 in k2010 in body401 in make-f32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1988(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1839r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1839r(t0,t1,t2,t3);}}

static void C_ccall f_1839r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li64),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1886,a[2]=t4,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1891,a[2]=t5,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1896,a[2]=t6,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init366388 */
t8=t7;
f_1896(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?367386 */
t10=t6;
f_1891(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin368383 */
t12=t5;
f_1886(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body364370 */
t14=t4;
f_1841(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init366 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1896,NULL,2,t0,t1);}
/* def-ext?367386 */
t2=((C_word*)t0)[2];
f_1891(t2,t1,C_SCHEME_FALSE);}

/* def-ext?367 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1891(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1891,NULL,3,t0,t1,t2);}
/* def-fin368383 */
t3=((C_word*)t0)[2];
f_1886(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin368 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1886(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1886,NULL,4,t0,t1,t2,t3);}
/* body364370 */
t4=((C_word*)t0)[2];
f_1841(t4,t1,t2,t3);}

/* body364 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1841(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1841,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 355  alloc */
f_1196(t5,lf[70],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1883 in body364 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[71],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 356  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1851(2,t5,C_SCHEME_UNDEFINED);}}

/* k1849 in k1883 in body364 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1865,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1865(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* do375 in k1849 in k1883 in body364 in make-s32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static C_word C_fcall f_1865(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_929(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1719r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1719r(t0,t1,t2,t3);}}

static void C_ccall f_1719r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1766,a[2]=t4,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1771,a[2]=t5,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1776,a[2]=t6,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init329351 */
t8=t7;
f_1776(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?330349 */
t10=t6;
f_1771(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin331346 */
t12=t5;
f_1766(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body327333 */
t14=t4;
f_1721(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init329 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1776,NULL,2,t0,t1);}
/* def-ext?330349 */
t2=((C_word*)t0)[2];
f_1771(t2,t1,C_SCHEME_FALSE);}

/* def-ext?330 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1771(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1771,NULL,3,t0,t1,t2);}
/* def-fin331346 */
t3=((C_word*)t0)[2];
f_1766(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin331 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1766(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1766,NULL,4,t0,t1,t2,t3);}
/* body327333 */
t4=((C_word*)t0)[2];
f_1721(t4,t1,t2,t3);}

/* body327 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1721(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1721,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 342  alloc */
f_1196(t5,lf[68],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1763 in body327 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[69],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1731,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 343  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1731(2,t5,C_SCHEME_UNDEFINED);}}

/* k1729 in k1763 in body327 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1731,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1745(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* do338 in k1729 in k1763 in body327 in make-u32vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static C_word C_fcall f_1745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_926(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1599r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1599r(t0,t1,t2,t3);}}

static void C_ccall f_1599r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li52),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1646,a[2]=t4,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1651,a[2]=t5,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1656,a[2]=t6,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init292314 */
t8=t7;
f_1656(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?293312 */
t10=t6;
f_1651(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin294309 */
t12=t5;
f_1646(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body290296 */
t14=t4;
f_1601(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init292 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1656(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1656,NULL,2,t0,t1);}
/* def-ext?293312 */
t2=((C_word*)t0)[2];
f_1651(t2,t1,C_SCHEME_FALSE);}

/* def-ext?293 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1651(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1651,NULL,3,t0,t1,t2);}
/* def-fin294309 */
t3=((C_word*)t0)[2];
f_1646(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin294 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1646(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1646,NULL,4,t0,t1,t2,t3);}
/* body290296 */
t4=((C_word*)t0)[2];
f_1601(t4,t1,t2,t3);}

/* body290 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1601(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1601,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[66]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 329  alloc */
f_1196(t5,lf[66],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1643 in body290 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[67],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 330  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1611(2,t5,C_SCHEME_UNDEFINED);}}

/* k1609 in k1643 in body290 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1611,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 334  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-32768),C_fix(32767),lf[66]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1618 in k1609 in k1643 in body290 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1620,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li51),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1625(t5,((C_word*)t0)[2],C_fix(0));}

/* do301 in k1618 in k1609 in k1643 in body290 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1625(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1625,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1632,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 337  ##sys#s16vector-set! */
t4=lf[19];
f_923(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1630 in do301 in k1618 in k1609 in k1643 in body290 in make-s16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1625(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1479(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1479r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1479r(t0,t1,t2,t3);}}

static void C_ccall f_1479r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li46),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1526,a[2]=t4,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1531,a[2]=t5,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1536,a[2]=t6,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init255277 */
t8=t7;
f_1536(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?256275 */
t10=t6;
f_1531(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin257272 */
t12=t5;
f_1526(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body253259 */
t14=t4;
f_1481(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init255 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1536,NULL,2,t0,t1);}
/* def-ext?256275 */
t2=((C_word*)t0)[2];
f_1531(t2,t1,C_SCHEME_FALSE);}

/* def-ext?256 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1531(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1531,NULL,3,t0,t1,t2);}
/* def-fin257272 */
t3=((C_word*)t0)[2];
f_1526(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin257 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1526(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1526,NULL,4,t0,t1,t2,t3);}
/* body253259 */
t4=((C_word*)t0)[2];
f_1481(t4,t1,t2,t3);}

/* body253 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1481(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1481,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[64]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 316  alloc */
f_1196(t5,lf[64],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1523 in body253 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1525,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[65],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 317  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1491(2,t5,C_SCHEME_UNDEFINED);}}

/* k1489 in k1523 in body253 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1491,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 321  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(65535),lf[64]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1498 in k1489 in k1523 in body253 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1500,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li45),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1505(t5,((C_word*)t0)[2],C_fix(0));}

/* do264 in k1498 in k1489 in k1523 in body253 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1505(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1505,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1512,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 324  ##sys#u16vector-set! */
t4=lf[18];
f_920(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1510 in do264 in k1498 in k1489 in k1523 in body253 in make-u16vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1505(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1359(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1359r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1359r(t0,t1,t2,t3);}}

static void C_ccall f_1359r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li40),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1406,a[2]=t4,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1411,a[2]=t5,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1416,a[2]=t6,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init218240 */
t8=t7;
f_1416(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?219238 */
t10=t6;
f_1411(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin220235 */
t12=t5;
f_1406(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body216222 */
t14=t4;
f_1361(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init218 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1416,NULL,2,t0,t1);}
/* def-ext?219238 */
t2=((C_word*)t0)[2];
f_1411(t2,t1,C_SCHEME_FALSE);}

/* def-ext?219 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1411(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1411,NULL,3,t0,t1,t2);}
/* def-fin220235 */
t3=((C_word*)t0)[2];
f_1406(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin220 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1406(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1406,NULL,4,t0,t1,t2,t3);}
/* body216222 */
t4=((C_word*)t0)[2];
f_1361(t4,t1,t2,t3);}

/* body216 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1361(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1361,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[61]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 303  alloc */
f_1196(t5,lf[61],((C_word*)t0)[5],t3);}

/* k1403 in body216 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1405,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[62],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1371,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 304  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1371(2,t5,C_SCHEME_UNDEFINED);}}

/* k1369 in k1403 in body216 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1371,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 308  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-128),C_fix(127),lf[61]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1378 in k1369 in k1403 in body216 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1380,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1385,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1385(t5,((C_word*)t0)[2],C_fix(0));}

/* do227 in k1378 in k1369 in k1403 in body216 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1385(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1385,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1392,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 311  ##sys#s8vector-set! */
t4=lf[17];
f_917(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1390 in do227 in k1378 in k1369 in k1403 in body216 in make-s8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1385(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1239r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1239r(t0,t1,t2,t3);}}

static void C_ccall f_1239r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li34),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1286,a[2]=t4,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1291,a[2]=t5,a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1296,a[2]=t6,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init180202 */
t8=t7;
f_1296(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?181200 */
t10=t6;
f_1291(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin?182197 */
t12=t5;
f_1286(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body178184 */
t14=t4;
f_1241(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init180 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1296(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1296,NULL,2,t0,t1);}
/* def-ext?181200 */
t2=((C_word*)t0)[2];
f_1291(t2,t1,C_SCHEME_FALSE);}

/* def-ext?181 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1291(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1291,NULL,3,t0,t1,t2);}
/* def-fin?182197 */
t3=((C_word*)t0)[2];
f_1286(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin?182 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1286(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1286,NULL,4,t0,t1,t2,t3);}
/* body178184 */
t4=((C_word*)t0)[2];
f_1241(t4,t1,t2,t3,C_SCHEME_TRUE);}

/* body178 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1241(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1241,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[59]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* srfi-4.scm: 290  alloc */
f_1196(t6,lf[59],((C_word*)t0)[5],t3);}

/* k1283 in body178 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[60],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1251,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 291  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1251(2,t5,C_SCHEME_UNDEFINED);}}

/* k1249 in k1283 in body178 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1251,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 295  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(255),lf[59]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1258 in k1249 in k1283 in body178 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1260,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1265,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li33),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1265(t5,((C_word*)t0)[2],C_fix(0));}

/* do189 in k1258 in k1249 in k1283 in body178 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1265(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1265,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1272,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 298  ##sys#u8vector-set! */
t4=lf[16];
f_914(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1270 in do189 in k1258 in k1249 in k1283 in body178 in make-u8vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1265(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* release-number-vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1214,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1221,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1221(t5,(C_word)C_i_memq(t4,lf[58]));}
else{
t4=t3;
f_1221(t4,C_SCHEME_FALSE);}}

/* k1219 in release-number-vector in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1221(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-4.scm: 284  ext-free */
t2=((C_word*)t0)[4];
f_1194(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 285  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[56],lf[57],((C_word*)t0)[2]);}}

/* alloc in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1196(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1196,NULL,4,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=t3;
t6=(C_word)C_i_foreign_fixnum_argumentp(t5);
t7=(C_word)stub153(C_SCHEME_UNDEFINED,t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* srfi-4.scm: 275  ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,lf[54],t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1212,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 276  ##sys#allocate-vector */
t6=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}}

/* k1210 in alloc in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_string_to_bytevector(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* ext-free in k1185 in k1181 in k1177 in k1173 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1194(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1194,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub158(C_SCHEME_UNDEFINED,t2));}

/* f_1040 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1040,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1044,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 193  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1042 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1047,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fits_in_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1047(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 195  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[41],lf[42],((C_word*)t0)[2]);}}

/* k1045 in k1042 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 196  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[41]);}

/* k1048 in k1045 in k1042 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 197  upd */
t2=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_929(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* f_1067 in k1137 in k1133 in k1129 in k1125 in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1067,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1071,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 201  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1069 */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1074,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_negativep(((C_word*)t0)[2]))){
/* srfi-4.scm: 203  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],lf[39],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_fits_in_unsigned_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1074(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 205  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],lf[40],((C_word*)t0)[2]);}}}

/* k1072 in k1069 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1077,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 206  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[38]);}

/* k1075 in k1072 in k1069 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 207  upd */
t2=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_926(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* setf in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1101(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1101,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1103,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp));}

/* f_1103 in setf in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1103,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1107,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 211  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1105 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1107,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1113,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 213  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1111 in k1105 */
static void C_ccall f_1113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)t0)[2]))){
t3=t2;
f_1120(2,t3,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 216  exact->inexact */
C_exact_to_inexact(3,0,t2,((C_word*)t0)[2]);}}

/* k1118 in k1111 in k1105 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 214  upd */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setu in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_1012(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1012,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1014,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp));}

/* f_1014 in setu in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1014,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1018,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 184  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1016 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1018,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[7],C_fix(0)))){
/* srfi-4.scm: 187  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[6],lf[33],((C_word*)t0)[7]);}
else{
t4=t3;
f_1024(2,t4,C_SCHEME_UNDEFINED);}}

/* k1022 in k1016 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 188  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1025 in k1022 in k1016 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 189  upd */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_995(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_995,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_997,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li22),tmp=(C_word)a,a+=6,tmp));}

/* f_997 in set in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_997,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1001,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 177  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k999 */
static void C_ccall f_1001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1001,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1007,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 179  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1005 in k999 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 180  upd */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* get in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_fcall f_981(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_981,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_983,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=((C_word)li20),tmp=(C_word)a,a+=6,tmp));}

/* f_983 in get in k977 in k973 in k969 in k965 in k961 in k957 in k953 in k949 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_983,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_987,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 171  length */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k985 */
static void C_ccall f_987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 172  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),t1,((C_word*)t0)[2]);}

/* k988 in k985 */
static void C_ccall f_990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 173  acc */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* len */
static void C_fcall f_938(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_938,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_940,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=((C_word)li18),tmp=(C_word)a,a+=6,tmp));}

/* f_940 in len */
static void C_ccall f_940(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_940,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_block_size((C_word)C_slot(t2,C_fix(1)));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_shift_right(t4,((C_word*)t0)[2]):t4));}

/* ##sys#f64vector-set! */
static void C_ccall f_935(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_935,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f64poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f32vector-set! */
static void C_ccall f_932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_932,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s32vector-set! */
static C_word C_fcall f_929(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_stack_check;
return((C_word)C_s32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#u32vector-set! */
static C_word C_fcall f_926(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_stack_check;
return((C_word)C_u32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#s16vector-set! */
static void C_ccall f_923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_923,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u16vector-set! */
static void C_ccall f_920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_920,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s8vector-set! */
static void C_ccall f_917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_917,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u8vector-set! */
static void C_ccall f_914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_914,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f64vector-ref */
static void C_ccall f_908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_908,4,t0,t1,t2,t3);}
t4=(C_word)C_f64peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 131  ##sys#cons-flonum */
t5=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#f32vector-ref */
static void C_ccall f_902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_902,4,t0,t1,t2,t3);}
t4=(C_word)C_f32peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 127  ##sys#cons-flonum */
t5=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#s32vector-ref */
static void C_ccall f_899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_899,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_s32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u32vector-ref */
static void C_ccall f_896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_896,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_u32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s16vector-ref */
static void C_ccall f_893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_893,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u16vector-ref */
static void C_ccall f_890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_890,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s8vector-ref */
static void C_ccall f_887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_887,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u8vector-ref */
static void C_ccall f_884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_884,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#check-inexact-interval */
static void C_ccall f_863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_863,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_number_2(t2,t5);
t7=(C_word)C_i_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_i_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 113  ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,lf[6],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* ##sys#check-exact-interval */
static void C_ccall f_848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_848,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_exact_2(t2,t5);
t7=(C_word)C_fixnum_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 107  ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t9+1)))(7,t9,t1,t5,lf[4],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[311] = {
{"toplevelsrfi-4.scm",(void*)C_srfi_4_toplevel},
{"f_951srfi-4.scm",(void*)f_951},
{"f_955srfi-4.scm",(void*)f_955},
{"f_959srfi-4.scm",(void*)f_959},
{"f_963srfi-4.scm",(void*)f_963},
{"f_967srfi-4.scm",(void*)f_967},
{"f_971srfi-4.scm",(void*)f_971},
{"f_975srfi-4.scm",(void*)f_975},
{"f_979srfi-4.scm",(void*)f_979},
{"f_1127srfi-4.scm",(void*)f_1127},
{"f_1131srfi-4.scm",(void*)f_1131},
{"f_1135srfi-4.scm",(void*)f_1135},
{"f_1139srfi-4.scm",(void*)f_1139},
{"f_1151srfi-4.scm",(void*)f_1151},
{"f_1155srfi-4.scm",(void*)f_1155},
{"f_3322srfi-4.scm",(void*)f_3322},
{"f_1159srfi-4.scm",(void*)f_1159},
{"f_3318srfi-4.scm",(void*)f_3318},
{"f_1163srfi-4.scm",(void*)f_1163},
{"f_3314srfi-4.scm",(void*)f_3314},
{"f_1167srfi-4.scm",(void*)f_1167},
{"f_3310srfi-4.scm",(void*)f_3310},
{"f_1171srfi-4.scm",(void*)f_1171},
{"f_3306srfi-4.scm",(void*)f_3306},
{"f_1175srfi-4.scm",(void*)f_1175},
{"f_3302srfi-4.scm",(void*)f_3302},
{"f_1179srfi-4.scm",(void*)f_1179},
{"f_3298srfi-4.scm",(void*)f_3298},
{"f_1183srfi-4.scm",(void*)f_1183},
{"f_3294srfi-4.scm",(void*)f_3294},
{"f_1187srfi-4.scm",(void*)f_1187},
{"f_2253srfi-4.scm",(void*)f_2253},
{"f_2257srfi-4.scm",(void*)f_2257},
{"f_2261srfi-4.scm",(void*)f_2261},
{"f_2265srfi-4.scm",(void*)f_2265},
{"f_2269srfi-4.scm",(void*)f_2269},
{"f_2273srfi-4.scm",(void*)f_2273},
{"f_2277srfi-4.scm",(void*)f_2277},
{"f_2281srfi-4.scm",(void*)f_2281},
{"f_2368srfi-4.scm",(void*)f_2368},
{"f_2372srfi-4.scm",(void*)f_2372},
{"f_2376srfi-4.scm",(void*)f_2376},
{"f_2380srfi-4.scm",(void*)f_2380},
{"f_2384srfi-4.scm",(void*)f_2384},
{"f_2388srfi-4.scm",(void*)f_2388},
{"f_2392srfi-4.scm",(void*)f_2392},
{"f_2396srfi-4.scm",(void*)f_2396},
{"f_2538srfi-4.scm",(void*)f_2538},
{"f_2542srfi-4.scm",(void*)f_2542},
{"f_2546srfi-4.scm",(void*)f_2546},
{"f_2550srfi-4.scm",(void*)f_2550},
{"f_2554srfi-4.scm",(void*)f_2554},
{"f_2558srfi-4.scm",(void*)f_2558},
{"f_2562srfi-4.scm",(void*)f_2562},
{"f_2566srfi-4.scm",(void*)f_2566},
{"f_2570srfi-4.scm",(void*)f_2570},
{"f_2574srfi-4.scm",(void*)f_2574},
{"f_2578srfi-4.scm",(void*)f_2578},
{"f_2582srfi-4.scm",(void*)f_2582},
{"f_2586srfi-4.scm",(void*)f_2586},
{"f_2590srfi-4.scm",(void*)f_2590},
{"f_2594srfi-4.scm",(void*)f_2594},
{"f_2598srfi-4.scm",(void*)f_2598},
{"f_2602srfi-4.scm",(void*)f_2602},
{"f_2606srfi-4.scm",(void*)f_2606},
{"f_2610srfi-4.scm",(void*)f_2610},
{"f_2614srfi-4.scm",(void*)f_2614},
{"f_2618srfi-4.scm",(void*)f_2618},
{"f_2622srfi-4.scm",(void*)f_2622},
{"f_2626srfi-4.scm",(void*)f_2626},
{"f_2630srfi-4.scm",(void*)f_2630},
{"f_2634srfi-4.scm",(void*)f_2634},
{"f_2638srfi-4.scm",(void*)f_2638},
{"f_2642srfi-4.scm",(void*)f_2642},
{"f_2646srfi-4.scm",(void*)f_2646},
{"f_2650srfi-4.scm",(void*)f_2650},
{"f_2654srfi-4.scm",(void*)f_2654},
{"f_2658srfi-4.scm",(void*)f_2658},
{"f_2662srfi-4.scm",(void*)f_2662},
{"f_2666srfi-4.scm",(void*)f_2666},
{"f_2670srfi-4.scm",(void*)f_2670},
{"f_2674srfi-4.scm",(void*)f_2674},
{"f_2678srfi-4.scm",(void*)f_2678},
{"f_2682srfi-4.scm",(void*)f_2682},
{"f_2686srfi-4.scm",(void*)f_2686},
{"f_2690srfi-4.scm",(void*)f_2690},
{"f_2694srfi-4.scm",(void*)f_2694},
{"f_2698srfi-4.scm",(void*)f_2698},
{"f_2702srfi-4.scm",(void*)f_2702},
{"f_2706srfi-4.scm",(void*)f_2706},
{"f_2710srfi-4.scm",(void*)f_2710},
{"f_2714srfi-4.scm",(void*)f_2714},
{"f_2718srfi-4.scm",(void*)f_2718},
{"f_2722srfi-4.scm",(void*)f_2722},
{"f_2726srfi-4.scm",(void*)f_2726},
{"f_3290srfi-4.scm",(void*)f_3290},
{"f_3172srfi-4.scm",(void*)f_3172},
{"f_3241srfi-4.scm",(void*)f_3241},
{"f_3236srfi-4.scm",(void*)f_3236},
{"f_3174srfi-4.scm",(void*)f_3174},
{"f_3178srfi-4.scm",(void*)f_3178},
{"f_3205srfi-4.scm",(void*)f_3205},
{"f_3210srfi-4.scm",(void*)f_3210},
{"f_3214srfi-4.scm",(void*)f_3214},
{"f_3232srfi-4.scm",(void*)f_3232},
{"f_3223srfi-4.scm",(void*)f_3223},
{"f_3187srfi-4.scm",(void*)f_3187},
{"f_3190srfi-4.scm",(void*)f_3190},
{"f_3163srfi-4.scm",(void*)f_3163},
{"f_3171srfi-4.scm",(void*)f_3171},
{"f_3062srfi-4.scm",(void*)f_3062},
{"f_3114srfi-4.scm",(void*)f_3114},
{"f_3109srfi-4.scm",(void*)f_3109},
{"f_3064srfi-4.scm",(void*)f_3064},
{"f_3068srfi-4.scm",(void*)f_3068},
{"f_3080srfi-4.scm",(void*)f_3080},
{"f_2946srfi-4.scm",(void*)f_2946},
{"f_2999srfi-4.scm",(void*)f_2999},
{"f_2994srfi-4.scm",(void*)f_2994},
{"f_2985srfi-4.scm",(void*)f_2985},
{"f_2993srfi-4.scm",(void*)f_2993},
{"f_2948srfi-4.scm",(void*)f_2948},
{"f_2955srfi-4.scm",(void*)f_2955},
{"f_2963srfi-4.scm",(void*)f_2963},
{"f_2973srfi-4.scm",(void*)f_2973},
{"f_2940srfi-4.scm",(void*)f_2940},
{"f_2934srfi-4.scm",(void*)f_2934},
{"f_2928srfi-4.scm",(void*)f_2928},
{"f_2922srfi-4.scm",(void*)f_2922},
{"f_2916srfi-4.scm",(void*)f_2916},
{"f_2910srfi-4.scm",(void*)f_2910},
{"f_2904srfi-4.scm",(void*)f_2904},
{"f_2898srfi-4.scm",(void*)f_2898},
{"f_2855srfi-4.scm",(void*)f_2855},
{"f_2868srfi-4.scm",(void*)f_2868},
{"f_2871srfi-4.scm",(void*)f_2871},
{"f_2877srfi-4.scm",(void*)f_2877},
{"f_2787srfi-4.scm",(void*)f_2787},
{"f_2797srfi-4.scm",(void*)f_2797},
{"f_2800srfi-4.scm",(void*)f_2800},
{"f_2807srfi-4.scm",(void*)f_2807},
{"f_2731srfi-4.scm",(void*)f_2731},
{"f_2741srfi-4.scm",(void*)f_2741},
{"f_2766srfi-4.scm",(void*)f_2766},
{"f_2504srfi-4.scm",(void*)f_2504},
{"f_2506srfi-4.scm",(void*)f_2506},
{"f_2516srfi-4.scm",(void*)f_2516},
{"f_2475srfi-4.scm",(void*)f_2475},
{"f_2477srfi-4.scm",(void*)f_2477},
{"f_2457srfi-4.scm",(void*)f_2457},
{"f_2459srfi-4.scm",(void*)f_2459},
{"f_2469srfi-4.scm",(void*)f_2469},
{"f_2446srfi-4.scm",(void*)f_2446},
{"f_2448srfi-4.scm",(void*)f_2448},
{"f_2440srfi-4.scm",(void*)f_2440},
{"f_2434srfi-4.scm",(void*)f_2434},
{"f_2428srfi-4.scm",(void*)f_2428},
{"f_2422srfi-4.scm",(void*)f_2422},
{"f_2416srfi-4.scm",(void*)f_2416},
{"f_2410srfi-4.scm",(void*)f_2410},
{"f_2404srfi-4.scm",(void*)f_2404},
{"f_2398srfi-4.scm",(void*)f_2398},
{"f_2331srfi-4.scm",(void*)f_2331},
{"f_2333srfi-4.scm",(void*)f_2333},
{"f_2337srfi-4.scm",(void*)f_2337},
{"f_2342srfi-4.scm",(void*)f_2342},
{"f_2356srfi-4.scm",(void*)f_2356},
{"f_2360srfi-4.scm",(void*)f_2360},
{"f_2325srfi-4.scm",(void*)f_2325},
{"f_2319srfi-4.scm",(void*)f_2319},
{"f_2313srfi-4.scm",(void*)f_2313},
{"f_2307srfi-4.scm",(void*)f_2307},
{"f_2301srfi-4.scm",(void*)f_2301},
{"f_2295srfi-4.scm",(void*)f_2295},
{"f_2289srfi-4.scm",(void*)f_2289},
{"f_2283srfi-4.scm",(void*)f_2283},
{"f_2213srfi-4.scm",(void*)f_2213},
{"f_2215srfi-4.scm",(void*)f_2215},
{"f_2225srfi-4.scm",(void*)f_2225},
{"f_2230srfi-4.scm",(void*)f_2230},
{"f_2237srfi-4.scm",(void*)f_2237},
{"f_2086srfi-4.scm",(void*)f_2086},
{"f_2150srfi-4.scm",(void*)f_2150},
{"f_2145srfi-4.scm",(void*)f_2145},
{"f_2140srfi-4.scm",(void*)f_2140},
{"f_2088srfi-4.scm",(void*)f_2088},
{"f_2139srfi-4.scm",(void*)f_2139},
{"f_2098srfi-4.scm",(void*)f_2098},
{"f_2129srfi-4.scm",(void*)f_2129},
{"f_2110srfi-4.scm",(void*)f_2110},
{"f_2115srfi-4.scm",(void*)f_2115},
{"f_2122srfi-4.scm",(void*)f_2122},
{"f_1959srfi-4.scm",(void*)f_1959},
{"f_2023srfi-4.scm",(void*)f_2023},
{"f_2018srfi-4.scm",(void*)f_2018},
{"f_2013srfi-4.scm",(void*)f_2013},
{"f_1961srfi-4.scm",(void*)f_1961},
{"f_2012srfi-4.scm",(void*)f_2012},
{"f_1971srfi-4.scm",(void*)f_1971},
{"f_2002srfi-4.scm",(void*)f_2002},
{"f_1983srfi-4.scm",(void*)f_1983},
{"f_1988srfi-4.scm",(void*)f_1988},
{"f_1995srfi-4.scm",(void*)f_1995},
{"f_1839srfi-4.scm",(void*)f_1839},
{"f_1896srfi-4.scm",(void*)f_1896},
{"f_1891srfi-4.scm",(void*)f_1891},
{"f_1886srfi-4.scm",(void*)f_1886},
{"f_1841srfi-4.scm",(void*)f_1841},
{"f_1885srfi-4.scm",(void*)f_1885},
{"f_1851srfi-4.scm",(void*)f_1851},
{"f_1865srfi-4.scm",(void*)f_1865},
{"f_1719srfi-4.scm",(void*)f_1719},
{"f_1776srfi-4.scm",(void*)f_1776},
{"f_1771srfi-4.scm",(void*)f_1771},
{"f_1766srfi-4.scm",(void*)f_1766},
{"f_1721srfi-4.scm",(void*)f_1721},
{"f_1765srfi-4.scm",(void*)f_1765},
{"f_1731srfi-4.scm",(void*)f_1731},
{"f_1745srfi-4.scm",(void*)f_1745},
{"f_1599srfi-4.scm",(void*)f_1599},
{"f_1656srfi-4.scm",(void*)f_1656},
{"f_1651srfi-4.scm",(void*)f_1651},
{"f_1646srfi-4.scm",(void*)f_1646},
{"f_1601srfi-4.scm",(void*)f_1601},
{"f_1645srfi-4.scm",(void*)f_1645},
{"f_1611srfi-4.scm",(void*)f_1611},
{"f_1620srfi-4.scm",(void*)f_1620},
{"f_1625srfi-4.scm",(void*)f_1625},
{"f_1632srfi-4.scm",(void*)f_1632},
{"f_1479srfi-4.scm",(void*)f_1479},
{"f_1536srfi-4.scm",(void*)f_1536},
{"f_1531srfi-4.scm",(void*)f_1531},
{"f_1526srfi-4.scm",(void*)f_1526},
{"f_1481srfi-4.scm",(void*)f_1481},
{"f_1525srfi-4.scm",(void*)f_1525},
{"f_1491srfi-4.scm",(void*)f_1491},
{"f_1500srfi-4.scm",(void*)f_1500},
{"f_1505srfi-4.scm",(void*)f_1505},
{"f_1512srfi-4.scm",(void*)f_1512},
{"f_1359srfi-4.scm",(void*)f_1359},
{"f_1416srfi-4.scm",(void*)f_1416},
{"f_1411srfi-4.scm",(void*)f_1411},
{"f_1406srfi-4.scm",(void*)f_1406},
{"f_1361srfi-4.scm",(void*)f_1361},
{"f_1405srfi-4.scm",(void*)f_1405},
{"f_1371srfi-4.scm",(void*)f_1371},
{"f_1380srfi-4.scm",(void*)f_1380},
{"f_1385srfi-4.scm",(void*)f_1385},
{"f_1392srfi-4.scm",(void*)f_1392},
{"f_1239srfi-4.scm",(void*)f_1239},
{"f_1296srfi-4.scm",(void*)f_1296},
{"f_1291srfi-4.scm",(void*)f_1291},
{"f_1286srfi-4.scm",(void*)f_1286},
{"f_1241srfi-4.scm",(void*)f_1241},
{"f_1285srfi-4.scm",(void*)f_1285},
{"f_1251srfi-4.scm",(void*)f_1251},
{"f_1260srfi-4.scm",(void*)f_1260},
{"f_1265srfi-4.scm",(void*)f_1265},
{"f_1272srfi-4.scm",(void*)f_1272},
{"f_1214srfi-4.scm",(void*)f_1214},
{"f_1221srfi-4.scm",(void*)f_1221},
{"f_1196srfi-4.scm",(void*)f_1196},
{"f_1212srfi-4.scm",(void*)f_1212},
{"f_1194srfi-4.scm",(void*)f_1194},
{"f_1040srfi-4.scm",(void*)f_1040},
{"f_1044srfi-4.scm",(void*)f_1044},
{"f_1047srfi-4.scm",(void*)f_1047},
{"f_1050srfi-4.scm",(void*)f_1050},
{"f_1067srfi-4.scm",(void*)f_1067},
{"f_1071srfi-4.scm",(void*)f_1071},
{"f_1074srfi-4.scm",(void*)f_1074},
{"f_1077srfi-4.scm",(void*)f_1077},
{"f_1101srfi-4.scm",(void*)f_1101},
{"f_1103srfi-4.scm",(void*)f_1103},
{"f_1107srfi-4.scm",(void*)f_1107},
{"f_1113srfi-4.scm",(void*)f_1113},
{"f_1120srfi-4.scm",(void*)f_1120},
{"f_1012srfi-4.scm",(void*)f_1012},
{"f_1014srfi-4.scm",(void*)f_1014},
{"f_1018srfi-4.scm",(void*)f_1018},
{"f_1024srfi-4.scm",(void*)f_1024},
{"f_1027srfi-4.scm",(void*)f_1027},
{"f_995srfi-4.scm",(void*)f_995},
{"f_997srfi-4.scm",(void*)f_997},
{"f_1001srfi-4.scm",(void*)f_1001},
{"f_1007srfi-4.scm",(void*)f_1007},
{"f_981srfi-4.scm",(void*)f_981},
{"f_983srfi-4.scm",(void*)f_983},
{"f_987srfi-4.scm",(void*)f_987},
{"f_990srfi-4.scm",(void*)f_990},
{"f_938srfi-4.scm",(void*)f_938},
{"f_940srfi-4.scm",(void*)f_940},
{"f_935srfi-4.scm",(void*)f_935},
{"f_932srfi-4.scm",(void*)f_932},
{"f_929srfi-4.scm",(void*)f_929},
{"f_926srfi-4.scm",(void*)f_926},
{"f_923srfi-4.scm",(void*)f_923},
{"f_920srfi-4.scm",(void*)f_920},
{"f_917srfi-4.scm",(void*)f_917},
{"f_914srfi-4.scm",(void*)f_914},
{"f_908srfi-4.scm",(void*)f_908},
{"f_902srfi-4.scm",(void*)f_902},
{"f_899srfi-4.scm",(void*)f_899},
{"f_896srfi-4.scm",(void*)f_896},
{"f_893srfi-4.scm",(void*)f_893},
{"f_890srfi-4.scm",(void*)f_890},
{"f_887srfi-4.scm",(void*)f_887},
{"f_884srfi-4.scm",(void*)f_884},
{"f_863srfi-4.scm",(void*)f_863},
{"f_848srfi-4.scm",(void*)f_848},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
