/* Generated from compiler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-06-28 12:11
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10664	compiled 2008-06-28 on galinha (Linux)
   command line: compiler.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file compiler.c
   unit: compiler
*/

#include "chicken.h"


#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif

#ifndef C_DEFAULT_TARGET_STACK_SIZE
# define C_DEFAULT_TARGET_STACK_SIZE 0
#endif

#ifndef C_DEFAULT_TARGET_HEAP_SIZE
# define C_DEFAULT_TARGET_HEAP_SIZE 0
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[578];
static double C_possibly_force_alignment;


C_noret_decl(C_compiler_toplevel)
C_externexport void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10153)
static void C_ccall f_10153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11210)
static void C_ccall f_11210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11213)
static void C_ccall f_11213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11216)
static void C_ccall f_11216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11219)
static void C_ccall f_11219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11222)
static void C_ccall f_11222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11010)
static void C_fcall f_11010(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11016)
static void C_ccall f_11016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10243)
static void C_fcall f_10243(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10999)
static void C_ccall f_10999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10996)
static void C_ccall f_10996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10909)
static void C_fcall f_10909(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10973)
static void C_ccall f_10973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10986)
static void C_ccall f_10986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10967)
static void C_ccall f_10967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10957)
static void C_ccall f_10957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10930)
static void C_fcall f_10930(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10933)
static void C_ccall f_10933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10881)
static void C_fcall f_10881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10884)
static void C_ccall f_10884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10838)
static void C_ccall f_10838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10850)
static void C_fcall f_10850(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10841)
static void C_fcall f_10841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10844)
static void C_ccall f_10844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10718)
static void C_ccall f_10718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10819)
static void C_ccall f_10819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10807)
static void C_ccall f_10807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10746)
static void C_ccall f_10746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10752)
static void C_fcall f_10752(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10776)
static void C_ccall f_10776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10768)
static void C_ccall f_10768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10734)
static void C_ccall f_10734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10677)
static void C_ccall f_10677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10689)
static void C_ccall f_10689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10693)
static void C_ccall f_10693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10681)
static void C_ccall f_10681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10493)
static void C_ccall f_10493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10614)
static void C_ccall f_10614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10620)
static void C_ccall f_10620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10645)
static void C_ccall f_10645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10626)
static void C_fcall f_10626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10500)
static void C_ccall f_10500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10605)
static void C_ccall f_10605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10503)
static void C_ccall f_10503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10506)
static void C_ccall f_10506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10509)
static void C_ccall f_10509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10547)
static void C_ccall f_10547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10573)
static void C_ccall f_10573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10554)
static void C_fcall f_10554(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10558)
static void C_ccall f_10558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10531)
static void C_ccall f_10531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10437)
static void C_ccall f_10437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10446)
static void C_fcall f_10446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10440)
static void C_fcall f_10440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10421)
static void C_ccall f_10421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10394)
static void C_ccall f_10394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10377)
static void C_ccall f_10377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10373)
static void C_ccall f_10373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10366)
static void C_ccall f_10366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10349)
static void C_ccall f_10349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10345)
static void C_ccall f_10345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10321)
static void C_ccall f_10321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10301)
static void C_ccall f_10301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10156)
static void C_fcall f_10156(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10160)
static void C_ccall f_10160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10175)
static void C_ccall f_10175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10185)
static void C_ccall f_10185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10190)
static void C_fcall f_10190(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10235)
static void C_ccall f_10235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10194)
static void C_ccall f_10194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10200)
static void C_fcall f_10200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10210)
static void C_ccall f_10210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11022)
static void C_fcall f_11022(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11029)
static void C_ccall f_11029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11091)
static void C_ccall f_11091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11081)
static void C_ccall f_11081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11055)
static void C_ccall f_11055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11041)
static void C_ccall f_11041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11116)
static void C_fcall f_11116(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11132)
static void C_ccall f_11132(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11139)
static void C_ccall f_11139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11146)
static void C_ccall f_11146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11120)
static void C_ccall f_11120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11130)
static void C_ccall f_11130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11102)
static void C_fcall f_11102(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11110)
static void C_ccall f_11110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11148)
static void C_fcall f_11148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11161)
static void C_ccall f_11161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10144)
static void C_ccall f_10144(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10135)
static void C_ccall f_10135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10126)
static void C_ccall f_10126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10117)
static void C_ccall f_10117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10108)
static void C_ccall f_10108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10099)
static void C_ccall f_10099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10090)
static void C_ccall f_10090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10081)
static void C_ccall f_10081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10072)
static void C_ccall f_10072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10063)
static void C_ccall f_10063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10054)
static void C_ccall f_10054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10045)
static void C_ccall f_10045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10036)
static void C_ccall f_10036(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10027)
static void C_ccall f_10027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10018)
static void C_ccall f_10018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10009)
static void C_ccall f_10009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10000)
static void C_ccall f_10000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9991)
static void C_ccall f_9991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9982)
static void C_ccall f_9982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9973)
static void C_ccall f_9973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9964)
static void C_ccall f_9964(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9955)
static void C_ccall f_9955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9946)
static void C_ccall f_9946(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9937)
static void C_ccall f_9937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9928)
static void C_ccall f_9928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9919)
static void C_ccall f_9919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9910)
static void C_ccall f_9910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9901)
static void C_ccall f_9901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9892)
static void C_ccall f_9892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9883)
static void C_ccall f_9883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9877)
static void C_ccall f_9877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9871)
static void C_ccall f_9871(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16) C_noret;
C_noret_decl(f_8637)
static void C_ccall f_8637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9838)
static void C_ccall f_9838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9841)
static void C_ccall f_9841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9844)
static void C_ccall f_9844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9847)
static void C_ccall f_9847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9850)
static void C_ccall f_9850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9865)
static void C_ccall f_9865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9863)
static void C_ccall f_9863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9853)
static void C_ccall f_9853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9690)
static void C_fcall f_9690(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9696)
static void C_ccall f_9696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9001)
static void C_fcall f_9001(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9020)
static void C_fcall f_9020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9053)
static void C_fcall f_9053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9580)
static void C_ccall f_9580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9576)
static void C_ccall f_9576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9569)
static void C_fcall f_9569(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9420)
static void C_ccall f_9420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9426)
static void C_ccall f_9426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9496)
static void C_ccall f_9496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9526)
static void C_ccall f_9526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9509)
static void C_ccall f_9509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9513)
static void C_ccall f_9513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9435)
static void C_ccall f_9435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9482)
static void C_ccall f_9482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9486)
static void C_ccall f_9486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9462)
static void C_ccall f_9462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9458)
static void C_ccall f_9458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9149)
static void C_ccall f_9149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9398)
static void C_ccall f_9398(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9153)
static void C_ccall f_9153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9396)
static void C_ccall f_9396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9156)
static void C_ccall f_9156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9159)
static void C_ccall f_9159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9165)
static void C_ccall f_9165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9171)
static void C_ccall f_9171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9177)
static void C_fcall f_9177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9363)
static void C_ccall f_9363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9366)
static void C_ccall f_9366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9180)
static void C_ccall f_9180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9339)
static void C_ccall f_9339(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9324)
static void C_ccall f_9324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9320)
static void C_ccall f_9320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9254)
static void C_ccall f_9254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9279)
static void C_ccall f_9279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9285)
static void C_ccall f_9285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9296)
static void C_ccall f_9296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9283)
static void C_ccall f_9283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9265)
static void C_ccall f_9265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9257)
static void C_ccall f_9257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9242)
static void C_ccall f_9242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9250)
static void C_ccall f_9250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9203)
static void C_ccall f_9203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9233)
static void C_ccall f_9233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9225)
static void C_ccall f_9225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9221)
static void C_ccall f_9221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9217)
static void C_ccall f_9217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9206)
static void C_ccall f_9206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9074)
static void C_ccall f_9074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9077)
static void C_ccall f_9077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9129)
static void C_ccall f_9129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9093)
static void C_ccall f_9093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9114)
static void C_ccall f_9114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9059)
static void C_ccall f_9059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9032)
static void C_ccall f_9032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9038)
static void C_ccall f_9038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9702)
static void C_fcall f_9702(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9709)
static void C_ccall f_9709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9725)
static void C_ccall f_9725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8667)
static void C_fcall f_8667(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8686)
static void C_fcall f_8686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8965)
static void C_ccall f_8965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8926)
static void C_ccall f_8926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9741)
static void C_ccall f_9741(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9779)
static void C_fcall f_9779(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9805)
static void C_ccall f_9805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9791)
static void C_fcall f_9791(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9770)
static void C_ccall f_9770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9739)
static void C_ccall f_9739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8939)
static void C_ccall f_8939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8942)
static void C_ccall f_8942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8953)
static void C_ccall f_8953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8890)
static void C_ccall f_8890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8782)
static void C_ccall f_8782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8788)
static void C_fcall f_8788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8800)
static void C_ccall f_8800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8803)
static void C_ccall f_8803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8806)
static void C_fcall f_8806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8824)
static void C_fcall f_8824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8831)
static void C_ccall f_8831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8809)
static void C_ccall f_8809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8812)
static void C_ccall f_8812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8815)
static void C_ccall f_8815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8776)
static void C_fcall f_8776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8766)
static void C_fcall f_8766(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8749)
static void C_ccall f_8749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8707)
static void C_ccall f_8707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8724)
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8711)
static void C_ccall f_8711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8722)
static void C_ccall f_8722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8697)
static void C_ccall f_8697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8656)
static void C_fcall f_8656(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8665)
static void C_ccall f_8665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8646)
static void C_fcall f_8646(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8651)
static void C_ccall f_8651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8640)
static void C_fcall f_8640(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7873)
static void C_ccall f_7873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7876)
static void C_ccall f_7876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8524)
static void C_ccall f_8524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8489)
static void C_fcall f_8489(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7900)
static void C_ccall f_7900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8435)
static void C_fcall f_8435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8438)
static void C_ccall f_8438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8450)
static void C_fcall f_8450(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8444)
static void C_fcall f_8444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7906)
static void C_ccall f_7906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8418)
static void C_ccall f_8418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8410)
static void C_ccall f_8410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8378)
static void C_ccall f_8378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8384)
static void C_fcall f_8384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_ccall f_7909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8340)
static void C_fcall f_8340(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8349)
static void C_ccall f_8349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8352)
static void C_fcall f_8352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7912)
static void C_ccall f_7912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8241)
static void C_fcall f_8241(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8259)
static void C_ccall f_8259(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8302)
static void C_ccall f_8302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8323)
static void C_ccall f_8323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8309)
static void C_fcall f_8309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8312)
static void C_ccall f_8312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8263)
static void C_ccall f_8263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8269)
static void C_fcall f_8269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7915)
static void C_ccall f_7915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8219)
static void C_ccall f_8219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8205)
static void C_fcall f_8205(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8212)
static void C_ccall f_8212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8193)
static void C_fcall f_8193(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8178)
static void C_fcall f_8178(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7918)
static void C_ccall f_7918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8090)
static void C_ccall f_8090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8164)
static void C_ccall f_8164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8096)
static void C_ccall f_8096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8154)
static void C_ccall f_8154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8146)
static void C_ccall f_8146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8099)
static void C_fcall f_8099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8102)
static void C_ccall f_8102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7921)
static void C_ccall f_7921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7949)
static void C_fcall f_7949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7970)
static void C_fcall f_7970(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7991)
static void C_fcall f_7991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7997)
static void C_ccall f_7997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7924)
static void C_ccall f_7924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7930)
static void C_fcall f_7930(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7934)
static void C_ccall f_7934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7879)
static void C_ccall f_7879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7883)
static void C_ccall f_7883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7886)
static void C_fcall f_7886(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7841)
static void C_fcall f_7841(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7859)
static void C_ccall f_7859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7827)
static void C_fcall f_7827(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7706)
static void C_fcall f_7706(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7712)
static void C_ccall f_7712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7125)
static void C_fcall f_7125(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7147)
static void C_fcall f_7147(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7668)
static void C_ccall f_7668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7662)
static void C_ccall f_7662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7644)
static void C_ccall f_7644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7629)
static void C_ccall f_7629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7554)
static void C_ccall f_7554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7583)
static void C_fcall f_7583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7598)
static void C_fcall f_7598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7602)
static void C_ccall f_7602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7589)
static void C_fcall f_7589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7557)
static void C_ccall f_7557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7580)
static void C_ccall f_7580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7560)
static void C_ccall f_7560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7444)
static void C_ccall f_7444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7536)
static void C_ccall f_7536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7526)
static void C_ccall f_7526(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7454)
static void C_ccall f_7454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7457)
static void C_ccall f_7457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7511)
static void C_ccall f_7511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7460)
static void C_ccall f_7460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7463)
static void C_fcall f_7463(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7496)
static void C_fcall f_7496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7466)
static void C_fcall f_7466(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7469)
static void C_ccall f_7469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7400)
static void C_ccall f_7400(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7419)
static void C_ccall f_7419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7417)
static void C_ccall f_7417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7333)
static void C_ccall f_7333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7338)
static void C_fcall f_7338(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7365)
static void C_ccall f_7365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7371)
static void C_ccall f_7371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7356)
static void C_ccall f_7356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7261)
static void C_ccall f_7261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7309)
static void C_ccall f_7309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7272)
static void C_ccall f_7272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7291)
static void C_ccall f_7291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7238)
static void C_ccall f_7238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7241)
static void C_ccall f_7241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7202)
static void C_ccall f_7202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7159)
static void C_ccall f_7159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7190)
static void C_ccall f_7190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7718)
static void C_fcall f_7718(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7731)
static void C_fcall f_7731(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7740)
static void C_fcall f_7740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7743)
static void C_ccall f_7743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7746)
static void C_ccall f_7746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7821)
static void C_fcall f_7821(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7118)
static C_word C_fcall f_7118(C_word t0);
C_noret_decl(f_7103)
static void C_ccall f_7103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7085)
static void C_ccall f_7085(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7076)
static void C_ccall f_7076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7031)
static void C_ccall f_7031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7010)
static void C_ccall f_7010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6335)
static void C_ccall f_6335(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6982)
static void C_ccall f_6982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6897)
static void C_fcall f_6897(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6903)
static void C_fcall f_6903(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6923)
static void C_ccall f_6923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6941)
static void C_ccall f_6941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6950)
static void C_ccall f_6950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6964)
static void C_ccall f_6964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6917)
static void C_ccall f_6917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6881)
static void C_fcall f_6881(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6887)
static void C_ccall f_6887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6756)
static void C_fcall f_6756(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6760)
static void C_ccall f_6760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6763)
static void C_ccall f_6763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6817)
static void C_ccall f_6817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6813)
static void C_ccall f_6813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6788)
static void C_ccall f_6788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6805)
static void C_ccall f_6805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6798)
static void C_ccall f_6798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6382)
static void C_fcall f_6382(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6404)
static void C_fcall f_6404(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6670)
static void C_fcall f_6670(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6827)
static void C_ccall f_6827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6830)
static void C_ccall f_6830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6875)
static void C_ccall f_6875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6871)
static void C_ccall f_6871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6863)
static void C_ccall f_6863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6635)
static void C_ccall f_6635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6585)
static void C_ccall f_6585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6594)
static void C_ccall f_6594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6572)
static void C_ccall f_6572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6510)
static void C_fcall f_6510(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6533)
static void C_ccall f_6533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6460)
static void C_ccall f_6460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6471)
static void C_ccall f_6471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6338)
static void C_fcall f_6338(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6365)
static void C_ccall f_6365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6376)
static void C_ccall f_6376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6359)
static void C_ccall f_6359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6245)
static void C_ccall f_6245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6277)
static void C_fcall f_6277(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6296)
static void C_ccall f_6296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6319)
static void C_ccall f_6319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6302)
static void C_ccall f_6302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6248)
static void C_fcall f_6248(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6254)
static void C_fcall f_6254(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6168)
static void C_fcall f_6168(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6171)
static void C_fcall f_6171(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6174)
static void C_fcall f_6174(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6190)
static void C_ccall f_6190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6177)
static void C_ccall f_6177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6180)
static void C_ccall f_6180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6183)
static void C_ccall f_6183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6127)
static void C_ccall f_6127(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6150)
static void C_ccall f_6150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6113)
static void C_ccall f_6113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6045)
static void C_ccall f_6045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6052)
static void C_ccall f_6052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6000)
static void C_ccall f_6000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6007)
static void C_ccall f_6007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5994)
static void C_ccall f_5994(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5850)
static void C_ccall f_5850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5853)
static void C_ccall f_5853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5856)
static void C_ccall f_5856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5988)
static void C_ccall f_5988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5872)
static void C_fcall f_5872(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5875)
static void C_ccall f_5875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5915)
static void C_ccall f_5915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5918)
static void C_ccall f_5918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_ccall f_5933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5908)
static void C_ccall f_5908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5898)
static void C_ccall f_5898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5801)
static void C_ccall f_5801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5792)
static void C_ccall f_5792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5747)
static void C_ccall f_5747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5738)
static void C_ccall f_5738(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5711)
static void C_ccall f_5711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4799)
static void C_fcall f_4799(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5664)
static void C_ccall f_5664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5631)
static void C_ccall f_5631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5585)
static void C_ccall f_5585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_ccall f_5592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_fcall f_5473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5477)
static void C_ccall f_5477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5318)
static void C_ccall f_5318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5363)
static void C_ccall f_5363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5266)
static void C_ccall f_5266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5167)
static void C_fcall f_5167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5145)
static void C_ccall f_5145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5149)
static void C_ccall f_5149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4884)
static void C_fcall f_4884(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_fcall f_4748(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4771)
static void C_ccall f_4771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4761)
static void C_fcall f_4761(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4730)
static void C_ccall f_4730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_fcall f_4690(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2156)
static void C_fcall f_2156(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_fcall f_4566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_fcall f_4587(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4609)
static void C_ccall f_4609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_fcall f_2388(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4453)
static void C_ccall f_4453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4324)
static void C_fcall f_4324(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4328)
static void C_ccall f_4328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4308)
static void C_ccall f_4308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4273)
static void C_fcall f_4273(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_fcall f_4223(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4263)
static void C_ccall f_4263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4072)
static C_word C_fcall f_4072(C_word *a,C_word t0);
C_noret_decl(f_4067)
static void C_fcall f_4067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4030)
static C_word C_fcall f_4030(C_word *a,C_word t0);
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3801)
static void C_ccall f_3801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3711)
static void C_ccall f_3711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_fcall f_3624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_fcall f_3521(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_fcall f_3253(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_fcall f_3049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_fcall f_2818(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_fcall f_2668(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_fcall f_2688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_fcall f_2721(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_fcall f_2678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_fcall f_2435(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_fcall f_2483(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2429)
static void C_ccall f_2429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2292)
static void C_ccall f_2292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_fcall f_2138(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2047)
static void C_fcall f_2047(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2012)
static void C_fcall f_2012(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_fcall f_1981(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1969)
static C_word C_fcall f_1969(C_word t0,C_word t1);
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11010)
static void C_fcall trf_11010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11010(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_11010(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10243)
static void C_fcall trf_10243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10243(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10243(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10909)
static void C_fcall trf_10909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10909(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10909(t0,t1);}

C_noret_decl(trf_10930)
static void C_fcall trf_10930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10930(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10930(t0,t1);}

C_noret_decl(trf_10881)
static void C_fcall trf_10881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10881(t0,t1);}

C_noret_decl(trf_10850)
static void C_fcall trf_10850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10850(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10850(t0,t1);}

C_noret_decl(trf_10841)
static void C_fcall trf_10841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10841(t0,t1);}

C_noret_decl(trf_10752)
static void C_fcall trf_10752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10752(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10752(t0,t1);}

C_noret_decl(trf_10626)
static void C_fcall trf_10626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10626(t0,t1);}

C_noret_decl(trf_10554)
static void C_fcall trf_10554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10554(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10554(t0,t1);}

C_noret_decl(trf_10446)
static void C_fcall trf_10446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10446(t0,t1);}

C_noret_decl(trf_10440)
static void C_fcall trf_10440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10440(t0,t1);}

C_noret_decl(trf_10156)
static void C_fcall trf_10156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10156(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10156(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10190)
static void C_fcall trf_10190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10190(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10190(t0,t1,t2,t3);}

C_noret_decl(trf_10200)
static void C_fcall trf_10200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10200(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10200(t0,t1);}

C_noret_decl(trf_11022)
static void C_fcall trf_11022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11022(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11022(t0,t1,t2);}

C_noret_decl(trf_11116)
static void C_fcall trf_11116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11116(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11116(t0,t1,t2);}

C_noret_decl(trf_11102)
static void C_fcall trf_11102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11102(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11102(t0,t1,t2);}

C_noret_decl(trf_11148)
static void C_fcall trf_11148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11148(t0,t1);}

C_noret_decl(trf_9690)
static void C_fcall trf_9690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9690(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9690(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9001)
static void C_fcall trf_9001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9001(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9001(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9020)
static void C_fcall trf_9020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9020(t0,t1);}

C_noret_decl(trf_9053)
static void C_fcall trf_9053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9053(t0,t1);}

C_noret_decl(trf_9569)
static void C_fcall trf_9569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9569(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9569(t0,t1);}

C_noret_decl(trf_9177)
static void C_fcall trf_9177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9177(t0,t1);}

C_noret_decl(trf_9702)
static void C_fcall trf_9702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9702(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9702(t0,t1,t2,t3);}

C_noret_decl(trf_8667)
static void C_fcall trf_8667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8667(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8667(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8686)
static void C_fcall trf_8686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8686(t0,t1);}

C_noret_decl(trf_9779)
static void C_fcall trf_9779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9779(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9779(t0,t1);}

C_noret_decl(trf_9791)
static void C_fcall trf_9791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9791(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9791(t0,t1);}

C_noret_decl(trf_8788)
static void C_fcall trf_8788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8788(t0,t1);}

C_noret_decl(trf_8806)
static void C_fcall trf_8806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8806(t0,t1);}

C_noret_decl(trf_8824)
static void C_fcall trf_8824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8824(t0,t1);}

C_noret_decl(trf_8776)
static void C_fcall trf_8776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8776(t0,t1);}

C_noret_decl(trf_8766)
static void C_fcall trf_8766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8766(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8766(t0,t1);}

C_noret_decl(trf_8656)
static void C_fcall trf_8656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8656(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8656(t0,t1,t2);}

C_noret_decl(trf_8646)
static void C_fcall trf_8646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8646(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8646(t0,t1,t2,t3);}

C_noret_decl(trf_8640)
static void C_fcall trf_8640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8640(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8640(t0,t1,t2,t3);}

C_noret_decl(trf_8489)
static void C_fcall trf_8489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8489(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8489(t0,t1);}

C_noret_decl(trf_8435)
static void C_fcall trf_8435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8435(t0,t1);}

C_noret_decl(trf_8450)
static void C_fcall trf_8450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8450(t0,t1);}

C_noret_decl(trf_8444)
static void C_fcall trf_8444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8444(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8444(t0,t1);}

C_noret_decl(trf_8384)
static void C_fcall trf_8384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8384(t0,t1);}

C_noret_decl(trf_8340)
static void C_fcall trf_8340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8340(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8340(t0,t1);}

C_noret_decl(trf_8352)
static void C_fcall trf_8352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8352(t0,t1);}

C_noret_decl(trf_8241)
static void C_fcall trf_8241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8241(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8241(t0,t1);}

C_noret_decl(trf_8309)
static void C_fcall trf_8309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8309(t0,t1);}

C_noret_decl(trf_8269)
static void C_fcall trf_8269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8269(t0,t1);}

C_noret_decl(trf_8205)
static void C_fcall trf_8205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8205(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8205(t0,t1);}

C_noret_decl(trf_8193)
static void C_fcall trf_8193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8193(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8193(t0,t1);}

C_noret_decl(trf_8178)
static void C_fcall trf_8178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8178(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8178(t0,t1);}

C_noret_decl(trf_8099)
static void C_fcall trf_8099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8099(t0,t1);}

C_noret_decl(trf_7949)
static void C_fcall trf_7949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7949(t0,t1);}

C_noret_decl(trf_7970)
static void C_fcall trf_7970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7970(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7970(t0,t1);}

C_noret_decl(trf_7991)
static void C_fcall trf_7991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7991(t0,t1);}

C_noret_decl(trf_7930)
static void C_fcall trf_7930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7930(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7930(t0,t1);}

C_noret_decl(trf_7886)
static void C_fcall trf_7886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7886(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7886(t0,t1);}

C_noret_decl(trf_7841)
static void C_fcall trf_7841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7841(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7841(t0,t1,t2,t3);}

C_noret_decl(trf_7827)
static void C_fcall trf_7827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7827(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7827(t0,t1,t2,t3);}

C_noret_decl(trf_7706)
static void C_fcall trf_7706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7706(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7706(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7125)
static void C_fcall trf_7125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7125(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7125(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7147)
static void C_fcall trf_7147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7147(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7147(t0,t1);}

C_noret_decl(trf_7583)
static void C_fcall trf_7583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7583(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7583(t0,t1);}

C_noret_decl(trf_7598)
static void C_fcall trf_7598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7598(t0,t1);}

C_noret_decl(trf_7589)
static void C_fcall trf_7589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7589(t0,t1);}

C_noret_decl(trf_7463)
static void C_fcall trf_7463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7463(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7463(t0,t1);}

C_noret_decl(trf_7496)
static void C_fcall trf_7496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7496(t0,t1);}

C_noret_decl(trf_7466)
static void C_fcall trf_7466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7466(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7466(t0,t1);}

C_noret_decl(trf_7338)
static void C_fcall trf_7338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7338(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7338(t0,t1,t2,t3);}

C_noret_decl(trf_7718)
static void C_fcall trf_7718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7718(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7718(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7731)
static void C_fcall trf_7731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7731(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7731(t0,t1);}

C_noret_decl(trf_7740)
static void C_fcall trf_7740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7740(t0,t1);}

C_noret_decl(trf_7821)
static void C_fcall trf_7821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7821(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7821(t0,t1,t2,t3);}

C_noret_decl(trf_6897)
static void C_fcall trf_6897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6897(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6897(t0,t1,t2,t3);}

C_noret_decl(trf_6903)
static void C_fcall trf_6903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6903(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6903(t0,t1,t2,t3);}

C_noret_decl(trf_6881)
static void C_fcall trf_6881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6881(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6881(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6756)
static void C_fcall trf_6756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6756(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6756(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6382)
static void C_fcall trf_6382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6382(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6382(t0,t1,t2,t3);}

C_noret_decl(trf_6404)
static void C_fcall trf_6404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6404(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6404(t0,t1);}

C_noret_decl(trf_6670)
static void C_fcall trf_6670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6670(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6670(t0,t1);}

C_noret_decl(trf_6510)
static void C_fcall trf_6510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6510(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6510(t0,t1,t2,t3);}

C_noret_decl(trf_6338)
static void C_fcall trf_6338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6338(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6338(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6277)
static void C_fcall trf_6277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6277(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6277(t0,t1,t2);}

C_noret_decl(trf_6248)
static void C_fcall trf_6248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6248(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6248(t0,t1,t2);}

C_noret_decl(trf_6254)
static void C_fcall trf_6254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6254(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6254(t0,t1,t2);}

C_noret_decl(trf_6168)
static void C_fcall trf_6168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6168(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6168(t0,t1);}

C_noret_decl(trf_6171)
static void C_fcall trf_6171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6171(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6171(t0,t1);}

C_noret_decl(trf_6174)
static void C_fcall trf_6174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6174(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6174(t0,t1);}

C_noret_decl(trf_5872)
static void C_fcall trf_5872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5872(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5872(t0,t1);}

C_noret_decl(trf_4799)
static void C_fcall trf_4799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4799(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4799(t0,t1);}

C_noret_decl(trf_5473)
static void C_fcall trf_5473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5473(t0,t1);}

C_noret_decl(trf_5167)
static void C_fcall trf_5167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5167(t0,t1);}

C_noret_decl(trf_4884)
static void C_fcall trf_4884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4884(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4884(t0,t1);}

C_noret_decl(trf_4748)
static void C_fcall trf_4748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4748(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4748(t0,t1,t2,t3);}

C_noret_decl(trf_4761)
static void C_fcall trf_4761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4761(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4761(t0,t1);}

C_noret_decl(trf_4690)
static void C_fcall trf_4690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4690(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4690(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2156)
static void C_fcall trf_2156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2156(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2156(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4566)
static void C_fcall trf_4566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4566(t0,t1);}

C_noret_decl(trf_4587)
static void C_fcall trf_4587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4587(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4587(t0,t1);}

C_noret_decl(trf_2388)
static void C_fcall trf_2388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2388(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2388(t0,t1);}

C_noret_decl(trf_4324)
static void C_fcall trf_4324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4324(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4324(t0,t1);}

C_noret_decl(trf_4273)
static void C_fcall trf_4273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4273(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4273(t0,t1);}

C_noret_decl(trf_4223)
static void C_fcall trf_4223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4223(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4223(t0,t1,t2,t3);}

C_noret_decl(trf_4067)
static void C_fcall trf_4067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4067(t0,t1);}

C_noret_decl(trf_3624)
static void C_fcall trf_3624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3624(t0,t1);}

C_noret_decl(trf_3521)
static void C_fcall trf_3521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3521(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3521(t0,t1);}

C_noret_decl(trf_3253)
static void C_fcall trf_3253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3253(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3253(t0,t1,t2);}

C_noret_decl(trf_3049)
static void C_fcall trf_3049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3049(t0,t1);}

C_noret_decl(trf_2818)
static void C_fcall trf_2818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2818(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2818(t0,t1);}

C_noret_decl(trf_2668)
static void C_fcall trf_2668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2668(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2668(t0,t1);}

C_noret_decl(trf_2688)
static void C_fcall trf_2688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2688(t0,t1);}

C_noret_decl(trf_2721)
static void C_fcall trf_2721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2721(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2721(t0,t1);}

C_noret_decl(trf_2678)
static void C_fcall trf_2678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2678(t0,t1,t2);}

C_noret_decl(trf_2435)
static void C_fcall trf_2435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2435(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2435(t0,t1,t2);}

C_noret_decl(trf_2483)
static void C_fcall trf_2483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2483(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2483(t0,t1);}

C_noret_decl(trf_2138)
static void C_fcall trf_2138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2138(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2138(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2047)
static void C_fcall trf_2047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2047(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2047(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2012)
static void C_fcall trf_2012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2012(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2012(t0,t1);}

C_noret_decl(trf_1981)
static void C_fcall trf_1981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1981(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1981(t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr17)
static void C_fcall tr17(C_proc17 k) C_regparm C_noret;
C_regparm static void C_fcall tr17(C_proc17 k){
C_word t16=C_pick(0);
C_word t15=C_pick(1);
C_word t14=C_pick(2);
C_word t13=C_pick(3);
C_word t12=C_pick(4);
C_word t11=C_pick(5);
C_word t10=C_pick(6);
C_word t9=C_pick(7);
C_word t8=C_pick(8);
C_word t7=C_pick(9);
C_word t6=C_pick(10);
C_word t5=C_pick(11);
C_word t4=C_pick(12);
C_word t3=C_pick(13);
C_word t2=C_pick(14);
C_word t1=C_pick(15);
C_word t0=C_pick(16);
C_adjust_stack(-17);
(k)(17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5592)){
C_save(t1);
C_rereclaim2(5592*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,578);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],17,"user-options-pass");
lf[4]=C_h_intern(&lf[4],14,"user-read-pass");
lf[5]=C_h_intern(&lf[5],22,"user-preprocessor-pass");
lf[6]=C_h_intern(&lf[6],9,"user-pass");
lf[7]=C_h_intern(&lf[7],11,"user-pass-2");
lf[8]=C_h_intern(&lf[8],23,"user-post-analysis-pass");
lf[9]=C_h_intern(&lf[9],18,"\010compilerunit-name");
lf[10]=C_h_intern(&lf[10],11,"number-type");
lf[11]=C_h_intern(&lf[11],7,"generic");
lf[12]=C_h_intern(&lf[12],17,"standard-bindings");
lf[13]=C_h_intern(&lf[13],17,"extended-bindings");
lf[14]=C_h_intern(&lf[14],28,"\010compilerinsert-timer-checks");
lf[15]=C_h_intern(&lf[15],19,"\010compilerused-units");
lf[16]=C_h_intern(&lf[16],6,"unsafe");
lf[17]=C_h_intern(&lf[17],12,"always-bound");
lf[18]=C_h_intern(&lf[18],34,"\010compileralways-bound-to-procedure");
lf[19]=C_h_intern(&lf[19],29,"\010compilerforeign-declarations");
lf[20]=C_h_intern(&lf[20],24,"\010compileremit-trace-info");
lf[21]=C_h_intern(&lf[21],26,"\010compilerblock-compilation");
lf[22]=C_h_intern(&lf[22],34,"\010compilerline-number-database-size");
lf[23]=C_h_intern(&lf[23],25,"\010compilertarget-heap-size");
lf[24]=C_h_intern(&lf[24],33,"\010compilertarget-initial-heap-size");
lf[25]=C_h_intern(&lf[25],26,"\010compilertarget-stack-size");
lf[26]=C_h_intern(&lf[26],22,"optimize-leaf-routines");
lf[27]=C_h_intern(&lf[27],21,"\010compileremit-profile");
lf[28]=C_h_intern(&lf[28],15,"no-bound-checks");
lf[29]=C_h_intern(&lf[29],14,"no-argc-checks");
lf[30]=C_h_intern(&lf[30],19,"no-procedure-checks");
lf[31]=C_h_intern(&lf[31],22,"\010compilerblock-globals");
lf[32]=C_h_intern(&lf[32],24,"\010compilersource-filename");
lf[33]=C_h_intern(&lf[33],20,"\010compilerexport-list");
lf[34]=C_h_intern(&lf[34],26,"\010compilersafe-globals-flag");
lf[35]=C_h_intern(&lf[35],26,"\010compilerexplicit-use-flag");
lf[36]=C_h_intern(&lf[36],40,"\010compilerdisable-stack-overflow-checking");
lf[37]=C_h_intern(&lf[37],29,"\010compilerrequire-imports-flag");
lf[38]=C_h_intern(&lf[38],27,"\010compileremit-unsafe-marker");
lf[39]=C_h_intern(&lf[39],30,"\010compilerexternal-protos-first");
lf[40]=C_h_intern(&lf[40],26,"\010compilerdo-lambda-lifting");
lf[41]=C_h_intern(&lf[41],24,"\010compilerinline-max-size");
lf[42]=C_h_intern(&lf[42],26,"\010compileremit-closure-info");
lf[43]=C_h_intern(&lf[43],25,"\010compilerexport-file-name");
lf[44]=C_h_intern(&lf[44],21,"\010compilerimport-table");
lf[45]=C_h_intern(&lf[45],25,"\010compileruse-import-table");
lf[46]=C_h_intern(&lf[46],33,"\010compilerundefine-shadowed-macros");
lf[47]=C_h_intern(&lf[47],30,"\010compilerconstant-declarations");
lf[48]=C_h_intern(&lf[48],41,"\010compilerdefault-default-target-heap-size");
lf[49]=C_h_intern(&lf[49],42,"\010compilerdefault-default-target-stack-size");
lf[50]=C_h_intern(&lf[50],21,"\010compilerverbose-mode");
lf[51]=C_h_intern(&lf[51],30,"\010compileroriginal-program-size");
lf[52]=C_h_intern(&lf[52],29,"\010compilercurrent-program-size");
lf[53]=C_h_intern(&lf[53],31,"\010compilerline-number-database-2");
lf[54]=C_h_intern(&lf[54],28,"\010compilerimmutable-constants");
lf[55]=C_h_intern(&lf[55],43,"\010compilerrest-parameters-promoted-to-vector");
lf[56]=C_h_intern(&lf[56],21,"\010compilerinline-table");
lf[57]=C_h_intern(&lf[57],26,"\010compilerinline-table-used");
lf[58]=C_h_intern(&lf[58],23,"\010compilerconstant-table");
lf[59]=C_h_intern(&lf[59],23,"\010compilerconstants-used");
lf[60]=C_h_intern(&lf[60],26,"\010compilermutable-constants");
lf[61]=C_h_intern(&lf[61],30,"\010compilerbroken-constant-nodes");
lf[62]=C_h_intern(&lf[62],37,"\010compilerinline-substitutions-enabled");
lf[63]=C_h_intern(&lf[63],24,"\010compilerdirect-call-ids");
lf[64]=C_h_intern(&lf[64],23,"\010compilerfirst-analysis");
lf[65]=C_h_intern(&lf[65],27,"\010compilerforeign-type-table");
lf[66]=C_h_intern(&lf[66],26,"\010compilerforeign-variables");
lf[67]=C_h_intern(&lf[67],29,"\010compilerforeign-lambda-stubs");
lf[68]=C_h_intern(&lf[68],22,"foreign-callback-stubs");
lf[69]=C_h_intern(&lf[69],27,"\010compilerexternal-variables");
lf[70]=C_h_intern(&lf[70],26,"\010compilerloop-lambda-names");
lf[71]=C_h_intern(&lf[71],28,"\010compilerprofile-lambda-list");
lf[72]=C_h_intern(&lf[72],29,"\010compilerprofile-lambda-index");
lf[73]=C_h_intern(&lf[73],33,"\010compilerprofile-info-vector-name");
lf[74]=C_h_intern(&lf[74],28,"\010compilerexternal-to-pointer");
lf[75]=C_h_intern(&lf[75],34,"\010compilererror-is-extended-binding");
lf[76]=C_h_intern(&lf[76],24,"\010compilerreal-name-table");
lf[77]=C_h_intern(&lf[77],29,"\010compilerlocation-pointer-map");
lf[78]=C_h_intern(&lf[78],34,"\010compilerpending-canonicalizations");
lf[79]=C_h_intern(&lf[79],29,"\010compilerdefconstant-bindings");
lf[80]=C_h_intern(&lf[80],23,"\010compilercallback-names");
lf[81]=C_h_intern(&lf[81],23,"\010compilertoplevel-scope");
lf[82]=C_h_intern(&lf[82],27,"\010compilertoplevel-lambda-id");
lf[83]=C_h_intern(&lf[83],29,"\010compilercustom-declare-alist");
lf[84]=C_h_intern(&lf[84],25,"\010compilercsc-control-file");
lf[85]=C_h_intern(&lf[85],26,"\010compilerdata-declarations");
lf[86]=C_h_intern(&lf[86],20,"\010compilerinline-list");
lf[87]=C_h_intern(&lf[87],24,"\010compilernot-inline-list");
lf[88]=C_h_intern(&lf[88],26,"\010compilerfile-requirements");
lf[89]=C_h_intern(&lf[89],28,"\010compilerpostponed-initforms");
lf[90]=C_h_intern(&lf[90],25,"\010compilerunused-variables");
lf[91]=C_h_intern(&lf[91],29,"\010compilercompiler-macro-table");
lf[92]=C_h_intern(&lf[92],32,"\010compilercompiler-macros-enabled");
lf[93]=C_h_intern(&lf[93],29,"\010compilerliteral-rewrite-hook");
lf[94]=C_h_intern(&lf[94],28,"\010compilerinitialize-compiler");
lf[95]=C_h_intern(&lf[95],12,"vector-fill!");
lf[96]=C_h_intern(&lf[96],11,"make-vector");
lf[97]=C_h_intern(&lf[97],25,"\010compilermake-random-name");
lf[98]=C_h_intern(&lf[98],12,"profile-info");
lf[99]=C_h_intern(&lf[99],32,"\010compilercanonicalize-expression");
lf[100]=C_h_intern(&lf[100],23,"\010compilerset-real-name!");
lf[101]=C_h_intern(&lf[101],8,"for-each");
lf[102]=C_h_intern(&lf[102],5,"quote");
lf[103]=C_h_intern(&lf[103],15,"\004coreinline_ref");
lf[104]=C_h_intern(&lf[104],36,"\010compilerforeign-type-convert-result");
lf[105]=C_h_intern(&lf[105],30,"\010compilerfinish-foreign-result");
lf[106]=C_h_intern(&lf[106],27,"\010compilerfinal-foreign-type");
lf[107]=C_h_intern(&lf[107],19,"\004coreinline_loc_ref");
lf[108]=C_h_intern(&lf[108],18,"\003syshash-table-ref");
lf[109]=C_h_intern(&lf[109],21,"\003sysalias-global-hook");
lf[110]=C_h_intern(&lf[110],12,"syntax-error");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal atomic form");
lf[112]=C_h_intern(&lf[112],24,"\003syssyntax-error-culprit");
lf[113]=C_h_intern(&lf[113],2,"if");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[115]=C_h_intern(&lf[115],16,"\003syscheck-syntax");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[118]=C_h_intern(&lf[118],10,"\004corecheck");
lf[119]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\006\001\376\377\016");
lf[120]=C_h_intern(&lf[120],14,"\004coreimmutable");
lf[121]=C_h_intern(&lf[121],10,"alist-cons");
lf[122]=C_h_intern(&lf[122],6,"gensym");
lf[123]=C_h_intern(&lf[123],1,"c");
lf[124]=C_h_intern(&lf[124],6,"cadadr");
lf[125]=C_h_intern(&lf[125],14,"\004coreundefined");
lf[126]=C_h_intern(&lf[126],23,"\004corerequire-for-syntax");
lf[127]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[128]=C_h_intern(&lf[128],10,"lset-union");
lf[129]=C_h_intern(&lf[129],3,"eq\077");
lf[130]=C_h_intern(&lf[130],22,"\003syshash-table-update!");
lf[131]=C_h_intern(&lf[131],19,"syntax-requirements");
lf[132]=C_h_intern(&lf[132],11,"\003sysrequire");
lf[133]=C_h_intern(&lf[133],7,"\003sysmap");
lf[134]=C_h_intern(&lf[134],4,"eval");
lf[135]=C_h_intern(&lf[135],22,"\004corerequire-extension");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[137]=C_h_intern(&lf[137],22,"\003sysdo-the-right-thing");
lf[138]=C_h_intern(&lf[138],5,"begin");
lf[139]=C_h_intern(&lf[139],28,"\010compilerlookup-exports-file");
lf[140]=C_h_intern(&lf[140],7,"exports");
lf[141]=C_h_intern(&lf[141],19,"\003syshash-table-set!");
lf[142]=C_h_intern(&lf[142],12,"\003sysfor-each");
lf[143]=C_h_intern(&lf[143],25,"\003sysextension-information");
lf[144]=C_h_intern(&lf[144],25,"\010compilercompiler-warning");
lf[145]=C_h_intern(&lf[145],3,"ext");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000)extension `~A\047 is currently not installed");
lf[147]=C_h_intern(&lf[147],18,"\003sysfind-extension");
lf[148]=C_h_intern(&lf[148],31,"\003syscanonicalize-extension-path");
lf[149]=C_h_intern(&lf[149],17,"require-extension");
lf[150]=C_h_intern(&lf[150],8,"feature\077");
lf[151]=C_h_intern(&lf[151],5,"cadar");
lf[152]=C_h_intern(&lf[152],3,"let");
lf[153]=C_h_intern(&lf[153],21,"\003syscanonicalize-body");
lf[154]=C_h_intern(&lf[154],3,"map");
lf[155]=C_h_intern(&lf[155],6,"append");
lf[156]=C_h_intern(&lf[156],4,"cons");
lf[157]=C_h_intern(&lf[157],6,"unzip1");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[159]=C_h_intern(&lf[159],6,"lambda");
lf[160]=C_h_intern(&lf[160],20,"\004coreinternal-lambda");
lf[161]=C_h_intern(&lf[161],30,"\010compilerexpand-profile-lambda");
lf[162]=C_h_intern(&lf[162],37,"\010compilerprocess-lambda-documentation");
lf[163]=C_h_intern(&lf[163],6,"cddadr");
lf[164]=C_h_intern(&lf[164],5,"cdadr");
lf[165]=C_h_intern(&lf[165],5,"caadr");
lf[166]=C_h_intern(&lf[166],26,"\010compilerbuild-lambda-list");
lf[167]=C_h_intern(&lf[167],13,"\010compilerposq");
lf[168]=C_h_intern(&lf[168],30,"\010compilerdecompose-lambda-list");
lf[169]=C_h_intern(&lf[169],31,"\003sysexpand-extended-lambda-list");
lf[170]=C_h_intern(&lf[170],9,"\003syserror");
lf[171]=C_h_intern(&lf[171],25,"\003sysextended-lambda-list\077");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[173]=C_h_intern(&lf[173],17,"\004corenamed-lambda");
lf[174]=C_h_intern(&lf[174],16,"\004coreloop-lambda");
lf[175]=C_h_intern(&lf[175],4,"set!");
lf[176]=C_h_intern(&lf[176],9,"\004coreset!");
lf[177]=C_h_intern(&lf[177],18,"\004coreinline_update");
lf[178]=C_h_intern(&lf[178],27,"\010compilerforeign-type-check");
lf[179]=C_h_intern(&lf[179],38,"\010compilerforeign-type-convert-argument");
lf[180]=C_h_intern(&lf[180],22,"\004coreinline_loc_update");
lf[181]=C_h_intern(&lf[181],6,"syntax");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\032assignment to keyword `~S\047");
lf[183]=C_h_intern(&lf[183],8,"keyword\077");
lf[184]=C_h_intern(&lf[184],15,"undefine-macro!");
lf[185]=C_h_intern(&lf[185],3,"var");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000+assigned global variable `~S\047 is a macro ~A");
lf[187]=C_h_intern(&lf[187],7,"sprintf");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\012in line ~S");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[190]=C_h_intern(&lf[190],6,"macro\077");
lf[191]=C_h_intern(&lf[191],11,"lset-adjoin");
lf[192]=C_h_intern(&lf[192],17,"\010compilerget-line");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[194]=C_h_intern(&lf[194],11,"\004coreinline");
lf[195]=C_h_intern(&lf[195],20,"\004coreinline_allocate");
lf[196]=C_h_intern(&lf[196],19,"\004corecompiletimetoo");
lf[197]=C_h_intern(&lf[197],23,"\004coreelaborationtimetoo");
lf[198]=C_h_intern(&lf[198],20,"\004corecompiletimeonly");
lf[199]=C_h_intern(&lf[199],24,"\004coreelaborationtimeonly");
lf[200]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[201]=C_h_intern(&lf[201],32,"\010compilercanonicalize-begin-body");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[204]=C_h_intern(&lf[204],19,"\004coreforeign-lambda");
lf[205]=C_h_intern(&lf[205],30,"\010compilerexpand-foreign-lambda");
lf[206]=C_h_intern(&lf[206],28,"\004coreforeign-callback-lambda");
lf[207]=C_h_intern(&lf[207],39,"\010compilerexpand-foreign-callback-lambda");
lf[208]=C_h_intern(&lf[208],20,"\004coreforeign-lambda*");
lf[209]=C_h_intern(&lf[209],31,"\010compilerexpand-foreign-lambda*");
lf[210]=C_h_intern(&lf[210],29,"\004coreforeign-callback-lambda*");
lf[211]=C_h_intern(&lf[211],40,"\010compilerexpand-foreign-callback-lambda*");
lf[212]=C_h_intern(&lf[212],22,"\004coreforeign-primitive");
lf[213]=C_h_intern(&lf[213],33,"\010compilerexpand-foreign-primitive");
lf[214]=C_h_intern(&lf[214],28,"\004coredefine-foreign-variable");
lf[215]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[216]=C_h_intern(&lf[216],14,"symbol->string");
lf[217]=C_h_intern(&lf[217],24,"\004coredefine-foreign-type");
lf[218]=C_h_intern(&lf[218],10,"\003sysvalues");
lf[219]=C_h_intern(&lf[219],5,"cons*");
lf[220]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[221]=C_h_intern(&lf[221],29,"\004coredefine-external-variable");
lf[222]=C_h_intern(&lf[222],9,"c-pointer");
lf[223]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[224]=C_h_intern(&lf[224],13,"string-append");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[226]=C_h_intern(&lf[226],5,"fifth");
lf[227]=C_h_intern(&lf[227],17,"\004corelet-location");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[229]=C_h_intern(&lf[229],10,"\003sysappend");
lf[230]=C_h_intern(&lf[230],14,"\010compilerwords");
lf[231]=C_h_intern(&lf[231],46,"\010compilerestimate-foreign-result-location-size");
lf[232]=C_h_intern(&lf[232],18,"\004coredefine-inline");
lf[233]=C_h_intern(&lf[233],34,"\010compilerextract-mutable-constants");
lf[234]=C_h_intern(&lf[234],20,"\004coredefine-constant");
lf[235]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010constant");
lf[237]=C_h_intern(&lf[237],29,"\010compilercollapsable-literal\077");
lf[238]=C_h_intern(&lf[238],4,"quit");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\0008error in constant evaluation of ~S for named constant ~S");
lf[240]=C_h_intern(&lf[240],22,"with-exception-handler");
lf[241]=C_h_intern(&lf[241],30,"call-with-current-continuation");
lf[242]=C_h_intern(&lf[242],12,"\004coredeclare");
lf[243]=C_h_intern(&lf[243],28,"\010compilerprocess-declaration");
lf[244]=C_h_intern(&lf[244],29,"\004coreforeign-callback-wrapper");
lf[245]=C_h_intern(&lf[245],8,"split-at");
lf[246]=C_h_intern(&lf[246],1,"r");
lf[247]=C_h_intern(&lf[247],17,"\003sysmake-c-string");
lf[248]=C_h_intern(&lf[248],3,"and");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000/not a valid result type for callback procedures");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\020nonnull-c-string\376\377\016");
lf[251]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\031nonnull-unsigned-c-string\376\377\016");
lf[252]=C_h_intern(&lf[252],25,"nonnull-unsigned-c-string");
lf[253]=C_h_intern(&lf[253],16,"nonnull-c-string");
lf[254]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\011c-string*\376\377\016");
lf[255]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\022unsigned-c-string*\376\377\016");
lf[256]=C_h_intern(&lf[256],18,"unsigned-c-string*");
lf[257]=C_h_intern(&lf[257],9,"c-string*");
lf[258]=C_h_intern(&lf[258],13,"c-string-list");
lf[259]=C_h_intern(&lf[259],14,"c-string-list*");
lf[260]=C_h_intern(&lf[260],8,"c-string");
lf[261]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\021unsigned-c-string\376\377\016");
lf[262]=C_h_intern(&lf[262],17,"unsigned-c-string");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\010c-string\376\377\016");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000Anon-matching or invalid argument list to foreign callback-wrapper");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000<name `~S\047 of external definition is not a valid C identifier");
lf[266]=C_h_intern(&lf[266],28,"\010compilervalid-c-identifier\077");
lf[267]=C_h_intern(&lf[267],8,"location");
lf[268]=C_h_intern(&lf[268],17,"\003sysmake-locative");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010location\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[270]=C_h_intern(&lf[270],13,"\004corecallunit");
lf[271]=C_h_intern(&lf[271],14,"\004coreprimitive");
lf[272]=C_h_intern(&lf[272],37,"\010compilerupdate-line-number-database!");
lf[273]=C_h_intern(&lf[273],23,"\003sysmacroexpand-1-local");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000#(in line ~s) - malformed expression");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[276]=C_h_intern(&lf[276],31,"\010compileremit-syntax-trace-info");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000 literal in operator position: ~S");
lf[278]=C_h_intern(&lf[278],4,"list");
lf[279]=C_h_intern(&lf[279],1,"t");
lf[280]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[281]=C_h_intern(&lf[281],4,"caar");
lf[282]=C_h_intern(&lf[282],18,"\010compilerconstant\077");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[284]=C_h_intern(&lf[284],26,"\010compilerinternal-bindings");
lf[285]=C_h_intern(&lf[285],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[286]=C_h_intern(&lf[286],7,"reverse");
lf[287]=C_h_intern(&lf[287],22,"\003sysclear-trace-buffer");
lf[288]=C_h_intern(&lf[288],26,"\010compilerdebugging-chicken");
lf[289]=C_h_intern(&lf[289],12,"pretty-print");
lf[290]=C_h_intern(&lf[290],7,"newline");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[293]=C_h_intern(&lf[293],4,"uses");
lf[294]=C_h_intern(&lf[294],29,"\010compilerstring->c-identifier");
lf[295]=C_h_intern(&lf[295],18,"\010compilerstringify");
lf[296]=C_h_intern(&lf[296],17,"register-feature!");
lf[297]=C_h_intern(&lf[297],4,"unit");
lf[298]=C_h_intern(&lf[298],5,"usage");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\0003unit was already given a name (new name is ignored)");
lf[300]=C_h_intern(&lf[300],34,"\010compilerdefault-standard-bindings");
lf[301]=C_h_intern(&lf[301],34,"\010compilerdefault-extended-bindings");
lf[302]=C_h_intern(&lf[302],18,"usual-integrations");
lf[303]=C_h_intern(&lf[303],17,"lset-intersection");
lf[304]=C_h_intern(&lf[304],6,"fixnum");
lf[305]=C_h_intern(&lf[305],17,"fixnum-arithmetic");
lf[306]=C_h_intern(&lf[306],23,"\005matchset-error-control");
lf[307]=C_h_intern(&lf[307],12,"\000unspecified");
lf[308]=C_h_intern(&lf[308],4,"safe");
lf[309]=C_h_intern(&lf[309],18,"interrupts-enabled");
lf[310]=C_h_intern(&lf[310],18,"disable-interrupts");
lf[311]=C_h_intern(&lf[311],15,"disable-warning");
lf[312]=C_h_intern(&lf[312],26,"\010compilerdisabled-warnings");
lf[313]=C_h_intern(&lf[313],12,"safe-globals");
lf[314]=C_h_intern(&lf[314],38,"no-procedure-checks-for-usual-bindings");
lf[315]=C_h_intern(&lf[315],18,"bound-to-procedure");
lf[316]=C_h_intern(&lf[316],15,"foreign-declare");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[318]=C_h_intern(&lf[318],5,"every");
lf[319]=C_h_intern(&lf[319],7,"string\077");
lf[320]=C_h_intern(&lf[320],14,"custom-declare");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[322]=C_h_intern(&lf[322],35,"\010compilerprocess-custom-declaration");
lf[323]=C_h_intern(&lf[323],9,"c-options");
lf[324]=C_h_intern(&lf[324],31,"\010compileremit-control-file-item");
lf[325]=C_h_intern(&lf[325],12,"link-options");
lf[326]=C_h_intern(&lf[326],12,"post-process");
lf[327]=C_h_intern(&lf[327],17,"string-substitute");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\003\134$@");
lf[329]=C_h_intern(&lf[329],24,"pathname-strip-extension");
lf[330]=C_h_intern(&lf[330],5,"block");
lf[331]=C_h_intern(&lf[331],8,"separate");
lf[332]=C_h_intern(&lf[332],20,"keep-shadowed-macros");
lf[333]=C_h_intern(&lf[333],6,"unused");
lf[334]=C_h_intern(&lf[334],3,"not");
lf[335]=C_h_intern(&lf[335],15,"lset-difference");
lf[336]=C_h_intern(&lf[336],6,"inline");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[338]=C_h_intern(&lf[338],15,"run-time-macros");
lf[339]=C_h_intern(&lf[339],25,"\003sysenable-runtime-macros");
lf[340]=C_h_intern(&lf[340],12,"block-global");
lf[341]=C_h_intern(&lf[341],4,"hide");
lf[342]=C_h_intern(&lf[342],6,"export");
lf[343]=C_h_intern(&lf[343],12,"emit-exports");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid `emit-exports\047 declaration");
lf[345]=C_h_intern(&lf[345],30,"emit-external-prototypes-first");
lf[346]=C_h_intern(&lf[346],11,"lambda-lift");
lf[347]=C_h_intern(&lf[347],12,"inline-limit");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000.invalid argument to `inline-limit\047 declaration");
lf[349]=C_h_intern(&lf[349],8,"constant");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000/invalid arguments to `constant\047 declaration: ~S");
lf[351]=C_h_intern(&lf[351],7,"symbol\077");
lf[352]=C_h_intern(&lf[352],6,"import");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000:argument to `import\047 declaration is not a string or symbol");
lf[354]=C_h_intern(&lf[354],9,"partition");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\006<here>");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000!invalid declaration specification");
lf[358]=C_h_intern(&lf[358],17,"make-foreign-stub");
lf[359]=C_h_intern(&lf[359],12,"foreign-stub");
lf[360]=C_h_intern(&lf[360],13,"foreign-stub\077");
lf[361]=C_h_intern(&lf[361],20,"foreign-stub-id-set!");
lf[362]=C_h_intern(&lf[362],14,"\003sysblock-set!");
lf[363]=C_h_intern(&lf[363],15,"foreign-stub-id");
lf[364]=C_h_intern(&lf[364],29,"foreign-stub-return-type-set!");
lf[365]=C_h_intern(&lf[365],24,"foreign-stub-return-type");
lf[366]=C_h_intern(&lf[366],22,"foreign-stub-name-set!");
lf[367]=C_h_intern(&lf[367],17,"foreign-stub-name");
lf[368]=C_h_intern(&lf[368],32,"foreign-stub-argument-types-set!");
lf[369]=C_h_intern(&lf[369],27,"foreign-stub-argument-types");
lf[370]=C_h_intern(&lf[370],32,"foreign-stub-argument-names-set!");
lf[371]=C_h_intern(&lf[371],27,"foreign-stub-argument-names");
lf[372]=C_h_intern(&lf[372],22,"foreign-stub-body-set!");
lf[373]=C_h_intern(&lf[373],17,"foreign-stub-body");
lf[374]=C_h_intern(&lf[374],21,"foreign-stub-cps-set!");
lf[375]=C_h_intern(&lf[375],16,"foreign-stub-cps");
lf[376]=C_h_intern(&lf[376],26,"foreign-stub-callback-set!");
lf[377]=C_h_intern(&lf[377],21,"foreign-stub-callback");
lf[378]=C_h_intern(&lf[378],28,"\010compilercreate-foreign-stub");
lf[379]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\003sysgc\376\003\000\000\002\376\377\006\000\376\377\016\376\377\016");
lf[380]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[382]=C_h_intern(&lf[382],37,"\010compilerestimate-foreign-result-size");
lf[383]=C_h_intern(&lf[383],4,"stub");
lf[384]=C_h_intern(&lf[384],1,"a");
lf[385]=C_h_intern(&lf[385],13,"list-tabulate");
lf[386]=C_h_intern(&lf[386],6,"second");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[389]=C_h_intern(&lf[389],4,"cadr");
lf[390]=C_h_intern(&lf[390],3,"car");
lf[391]=C_h_intern(&lf[391],4,"void");
lf[392]=C_h_intern(&lf[392],24,"\003sysline-number-database");
lf[393]=C_h_intern(&lf[393],31,"\010compilerperform-cps-conversion");
lf[394]=C_h_intern(&lf[394],4,"node");
lf[395]=C_h_intern(&lf[395],11,"\004corelambda");
lf[396]=C_h_intern(&lf[396],9,"\004corecall");
lf[397]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[398]=C_h_intern(&lf[398],16,"\010compilervarnode");
lf[399]=C_h_intern(&lf[399],1,"k");
lf[400]=C_h_intern(&lf[400],13,"\004corevariable");
lf[401]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[402]=C_h_intern(&lf[402],2,"f_");
lf[403]=C_h_intern(&lf[403],26,"make-foreign-callback-stub");
lf[404]=C_h_intern(&lf[404],13,"\010compilerbomb");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\016bad node (cps)");
lf[406]=C_h_intern(&lf[406],15,"\004coreglobal-ref");
lf[407]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\015\004corevariable\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\003\000\000\002\376\001\000\000\017\004coreglo"
"bal-ref\376\377\016");
lf[408]=C_h_intern(&lf[408],6,"values");
lf[409]=C_h_intern(&lf[409],21,"foreign-callback-stub");
lf[410]=C_h_intern(&lf[410],22,"foreign-callback-stub\077");
lf[411]=C_h_intern(&lf[411],29,"foreign-callback-stub-id-set!");
lf[412]=C_h_intern(&lf[412],24,"foreign-callback-stub-id");
lf[413]=C_h_intern(&lf[413],31,"foreign-callback-stub-name-set!");
lf[414]=C_h_intern(&lf[414],26,"foreign-callback-stub-name");
lf[415]=C_h_intern(&lf[415],37,"foreign-callback-stub-qualifiers-set!");
lf[416]=C_h_intern(&lf[416],32,"foreign-callback-stub-qualifiers");
lf[417]=C_h_intern(&lf[417],38,"foreign-callback-stub-return-type-set!");
lf[418]=C_h_intern(&lf[418],33,"foreign-callback-stub-return-type");
lf[419]=C_h_intern(&lf[419],41,"foreign-callback-stub-argument-types-set!");
lf[420]=C_h_intern(&lf[420],36,"foreign-callback-stub-argument-types");
lf[421]=C_h_intern(&lf[421],27,"\010compileranalyze-expression");
lf[422]=C_h_intern(&lf[422],17,"\010compilercollect!");
lf[423]=C_h_intern(&lf[423],10,"references");
lf[424]=C_h_intern(&lf[424],13,"\010compilerput!");
lf[425]=C_h_intern(&lf[425],9,"undefined");
lf[426]=C_h_intern(&lf[426],7,"unknown");
lf[427]=C_h_intern(&lf[427],5,"value");
lf[428]=C_h_intern(&lf[428],12,"\010compilerget");
lf[429]=C_h_intern(&lf[429],4,"home");
lf[430]=C_h_intern(&lf[430],16,"\010compilerget-all");
lf[431]=C_h_intern(&lf[431],8,"captured");
lf[432]=C_h_intern(&lf[432],6,"global");
lf[433]=C_h_intern(&lf[433],12,"\004corerecurse");
lf[434]=C_h_intern(&lf[434],44,"\010compileroptimizable-rest-argument-operators");
lf[435]=C_h_intern(&lf[435],15,"\010compilercount!");
lf[436]=C_h_intern(&lf[436],16,"o-r/access-count");
lf[437]=C_h_intern(&lf[437],14,"rest-parameter");
lf[438]=C_h_intern(&lf[438],16,"standard-binding");
lf[439]=C_h_intern(&lf[439],10,"call-sites");
lf[440]=C_h_intern(&lf[440],18,"\004coredirect_lambda");
lf[441]=C_h_intern(&lf[441],6,"simple");
lf[442]=C_h_intern(&lf[442],28,"\010compilersimple-lambda-node\077");
lf[443]=C_h_intern(&lf[443],6,"vector");
lf[444]=C_h_intern(&lf[444],12,"contained-in");
lf[445]=C_h_intern(&lf[445],8,"contains");
lf[446]=C_h_intern(&lf[446],8,"assigned");
lf[447]=C_h_intern(&lf[447],16,"assigned-locally");
lf[448]=C_h_intern(&lf[448],15,"potential-value");
lf[449]=C_h_intern(&lf[449],5,"redef");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of standard binding `~S\047");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of extended binding `~S\047");
lf[452]=C_h_intern(&lf[452],16,"extended-binding");
lf[453]=C_h_intern(&lf[453],9,"\004coreproc");
lf[454]=C_h_intern(&lf[454],3,"any");
lf[455]=C_h_intern(&lf[455],9,"replacing");
lf[456]=C_h_intern(&lf[456],10,"replacable");
lf[457]=C_h_intern(&lf[457],9,"removable");
lf[458]=C_h_intern(&lf[458],37,"\010compilerexpression-has-side-effects\077");
lf[459]=C_h_intern(&lf[459],21,"has-unused-parameters");
lf[460]=C_h_intern(&lf[460],13,"explicit-rest");
lf[461]=C_h_intern(&lf[461],11,"collapsable");
lf[462]=C_h_intern(&lf[462],12,"contractable");
lf[463]=C_h_intern(&lf[463],9,"inlinable");
lf[464]=C_h_intern(&lf[464],28,"\010compilerscan-free-variables");
lf[465]=C_h_intern(&lf[465],5,"boxed");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\042global variable `~S\047 is never used");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000:local assignment to unused variable `~S\047 may be unintended");
lf[468]=C_h_intern(&lf[468],23,"\003syshash-table-for-each");
lf[469]=C_h_intern(&lf[469],18,"\010compilerdebugging");
lf[470]=C_h_intern(&lf[470],1,"p");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis gathering phase...");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis traversal phase...");
lf[473]=C_h_intern(&lf[473],37,"\010compilerinitialize-analysis-database");
lf[474]=C_h_intern(&lf[474],35,"\010compilerperform-closure-conversion");
lf[475]=C_h_intern(&lf[475],12,"customizable");
lf[476]=C_h_intern(&lf[476],20,"node-parameters-set!");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\0009known procedure called with wrong number of arguments: ~A");
lf[478]=C_h_intern(&lf[478],28,"\010compilersource-info->string");
lf[479]=C_h_intern(&lf[479],8,"toplevel");
lf[480]=C_h_intern(&lf[480],18,"captured-variables");
lf[481]=C_h_intern(&lf[481],12,"closure-size");
lf[482]=C_h_intern(&lf[482],8,"\004coreref");
lf[483]=C_h_intern(&lf[483],10,"\004coreunbox");
lf[484]=C_h_intern(&lf[484],8,"\004corebox");
lf[485]=C_h_intern(&lf[485],12,"\004coreclosure");
lf[486]=C_h_intern(&lf[486],14,"\010compilerqnode");
lf[487]=C_h_intern(&lf[487],20,"\003sysmake-lambda-info");
lf[488]=C_h_intern(&lf[488],1,"\077");
lf[489]=C_h_intern(&lf[489],8,"->string");
lf[490]=C_h_intern(&lf[490],18,"\010compilerreal-name");
lf[491]=C_h_intern(&lf[491],10,"fold-right");
lf[492]=C_h_intern(&lf[492],10,"boxed-rest");
lf[493]=C_h_intern(&lf[493],6,"filter");
lf[494]=C_h_intern(&lf[494],16,"\004coreupdatebox_i");
lf[495]=C_h_intern(&lf[495],14,"\004coreupdatebox");
lf[496]=C_h_intern(&lf[496],13,"\004coreupdate_i");
lf[497]=C_h_intern(&lf[497],11,"\004coreupdate");
lf[498]=C_h_intern(&lf[498],19,"\010compilerimmediate\077");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\023bad node (closure2)");
lf[500]=C_h_intern(&lf[500],11,"\004coreswitch");
lf[501]=C_h_intern(&lf[501],9,"\004corecond");
lf[502]=C_h_intern(&lf[502],16,"\004coredirect_call");
lf[503]=C_h_intern(&lf[503],11,"\004corereturn");
lf[504]=C_h_intern(&lf[504],1,"o");
lf[505]=C_decode_literal(C_heaptop,"\376B\000\000\026calls to known targets");
lf[506]=C_h_intern(&lf[506],16,"\003sysmake-promise");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000*closure conversion transformation phase...");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\027customizable procedures");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000%closure conversion gathering phase...");
lf[510]=C_h_intern(&lf[510],19,"make-lambda-literal");
lf[511]=C_h_intern(&lf[511],14,"lambda-literal");
lf[512]=C_h_intern(&lf[512],15,"lambda-literal\077");
lf[513]=C_h_intern(&lf[513],22,"lambda-literal-id-set!");
lf[514]=C_h_intern(&lf[514],17,"lambda-literal-id");
lf[515]=C_h_intern(&lf[515],28,"lambda-literal-external-set!");
lf[516]=C_h_intern(&lf[516],23,"lambda-literal-external");
lf[517]=C_h_intern(&lf[517],29,"lambda-literal-arguments-set!");
lf[518]=C_h_intern(&lf[518],24,"lambda-literal-arguments");
lf[519]=C_h_intern(&lf[519],34,"lambda-literal-argument-count-set!");
lf[520]=C_h_intern(&lf[520],29,"lambda-literal-argument-count");
lf[521]=C_h_intern(&lf[521],33,"lambda-literal-rest-argument-set!");
lf[522]=C_h_intern(&lf[522],28,"lambda-literal-rest-argument");
lf[523]=C_h_intern(&lf[523],31,"lambda-literal-temporaries-set!");
lf[524]=C_h_intern(&lf[524],26,"lambda-literal-temporaries");
lf[525]=C_h_intern(&lf[525],37,"lambda-literal-callee-signatures-set!");
lf[526]=C_h_intern(&lf[526],32,"lambda-literal-callee-signatures");
lf[527]=C_h_intern(&lf[527],29,"lambda-literal-allocated-set!");
lf[528]=C_h_intern(&lf[528],24,"lambda-literal-allocated");
lf[529]=C_h_intern(&lf[529],35,"lambda-literal-directly-called-set!");
lf[530]=C_h_intern(&lf[530],30,"lambda-literal-directly-called");
lf[531]=C_h_intern(&lf[531],32,"lambda-literal-closure-size-set!");
lf[532]=C_h_intern(&lf[532],27,"lambda-literal-closure-size");
lf[533]=C_h_intern(&lf[533],27,"lambda-literal-looping-set!");
lf[534]=C_h_intern(&lf[534],22,"lambda-literal-looping");
lf[535]=C_h_intern(&lf[535],32,"lambda-literal-customizable-set!");
lf[536]=C_h_intern(&lf[536],27,"lambda-literal-customizable");
lf[537]=C_h_intern(&lf[537],38,"lambda-literal-rest-argument-mode-set!");
lf[538]=C_h_intern(&lf[538],33,"lambda-literal-rest-argument-mode");
lf[539]=C_h_intern(&lf[539],24,"lambda-literal-body-set!");
lf[540]=C_h_intern(&lf[540],19,"lambda-literal-body");
lf[541]=C_h_intern(&lf[541],26,"lambda-literal-direct-set!");
lf[542]=C_h_intern(&lf[542],21,"lambda-literal-direct");
lf[543]=C_h_intern(&lf[543],36,"\010compilerprepare-for-code-generation");
lf[544]=C_h_intern(&lf[544],14,"\004coreimmediate");
lf[545]=C_h_intern(&lf[545],3,"fix");
lf[546]=C_h_intern(&lf[546],4,"bool");
lf[547]=C_h_intern(&lf[547],4,"char");
lf[548]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003nil\376\377\016");
lf[549]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003eof\376\377\016");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\027bad immediate (prepare)");
lf[551]=C_h_intern(&lf[551],36,"\010compilermake-block-variable-literal");
lf[552]=C_h_intern(&lf[552],36,"\010compilerblock-variable-literal-name");
lf[553]=C_h_intern(&lf[553],32,"\010compilerblock-variable-literal\077");
lf[554]=C_h_intern(&lf[554],10,"list-index");
lf[555]=C_h_intern(&lf[555],11,"\004coreglobal");
lf[556]=C_h_intern(&lf[556],10,"\004corelocal");
lf[557]=C_h_intern(&lf[557],12,"\004coreliteral");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000!identified direct recursive calls");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\021bad direct lambda");
lf[560]=C_h_intern(&lf[560],4,"none");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\024unused rest argument");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000 rest argument accessed as vector");
lf[563]=C_h_intern(&lf[563],7,"butlast");
lf[564]=C_h_intern(&lf[564],9,"\004corebind");
lf[565]=C_h_intern(&lf[565],13,"\004coresetlocal");
lf[566]=C_h_intern(&lf[566],16,"\004coresetglobal_i");
lf[567]=C_h_intern(&lf[567],14,"\004coresetglobal");
lf[568]=C_h_intern(&lf[568],1,"=");
lf[569]=C_h_intern(&lf[569],4,"type");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\0000coerced inexact literal number `~S\047 to fixnum ~S");
lf[571]=C_decode_literal(C_heaptop,"\376B\000\000-can not coerce inexact literal `~S\047 to fixnum");
lf[572]=C_h_intern(&lf[572],20,"\010compilerbig-fixnum\077");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000\027fast global assignments");
lf[574]=C_decode_literal(C_heaptop,"\376B\000\000\026fast global references");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\030fast box initializations");
lf[576]=C_decode_literal(C_heaptop,"\376B\000\000\024preparation phase...");
lf[577]=C_h_intern(&lf[577],14,"make-parameter");
C_register_lf2(lf,578,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1770,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1768 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1773,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1771 in k1768 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1774 in k1771 in k1768 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1789,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 311  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1789,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1793,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 312  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 313  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 314  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 315  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1805,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 316  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word ab[152],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1809,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_set_block_item(lf[9],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[10]+1,lf[11]);
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t8=C_set_block_item(lf[15],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t10=C_set_block_item(lf[17],0,C_SCHEME_END_OF_LIST);
t11=C_set_block_item(lf[18],0,C_SCHEME_END_OF_LIST);
t12=C_set_block_item(lf[19],0,C_SCHEME_END_OF_LIST);
t13=C_set_block_item(lf[20],0,C_SCHEME_FALSE);
t14=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t15=C_set_block_item(lf[22],0,C_fix(997));
t16=C_set_block_item(lf[23],0,C_SCHEME_FALSE);
t17=C_set_block_item(lf[24],0,C_SCHEME_FALSE);
t18=C_set_block_item(lf[25],0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[26],0,C_SCHEME_FALSE);
t20=C_set_block_item(lf[27],0,C_SCHEME_FALSE);
t21=C_set_block_item(lf[28],0,C_SCHEME_FALSE);
t22=C_set_block_item(lf[29],0,C_SCHEME_FALSE);
t23=C_set_block_item(lf[30],0,C_SCHEME_FALSE);
t24=C_set_block_item(lf[31],0,C_SCHEME_END_OF_LIST);
t25=C_set_block_item(lf[32],0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[33],0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[34],0,C_SCHEME_FALSE);
t28=C_set_block_item(lf[35],0,C_SCHEME_FALSE);
t29=C_set_block_item(lf[36],0,C_SCHEME_FALSE);
t30=C_set_block_item(lf[37],0,C_SCHEME_FALSE);
t31=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t32=C_set_block_item(lf[39],0,C_SCHEME_FALSE);
t33=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t34=C_set_block_item(lf[41],0,C_fix(-1));
t35=C_set_block_item(lf[42],0,C_SCHEME_TRUE);
t36=C_set_block_item(lf[43],0,C_SCHEME_FALSE);
t37=C_set_block_item(lf[44],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[45],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[46],0,C_SCHEME_TRUE);
t40=C_set_block_item(lf[47],0,C_SCHEME_END_OF_LIST);
t41=C_mutate((C_word*)lf[48]+1,C_fix((C_word)C_DEFAULT_TARGET_HEAP_SIZE));
t42=C_mutate((C_word*)lf[49]+1,C_fix((C_word)C_DEFAULT_TARGET_STACK_SIZE));
t43=C_set_block_item(lf[50],0,C_SCHEME_FALSE);
t44=C_set_block_item(lf[51],0,C_SCHEME_FALSE);
t45=C_set_block_item(lf[52],0,C_fix(0));
t46=C_set_block_item(lf[53],0,C_SCHEME_FALSE);
t47=C_set_block_item(lf[54],0,C_SCHEME_END_OF_LIST);
t48=C_set_block_item(lf[55],0,C_SCHEME_END_OF_LIST);
t49=C_set_block_item(lf[56],0,C_SCHEME_FALSE);
t50=C_set_block_item(lf[57],0,C_SCHEME_FALSE);
t51=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t52=C_set_block_item(lf[59],0,C_SCHEME_FALSE);
t53=C_set_block_item(lf[60],0,C_SCHEME_END_OF_LIST);
t54=C_set_block_item(lf[61],0,C_SCHEME_END_OF_LIST);
t55=C_set_block_item(lf[62],0,C_SCHEME_FALSE);
t56=C_set_block_item(lf[63],0,C_SCHEME_END_OF_LIST);
t57=C_set_block_item(lf[64],0,C_SCHEME_TRUE);
t58=C_set_block_item(lf[65],0,C_SCHEME_FALSE);
t59=C_set_block_item(lf[66],0,C_SCHEME_END_OF_LIST);
t60=C_set_block_item(lf[67],0,C_SCHEME_END_OF_LIST);
t61=C_set_block_item(lf[68],0,C_SCHEME_END_OF_LIST);
t62=C_set_block_item(lf[69],0,C_SCHEME_END_OF_LIST);
t63=C_set_block_item(lf[70],0,C_SCHEME_END_OF_LIST);
t64=C_set_block_item(lf[71],0,C_SCHEME_END_OF_LIST);
t65=C_set_block_item(lf[72],0,C_fix(0));
t66=C_set_block_item(lf[73],0,C_SCHEME_FALSE);
t67=C_set_block_item(lf[74],0,C_SCHEME_END_OF_LIST);
t68=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t69=C_set_block_item(lf[76],0,C_SCHEME_FALSE);
t70=C_set_block_item(lf[77],0,C_SCHEME_END_OF_LIST);
t71=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t72=C_set_block_item(lf[79],0,C_SCHEME_END_OF_LIST);
t73=C_set_block_item(lf[80],0,C_SCHEME_END_OF_LIST);
t74=C_set_block_item(lf[81],0,C_SCHEME_TRUE);
t75=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t76=C_set_block_item(lf[83],0,C_SCHEME_END_OF_LIST);
t77=C_set_block_item(lf[84],0,C_SCHEME_FALSE);
t78=C_set_block_item(lf[85],0,C_SCHEME_END_OF_LIST);
t79=C_set_block_item(lf[86],0,C_SCHEME_END_OF_LIST);
t80=C_set_block_item(lf[87],0,C_SCHEME_END_OF_LIST);
t81=C_set_block_item(lf[88],0,C_SCHEME_FALSE);
t82=C_set_block_item(lf[89],0,C_SCHEME_END_OF_LIST);
t83=C_set_block_item(lf[90],0,C_SCHEME_END_OF_LIST);
t84=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t85=C_set_block_item(lf[92],0,C_SCHEME_TRUE);
t86=C_set_block_item(lf[93],0,C_SCHEME_FALSE);
t87=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1895,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1966,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[243]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4745,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[358]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5690,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[360]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5696,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[361]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5702,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[363]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5711,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5720,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5729,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5738,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5747,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5756,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5765,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5774,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[371]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5783,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[372]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5792,tmp=(C_word)a,a+=2,tmp));
t103=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5801,tmp=(C_word)a,a+=2,tmp));
t104=C_mutate((C_word*)lf[374]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5810,tmp=(C_word)a,a+=2,tmp));
t105=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5819,tmp=(C_word)a,a+=2,tmp));
t106=C_mutate((C_word*)lf[376]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5828,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[377]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5837,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5846,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[205]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6000,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6045,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6090,tmp=(C_word)a,a+=2,tmp));
t112=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6127,tmp=(C_word)a,a+=2,tmp));
t113=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6164,tmp=(C_word)a,a+=2,tmp));
t114=C_mutate((C_word*)lf[272]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6245,tmp=(C_word)a,a+=2,tmp));
t115=C_mutate((C_word*)lf[393]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6335,tmp=(C_word)a,a+=2,tmp));
t116=C_mutate((C_word*)lf[403]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7010,tmp=(C_word)a,a+=2,tmp));
t117=C_mutate((C_word*)lf[410]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7016,tmp=(C_word)a,a+=2,tmp));
t118=C_mutate((C_word*)lf[411]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7022,tmp=(C_word)a,a+=2,tmp));
t119=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7031,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[413]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7040,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7049,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7058,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7067,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[417]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7076,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7085,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7094,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7103,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7112,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[474]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8637,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[510]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9871,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[512]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9877,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[513]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9883,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[514]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9892,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[515]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9901,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[516]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9910,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[517]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9919,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[518]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9928,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[519]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9937,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[520]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9946,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[521]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9955,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[522]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9964,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[523]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9973,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[524]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9982,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[525]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9991,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[526]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10000,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[527]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10009,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[528]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10018,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[529]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10027,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[530]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10036,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[531]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10045,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[532]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10054,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[533]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10063,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[534]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10072,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[535]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10081,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[536]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10090,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[537]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10099,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[538]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10108,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[539]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10117,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[540]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10126,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[541]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10135,tmp=(C_word)a,a+=2,tmp));
t161=C_mutate((C_word*)lf[542]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10144,tmp=(C_word)a,a+=2,tmp));
t162=C_mutate((C_word*)lf[543]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10153,tmp=(C_word)a,a+=2,tmp));
t163=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t163+1)))(2,t163,C_SCHEME_UNDEFINED);}

/* ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[80],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10153,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_fix(0);
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_fix(0);
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_END_OF_LIST;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_fix(0);
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_fix(0);
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_fix(0);
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11148,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11102,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11116,a[2]=t5,a[3]=t25,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11022,a[2]=t7,a[3]=t5,a[4]=t25,a[5]=t24,tmp=(C_word)a,a+=6,tmp);
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10190,a[2]=t3,a[3]=t21,a[4]=t27,a[5]=t26,tmp=(C_word)a,a+=6,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10156,a[2]=t28,a[3]=t27,tmp=(C_word)a,a+=4,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10243,a[2]=t24,a[3]=t23,a[4]=t27,a[5]=t26,a[6]=t3,a[7]=t9,a[8]=t15,a[9]=t17,a[10]=t11,a[11]=t19,a[12]=t31,a[13]=t33,a[14]=t13,a[15]=t28,a[16]=t29,tmp=(C_word)a,a+=17,tmp));
t35=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11010,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t36=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11210,a[2]=t2,a[3]=t31,a[4]=t19,a[5]=t21,a[6]=t23,a[7]=t9,a[8]=t7,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2314 debugging */
t37=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t37))(4,t37,t36,lf[470],lf[576]);}

/* k11208 in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11213,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2315 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10243(t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k11211 in k11208 in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2316 debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[504],lf[575],((C_word*)((C_word*)t0)[2])[1]);}

/* k11214 in k11211 in k11208 in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11219,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2317 debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[504],lf[574],((C_word*)((C_word*)t0)[2])[1]);}

/* k11217 in k11214 in k11211 in k11208 in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2318 debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[504],lf[573],((C_word*)((C_word*)t0)[2])[1]);}

/* k11220 in k11217 in k11214 in k11211 in k11208 in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2319 values */
C_values(6,0,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* mapwalk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_11010(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11010,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11016,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* map */
t7=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a11015 in mapwalk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11016,3,t0,t1,t2);}
/* compiler.scm: 2272 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10243(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10243(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word *a;
loop:
a=C_alloc(131);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10243,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[125]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t11,lf[453]));
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t2);}
else{
t14=(C_word)C_eqp(t11,lf[400]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t9);
/* compiler.scm: 2106 walk-var */
t16=((C_word*)t0)[16];
f_10156(t16,t1,t15,t3,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(t11,lf[406]);
if(C_truep(t15)){
t16=(C_word)C_i_car(t9);
/* compiler.scm: 2109 walk-global */
t17=((C_word*)t0)[15];
f_10190(t17,t1,t16,C_SCHEME_TRUE);}
else{
t16=(C_word)C_eqp(t11,lf[502]);
if(C_truep(t16)){
t17=(C_word)C_i_cadddr(t9);
t18=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t17);
t19=C_mutate(((C_word *)((C_word*)t0)[14])+1,t18);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10301,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2113 mapwalk */
t21=((C_word*)((C_word*)t0)[13])[1];
f_11010(t21,t20,t7,t3,t4,t5);}
else{
t17=(C_word)C_eqp(t11,lf[195]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t9);
t19=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t18);
t20=C_mutate(((C_word *)((C_word*)t0)[14])+1,t19);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10321,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2117 mapwalk */
t22=((C_word*)((C_word*)t0)[13])[1];
f_11010(t22,t21,t7,t3,t4,t5);}
else{
t18=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10345,a[2]=t9,a[3]=t11,a[4]=t1,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10349,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
t21=(C_word)C_i_cadr(t9);
/* compiler.scm: 2120 estimate-foreign-result-size */
t22=C_retrieve(lf[382]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t20,t21);}
else{
t19=(C_word)C_eqp(t11,lf[107]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10373,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10377,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_car(t9);
/* compiler.scm: 2124 estimate-foreign-result-size */
t23=C_retrieve(lf[382]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}
else{
t20=(C_word)C_eqp(t11,lf[485]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t21),C_fix(1));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10394,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2129 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_11010(t25,t24,t7,t3,t4,t5);}
else{
t21=(C_word)C_eqp(t11,lf[484]);
if(C_truep(t21)){
t22=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],C_fix(2));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10421,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_car(t7);
/* compiler.scm: 2133 walk */
t90=t24;
t91=t25;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t22=(C_word)C_eqp(t11,lf[495]);
if(C_truep(t22)){
t23=(C_word)C_i_car(t7);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10437,a[2]=t5,a[3]=t23,a[4]=t11,a[5]=((C_word*)t0)[11],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2137 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_11010(t25,t24,t7,t3,t4,t5);}
else{
t23=(C_word)C_eqp(t11,lf[395]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[440]));
if(C_truep(t24)){
t25=((C_word*)((C_word*)t0)[10])[1];
t26=((C_word*)((C_word*)t0)[9])[1];
t27=((C_word*)((C_word*)t0)[8])[1];
t28=((C_word*)((C_word*)t0)[14])[1];
t29=(C_word)C_eqp(t11,lf[440]);
t30=C_set_block_item(((C_word*)t0)[10],0,C_fix(0));
t31=C_set_block_item(((C_word*)t0)[14],0,C_fix(0));
t32=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_END_OF_LIST);
t33=C_set_block_item(((C_word*)t0)[8],0,C_fix(0));
t34=(C_word)C_i_caddr(t9);
t35=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10493,a[2]=((C_word*)t0)[12],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=t29,a[6]=t26,a[7]=((C_word*)t0)[9],a[8]=t28,a[9]=((C_word*)t0)[14],a[10]=t25,a[11]=((C_word*)t0)[10],a[12]=t27,a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[7],a[15]=t9,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 2157 decompose-lambda-list */
t36=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t1,t34,t35);}
else{
t25=(C_word)C_eqp(t11,lf[152]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t9);
t27=(C_word)C_i_car(t7);
t28=(C_word)C_slot(t27,C_fix(1));
t29=(C_word)C_eqp(lf[484],t28);
t30=(C_truep(t29)?(C_word)C_a_i_list(&a,1,t26):C_SCHEME_END_OF_LIST);
t31=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[10])[1]);
t32=C_mutate(((C_word *)((C_word*)t0)[10])+1,t31);
t33=(C_word)C_a_i_list(&a,1,C_fix(1));
t34=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10677,a[2]=t9,a[3]=t3,a[4]=t5,a[5]=t30,a[6]=t4,a[7]=((C_word*)t0)[12],a[8]=t7,a[9]=t33,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2214 walk */
t90=t34;
t91=t27;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t26=(C_word)C_eqp(t11,lf[175]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t9);
t28=(C_word)C_i_car(t7);
t29=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10718,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,a[7]=t27,a[8]=t5,a[9]=t4,a[10]=t3,a[11]=t28,a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 2220 posq */
t30=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t30))(4,t30,t29,t27,t3);}
else{
t27=(C_word)C_eqp(t11,lf[396]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(t7);
t29=(C_word)C_i_length(t28);
t30=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10838,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=((C_word*)t0)[13],a[8]=t9,a[9]=t11,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 2244 lset-adjoin */
t31=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t31))(5,t31,t30,*((C_word*)lf[568]+1),((C_word*)((C_word*)t0)[9])[1],t29);}
else{
t28=(C_word)C_eqp(t11,lf[433]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10881,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_car(t9))){
t30=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[8])[1]);
t31=C_mutate(((C_word *)((C_word*)t0)[8])+1,t30);
t32=t29;
f_10881(t32,t31);}
else{
t30=t29;
f_10881(t30,C_SCHEME_UNDEFINED);}}
else{
t29=(C_word)C_eqp(t11,lf[102]);
if(C_truep(t29)){
t30=(C_word)C_i_car(t9);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10909,a[2]=((C_word*)t0)[4],a[3]=t30,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnump(t30))){
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10996,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2255 big-fixnum? */
t33=C_retrieve(lf[572]);
((C_proc3)C_retrieve_proc(t33))(3,t33,t32,t30);}
else{
t32=t31;
f_10909(t32,C_SCHEME_FALSE);}}
else{
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10999,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2269 mapwalk */
t31=((C_word*)((C_word*)t0)[13])[1];
f_11010(t31,t30,t7,t3,t4,t5);}}}}}}}}}}}}}}}}}

/* k10997 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10999,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10994 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10909(t2,(C_word)C_i_not(t1));}

/* k10907 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10909(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10909,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2256 immediate-literal */
f_11148(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t2=(C_word)C_eqp(lf[304],C_retrieve(lf[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10930,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_integerp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10957,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2259 big-fixnum? */
t5=C_retrieve(lf[572]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t4=t3;
f_10930(t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10967,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2265 literal */
t4=((C_word*)t0)[2];
f_11022(t4,t3,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2266 immediate? */
t3=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}}

/* k10971 in k10907 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10973,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2266 immediate-literal */
f_11148(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10986,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2267 literal */
t3=((C_word*)t0)[2];
f_11022(t3,t2,((C_word*)t0)[3]);}}

/* k10984 in k10971 in k10907 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10986,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[557],t2,C_SCHEME_END_OF_LIST));}

/* k10965 in k10907 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10967,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[557],t2,C_SCHEME_END_OF_LIST));}

/* k10955 in k10907 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10930(t2,(C_word)C_i_not(t1));}

/* k10928 in k10907 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10930(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10930,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2260 compiler-warning */
t4=C_retrieve(lf[144]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[569],lf[570],((C_word*)t0)[4],t3);}
else{
/* compiler.scm: 2264 quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[571],((C_word*)t0)[4]);}}

/* k10931 in k10928 in k10907 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2263 immediate-literal */
f_11148(((C_word*)t0)[2],t2);}

/* k10879 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10881,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10884,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2251 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_11010(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10882 in k10879 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10884,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10836 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10838,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10850,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[8]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=t4;
f_10850(t7,(C_word)C_eqp(((C_word*)t0)[4],t6));}
else{
t6=t4;
f_10850(t6,C_SCHEME_FALSE);}}

/* k10848 in k10836 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10850(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10841(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10841(t2,C_SCHEME_UNDEFINED);}}

/* k10839 in k10836 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10841,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10844,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2247 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_11010(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10842 in k10839 in k10836 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10844,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10716 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10718,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10734,a[2]=t2,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2222 walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_10243(t4,t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_retrieve(lf[28]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10807,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[13],a[12]=t2,a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_10807(2,t5,t3);}
else{
t5=C_retrieve(lf[16]);
if(C_truep(t5)){
t6=t4;
f_10807(2,t6,t5);}
else{
t6=(C_word)C_i_memq(((C_word*)t0)[7],C_retrieve(lf[17]));
if(C_truep(t6)){
t7=t4;
f_10807(2,t7,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10819,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2228 get */
t8=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[2],((C_word*)t0)[7],lf[438]);}}}}}

/* k10817 in k10716 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10807(2,t2,t1);}
else{
/* compiler.scm: 2229 get */
t2=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[452]);}}

/* k10805 in k10716 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10807,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(C_word)C_i_memq(((C_word*)t0)[13],C_retrieve(lf[31]));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10746,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[12],lf[102]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t7=(C_word)C_i_car(t6);
/* compiler.scm: 2231 immediate? */
t8=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t4,t7);}
else{
t6=t4;
f_10746(2,t6,C_SCHEME_FALSE);}}

/* k10744 in k10805 in k10716 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10746,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[125],((C_word*)t0)[13]));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10752,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10752(t6,t5);}
else{
t4=t3;
f_10752(t4,C_SCHEME_UNDEFINED);}}

/* k10750 in k10744 in k10805 in k10716 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10752(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10752,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[12])?lf[566]:lf[567]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10776,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[11])){
/* compiler.scm: 2237 blockvar-literal */
t4=((C_word*)t0)[4];
f_11116(t4,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2238 literal */
t4=((C_word*)t0)[2];
f_11022(t4,t3,((C_word*)t0)[3]);}}

/* k10774 in k10750 in k10744 in k10805 in k10716 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10776,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10768,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 2240 walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_10243(t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10766 in k10774 in k10750 in k10744 in k10805 in k10716 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10768,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k10732 in k10716 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10734,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[565],((C_word*)t0)[2],t2));}

/* k10675 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10681,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10689,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2215 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10687 in k10675 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10693,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2215 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10691 in k10687 in k10675 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2215 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_10243(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10679 in k10675 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10681,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[564],((C_word*)t0)[2],t2));}

/* a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10493,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=((C_word*)t0)[5],a[10]=t1,a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t4)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10614,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2163 get */
t8=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[4],t4,lf[423]);}
else{
t7=t6;
f_10500(2,t7,C_SCHEME_FALSE);}}

/* k10612 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10620,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2164 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[446]);}

/* k10618 in k10612 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10620,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10500(2,t2,lf[278]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10645,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2165 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],lf[492]);}}

/* k10643 in k10618 in k10612 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_10626(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_not(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10626(t3,(C_truep(t2)?t2:(C_word)C_i_nullp(((C_word*)t0)[2])));}}

/* k10624 in k10618 in k10612 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10500(2,t2,lf[560]);}
else{
/* compiler.scm: 2166 get */
t2=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[437]);}}

/* k10498 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_10503,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10605,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(lf[560],t1);
if(C_truep(t5)){
/* compiler.scm: 2170 butlast */
t6=C_retrieve(lf[563]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[7]);}
else{
t6=t4;
f_10605(2,t6,((C_word*)t0)[7]);}}

/* k10603 in k10498 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2167 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_10243(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10501 in k10498 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10506,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[560]);
if(C_truep(t3)){
/* compiler.scm: 2175 debugging */
t4=C_retrieve(lf[469]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[504],lf[561],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[443]);
if(C_truep(t4)){
/* compiler.scm: 2176 debugging */
t5=C_retrieve(lf[469]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[504],lf[562],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t5=t2;
f_10506(2,t5,C_SCHEME_UNDEFINED);}}}

/* k10504 in k10501 in k10498 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 2178 bomb */
t4=C_retrieve(lf[404]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[559],((C_word*)t0)[8],((C_word*)((C_word*)t0)[15])[1],((C_word*)t0)[5]);}
else{
t4=t2;
f_10509(2,t4,C_SCHEME_UNDEFINED);}}

/* k10507 in k10504 in k10501 in k10498 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10531,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[20],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[17])[1]);
t5=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[9]:(C_word)C_i_memq(((C_word*)t0)[8],C_retrieve(lf[63])));
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10547,a[2]=((C_word*)t0)[19],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[13],a[10]=t4,a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=t3,a[15]=((C_word*)t0)[8],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* compiler.scm: 2190 get */
t7=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[8],lf[481]);}

/* k10545 in k10507 in k10504 in k10501 in k10498 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10547,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t4=((C_word*)t0)[11];
if(C_truep(t4)){
t5=t3;
f_10554(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10573,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2194 debugging */
t7=C_retrieve(lf[469]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,lf[504],lf[558],((C_word*)t0)[15],((C_word*)((C_word*)t0)[2])[1]);}
else{
t6=t3;
f_10554(t6,C_SCHEME_FALSE);}}}

/* k10571 in k10545 in k10507 in k10504 in k10501 in k10498 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10554(t2,C_SCHEME_TRUE);}

/* k10552 in k10545 in k10507 in k10504 in k10501 in k10498 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10554(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10554,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_10558(2,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2196 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[15],lf[475]);}}

/* k10556 in k10552 in k10545 in k10507 in k10504 in k10501 in k10498 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2180 make-lambda-literal */
t2=C_retrieve(lf[510]);
((C_proc17)C_retrieve_proc(t2))(17,t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10529 in k10507 in k10504 in k10501 in k10498 in a10492 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10531,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[12])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[11])+1,((C_word*)t0)[10]);
t5=C_mutate(((C_word *)((C_word*)t0)[9])+1,((C_word*)t0)[8]);
t6=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,4,lf[394],lf[453],t9,C_SCHEME_END_OF_LIST));}

/* k10435 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10440,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10446,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_eqp(lf[400],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t7=(C_word)C_i_car(t6);
t8=t3;
f_10446(t8,(C_word)C_i_memq(t7,((C_word*)t0)[2]));}
else{
t6=t3;
f_10446(t6,C_SCHEME_FALSE);}}

/* k10444 in k10435 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_10440(t4,lf[494]);}
else{
t2=((C_word*)t0)[3];
f_10440(t2,((C_word*)t0)[2]);}}

/* k10438 in k10435 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10440,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}

/* k10419 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10421,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[484],((C_word*)t0)[2],t2));}

/* k10392 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10394,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],lf[485],((C_word*)t0)[2],t1));}

/* k10375 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2124 words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10371 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10373,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10366,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2125 mapwalk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_11010(t5,t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10364 in k10371 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10366,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10347 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2120 words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10343 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10345,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* k10319 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10321,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10299 in walk in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10301,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* walk-var in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10156(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10156,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10160,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2074 posq */
t6=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k10158 in walk-var in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10160,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[556],t2,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2075 keyword? */
t3=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k10173 in k10158 in walk-var in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10175,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10185,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2075 literal */
t3=((C_word*)t0)[5];
f_11022(t3,t2,((C_word*)t0)[4]);}
else{
/* compiler.scm: 2076 walk-global */
t2=((C_word*)t0)[3];
f_10190(t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k10183 in k10173 in k10158 in walk-var in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10185,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[557],t2,C_SCHEME_END_OF_LIST));}

/* walk-global in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10190(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10190,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10194,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_10194(2,t5,t3);}
else{
t5=C_retrieve(lf[28]);
if(C_truep(t5)){
t6=t4;
f_10194(2,t6,t5);}
else{
t6=C_retrieve(lf[16]);
if(C_truep(t6)){
t7=t4;
f_10194(2,t7,t6);}
else{
t7=(C_word)C_i_memq(t2,C_retrieve(lf[17]));
if(C_truep(t7)){
t8=t4;
f_10194(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10235,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2083 get */
t9=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[2],t2,lf[438]);}}}}}

/* k10233 in walk-global in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10194(2,t2,t1);}
else{
/* compiler.scm: 2084 get */
t2=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[452]);}}

/* k10192 in walk-global in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10194,2,t0,t1);}
t2=(C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[31]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10200(t6,t5);}
else{
t4=t3;
f_10200(t4,C_SCHEME_UNDEFINED);}}

/* k10198 in k10192 in walk-global in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_10200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10200,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10210,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
/* compiler.scm: 2090 blockvar-literal */
t3=((C_word*)t0)[3];
f_11116(t3,t2,((C_word*)t0)[5]);}
else{
/* compiler.scm: 2091 literal */
t3=((C_word*)t0)[2];
f_11022(t3,t2,((C_word*)t0)[5]);}}

/* k10208 in k10198 in k10192 in walk-global in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10210,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[555],t2,C_SCHEME_END_OF_LIST));}

/* literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_11022(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11022,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2275 immediate? */
t4=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11027 in literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11029,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2275 immediate-literal */
f_11148(((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11041,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_inexactp(((C_word*)t0)[5]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11055,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2278 list-index */
t4=C_retrieve(lf[554]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_11041(2,t3,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[5]))){
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11081,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
/* compiler.scm: 2284 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11091,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2286 posq */
t3=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}}}}

/* k11089 in k11027 in literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2287 new-literal */
t2=((C_word*)t0)[3];
f_11102(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k11079 in k11027 in literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11081,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_vector(&a,1,((C_word*)t0)[2]));}

/* a11054 in k11027 in literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11055,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_inexactp(t2))){
t3=((C_word*)t0)[2];
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k11039 in k11027 in literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2280 new-literal */
t2=((C_word*)t0)[3];
f_11102(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* blockvar-literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_11116(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11116,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11120,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11132,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2295 list-index */
t5=C_retrieve(lf[554]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a11131 in blockvar-literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11132(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11132,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11139,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2297 block-variable-literal? */
t4=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11137 in a11131 in blockvar-literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11139,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2298 block-variable-literal-name */
t3=C_retrieve(lf[552]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11144 in k11137 in a11131 in blockvar-literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k11118 in blockvar-literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11120,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11130,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2300 make-block-variable-literal */
t3=C_retrieve(lf[551]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k11128 in k11118 in blockvar-literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2300 new-literal */
t2=((C_word*)t0)[3];
f_11102(t2,((C_word*)t0)[2],t1);}

/* new-literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_11102(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11102,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11110,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,t2);
/* compiler.scm: 2291 append */
t6=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k11108 in new-literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* immediate-literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_11148(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11148,NULL,2,t1,t2);}
t3=C_retrieve(lf[2]);
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[394],lf[125],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11161,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_11161(2,t6,(C_word)C_a_i_list(&a,2,lf[545],t2));}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=t5;
f_11161(2,t6,(C_word)C_a_i_list(&a,2,lf[546],t2));}
else{
if(C_truep((C_word)C_charp(t2))){
t6=t5;
f_11161(2,t6,(C_word)C_a_i_list(&a,2,lf[547],t2));}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t6=t5;
f_11161(2,t6,lf[548]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t6=t5;
f_11161(2,t6,lf[549]);}
else{
/* compiler.scm: 2311 bomb */
t6=C_retrieve(lf[404]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[550]);}}}}}}}

/* k11159 in immediate-literal in ##compiler#prepare-for-code-generation in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_11161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11161,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],lf[544],t1,C_SCHEME_END_OF_LIST));}

/* lambda-literal-direct in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10144(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10144,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(15)));}

/* lambda-literal-direct-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10135,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(15),t3);}

/* lambda-literal-body in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10126,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(14)));}

/* lambda-literal-body-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10117,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(14),t3);}

/* lambda-literal-rest-argument-mode in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10108,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(13)));}

/* lambda-literal-rest-argument-mode-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10099,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(13),t3);}

/* lambda-literal-customizable in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10090,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(12)));}

/* lambda-literal-customizable-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10081,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(12),t3);}

/* lambda-literal-looping in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10072,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(11)));}

/* lambda-literal-looping-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10063,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(11),t3);}

/* lambda-literal-closure-size in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10054,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(10)));}

/* lambda-literal-closure-size-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10045,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(10),t3);}

/* lambda-literal-directly-called in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10036(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10036,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(9)));}

/* lambda-literal-directly-called-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10027,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(9),t3);}

/* lambda-literal-allocated in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10018,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* lambda-literal-allocated-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10009,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* lambda-literal-callee-signatures in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_10000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10000,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* lambda-literal-callee-signatures-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9991,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* lambda-literal-temporaries in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9982,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* lambda-literal-temporaries-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9973,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* lambda-literal-rest-argument in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9964(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9964,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* lambda-literal-rest-argument-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9955,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* lambda-literal-argument-count in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9946(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9946,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* lambda-literal-argument-count-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9937,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* lambda-literal-arguments in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9928,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* lambda-literal-arguments-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9919,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* lambda-literal-external in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9910,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* lambda-literal-external-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9901,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* lambda-literal-id in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9892,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* lambda-literal-id-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9883,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* lambda-literal? in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9877,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[511]));}

/* make-lambda-literal in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9871(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16){
C_word tmp;
C_word t17;
C_word ab[17],*a=ab;
if(c!=17) C_bad_argc_2(c,17,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr17,(void*)f_9871,17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,16,lf[511],t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16));}

/* ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[47],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8637,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8640,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8646,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8656,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8667,a[2]=t3,a[3]=t8,a[4]=t10,a[5]=t9,a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9702,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9001,a[2]=t3,a[3]=t16,a[4]=t18,a[5]=t14,a[6]=t8,tmp=(C_word)a,a+=7,tmp));
t20=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9690,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9838,a[2]=t12,a[3]=t7,a[4]=t2,a[5]=t16,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2032 debugging */
t22=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t22))(4,t22,t21,lf[470],lf[509]);}

/* k9836 in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2033 gather */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8667(t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k9839 in k9836 in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9844,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2034 debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[504],lf[508],((C_word*)((C_word*)t0)[2])[1]);}

/* k9842 in k9839 in k9836 in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2035 debugging */
t3=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[470],lf[507]);}

/* k9845 in k9842 in k9839 in k9836 in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9850,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2036 transform */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9001(t3,t2,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k9848 in k9845 in k9842 in k9839 in k9836 in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9853,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_9853(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9863,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9865,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 2038 ##sys#make-promise */
t6=*((C_word*)lf[506]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* a9864 in k9848 in k9845 in k9842 in k9839 in k9836 in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9865,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_length(C_retrieve(lf[63])));}

/* k9861 in k9848 in k9845 in k9842 in k9839 in k9836 in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2038 debugging */
t2=C_retrieve(lf[469]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[504],lf[505],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k9851 in k9848 in k9845 in k9842 in k9839 in k9836 in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* maptransform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_9690(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9690,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9696,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a9695 in maptransform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9696,3,t0,t1,t2);}
/* compiler.scm: 2004 transform */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9001(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_9001(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9001,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[102]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t8,a[11]=t10,a[12]=t2,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_9020(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[125]);
if(C_truep(t13)){
t14=t12;
f_9020(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[453]);
t15=t12;
f_9020(t15,(C_truep(t14)?t14:(C_word)C_eqp(t10,lf[406])));}}}

/* k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_9020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9020,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[400]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9032,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1879 ref-var */
f_9702(t4,((C_word*)t0)[12],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[113]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_9053(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[396]);
if(C_truep(t5)){
t6=t4;
f_9053(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t6)){
t7=t4;
f_9053(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t7)){
t8=t4;
f_9053(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[270]);
if(C_truep(t8)){
t9=t4;
f_9053(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[103]);
if(C_truep(t9)){
t10=t4;
f_9053(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t10)){
t11=t4;
f_9053(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[500]);
if(C_truep(t11)){
t12=t4;
f_9053(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[501]);
if(C_truep(t12)){
t13=t4;
f_9053(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[502]);
if(C_truep(t13)){
t14=t4;
f_9053(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[433]);
if(C_truep(t14)){
t15=t4;
f_9053(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[503]);
if(C_truep(t15)){
t16=t4;
f_9053(t16,t15);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[11],lf[107]);
t17=t4;
f_9053(t17,(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[11],lf[180])));}}}}}}}}}}}}}}}

/* k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_9053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9053,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9059,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1887 maptransform */
t5=((C_word*)((C_word*)t0)[10])[1];
f_9690(t5,t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[152]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9074,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1891 test */
t5=((C_word*)t0)[4];
f_8640(t5,t4,t3,lf[465]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[395]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[6],lf[440]));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9149,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1907 decompose-lambda-list */
t7=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[12],t5,t6);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[175]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_i_car(((C_word*)t0)[9]);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9420,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(lf[102],t8);
if(C_truep(t10)){
t11=(C_word)C_slot(t7,C_fix(2));
t12=(C_word)C_i_car(t11);
/* compiler.scm: 1967 immediate? */
t13=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t9,t12);}
else{
t11=t9;
f_9420(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[271]);
if(C_truep(t6)){
t7=(C_truep(C_retrieve(lf[42]))?C_fix(2):C_fix(1));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(C_word)C_a_i_list(&a,2,t9,C_SCHEME_TRUE);
t11=(C_word)C_a_i_record(&a,4,lf[394],lf[453],t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9569,a[2]=t8,a[3]=((C_word*)t0)[12],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[42]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9576,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9580,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_car(((C_word*)t0)[11]);
/* compiler.scm: 1998 ##sys#make-lambda-info */
t16=C_retrieve(lf[487]);
((C_proc3)C_retrieve_proc(t16))(3,t16,t14,t15);}
else{
t13=t12;
f_9569(t13,C_SCHEME_END_OF_LIST);}}
else{
/* compiler.scm: 2001 bomb */
t7=C_retrieve(lf[404]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[12],lf[499]);}}}}}}

/* k9578 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1998 qnode */
t2=C_retrieve(lf[486]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9574 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9576,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9569(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9567 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_9569(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9569,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[485],((C_word*)t0)[2],t2));}

/* k9418 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9420,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[125],((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1969 posq */
t4=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k9424 in k9418 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9426,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9435,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1971 test */
t3=((C_word*)t0)[3];
f_8640(t3,t2,((C_word*)t0)[2],lf[465]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1983 test */
t3=((C_word*)t0)[3];
f_8640(t3,t2,((C_word*)t0)[2],lf[465]);}}

/* k9494 in k9424 in k9418 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9496,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[494]:lf[495]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1987 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9526,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1991 transform */
t4=((C_word*)((C_word*)t0)[6])[1];
f_9001(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k9524 in k9494 in k9424 in k9418 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9526,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[175],((C_word*)t0)[2],t2));}

/* k9507 in k9494 in k9424 in k9418 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9513,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1988 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9001(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9511 in k9507 in k9494 in k9424 in k9418 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9513,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* k9433 in k9424 in k9418 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9435,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[494]:lf[495]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1975 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}
else{
t2=(C_truep(((C_word*)t0)[8])?lf[496]:lf[497]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1981 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k9480 in k9433 in k9424 in k9418 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9486,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1982 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9001(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9484 in k9480 in k9433 in k9424 in k9418 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9486,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k9460 in k9433 in k9424 in k9418 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9462,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[482],((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9458,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1976 transform */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9001(t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9456 in k9460 in k9433 in k9424 in k9418 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9458,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9149,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1910 filter */
t7=C_retrieve(lf[493]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}

/* a9397 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9398(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9398,3,t0,t1,t2);}
/* compiler.scm: 1910 test */
t3=((C_word*)t0)[2];
f_8640(t3,t1,t2,lf[465]);}

/* k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_9156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9396,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[122]),t1);}

/* k9394 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1911 map */
t2=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_9159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* compiler.scm: 1912 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[123]);}

/* k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9159,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_car(((C_word*)t0)[16]):lf[479]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_9165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,a[18]=t1,a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* compiler.scm: 1914 test */
t4=((C_word*)t0)[2];
f_8640(t4,t3,t2,lf[480]);}

/* k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9165,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* compiler.scm: 1915 test */
t4=((C_word*)t0)[2];
f_8640(t4,t3,((C_word*)t0)[17],lf[481]);}

/* k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9171,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_9177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t2,tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[42]))){
t4=(C_word)C_i_cadr(((C_word*)t0)[20]);
t5=t3;
f_9177(t5,(C_truep(t4)?(C_word)C_i_pairp(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t4=t3;
f_9177(t4,C_SCHEME_FALSE);}}

/* k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_9177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9177,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9180,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=t1,tmp=(C_word)a,a+=21,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1921 test */
t4=((C_word*)t0)[2];
f_8640(t4,t3,((C_word*)t0)[6],lf[465]);}
else{
t3=t2;
f_9180(2,t3,C_SCHEME_FALSE);}}

/* k9361 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9363,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1922 test */
t3=((C_word*)t0)[2];
f_8640(t3,t2,((C_word*)t0)[6],lf[437]);}
else{
t2=((C_word*)t0)[4];
f_9180(2,t2,C_SCHEME_FALSE);}}

/* k9364 in k9361 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t2);
/* compiler.scm: 1923 put! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3,lf[492],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_9180(2,t2,C_SCHEME_FALSE);}}

/* k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9180,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[20])?C_fix(2):C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[19],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_9320,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[20],a[12]=t4,a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t5,a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9324,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9339,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* map */
t9=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a9338 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9339(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9339,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k9322 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdr(t2):((C_word*)t0)[5]);
/* compiler.scm: 1933 build-lambda-list */
t4=C_retrieve(lf[166]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,((C_word*)t0)[2],t3);}

/* k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9320,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],t1);
t3=(C_word)C_i_cadddr(((C_word*)t0)[17]);
t4=(C_word)C_a_i_list(&a,4,((C_word*)t0)[16],((C_word*)t0)[15],t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9254,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t4,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* compiler.scm: 1942 transform */
t7=((C_word*)((C_word*)t0)[2])[1];
f_9001(t7,t5,t6,((C_word*)t0)[18],((C_word*)t0)[6]);}

/* k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9257,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9265,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9279,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1947 unzip1 */
t5=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_9257(2,t3,t1);}}

/* k9277 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9283,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9285,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9284 in k9277 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9285,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9296,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(t2);
/* compiler.scm: 1948 varnode */
t5=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k9294 in a9284 in k9277 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9296,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[484],C_SCHEME_END_OF_LIST,t2));}

/* k9281 in k9277 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1944 fold-right */
t2=C_retrieve(lf[491]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9264 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9265,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[394],lf[152],t5,t6));}

/* k9255 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9257,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[12],((C_word*)t0)[11],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9203,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9242,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9241 in k9255 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9242,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1951 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9248 in a9241 in k9255 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1951 ref-var */
f_9702(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9201 in k9255 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9206,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9217,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9221,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9225,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9233,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1959 real-name */
t7=C_retrieve(lf[490]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t3=t2;
f_9206(2,t3,t1);}}

/* k9231 in k9201 in k9255 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9233,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[488]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* compiler.scm: 1959 ->string */
t5=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k9223 in k9201 in k9255 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1958 ##sys#make-lambda-info */
t2=C_retrieve(lf[487]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9219 in k9201 in k9255 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1957 qnode */
t2=C_retrieve(lf[486]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9215 in k9201 in k9255 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9217,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 1954 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9204 in k9201 in k9255 in k9252 in k9318 in k9178 in k9175 in k9169 in k9163 in k9157 in k9154 in k9151 in a9148 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9206,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[485],((C_word*)t0)[2],t2));}

/* k9072 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1892 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k9075 in k9072 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9077,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9093,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1896 transform */
t5=((C_word*)((C_word*)t0)[6])[1];
f_9001(t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1903 maptransform */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9690(t3,t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k9127 in k9075 in k9072 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9129,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t1));}

/* k9091 in k9075 in k9072 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9093,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9122,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1899 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k9120 in k9091 in k9075 in k9072 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9122,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[484],C_SCHEME_END_OF_LIST,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9114,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 1900 transform */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9001(t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9112 in k9120 in k9091 in k9075 in k9072 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9114,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t4));}

/* k9057 in k9051 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9059,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k9030 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9038,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1880 test */
t3=((C_word*)t0)[3];
f_8640(t3,t2,((C_word*)t0)[2],lf[465]);}

/* k9036 in k9030 in k9018 in transform in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9038,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[483],C_SCHEME_END_OF_LIST,t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ref-var in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_9702(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9702,NULL,4,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9709,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2008 posq */
t9=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t7,t4);}

/* k9707 in ref-var in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9709,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(t1,C_fix(1));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9725,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2011 varnode */
t5=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9723 in k9707 in ref-var in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9725,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[482],((C_word*)t0)[2],t2));}

/* gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8667(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8667,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[102]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t6,a[11]=t8,a[12]=t10,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8686(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[400]);
if(C_truep(t13)){
t14=t12;
f_8686(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[125]);
if(C_truep(t14)){
t15=t12;
f_8686(t15,t14);}
else{
t15=(C_word)C_eqp(t10,lf[453]);
if(C_truep(t15)){
t16=t12;
f_8686(t16,t15);}
else{
t16=(C_word)C_eqp(t10,lf[271]);
t17=t12;
f_8686(t17,(C_truep(t16)?t16:(C_word)C_eqp(t10,lf[406])));}}}}}

/* k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8686,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[12],lf[152]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8697,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8707,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1816 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[12],lf[396]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_cdr(((C_word*)t0)[11]);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_i_cadr(((C_word*)t0)[11]):C_SCHEME_FALSE);
t9=(C_word)C_slot(t4,C_fix(1));
t10=(C_word)C_eqp(lf[400],t9);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8749,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8766,a[2]=((C_word*)t0)[6],a[3]=t11,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t13=(C_truep(t8)?t8:t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8776,a[2]=t8,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t10)){
t15=(C_word)C_slot(t4,C_fix(2));
t16=(C_word)C_i_car(t15);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8782,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t16,a[7]=((C_word*)t0)[5],a[8]=t14,tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8890,a[2]=t16,a[3]=((C_word*)t0)[3],a[4]=t17,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1832 test */
t19=((C_word*)t0)[3];
f_8640(t19,t18,t16,lf[426]);}
else{
t15=t14;
f_8776(t15,C_SCHEME_END_OF_LIST);}}
else{
t14=t12;
f_8766(t14,C_SCHEME_END_OF_LIST);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[12],lf[395]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[12],lf[440]));
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[11]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1856 decompose-lambda-list */
t8=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[13],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8965,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[13],t6,((C_word*)t0)[10]);}}}}}

/* a8964 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8965,3,t0,t1,t2);}
/* compiler.scm: 1866 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8667(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8925 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8926,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_i_car(((C_word*)t0)[6]):lf[479]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=((C_word*)t0)[4];
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9741,a[2]=t12,a[3]=t9,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_9741(3,t14,t10,t6);}

/* walk in a8925 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9741(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9741,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[400]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t10,((C_word*)t0)[4]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9770,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2023 lset-adjoin */
t12=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[129]+1),((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[102]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9779,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t6,a[7]=t8,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9779(t12,t10);}
else{
t12=(C_word)C_eqp(t8,lf[125]);
if(C_truep(t12)){
t13=t11;
f_9779(t13,t12);}
else{
t13=(C_word)C_eqp(t8,lf[271]);
if(C_truep(t13)){
t14=t11;
f_9779(t14,t13);}
else{
t14=(C_word)C_eqp(t8,lf[453]);
if(C_truep(t14)){
t15=t11;
f_9779(t15,t14);}
else{
t15=(C_word)C_eqp(t8,lf[103]);
t16=t11;
f_9779(t16,(C_truep(t15)?t15:(C_word)C_eqp(t8,lf[406])));}}}}}}

/* k9777 in walk in a8925 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_9779(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9779,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9791,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9805,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2027 lset-adjoin */
t6=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[129]+1),((C_word*)((C_word*)t0)[2])[1],t3);}
else{
t5=t4;
f_9791(t5,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[8],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}}

/* k9803 in k9777 in walk in a8925 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9791(t3,t2);}

/* k9789 in k9777 in walk in a8925 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_9791(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[4]);
/* compiler.scm: 2028 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9741(3,t3,((C_word*)t0)[2],t2);}

/* k9768 in walk in a8925 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9737 in a8925 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_9739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9739,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[9])[1];
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8939,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1862 put! */
t5=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],lf[481],t3);}

/* k8937 in k9737 in a8925 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8942,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1863 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6],lf[480],((C_word*)t0)[2]);}

/* k8940 in k8937 in k9737 in a8925 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8942,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8953,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1864 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8951 in k8940 in k8937 in k9737 in a8925 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1864 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8667(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8888 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8782(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1832 test */
t2=((C_word*)t0)[3];
f_8640(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[427]);}}

/* k8780 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=t2;
f_8788(t4,(C_word)C_eqp(lf[395],t3));}
else{
t3=t2;
f_8788(t3,C_SCHEME_FALSE);}}

/* k8786 in k8780 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8788,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1837 test */
t6=((C_word*)t0)[2];
f_8640(t6,t5,((C_word*)t0)[6],lf[423]);}
else{
t2=((C_word*)t0)[8];
f_8776(t2,C_SCHEME_END_OF_LIST);}}

/* k8798 in k8786 in k8780 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8803,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1838 test */
t3=((C_word*)t0)[2];
f_8640(t3,t2,((C_word*)t0)[7],lf[439]);}

/* k8801 in k8798 in k8786 in k8780 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8806,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
t6=t2;
f_8806(t6,(C_truep(t5)?(C_word)C_i_listp(((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_8806(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_8806(t3,C_SCHEME_FALSE);}}

/* k8804 in k8801 in k8798 in k8786 in k8780 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8806,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8809,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8824,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(t1)){
t4=(C_word)C_i_length(((C_word*)t0)[3]);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_eqp(t4,t6);
t8=t3;
f_8824(t8,(C_word)C_i_not(t7));}
else{
t4=t3;
f_8824(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8824(t4,C_SCHEME_FALSE);}}

/* k8822 in k8804 in k8801 in k8798 in k8786 in k8780 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8824,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8831,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1846 source-info->string */
t3=C_retrieve(lf[478]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8809(2,t2,C_SCHEME_UNDEFINED);}}

/* k8829 in k8822 in k8804 in k8801 in k8798 in k8786 in k8780 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1844 quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[477],t1);}

/* k8807 in k8804 in k8801 in k8798 in k8786 in k8780 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1847 register-direct-call! */
t3=((C_word*)t0)[2];
f_8656(t3,t2,((C_word*)t0)[6]);}

/* k8810 in k8807 in k8804 in k8801 in k8798 in k8786 in k8780 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8815,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* compiler.scm: 1848 register-customizable! */
t3=((C_word*)t0)[3];
f_8646(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=t2;
f_8815(2,t3,C_SCHEME_UNDEFINED);}}

/* k8813 in k8810 in k8807 in k8804 in k8801 in k8798 in k8786 in k8780 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8815,2,t0,t1);}
t2=((C_word*)t0)[4];
f_8776(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k8774 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8776,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
f_8766(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8764 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8766(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8766,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 1825 node-parameters-set! */
t3=C_retrieve(lf[476]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8747 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8754,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8753 in k8747 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8754,3,t0,t1,t2);}
/* compiler.scm: 1853 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8667(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8706 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8707,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a8723 in a8706 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8724,3,t0,t1,t2);}
/* compiler.scm: 1817 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8667(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8709 in a8706 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8711,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8722,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1818 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8720 in k8709 in a8706 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1818 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8667(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8696 in k8684 in gather in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8697,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
/* compiler.scm: 1816 split-at */
t3=C_retrieve(lf[245]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* register-direct-call! in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8656(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8656,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8665,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1803 lset-adjoin */
t6=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[129]+1),C_retrieve(lf[63]),t2);}

/* k8663 in register-direct-call! in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[63]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* register-customizable! in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8646(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8646,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8651,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1798 lset-adjoin */
t5=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[129]+1),((C_word*)((C_word*)t0)[3])[1],t2);}

/* k8649 in register-customizable! in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* compiler.scm: 1799 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[475],C_SCHEME_TRUE);}

/* test in ##compiler#perform-closure-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8640(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8640,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1795 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7112,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7116,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1416 make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(3001),C_SCHEME_END_OF_LIST);}

/* k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7116,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7118,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7821,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7718,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7125,a[2]=t6,a[3]=t8,a[4]=t10,a[5]=t5,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7706,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7827,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7841,a[2]=t1,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t13,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1586 initialize-analysis-database */
t18=C_retrieve(lf[473]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,t1);}

/* k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1589 debugging */
t3=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[470],lf[472]);}

/* k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7869,2,t0,t1);}
t2=C_set_block_item(lf[52],0,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7873,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1591 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7125(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1594 debugging */
t3=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[470],lf[471]);}

/* k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7879,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1595 ##sys#hash-table-for-each */
t4=C_retrieve(lf[468]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[65],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7889,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_fix(0);
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_FALSE;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_fix(0);
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_fix(0);
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_7893,a[2]=t9,a[3]=t19,a[4]=t13,a[5]=t31,a[6]=((C_word*)t0)[2],a[7]=t21,a[8]=t11,a[9]=t23,a[10]=t3,a[11]=((C_word*)t0)[3],a[12]=t25,a[13]=t29,a[14]=t17,a[15]=t27,a[16]=t2,a[17]=((C_word*)t0)[4],a[18]=t1,a[19]=t7,a[20]=t5,tmp=(C_word)a,a+=21,tmp);
t33=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8524,a[2]=t27,a[3]=t25,a[4]=t7,a[5]=t23,a[6]=t21,a[7]=t19,a[8]=t17,a[9]=t31,a[10]=t15,a[11]=t9,a[12]=t13,a[13]=t29,a[14]=t11,a[15]=t5,tmp=(C_word)a,a+=16,tmp);
/* for-each */
t34=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,t3);}

/* a8523 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8524,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[426]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_TRUE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t3,lf[423]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=C_mutate(((C_word *)((C_word*)t0)[14])+1,t6);
t8=(C_word)C_i_length(((C_word*)((C_word*)t0)[14])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t6=(C_word)C_eqp(t3,lf[431]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[448]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
t9=C_mutate(((C_word *)((C_word*)t0)[11])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t8=(C_word)C_eqp(t3,lf[439]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=C_mutate(((C_word *)((C_word*)t0)[10])+1,t9);
t11=(C_word)C_i_length(((C_word*)((C_word*)t0)[10])[1]);
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=(C_word)C_eqp(t3,lf[446]);
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=(C_word)C_eqp(t3,lf[447]);
if(C_truep(t10)){
t11=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=(C_word)C_eqp(t3,lf[425]);
if(C_truep(t11)){
t12=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=(C_word)C_eqp(t3,lf[432]);
if(C_truep(t12)){
t13=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=(C_word)C_eqp(t3,lf[427]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t2);
t15=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,t15);}
else{
t14=(C_word)C_eqp(t3,lf[436]);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t2);
t16=C_mutate(((C_word *)((C_word*)t0)[3])+1,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t15=(C_word)C_eqp(t3,lf[437]);
if(C_truep(t15)){
t16=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}

/* k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7893,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[19])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[19])+1,t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_7900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8489,a[2]=((C_word*)t0)[16],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[19],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[64]))){
t7=((C_word*)((C_word*)t0)[19])[1];
t8=(C_truep(t7)?t7:(C_truep(((C_word*)((C_word*)t0)[9])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));
t9=(C_truep(t8)?(C_word)C_slot(t8,C_fix(1)):C_SCHEME_FALSE);
t10=t6;
f_8489(t10,(C_word)C_eqp(lf[395],t9));}
else{
t7=t6;
f_8489(t7,C_SCHEME_FALSE);}}

/* k8487 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
/* compiler.scm: 1641 set-real-name! */
t6=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7900(2,t2,C_SCHEME_UNDEFINED);}}

/* k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_7903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[16],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[7])[1]))){
t4=(C_word)C_i_memq(((C_word*)t0)[16],C_retrieve(lf[90]));
t5=t3;
f_8435(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_8435(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8435(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8435(t4,C_SCHEME_FALSE);}}

/* k8433 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8435,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8438,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* compiler.scm: 1650 compiler-warning */
t3=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[185],lf[467],((C_word*)t0)[3]);}
else{
t3=t2;
f_8438(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7903(2,t2,C_SCHEME_UNDEFINED);}}

/* k8436 in k8433 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[21]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8450,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_8450(t5,t3);}
else{
if(C_truep(C_retrieve(lf[33]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t6=t4;
f_8450(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8450(t5,C_SCHEME_FALSE);}}}

/* k8448 in k8436 in k8433 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[60]));
t3=((C_word*)t0)[2];
f_8444(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_8444(t2,C_SCHEME_FALSE);}}

/* k8442 in k8436 in k8433 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1654 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[185],lf[466],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7903(2,t2,C_SCHEME_UNDEFINED);}}

/* k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7906,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[13])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 1658 quick-put! */
f_7827(t2,((C_word*)t0)[8],lf[465],C_SCHEME_TRUE);}
else{
t4=t2;
f_7906(2,t4,C_SCHEME_UNDEFINED);}}

/* k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=((C_word*)((C_word*)t0)[9])[1];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[395],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t4);
t10=(C_word)C_i_not(t9);
if(C_truep(t10)){
t11=t5;
f_8378(2,t11,t10);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8410,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8418,a[2]=t11,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1667 scan-free-variables */
t13=C_retrieve(lf[464]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)((C_word*)t0)[9])[1]);}}
else{
t9=t5;
f_8378(2,t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7909(2,t3,C_SCHEME_UNDEFINED);}}

/* k8416 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1667 every */
t2=C_retrieve(lf[318]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8409 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8410,3,t0,t1,t2);}
/* compiler.scm: 1667 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],t2,lf[432]);}

/* k8376 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8378,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8384,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_8384(t6,(C_word)C_eqp(C_fix(1),t5));}
else{
t5=t2;
f_8384(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_7909(2,t2,C_SCHEME_UNDEFINED);}}

/* k8382 in k8376 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1669 quick-put! */
f_7827(((C_word*)t0)[3],((C_word*)t0)[2],lf[462],C_SCHEME_TRUE);}
else{
/* compiler.scm: 1670 quick-put! */
f_7827(((C_word*)t0)[3],((C_word*)t0)[2],lf[463],C_SCHEME_TRUE);}}

/* k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8340,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t4=((C_word*)((C_word*)t0)[9])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_8340(t6,(C_word)C_eqp(lf[102],t5));}
else{
t4=t3;
f_8340(t4,C_SCHEME_FALSE);}}

/* k8338 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8340(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8340,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1678 collapsable-literal? */
t6=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t2=((C_word*)t0)[4];
f_7912(2,t2,C_SCHEME_UNDEFINED);}}

/* k8347 in k8338 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8352,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_8352(t3,t1);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t2;
f_8352(t4,(C_word)C_eqp(C_fix(1),t3));}}

/* k8350 in k8347 in k8338 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1680 quick-put! */
f_7827(((C_word*)t0)[3],((C_word*)t0)[2],lf[461],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7912(2,t2,C_SCHEME_UNDEFINED);}}

/* k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7915,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8241,a[2]=t2,a[3]=((C_word*)t0)[14],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[395],t7);
if(C_truep(t8)){
t9=((C_word*)((C_word*)t0)[11])[1];
t10=((C_word*)((C_word*)t0)[2])[1];
t11=t5;
f_8241(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t5;
f_8241(t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7915(2,t3,C_SCHEME_UNDEFINED);}}

/* k8239 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8241(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8241,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[7])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8259,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1694 decompose-lambda-list */
t6=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],t4,t5);}
else{
t4=((C_word*)t0)[2];
f_7915(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
f_7915(2,t2,C_SCHEME_UNDEFINED);}}

/* a8258 in k8239 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8259(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8259,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_8263(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8302,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* a8301 in a8258 in k8239 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8302,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8309,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8327,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1700 get */
t5=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[423]);}

/* k8325 in a8301 in a8258 in k8239 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8327,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8309(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8323,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1701 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[446]);}}

/* k8321 in k8325 in a8301 in a8258 in k8239 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8309(t2,(C_word)C_i_not(t1));}

/* k8307 in a8301 in a8258 in k8239 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8309,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8312,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1702 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[333],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8310 in k8307 in a8301 in a8258 in k8239 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* k8261 in a8258 in k8239 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8269,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[80]));
t4=t2;
f_8269(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_8269(t3,C_SCHEME_FALSE);}}

/* k8267 in k8261 in a8258 in k8239 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8269,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1708 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,lf[459],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[3])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1711 put! */
t5=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t5))(6,t5,((C_word*)t0)[5],((C_word*)t0)[4],t4,lf[460],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7918,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8178,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[10])[1];
if(C_truep(t4)){
t5=t3;
f_8178(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8193,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t6=((C_word*)((C_word*)t0)[7])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[400],t7);
t9=(C_word)C_i_not(t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8205,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[7],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_8205(t11,t9);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8219,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=((C_word*)((C_word*)t0)[7])[1];
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
/* compiler.scm: 1719 get */
t15=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t11,((C_word*)t0)[13],t14,lf[432]);}}
else{
t6=t5;
f_8193(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8178(t5,C_SCHEME_FALSE);}}}

/* k8217 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8205(t2,(C_word)C_i_not(t1));}

/* k8203 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8205(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8205,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8212,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1720 expression-has-side-effects? */
t3=C_retrieve(lf[458]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8193(t2,C_SCHEME_FALSE);}}

/* k8210 in k8203 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8193(t2,(C_word)C_i_not(t1));}

/* k8191 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8193(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_8178(t2,(C_truep(t1)?t1:((C_word*)((C_word*)t0)[2])[1]));}

/* k8176 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8178(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1722 quick-put! */
f_7827(((C_word*)t0)[3],((C_word*)t0)[2],lf[457],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7918(2,t2,C_SCHEME_UNDEFINED);}}

/* k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7921,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_eqp(lf[400],t5);
if(C_truep(t6)){
t7=((C_word*)((C_word*)t0)[5])[1];
t8=(C_word)C_slot(t7,C_fix(2));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8090,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word*)t0)[11],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1734 get */
t11=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,((C_word*)t0)[11],t9,lf[423]);}
else{
t7=t2;
f_7921(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=t2;
f_7921(2,t4,C_SCHEME_UNDEFINED);}}

/* k8088 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8096,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8164,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1735 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[5],lf[426]);}

/* k8162 in k8088 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8096(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1735 get */
t2=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[427]);}}

/* k8094 in k8088 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8099,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_8099(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8154,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1736 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[7],((C_word*)t0)[6],lf[431]);}}

/* k8152 in k8094 in k8088 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8154,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8099(t2,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=((C_word*)t0)[6];
f_8099(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1740 get */
t6=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[446]);}}
else{
t4=((C_word*)t0)[6];
f_8099(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
f_8099(t2,C_SCHEME_FALSE);}}}

/* k8144 in k8152 in k8094 in k8088 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8146,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8099(t2,C_SCHEME_FALSE);}
else{
t2=C_retrieve(lf[21]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_8099(t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8142,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1741 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[432]);}}}

/* k8140 in k8144 in k8152 in k8094 in k8088 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8099(t2,(C_word)C_i_not(t1));}

/* k8097 in k8094 in k8088 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_8099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8099,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8102,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1742 quick-put! */
f_7827(t2,((C_word*)t0)[2],lf[456],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[6];
f_7921(2,t2,C_SCHEME_UNDEFINED);}}

/* k8100 in k8097 in k8094 in k8088 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_8102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1743 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[455],C_SCHEME_TRUE);}

/* k7919 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7924,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_7949(t6,(C_word)C_eqp(lf[395],t5));}
else{
t4=t3;
f_7949(t4,C_SCHEME_FALSE);}}

/* k7947 in k7919 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7949,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=((C_word*)t0)[5];
f_7924(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_caddr(t3);
t5=((C_word*)((C_word*)t0)[6])[1];
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7970,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
t10=(C_word)C_slot(t7,C_fix(1));
t11=t8;
f_7970(t11,(C_word)C_eqp(lf[396],t10));}
else{
t10=t8;
f_7970(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_7970(t9,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[5];
f_7924(2,t2,C_SCHEME_UNDEFINED);}}

/* k7968 in k7947 in k7919 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7970(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7970,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(2),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_slot(t5,C_fix(1));
t9=(C_word)C_eqp(lf[400],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t6,C_fix(1));
t11=(C_word)C_eqp(lf[400],t10);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=(C_word)C_slot(t6,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=t7;
f_7991(t15,(C_word)C_eqp(t12,t14));}
else{
t12=t7;
f_7991(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_7991(t10,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[6];
f_7924(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[6];
f_7924(2,t2,C_SCHEME_UNDEFINED);}}

/* k7989 in k7968 in k7947 in k7919 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7991,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7997,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1763 quick-put! */
f_7827(t4,((C_word*)t0)[2],lf[456],t3);}
else{
t2=((C_word*)t0)[5];
f_7924(2,t2,C_SCHEME_UNDEFINED);}}

/* k7995 in k7989 in k7968 in k7947 in k7919 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1764 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[455],C_SCHEME_TRUE);}

/* k7922 in k7919 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7930,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t3)){
t4=t2;
f_7930(t4,C_SCHEME_FALSE);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_7930(t6,(C_word)C_eqp(t4,t5));}}
else{
t3=t2;
f_7930(t3,C_SCHEME_FALSE);}}

/* k7928 in k7922 in k7919 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7930(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7930,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1774 lset-adjoin */
t3=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),C_retrieve(lf[55]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7932 in k7928 in k7922 in k7919 in k7916 in k7913 in k7910 in k7907 in k7904 in k7901 in k7898 in k7891 in a7888 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[55]+1,t1);
/* compiler.scm: 1775 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[437],lf[443]);}

/* k7877 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1781 lset-difference */
t3=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),C_retrieve(lf[55]),((C_word*)((C_word*)t0)[2])[1]);}

/* k7881 in k7877 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7883,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[51]))){
t4=t3;
f_7886(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[51]+1,C_retrieve(lf[52]));
t5=t3;
f_7886(t5,t4);}}

/* k7884 in k7881 in k7877 in k7874 in k7871 in k7867 in k7864 in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7886(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* contains? in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7841(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7841,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7851,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1581 get */
t6=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t2,lf[445]);}}

/* k7849 in contains? in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7851,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1583 any */
t3=C_retrieve(lf[454]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7858 in k7849 in contains? in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7859,3,t0,t1,t2);}
/* compiler.scm: 1583 contains? */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7841(t3,t1,t2,((C_word*)t0)[2]);}

/* quick-put! in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7827(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7827,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7835,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* compiler.scm: 1576 alist-cons */
t7=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t3,t4,t6);}

/* k7833 in quick-put! in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* walkeach in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7706(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7706,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7712,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a7711 in walkeach in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7712,3,t0,t1,t2);}
/* compiler.scm: 1550 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7125(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7125(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7125,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=f_7118(C_fix(1));
t13=(C_word)C_eqp(t11,lf[102]);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_7147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=t9,a[14]=t11,a[15]=t1,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t13)){
t15=t14;
f_7147(t15,t13);}
else{
t15=(C_word)C_eqp(t11,lf[125]);
t16=t14;
f_7147(t16,(C_truep(t15)?t15:(C_word)C_eqp(t11,lf[453])));}}

/* k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7147(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7147,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[400]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7159,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[12],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1432 ref */
t5=((C_word*)t0)[8];
f_7821(t5,t4,t3,((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[406]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7202,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1440 ref */
t6=((C_word*)t0)[8];
f_7821(t6,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[270]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[14],lf[433]));
if(C_truep(t5)){
t6=f_7118(C_fix(1));
/* compiler.scm: 1446 walkeach */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7706(t7,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[396]);
if(C_truep(t6)){
t7=f_7118(C_fix(1));
t8=(C_word)C_i_car(((C_word*)t0)[5]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_slot(t8,C_fix(1));
t11=(C_word)C_eqp(lf[400],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t8,C_fix(2));
t13=(C_word)C_i_car(t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7261,a[2]=t9,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[7]);
/* compiler.scm: 1453 collect! */
t16=C_retrieve(lf[422]);
((C_proc6)C_retrieve_proc(t16))(6,t16,t14,((C_word*)t0)[9],t13,lf[439],t15);}
else{
t12=t9;
f_7238(2,t12,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[152]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7333,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1467 append */
t9=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[10]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[159]);
if(C_truep(t8)){
t9=f_7118(C_fix(1));
t10=(C_word)C_i_car(((C_word*)t0)[13]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7400,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1480 decompose-lambda-list */
t12=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[15],t10,t11);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[395]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[14],lf[440]));
if(C_truep(t10)){
t11=f_7118(C_fix(1));
t12=(C_word)C_i_caddr(((C_word*)t0)[13]);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7444,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1493 decompose-lambda-list */
t14=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[15],t12,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[175]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[13]);
t13=(C_word)C_i_car(((C_word*)t0)[5]);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7554,a[2]=((C_word*)t0)[11],a[3]=t13,a[4]=((C_word*)t0)[2],a[5]=t12,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[5],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[64]))){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7629,a[2]=t13,a[3]=t12,a[4]=((C_word*)t0)[9],a[5]=t14,tmp=(C_word)a,a+=6,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7635,a[2]=((C_word*)t0)[9],a[3]=t12,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1524 get */
t17=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,((C_word*)t0)[9],t12,lf[438]);}
else{
t15=t14;
f_7554(2,t15,C_SCHEME_UNDEFINED);}}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[271]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[14],lf[194]));
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[13]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7662,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7668,a[2]=((C_word*)t0)[4],a[3]=t14,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_i_symbolp(t14))){
/* compiler.scm: 1543 ##sys#hash-table-ref */
t17=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t16,C_retrieve(lf[76]),t14);}
else{
t17=t16;
f_7668(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7668(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7668(2,t17,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 1547 walkeach */
t14=((C_word*)((C_word*)t0)[6])[1];
f_7706(t14,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}}}}}}}}}}}

/* k7666 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1544 set-real-name! */
t2=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7662(2,t2,C_SCHEME_UNDEFINED);}}

/* k7660 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1545 walkeach */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7706(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7633 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7635,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1525 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[449],lf[450],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7644,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1526 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[452]);}}

/* k7642 in k7633 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1527 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[449],lf[451],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7629(2,t2,C_SCHEME_UNDEFINED);}}

/* k7627 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1528 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[448],((C_word*)t0)[2]);}

/* k7552 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7583,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[8]))){
t4=t3;
f_7583(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[9]);
t5=t3;
f_7583(t5,(C_word)C_i_not(t4));}}

/* k7581 in k7552 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7583,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_7118(C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
t4=C_retrieve(lf[21]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7598,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7598(t6,t4);}
else{
if(C_truep(C_retrieve(lf[33]))){
t6=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t7=t5;
f_7598(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_7598(t6,C_SCHEME_FALSE);}}}
else{
t4=t3;
f_7589(t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7557(2,t2,C_SCHEME_UNDEFINED);}}

/* k7596 in k7581 in k7552 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7598,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7602,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1534 lset-adjoin */
t3=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),C_retrieve(lf[31]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7589(t2,C_SCHEME_UNDEFINED);}}

/* k7600 in k7596 in k7581 in k7552 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_7589(t3,t2);}

/* k7587 in k7581 in k7552 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1535 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[432],C_SCHEME_TRUE);}

/* k7555 in k7552 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7560,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7580,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1536 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k7578 in k7555 in k7552 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1536 assign */
t2=((C_word*)t0)[6];
f_7718(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7558 in k7555 in k7552 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[81]))){
t3=t2;
f_7563(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1537 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[447],C_SCHEME_TRUE);}}

/* k7561 in k7558 in k7555 in k7552 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7566,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1538 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[446],C_SCHEME_TRUE);}

/* k7564 in k7561 in k7558 in k7555 in k7552 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1539 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7125(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7444,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[9]);
t6=C_retrieve(lf[52]);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7451,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t1,a[13]=t6,a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7536,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1499 collect! */
t9=C_retrieve(lf[422]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[3],((C_word*)t0)[2],lf[445],t5);}
else{
t8=t7;
f_7451(2,t8,C_SCHEME_UNDEFINED);}}

/* k7534 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1500 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[444],((C_word*)t0)[2]);}

/* k7449 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[9]);}

/* a7525 in k7449 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7526(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7526,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7530,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1503 put! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[3],t2,lf[429],((C_word*)t0)[2]);}

/* k7528 in a7525 in k7449 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1504 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[426],C_SCHEME_TRUE);}

/* k7452 in k7449 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[55]));
t4=(C_truep(t3)?lf[443]:lf[278]);
/* compiler.scm: 1507 put! */
t5=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[437],t4);}
else{
t3=t2;
f_7457(2,t3,C_SCHEME_UNDEFINED);}}

/* k7455 in k7452 in k7449 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7511,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1511 simple-lambda-node? */
t4=C_retrieve(lf[442]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}

/* k7509 in k7455 in k7452 in k7449 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1511 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[441],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
f_7460(2,t2,C_SCHEME_UNDEFINED);}}

/* k7458 in k7455 in k7452 in k7449 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7460,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[82]))){
t4=t3;
f_7463(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[82]+1,((C_word*)t0)[5]);
t5=t3;
f_7463(t5,t4);}}

/* k7461 in k7458 in k7455 in k7452 in k7449 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7463,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7466,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7496,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[2]))){
t4=(C_word)C_eqp(C_retrieve(lf[82]),((C_word*)t0)[5]);
t5=t3;
f_7496(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_7496(t4,C_SCHEME_FALSE);}}

/* k7494 in k7461 in k7458 in k7455 in k7452 in k7449 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_7466(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_7466(t2,C_SCHEME_UNDEFINED);}}

/* k7464 in k7461 in k7458 in k7455 in k7452 in k7449 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7466(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7466,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7469,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7493,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1516 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7491 in k7464 in k7461 in k7458 in k7455 in k7452 in k7449 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1516 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7125(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7467 in k7464 in k7461 in k7458 in k7455 in k7452 in k7449 in a7443 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_cdddr(t4);
t6=(C_word)C_fixnum_difference(C_retrieve(lf[52]),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_car(t5,t6));}

/* a7399 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7400(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7400,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7404,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7418 in a7399 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7419,3,t0,t1,t2);}
/* compiler.scm: 1484 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t1,((C_word*)t0)[2],t2,lf[426],C_SCHEME_TRUE);}

/* k7402 in a7399 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7404,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7408,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7417,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1488 append */
t7=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7415 in k7402 in a7399 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1488 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7125(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7406 in k7402 in a7399 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7331 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7333,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7338,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7338(t5,((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* loop in k7331 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7338(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7338,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7356,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1470 append */
t6=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7365,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[5],a[12]=t3,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1473 put! */
t7=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,((C_word*)t0)[2],t4,lf[429],((C_word*)t0)[8]);}}

/* k7363 in loop in k7331 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7368,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1474 assign */
t3=((C_word*)t0)[4];
f_7718(t3,t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k7366 in k7363 in loop in k7331 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7371,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1475 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7125(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7369 in k7366 in k7363 in loop in k7331 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1476 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7338(t4,((C_word*)t0)[2],t2,t3);}

/* k7354 in loop in k7331 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1470 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7125(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7259 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1455 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],lf[438]);}

/* k7307 in k7259 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7309,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_memq(((C_word*)t0)[5],C_retrieve(lf[434])):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7272,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
t3=((C_word*)t0)[2];
f_7238(2,t3,C_SCHEME_UNDEFINED);}}

/* a7271 in k7307 in k7259 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7272,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[400],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7291,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1461 get */
t10=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],t8,lf[437]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7289 in a7271 in k7307 in k7259 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1461 count! */
t2=C_retrieve(lf[435]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[436]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7236 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* compiler.scm: 1463 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7125(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k7239 in k7236 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* compiler.scm: 1464 walkeach */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7706(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7200 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_7118(C_fix(1));
/* compiler.scm: 1442 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[432],C_SCHEME_TRUE);}

/* k7157 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7159,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_7118(C_fix(1));
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[3]))){
/* compiler.scm: 1435 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],lf[431],C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7190,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1436 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7],lf[432]);}}}

/* k7188 in k7157 in k7145 in walk in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1436 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[432],C_SCHEME_TRUE);}}

/* assign in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7718(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7718,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[125],t7);
if(C_truep(t8)){
/* compiler.scm: 1554 put! */
t9=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t1,((C_word*)t0)[2],t2,lf[425],C_SCHEME_TRUE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7731,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=t3;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[400],t11);
if(C_truep(t12)){
t13=t3;
t14=(C_word)C_slot(t13,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=t9;
f_7731(t16,(C_word)C_eqp(t2,t15));}
else{
t13=t9;
f_7731(t13,C_SCHEME_FALSE);}}}

/* k7729 in assign in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7731(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7731,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[21]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7740,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7740(t4,t2);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_7740(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1559 get */
t6=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[6],((C_word*)t0)[5],lf[349]);}}}}

/* k7789 in k7729 in assign in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_7740(t2,(C_truep(t1)?t1:(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[31]))));}

/* k7738 in k7729 in assign in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7740,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1562 get-all */
t3=C_retrieve(lf[430]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[426],lf[427]);}
else{
/* compiler.scm: 1570 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[426],C_SCHEME_TRUE);}}

/* k7741 in k7738 in k7729 in assign in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1563 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[429]);}

/* k7744 in k7741 in k7738 in k7729 in assign in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_assq(lf[426],((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep((C_word)C_i_assq(lf[427],((C_word*)t0)[7]))){
/* compiler.scm: 1566 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[426],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_not(t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[3],t1));
if(C_truep(t3)){
/* compiler.scm: 1568 put! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[427],((C_word*)t0)[2]);}
else{
/* compiler.scm: 1569 put! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[426],C_SCHEME_TRUE);}}}}

/* ref in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_7821(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7821,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1573 collect! */
t4=C_retrieve(lf[422]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t2,lf[423],t3);}

/* grow in k7114 in ##compiler#analyze-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static C_word C_fcall f_7118(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_fixnum_plus(C_retrieve(lf[52]),t1);
t3=C_mutate((C_word*)lf[52]+1,t2);
return(t3);}

/* foreign-callback-stub-argument-types in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7103,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-callback-stub-argument-types-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7094,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-callback-stub-return-type in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7085(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7085,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-callback-stub-return-type-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7076,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-callback-stub-qualifiers in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7067(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7067,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-callback-stub-qualifiers-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7058,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-callback-stub-name in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7049,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-callback-stub-name-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7040,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-callback-stub-id in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7031,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-callback-stub-id-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7022,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-callback-stub? in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7016,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[409]));}

/* make-foreign-callback-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_7010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7010,7,t0,t1,t2,t3,t4,t5,t6);}
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,6,lf[409],t2,t3,t4,t5,t6));}

/* ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6335(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6335,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6338,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6382,a[2]=t8,a[3]=t10,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t17=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6756,a[2]=t12,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t18=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6881,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6897,a[2]=t14,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t20=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6982,a[2]=t14,tmp=(C_word)a,a+=3,tmp));
/* compiler.scm: 1400 walk */
t21=((C_word*)t6)[1];
f_6382(t21,t1,t2,*((C_word*)lf[408]+1));}

/* atomic? in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6982,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_i_memq(t4,lf[407]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_truep((C_word)C_eqp(t4,lf[194]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[195]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[103]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[177]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[107]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[180]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
/* compiler.scm: 1398 every */
t8=C_retrieve(lf[318]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,((C_word*)((C_word*)t0)[2])[1],t7);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* walk-arguments in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6897(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6897,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6903(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in walk-arguments in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6903(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6903,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6917,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1381 reverse */
t5=*((C_word*)lf[286]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6923,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t2);
/* compiler.scm: 1382 atomic? */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6982(3,t6,t4,t5);}}

/* k6921 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6923,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* compiler.scm: 1383 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6903(t5,((C_word*)t0)[3],t2,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6941,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1385 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[384]);}}

/* k6939 in k6921 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6941,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6950,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1386 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6382(t4,((C_word*)t0)[2],t2,t3);}

/* a6949 in k6939 in k6921 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6950,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6964,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6976,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1391 varnode */
t7=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k6974 in a6949 in k6939 in k6921 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6976,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* compiler.scm: 1390 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6903(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6962 in a6949 in k6939 in k6921 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6964,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* k6915 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1381 wk */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* walk-inline-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6881(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6881,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6887,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1374 walk-arguments */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6897(t7,t1,t4,t6);}

/* a6886 in walk-inline-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6887,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[394],t3,t4,t2);
/* compiler.scm: 1377 k */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t5);}

/* walk-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6756(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6756,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6760,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1350 gensym */
t7=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[399]);}

/* k6758 in walk-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1351 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k6761 in k6758 in walk-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6763,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* gensym */
t4=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[402]);}

/* k6815 in k6761 in k6758 in walk-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6817,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[11]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6813,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1355 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[11]);}

/* k6811 in k6815 in k6761 in k6758 in walk-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1355 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6807 in k6815 in k6761 in k6758 in walk-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6809,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[395],((C_word*)t0)[10],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6786,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6788,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1356 walk-arguments */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6897(t6,t4,((C_word*)t0)[2],t5);}

/* a6787 in k6807 in k6815 in k6761 in k6758 in walk-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6788,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6794,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1359 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6382(t4,t1,((C_word*)t0)[2],t3);}

/* a6793 in a6787 in k6807 in k6815 in k6761 in k6758 in walk-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6794,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6798,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6805,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1361 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6803 in a6793 in a6787 in k6807 in k6815 in k6761 in k6758 in walk-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1361 cons* */
t2=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6796 in a6793 in a6787 in k6807 in k6815 in k6761 in k6758 in walk-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6798,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],lf[396],((C_word*)t0)[2],t1));}

/* k6784 in k6807 in k6815 in k6761 in k6758 in walk-call in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6786,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6382(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6382,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[400]);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6404,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t11,a[10]=t2,a[11]=t1,a[12]=t3,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t12)){
t14=t13;
f_6404(t14,t12);}
else{
t14=(C_word)C_eqp(t11,lf[102]);
if(C_truep(t14)){
t15=t13;
f_6404(t15,t14);}
else{
t15=(C_word)C_eqp(t11,lf[125]);
if(C_truep(t15)){
t16=t13;
f_6404(t16,t15);}
else{
t16=(C_word)C_eqp(t11,lf[271]);
t17=t13;
f_6404(t17,(C_truep(t16)?t16:(C_word)C_eqp(t11,lf[406])));}}}}

/* k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6404(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6404,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1307 k */
t2=((C_word*)t0)[12];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[113]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6416,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1308 gensym */
t4=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[399]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[152]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6510,a[2]=t5,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6510(t7,((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[8]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[159]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6572,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t6=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[402]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[175]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6585,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1330 gensym */
t7=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[279]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[244]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6635,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t8=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[402]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[194]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t9=t8;
f_6670(t9,t7);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[195]);
if(C_truep(t9)){
t10=t8;
f_6670(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[103]);
if(C_truep(t10)){
t11=t8;
f_6670(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[9],lf[177]);
if(C_truep(t11)){
t12=t8;
f_6670(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[9],lf[107]);
t13=t8;
f_6670(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[9],lf[180])));}}}}}}}}}}}

/* k6668 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6670(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6670,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1344 walk-inline-call */
t2=((C_word*)((C_word*)t0)[9])[1];
f_6881(t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[396]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 1345 walk-call */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6756(t5,((C_word*)t0)[8],t3,t4,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[270]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=((C_word*)t0)[8];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6827,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1364 gensym */
t8=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[399]);}
else{
/* compiler.scm: 1347 bomb */
t4=C_retrieve(lf[404]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[8],lf[405]);}}}}

/* k6825 in k6668 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1365 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k6828 in k6825 in k6668 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6830,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* gensym */
t4=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[402]);}

/* k6873 in k6828 in k6825 in k6668 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6875,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6871,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1369 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}

/* k6869 in k6873 in k6828 in k6825 in k6668 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1369 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6865 in k6873 in k6828 in k6825 in k6668 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6867,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[395],((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1371 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6861 in k6865 in k6873 in k6828 in k6825 in k6668 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6863,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[270],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t4));}

/* k6633 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6635,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6661,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_apply(5,0,t3,C_retrieve(lf[403]),t1,((C_word*)t0)[2]);}

/* k6659 in k6633 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6661,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[68]));
t3=C_mutate((C_word*)lf[68]+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* compiler.scm: 1341 cps-lambda */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6338(t7,((C_word*)t0)[4],((C_word*)t0)[3],t5,t6,((C_word*)t0)[2]);}

/* k6583 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6585,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6594,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1331 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6382(t4,((C_word*)t0)[2],t2,t3);}

/* a6593 in k6583 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6594,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,1,t2);
t7=(C_word)C_a_i_record(&a,4,lf[394],lf[175],t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6618,a[2]=t3,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6622,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1335 varnode */
t10=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[4]);}

/* k6620 in a6593 in k6583 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1335 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6616 in a6593 in k6583 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6618,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* k6570 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1329 cps-lambda */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6338(t3,((C_word*)t0)[4],t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6510(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6510,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
/* compiler.scm: 1323 walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6382(t5,t1,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6533,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1324 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6382(t6,t1,t4,t5);}}

/* a6532 in loop in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6533,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6547,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 1328 loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_6510(t8,t5,t6,t7);}

/* k6545 in a6532 in loop in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6547,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* k6414 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1309 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k6417 in k6414 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6495,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* gensym */
t5=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[402]);}

/* k6493 in k6417 in k6414 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6495,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6487,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6491,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1314 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[8]);}

/* k6489 in k6493 in k6417 in k6414 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1314 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6485 in k6493 in k6417 in k6414 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6487,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[395],((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6454,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1315 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6382(t7,t4,t5,t6);}

/* a6459 in k6485 in k6493 in k6417 in k6414 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6460,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* compiler.scm: 1319 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6382(t5,t3,t4,((C_word*)t0)[2]);}

/* k6469 in a6459 in k6485 in k6493 in k6417 in k6414 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6475,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* compiler.scm: 1320 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6382(t4,t2,t3,((C_word*)t0)[2]);}

/* k6473 in k6469 in a6459 in k6485 in k6493 in k6417 in k6414 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6475,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[113],C_SCHEME_END_OF_LIST,t2));}

/* k6452 in k6485 in k6493 in k6417 in k6414 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6454,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* k1 in k6417 in k6414 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6420,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6431,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1310 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6429 in k1 in k6417 in k6414 in k6402 in walk in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6431,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[396],lf[401],t2));}

/* cps-lambda in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6338(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6338,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t5,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1295 gensym */
t7=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[399]);}

/* k6340 in cps-lambda in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],C_SCHEME_TRUE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6359,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6365,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1298 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6382(t7,t4,t5,t6);}

/* a6364 in k6340 in cps-lambda in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6365,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6376,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1300 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6374 in a6364 in k6340 in cps-lambda in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6376,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[396],lf[397],t2));}

/* k6357 in k6340 in cps-lambda in ##compiler#perform-cps-conversion in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6359,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[395],((C_word*)t0)[4],t2);
/* compiler.scm: 1296 k */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* ##compiler#update-line-number-database! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6245,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6248,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6277,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
/* compiler.scm: 1287 walk */
t10=((C_word*)t7)[1];
f_6277(t10,t1,t2);}

/* walk in ##compiler#update-line-number-database! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6277(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6277,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_not_pair_p(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6296,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1282 ##sys#hash-table-ref */
t7=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[392]),t5);}
else{
/* compiler.scm: 1286 mapupdate */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6248(t5,t1,t2);}}}

/* k6294 in walk in ##compiler#update-line-number-database! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6296,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6302,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[6],t2))){
t4=t3;
f_6302(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6319,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1284 alist-cons */
t5=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k6317 in k6294 in walk in ##compiler#update-line-number-database! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1284 ##sys#hash-table-set! */
t2=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[392]),((C_word*)t0)[2],t1);}

/* k6300 in k6294 in walk in ##compiler#update-line-number-database! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1285 mapupdate */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6248(t3,((C_word*)t0)[2],t2);}

/* mapupdate in ##compiler#update-line-number-database! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6248(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6248,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6254,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6254(t6,t1,t2);}

/* loop in mapupdate in ##compiler#update-line-number-database! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6254(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6254,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6264,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* compiler.scm: 1276 walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6277(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6262 in loop in mapupdate in ##compiler#update-line-number-database! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1277 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6254(t3,((C_word*)t0)[2],t2);}

/* ##compiler#expand-foreign-primitive in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6164(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6164,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6168,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_i_stringp(t6);
t8=t3;
f_6168(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_6168(t5,C_SCHEME_FALSE);}}

/* k6166 in ##compiler#expand-foreign-primitive in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6168(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6168,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6171,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6171(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_6171(t3,lf[391]);}}

/* k6169 in k6166 in ##compiler#expand-foreign-primitive in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6171(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6171,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_caddr(((C_word*)t0)[2]);
t4=t2;
f_6174(t4,(C_word)C_i_cadr(t3));}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6174(t4,(C_word)C_i_cadr(t3));}}

/* k6172 in k6169 in k6166 in ##compiler#expand-foreign-primitive in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_6174(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6174,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6177,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6190,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,*((C_word*)lf[389]+1),t4);}

/* k6188 in k6172 in k6169 in k6166 in ##compiler#expand-foreign-primitive in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6175 in k6172 in k6169 in k6166 in ##compiler#expand-foreign-primitive in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6180,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[390]+1),((C_word*)t0)[2]);}

/* k6178 in k6175 in k6172 in k6169 in k6166 in ##compiler#expand-foreign-primitive in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6183,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[389]+1),((C_word*)t0)[2]);}

/* k6181 in k6178 in k6175 in k6172 in k6169 in k6166 in ##compiler#expand-foreign-primitive in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1266 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-callback-lambda* in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6127(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6127,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6137,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6150,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[389]+1),t9);}

/* k6148 in ##compiler#expand-foreign-callback-lambda* in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6135 in ##compiler#expand-foreign-callback-lambda* in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[390]+1),((C_word*)t0)[2]);}

/* k6138 in k6135 in ##compiler#expand-foreign-callback-lambda* in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6143,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[389]+1),((C_word*)t0)[2]);}

/* k6141 in k6138 in k6135 in ##compiler#expand-foreign-callback-lambda* in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1257 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda* in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6090,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6100,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6113,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[389]+1),t9);}

/* k6111 in ##compiler#expand-foreign-lambda* in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6098 in ##compiler#expand-foreign-lambda* in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6103,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[390]+1),((C_word*)t0)[2]);}

/* k6101 in k6098 in ##compiler#expand-foreign-lambda* in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6106,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[389]+1),((C_word*)t0)[2]);}

/* k6104 in k6101 in k6098 in ##compiler#expand-foreign-lambda* in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1249 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#expand-foreign-callback-lambda in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6045,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6052,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1236 symbol->string */
t6=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_6052(2,t6,t4);}
else{
/* compiler.scm: 1238 quit */
t6=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[388],t4);}}}

/* k6050 in ##compiler#expand-foreign-callback-lambda in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6052,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6058,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[386]+1),t5);}

/* k6056 in k6050 in ##compiler#expand-foreign-callback-lambda in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1241 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6000,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6007,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1227 symbol->string */
t6=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_6007(2,t6,t4);}
else{
/* compiler.scm: 1229 quit */
t6=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[387],t4);}}}

/* k6005 in ##compiler#expand-foreign-lambda in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6007,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6013,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[386]+1),t5);}

/* k6011 in k6005 in ##compiler#expand-foreign-lambda in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_6013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1232 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5846,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5850,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t8,a[6]=t4,a[7]=t2,a[8]=t1,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_i_length(t4);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5994,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1200 list-tabulate */
t12=C_retrieve(lf[385]);
((C_proc4)C_retrieve_proc(t12))(4,t12,t9,t10,t11);}

/* a5993 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5994(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5994,3,t0,t1,t2);}
/* compiler.scm: 1200 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[384]);}

/* k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1201 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[383]);}

/* k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1202 gensym */
t3=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 1203 estimate-foreign-result-size */
t3=C_retrieve(lf[382]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}

/* k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1204 set-real-name! */
t3=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5988,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1206 make-foreign-stub */
t3=C_retrieve(lf[358]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[13]);}

/* k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5988,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[67]));
t3=C_mutate((C_word*)lf[67]+1,t2);
t4=(C_truep(((C_word*)t0)[10])?(C_word)C_fixnum_plus(((C_word*)t0)[9],C_fix(24)):((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5872,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_a_i_list(&a,2,lf[271],((C_word*)t0)[2]);
t7=t5;
f_5872(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t5;
f_5872(t6,(C_word)C_a_i_list(&a,2,lf[194],((C_word*)t0)[2]));}}

/* k5870 in k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_5872(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5872,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5875,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5963,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1212 map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[8],((C_word*)t0)[2]);}

/* a5962 in k5870 in k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5963,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5971,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1212 foreign-type-convert-argument */
t5=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k5969 in a5962 in k5870 in k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1212 foreign-type-check */
t2=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5873 in k5870 in k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5886,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[6])?lf[379]:C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5898,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5908,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_cons(&a,2,lf[380],t1);
/* compiler.scm: 1217 append */
t8=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5915,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1218 final-foreign-type */
t7=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[4]);}}

/* k5913 in k5873 in k5870 in k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5918,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1219 words */
t3=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5916 in k5913 in k5873 in k5870 in k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5918,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[381],t2);
t4=(C_word)C_a_i_list(&a,2,lf[102],t1);
t5=(C_word)C_a_i_list(&a,3,lf[195],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5929,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5933,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5937,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[3]);
/* compiler.scm: 1222 append */
t12=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,((C_word*)t0)[2],t11);}

/* k5935 in k5916 in k5913 in k5873 in k5870 in k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1222 finish-foreign-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5931 in k5916 in k5913 in k5873 in k5870 in k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1221 foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5927 in k5916 in k5913 in k5873 in k5870 in k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5929,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5898(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* k5906 in k5873 in k5870 in k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1217 foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5896 in k5873 in k5870 in k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5898,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5884 in k5873 in k5870 in k5986 in k5860 in k5857 in k5854 in k5851 in k5848 in ##compiler#create-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5886,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[159],t2));}

/* foreign-stub-callback in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5837,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* foreign-stub-callback-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5828,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* foreign-stub-cps in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5819,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* foreign-stub-cps-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5810,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* foreign-stub-body in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5801,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* foreign-stub-body-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5792,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* foreign-stub-argument-names in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5783,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-stub-argument-names-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5774,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-stub-argument-types in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5765,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-stub-argument-types-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5756,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-stub-name in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5747,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-stub-name-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5738(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5738,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-stub-return-type in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5729,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-stub-return-type-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5720,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-stub-id in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5711,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-stub-id-set! in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5702,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-stub? in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5696,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[359]));}

/* make-foreign-stub in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word ab[10],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_5690,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,9,lf[359],t2,t3,t4,t5,t6,t7,t8,t9));}

/* ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4745,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4748,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4799,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
f_4799(t5,t1);}

/* a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_4799(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4799,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4803,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=t2;
f_4803(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1025 syntax-error */
t3=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[357],((C_word*)t0)[3]);}}

/* k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word ab[102],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4809,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(t2,lf[293]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4818,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t6,C_retrieve(lf[296]),t5);}
else{
t5=(C_word)C_eqp(t2,lf[297]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4868,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1037 check-decl */
f_4748(t6,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t6=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[300]));
t9=t3;
f_4809(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4915,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1047 append */
t10=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t9,C_retrieve(lf[12]));}}
else{
t7=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t8))){
t9=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[301]));
t10=t3;
f_4809(2,t10,t9);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4940,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1051 append */
t11=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t10,C_retrieve(lf[13]));}}
else{
t8=(C_word)C_eqp(t2,lf[302]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t9))){
t10=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[300]));
t11=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[301]));
t12=t3;
f_4809(2,t12,t11);}
else{
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4969,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1058 lset-intersection */
t12=C_retrieve(lf[303]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[129]+1),t10,C_retrieve(lf[300]));}}
else{
t9=(C_word)C_eqp(t2,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4986,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1061 check-decl */
f_4748(t10,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t10=(C_word)C_eqp(t2,lf[304]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[305]));
if(C_truep(t11)){
t12=C_mutate((C_word*)lf[10]+1,lf[304]);
t13=t3;
f_4809(2,t13,t12);}
else{
t12=(C_word)C_eqp(t2,lf[11]);
if(C_truep(t12)){
t13=C_mutate((C_word*)lf[10]+1,lf[11]);
t14=t3;
f_4809(2,t14,t13);}
else{
t13=(C_word)C_eqp(t2,lf[16]);
if(C_truep(t13)){
t14=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1067 ##match#set-error-control */
t15=C_retrieve(lf[306]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t3,lf[307]);}
else{
t14=(C_word)C_eqp(t2,lf[308]);
if(C_truep(t14)){
t15=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t16=t3;
f_4809(2,t16,t15);}
else{
t15=(C_word)C_eqp(t2,lf[28]);
if(C_truep(t15)){
t16=C_set_block_item(lf[28],0,C_SCHEME_TRUE);
t17=t3;
f_4809(2,t17,t16);}
else{
t16=(C_word)C_eqp(t2,lf[29]);
if(C_truep(t16)){
t17=C_set_block_item(lf[29],0,C_SCHEME_TRUE);
t18=t3;
f_4809(2,t18,t17);}
else{
t17=(C_word)C_eqp(t2,lf[30]);
if(C_truep(t17)){
t18=C_set_block_item(lf[30],0,C_SCHEME_TRUE);
t19=t3;
f_4809(2,t19,t18);}
else{
t18=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t18)){
t19=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t20=t3;
f_4809(2,t20,t19);}
else{
t19=(C_word)C_eqp(t2,lf[310]);
if(C_truep(t19)){
t20=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t21=t3;
f_4809(2,t21,t20);}
else{
t20=(C_word)C_eqp(t2,lf[311]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5069,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1074 append */
t23=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t23))(4,t23,t21,t22,C_retrieve(lf[312]));}
else{
t21=(C_word)C_eqp(t2,lf[17]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5083,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1075 append */
t24=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t24))(4,t24,t22,t23,C_retrieve(lf[17]));}
else{
t22=(C_word)C_eqp(t2,lf[313]);
if(C_truep(t22)){
t23=C_set_block_item(lf[34],0,C_SCHEME_TRUE);
t24=t3;
f_4809(2,t24,t23);}
else{
t23=(C_word)C_eqp(t2,lf[314]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5104,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1079 append */
t25=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t25))(5,t25,t24,C_retrieve(lf[300]),C_retrieve(lf[301]),C_retrieve(lf[18]));}
else{
t24=(C_word)C_eqp(t2,lf[315]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5118,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1083 append */
t27=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t27))(4,t27,t25,t26,C_retrieve(lf[18]));}
else{
t25=(C_word)C_eqp(t2,lf[316]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
t27=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5145,a[2]=((C_word*)t0)[4],a[3]=t26,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1087 every */
t28=C_retrieve(lf[318]);
((C_proc4)C_retrieve_proc(t28))(4,t28,t27,*((C_word*)lf[319]+1),t26);}
else{
t26=(C_word)C_eqp(t2,lf[320]);
if(C_truep(t26)){
t27=(C_word)C_i_listp(((C_word*)t0)[4]);
t28=(C_word)C_i_not(t27);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5167,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t28)){
t30=t29;
f_5167(t30,t28);}
else{
t30=(C_word)C_i_cadr(((C_word*)t0)[4]);
t31=(C_word)C_i_listp(t30);
t32=(C_word)C_i_not(t31);
if(C_truep(t32)){
t33=t29;
f_5167(t33,t32);}
else{
t33=(C_word)C_i_cadr(((C_word*)t0)[4]);
t34=(C_word)C_i_length(t33);
t35=t29;
f_5167(t35,(C_word)C_fixnum_lessp(t34,C_fix(3)));}}}
else{
t27=(C_word)C_eqp(t2,lf[323]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
t29=(C_word)C_a_i_cons(&a,2,lf[323],t28);
/* compiler.scm: 1095 emit-control-file-item */
t30=C_retrieve(lf[324]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t3,t29);}
else{
t28=(C_word)C_eqp(t2,lf[325]);
if(C_truep(t28)){
t29=(C_word)C_i_cdr(((C_word*)t0)[4]);
t30=(C_word)C_a_i_cons(&a,2,lf[325],t29);
/* compiler.scm: 1097 emit-control-file-item */
t31=C_retrieve(lf[324]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t3,t30);}
else{
t29=(C_word)C_eqp(t2,lf[326]);
if(C_truep(t29)){
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5257,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1100 pathname-strip-extension */
t31=C_retrieve(lf[329]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,C_retrieve(lf[32]));}
else{
t30=(C_word)C_eqp(t2,lf[330]);
if(C_truep(t30)){
t31=C_set_block_item(lf[21],0,C_SCHEME_TRUE);
t32=t3;
f_4809(2,t32,t31);}
else{
t31=(C_word)C_eqp(t2,lf[331]);
if(C_truep(t31)){
t32=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t33=t3;
f_4809(2,t33,t32);}
else{
t32=(C_word)C_eqp(t2,lf[332]);
if(C_truep(t32)){
t33=C_set_block_item(lf[46],0,C_SCHEME_FALSE);
t34=t3;
f_4809(2,t34,t33);}
else{
t33=(C_word)C_eqp(t2,lf[333]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5305,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t35=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1106 append */
t36=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t36))(4,t36,t34,t35,C_retrieve(lf[90]));}
else{
t34=(C_word)C_eqp(t2,lf[334]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5318,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1108 check-decl */
f_4748(t35,((C_word*)t0)[4],C_fix(1),C_SCHEME_END_OF_LIST);}
else{
t35=(C_word)C_eqp(t2,lf[338]);
if(C_truep(t35)){
t36=C_set_block_item(lf[339],0,C_SCHEME_TRUE);
t37=t3;
f_4809(2,t37,t36);}
else{
t36=(C_word)C_eqp(t2,lf[340]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t2,lf[341]));
if(C_truep(t37)){
t38=(C_word)C_i_cdr(((C_word*)t0)[4]);
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5473,a[2]=t38,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[33]))){
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5481,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1142 lset-difference */
t41=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[129]+1),C_retrieve(lf[33]),t38);}
else{
t40=t39;
f_5473(t40,C_SCHEME_UNDEFINED);}}
else{
t38=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t38)){
t39=(C_word)C_i_cdr(((C_word*)t0)[4]);
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5494,a[2]=t39,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1146 lset-difference */
t41=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[129]+1),C_retrieve(lf[31]),t39);}
else{
t39=(C_word)C_eqp(t2,lf[343]);
if(C_truep(t39)){
t40=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t40))){
/* compiler.scm: 1150 quit */
t41=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t41))(4,t41,t3,lf[344],((C_word*)t0)[4]);}
else{
t41=C_retrieve(lf[43]);
if(C_truep(t41)){
t42=t3;
f_4809(2,t42,C_SCHEME_UNDEFINED);}
else{
t42=(C_word)C_i_cadr(((C_word*)t0)[4]);
t43=C_mutate((C_word*)lf[43]+1,t42);
t44=t3;
f_4809(2,t44,t43);}}}
else{
t40=(C_word)C_eqp(t2,lf[345]);
if(C_truep(t40)){
t41=C_set_block_item(lf[39],0,C_SCHEME_TRUE);
t42=t3;
f_4809(2,t42,t41);}
else{
t41=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t41)){
t42=C_set_block_item(lf[40],0,C_SCHEME_TRUE);
t43=t3;
f_4809(2,t43,t42);}
else{
t42=(C_word)C_eqp(t2,lf[336]);
if(C_truep(t42)){
t43=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t43))){
t44=C_retrieve(lf[41]);
if(C_truep((C_word)C_fixnum_greaterp(t44,C_fix(-1)))){
t45=t3;
f_4809(2,t45,C_SCHEME_UNDEFINED);}
else{
t45=C_set_block_item(lf[41],0,C_fix(10));
t46=t3;
f_4809(2,t46,t45);}}
else{
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5568,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1159 lset-union */
t46=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t44,*((C_word*)lf[129]+1),C_retrieve(lf[86]),t45);}}
else{
t43=(C_word)C_eqp(t2,lf[347]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5585,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1161 check-decl */
f_4748(t44,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t44=(C_word)C_eqp(t2,lf[349]);
if(C_truep(t44)){
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
t46=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5613,a[2]=((C_word*)t0)[4],a[3]=t45,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1169 every */
t47=C_retrieve(lf[318]);
((C_proc4)C_retrieve_proc(t47))(4,t47,t46,*((C_word*)lf[351]+1),t45);}
else{
t45=(C_word)C_eqp(t2,lf[352]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5631,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t47=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5659,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1173 ##sys#call-with-values */
C_call_with_values(4,0,t3,t46,t47);}
else{
/* compiler.scm: 1183 compiler-warning */
t46=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t3,lf[181],lf[356],((C_word*)t0)[4]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* a5658 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5659,4,t0,t1,t2,t3);}
t4=C_set_block_item(lf[45],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5664,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5669,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5668 in a5658 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5669,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,lf[355]);}

/* k5662 in a5658 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[139]),((C_word*)t0)[2]);}

/* a5630 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5637,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1174 partition */
t4=C_retrieve(lf[354]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* a5636 in a5630 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5637,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1178 quit */
t3=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[353],t2);}}}

/* k5611 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5613,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1170 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],C_retrieve(lf[47]));}
else{
/* compiler.scm: 1171 quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[350],((C_word*)t0)[2]);}}

/* k5615 in k5611 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5583 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5585,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5592,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t4=t3;
f_5592(2,t4,t2);}
else{
/* compiler.scm: 1166 quit */
t4=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[348],((C_word*)t0)[3]);}}

/* k5590 in k5583 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5566 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5492 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5498,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[33]);
t5=(C_truep(t4)?t4:C_SCHEME_END_OF_LIST);
/* compiler.scm: 1147 lset-union */
t6=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,*((C_word*)lf[129]+1),((C_word*)t0)[2],t5);}

/* k5496 in k5492 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5479 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_5473(t3,t2);}

/* k5471 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_5473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5473,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5477,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1143 lset-union */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[2],C_retrieve(lf[31]));}

/* k5475 in k5471 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5316 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5318,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
f_4809(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5338,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1113 lset-difference */
t7=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[129]+1),C_retrieve(lf[300]),t6);}}
else{
t4=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t4)){
t5=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t5))){
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[3];
f_4809(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5363,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1117 lset-difference */
t8=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,*((C_word*)lf[129]+1),C_retrieve(lf[301]),t7);}}
else{
t5=(C_word)C_eqp(t2,lf[336]);
if(C_truep(t5)){
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t6))){
t7=C_set_block_item(lf[41],0,C_fix(-1));
t8=((C_word*)t0)[3];
f_4809(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5388,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1121 lset-union */
t9=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[129]+1),C_retrieve(lf[87]),t8);}}
else{
t6=(C_word)C_eqp(t2,lf[302]);
if(C_truep(t6)){
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[3];
f_4809(2,t10,t9);}
else{
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5417,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1128 lset-difference */
t10=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,*((C_word*)lf[129]+1),C_retrieve(lf[300]),t8);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5428,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1131 check-decl */
f_4748(t7,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}}}}}

/* k5426 in k5316 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t3)){
t4=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t5=((C_word*)t0)[2];
f_4809(2,t5,t4);}
else{
t4=(C_word)C_eqp(t2,lf[308]);
if(C_truep(t4)){
t5=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1136 ##match#set-error-control */
t6=C_retrieve(lf[306]);
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[2],lf[307]);}
else{
/* compiler.scm: 1137 compiler-warning */
t5=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],lf[181],lf[337],((C_word*)t0)[3]);}}}

/* k5415 in k5316 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5417,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5421,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1129 lset-difference */
t4=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[129]+1),C_retrieve(lf[301]),((C_word*)t0)[2]);}

/* k5419 in k5415 in k5316 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5386 in k5316 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5361 in k5316 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5336 in k5316 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5303 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5255 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5264,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5266,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5265 in k5255 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5266,3,t0,t1,t2);}
/* string-substitute */
t3=C_retrieve(lf[327]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[328],((C_word*)t0)[2],t2);}

/* k5262 in k5255 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5264,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[326],t1);
/* compiler.scm: 1099 emit-control-file-item */
t3=C_retrieve(lf[324]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5165 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_5167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1092 syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[321],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* compiler.scm: 1093 process-custom-declaration */
t4=C_retrieve(lf[322]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t2,t3);}}

/* k5143 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5145,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5149,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1088 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[19]),((C_word*)t0)[3]);}
else{
/* compiler.scm: 1089 syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[317],((C_word*)t0)[2]);}}

/* k5147 in k5143 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[19]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5116 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5118,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1084 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve(lf[17]));}

/* k5120 in k5116 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5102 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5104,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5108,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1081 append */
t4=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve(lf[300]),C_retrieve(lf[301]),C_retrieve(lf[17]));}

/* k5106 in k5102 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5081 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k5067 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_5069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[312]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k4984 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[10]+1,t2);
t4=((C_word*)t0)[2];
f_4809(2,t4,t3);}

/* k4967 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4969,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4973,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1059 lset-intersection */
t4=C_retrieve(lf[303]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[129]+1),((C_word*)t0)[2],C_retrieve(lf[301]));}

/* k4971 in k4967 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k4938 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k4913 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k4866 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4874,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4898,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1039 stringify */
t5=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4896 in k4866 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1039 string->c-identifier */
t2=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4872 in k4866 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1040 ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_retrieve(lf[88]),lf[297],((C_word*)t0)[2]);}

/* k4875 in k4872 in k4866 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4884,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[9]))){
t4=(C_word)C_i_string_equal_p(C_retrieve(lf[9]),((C_word*)t0)[3]);
t5=t3;
f_4884(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4884(t4,C_SCHEME_FALSE);}}

/* k4882 in k4875 in k4872 in k4866 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_4884(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1042 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[298],lf[299]);}
else{
t2=((C_word*)t0)[2];
f_4880(2,t2,C_SCHEME_UNDEFINED);}}

/* k4878 in k4875 in k4872 in k4866 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[9]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k4816 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[139]),((C_word*)t0)[3]);}
else{
t3=t2;
f_4821(2,t3,C_SCHEME_UNDEFINED);}}

/* k4819 in k4816 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4821,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4855,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1033 ##sys#hash-table-update! */
t5=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[293],t3,t4);}
else{
t2=((C_word*)t0)[2];
f_4809(2,t2,C_SCHEME_UNDEFINED);}}

/* a4854 in k4819 in k4816 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4855,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4848 in k4819 in k4816 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4849,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[129]+1),((C_word*)t0)[2],t2);}

/* k4828 in k4819 in k4816 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4833,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4839,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4838 in k4828 in k4819 in k4816 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4839,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4847,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1034 stringify */
t4=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4845 in a4838 in k4828 in k4819 in k4816 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1034 string->c-identifier */
t2=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4831 in k4828 in k4819 in k4816 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4837,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1035 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[15]),t1);}

/* k4835 in k4831 in k4828 in k4819 in k4816 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[15]+1,t1);
t3=((C_word*)t0)[2];
f_4809(2,t3,t2);}

/* k4807 in k4801 in a4798 in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[292]);}

/* check-decl in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_4748(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4748,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_fixnum_lessp(t6,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4761,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=t8;
f_4761(t9,t7);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4771,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t10=t9;
f_4771(2,t10,C_fix(99999));}
else{
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_4771(2,t11,(C_word)C_i_car(t4));}
else{
/* compiler.scm: 1020 ##sys#error */
t11=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[1],t4);}}}}

/* k4769 in check-decl in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4761(t2,(C_word)C_fixnum_greaterp(((C_word*)t0)[2],t1));}

/* k4759 in check-decl in ##compiler#process-declaration in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_4761(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1021 syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[291],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[41],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1966,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1969,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1981,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2005,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2047,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2138,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2156,a[2]=t5,a[3]=t13,a[4]=t4,a[5]=t11,a[6]=t3,a[7]=t9,a[8]=t7,tmp=(C_word)a,a+=9,tmp));
t17=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4690,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4703,a[2]=t2,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(lf[123],C_retrieve(lf[288])))){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4740,a[2]=t2,a[3]=t18,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1003 newline */
t20=*((C_word*)lf[290]+1);
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}
else{
t19=t18;
f_4703(2,t19,C_SCHEME_UNDEFINED);}}

/* k4738 in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1003 pretty-print */
t2=C_retrieve(lf[289]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4701 in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1004 ##sys#clear-trace-buffer */
t3=C_retrieve(lf[287]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4704 in k4701 in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1008 reverse */
t4=*((C_word*)lf[286]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[78]));}

/* k4719 in k4704 in k4701 in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4721,2,t0,t1);}
t2=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4730,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1011 ##sys#compiler-toplevel-macroexpand-hook */
t4=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4728 in k4719 in k4704 in k4701 in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1012 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[284]),C_retrieve(lf[13]));}

/* k4732 in k4728 in k4719 in k4704 in k4701 in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4734,2,t0,t1);}
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* compiler.scm: 452  ##sys#append */
t4=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4715 in k4704 in k4701 in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4717,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 1006 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2156(t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* mapwalk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_4690(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4690,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4696,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a4695 in mapwalk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4696,3,t0,t1,t2);}
/* compiler.scm: 1001 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2156(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_2156(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2156,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(C_word)C_i_assq(t2,t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2175,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 505  resolve-atom */
t9=((C_word*)((C_word*)t0)[8])[1];
f_2047(t9,t8,t7,t3,t4,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2181,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 507  resolve-atom */
t8=((C_word*)((C_word*)t0)[8])[1];
f_2047(t8,t7,t2,t3,t4,t5);}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t5,a[8]=t4,a[9]=t3,a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* compiler.scm: 509  constant? */
t7=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t7=t6;
f_2193(2,t7,C_SCHEME_FALSE);}}}

/* k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 510  walk-literal */
t2=((C_word*)((C_word*)t0)[12])[1];
f_2138(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_not_pair_p(((C_word*)t0)[10]))){
/* compiler.scm: 511  syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[111],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[5],a[10]=t4,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[9],a[13]=t3,a[14]=((C_word*)t0)[6],tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 515  get-line */
t6=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4551,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* compiler.scm: 977  constant? */
t5=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
/* compiler.scm: 975  syntax-error */
t3=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[11],lf[283],((C_word*)t0)[10]);}}}}}

/* k4549 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4551,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4554,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 978  emit-syntax-trace-info */
t3=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4666,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 982  caar */
t5=*((C_word*)lf[281]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_4566(t4,C_SCHEME_FALSE);}}}

/* k4664 in k4549 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4566(t2,(C_word)C_eqp(lf[159],t1));}

/* k4564 in k4549 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_4566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4566,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4575,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 985  emit-syntax-trace-info */
t5=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4653,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 997  emit-syntax-trace-info */
t3=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4651 in k4564 in k4549 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 998  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4690(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4573 in k4564 in k4549 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 986  ##sys#check-syntax */
t3=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[159],((C_word*)t0)[9],lf[280]);}

/* k4576 in k4573 in k4564 in k4549 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4578,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t3;
f_4587(t6,(C_word)C_eqp(t4,t5));}
else{
t4=t3;
f_4587(t4,C_SCHEME_FALSE);}}

/* k4585 in k4576 in k4573 in k4564 in k4549 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_4587(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4587,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 989  map */
t3=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[278]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 990  gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[279]);}}

/* k4607 in k4585 in k4576 in k4573 in k4564 in k4549 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4609,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[152],t4,t6);
/* compiler.scm: 991  walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_2156(t8,((C_word*)t0)[5],t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4600 in k4585 in k4576 in k4573 in k4564 in k4549 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4602,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[152],t3);
/* compiler.scm: 989  walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2156(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4552 in k4549 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 979  compiler-warning */
t3=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[181],lf[277],((C_word*)t0)[4]);}

/* k4555 in k4552 in k4549 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 980  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4690(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2220,2,t0,t1);}
t2=f_1969(((C_word*)t0)[13],((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2226,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=t2,a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 517  emit-syntax-trace-info */
t4=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[11],C_SCHEME_FALSE);}

/* k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[15]))){
t3=t2;
f_2229(2,t3,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[15],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 520  sprintf */
t4=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[274],((C_word*)t0)[2]);}
else{
/* compiler.scm: 521  syntax-error */
t3=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[275],((C_word*)t0)[15]);}}}

/* k4531 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 520  syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2229,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1,((C_word*)t0)[15]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[15],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 524  ##sys#macroexpand-1-local */
t5=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,((C_word*)t0)[9]);}

/* k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2236,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[15],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 528  ##sys#hash-table-ref */
t4=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[56]),((C_word*)t0)[8]);}
else{
t4=t3;
f_2254(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2245,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=t1,a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 526  update-line-number-database! */
t4=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,((C_word*)t0)[2]);}
else{
t4=t3;
f_2245(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2243 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 527  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2156(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2254,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* compiler.scm: 530  walk */
t4=((C_word*)((C_word*)t0)[13])[1];
f_2156(t4,((C_word*)t0)[12],t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[113]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 535  ##sys#check-syntax */
t4=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[113],((C_word*)t0)[14],lf[116]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[102]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2323,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 543  ##sys#check-syntax */
t5=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[102],((C_word*)t0)[14],lf[117]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[118]);
if(C_truep(t4)){
if(C_truep(C_retrieve(lf[16]))){
t5=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[119]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[14]);
/* compiler.scm: 549  walk */
t6=((C_word*)((C_word*)t0)[13])[1];
f_2156(t6,((C_word*)t0)[12],t5,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[120]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2355,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 552  cadadr */
t7=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[14]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[8],lf[125]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t6)){
t8=t7;
f_2388(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[8],lf[270]);
if(C_truep(t8)){
t9=t7;
f_2388(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[8],lf[271]);
if(C_truep(t9)){
t10=t7;
f_2388(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[8],lf[103]);
t11=t7;
f_2388(t11,(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[8],lf[107])));}}}}}}}}}

/* k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_2388(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word ab[237],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2388,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[126]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[134]),t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[135]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2429,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[12]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2435,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_2435(t9,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[152]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 600  ##sys#check-syntax */
t6=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[152],((C_word*)t0)[12],lf[158]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[159]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[11],lf[160]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 614  ##sys#check-syntax */
t8=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[159],((C_word*)t0)[12],lf[172]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[173]);
if(C_truep(t7)){
t8=(C_word)C_i_cddr(((C_word*)t0)[12]);
t9=(C_word)C_a_i_cons(&a,2,lf[159],t8);
t10=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 649  walk */
t11=((C_word*)((C_word*)t0)[10])[1];
f_2156(t11,((C_word*)t0)[13],t9,((C_word*)t0)[9],((C_word*)t0)[8],t10);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[174]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(((C_word*)t0)[12]);
t10=(C_word)C_i_cddr(((C_word*)t0)[12]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=t10,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=t9,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* map */
t12=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_retrieve(lf[122]),t9);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[175]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],lf[176]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 665  ##sys#check-syntax */
t12=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[175],((C_word*)t0)[12],lf[193]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3100,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 704  unquotify */
t14=((C_word*)t0)[3];
f_2005(3,t14,t12,t13);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3129,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* map */
t15=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,((C_word*)t0)[3],t14);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3158,a[2]=t14,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 712  walk */
t17=((C_word*)((C_word*)t0)[10])[1];
f_2156(t17,t15,t16,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[180]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(((C_word*)t0)[12]);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3179,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=t15,a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t17=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 717  walk */
t18=((C_word*)((C_word*)t0)[10])[1];
f_2156(t18,t16,t17,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[196]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[11],lf[197]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(((C_word*)t0)[12]);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3206,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t17,a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 722  eval */
t19=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t17);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[11],lf[198]);
t18=(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[11],lf[199]));
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3221,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t20=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 726  eval */
t21=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t19,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[11],lf[138]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3234,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 730  ##sys#check-syntax */
t21=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t20,lf[138],((C_word*)t0)[12],lf[203]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[11],lf[204]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 742  expand-foreign-lambda */
t22=C_retrieve(lf[205]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,((C_word*)t0)[12]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[11],lf[206]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 745  expand-foreign-callback-lambda */
t23=C_retrieve(lf[207]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t22,((C_word*)t0)[12]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[11],lf[208]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 748  expand-foreign-lambda* */
t24=C_retrieve(lf[209]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,((C_word*)t0)[12]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[11],lf[210]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3340,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 751  expand-foreign-callback-lambda* */
t25=C_retrieve(lf[211]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,((C_word*)t0)[12]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[11],lf[212]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3353,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 754  expand-foreign-primitive */
t26=C_retrieve(lf[213]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,((C_word*)t0)[12]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[11],lf[214]);
if(C_truep(t25)){
t26=(C_word)C_i_cadr(((C_word*)t0)[12]);
t27=(C_word)C_i_cadr(t26);
t28=(C_word)C_i_caddr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3368,a[2]=((C_word*)t0)[13],a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cadddr(((C_word*)t0)[12]);
t33=t30;
f_3368(2,t33,(C_word)C_i_cadr(t32));}
else{
/* compiler.scm: 761  symbol->string */
t32=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t32))(3,t32,t30,t27);}}
else{
t26=(C_word)C_eqp(((C_word*)t0)[11],lf[217]);
if(C_truep(t26)){
t27=(C_word)C_i_cadr(((C_word*)t0)[12]);
t28=(C_word)C_i_cadr(t27);
t29=(C_word)C_i_caddr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3435,a[2]=t28,a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=t31,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 772  gensym */
t33=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t33))(2,t33,t32);}
else{
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3489,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 785  ##sys#hash-table-set! */
t33=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t33))(5,t33,t32,C_retrieve(lf[65]),t28,t30);}}
else{
t27=(C_word)C_eqp(((C_word*)t0)[11],lf[221]);
if(C_truep(t27)){
t28=(C_word)C_i_cadr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3509,a[2]=t29,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 790  symbol->string */
t31=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,t29);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[11],lf[227]);
if(C_truep(t28)){
t29=(C_word)C_i_cadr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_caddr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[9],a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=t32,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 805  gensym */
t34=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t34))(2,t34,t33);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[11],lf[232]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[12]);
t31=(C_word)C_i_cadr(t30);
t32=(C_word)C_i_caddr(((C_word*)t0)[12]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3711,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3729,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[11],lf[234]);
if(C_truep(t30)){
t31=(C_word)C_i_cadr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(C_word)C_i_caddr(((C_word*)t0)[12]);
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3790,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[13],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3852,a[2]=t34,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3854,a[2]=t32,a[3]=t33,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 844  call-with-current-continuation */
t37=*((C_word*)lf[241]+1);
((C_proc3)C_retrieve_proc(t37))(3,t37,t35,t36);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[11],lf[242]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3927,tmp=(C_word)a,a+=2,tmp);
t34=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t35=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t35+1)))(4,t35,t32,t33,t34);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[11],lf[244]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3960,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 872  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4324,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_eqp(lf[267],((C_word*)t0)[11]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4364,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 947  ##sys#check-syntax */
t36=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t36))(5,t36,t35,lf[267],((C_word*)t0)[12],lf[269]);}
else{
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4453,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=t33,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_retrieve(lf[92]))){
if(C_truep(C_retrieve(lf[91]))){
/* compiler.scm: 965  ##sys#hash-table-ref */
t36=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t35,C_retrieve(lf[91]),((C_word*)t0)[11]);}
else{
t36=t35;
f_4453(2,t36,C_SCHEME_FALSE);}}
else{
t36=t35;
f_4453(2,t36,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4451 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4453,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 967  cm */
t3=t1;
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
/* compiler.scm: 972  handle-call */
t2=((C_word*)t0)[7];
f_4324(t2,((C_word*)t0)[6]);}}

/* k4457 in k4451 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[8]))){
/* compiler.scm: 969  handle-call */
t2=((C_word*)t0)[7];
f_4324(t2,((C_word*)t0)[6]);}
else{
/* compiler.scm: 970  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2156(t2,((C_word*)t0)[6],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4362 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4364,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_1969(t2,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(t3,C_retrieve(lf[77]));
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_a_i_list(&a,2,lf[102],lf[267]);
t7=(C_word)C_a_i_list(&a,5,lf[268],t5,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 952  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2156(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_assq(t2,C_retrieve(lf[74]));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
/* compiler.scm: 956  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2156(t7,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[80])))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 958  symbol->string */
t7=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_a_i_list(&a,2,lf[102],lf[267]);
t7=(C_word)C_a_i_list(&a,5,lf[268],t2,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 960  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2156(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}}}
else{
t3=(C_word)C_a_i_list(&a,2,lf[102],lf[267]);
t4=(C_word)C_a_i_list(&a,5,lf[268],t2,C_fix(0),C_SCHEME_FALSE,t3);
/* compiler.scm: 961  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2156(t5,((C_word*)t0)[3],t4,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4422 in k4362 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[222]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[103],t2));}

/* handle-call in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_4324(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4324,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4328,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 936  mapwalk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4690(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4326 in handle-call in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4328,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4334,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 938  ##sys#hash-table-ref */
t4=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[53]),t2);}

/* k4332 in k4326 in handle-call in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4348,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cdr(t1):C_SCHEME_END_OF_LIST);
/* compiler.scm: 943  alist-cons */
t5=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t4);}
else{
t3=t2;
f_4337(2,t3,C_SCHEME_UNDEFINED);}}

/* k4346 in k4332 in k4326 in handle-call in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4348,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 940  ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],C_retrieve(lf[53]),((C_word*)t0)[2],t2);}

/* k4335 in k4332 in k4326 in handle-call in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3960,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_cadddr(t2);
t9=(C_word)C_i_cadr(t8);
t10=(C_word)C_i_cadr(t4);
t11=(C_word)C_i_cadr(t5);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3982,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t1,tmp=(C_word)a,a+=13,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4308,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 879  valid-c-identifier? */
t14=C_retrieve(lf[266]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t11);}

/* k4306 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4308,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[80]));
t3=C_mutate((C_word*)lf[80]+1,t2);
t4=((C_word*)t0)[2];
f_3982(2,t4,t3);}
else{
/* compiler.scm: 881  quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[265],((C_word*)t0)[3]);}}

/* k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[11]);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4273,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4273(t6,t4);}
else{
t6=(C_word)C_i_listp(((C_word*)t0)[4]);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t5;
f_4273(t8,t7);}
else{
t8=(C_word)C_i_length(((C_word*)t0)[11]);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t8,t9);
t11=t5;
f_4273(t11,(C_word)C_i_not(t10));}}}

/* k4271 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_4273(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 886  syntax-error */
t2=C_retrieve(lf[110]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[264],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3985(2,t2,C_SCHEME_UNDEFINED);}}

/* k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3996,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 890  mapwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4690(t4,t3,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}

/* k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4004,a[2]=t1,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4223,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4223(t7,t3,((C_word*)t0)[9],((C_word*)t0)[2]);}

/* loop in k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_4223(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4223,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4259,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4263,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4267,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 902  final-foreign-type */
t9=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t5);}}

/* k4265 in loop in k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 902  finish-foreign-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4261 in loop in k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 901  foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4257 in loop in k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4259,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4247,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 904  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4223(t6,t3,t4,t5);}

/* k4245 in k4257 in loop in k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4247,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4014 in k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[250],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4020,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4030,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4072,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4095,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[250]))){
/* compiler.scm: 907  g300 */
t7=t6;
f_4095(2,t7,f_4072(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[251]))){
/* compiler.scm: 907  g300 */
t7=t6;
f_4095(2,t7,f_4072(C_a_i(&a,15),t5));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[252]);
if(C_truep(t7)){
/* compiler.scm: 907  g300 */
t8=t6;
f_4095(2,t8,f_4072(C_a_i(&a,15),t5));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[253]);
if(C_truep(t8)){
/* compiler.scm: 907  g300 */
t9=t6;
f_4095(2,t9,f_4072(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[254]))){
/* compiler.scm: 907  g301 */
t9=t4;
f_4067(t9,t6);}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[255]))){
/* compiler.scm: 907  g301 */
t9=t4;
f_4067(t9,t6);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],lf[256]);
if(C_truep(t9)){
/* compiler.scm: 907  g301 */
t10=t4;
f_4067(t10,t6);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[3],lf[257]);
if(C_truep(t10)){
/* compiler.scm: 907  g301 */
t11=t4;
f_4067(t11,t6);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[3],lf[258]);
if(C_truep(t11)){
/* compiler.scm: 907  g301 */
t12=t4;
f_4067(t12,t6);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[3],lf[259]);
if(C_truep(t12)){
/* compiler.scm: 907  g301 */
t13=t4;
f_4067(t13,t6);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[3],lf[260]);
if(C_truep(t13)){
/* compiler.scm: 907  g302 */
t14=t6;
f_4095(2,t14,f_4030(C_a_i(&a,42),t3));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[261]))){
/* compiler.scm: 907  g302 */
t14=t6;
f_4095(2,t14,f_4030(C_a_i(&a,42),t3));}
else{
t14=(C_word)C_eqp(((C_word*)t0)[3],lf[262]);
/* compiler.scm: 907  g302 */
t15=t6;
f_4095(2,t15,(C_truep(t14)?f_4030(C_a_i(&a,42),t3):(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[263]))?f_4030(C_a_i(&a,42),t3):(C_word)C_i_cddr(((C_word*)t0)[4]))));}}}}}}}}}}}}}

/* k4093 in k4014 in k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
/* compiler.scm: 905  foreign-type-convert-argument */
t4=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* g300 in k4014 in k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static C_word C_fcall f_4072(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
t4=(C_word)C_a_i_list(&a,2,lf[247],t3);
return((C_word)C_a_i_list(&a,1,t4));}

/* g301 in k4014 in k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_4067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4067,NULL,2,t0,t1);}
/* compiler.scm: 919  syntax-error */
t2=C_retrieve(lf[110]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[249],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* g302 in k4014 in k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static C_word C_fcall f_4030(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
t4=(C_word)C_a_i_list(&a,2,lf[246],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[247],lf[246]);
t7=(C_word)C_a_i_list(&a,3,lf[248],lf[246],t6);
t8=(C_word)C_a_i_list(&a,3,lf[152],t5,t7);
return((C_word)C_a_i_list(&a,1,t8));}

/* k4018 in k4014 in k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[160],((C_word*)t0)[6],t2);
/* compiler.scm: 891  walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2156(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4002 in k3994 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4004,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 452  ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3990 in k3983 in k3980 in a3959 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3992,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[244],t1));}

/* a3949 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3950,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 872  split-at */
t3=C_retrieve(lf[245]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_fix(4));}

/* a3926 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3927,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* compiler.scm: 867  process-declaration */
t4=C_retrieve(lf[243]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k3923 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3925,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 865  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2156(t3,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3853 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3854,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3860,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3872,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 844  with-exception-handler */
t5=C_retrieve(lf[240]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3871 in a3853 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3878,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3894,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 844  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3893 in a3871 in a3853 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3894r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3894r(t0,t1,t2);}}

static void C_ccall f_3894r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3900,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 844  g263 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3899 in a3893 in a3871 in a3853 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3900,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3877 in a3871 in a3853 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3885,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 848  collapsable-literal? */
t3=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3883 in a3877 in a3871 in a3853 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3885,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,3,lf[152],C_retrieve(lf[79]),((C_word*)t0)[2]);
/* compiler.scm: 850  eval */
t3=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}

/* a3859 in a3853 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3860,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 844  g263 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3865 in a3859 in a3853 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3866,2,t0,t1);}
/* compiler.scm: 846  quit */
t2=C_retrieve(lf[238]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[239],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3850 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3788 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
t2=C_set_block_item(lf[59],0,C_SCHEME_TRUE);
t3=(C_word)C_a_i_list(&a,2,lf[102],t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[79]));
t6=C_mutate((C_word*)lf[79]+1,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 853  collapsable-literal? */
t8=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t1);}

/* k3799 in k3788 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3801,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3804,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* compiler.scm: 854  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3811,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 857  gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[236]);}}

/* k3809 in k3799 in k3788 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 858  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[2],t3);}

/* k3812 in k3809 in k3799 in k3788 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 859  alist-cons */
t3=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],C_retrieve(lf[60]));}

/* k3816 in k3812 in k3809 in k3799 in k3788 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3818,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[31]));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[17]));
t6=C_mutate((C_word*)lf[17]+1,t5);
t7=(C_word)C_a_i_list(&a,2,lf[102],((C_word*)t0)[6]);
t8=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[7],t7);
/* compiler.scm: 862  walk */
t9=((C_word*)((C_word*)t0)[5])[1];
f_2156(t9,((C_word*)t0)[4],t8,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3802 in k3799 in k3788 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[235]);}

/* a3728 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3729,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3733,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 834  ##sys#hash-table-set! */
t5=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[56]),((C_word*)t0)[2],t2);}

/* k3731 in a3728 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3771,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 835  unzip1 */
t4=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3769 in k3731 in a3728 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 835  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve(lf[17]));}

/* k3735 in k3731 in a3728 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3737,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=C_set_block_item(lf[57],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3751,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a3750 in k3735 in k3731 in a3728 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3751,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_a_i_list(&a,2,lf[102],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[176],t3,t5));}

/* k3747 in k3735 in k3731 in a3728 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3749,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 837  walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2156(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3710 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3719,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,lf[160],t3);
/* compiler.scm: 833  walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2156(t5,t2,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3717 in a3710 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 832  extract-mutable-constants */
t2=C_retrieve(lf[233]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3582 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 806  gensym */
t3=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3585 in k3582 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3587,2,t0,t1);}
t2=(C_word)C_i_cddddr(((C_word*)t0)[10]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_cadddr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3593,a[2]=((C_word*)t0)[10],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 808  set-real-name! */
t6=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[9],((C_word*)t0)[3]);}

/* k3591 in k3585 in k3582 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3593,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[77]));
t4=C_mutate((C_word*)lf[77]+1,t3);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3672,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 811  estimate-foreign-result-location-size */
t7=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[10]);}

/* k3670 in k3591 in k3585 in k3582 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 811  words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3647 in k3591 in k3585 in k3582 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3649,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[228],t2);
t4=(C_word)C_a_i_list(&a,2,lf[102],t1);
t5=(C_word)C_a_i_list(&a,3,lf[195],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3608,a[2]=t7,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3620,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t8,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t11=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[5],((C_word*)t0)[3]);
t12=t10;
f_3624(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t11=t10;
f_3624(t11,C_SCHEME_END_OF_LIST);}}

/* k3622 in k3647 in k3591 in k3585 in k3582 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_3624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3624,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3632,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* compiler.scm: 824  fifth */
t3=C_retrieve(lf[226]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3632(2,t3,(C_word)C_i_cadddr(((C_word*)t0)[2]));}}

/* k3630 in k3622 in k3647 in k3591 in k3585 in k3582 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3632,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 452  ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3618 in k3647 in k3591 in k3585 in k3582 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3620,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 825  alist-cons */
t4=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3614 in k3618 in k3647 in k3591 in k3585 in k3582 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 819  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2156(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3606 in k3647 in k3591 in k3585 in k3582 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3608,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* k3507 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3518,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 793  make-random-name */
t9=C_retrieve(lf[97]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k3516 in k3507 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3521(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3549,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3557,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 794  fifth */
t5=C_retrieve(lf[226]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3555 in k3516 in k3507 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(t1);
/* compiler.scm: 794  symbol->string */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3547 in k3516 in k3507 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3521(t3,t2);}

/* k3519 in k3516 in k3507 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_3521(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3521,NULL,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[69]));
t4=C_mutate((C_word*)lf[69]+1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 797  string-append */
t6=*((C_word*)lf[224]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[225],((C_word*)((C_word*)t0)[7])[1]);}

/* k3539 in k3519 in k3516 in k3507 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3541,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],lf[222],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3533,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 799  alist-cons */
t6=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[4],C_retrieve(lf[74]));}

/* k3531 in k3539 in k3519 in k3516 in k3507 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[223]);}

/* k3487 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[220]);}

/* k3433 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 773  gensym */
t3=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3436 in k3433 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[3],((C_word*)t0)[9],t1);
/* compiler.scm: 774  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[65]),((C_word*)t0)[2],t3);}

/* k3439 in k3436 in k3433 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 775  cons* */
t3=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[17]));}

/* k3443 in k3439 in k3436 in k3433 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 776  cons* / */
t4=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[31]));}

/* k3447 in k3443 in k3439 in k3436 in k3433 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3449,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[8],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[9]):lf[218]);
t8=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_list(&a,3,lf[138],t4,t8);
/* compiler.scm: 777  walk */
t10=((C_word*)((C_word*)t0)[6])[1];
f_2156(t10,((C_word*)t0)[5],t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3366 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t1))){
t3=t2;
f_3380(2,t3,t1);}
else{
/* compiler.scm: 763  symbol->string */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k3378 in k3366 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3380,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[215]);}

/* k3351 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 754  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2156(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3338 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 751  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2156(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3325 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 748  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2156(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3312 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 745  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2156(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3299 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 742  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2156(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3232 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3234,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3247,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3253,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3253(t8,t3,t4);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[202]);}}

/* fold in k3232 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_3253(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3253,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3273,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 737  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2156(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3280,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 738  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2156(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE);}}

/* k3278 in fold in k3232 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3284,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 738  fold */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3253(t3,t2,((C_word*)t0)[2]);}

/* k3282 in k3278 in fold in k3232 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3284,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3271 in fold in k3232 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3273,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3245 in k3232 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 732  canonicalize-begin-body */
t2=C_retrieve(lf[201]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3219 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[200]);}

/* k3204 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 723  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2156(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3177 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3183,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 718  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2156(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3181 in k3177 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[180],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3156 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3158,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[2],t1));}

/* k3127 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3133,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 709  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4690(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3131 in k3127 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[195],t2));}

/* k3098 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3104,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 704  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4690(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3102 in k3098 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3104,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[194],t2));}

/* k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2926,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=f_1969(t2,((C_word*)t0)[5]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 668  get-line */
t7=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}

/* k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2938,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 669  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2156(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2941,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 671  ##sys#alias-global-hook */
t5=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=t2;
f_2941(2,t4,C_SCHEME_UNDEFINED);}}

/* k3044 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[34]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3075,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 674  lset-adjoin */
t5=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[129]+1),C_retrieve(lf[18]),((C_word*)((C_word*)t0)[4])[1]);}
else{
t4=t3;
f_3049(t4,C_SCHEME_UNDEFINED);}}

/* k3073 in k3044 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3075,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 675  lset-adjoin */
t4=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[129]+1),C_retrieve(lf[17]),((C_word*)((C_word*)t0)[2])[1]);}

/* k3077 in k3073 in k3044 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_3049(t3,t2);}

/* k3047 in k3044 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_3049(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3049,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 676  macro? */
t3=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k3053 in k3047 in k3044 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3068,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 680  sprintf */
t4=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[188],((C_word*)t0)[2]);}
else{
t4=t3;
f_3068(2,t4,lf[189]);}}
else{
t2=((C_word*)t0)[4];
f_2941(2,t2,C_SCHEME_UNDEFINED);}}

/* k3066 in k3053 in k3047 in k3044 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 677  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[185],lf[186],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3056 in k3053 in k3047 in k3044 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[46]))){
/* compiler.scm: 681  undefine-macro! */
t2=C_retrieve(lf[184]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2941(2,t2,C_SCHEME_UNDEFINED);}}

/* k2939 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3036,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 682  keyword? */
t4=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k3034 in k2939 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 683  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[181],lf[182],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2944(2,t2,C_SCHEME_UNDEFINED);}}

/* k2942 in k2939 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2944,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 687  gensym */
t5=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 695  gensym */
t6=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[175],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]));}}}

/* k2997 in k2942 in k2939 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 696  foreign-type-convert-argument */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k3028 in k2997 in k2942 in k2939 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3030,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3022,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 700  foreign-type-check */
t7=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k3020 in k3028 in k2997 in k2942 in k2939 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3022,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[180],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t2));}

/* k2954 in k2942 in k2939 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 688  foreign-type-convert-argument */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2985 in k2954 in k2942 in k2939 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2975,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 691  foreign-type-check */
t7=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k2973 in k2985 in k2954 in k2942 in k2939 in k2936 in k2933 in k2924 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t2));}

/* k2886 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2891,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 655  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[7],t1);}

/* k2912 in k2886 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 655  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2889 in k2886 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2904,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2906,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 658  ##sys#canonicalize-body */
t5=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a2905 in k2889 in k2886 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2906,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2902 in k2889 in k2886 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 657  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2156(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2892 in k2889 in k2886 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2897,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 661  set-real-names! */
f_1981(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2895 in k2892 in k2889 in k2886 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2897,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[159],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2623,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[10]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2632,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2838,a[2]=t8,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 617  ##sys#extended-lambda-list? */
t10=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t4)[1]);}

/* k2836 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2838,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2843,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 618  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_2632(2,t2,C_SCHEME_UNDEFINED);}}

/* a2848 in k2836 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2849,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2842 in k2836 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2843,2,t0,t1);}
/* compiler.scm: 620  ##sys#expand-extended-lambda-list */
t2=C_retrieve(lf[169]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[170]+1));}

/* k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 623  decompose-lambda-list */
t3=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2637,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[122]),t2);}

/* k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2835,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 627  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[7],t1);}

/* k2833 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 627  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2827,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 628  ##sys#canonicalize-body */
t4=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3,((C_word*)t0)[3],((C_word*)t0)[14]);}

/* a2826 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2827,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=t1,a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 629  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2156(t3,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2653,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2818,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2825,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 633  posq */
t5=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t4=t3;
f_2818(t4,C_SCHEME_FALSE);}}

/* k2823 in k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2818(t2,(C_word)C_i_list_ref(((C_word*)t0)[2],t1));}

/* k2816 in k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_2818(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 631  build-lambda-list */
t2=C_retrieve(lf[166]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2651 in k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2653,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[159],t1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 635  set-real-names! */
f_1981(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2657 in k2651 in k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2659,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_2668(t4,t2);}
else{
t4=f_1969(((C_word*)t0)[10],((C_word*)t0)[2]);
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
t6=t3;
f_2668(t6,(C_word)C_i_not(t5));}}

/* k2666 in k2657 in k2651 in k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_2668(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2668,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_truep(C_retrieve(lf[27]))?(C_word)C_eqp(lf[159],((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t2)){
/* compiler.scm: 640  expand-profile-lambda */
t3=C_retrieve(lf[161]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2688,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(C_word)C_eqp(t5,lf[138]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
t8=t4;
f_2688(t8,(C_word)C_i_pairp(t7));}
else{
t7=t4;
f_2688(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2688(t5,C_SCHEME_FALSE);}}}}

/* k2686 in k2666 in k2657 in k2651 in k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_2688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2688,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_i_cdddr(((C_word*)t0)[5]);
/* compiler.scm: 642  g169 */
t6=((C_word*)t0)[4];
f_2678(t6,((C_word*)t0)[3],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2772,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 642  caadr */
t6=*((C_word*)lf[165]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t5=t3;
f_2721(t5,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2770 in k2686 in k2666 in k2657 in k2651 in k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[102]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 642  cdadr */
t4=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_2721(t3,C_SCHEME_FALSE);}}

/* k2766 in k2770 in k2686 in k2666 in k2657 in k2651 in k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2768,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 642  cddadr */
t3=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_2721(t2,C_SCHEME_FALSE);}}

/* k2762 in k2766 in k2770 in k2686 in k2666 in k2657 in k2651 in k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2721(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_2721(t2,C_SCHEME_FALSE);}}

/* k2719 in k2686 in k2666 in k2657 in k2651 in k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_2721(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2721,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 642  cadadr */
t3=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2726 in k2719 in k2686 in k2666 in k2657 in k2651 in k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* compiler.scm: 642  g169 */
t3=((C_word*)t0)[3];
f_2678(t3,((C_word*)t0)[2],t1);}

/* g169 in k2666 in k2657 in k2651 in k2648 in k2645 in k2642 in k2639 in a2636 in k2630 in k2621 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_2678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2678,NULL,3,t0,t1,t2);}
/* compiler.scm: 644  process-lambda-documentation */
t3=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2547 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2555,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 602  unzip1 */
t4=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2553 in k2547 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2558,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[122]),t1);}

/* k2556 in k2553 in k2547 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 604  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k2609 in k2556 in k2553 in k2547 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 604  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2559 in k2556 in k2553 in k2547 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2564,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 605  set-real-names! */
f_1981(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k2562 in k2559 in k2556 in k2553 in k2547 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2591,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 606  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2590 in k2562 in k2559 in k2556 in k2553 in k2547 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2591,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2599,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_car(t3);
/* compiler.scm: 607  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2156(t7,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k2597 in a2590 in k2562 in k2559 in k2556 in k2553 in k2547 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2599,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2569 in k2562 in k2559 in k2556 in k2553 in k2547 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2575,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 609  ##sys#canonicalize-body */
t6=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,t4,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* a2584 in k2569 in k2562 in k2559 in k2556 in k2553 in k2547 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2585,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2577 in k2569 in k2562 in k2559 in k2556 in k2553 in k2547 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 609  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2156(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2573 in k2569 in k2562 in k2559 in k2556 in k2553 in k2547 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2575,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_2435(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2435,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[136]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2445,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 577  cadar */
t4=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k2443 in loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2450,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2456,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2455 in k2443 in loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2456,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t6=t5;
f_2521(2,t6,t3);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 581  feature? */
t7=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t6=t5;
f_2521(2,t6,C_SCHEME_FALSE);}}}

/* k2528 in a2455 in k2443 in loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2530,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2521(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 583  ##sys#canonicalize-extension-path */
t3=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[149]);}}

/* k2538 in k2528 in a2455 in k2443 in loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 582  ##sys#find-extension */
t2=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2519 in a2455 in k2443 in loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 589  ##sys#extension-information */
t4=C_retrieve(lf[143]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t3=t2;
f_2483(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2483(t3,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 585  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[145],lf[146],((C_word*)t0)[2]);}}

/* k2493 in k2519 in a2455 in k2443 in loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2495,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[140],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* for-each */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=((C_word*)t0)[3];
f_2483(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_2483(t2,C_SCHEME_FALSE);}}

/* a2508 in k2493 in k2519 in a2455 in k2443 in loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2509,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,((C_word*)t0)[2]);}

/* k2505 in k2493 in k2519 in a2455 in k2443 in loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2483(t2,C_SCHEME_TRUE);}

/* k2481 in k2519 in a2455 in k2443 in loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_2483(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2460(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 595  lookup-exports-file */
t2=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2458 in a2455 in k2443 in loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2467,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 596  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2435(t4,t2,t3);}

/* k2465 in k2458 in a2455 in k2443 in loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[138],((C_word*)t0)[2],t1));}

/* a2449 in k2443 in loop in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2450,2,t0,t1);}
/* compiler.scm: 578  ##sys#do-the-right-thing */
t2=C_retrieve(lf[137]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2427 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 573  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2156(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2395 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2400,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[132]),t1);}

/* k2398 in k2395 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2403,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 567  ##sys#hash-table-update! */
t5=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[131],t3,t4);}

/* a2410 in k2398 in k2395 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2411,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2404 in k2398 in k2395 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2405,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[129]+1),t2,((C_word*)t0)[2]);}

/* k2401 in k2398 in k2395 in k2386 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[127]);}

/* k2353 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2355,2,t0,t1);}
t2=(C_word)C_i_assoc(t1,C_retrieve(lf[54]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2367,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 555  gensym */
t4=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[123]);}}

/* k2365 in k2353 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 556  alist-cons */
t3=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],t1,C_retrieve(lf[54]));}

/* k2369 in k2365 in k2353 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=C_mutate((C_word*)lf[54]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[17]));
t4=C_mutate((C_word*)lf[17]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[31]));
t6=C_mutate((C_word*)lf[31]+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[3]);}

/* k2321 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
/* compiler.scm: 544  walk-literal */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2138(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2275 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 536  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2156(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2282 in k2275 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 537  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2156(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2286 in k2282 in k2275 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2292,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_2292(2,t4,lf[114]);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 540  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2156(t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2290 in k2286 in k2282 in k2275 in k2252 in k2234 in k2227 in k2224 in k2218 in k2191 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2292,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[113],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2179 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 508  ##sys#alias-global-hook */
t2=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2173 in walk in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* walk-literal in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_2138(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2138,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_retrieve(lf[93]))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2147,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 497  literal-rewrite-hook */
t7=C_retrieve(lf[93]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,lf[102],t2));}}

/* a2146 in walk-literal in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2147,3,t0,t1,t2);}
/* walk21 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2156(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* resolve-atom in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_2047(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2047,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2051,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[59]))){
/* compiler.scm: 472  ##sys#hash-table-ref */
t7=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[58]),t2);}
else{
t7=t6;
f_2051(2,t7,C_SCHEME_FALSE);}}

/* k2049 in resolve-atom in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2051,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
/* compiler.scm: 473  walk */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2156(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 474  ##sys#hash-table-ref */
t3=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),((C_word*)t0)[2]);}
else{
t3=t2;
f_2064(2,t3,C_SCHEME_FALSE);}}}

/* k2062 in k2049 in resolve-atom in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 476  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2156(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2082,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 480  final-foreign-type */
t5=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t3=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2112,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 488  final-foreign-type */
t6=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k2110 in k2062 in k2049 in resolve-atom in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2112,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[107],t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2122,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 491  finish-foreign-result */
t6=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2120 in k2110 in k2062 in k2049 in resolve-atom in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 490  foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2080 in k2062 in k2049 in resolve-atom in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2082,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[103],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2092,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 483  finish-foreign-result */
t6=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2090 in k2080 in k2062 in k2049 in resolve-atom in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 482  foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* unquotify in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2005,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2012,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[102]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(t2);
t8=t3;
f_2012(t8,(C_word)C_i_nullp(t7));}
else{
t7=t3;
f_2012(t7,C_SCHEME_FALSE);}}
else{
t6=t3;
f_2012(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2012(t4,C_SCHEME_FALSE);}}

/* k2010 in unquotify in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_2012(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cadr(((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-real-names! in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_fcall f_1981(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1981,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1987,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 459  for-each */
t5=*((C_word*)lf[101]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t2,t3);}

/* a1986 in set-real-names! in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1987,4,t0,t1,t2,t3);}
/* compiler.scm: 459  set-real-name! */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* resolve in ##compiler#canonicalize-expression in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static C_word C_fcall f_1969(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_stack_check;
t3=(C_word)C_i_assq(t1,t2);
return((C_truep(t3)?(C_word)C_i_cdr(t3):t1));}

/* ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1899,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[53]))){
/* compiler.scm: 429  vector-fill! */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[53]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1964,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 430  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[22]),C_SCHEME_END_OF_LIST);}}

/* k1962 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[53]+1,t1);
t3=((C_word*)t0)[2];
f_1899(2,t3,t2);}

/* k1897 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[56]))){
/* compiler.scm: 432  vector-fill! */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1957,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 433  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1955 in k1897 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=((C_word*)t0)[2];
f_1902(2,t3,t2);}

/* k1900 in k1897 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[58]))){
/* compiler.scm: 435  vector-fill! */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[58]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1950,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 436  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1948 in k1900 in k1897 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[58]+1,t1);
t3=((C_word*)t0)[2];
f_1905(2,t3,t2);}

/* k1903 in k1900 in k1897 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 437  make-random-name */
t3=C_retrieve(lf[97]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[98]);}

/* k1907 in k1903 in k1900 in k1897 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 438  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}

/* k1911 in k1907 in k1903 in k1900 in k1897 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[88]))){
/* compiler.scm: 440  vector-fill! */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[88]),C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1943,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 441  make-vector */
t5=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1941 in k1911 in k1907 in k1903 in k1900 in k1897 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=((C_word*)t0)[2];
f_1916(2,t3,t2);}

/* k1914 in k1911 in k1907 in k1903 in k1900 in k1897 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[44]))){
/* compiler.scm: 443  vector-fill! */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[44]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1936,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 444  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}}

/* k1934 in k1914 in k1911 in k1907 in k1903 in k1900 in k1897 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=((C_word*)t0)[2];
f_1919(2,t3,t2);}

/* k1917 in k1914 in k1911 in k1907 in k1903 in k1900 in k1897 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1919,2,t0,t1);}
if(C_truep(C_retrieve(lf[65]))){
/* compiler.scm: 446  vector-fill! */
t2=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[65]),C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 447  make-vector */
t3=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1927 in k1917 in k1914 in k1911 in k1907 in k1903 in k1900 in k1897 in ##compiler#initialize-compiler in k1807 in k1803 in k1799 in k1795 in k1791 in k1787 in k1780 in k1777 in k1774 in k1771 in k1768 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[65]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[819] = {
{"toplevelcompiler.scm",(void*)C_compiler_toplevel},
{"f_1770compiler.scm",(void*)f_1770},
{"f_1773compiler.scm",(void*)f_1773},
{"f_1776compiler.scm",(void*)f_1776},
{"f_1779compiler.scm",(void*)f_1779},
{"f_1782compiler.scm",(void*)f_1782},
{"f_1789compiler.scm",(void*)f_1789},
{"f_1793compiler.scm",(void*)f_1793},
{"f_1797compiler.scm",(void*)f_1797},
{"f_1801compiler.scm",(void*)f_1801},
{"f_1805compiler.scm",(void*)f_1805},
{"f_1809compiler.scm",(void*)f_1809},
{"f_10153compiler.scm",(void*)f_10153},
{"f_11210compiler.scm",(void*)f_11210},
{"f_11213compiler.scm",(void*)f_11213},
{"f_11216compiler.scm",(void*)f_11216},
{"f_11219compiler.scm",(void*)f_11219},
{"f_11222compiler.scm",(void*)f_11222},
{"f_11010compiler.scm",(void*)f_11010},
{"f_11016compiler.scm",(void*)f_11016},
{"f_10243compiler.scm",(void*)f_10243},
{"f_10999compiler.scm",(void*)f_10999},
{"f_10996compiler.scm",(void*)f_10996},
{"f_10909compiler.scm",(void*)f_10909},
{"f_10973compiler.scm",(void*)f_10973},
{"f_10986compiler.scm",(void*)f_10986},
{"f_10967compiler.scm",(void*)f_10967},
{"f_10957compiler.scm",(void*)f_10957},
{"f_10930compiler.scm",(void*)f_10930},
{"f_10933compiler.scm",(void*)f_10933},
{"f_10881compiler.scm",(void*)f_10881},
{"f_10884compiler.scm",(void*)f_10884},
{"f_10838compiler.scm",(void*)f_10838},
{"f_10850compiler.scm",(void*)f_10850},
{"f_10841compiler.scm",(void*)f_10841},
{"f_10844compiler.scm",(void*)f_10844},
{"f_10718compiler.scm",(void*)f_10718},
{"f_10819compiler.scm",(void*)f_10819},
{"f_10807compiler.scm",(void*)f_10807},
{"f_10746compiler.scm",(void*)f_10746},
{"f_10752compiler.scm",(void*)f_10752},
{"f_10776compiler.scm",(void*)f_10776},
{"f_10768compiler.scm",(void*)f_10768},
{"f_10734compiler.scm",(void*)f_10734},
{"f_10677compiler.scm",(void*)f_10677},
{"f_10689compiler.scm",(void*)f_10689},
{"f_10693compiler.scm",(void*)f_10693},
{"f_10681compiler.scm",(void*)f_10681},
{"f_10493compiler.scm",(void*)f_10493},
{"f_10614compiler.scm",(void*)f_10614},
{"f_10620compiler.scm",(void*)f_10620},
{"f_10645compiler.scm",(void*)f_10645},
{"f_10626compiler.scm",(void*)f_10626},
{"f_10500compiler.scm",(void*)f_10500},
{"f_10605compiler.scm",(void*)f_10605},
{"f_10503compiler.scm",(void*)f_10503},
{"f_10506compiler.scm",(void*)f_10506},
{"f_10509compiler.scm",(void*)f_10509},
{"f_10547compiler.scm",(void*)f_10547},
{"f_10573compiler.scm",(void*)f_10573},
{"f_10554compiler.scm",(void*)f_10554},
{"f_10558compiler.scm",(void*)f_10558},
{"f_10531compiler.scm",(void*)f_10531},
{"f_10437compiler.scm",(void*)f_10437},
{"f_10446compiler.scm",(void*)f_10446},
{"f_10440compiler.scm",(void*)f_10440},
{"f_10421compiler.scm",(void*)f_10421},
{"f_10394compiler.scm",(void*)f_10394},
{"f_10377compiler.scm",(void*)f_10377},
{"f_10373compiler.scm",(void*)f_10373},
{"f_10366compiler.scm",(void*)f_10366},
{"f_10349compiler.scm",(void*)f_10349},
{"f_10345compiler.scm",(void*)f_10345},
{"f_10321compiler.scm",(void*)f_10321},
{"f_10301compiler.scm",(void*)f_10301},
{"f_10156compiler.scm",(void*)f_10156},
{"f_10160compiler.scm",(void*)f_10160},
{"f_10175compiler.scm",(void*)f_10175},
{"f_10185compiler.scm",(void*)f_10185},
{"f_10190compiler.scm",(void*)f_10190},
{"f_10235compiler.scm",(void*)f_10235},
{"f_10194compiler.scm",(void*)f_10194},
{"f_10200compiler.scm",(void*)f_10200},
{"f_10210compiler.scm",(void*)f_10210},
{"f_11022compiler.scm",(void*)f_11022},
{"f_11029compiler.scm",(void*)f_11029},
{"f_11091compiler.scm",(void*)f_11091},
{"f_11081compiler.scm",(void*)f_11081},
{"f_11055compiler.scm",(void*)f_11055},
{"f_11041compiler.scm",(void*)f_11041},
{"f_11116compiler.scm",(void*)f_11116},
{"f_11132compiler.scm",(void*)f_11132},
{"f_11139compiler.scm",(void*)f_11139},
{"f_11146compiler.scm",(void*)f_11146},
{"f_11120compiler.scm",(void*)f_11120},
{"f_11130compiler.scm",(void*)f_11130},
{"f_11102compiler.scm",(void*)f_11102},
{"f_11110compiler.scm",(void*)f_11110},
{"f_11148compiler.scm",(void*)f_11148},
{"f_11161compiler.scm",(void*)f_11161},
{"f_10144compiler.scm",(void*)f_10144},
{"f_10135compiler.scm",(void*)f_10135},
{"f_10126compiler.scm",(void*)f_10126},
{"f_10117compiler.scm",(void*)f_10117},
{"f_10108compiler.scm",(void*)f_10108},
{"f_10099compiler.scm",(void*)f_10099},
{"f_10090compiler.scm",(void*)f_10090},
{"f_10081compiler.scm",(void*)f_10081},
{"f_10072compiler.scm",(void*)f_10072},
{"f_10063compiler.scm",(void*)f_10063},
{"f_10054compiler.scm",(void*)f_10054},
{"f_10045compiler.scm",(void*)f_10045},
{"f_10036compiler.scm",(void*)f_10036},
{"f_10027compiler.scm",(void*)f_10027},
{"f_10018compiler.scm",(void*)f_10018},
{"f_10009compiler.scm",(void*)f_10009},
{"f_10000compiler.scm",(void*)f_10000},
{"f_9991compiler.scm",(void*)f_9991},
{"f_9982compiler.scm",(void*)f_9982},
{"f_9973compiler.scm",(void*)f_9973},
{"f_9964compiler.scm",(void*)f_9964},
{"f_9955compiler.scm",(void*)f_9955},
{"f_9946compiler.scm",(void*)f_9946},
{"f_9937compiler.scm",(void*)f_9937},
{"f_9928compiler.scm",(void*)f_9928},
{"f_9919compiler.scm",(void*)f_9919},
{"f_9910compiler.scm",(void*)f_9910},
{"f_9901compiler.scm",(void*)f_9901},
{"f_9892compiler.scm",(void*)f_9892},
{"f_9883compiler.scm",(void*)f_9883},
{"f_9877compiler.scm",(void*)f_9877},
{"f_9871compiler.scm",(void*)f_9871},
{"f_8637compiler.scm",(void*)f_8637},
{"f_9838compiler.scm",(void*)f_9838},
{"f_9841compiler.scm",(void*)f_9841},
{"f_9844compiler.scm",(void*)f_9844},
{"f_9847compiler.scm",(void*)f_9847},
{"f_9850compiler.scm",(void*)f_9850},
{"f_9865compiler.scm",(void*)f_9865},
{"f_9863compiler.scm",(void*)f_9863},
{"f_9853compiler.scm",(void*)f_9853},
{"f_9690compiler.scm",(void*)f_9690},
{"f_9696compiler.scm",(void*)f_9696},
{"f_9001compiler.scm",(void*)f_9001},
{"f_9020compiler.scm",(void*)f_9020},
{"f_9053compiler.scm",(void*)f_9053},
{"f_9580compiler.scm",(void*)f_9580},
{"f_9576compiler.scm",(void*)f_9576},
{"f_9569compiler.scm",(void*)f_9569},
{"f_9420compiler.scm",(void*)f_9420},
{"f_9426compiler.scm",(void*)f_9426},
{"f_9496compiler.scm",(void*)f_9496},
{"f_9526compiler.scm",(void*)f_9526},
{"f_9509compiler.scm",(void*)f_9509},
{"f_9513compiler.scm",(void*)f_9513},
{"f_9435compiler.scm",(void*)f_9435},
{"f_9482compiler.scm",(void*)f_9482},
{"f_9486compiler.scm",(void*)f_9486},
{"f_9462compiler.scm",(void*)f_9462},
{"f_9458compiler.scm",(void*)f_9458},
{"f_9149compiler.scm",(void*)f_9149},
{"f_9398compiler.scm",(void*)f_9398},
{"f_9153compiler.scm",(void*)f_9153},
{"f_9396compiler.scm",(void*)f_9396},
{"f_9156compiler.scm",(void*)f_9156},
{"f_9159compiler.scm",(void*)f_9159},
{"f_9165compiler.scm",(void*)f_9165},
{"f_9171compiler.scm",(void*)f_9171},
{"f_9177compiler.scm",(void*)f_9177},
{"f_9363compiler.scm",(void*)f_9363},
{"f_9366compiler.scm",(void*)f_9366},
{"f_9180compiler.scm",(void*)f_9180},
{"f_9339compiler.scm",(void*)f_9339},
{"f_9324compiler.scm",(void*)f_9324},
{"f_9320compiler.scm",(void*)f_9320},
{"f_9254compiler.scm",(void*)f_9254},
{"f_9279compiler.scm",(void*)f_9279},
{"f_9285compiler.scm",(void*)f_9285},
{"f_9296compiler.scm",(void*)f_9296},
{"f_9283compiler.scm",(void*)f_9283},
{"f_9265compiler.scm",(void*)f_9265},
{"f_9257compiler.scm",(void*)f_9257},
{"f_9242compiler.scm",(void*)f_9242},
{"f_9250compiler.scm",(void*)f_9250},
{"f_9203compiler.scm",(void*)f_9203},
{"f_9233compiler.scm",(void*)f_9233},
{"f_9225compiler.scm",(void*)f_9225},
{"f_9221compiler.scm",(void*)f_9221},
{"f_9217compiler.scm",(void*)f_9217},
{"f_9206compiler.scm",(void*)f_9206},
{"f_9074compiler.scm",(void*)f_9074},
{"f_9077compiler.scm",(void*)f_9077},
{"f_9129compiler.scm",(void*)f_9129},
{"f_9093compiler.scm",(void*)f_9093},
{"f_9122compiler.scm",(void*)f_9122},
{"f_9114compiler.scm",(void*)f_9114},
{"f_9059compiler.scm",(void*)f_9059},
{"f_9032compiler.scm",(void*)f_9032},
{"f_9038compiler.scm",(void*)f_9038},
{"f_9702compiler.scm",(void*)f_9702},
{"f_9709compiler.scm",(void*)f_9709},
{"f_9725compiler.scm",(void*)f_9725},
{"f_8667compiler.scm",(void*)f_8667},
{"f_8686compiler.scm",(void*)f_8686},
{"f_8965compiler.scm",(void*)f_8965},
{"f_8926compiler.scm",(void*)f_8926},
{"f_9741compiler.scm",(void*)f_9741},
{"f_9779compiler.scm",(void*)f_9779},
{"f_9805compiler.scm",(void*)f_9805},
{"f_9791compiler.scm",(void*)f_9791},
{"f_9770compiler.scm",(void*)f_9770},
{"f_9739compiler.scm",(void*)f_9739},
{"f_8939compiler.scm",(void*)f_8939},
{"f_8942compiler.scm",(void*)f_8942},
{"f_8953compiler.scm",(void*)f_8953},
{"f_8890compiler.scm",(void*)f_8890},
{"f_8782compiler.scm",(void*)f_8782},
{"f_8788compiler.scm",(void*)f_8788},
{"f_8800compiler.scm",(void*)f_8800},
{"f_8803compiler.scm",(void*)f_8803},
{"f_8806compiler.scm",(void*)f_8806},
{"f_8824compiler.scm",(void*)f_8824},
{"f_8831compiler.scm",(void*)f_8831},
{"f_8809compiler.scm",(void*)f_8809},
{"f_8812compiler.scm",(void*)f_8812},
{"f_8815compiler.scm",(void*)f_8815},
{"f_8776compiler.scm",(void*)f_8776},
{"f_8766compiler.scm",(void*)f_8766},
{"f_8749compiler.scm",(void*)f_8749},
{"f_8754compiler.scm",(void*)f_8754},
{"f_8707compiler.scm",(void*)f_8707},
{"f_8724compiler.scm",(void*)f_8724},
{"f_8711compiler.scm",(void*)f_8711},
{"f_8722compiler.scm",(void*)f_8722},
{"f_8697compiler.scm",(void*)f_8697},
{"f_8656compiler.scm",(void*)f_8656},
{"f_8665compiler.scm",(void*)f_8665},
{"f_8646compiler.scm",(void*)f_8646},
{"f_8651compiler.scm",(void*)f_8651},
{"f_8640compiler.scm",(void*)f_8640},
{"f_7112compiler.scm",(void*)f_7112},
{"f_7116compiler.scm",(void*)f_7116},
{"f_7866compiler.scm",(void*)f_7866},
{"f_7869compiler.scm",(void*)f_7869},
{"f_7873compiler.scm",(void*)f_7873},
{"f_7876compiler.scm",(void*)f_7876},
{"f_7889compiler.scm",(void*)f_7889},
{"f_8524compiler.scm",(void*)f_8524},
{"f_7893compiler.scm",(void*)f_7893},
{"f_8489compiler.scm",(void*)f_8489},
{"f_7900compiler.scm",(void*)f_7900},
{"f_8435compiler.scm",(void*)f_8435},
{"f_8438compiler.scm",(void*)f_8438},
{"f_8450compiler.scm",(void*)f_8450},
{"f_8444compiler.scm",(void*)f_8444},
{"f_7903compiler.scm",(void*)f_7903},
{"f_7906compiler.scm",(void*)f_7906},
{"f_8418compiler.scm",(void*)f_8418},
{"f_8410compiler.scm",(void*)f_8410},
{"f_8378compiler.scm",(void*)f_8378},
{"f_8384compiler.scm",(void*)f_8384},
{"f_7909compiler.scm",(void*)f_7909},
{"f_8340compiler.scm",(void*)f_8340},
{"f_8349compiler.scm",(void*)f_8349},
{"f_8352compiler.scm",(void*)f_8352},
{"f_7912compiler.scm",(void*)f_7912},
{"f_8241compiler.scm",(void*)f_8241},
{"f_8259compiler.scm",(void*)f_8259},
{"f_8302compiler.scm",(void*)f_8302},
{"f_8327compiler.scm",(void*)f_8327},
{"f_8323compiler.scm",(void*)f_8323},
{"f_8309compiler.scm",(void*)f_8309},
{"f_8312compiler.scm",(void*)f_8312},
{"f_8263compiler.scm",(void*)f_8263},
{"f_8269compiler.scm",(void*)f_8269},
{"f_7915compiler.scm",(void*)f_7915},
{"f_8219compiler.scm",(void*)f_8219},
{"f_8205compiler.scm",(void*)f_8205},
{"f_8212compiler.scm",(void*)f_8212},
{"f_8193compiler.scm",(void*)f_8193},
{"f_8178compiler.scm",(void*)f_8178},
{"f_7918compiler.scm",(void*)f_7918},
{"f_8090compiler.scm",(void*)f_8090},
{"f_8164compiler.scm",(void*)f_8164},
{"f_8096compiler.scm",(void*)f_8096},
{"f_8154compiler.scm",(void*)f_8154},
{"f_8146compiler.scm",(void*)f_8146},
{"f_8142compiler.scm",(void*)f_8142},
{"f_8099compiler.scm",(void*)f_8099},
{"f_8102compiler.scm",(void*)f_8102},
{"f_7921compiler.scm",(void*)f_7921},
{"f_7949compiler.scm",(void*)f_7949},
{"f_7970compiler.scm",(void*)f_7970},
{"f_7991compiler.scm",(void*)f_7991},
{"f_7997compiler.scm",(void*)f_7997},
{"f_7924compiler.scm",(void*)f_7924},
{"f_7930compiler.scm",(void*)f_7930},
{"f_7934compiler.scm",(void*)f_7934},
{"f_7879compiler.scm",(void*)f_7879},
{"f_7883compiler.scm",(void*)f_7883},
{"f_7886compiler.scm",(void*)f_7886},
{"f_7841compiler.scm",(void*)f_7841},
{"f_7851compiler.scm",(void*)f_7851},
{"f_7859compiler.scm",(void*)f_7859},
{"f_7827compiler.scm",(void*)f_7827},
{"f_7835compiler.scm",(void*)f_7835},
{"f_7706compiler.scm",(void*)f_7706},
{"f_7712compiler.scm",(void*)f_7712},
{"f_7125compiler.scm",(void*)f_7125},
{"f_7147compiler.scm",(void*)f_7147},
{"f_7668compiler.scm",(void*)f_7668},
{"f_7662compiler.scm",(void*)f_7662},
{"f_7635compiler.scm",(void*)f_7635},
{"f_7644compiler.scm",(void*)f_7644},
{"f_7629compiler.scm",(void*)f_7629},
{"f_7554compiler.scm",(void*)f_7554},
{"f_7583compiler.scm",(void*)f_7583},
{"f_7598compiler.scm",(void*)f_7598},
{"f_7602compiler.scm",(void*)f_7602},
{"f_7589compiler.scm",(void*)f_7589},
{"f_7557compiler.scm",(void*)f_7557},
{"f_7580compiler.scm",(void*)f_7580},
{"f_7560compiler.scm",(void*)f_7560},
{"f_7563compiler.scm",(void*)f_7563},
{"f_7566compiler.scm",(void*)f_7566},
{"f_7444compiler.scm",(void*)f_7444},
{"f_7536compiler.scm",(void*)f_7536},
{"f_7451compiler.scm",(void*)f_7451},
{"f_7526compiler.scm",(void*)f_7526},
{"f_7530compiler.scm",(void*)f_7530},
{"f_7454compiler.scm",(void*)f_7454},
{"f_7457compiler.scm",(void*)f_7457},
{"f_7511compiler.scm",(void*)f_7511},
{"f_7460compiler.scm",(void*)f_7460},
{"f_7463compiler.scm",(void*)f_7463},
{"f_7496compiler.scm",(void*)f_7496},
{"f_7466compiler.scm",(void*)f_7466},
{"f_7493compiler.scm",(void*)f_7493},
{"f_7469compiler.scm",(void*)f_7469},
{"f_7400compiler.scm",(void*)f_7400},
{"f_7419compiler.scm",(void*)f_7419},
{"f_7404compiler.scm",(void*)f_7404},
{"f_7417compiler.scm",(void*)f_7417},
{"f_7408compiler.scm",(void*)f_7408},
{"f_7333compiler.scm",(void*)f_7333},
{"f_7338compiler.scm",(void*)f_7338},
{"f_7365compiler.scm",(void*)f_7365},
{"f_7368compiler.scm",(void*)f_7368},
{"f_7371compiler.scm",(void*)f_7371},
{"f_7356compiler.scm",(void*)f_7356},
{"f_7261compiler.scm",(void*)f_7261},
{"f_7309compiler.scm",(void*)f_7309},
{"f_7272compiler.scm",(void*)f_7272},
{"f_7291compiler.scm",(void*)f_7291},
{"f_7238compiler.scm",(void*)f_7238},
{"f_7241compiler.scm",(void*)f_7241},
{"f_7202compiler.scm",(void*)f_7202},
{"f_7159compiler.scm",(void*)f_7159},
{"f_7190compiler.scm",(void*)f_7190},
{"f_7718compiler.scm",(void*)f_7718},
{"f_7731compiler.scm",(void*)f_7731},
{"f_7791compiler.scm",(void*)f_7791},
{"f_7740compiler.scm",(void*)f_7740},
{"f_7743compiler.scm",(void*)f_7743},
{"f_7746compiler.scm",(void*)f_7746},
{"f_7821compiler.scm",(void*)f_7821},
{"f_7118compiler.scm",(void*)f_7118},
{"f_7103compiler.scm",(void*)f_7103},
{"f_7094compiler.scm",(void*)f_7094},
{"f_7085compiler.scm",(void*)f_7085},
{"f_7076compiler.scm",(void*)f_7076},
{"f_7067compiler.scm",(void*)f_7067},
{"f_7058compiler.scm",(void*)f_7058},
{"f_7049compiler.scm",(void*)f_7049},
{"f_7040compiler.scm",(void*)f_7040},
{"f_7031compiler.scm",(void*)f_7031},
{"f_7022compiler.scm",(void*)f_7022},
{"f_7016compiler.scm",(void*)f_7016},
{"f_7010compiler.scm",(void*)f_7010},
{"f_6335compiler.scm",(void*)f_6335},
{"f_6982compiler.scm",(void*)f_6982},
{"f_6897compiler.scm",(void*)f_6897},
{"f_6903compiler.scm",(void*)f_6903},
{"f_6923compiler.scm",(void*)f_6923},
{"f_6941compiler.scm",(void*)f_6941},
{"f_6950compiler.scm",(void*)f_6950},
{"f_6976compiler.scm",(void*)f_6976},
{"f_6964compiler.scm",(void*)f_6964},
{"f_6917compiler.scm",(void*)f_6917},
{"f_6881compiler.scm",(void*)f_6881},
{"f_6887compiler.scm",(void*)f_6887},
{"f_6756compiler.scm",(void*)f_6756},
{"f_6760compiler.scm",(void*)f_6760},
{"f_6763compiler.scm",(void*)f_6763},
{"f_6817compiler.scm",(void*)f_6817},
{"f_6813compiler.scm",(void*)f_6813},
{"f_6809compiler.scm",(void*)f_6809},
{"f_6788compiler.scm",(void*)f_6788},
{"f_6794compiler.scm",(void*)f_6794},
{"f_6805compiler.scm",(void*)f_6805},
{"f_6798compiler.scm",(void*)f_6798},
{"f_6786compiler.scm",(void*)f_6786},
{"f_6382compiler.scm",(void*)f_6382},
{"f_6404compiler.scm",(void*)f_6404},
{"f_6670compiler.scm",(void*)f_6670},
{"f_6827compiler.scm",(void*)f_6827},
{"f_6830compiler.scm",(void*)f_6830},
{"f_6875compiler.scm",(void*)f_6875},
{"f_6871compiler.scm",(void*)f_6871},
{"f_6867compiler.scm",(void*)f_6867},
{"f_6863compiler.scm",(void*)f_6863},
{"f_6635compiler.scm",(void*)f_6635},
{"f_6661compiler.scm",(void*)f_6661},
{"f_6585compiler.scm",(void*)f_6585},
{"f_6594compiler.scm",(void*)f_6594},
{"f_6622compiler.scm",(void*)f_6622},
{"f_6618compiler.scm",(void*)f_6618},
{"f_6572compiler.scm",(void*)f_6572},
{"f_6510compiler.scm",(void*)f_6510},
{"f_6533compiler.scm",(void*)f_6533},
{"f_6547compiler.scm",(void*)f_6547},
{"f_6416compiler.scm",(void*)f_6416},
{"f_6419compiler.scm",(void*)f_6419},
{"f_6495compiler.scm",(void*)f_6495},
{"f_6491compiler.scm",(void*)f_6491},
{"f_6487compiler.scm",(void*)f_6487},
{"f_6460compiler.scm",(void*)f_6460},
{"f_6471compiler.scm",(void*)f_6471},
{"f_6475compiler.scm",(void*)f_6475},
{"f_6454compiler.scm",(void*)f_6454},
{"f_6420compiler.scm",(void*)f_6420},
{"f_6431compiler.scm",(void*)f_6431},
{"f_6338compiler.scm",(void*)f_6338},
{"f_6342compiler.scm",(void*)f_6342},
{"f_6365compiler.scm",(void*)f_6365},
{"f_6376compiler.scm",(void*)f_6376},
{"f_6359compiler.scm",(void*)f_6359},
{"f_6245compiler.scm",(void*)f_6245},
{"f_6277compiler.scm",(void*)f_6277},
{"f_6296compiler.scm",(void*)f_6296},
{"f_6319compiler.scm",(void*)f_6319},
{"f_6302compiler.scm",(void*)f_6302},
{"f_6248compiler.scm",(void*)f_6248},
{"f_6254compiler.scm",(void*)f_6254},
{"f_6264compiler.scm",(void*)f_6264},
{"f_6164compiler.scm",(void*)f_6164},
{"f_6168compiler.scm",(void*)f_6168},
{"f_6171compiler.scm",(void*)f_6171},
{"f_6174compiler.scm",(void*)f_6174},
{"f_6190compiler.scm",(void*)f_6190},
{"f_6177compiler.scm",(void*)f_6177},
{"f_6180compiler.scm",(void*)f_6180},
{"f_6183compiler.scm",(void*)f_6183},
{"f_6127compiler.scm",(void*)f_6127},
{"f_6150compiler.scm",(void*)f_6150},
{"f_6137compiler.scm",(void*)f_6137},
{"f_6140compiler.scm",(void*)f_6140},
{"f_6143compiler.scm",(void*)f_6143},
{"f_6090compiler.scm",(void*)f_6090},
{"f_6113compiler.scm",(void*)f_6113},
{"f_6100compiler.scm",(void*)f_6100},
{"f_6103compiler.scm",(void*)f_6103},
{"f_6106compiler.scm",(void*)f_6106},
{"f_6045compiler.scm",(void*)f_6045},
{"f_6052compiler.scm",(void*)f_6052},
{"f_6058compiler.scm",(void*)f_6058},
{"f_6000compiler.scm",(void*)f_6000},
{"f_6007compiler.scm",(void*)f_6007},
{"f_6013compiler.scm",(void*)f_6013},
{"f_5846compiler.scm",(void*)f_5846},
{"f_5994compiler.scm",(void*)f_5994},
{"f_5850compiler.scm",(void*)f_5850},
{"f_5853compiler.scm",(void*)f_5853},
{"f_5856compiler.scm",(void*)f_5856},
{"f_5859compiler.scm",(void*)f_5859},
{"f_5862compiler.scm",(void*)f_5862},
{"f_5988compiler.scm",(void*)f_5988},
{"f_5872compiler.scm",(void*)f_5872},
{"f_5963compiler.scm",(void*)f_5963},
{"f_5971compiler.scm",(void*)f_5971},
{"f_5875compiler.scm",(void*)f_5875},
{"f_5915compiler.scm",(void*)f_5915},
{"f_5918compiler.scm",(void*)f_5918},
{"f_5937compiler.scm",(void*)f_5937},
{"f_5933compiler.scm",(void*)f_5933},
{"f_5929compiler.scm",(void*)f_5929},
{"f_5908compiler.scm",(void*)f_5908},
{"f_5898compiler.scm",(void*)f_5898},
{"f_5886compiler.scm",(void*)f_5886},
{"f_5837compiler.scm",(void*)f_5837},
{"f_5828compiler.scm",(void*)f_5828},
{"f_5819compiler.scm",(void*)f_5819},
{"f_5810compiler.scm",(void*)f_5810},
{"f_5801compiler.scm",(void*)f_5801},
{"f_5792compiler.scm",(void*)f_5792},
{"f_5783compiler.scm",(void*)f_5783},
{"f_5774compiler.scm",(void*)f_5774},
{"f_5765compiler.scm",(void*)f_5765},
{"f_5756compiler.scm",(void*)f_5756},
{"f_5747compiler.scm",(void*)f_5747},
{"f_5738compiler.scm",(void*)f_5738},
{"f_5729compiler.scm",(void*)f_5729},
{"f_5720compiler.scm",(void*)f_5720},
{"f_5711compiler.scm",(void*)f_5711},
{"f_5702compiler.scm",(void*)f_5702},
{"f_5696compiler.scm",(void*)f_5696},
{"f_5690compiler.scm",(void*)f_5690},
{"f_4745compiler.scm",(void*)f_4745},
{"f_4799compiler.scm",(void*)f_4799},
{"f_4803compiler.scm",(void*)f_4803},
{"f_5659compiler.scm",(void*)f_5659},
{"f_5669compiler.scm",(void*)f_5669},
{"f_5664compiler.scm",(void*)f_5664},
{"f_5631compiler.scm",(void*)f_5631},
{"f_5637compiler.scm",(void*)f_5637},
{"f_5613compiler.scm",(void*)f_5613},
{"f_5617compiler.scm",(void*)f_5617},
{"f_5585compiler.scm",(void*)f_5585},
{"f_5592compiler.scm",(void*)f_5592},
{"f_5568compiler.scm",(void*)f_5568},
{"f_5494compiler.scm",(void*)f_5494},
{"f_5498compiler.scm",(void*)f_5498},
{"f_5481compiler.scm",(void*)f_5481},
{"f_5473compiler.scm",(void*)f_5473},
{"f_5477compiler.scm",(void*)f_5477},
{"f_5318compiler.scm",(void*)f_5318},
{"f_5428compiler.scm",(void*)f_5428},
{"f_5417compiler.scm",(void*)f_5417},
{"f_5421compiler.scm",(void*)f_5421},
{"f_5388compiler.scm",(void*)f_5388},
{"f_5363compiler.scm",(void*)f_5363},
{"f_5338compiler.scm",(void*)f_5338},
{"f_5305compiler.scm",(void*)f_5305},
{"f_5257compiler.scm",(void*)f_5257},
{"f_5266compiler.scm",(void*)f_5266},
{"f_5264compiler.scm",(void*)f_5264},
{"f_5167compiler.scm",(void*)f_5167},
{"f_5145compiler.scm",(void*)f_5145},
{"f_5149compiler.scm",(void*)f_5149},
{"f_5118compiler.scm",(void*)f_5118},
{"f_5122compiler.scm",(void*)f_5122},
{"f_5104compiler.scm",(void*)f_5104},
{"f_5108compiler.scm",(void*)f_5108},
{"f_5083compiler.scm",(void*)f_5083},
{"f_5069compiler.scm",(void*)f_5069},
{"f_4986compiler.scm",(void*)f_4986},
{"f_4969compiler.scm",(void*)f_4969},
{"f_4973compiler.scm",(void*)f_4973},
{"f_4940compiler.scm",(void*)f_4940},
{"f_4915compiler.scm",(void*)f_4915},
{"f_4868compiler.scm",(void*)f_4868},
{"f_4898compiler.scm",(void*)f_4898},
{"f_4874compiler.scm",(void*)f_4874},
{"f_4877compiler.scm",(void*)f_4877},
{"f_4884compiler.scm",(void*)f_4884},
{"f_4880compiler.scm",(void*)f_4880},
{"f_4818compiler.scm",(void*)f_4818},
{"f_4821compiler.scm",(void*)f_4821},
{"f_4855compiler.scm",(void*)f_4855},
{"f_4849compiler.scm",(void*)f_4849},
{"f_4830compiler.scm",(void*)f_4830},
{"f_4839compiler.scm",(void*)f_4839},
{"f_4847compiler.scm",(void*)f_4847},
{"f_4833compiler.scm",(void*)f_4833},
{"f_4837compiler.scm",(void*)f_4837},
{"f_4809compiler.scm",(void*)f_4809},
{"f_4748compiler.scm",(void*)f_4748},
{"f_4771compiler.scm",(void*)f_4771},
{"f_4761compiler.scm",(void*)f_4761},
{"f_1966compiler.scm",(void*)f_1966},
{"f_4740compiler.scm",(void*)f_4740},
{"f_4703compiler.scm",(void*)f_4703},
{"f_4706compiler.scm",(void*)f_4706},
{"f_4721compiler.scm",(void*)f_4721},
{"f_4730compiler.scm",(void*)f_4730},
{"f_4734compiler.scm",(void*)f_4734},
{"f_4717compiler.scm",(void*)f_4717},
{"f_4690compiler.scm",(void*)f_4690},
{"f_4696compiler.scm",(void*)f_4696},
{"f_2156compiler.scm",(void*)f_2156},
{"f_2193compiler.scm",(void*)f_2193},
{"f_4551compiler.scm",(void*)f_4551},
{"f_4666compiler.scm",(void*)f_4666},
{"f_4566compiler.scm",(void*)f_4566},
{"f_4653compiler.scm",(void*)f_4653},
{"f_4575compiler.scm",(void*)f_4575},
{"f_4578compiler.scm",(void*)f_4578},
{"f_4587compiler.scm",(void*)f_4587},
{"f_4609compiler.scm",(void*)f_4609},
{"f_4602compiler.scm",(void*)f_4602},
{"f_4554compiler.scm",(void*)f_4554},
{"f_4557compiler.scm",(void*)f_4557},
{"f_2220compiler.scm",(void*)f_2220},
{"f_2226compiler.scm",(void*)f_2226},
{"f_4533compiler.scm",(void*)f_4533},
{"f_2229compiler.scm",(void*)f_2229},
{"f_2236compiler.scm",(void*)f_2236},
{"f_2245compiler.scm",(void*)f_2245},
{"f_2254compiler.scm",(void*)f_2254},
{"f_2388compiler.scm",(void*)f_2388},
{"f_4453compiler.scm",(void*)f_4453},
{"f_4459compiler.scm",(void*)f_4459},
{"f_4364compiler.scm",(void*)f_4364},
{"f_4424compiler.scm",(void*)f_4424},
{"f_4324compiler.scm",(void*)f_4324},
{"f_4328compiler.scm",(void*)f_4328},
{"f_4334compiler.scm",(void*)f_4334},
{"f_4348compiler.scm",(void*)f_4348},
{"f_4337compiler.scm",(void*)f_4337},
{"f_3960compiler.scm",(void*)f_3960},
{"f_4308compiler.scm",(void*)f_4308},
{"f_3982compiler.scm",(void*)f_3982},
{"f_4273compiler.scm",(void*)f_4273},
{"f_3985compiler.scm",(void*)f_3985},
{"f_3996compiler.scm",(void*)f_3996},
{"f_4223compiler.scm",(void*)f_4223},
{"f_4267compiler.scm",(void*)f_4267},
{"f_4263compiler.scm",(void*)f_4263},
{"f_4259compiler.scm",(void*)f_4259},
{"f_4247compiler.scm",(void*)f_4247},
{"f_4016compiler.scm",(void*)f_4016},
{"f_4095compiler.scm",(void*)f_4095},
{"f_4072compiler.scm",(void*)f_4072},
{"f_4067compiler.scm",(void*)f_4067},
{"f_4030compiler.scm",(void*)f_4030},
{"f_4020compiler.scm",(void*)f_4020},
{"f_4004compiler.scm",(void*)f_4004},
{"f_3992compiler.scm",(void*)f_3992},
{"f_3950compiler.scm",(void*)f_3950},
{"f_3927compiler.scm",(void*)f_3927},
{"f_3925compiler.scm",(void*)f_3925},
{"f_3854compiler.scm",(void*)f_3854},
{"f_3872compiler.scm",(void*)f_3872},
{"f_3894compiler.scm",(void*)f_3894},
{"f_3900compiler.scm",(void*)f_3900},
{"f_3878compiler.scm",(void*)f_3878},
{"f_3885compiler.scm",(void*)f_3885},
{"f_3860compiler.scm",(void*)f_3860},
{"f_3866compiler.scm",(void*)f_3866},
{"f_3852compiler.scm",(void*)f_3852},
{"f_3790compiler.scm",(void*)f_3790},
{"f_3801compiler.scm",(void*)f_3801},
{"f_3811compiler.scm",(void*)f_3811},
{"f_3814compiler.scm",(void*)f_3814},
{"f_3818compiler.scm",(void*)f_3818},
{"f_3804compiler.scm",(void*)f_3804},
{"f_3729compiler.scm",(void*)f_3729},
{"f_3733compiler.scm",(void*)f_3733},
{"f_3771compiler.scm",(void*)f_3771},
{"f_3737compiler.scm",(void*)f_3737},
{"f_3751compiler.scm",(void*)f_3751},
{"f_3749compiler.scm",(void*)f_3749},
{"f_3711compiler.scm",(void*)f_3711},
{"f_3719compiler.scm",(void*)f_3719},
{"f_3584compiler.scm",(void*)f_3584},
{"f_3587compiler.scm",(void*)f_3587},
{"f_3593compiler.scm",(void*)f_3593},
{"f_3672compiler.scm",(void*)f_3672},
{"f_3649compiler.scm",(void*)f_3649},
{"f_3624compiler.scm",(void*)f_3624},
{"f_3632compiler.scm",(void*)f_3632},
{"f_3620compiler.scm",(void*)f_3620},
{"f_3616compiler.scm",(void*)f_3616},
{"f_3608compiler.scm",(void*)f_3608},
{"f_3509compiler.scm",(void*)f_3509},
{"f_3518compiler.scm",(void*)f_3518},
{"f_3557compiler.scm",(void*)f_3557},
{"f_3549compiler.scm",(void*)f_3549},
{"f_3521compiler.scm",(void*)f_3521},
{"f_3541compiler.scm",(void*)f_3541},
{"f_3533compiler.scm",(void*)f_3533},
{"f_3489compiler.scm",(void*)f_3489},
{"f_3435compiler.scm",(void*)f_3435},
{"f_3438compiler.scm",(void*)f_3438},
{"f_3441compiler.scm",(void*)f_3441},
{"f_3445compiler.scm",(void*)f_3445},
{"f_3449compiler.scm",(void*)f_3449},
{"f_3368compiler.scm",(void*)f_3368},
{"f_3380compiler.scm",(void*)f_3380},
{"f_3353compiler.scm",(void*)f_3353},
{"f_3340compiler.scm",(void*)f_3340},
{"f_3327compiler.scm",(void*)f_3327},
{"f_3314compiler.scm",(void*)f_3314},
{"f_3301compiler.scm",(void*)f_3301},
{"f_3234compiler.scm",(void*)f_3234},
{"f_3253compiler.scm",(void*)f_3253},
{"f_3280compiler.scm",(void*)f_3280},
{"f_3284compiler.scm",(void*)f_3284},
{"f_3273compiler.scm",(void*)f_3273},
{"f_3247compiler.scm",(void*)f_3247},
{"f_3221compiler.scm",(void*)f_3221},
{"f_3206compiler.scm",(void*)f_3206},
{"f_3179compiler.scm",(void*)f_3179},
{"f_3183compiler.scm",(void*)f_3183},
{"f_3158compiler.scm",(void*)f_3158},
{"f_3129compiler.scm",(void*)f_3129},
{"f_3133compiler.scm",(void*)f_3133},
{"f_3100compiler.scm",(void*)f_3100},
{"f_3104compiler.scm",(void*)f_3104},
{"f_2926compiler.scm",(void*)f_2926},
{"f_2935compiler.scm",(void*)f_2935},
{"f_2938compiler.scm",(void*)f_2938},
{"f_3046compiler.scm",(void*)f_3046},
{"f_3075compiler.scm",(void*)f_3075},
{"f_3079compiler.scm",(void*)f_3079},
{"f_3049compiler.scm",(void*)f_3049},
{"f_3055compiler.scm",(void*)f_3055},
{"f_3068compiler.scm",(void*)f_3068},
{"f_3058compiler.scm",(void*)f_3058},
{"f_2941compiler.scm",(void*)f_2941},
{"f_3036compiler.scm",(void*)f_3036},
{"f_2944compiler.scm",(void*)f_2944},
{"f_2999compiler.scm",(void*)f_2999},
{"f_3030compiler.scm",(void*)f_3030},
{"f_3022compiler.scm",(void*)f_3022},
{"f_2956compiler.scm",(void*)f_2956},
{"f_2987compiler.scm",(void*)f_2987},
{"f_2975compiler.scm",(void*)f_2975},
{"f_2888compiler.scm",(void*)f_2888},
{"f_2914compiler.scm",(void*)f_2914},
{"f_2891compiler.scm",(void*)f_2891},
{"f_2906compiler.scm",(void*)f_2906},
{"f_2904compiler.scm",(void*)f_2904},
{"f_2894compiler.scm",(void*)f_2894},
{"f_2897compiler.scm",(void*)f_2897},
{"f_2623compiler.scm",(void*)f_2623},
{"f_2838compiler.scm",(void*)f_2838},
{"f_2849compiler.scm",(void*)f_2849},
{"f_2843compiler.scm",(void*)f_2843},
{"f_2632compiler.scm",(void*)f_2632},
{"f_2637compiler.scm",(void*)f_2637},
{"f_2641compiler.scm",(void*)f_2641},
{"f_2835compiler.scm",(void*)f_2835},
{"f_2644compiler.scm",(void*)f_2644},
{"f_2827compiler.scm",(void*)f_2827},
{"f_2647compiler.scm",(void*)f_2647},
{"f_2650compiler.scm",(void*)f_2650},
{"f_2825compiler.scm",(void*)f_2825},
{"f_2818compiler.scm",(void*)f_2818},
{"f_2653compiler.scm",(void*)f_2653},
{"f_2659compiler.scm",(void*)f_2659},
{"f_2668compiler.scm",(void*)f_2668},
{"f_2688compiler.scm",(void*)f_2688},
{"f_2772compiler.scm",(void*)f_2772},
{"f_2768compiler.scm",(void*)f_2768},
{"f_2764compiler.scm",(void*)f_2764},
{"f_2721compiler.scm",(void*)f_2721},
{"f_2728compiler.scm",(void*)f_2728},
{"f_2678compiler.scm",(void*)f_2678},
{"f_2549compiler.scm",(void*)f_2549},
{"f_2555compiler.scm",(void*)f_2555},
{"f_2558compiler.scm",(void*)f_2558},
{"f_2611compiler.scm",(void*)f_2611},
{"f_2561compiler.scm",(void*)f_2561},
{"f_2564compiler.scm",(void*)f_2564},
{"f_2591compiler.scm",(void*)f_2591},
{"f_2599compiler.scm",(void*)f_2599},
{"f_2571compiler.scm",(void*)f_2571},
{"f_2585compiler.scm",(void*)f_2585},
{"f_2579compiler.scm",(void*)f_2579},
{"f_2575compiler.scm",(void*)f_2575},
{"f_2435compiler.scm",(void*)f_2435},
{"f_2445compiler.scm",(void*)f_2445},
{"f_2456compiler.scm",(void*)f_2456},
{"f_2530compiler.scm",(void*)f_2530},
{"f_2540compiler.scm",(void*)f_2540},
{"f_2521compiler.scm",(void*)f_2521},
{"f_2495compiler.scm",(void*)f_2495},
{"f_2509compiler.scm",(void*)f_2509},
{"f_2507compiler.scm",(void*)f_2507},
{"f_2483compiler.scm",(void*)f_2483},
{"f_2460compiler.scm",(void*)f_2460},
{"f_2467compiler.scm",(void*)f_2467},
{"f_2450compiler.scm",(void*)f_2450},
{"f_2429compiler.scm",(void*)f_2429},
{"f_2397compiler.scm",(void*)f_2397},
{"f_2400compiler.scm",(void*)f_2400},
{"f_2411compiler.scm",(void*)f_2411},
{"f_2405compiler.scm",(void*)f_2405},
{"f_2403compiler.scm",(void*)f_2403},
{"f_2355compiler.scm",(void*)f_2355},
{"f_2367compiler.scm",(void*)f_2367},
{"f_2371compiler.scm",(void*)f_2371},
{"f_2323compiler.scm",(void*)f_2323},
{"f_2277compiler.scm",(void*)f_2277},
{"f_2284compiler.scm",(void*)f_2284},
{"f_2288compiler.scm",(void*)f_2288},
{"f_2292compiler.scm",(void*)f_2292},
{"f_2181compiler.scm",(void*)f_2181},
{"f_2175compiler.scm",(void*)f_2175},
{"f_2138compiler.scm",(void*)f_2138},
{"f_2147compiler.scm",(void*)f_2147},
{"f_2047compiler.scm",(void*)f_2047},
{"f_2051compiler.scm",(void*)f_2051},
{"f_2064compiler.scm",(void*)f_2064},
{"f_2112compiler.scm",(void*)f_2112},
{"f_2122compiler.scm",(void*)f_2122},
{"f_2082compiler.scm",(void*)f_2082},
{"f_2092compiler.scm",(void*)f_2092},
{"f_2005compiler.scm",(void*)f_2005},
{"f_2012compiler.scm",(void*)f_2012},
{"f_1981compiler.scm",(void*)f_1981},
{"f_1987compiler.scm",(void*)f_1987},
{"f_1969compiler.scm",(void*)f_1969},
{"f_1895compiler.scm",(void*)f_1895},
{"f_1964compiler.scm",(void*)f_1964},
{"f_1899compiler.scm",(void*)f_1899},
{"f_1957compiler.scm",(void*)f_1957},
{"f_1902compiler.scm",(void*)f_1902},
{"f_1950compiler.scm",(void*)f_1950},
{"f_1905compiler.scm",(void*)f_1905},
{"f_1909compiler.scm",(void*)f_1909},
{"f_1913compiler.scm",(void*)f_1913},
{"f_1943compiler.scm",(void*)f_1943},
{"f_1916compiler.scm",(void*)f_1916},
{"f_1936compiler.scm",(void*)f_1936},
{"f_1919compiler.scm",(void*)f_1919},
{"f_1929compiler.scm",(void*)f_1929},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
