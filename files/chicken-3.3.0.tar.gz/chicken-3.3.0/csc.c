/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-06-28 12:20
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10664	compiled 2008-06-28 on galinha (Linux)
   command line: csc.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -output-file csc.c
   used units: library eval data_structures extras srfi_69 data_structures ports srfi_1 srfi_13 utils extras
*/

#include "chicken.h"


#ifndef C_TARGET_CC
# define C_TARGET_CC  C_INSTALL_CC
#endif

#ifndef C_TARGET_CXX
# define C_TARGET_CXX  C_INSTALL_CXX
#endif

#ifndef C_TARGET_CFLAGS
# define C_TARGET_CFLAGS  C_INSTALL_CFLAGS
#endif

#ifndef C_TARGET_LDFLAGS
# define C_TARGET_LDFLAGS  C_INSTALL_LDFLAGS
#endif

#ifndef C_TARGET_BIN_HOME
# define C_TARGET_BIN_HOME  C_INSTALL_BIN_HOME
#endif

#ifndef C_TARGET_LIB_HOME
# define C_TARGET_LIB_HOME  C_INSTALL_LIB_HOME
#endif

#ifndef C_TARGET_STATIC_LIB_HOME
# define C_TARGET_STATIC_LIB_HOME  C_INSTALL_STATIC_LIB_HOME
#endif

#ifndef C_TARGET_INCLUDE_HOME
# define C_TARGET_INCLUDE_HOME  C_INSTALL_INCLUDE_HOME
#endif

#ifndef C_TARGET_SHARE_HOME
# define C_TARGET_SHARE_HOME  C_INSTALL_SHARE_HOME
#endif

#ifndef C_TARGET_RUN_LIB_HOME
# define C_TARGET_RUN_LIB_HOME    C_TARGET_LIB_HOME
#endif

#ifndef C_CHICKEN_PROGRAM
# define C_CHICKEN_PROGRAM     "chicken"
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[369];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_ccall f_404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_407)
static void C_ccall f_407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_416)
static void C_ccall f_416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_419)
static void C_ccall f_419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_435)
static void C_fcall f_435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_452)
static void C_ccall f_452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_456)
static void C_ccall f_456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_493)
static void C_ccall f_493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_497)
static void C_ccall f_497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_501)
static void C_ccall f_501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_505)
static void C_ccall f_505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_509)
static void C_ccall f_509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_513)
static void C_ccall f_513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_544)
static void C_ccall f_544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_548)
static void C_ccall f_548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_556)
static void C_ccall f_556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_561)
static void C_ccall f_561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_587)
static void C_ccall f_587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_591)
static void C_ccall f_591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3151)
static void C_ccall f_3151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_599)
static void C_fcall f_599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3114)
static void C_ccall f_3114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_607)
static void C_fcall f_607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_616)
static void C_ccall f_616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_624)
static void C_fcall f_624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_632)
static void C_ccall f_632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_637)
static void C_fcall f_637(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_735)
static void C_fcall f_735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_fcall f_1402(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_fcall f_1643(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_fcall f_1646(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1649)
static void C_fcall f_1649(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_fcall f_1700(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_fcall f_1709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_fcall f_1935(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_fcall f_1787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1293)
static void C_fcall f_1293(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1226)
static void C_ccall f_1226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1138)
static void C_fcall f_1138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1066)
static void C_ccall f_1066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_967)
static void C_ccall f_967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_960)
static void C_ccall f_960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_944)
static void C_ccall f_944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_932)
static void C_ccall f_932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_920)
static void C_ccall f_920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_746)
static void C_ccall f_746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_875)
static void C_ccall f_875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_878)
static void C_ccall f_878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_881)
static void C_ccall f_881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_884)
static void C_ccall f_884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_753)
static void C_ccall f_753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_838)
static void C_fcall f_838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_848)
static void C_ccall f_848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_841)
static void C_fcall f_841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_fcall f_2354(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_fcall f_2299(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2314)
static void C_fcall f_2314(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2222)
static void C_fcall f_2222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2155)
static void C_fcall f_2155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_800)
static void C_ccall f_800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_803)
static void C_ccall f_803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_756)
static void C_ccall f_756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_762)
static void C_ccall f_762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_794)
static void C_ccall f_794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_790)
static void C_ccall f_790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_768)
static void C_ccall f_768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_fcall f_2492(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_706)
static void C_fcall f_706(C_word t0,C_word t1) C_noret;
C_noret_decl(f_711)
static void C_ccall f_711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_715)
static void C_ccall f_715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_667)
static void C_fcall f_667(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_685)
static void C_ccall f_685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_660)
static void C_fcall f_660(C_word t0,C_word t1) C_noret;
C_noret_decl(f_665)
static void C_ccall f_665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_fcall f_2936(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_fcall f_2852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2882)
static void C_fcall f_2882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2750)
static void C_fcall f_2750(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_fcall f_2698(C_word t0) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_fcall f_2601(C_word t0) C_noret;
C_noret_decl(f_2605)
static void C_ccall f_2605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_fcall f_2611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_fcall f_2616(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_fcall f_2657(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_fcall f_2661(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2449)
static void C_fcall f_2449(C_word t0) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_479)
static void C_fcall f_479(C_word t0,C_word t1) C_noret;
C_noret_decl(f_486)
static void C_ccall f_486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_466)
static void C_fcall f_466(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_437)
static void C_fcall f_437(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_448)
static void C_ccall f_448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_441)
static void C_ccall f_441(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_435)
static void C_fcall trf_435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_435(t0,t1);}

C_noret_decl(trf_599)
static void C_fcall trf_599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_599(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_599(t0,t1);}

C_noret_decl(trf_607)
static void C_fcall trf_607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_607(t0,t1);}

C_noret_decl(trf_624)
static void C_fcall trf_624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_624(t0,t1);}

C_noret_decl(trf_637)
static void C_fcall trf_637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_637(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_637(t0,t1);}

C_noret_decl(trf_735)
static void C_fcall trf_735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_735(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_735(t0,t1,t2);}

C_noret_decl(trf_1402)
static void C_fcall trf_1402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1402(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1402(t0,t1);}

C_noret_decl(trf_1643)
static void C_fcall trf_1643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1643(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1643(t0,t1);}

C_noret_decl(trf_1646)
static void C_fcall trf_1646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1646(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1646(t0,t1);}

C_noret_decl(trf_1649)
static void C_fcall trf_1649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1649(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1649(t0,t1);}

C_noret_decl(trf_1700)
static void C_fcall trf_1700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1700(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1700(t0,t1);}

C_noret_decl(trf_1709)
static void C_fcall trf_1709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1709(t0,t1);}

C_noret_decl(trf_1935)
static void C_fcall trf_1935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1935(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1935(t0,t1);}

C_noret_decl(trf_1787)
static void C_fcall trf_1787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1787(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1787(t0,t1);}

C_noret_decl(trf_1293)
static void C_fcall trf_1293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1293(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1293(t0,t1);}

C_noret_decl(trf_1138)
static void C_fcall trf_1138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1138(t0,t1);}

C_noret_decl(trf_838)
static void C_fcall trf_838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_838(t0,t1);}

C_noret_decl(trf_841)
static void C_fcall trf_841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_841(t0,t1);}

C_noret_decl(trf_2354)
static void C_fcall trf_2354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2354(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2354(t0,t1);}

C_noret_decl(trf_2299)
static void C_fcall trf_2299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2299(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2299(t0,t1);}

C_noret_decl(trf_2314)
static void C_fcall trf_2314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2314(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2314(t0,t1);}

C_noret_decl(trf_2222)
static void C_fcall trf_2222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2222(t0,t1);}

C_noret_decl(trf_2155)
static void C_fcall trf_2155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2155(t0,t1);}

C_noret_decl(trf_2492)
static void C_fcall trf_2492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2492(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2492(t0,t1);}

C_noret_decl(trf_706)
static void C_fcall trf_706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_706(t0,t1);}

C_noret_decl(trf_667)
static void C_fcall trf_667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_667(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_667(t0,t1,t2,t3);}

C_noret_decl(trf_660)
static void C_fcall trf_660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_660(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_660(t0,t1);}

C_noret_decl(trf_2936)
static void C_fcall trf_2936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2936(t0,t1);}

C_noret_decl(trf_2852)
static void C_fcall trf_2852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2852(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2852(t0,t1,t2);}

C_noret_decl(trf_2882)
static void C_fcall trf_2882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2882(t0,t1);}

C_noret_decl(trf_2750)
static void C_fcall trf_2750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2750(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2750(t0,t1);}

C_noret_decl(trf_2698)
static void C_fcall trf_2698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2698(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2698(t0);}

C_noret_decl(trf_2601)
static void C_fcall trf_2601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2601(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2601(t0);}

C_noret_decl(trf_2611)
static void C_fcall trf_2611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2611(t0,t1);}

C_noret_decl(trf_2616)
static void C_fcall trf_2616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2616(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2616(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2657)
static void C_fcall trf_2657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2657(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2657(t0,t1);}

C_noret_decl(trf_2661)
static void C_fcall trf_2661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2661(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2661(t0,t1);}

C_noret_decl(trf_2449)
static void C_fcall trf_2449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2449(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2449(t0);}

C_noret_decl(trf_479)
static void C_fcall trf_479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_479(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_479(t0,t1);}

C_noret_decl(trf_466)
static void C_fcall trf_466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_466(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_466(t0,t1,t2,t3);}

C_noret_decl(trf_437)
static void C_fcall trf_437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_437(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_437(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2488)){
C_save(t1);
C_rereclaim2(2488*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,369);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"mingw32");
lf[4]=C_h_intern(&lf[4],4,"msvc");
lf[6]=C_h_intern(&lf[6],6,"macosx");
lf[10]=C_h_intern(&lf[10],4,"exit");
lf[11]=C_h_intern(&lf[11],7,"fprintf");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\011csc: ~\077~%");
lf[13]=C_h_intern(&lf[13],18,"current-error-port");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[20]=C_h_intern(&lf[20],13,"make-pathname");
lf[22]=C_h_intern(&lf[22],13,"string-append");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[25]=C_h_intern(&lf[25],10,"string-any");
lf[26]=C_h_intern(&lf[26],16,"char-whitespace\077");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003obj");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\005-out:");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\003-Fo");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[49]=C_h_intern(&lf[49],26,"\003sysload-dynamic-extension");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[51]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[107]=C_h_intern(&lf[107],18,"string-intersperse");
lf[108]=C_h_intern(&lf[108],7,"\003sysmap");
lf[110]=C_h_intern(&lf[110],6,"append");
lf[112]=C_h_intern(&lf[112],7,"reverse");
lf[113]=C_h_intern(&lf[113],6,"static");
lf[114]=C_h_intern(&lf[114],14,"static-options");
lf[115]=C_h_intern(&lf[115],21,"extension-information");
lf[116]=C_h_intern(&lf[116],15,"repository-path");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[121]=C_h_intern(&lf[121],9,"\003syserror");
lf[123]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[126]=C_h_intern(&lf[126],17,"string-translate*");
lf[127]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[128]=C_h_intern(&lf[128],16,"\003syslist->string");
lf[129]=C_h_intern(&lf[129],5,"cons*");
lf[130]=C_h_intern(&lf[130],16,"\003sysstring->list");
lf[131]=C_h_intern(&lf[131],3,"any");
lf[134]=C_h_intern(&lf[134],6,"printf");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\0006*** Shell command terminated with exit status ~S: ~A~%");
lf[136]=C_h_intern(&lf[136],6,"system");
lf[137]=C_h_intern(&lf[137],5,"print");
lf[139]=C_h_intern(&lf[139],11,"delete-file");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[141]=C_h_intern(&lf[141],25,"\003sysimplicit-exit-handler");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007-bundle");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\004-dll");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[150]=C_h_intern(&lf[150],12,"\003sysfor-each");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000+install_name_tool -change libchicken.dylib ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\020libchicken.dylib");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[156]=C_h_intern(&lf[156],17,"\003syspeek-c-string");
lf[157]=C_h_intern(&lf[157],7,"sprintf");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\014mv ~A ~A.old");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000TWarning: output file will overwrite source file `~A\047 - renaming source to `"
"~A.old\047~%");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[161]=C_h_intern(&lf[161],26,"pathname-replace-extension");
lf[162]=C_h_intern(&lf[162],4,"last");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[164]=C_h_intern(&lf[164],5,"error");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000!invalid entry in csc control file");
lf[166]=C_h_intern(&lf[166],12,"post-process");
lf[167]=C_h_intern(&lf[167],9,"c-options");
lf[168]=C_h_intern(&lf[168],12,"link-options");
lf[169]=C_h_intern(&lf[169],9,"read-file");
lf[170]=C_h_intern(&lf[170],9,"read-line");
lf[171]=C_h_intern(&lf[171],20,"with-input-from-file");
lf[172]=C_h_intern(&lf[172],12,"file-exists\077");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[174]=C_h_intern(&lf[174],4,"conc");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\006-uses ");
lf[176]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\005#%eof");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[184]=C_h_intern(&lf[184],7,"newline");
lf[185]=C_h_intern(&lf[185],6,"print*");
lf[186]=C_h_intern(&lf[186],5,"-help");
lf[187]=C_h_intern(&lf[187],6,"--help");
lf[188]=C_h_intern(&lf[188],7,"display");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\036\343Usage: csc FILENAME | OPTION ...\012\012  `csc\047 is a driver program for the CHICK"
"EN compiler. Any Scheme, C or object\012  files and all libraries given on the comm"
"and line are translated, compiled or\012  linked as needed.\012\012  General options:\012\012  "
"  -h  -help                   display this text and exit\012    -v                 "
"         show intermediate compilation stages\012    -v2  -verbose               di"
"splay information about translation progress\012    -v3                         dis"
"play information about all compilation stages\012    -V  -version                di"
"splay Scheme compiler version and exit\012    -release                    display r"
"elease number and exit\012\012  File and pathname options:\012\012    -o -output-file FILENA"
"ME    specifies target executable name\012    -I -include-path PATHNAME   specifies"
" alternative path for included files\012    -to-stdout                  write compi"
"ler to stdout (implies -t)\012    -s -shared -dynamic         generate dynamically "
"loadable shared object file\012\012  Language options:\012\012    -D  -DSYMBOL  -feature SYM"
"BOL \012                                register feature identifier\012    -c++       "
"                 Compile via a C++ source file (.cpp) \012    -objc                "
"       Compile via Objective-C source file (.m)\012\012  Syntax related options:\012\012    "
"-i -case-insensitive        don\047t preserve case of read symbols    \012    -K -keyw"
"ord-style STYLE     allow alternative keyword syntax (prefix, suffix or none)\012  "
"  -run-time-macros            macros are made available at run-time\012\012  Translati"
"on options:\012\012    -x  -explicit-use           do not use units `library\047 and `eva"
"l\047 by default\012    -P  -check-syntax           stop compilation after macro-expan"
"sion\012    -A  -analyze-only           stop compilation after first analysis pass\012"
"\012  Debugging options:\012\012    -w  -no-warnings            disable warnings\012    -dis"
"able-warning CLASS      disable specific class of warnings\012    -d0 -d1 -d2 -debu"
"g-level NUMBER\012                                set level of available debugging "
"information\012    -no-trace                   disable rudimentary debugging inform"
"ation\012    -profile                    executable emits profiling information \012  "
"  -accumulate-profile         executable emits profiling information in append m"
"ode\012    -profile-name FILENAME      name of the generated profile information fi"
"le\012    -emit-debug-info            emit additional debug-information\012    -emit-e"
"xports FILENAME      write exported toplevel variables to FILENAME\012    -G  -chec"
"k-imports          look for undefined toplevel variables\012    -import FILENAME   "
"         read externally exported symbols from FILENAME\012\012  Optimization options:"
"\012\012    -O -O1 -O2 -O3 -optimize-level NUMBER\012\011\011\011        enable certain sets of op"
"timization options\012    -optimize-leaf-routines     enable leaf routine optimizat"
"ion\012    -N  -no-usual-integrations  standard procedures may be redefined\012    -u "
" -unsafe                 disable safety checks\012    -b  -block                  e"
"nable block-compilation\012    -disable-interrupts         disable interrupts in co"
"mpiled code\012    -f  -fixnum-arithmetic      assume all numbers are fixnums\012    -"
"Ob  -benchmark-mode        equivalent to \047-block -optimize-level 3 \012            "
"                     -debug-level 0 -fixnum-arithmetic -lambda-lift \012           "
"                      -disable-interrupts\047\012    -lambda-lift                perfo"
"rm lambda-lifting\012    -unsafe-libraries           link with unsafe runtime syste"
"m\012    -disable-stack-overflow-checks  disables detection of stack-overflows\012    "
"-inline                     enable inlining\012    -inline-limit               set "
"inlining threshold\012    -disable-compiler-macros    disable expansion of compiler"
" macros\012\012  Configuration options:\012\012    -unit NAME                  compile file "
"as a library unit\012    -uses NAME                  declare library unit as used.\012"
"    -heap-size NUMBER           specifies heap-size of compiled executable\012    -"
"heap-initial-size NUMBER   specifies heap-size at startup time\012    -heap-growth "
"PERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shrinkage PERCE"
"NTAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER  -stack-siz"
"e NUMBER\012\011\011                specifies nursery size of compiled executable\012    -X "
"-extend FILENAME         load file before compilation commences\012    -prelude EXP"
"RESSION         add expression to beginning of source file\012    -postlude EXPRESS"
"ION        add expression to end of source file\012    -prologue FILENAME          "
"include file before main source file\012    -epilogue FILENAME          include fil"
"e after main source file\012\012    -e  -embedded               compile as embedded (d"
"on\047t generate `main()\047)\012    -W  -windows                compile as Windows GUI a"
"pplication (MSVC only)\012    -R  -require-extension NAME require extension in comp"
"iled code\012    -E  -extension              compile as extension (dynamic or stati"
"c)\012    -dll -library               compile multiple units into a dynamic library"
"\012\012  Options to other passes:\012\012    -C OPTION                   pass option to C c"
"ompiler\012    -L OPTION                   pass option to linker\012    -I<DIR>       "
"              pass \042-I<DIR>\042 to C compiler (add include path)\012    -L<DIR>       "
"              pass \042-L<DIR>\042 to linker (add library path)\012    -k                "
"          keep intermediate files\012    -c                          stop after com"
"pilation to object files\012    -t                          stop after translation "
"to C\012    -cc COMPILER                select other C compiler than the default on"
"e\012    -cxx COMPILER               select other C++ compiler than the default one"
"\012    -ld COMPILER                select other linker than the default one\012    -l"
"LIBNAME                   link with given library (`libLIBNAME\047 on UNIX,\012       "
"                          `LIBNAME.lib\047 on Windows)                             "
"   \012    -static-libs                link with static CHICKEN libraries\012    -stat"
"ic                     generate completely statically linked executable\012    -sta"
"tic-extensions          link with static extensions (if available)\012    -F<DIR>  "
"                   pass \042-F<DIR>\042 to C compiler (add framework \012                "
"                 header path on Mac OS X)\012    -framework NAME             passed"
" to linker on Mac OS X\012    -rpath PATHNAME             add directory to runtime "
"library search path\012    -Wl,...                     pass linker options\012    -str"
"ip                      strip resulting binary\012\012  Inquiry options:\012\012    -home   "
"                    show home-directory (where support files go)\012    -cflags    "
"                 show required C-compiler flags and exit\012    -ldflags           "
"         show required linker flags and exit\012    -libs                       sho"
"w required libraries and exit\012    -cc-name                    show name of defau"
"lt C compiler used\012    -cxx-name                   show name of default C++ comp"
"iler used\012    -ld-name                    show name of default linker used\012    -"
"dry-run                    just show commands executed, don\047t run them \012        "
"                         (implies `-v\047)\012\012  Obscure options:\012\012    -debug MODES   "
"             display debugging output for the given modes\012    -compiler PATHNAME"
"          use other compiler than default `chicken\047\012    -disable-c-syntax-checks"
"    disable syntax checks of C code fragments\012    -raw                        do"
" not generate implicit init- and exit code\011\011\011       \012    -emit-external-prototyp"
"es-first  emit protoypes for callbacks before foreign\012                          "
"       declarations\012    -keep-shadowed-macros       do not remove shadowed macro"
"\012    -host                       compile for host when configured for cross-comp"
"iling\012\012  Options can be collapsed if unambiguous, so\012\012    -vkfO\012\012  is the same a"
"s\012\012    -v -k -fixnum-arithmetic -optimize\012\012  The contents of the environment var"
"iable CSC_OPTIONS are implicitly\012  passed to every invocation of `csc\047.\012");
lf[190]=C_h_intern(&lf[190],8,"-release");
lf[191]=C_h_intern(&lf[191],15,"chicken-version");
lf[192]=C_h_intern(&lf[192],8,"-version");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[194]=C_h_intern(&lf[194],4,"-c++");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[196]=C_h_intern(&lf[196],5,"-objc");
lf[197]=C_h_intern(&lf[197],7,"-static");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[200]=C_h_intern(&lf[200],12,"-static-libs");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[203]=C_h_intern(&lf[203],18,"-static-extensions");
lf[204]=C_h_intern(&lf[204],7,"-cflags");
lf[205]=C_h_intern(&lf[205],8,"-ldflags");
lf[206]=C_h_intern(&lf[206],8,"-cc-name");
lf[207]=C_h_intern(&lf[207],9,"-cxx-name");
lf[208]=C_h_intern(&lf[208],8,"-ld-name");
lf[209]=C_h_intern(&lf[209],5,"-home");
lf[210]=C_h_intern(&lf[210],5,"-libs");
lf[211]=C_h_intern(&lf[211],2,"-v");
lf[212]=C_h_intern(&lf[212],3,"-v2");
lf[213]=C_h_intern(&lf[213],8,"-verbose");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[215]=C_h_intern(&lf[215],2,"-w");
lf[216]=C_h_intern(&lf[216],12,"-no-warnings");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[219]=C_h_intern(&lf[219],3,"-v3");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\010-VERBOSE");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[225]=C_h_intern(&lf[225],2,"-A");
lf[226]=C_h_intern(&lf[226],13,"-analyze-only");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[228]=C_h_intern(&lf[228],2,"-P");
lf[229]=C_h_intern(&lf[229],13,"-check-syntax");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[231]=C_h_intern(&lf[231],2,"-k");
lf[232]=C_h_intern(&lf[232],2,"-c");
lf[233]=C_h_intern(&lf[233],2,"-t");
lf[234]=C_h_intern(&lf[234],2,"-e");
lf[235]=C_h_intern(&lf[235],9,"-embedded");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[237]=C_h_intern(&lf[237],18,"-require-extension");
lf[238]=C_h_intern(&lf[238],2,"-R");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[240]=C_h_intern(&lf[240],8,"-windows");
lf[241]=C_h_intern(&lf[241],2,"-W");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\010-luser32");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\014kernel32.lib");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\012user32.lib");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\011gdi32.lib");
lf[251]=C_h_intern(&lf[251],10,"-framework");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[253]=C_h_intern(&lf[253],2,"-o");
lf[254]=C_h_intern(&lf[254],2,"-O");
lf[255]=C_h_intern(&lf[255],3,"-O1");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[258]=C_h_intern(&lf[258],3,"-O2");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[261]=C_h_intern(&lf[261],3,"-O3");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[264]=C_h_intern(&lf[264],3,"-d0");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[267]=C_h_intern(&lf[267],3,"-d1");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[270]=C_h_intern(&lf[270],3,"-d2");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[273]=C_h_intern(&lf[273],8,"-dry-run");
lf[274]=C_h_intern(&lf[274],2,"-s");
lf[275]=C_h_intern(&lf[275],4,"-dll");
lf[276]=C_h_intern(&lf[276],8,"-library");
lf[277]=C_h_intern(&lf[277],9,"-compiler");
lf[278]=C_h_intern(&lf[278],3,"-cc");
lf[279]=C_h_intern(&lf[279],4,"-cxx");
lf[280]=C_h_intern(&lf[280],3,"-ld");
lf[281]=C_h_intern(&lf[281],2,"-I");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[283]=C_h_intern(&lf[283],2,"-C");
lf[284]=C_h_intern(&lf[284],12,"string-split");
lf[285]=C_h_intern(&lf[285],6,"-strip");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[287]=C_h_intern(&lf[287],2,"-L");
lf[288]=C_h_intern(&lf[288],17,"-unsafe-libraries");
lf[289]=C_h_intern(&lf[289],6,"-rpath");
lf[290]=C_h_intern(&lf[290],3,"gnu");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[292]=C_h_intern(&lf[292],14,"build-platform");
lf[293]=C_h_intern(&lf[293],5,"-host");
lf[294]=C_h_intern(&lf[294],1,"-");
lf[295]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[297]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-E\376\003\000\000\002\376B\000\000\012-extension\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\002-V\376\003\000\000\002\376B\000\000\010-version\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003-Ob\376\003\000\000\002\376B\000\000\017-benchmark-mode\376\377\016\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-featu"
"re\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016-"
"keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B\000\000\007-extend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-N\376\003\000\000\002\376B\000\000\026"
"-no-usual-integrations\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-G\376\003\000\000\002\376B\000\000\016-check-imports\376\377\016\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\002-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-u\376\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\002-b\376\003\000\000\002\376B\000\000\006-block\376\377\016\376\377\016");
lf[298]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\017-benchmark-mode\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000"
"\000\020-run-time-macros\376\003\000\000\002\376\001\000\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\014-lambda-lift\376\003\000\000\002\376\001\000\000\010-dyna"
"mic\376\003\000\000\002\376\001\000\000\036-disable-stack-overflow-checks\376\003\000\000\002\376\001\000\000\020-emit-debug-info\376\003\000\000\002\376\001\000\000\016-"
"check-imports\376\003\000\000\002\376\001\000\000\037-emit-external-prototypes-first\376\003\000\000\002\376\001\000\000\007-inline\376\003\000\000\002\376\001\000\000"
"\012-extension\376\003\000\000\002\376\001\000\000\010-release\376\003\000\000\002\376\001\000\000\022-static-extensions\376\003\000\000\002\376\001\000\000\015-analyze-only"
"\376\003\000\000\002\376\001\000\000\025-keep-shadowed-macros\376\003\000\000\002\376\001\000\000\030-disable-compiler-macros\376\377\016");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\014-output-file\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000"
"\002\376\001\000\000\013-stack-size\376\003\000\000\002\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-key"
"word-style\376\003\000\000\002\376\001\000\000\017-optimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-si"
"ze\376\003\000\000\002\376\001\000\000\007-extend\376\003\000\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002"
"\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\020-disable-w"
"arning\376\003\000\000\002\376\001\000\000\007-import\376\003\000\000\002\376\001\000\000\031-require-static-extension\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000"
"\002\376\001\000\000\014-debug-level\376\003\000\000\002\376\001\000\000\014-heap-growth\376\003\000\000\002\376\001\000\000\017-heap-shrinkage\376\003\000\000\002\376\001\000\000\022-heap"
"-initial-size\376\003\000\000\002\376\001\000\000\015-emit-exports\376\003\000\000\002\376\001\000\000\022-compress-literals\376\377\016");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[301]=C_h_intern(&lf[301],9,"substring");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[304]=C_h_intern(&lf[304],15,"lset-difference");
lf[305]=C_h_intern(&lf[305],6,"char=\077");
lf[306]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\003\000\000\002\376\377\012\000"
"\000G\376\377\016");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[309]=C_h_intern(&lf[309],18,"decompose-pathname");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[324]=C_h_intern(&lf[324],15,"-optimize-level");
lf[325]=C_h_intern(&lf[325],15,"-benchmark-mode");
lf[326]=C_h_intern(&lf[326],10,"-to-stdout");
lf[327]=C_h_intern(&lf[327],7,"-unsafe");
lf[328]=C_h_intern(&lf[328],7,"-shared");
lf[329]=C_h_intern(&lf[329],8,"-dynamic");
lf[330]=C_h_intern(&lf[330],14,"string->symbol");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[332]=C_h_intern(&lf[332],6,"getenv");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\011-LIBPATH:");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\007 -Wl,-R");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[346]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-luchicken\376\377\016");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[350]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\011-lchicken\376\377\016");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\023libuchicken-static.");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\022libchicken-static.");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[363]=C_h_intern(&lf[363],22,"command-line-arguments");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[365]=C_h_intern(&lf[365],4,"hpux");
lf[366]=C_h_intern(&lf[366],4,"hppa");
lf[367]=C_h_intern(&lf[367],12,"machine-type");
lf[368]=C_h_intern(&lf[368],16,"software-version");
C_register_lf2(lf,369,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k387 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k390 in k387 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_395,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k393 in k390 in k387 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k396 in k393 in k390 in k387 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_410,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 106  build-platform */
t3=C_retrieve(lf[292]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3326,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[2]);
t3=C_mutate(&lf[3],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 107  build-platform */
t5=C_retrieve(lf[292]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3322,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[4]);
t3=C_mutate(&lf[5],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 108  software-version */
t5=C_retrieve(lf[368]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3318,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[6]);
t3=C_mutate(&lf[7],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_435,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3314,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 109  software-version */
t6=C_retrieve(lf[368]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3312 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[365]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 110  machine-type */
t4=C_retrieve(lf[367]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_435(t3,C_SCHEME_FALSE);}}

/* k3308 in k3312 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_435(t2,(C_word)C_eqp(t1,lf[366]));}

/* k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_435,NULL,2,t0,t1);}
t2=C_mutate(&lf[8],t1);
t3=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_437,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_452,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 116  getenv */
t5=C_retrieve(lf[332]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[364]);}

/* k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_452,2,t0,t1);}
t2=C_mutate(&lf[14],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_456,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 117  command-line-arguments */
t4=C_retrieve(lf[363]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_456,2,t0,t1);}
t2=C_mutate(&lf[15],t1);
t3=(C_word)C_i_member(lf[16],C_retrieve2(lf[15],"arguments"));
t4=C_mutate(&lf[17],t3);
t5=(C_word)C_fudge(C_fix(39));
t6=C_mutate(&lf[18],t5);
t7=C_mutate(&lf[19],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_466,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_479,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3290,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3294,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t12=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t12=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k3292 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 133  prefix */
f_466(((C_word*)t0)[2],lf[361],lf[362],t1);}

/* k3288 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 132  quotewrap */
f_479(((C_word*)t0)[2],t1);}

/* k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_493,2,t0,t1);}
t2=C_mutate(&lf[27],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_497,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3272,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3276,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_BIN_HOME),C_fix(0));}}

/* k3274 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3280,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k3278 in k3274 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 138  make-pathname */
t2=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3270 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 137  prefix */
f_466(((C_word*)t0)[2],lf[359],lf[360],t1);}

/* k3266 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 136  quotewrap */
f_479(((C_word*)t0)[2],t1);}

/* k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_497,2,t0,t1);}
t2=C_mutate(&lf[28],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_501,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3258,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k3256 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 142  quotewrap */
f_479(((C_word*)t0)[2],t1);}

/* k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_501,2,t0,t1);}
t2=C_mutate(&lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_505,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3248,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k3246 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 143  quotewrap */
f_479(((C_word*)t0)[2],t1);}

/* k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_505,2,t0,t1);}
t2=C_mutate(&lf[30],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3235,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3235(2,t5,lf[358]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}}

/* k3233 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 144  quotewrap */
f_479(((C_word*)t0)[2],t1);}

/* k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_509,2,t0,t1);}
t2=C_mutate(&lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_513,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3222,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3222(2,t5,lf[357]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}}

/* k3220 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 145  quotewrap */
f_479(((C_word*)t0)[2],t1);}

/* k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_513,2,t0,t1);}
t2=C_mutate(&lf[32],t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[33]:lf[34]);
t4=C_mutate(&lf[35],t3);
t5=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[36]:lf[37]);
t6=C_mutate(&lf[38],t5);
t7=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[39]:lf[40]);
t8=C_mutate(&lf[41],t7);
t9=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[42]:lf[43]);
t10=C_mutate(&lf[44],t9);
t11=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[45]:lf[46]);
t12=C_mutate(&lf[47],t11);
t13=C_mutate(&lf[48],C_retrieve(lf[49]));
t14=(C_truep(lf[3])?lf[3]:C_retrieve2(lf[5],"msvc"));
t15=(C_truep(t14)?lf[50]:lf[51]);
t16=C_mutate(&lf[52],t15);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_544,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t18=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[355]:lf[356]);
/* csc.scm: 156  string-append */
t19=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t19))(4,t19,t17,t18,C_retrieve2(lf[38],"library-extension"));}

/* k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_544,2,t0,t1);}
t2=C_mutate(&lf[53],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_548,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[353]:lf[354]);
/* csc.scm: 159  string-append */
t5=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[38],"library-extension"));}

/* k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_548,2,t0,t1);}
t2=C_mutate(&lf[54],t1);
t3=(C_truep(lf[3])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3206,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3201,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[55],t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_556,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3191,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k3189 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 168  string-split */
t2=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_556,2,t0,t1);}
t2=C_mutate(&lf[56],t1);
t3=C_mutate(&lf[57],C_retrieve2(lf[56],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_561,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3181,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* k3179 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 170  string-split */
t2=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_561,2,t0,t1);}
t2=C_mutate(&lf[58],t1);
t3=C_mutate(&lf[59],C_retrieve2(lf[58],"default-linking-optimization-options"));
t4=lf[60]=C_SCHEME_END_OF_LIST;;
t5=lf[61]=C_SCHEME_END_OF_LIST;;
t6=lf[62]=C_SCHEME_END_OF_LIST;;
t7=lf[63]=C_SCHEME_END_OF_LIST;;
t8=lf[64]=C_SCHEME_END_OF_LIST;;
t9=lf[65]=C_SCHEME_FALSE;;
t10=lf[66]=C_SCHEME_FALSE;;
t11=lf[67]=C_SCHEME_FALSE;;
t12=lf[68]=C_SCHEME_FALSE;;
t13=lf[69]=C_SCHEME_FALSE;;
t14=lf[70]=C_SCHEME_FALSE;;
t15=lf[71]=C_SCHEME_FALSE;;
t16=lf[72]=C_SCHEME_FALSE;;
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_587,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t18=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t18=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_587,2,t0,t1);}
t2=C_mutate(&lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_591,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_591,2,t0,t1);}
t2=C_mutate(&lf[74],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3143,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3147,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3151,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3155,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3153 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3159,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 241  string-append */
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[352],C_retrieve2(lf[53],"default-library"));}

/* k3157 in k3153 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 239  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3149 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 238  prefix */
f_466(((C_word*)t0)[2],C_retrieve2(lf[53],"default-library"),lf[351],t1);}

/* k3145 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 237  quotewrap */
f_479(((C_word*)t0)[2],t1);}

/* k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3143,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[75],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_599,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3139,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 243  string-append */
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[349],C_retrieve2(lf[38],"library-extension"));}
else{
t5=t4;
f_599(t5,lf[350]);}}

/* k3137 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3139,2,t0,t1);}
t2=((C_word*)t0)[2];
f_599(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_599(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_599,NULL,2,t0,t1);}
t2=C_mutate(&lf[76],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3110,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3114,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3118,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3122,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3120 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3126,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 251  string-append */
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[348],C_retrieve2(lf[54],"default-unsafe-library"));}

/* k3124 in k3120 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 249  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3116 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 248  prefix */
f_466(((C_word*)t0)[2],C_retrieve2(lf[54],"default-unsafe-library"),lf[347],t1);}

/* k3112 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 247  quotewrap */
f_479(((C_word*)t0)[2],t1);}

/* k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3110,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[77],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_607,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3106,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 253  string-append */
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[345],C_retrieve2(lf[38],"library-extension"));}
else{
t5=t4;
f_607(t5,lf[346]);}}

/* k3104 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
t2=((C_word*)t0)[2];
f_607(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_607,NULL,2,t0,t1);}
t2=C_mutate(&lf[78],t1);
t3=C_mutate(&lf[79],C_retrieve2(lf[75],"default-library-files"));
t4=C_mutate(&lf[80],C_retrieve2(lf[76],"default-shared-library-files"));
t5=C_mutate(&lf[81],C_retrieve2(lf[75],"default-library-files"));
t6=C_mutate(&lf[82],C_retrieve2(lf[76],"default-shared-library-files"));
t7=C_mutate(&lf[83],lf[84]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_616,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3093,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t10=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t10=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* k3091 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 263  prefix */
f_466(((C_word*)t0)[2],lf[343],lf[344],t1);}

/* k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_616,2,t0,t1);}
t2=(C_word)C_i_member(t1,lf[85]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate(&lf[86],t3);
t5=lf[87]=C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_624,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[86],"include-dir"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3078,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 270  quotewrap */
f_479(t8,C_retrieve2(lf[86],"include-dir"));}
else{
t7=t6;
f_624(t7,C_SCHEME_END_OF_LIST);}}

/* k3080 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 270  conc */
t2=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[342],t1);}

/* k3076 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3078,2,t0,t1);}
t2=((C_word*)t0)[2];
f_624(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_624,NULL,2,t0,t1);}
t2=C_mutate(&lf[88],t1);
t3=C_mutate(&lf[89],C_retrieve2(lf[56],"default-compilation-optimization-options"));
t4=C_mutate(&lf[90],C_retrieve2(lf[58],"default-linking-optimization-options"));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3065,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3063 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 278  prefix */
f_466(((C_word*)t0)[2],lf[340],lf[341],t1);}

/* k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_632,2,t0,t1);}
t2=C_mutate(&lf[91],t1);
t3=lf[92]=C_SCHEME_END_OF_LIST;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[7],"osx"):(C_truep(C_retrieve2(lf[8],"hpux-hppa"))?C_retrieve2(lf[8],"hpux-hppa"):lf[3]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3007,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3011,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 286  quotewrap */
f_479(t7,C_retrieve2(lf[91],"library-dir"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3021,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 288  quotewrap */
f_479(t7,C_retrieve2(lf[91],"library-dir"));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3032,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3058,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 291  quotewrap */
f_479(t7,C_retrieve2(lf[91],"library-dir"));}}}

/* k3056 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 291  conc */
t2=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[339],t1);}

/* k3030 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3036,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3040,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3044,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3048,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}

/* k3046 in k3030 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 292  prefix */
f_466(((C_word*)t0)[2],lf[337],lf[338],t1);}

/* k3042 in k3030 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 292  quotewrap */
f_479(((C_word*)t0)[2],t1);}

/* k3038 in k3030 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 292  conc */
t2=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[336],t1);}

/* k3034 in k3030 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3036,2,t0,t1);}
t2=((C_word*)t0)[3];
f_637(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k3023 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 288  conc */
t2=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[335],t1);}

/* k3019 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3021,2,t0,t1);}
t2=((C_word*)t0)[2];
f_637(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3009 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 286  conc */
t2=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[334],t1);}

/* k3005 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3007,2,t0,t1);}
t2=((C_word*)t0)[2];
f_637(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_637(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_637,NULL,2,t0,t1);}
t2=C_mutate(&lf[93],t1);
t3=lf[94]=C_SCHEME_FALSE;;
t4=lf[95]=C_SCHEME_FALSE;;
t5=lf[96]=C_SCHEME_FALSE;;
t6=lf[97]=C_SCHEME_FALSE;;
t7=lf[98]=C_SCHEME_FALSE;;
t8=lf[99]=C_SCHEME_FALSE;;
t9=lf[100]=C_SCHEME_FALSE;;
t10=lf[101]=C_SCHEME_FALSE;;
t11=lf[102]=C_SCHEME_FALSE;;
t12=lf[103]=C_SCHEME_FALSE;;
t13=lf[104]=C_SCHEME_END_OF_LIST;;
t14=lf[105]=C_SCHEME_FALSE;;
t15=C_mutate(&lf[106],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2449,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[111],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2601,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[117],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2698,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[120],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2750,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[122],lf[123]);
t20=C_mutate(&lf[109],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2899,tmp=(C_word)a,a+=2,tmp));
t21=lf[132]=C_SCHEME_FALSE;;
t22=C_mutate(&lf[133],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2928,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[138],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2960,tmp=(C_word)a,a+=2,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2986,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2990,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2994,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 953  getenv */
t28=C_retrieve(lf[332]);
((C_proc3)C_retrieve_proc(t28))(3,t28,t27,lf[333]);}

/* k2992 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[331]);
/* csc.scm: 953  string-split */
t3=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2988 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 953  append */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[15],"arguments"));}

/* k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_660,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_667,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_706,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_735,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_735(t8,((C_word*)t0)[2],t1);}

/* loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_735,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_746,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 498  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[87],"compile-options"),C_retrieve2(lf[88],"builtin-compile-options"));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_917,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* csc.scm: 540  string->symbol */
t8=*((C_word*)lf[330]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word ab[117],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_920,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[186]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[187]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_932,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 314  display */
t6=*((C_word*)lf[188]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[189]);}
else{
t5=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_944,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_951,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 546  chicken-version */
t8=C_retrieve(lf[191]);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t6=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_960,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_967,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 549  sprintf */
t9=C_retrieve(lf[157]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,C_retrieve2(lf[28],"translator"),lf[193]);}
else{
t7=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t7)){
t8=lf[65]=C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[195],C_retrieve2(lf[87],"compile-options"));
t10=C_mutate(&lf[87],t9);
t11=t2;
f_920(2,t11,t10);}
else{
t9=t2;
f_920(2,t9,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t1,lf[196]);
if(C_truep(t8)){
t9=lf[66]=C_SCHEME_TRUE;;
t10=t2;
f_920(2,t10,t9);}
else{
t9=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_998,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 557  cons* */
t11=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,lf[198],lf[199],C_retrieve2(lf[83],"translate-options"));}
else{
t10=(C_word)C_eqp(t1,lf[200]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1009,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 560  cons* */
t12=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[201],lf[202],C_retrieve2(lf[83],"translate-options"));}
else{
t11=(C_word)C_eqp(t1,lf[203]);
if(C_truep(t11)){
t12=lf[103]=C_SCHEME_TRUE;;
t13=t2;
f_920(2,t13,t12);}
else{
t12=(C_word)C_eqp(t1,lf[204]);
if(C_truep(t12)){
t13=lf[68]=C_SCHEME_TRUE;;
t14=lf[69]=C_SCHEME_TRUE;;
t15=t2;
f_920(2,t15,t14);}
else{
t13=(C_word)C_eqp(t1,lf[205]);
if(C_truep(t13)){
t14=lf[68]=C_SCHEME_TRUE;;
t15=lf[70]=C_SCHEME_TRUE;;
t16=t2;
f_920(2,t16,t15);}
else{
t14=(C_word)C_eqp(t1,lf[206]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1042,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 570  print */
t16=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,C_retrieve2(lf[29],"compiler"));}
else{
t15=(C_word)C_eqp(t1,lf[207]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1054,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 571  print */
t17=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,C_retrieve2(lf[30],"c++-compiler"));}
else{
t16=(C_word)C_eqp(t1,lf[208]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1066,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 572  print */
t18=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,C_retrieve2(lf[31],"linker"));}
else{
t17=(C_word)C_eqp(t1,lf[209]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1078,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 573  print */
t19=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,C_retrieve2(lf[27],"home"));}
else{
t18=(C_word)C_eqp(t1,lf[210]);
if(C_truep(t18)){
t19=lf[68]=C_SCHEME_TRUE;;
t20=lf[71]=C_SCHEME_TRUE;;
t21=t2;
f_920(2,t21,t20);}
else{
t19=(C_word)C_eqp(t1,lf[211]);
if(C_truep(t19)){
t20=lf[95]=C_SCHEME_TRUE;;
t21=t2;
f_920(2,t21,t20);}
else{
t20=(C_word)C_eqp(t1,lf[212]);
t21=(C_truep(t20)?t20:(C_word)C_eqp(t1,lf[213]));
if(C_truep(t21)){
t22=lf[95]=C_SCHEME_TRUE;;
/* csc.scm: 581  t-options */
f_660(t2,(C_word)C_a_i_list(&a,1,lf[214]));}
else{
t22=(C_word)C_eqp(t1,lf[215]);
t23=(C_truep(t22)?t22:(C_word)C_eqp(t1,lf[216]));
if(C_truep(t23)){
t24=(C_word)C_a_i_cons(&a,2,lf[217],C_retrieve2(lf[87],"compile-options"));
t25=C_mutate(&lf[87],t24);
/* csc.scm: 584  t-options */
f_660(t2,(C_word)C_a_i_list(&a,1,lf[218]));}
else{
t24=(C_word)C_eqp(t1,lf[219]);
if(C_truep(t24)){
t25=lf[95]=C_SCHEME_TRUE;;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1135,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 587  t-options */
f_660(t26,(C_word)C_a_i_list(&a,1,lf[224]));}
else{
t25=(C_word)C_eqp(t1,lf[225]);
t26=(C_truep(t25)?t25:(C_word)C_eqp(t1,lf[226]));
if(C_truep(t26)){
t27=lf[97]=C_SCHEME_TRUE;;
/* csc.scm: 593  t-options */
f_660(t2,(C_word)C_a_i_list(&a,1,lf[227]));}
else{
t27=(C_word)C_eqp(t1,lf[228]);
t28=(C_truep(t27)?t27:(C_word)C_eqp(t1,lf[229]));
if(C_truep(t28)){
t29=lf[97]=C_SCHEME_TRUE;;
/* csc.scm: 596  t-options */
f_660(t2,(C_word)C_a_i_list(&a,1,lf[230]));}
else{
t29=(C_word)C_eqp(t1,lf[231]);
if(C_truep(t29)){
t30=lf[96]=C_SCHEME_TRUE;;
t31=t2;
f_920(2,t31,t30);}
else{
t30=(C_word)C_eqp(t1,lf[232]);
if(C_truep(t30)){
t31=lf[98]=C_SCHEME_TRUE;;
t32=t2;
f_920(2,t32,t31);}
else{
t31=(C_word)C_eqp(t1,lf[233]);
if(C_truep(t31)){
t32=lf[97]=C_SCHEME_TRUE;;
t33=t2;
f_920(2,t33,t32);}
else{
t32=(C_word)C_eqp(t1,lf[234]);
t33=(C_truep(t32)?t32:(C_word)C_eqp(t1,lf[235]));
if(C_truep(t33)){
t34=lf[67]=C_SCHEME_TRUE;;
t35=(C_word)C_a_i_cons(&a,2,lf[236],C_retrieve2(lf[87],"compile-options"));
t36=C_mutate(&lf[87],t35);
t37=t2;
f_920(2,t37,t36);}
else{
t34=(C_word)C_eqp(t1,lf[237]);
t35=(C_truep(t34)?t34:(C_word)C_eqp(t1,lf[238]));
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1226,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 604  check */
f_667(t36,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t36=(C_word)C_eqp(t1,lf[240]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t1,lf[241]));
if(C_truep(t37)){
t38=lf[105]=C_SCHEME_TRUE;;
if(C_truep(lf[3])){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1266,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 613  cons* */
t40=C_retrieve(lf[129]);
((C_proc7)C_retrieve_proc(t40))(7,t40,t39,lf[243],lf[244],lf[245],lf[246],C_retrieve2(lf[92],"link-options"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1277,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 618  cons* */
t40=C_retrieve(lf[129]);
((C_proc6)C_retrieve_proc(t40))(6,t40,t39,lf[248],lf[249],lf[250],C_retrieve2(lf[92],"link-options"));}
else{
t39=t2;
f_920(2,t39,C_SCHEME_UNDEFINED);}}}
else{
t38=(C_word)C_eqp(t1,lf[251]);
if(C_truep(t38)){
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1290,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 621  check */
f_667(t39,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t39=(C_word)C_eqp(t1,lf[253]);
if(C_truep(t39)){
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1314,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 626  check */
f_667(t40,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t40=(C_word)C_eqp(t1,lf[254]);
t41=(C_truep(t40)?t40:(C_word)C_eqp(t1,lf[255]));
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1335,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 630  cons* */
t43=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t43))(5,t43,t42,lf[256],lf[257],((C_word*)((C_word*)t0)[6])[1]);}
else{
t42=(C_word)C_eqp(t1,lf[258]);
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1345,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 631  cons* */
t44=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t44))(5,t44,t43,lf[259],lf[260],((C_word*)((C_word*)t0)[6])[1]);}
else{
t43=(C_word)C_eqp(t1,lf[261]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1355,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 632  cons* */
t45=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t45))(5,t45,t44,lf[262],lf[263],((C_word*)((C_word*)t0)[6])[1]);}
else{
t44=(C_word)C_eqp(t1,lf[264]);
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1365,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 633  cons* */
t46=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t45,lf[265],lf[266],((C_word*)((C_word*)t0)[6])[1]);}
else{
t45=(C_word)C_eqp(t1,lf[267]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1375,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 634  cons* */
t47=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t47))(5,t47,t46,lf[268],lf[269],((C_word*)((C_word*)t0)[6])[1]);}
else{
t46=(C_word)C_eqp(t1,lf[270]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1385,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 635  cons* */
t48=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t48))(5,t48,t47,lf[271],lf[272],((C_word*)((C_word*)t0)[6])[1]);}
else{
t47=(C_word)C_eqp(t1,lf[273]);
if(C_truep(t47)){
t48=lf[95]=C_SCHEME_TRUE;;
t49=lf[72]=C_SCHEME_TRUE;;
t50=t2;
f_920(2,t50,t49);}
else{
t48=(C_word)C_eqp(t1,lf[274]);
t49=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t48)){
t50=t49;
f_1402(t50,t48);}
else{
t50=(C_word)C_eqp(t1,lf[328]);
t51=t49;
f_1402(t51,(C_truep(t50)?t50:(C_word)C_eqp(t1,lf[329])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_1402(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[55],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1402,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 640  shared-build */
f_706(((C_word*)t0)[7],C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[275]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[6],lf[276]));
if(C_truep(t3)){
/* csc.scm: 642  shared-build */
f_706(((C_word*)t0)[7],C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[277]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1426,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 644  check */
f_667(t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[278]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 648  check */
f_667(t6,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[279]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 652  check */
f_667(t7,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[280]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 656  check */
f_667(t8,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[281]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1494,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 660  check */
f_667(t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[283]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 663  check */
f_667(t10,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[285]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1541,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,lf[286]);
/* csc.scm: 667  append */
t13=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[92],"link-options"),t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[287]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1554,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 669  check */
f_667(t12,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[288]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 673  t-options */
f_660(t13,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[289]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 677  check */
f_667(t14,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[293]);
if(C_truep(t14)){
t15=((C_word*)t0)[7];
f_920(2,t15,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[6],lf[294]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 683  make-pathname */
t17=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,C_SCHEME_FALSE,lf[296],C_retrieve2(lf[44],"executable-extension"));}
else{
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1643,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t17=((C_word*)t0)[6];
if(C_truep((C_truep((C_word)C_eqp(t17,lf[327]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t17,lf[325]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t18=(C_word)C_eqp(((C_word*)t0)[6],lf[325]);
if(C_truep(t18)){
t19=C_mutate(&lf[81],C_retrieve2(lf[77],"unsafe-library-files"));
t20=C_mutate(&lf[82],C_retrieve2(lf[78],"unsafe-shared-library-files"));
t21=t16;
f_1643(t21,t20);}
else{
t19=t16;
f_1643(t19,C_SCHEME_UNDEFINED);}}
else{
t18=t16;
f_1643(t18,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}}

/* k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_1643(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1643,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[326]);
if(C_truep(t3)){
t4=lf[99]=C_SCHEME_TRUE;;
t5=lf[97]=C_SCHEME_TRUE;;
t6=t2;
f_1646(t6,t5);}
else{
t4=t2;
f_1646(t4,C_SCHEME_UNDEFINED);}}

/* k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_1646(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1646,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[324]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[325]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_mutate(&lf[89],C_retrieve2(lf[57],"best-compilation-optimization-options"));
t5=C_mutate(&lf[90],C_retrieve2(lf[59],"best-linking-optimization-options"));
t6=t2;
f_1649(t6,t5);}
else{
t4=t2;
f_1649(t4,C_SCHEME_UNDEFINED);}}

/* k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_1649(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1649,NULL,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[7],lf[297]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=((C_word*)t0)[5];
f_920(2,t6,t5);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[298]))){
/* csc.scm: 697  t-options */
f_660(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[299]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 699  check */
f_667(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1700,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2031,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 704  substring */
t6=*((C_word*)lf[301]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],C_fix(0),C_fix(2));}
else{
t5=t3;
f_1700(t5,C_SCHEME_FALSE);}}}}}

/* k2029 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1700(t2,(C_word)C_i_string_equal_p(lf[323],t1));}

/* k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_1700(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1700,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 705  t-options */
f_660(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t3,C_fix(1)))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],C_fix(0));
t5=t2;
f_1709(t5,(C_word)C_eqp(C_make_character(45),t4));}
else{
t4=t2;
f_1709(t4,C_SCHEME_FALSE);}}}

/* k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_1709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1709,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_eqp(C_make_character(108),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1719,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 709  append */
t6=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve2(lf[92],"link-options"),t5);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(C_make_character(76),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1733,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 711  append */
t8=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[92],"link-options"),t7);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t7=(C_word)C_eqp(C_make_character(73),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1747,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 713  append */
t10=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,C_retrieve2(lf[87],"compile-options"),t9);}
else{
t8=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t9=(C_word)C_eqp(C_make_character(68),t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 715  substring */
t11=*((C_word*)lf[301]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,((C_word*)t0)[6],C_fix(2));}
else{
t10=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t11=(C_word)C_eqp(C_make_character(70),t10);
if(C_truep(t11)){
if(C_truep(C_retrieve2(lf[7],"osx"))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1777,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 718  append */
t14=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t12,C_retrieve2(lf[87],"compile-options"),t13);}
else{
t12=((C_word*)t0)[5];
f_920(2,t12,C_SCHEME_UNDEFINED);}}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t13,C_fix(3)))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1856,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 719  substring */
t15=*((C_word*)lf[301]+1);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[6],C_fix(0),C_fix(4));}
else{
t14=t12;
f_1787(t14,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 728  file-exists? */
t3=C_retrieve(lf[172]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k1884 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 729  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1994,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 745  string-append */
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],lf[322]);}}

/* k1992 in k1884 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 746  file-exists? */
t3=C_retrieve(lf[172]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1998 in k1992 in k1884 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_920(2,t4,t3);}
else{
/* csc.scm: 748  quit */
f_437(((C_word*)t0)[3],lf[321],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a1896 in k1884 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[37],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1897,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(t5)){
t6=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t6,lf[310]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t6,lf[311]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1922,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 732  append */
t9=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve2(lf[61],"c-files"),t8);}
else{
t7=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t7,lf[312]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[313]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[314]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[315]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[316]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1935,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[317],C_retrieve2(lf[87],"compile-options"));
t10=C_mutate(&lf[87],t9);
t11=t8;
f_1935(t11,t10);}
else{
t9=t8;
f_1935(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t8,lf[318]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[319]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[320]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t9=lf[66]=C_SCHEME_TRUE;;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1959,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 739  append */
t12=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,C_retrieve2(lf[61],"c-files"),t11);}
else{
t9=(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[35],"object-extension"));
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[38],"library-extension")));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1976,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 742  append */
t13=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[63],"object-files"),t12);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1984,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 743  append */
t13=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[60],"scheme-files"),t12);}}}}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 730  append */
t8=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[60],"scheme-files"),t7);}}

/* k1906 in a1896 in k1884 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1982 in a1896 in k1884 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1974 in a1896 in k1884 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[63],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1957 in a1896 in k1884 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1933 in a1896 in k1884 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_1935(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1935,NULL,2,t0,t1);}
t2=lf[65]=C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 736  append */
t5=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,C_retrieve2(lf[61],"c-files"),t4);}

/* k1938 in k1933 in a1896 in k1884 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1920 in a1896 in k1884 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1890 in k1884 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
/* csc.scm: 729  decompose-pathname */
t2=C_retrieve(lf[309]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1854 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1787(t2,(C_word)C_i_string_equal_p(lf[308],t1));}

/* k1785 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_1787(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1787,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* csc.scm: 720  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve2(lf[92],"link-options"),t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->list */
t4=C_retrieve(lf[130]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
/* csc.scm: 727  quit */
f_437(((C_word*)t0)[5],lf[307],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}}

/* k1837 in k1785 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 723  lset-difference */
t4=C_retrieve(lf[304]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[305]+1),t2,lf[306]);}

/* k1833 in k1837 in k1785 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1835,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1820,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}
else{
/* csc.scm: 726  quit */
f_437(((C_word*)t0)[4],lf[303],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a1819 in k1833 in k1837 in k1785 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1820,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* csc.scm: 725  string-append */
t4=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,lf[302],t3);}

/* k1816 in k1833 in k1837 in k1785 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 725  append */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k1812 in k1833 in k1837 in k1785 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1789 in k1785 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1775 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87],t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1762 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
/* csc.scm: 715  t-options */
f_660(((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,lf[300],t1));}

/* k1745 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87],t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1731 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1717 in k1707 in k1698 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1679 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1681,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1687,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 701  string->number */
C_string_to_number(3,0,t3,t2);}

/* k1685 in k1679 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 702  t-options */
f_660(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1688 in k1685 in k1679 in k1647 in k1644 in k1641 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_920(2,t4,t3);}

/* k1634 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1636,2,t0,t1);}
t2=C_mutate(&lf[94],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 684  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[60],"scheme-files"),lf[295]);}

/* k1638 in k1634 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60],t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1588 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 678  build-platform */
t3=C_retrieve(lf[292]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1618 in k1588 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1620,2,t0,t1);}
t2=(C_word)C_eqp(lf[290],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1612,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 679  string-append */
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[291],t5);}
else{
t3=((C_word*)t0)[2];
f_920(2,t3,C_SCHEME_UNDEFINED);}}

/* k1610 in k1618 in k1588 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1612,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* csc.scm: 679  append */
t3=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[92],"link-options"),t2);}

/* k1598 in k1618 in k1588 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_920(2,t5,t4);}

/* k1577 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[81],C_retrieve2(lf[77],"unsafe-library-files"));
t3=C_mutate(&lf[82],C_retrieve2(lf[78],"unsafe-shared-library-files"));
t4=((C_word*)t0)[2];
f_920(2,t4,t3);}

/* k1552 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1566,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 670  string-split */
t5=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1564 in k1552 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 670  append */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[92],"link-options"),t1);}

/* k1556 in k1552 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_920(2,t5,t4);}

/* k1539 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1513 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1527,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 664  string-split */
t5=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1525 in k1513 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 664  append */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[87],"compile-options"),t1);}

/* k1517 in k1513 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[87],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_920(2,t5,t4);}

/* k1492 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 661  cons* */
t5=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[282],t3,t4);}

/* k1496 in k1492 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1475 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[31],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_920(2,t6,t5);}

/* k1458 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[30],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_920(2,t6,t5);}

/* k1441 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[29],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_920(2,t6,t5);}

/* k1424 in k1400 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[28],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_920(2,t6,t5);}

/* k1383 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1373 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1363 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1353 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1343 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1333 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_920(2,t3,t2);}

/* k1312 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_mutate(&lf[94],t2);
t6=((C_word*)t0)[2];
f_920(2,t6,t5);}

/* k1288 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1301,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 623  cons* */
t5=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,lf[252],t4,C_retrieve2(lf[92],"link-options"));}
else{
t3=t2;
f_1293(t3,C_SCHEME_UNDEFINED);}}

/* k1299 in k1288 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_1293(t3,t2);}

/* k1291 in k1288 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_1293(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_920(2,t4,t3);}

/* k1275 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1277,2,t0,t1);}
t2=C_mutate(&lf[92],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[247],C_retrieve2(lf[87],"compile-options"));
t4=C_mutate(&lf[87],t3);
t5=((C_word*)t0)[2];
f_920(2,t5,t4);}

/* k1264 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1266,2,t0,t1);}
t2=C_mutate(&lf[92],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[242],C_retrieve2(lf[87],"compile-options"));
t4=C_mutate(&lf[87],t3);
t5=((C_word*)t0)[2];
f_920(2,t5,t4);}

/* k1224 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* csc.scm: 605  append */
t5=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_retrieve2(lf[104],"required-extensions"),t4);}

/* k1228 in k1224 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1230,2,t0,t1);}
t2=C_mutate(&lf[104],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 606  t-options */
f_660(t3,(C_word)C_a_i_list(&a,2,lf[239],t4));}

/* k1231 in k1228 in k1224 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_920(2,t4,t3);}

/* k1133 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1138,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t3=t2;
f_1138(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1153,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 589  cons* */
t4=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[222],lf[223],C_retrieve2(lf[87],"compile-options"));}}

/* k1151 in k1133 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87],t1);
t3=((C_word*)t0)[2];
f_1138(t3,t2);}

/* k1136 in k1133 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_1138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1138,NULL,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[220]:lf[221]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[92],"link-options"));
t4=C_mutate(&lf[92],t3);
t5=((C_word*)t0)[2];
f_920(2,t5,t4);}

/* k1076 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 573  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1064 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 572  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1052 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 571  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1040 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 570  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1007 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[83],t1);
t3=lf[102]=C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_920(2,t4,t3);}

/* k996 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[83],t1);
t3=lf[101]=C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_920(2,t4,t3);}

/* k965 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 549  system */
t2=C_retrieve(lf[136]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k958 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 550  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k949 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 546  print */
t2=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k942 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 547  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k930 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 544  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k918 in k915 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 749  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_735(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_746,2,t0,t1);}
t2=C_mutate(&lf[87],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_750,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 499  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[92],"link-options"),C_retrieve2(lf[93],"builtin-link-options"));}

/* k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_750,2,t0,t1);}
t2=C_mutate(&lf[92],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_753,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[68],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_875,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[69],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_908,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 502  compiler-options */
f_2449(t5);}
else{
t5=t4;
f_875(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_753(2,t4,C_SCHEME_UNDEFINED);}}

/* k906 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 502  print* */
t2=*((C_word*)lf[185]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k873 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[70],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_901,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 503  linker-options */
f_2698(t3);}
else{
t3=t2;
f_878(2,t3,C_SCHEME_UNDEFINED);}}

/* k899 in k873 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 503  print* */
t2=*((C_word*)lf[185]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k876 in k873 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_881,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[71],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_894,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 504  linker-libraries */
f_2750(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}
else{
t3=t2;
f_881(2,t3,C_SCHEME_UNDEFINED);}}

/* k892 in k876 in k873 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 504  print* */
t2=*((C_word*)lf[185]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k879 in k876 in k873 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 505  newline */
t3=*((C_word*)lf[184]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k882 in k879 in k876 in k873 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 506  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_756,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(C_retrieve2(lf[60],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_800,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_nullp(C_retrieve2(lf[61],"c-files"));
t5=(C_truep(t4)?(C_word)C_i_nullp(C_retrieve2(lf[63],"object-files")):C_SCHEME_FALSE);
if(C_truep(t5)){
/* csc.scm: 512  quit */
f_437(t3,lf[163],C_SCHEME_END_OF_LIST);}
else{
t6=t3;
f_800(2,t6,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_838,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[100],"shared"))?(C_word)C_i_not(C_retrieve2(lf[67],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[183],C_retrieve2(lf[83],"translate-options"));
t6=C_mutate(&lf[83],t5);
t7=t3;
f_838(t7,t6);}
else{
t5=t3;
f_838(t5,C_SCHEME_UNDEFINED);}}}

/* k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_838,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_841,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[94],"target-filename"))){
t3=t2;
f_841(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_848,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[100],"shared"))){
t4=(C_word)C_i_car(C_retrieve2(lf[60],"scheme-files"));
/* csc.scm: 525  pathname-replace-extension */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[48],"shared-library-extension"));}
else{
t4=(C_word)C_i_car(C_retrieve2(lf[60],"scheme-files"));
/* csc.scm: 526  pathname-replace-extension */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[44],"executable-extension"));}}}

/* k846 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94],t1);
t3=((C_word*)t0)[2];
f_841(t3,t2);}

/* k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_841,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2109,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[60],"scheme-files"));}

/* a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2109,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2113,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 757  pathname-replace-extension */
t4=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[182]);}

/* k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2116,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2354,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2360,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 758  file-exists? */
t5=C_retrieve(lf[172]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2358 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2363,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 759  with-input-from-file */
t3=C_retrieve(lf[171]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_retrieve(lf[170]));}
else{
t2=((C_word*)t0)[3];
f_2354(t2,C_SCHEME_FALSE);}}

/* k2361 in k2358 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eofp(t1);
t3=((C_word*)t0)[2];
f_2354(t3,(C_truep(t2)?t2:(C_word)C_i_string_equal_p(lf[181],t1)));}

/* k2352 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2354(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm: 761  $delete-file */
t2=C_retrieve2(lf[138],"$delete-file");
f_2960(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2116(2,t2,C_SCHEME_UNDEFINED);}}

/* k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_length(C_retrieve2(lf[60],"scheme-files"));
t4=(C_word)C_i_nequalp(C_fix(1),t3);
t5=(C_truep(t4)?C_retrieve2(lf[94],"target-filename"):((C_word*)t0)[2]);
t6=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?lf[178]:(C_truep(C_retrieve2(lf[66],"objc-mode"))?lf[179]:lf[180]));
/* csc.scm: 762  pathname-replace-extension */
t7=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,t5,t6);}

/* k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2122,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2283,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2287,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2291,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 772  cleanup-filename */
t7=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2289 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2295,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2299,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[99],"to-stdout"))){
t4=t3;
f_2299(t4,lf[176]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2333,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 776  cleanup-filename */
t5=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2331 in k2289 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2299(t2,(C_word)C_a_i_list(&a,2,lf[177],t1));}

/* k2297 in k2289 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2299,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2303,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[101],"static");
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2314,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_2314(t5,t3);}
else{
t5=C_retrieve2(lf[102],"static-libs");
t6=t4;
f_2314(t6,(C_truep(t5)?t5:C_retrieve2(lf[103],"static-extensions")));}}

/* k2312 in k2297 in k2289 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2314(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2314,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2319,tmp=(C_word)a,a+=2,tmp);
/* map */
t3=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve2(lf[104],"required-extensions"));}
else{
t2=((C_word*)t0)[2];
f_2303(2,t2,C_SCHEME_END_OF_LIST);}}

/* a2318 in k2312 in k2297 in k2289 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2319,3,t0,t1,t2);}
/* csc.scm: 778  conc */
t3=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[175],t2);}

/* k2301 in k2297 in k2289 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2307,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2311,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 780  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[83],"translate-options"),C_SCHEME_END_OF_LIST);}

/* k2309 in k2301 in k2297 in k2289 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[109],"quote-option"),t1);}

/* k2305 in k2301 in k2297 in k2289 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 773  append */
t2=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2293 in k2289 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 772  cons* */
t2=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve2(lf[28],"translator"),((C_word*)t0)[2],t1);}

/* k2285 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 771  string-intersperse */
t2=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[173]);}

/* k2281 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 770  $system */
t2=C_retrieve2(lf[133],"$system");
f_2928(3,t2,((C_word*)t0)[2],t1);}

/* k2277 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2122(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 782  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 783  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_retrieve2(lf[61],"c-files"));}

/* k2124 in k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2126,2,t0,t1);}
t2=C_mutate(&lf[61],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2130,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 784  append */
t5=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[62],"generated-c-files"));}

/* k2128 in k2124 in k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2130,2,t0,t1);}
t2=C_mutate(&lf[62],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 785  file-exists? */
t4=C_retrieve(lf[172]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2134 in k2128 in k2124 in k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2136,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2144,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 786  with-input-from-file */
t4=C_retrieve(lf[171]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a2143 in k2134 in k2128 in k2124 in k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2148,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 788  read-line */
t3=C_retrieve(lf[170]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2146 in a2143 in k2134 in k2128 in k2124 in k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2153,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2261,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 798  read-file */
t4=C_retrieve(lf[169]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2259 in k2146 in a2143 in k2134 in k2128 in k2124 in k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2152 in k2146 in a2143 in k2134 in k2128 in k2124 in k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2153,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2155,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[166]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(t2);
/* for-each */
t8=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,C_retrieve2(lf[133],"$system"),t7);}
else{
/* g192194 */
f_2155(t1,t2);}}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[167]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_listp(t8))){
t9=(C_word)C_i_cdr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2209,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* append */
t11=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,C_retrieve2(lf[87],"compile-options"),t9);}
else{
/* g192194 */
f_2155(t1,t2);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2222,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_eqp(t9,lf[168]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t2);
t12=t8;
f_2222(t12,(C_word)C_i_listp(t11));}
else{
t11=t8;
f_2222(t11,C_SCHEME_FALSE);}}}}
else{
/* g192194 */
f_2155(t1,t2);}}

/* k2220 in a2152 in k2146 in a2143 in k2134 in k2128 in k2124 in k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2222(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2222,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[92],"link-options"),t2);}
else{
/* g192194 */
f_2155(((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k2227 in k2220 in a2152 in k2146 in a2143 in k2134 in k2128 in k2124 in k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2207 in a2152 in k2146 in a2143 in k2134 in k2128 in k2124 in k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* g192 in a2152 in k2146 in a2143 in k2134 in k2128 in k2124 in k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2155(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2155,NULL,2,t1,t2);}
/* csc.scm: 797  error */
t3=*((C_word*)lf[164]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[165],t2);}

/* k2137 in k2134 in k2128 in k2124 in k2120 in k2117 in k2114 in k2111 in a2108 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 799  $delete-file */
t2=C_retrieve2(lf[138],"$delete-file");
f_2960(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2099 in k839 in k836 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[96],"keep-files"))){
t2=((C_word*)t0)[2];
f_756(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_SCHEME_END_OF_LIST);}}

/* k798 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_803,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_nullp(C_retrieve2(lf[61],"c-files"));
t4=(C_truep(t3)?C_retrieve2(lf[63],"object-files"):C_retrieve2(lf[61],"c-files"));
/* csc.scm: 513  last */
t5=C_retrieve(lf[162]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k801 in k798 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_803,2,t0,t1);}
if(C_truep(C_retrieve2(lf[94],"target-filename"))){
t2=((C_word*)t0)[2];
f_756(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_810,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[100],"shared"))){
/* csc.scm: 517  pathname-replace-extension */
t3=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_retrieve2(lf[48],"shared-library-extension"));}
else{
/* csc.scm: 518  pathname-replace-extension */
t3=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_retrieve2(lf[44],"executable-extension"));}}}

/* k808 in k801 in k798 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94],t1);
t3=((C_word*)t0)[2];
f_756(2,t3,t2);}

/* k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_756,2,t0,t1);}
if(C_truep(C_retrieve2(lf[97],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_762,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2378,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2394,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_retrieve2(lf[61],"c-files"));}}

/* a2393 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2394,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2398,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 810  pathname-replace-extension */
t4=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_retrieve2(lf[35],"object-extension"));}

/* k2396 in a2393 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2419,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2423,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?C_retrieve2(lf[30],"c++-compiler"):C_retrieve2(lf[29],"compiler"));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2435,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 816  cleanup-filename */
t7=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2433 in k2396 in a2393 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2447,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 817  cleanup-filename */
t4=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2445 in k2433 in k2396 in a2393 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 817  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[47],"compile-output-flag"),t1);}

/* k2437 in k2433 in k2396 in a2393 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2443,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 819  compiler-options */
f_2449(t2);}

/* k2441 in k2437 in k2433 in k2396 in a2393 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2443,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[160],t1);
/* csc.scm: 813  string-intersperse */
t3=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2421 in k2396 in a2393 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 812  $system */
t2=C_retrieve2(lf[133],"$system");
f_2928(3,t2,((C_word*)t0)[2],t1);}

/* k2417 in k2396 in a2393 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2401(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 820  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k2399 in k2396 in a2393 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[64],"generated-object-files"));
t3=C_mutate(&lf[64],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2376 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2382,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2392,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 824  reverse */
t4=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2390 in k2376 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 824  append */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[63],"object-files"));}

/* k2380 in k2376 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[63],t1);
if(C_truep(C_retrieve2(lf[96],"keep-files"))){
t3=((C_word*)t0)[2];
f_762(2,t3,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t3=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_retrieve2(lf[62],"generated-c-files"));}}

/* k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_762,2,t0,t1);}
if(C_truep(C_retrieve2(lf[98],"compile-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_member(C_retrieve2(lf[94],"target-filename"),C_retrieve2(lf[60],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_777,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 532  printf */
t4=C_retrieve(lf[134]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[159],C_retrieve2(lf[94],"target-filename"),C_retrieve2(lf[94],"target-filename"));}
else{
t3=t2;
f_768(2,t3,C_SCHEME_UNDEFINED);}}}

/* k775 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_790,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_794,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 534  sprintf */
t4=C_retrieve(lf[157]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[158],C_retrieve2(lf[94],"target-filename"),C_retrieve2(lf[94],"target-filename"));}

/* k792 in k775 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 534  $system */
t2=C_retrieve2(lf[133],"$system");
f_2928(3,t2,((C_word*)t0)[2],t1);}

/* k788 in k775 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_768(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 535  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_768,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2474,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2583,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2587,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2589,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2595,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 841  ##sys#call-with-values */
C_call_with_values(4,0,t5,t6,t7);}

/* a2594 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2595r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2595r(t0,t1,t2);}}

static void C_ccall f_2595r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a2588 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2589,2,t0,t1);}
/* csc.scm: 841  static-extension-info */
f_2601(t1);}

/* k2585 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 840  append */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[63],"object-files"),t1);}

/* k2581 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[55],"cleanup-filename"),t1);}

/* k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2477,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 842  cleanup-filename */
t3=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve2(lf[94],"target-filename"));}

/* k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2480,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2547,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2551,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2555,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?C_retrieve2(lf[32],"c++-linker"):C_retrieve2(lf[31],"linker"));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2563,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 850  string-append */
t9=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,C_retrieve2(lf[41],"link-output-flag"),t1);}

/* k2569 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 851  linker-options */
f_2698(t2);}

/* k2573 in k2569 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 852  linker-libraries */
f_2750(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_FALSE));}

/* k2577 in k2573 in k2569 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2579,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],t1);
/* csc.scm: 848  append */
t3=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2561 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 846  cons* */
t2=C_retrieve(lf[129]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2553 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 845  string-intersperse */
t2=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2549 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 844  $system */
t2=C_retrieve2(lf[133],"$system");
f_2928(3,t2,((C_word*)t0)[2],t1);}

/* k2545 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2480(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 853  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k2478 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=(C_word)C_i_not(C_retrieve2(lf[18],"cross-chicken"));
t5=t3;
f_2492(t5,(C_truep(t4)?t4:C_retrieve2(lf[17],"host-mode")));}
else{
t4=t3;
f_2492(t4,C_SCHEME_FALSE);}}

/* k2490 in k2478 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2492,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2509,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2521,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2525,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}
else{
t2=((C_word*)t0)[3];
f_2483(2,t2,C_SCHEME_UNDEFINED);}}

/* k2523 in k2490 in k2478 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 860  prefix */
f_466(((C_word*)t0)[2],lf[154],lf[155],t1);}

/* k2519 in k2490 in k2478 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 859  make-pathname */
t2=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[153]);}

/* k2515 in k2490 in k2478 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 858  quotewrap */
f_479(((C_word*)t0)[2],t1);}

/* k2511 in k2490 in k2478 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 856  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[151],t1,lf[152],((C_word*)t0)[2]);}

/* k2507 in k2490 in k2478 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 855  $system */
t2=C_retrieve2(lf[133],"$system");
f_2928(3,t2,((C_word*)t0)[2],t1);}

/* k2503 in k2490 in k2478 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2483(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 867  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k2481 in k2478 in k2475 in k2472 in k766 in k760 in k754 in k751 in k748 in k744 in loop in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[96],"keep-files"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_retrieve2(lf[64],"generated-object-files"));}}

/* shared-build in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_706(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_706,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_711,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 486  cons* */
t4=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[148],lf[149],C_retrieve2(lf[83],"translate-options"));}

/* k709 in shared-build in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_711,2,t0,t1);}
t2=C_mutate(&lf[83],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 487  append */
t4=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[52],"pic-options"),lf[147],C_retrieve2(lf[87],"compile-options"));}

/* k713 in k709 in shared-build in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_715,2,t0,t1);}
t2=C_mutate(&lf[87],t1);
t3=(C_truep(C_retrieve2(lf[7],"osx"))?(C_truep(((C_word*)t0)[3])?lf[143]:lf[144]):(C_truep(C_retrieve2(lf[5],"msvc"))?lf[145]:lf[146]));
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[92],"link-options"));
t5=C_mutate(&lf[92],t4);
t6=lf[100]=C_SCHEME_TRUE;;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* check in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_667(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_667,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_685,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t7=t6;
f_685(2,t7,C_fix(1));}
else{
t7=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_685(2,t8,(C_word)C_i_car(t4));}
else{
/* csc.scm: 482  ##sys#error */
t8=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k683 in check in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_685,2,t0,t1);}
if(C_truep((C_word)C_i_greater_or_equalp(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 483  quit */
f_437(((C_word*)t0)[3],lf[142],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* t-options in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_660(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_660,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_665,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 479  append */
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[83],"translate-options"),t2);}

/* k663 in t-options in k2984 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[83],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2974 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2982,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[141]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2980 in k2974 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2977 in k2974 in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* $delete-file in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2960,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2964,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[95],"verbose"))){
/* csc.scm: 947  print */
t4=*((C_word*)lf[137]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[140],t2);}
else{
t4=t3;
f_2964(2,t4,C_SCHEME_UNDEFINED);}}

/* k2962 in $delete-file in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[72],"dry-run"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 948  delete-file */
t2=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* $system in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2928,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2932,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[95],"verbose"))){
/* csc.scm: 934  print */
t4=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2932(2,t4,C_SCHEME_UNDEFINED);}}

/* k2930 in $system in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[72],"dry-run"))){
t3=t2;
f_2936(t3,C_fix(0));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2955,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 938  system */
t4=C_retrieve(lf[136]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k2953 in k2930 in $system in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_zerop(t1);
t3=((C_word*)t0)[2];
f_2936(t3,(C_truep(t2)?C_fix(0):C_fix(1)));}

/* k2934 in k2930 in $system in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2936,NULL,2,t0,t1);}
t2=C_mutate(&lf[132],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_zerop(C_retrieve2(lf[132],"last-exit-code")))){
t4=t3;
f_2939(2,t4,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 942  printf */
t4=C_retrieve(lf[134]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[135],C_retrieve2(lf[132],"last-exit-code"),((C_word*)t0)[2]);}}

/* k2937 in k2934 in k2930 in $system in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve2(lf[132],"last-exit-code"));}

/* quote-option in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2899,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2906,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2911,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2925,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t6=C_retrieve(lf[130]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2923 in quote-option in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 925  any */
t2=C_retrieve(lf[131]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2910 in quote-option in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2911,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,lf[122])));}

/* k2904 in quote-option in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2906,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2832,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2846,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2850,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=C_retrieve(lf[130]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2848 in k2904 in quote-option in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2850,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2852,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2852(t5,((C_word*)t0)[2],t1);}

/* fold in k2848 in k2904 in quote-option in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2852(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2852,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_memq(t3,lf[122]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2875,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* csc.scm: 916  fold */
t9=t4;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_whitespacep(t3))){
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=t4;
f_2882(t6,t5);}
else{
t5=t4;
f_2882(t5,C_SCHEME_UNDEFINED);}}}}

/* k2880 in fold in k2848 in k2904 in quote-option in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2882,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csc.scm: 919  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2852(t4,t2,t3);}

/* k2887 in k2880 in fold in k2848 in k2904 in quote-option in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2873 in fold in k2848 in k2904 in quote-option in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 916  cons* */
t2=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_make_character(92),((C_word*)t0)[2],t1);}

/* k2844 in k2904 in quote-option in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2830 in k2904 in quote-option in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2832,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 921  string-translate* */
t3=C_retrieve(lf[126]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,lf[127]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k2840 in k2830 in k2904 in quote-option in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 921  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[124],t1,lf[125]);}

/* linker-libraries in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2750(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2750,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2754,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2754(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2754(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2752 in linker-libraries in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2761,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2765,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2796,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2802,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 896  ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,t5);}
else{
t4=t3;
f_2765(2,t4,C_SCHEME_END_OF_LIST);}}

/* a2801 in k2752 in linker-libraries in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2802r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2802r(t0,t1,t2);}}

static void C_ccall f_2802r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a2795 in k2752 in linker-libraries in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
/* csc.scm: 896  static-extension-info */
f_2601(t1);}

/* k2763 in k2752 in linker-libraries in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2765,2,t0,t1);}
t2=C_retrieve2(lf[101],"static");
t3=(C_truep(t2)?t2:C_retrieve2(lf[102],"static-libs"));
t4=(C_truep(t3)?(C_truep(C_retrieve2(lf[105],"gui"))?C_retrieve2(lf[79],"gui-library-files"):C_retrieve2(lf[81],"library-files")):(C_truep(C_retrieve2(lf[105],"gui"))?C_retrieve2(lf[80],"gui-shared-library-files"):C_retrieve2(lf[82],"shared-library-files")));
t5=C_retrieve2(lf[101],"static");
t6=(C_truep(t5)?t5:C_retrieve2(lf[102],"static-libs"));
t7=(C_truep(t6)?(C_word)C_a_i_list(&a,1,C_retrieve2(lf[73],"extra-libraries")):(C_word)C_a_i_list(&a,1,C_retrieve2(lf[74],"extra-shared-libraries")));
/* csc.scm: 895  append */
t8=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,((C_word*)t0)[2],t1,t4,t7);}

/* k2759 in k2752 in linker-libraries in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 894  string-intersperse */
t2=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* linker-options in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2698(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2698,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2706,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2732,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2736,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2738,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2744,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 890  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a2743 in linker-options in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2744r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2744r(t0,t1,t2);}}

static void C_ccall f_2744r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a2737 in linker-options in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2738,2,t0,t1);}
/* csc.scm: 890  static-extension-info */
f_2601(t1);}

/* k2734 in linker-options in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 889  append */
t2=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_retrieve2(lf[90],"linking-optimization-options"),C_retrieve2(lf[92],"link-options"),t1);}

/* k2730 in linker-options in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 888  string-intersperse */
t2=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2704 in linker-options in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(C_retrieve2(lf[101],"static"))?(C_truep(lf[3])?C_SCHEME_FALSE:(C_truep(C_retrieve2(lf[5],"msvc"))?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve2(lf[7],"osx")))):C_SCHEME_FALSE);
t3=(C_truep(t2)?lf[118]:lf[119]);
/* csc.scm: 887  string-append */
t4=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t1,t3);}

/* static-extension-info in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2601(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2601,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2605,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 871  repository-path */
t3=C_retrieve(lf[116]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2603 in static-extension-info in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2605,2,t0,t1);}
t2=C_retrieve2(lf[101],"static");
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_2611(t4,t2);}
else{
t4=C_retrieve2(lf[102],"static-libs");
t5=t3;
f_2611(t5,(C_truep(t4)?t4:C_retrieve2(lf[103],"static-extensions")));}}

/* k2609 in k2603 in static-extension-info in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2611,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2616(t5,((C_word*)t0)[2],C_retrieve2(lf[104],"required-extensions"),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
/* csc.scm: 884  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* loop in k2609 in k2603 in static-extension-info in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2616(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2616,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2630,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 875  reverse */
t6=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
/* csc.scm: 876  extension-information */
t7=C_retrieve(lf[115]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k2635 in loop in k2609 in k2603 in static-extension-info in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2637,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[113],t1);
t3=(C_word)C_i_assq(lf[114],t1);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* csc.scm: 881  make-pathname */
t8=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}
else{
t6=t5;
f_2657(t6,((C_word*)t0)[3]);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* csc.scm: 883  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2616(t3,((C_word*)t0)[5],t2,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k2673 in k2635 in loop in k2609 in k2603 in static-extension-info in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2675,2,t0,t1);}
t2=((C_word*)t0)[3];
f_2657(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2655 in k2635 in loop in k2609 in k2603 in static-extension-info in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2657(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2657,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2661,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=t2;
f_2661(t4,(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}
else{
t3=t2;
f_2661(t3,((C_word*)t0)[2]);}}

/* k2659 in k2655 in k2635 in loop in k2609 in k2603 in static-extension-info in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2661(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 880  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2616(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2628 in loop in k2609 in k2603 in static-extension-info in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2634,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 875  reverse */
t3=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2632 in k2628 in loop in k2609 in k2603 in static-extension-info in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 875  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* compiler-options in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_2449(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2449,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2457,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2461,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[101],"static");
t5=(C_truep(t4)?t4:C_retrieve2(lf[102],"static-libs"));
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_END_OF_LIST);
/* csc.scm: 830  append */
t7=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t3,t6,C_retrieve2(lf[89],"compilation-optimization-options"),C_retrieve2(lf[87],"compile-options"));}

/* k2459 in compiler-options in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[109],"quote-option"),t1);}

/* k2455 in compiler-options in k635 in k630 in k622 in k614 in k605 in k3108 in k597 in k3141 in k589 in k585 in k559 in k554 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 828  string-intersperse */
t2=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_3201 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3201,3,t0,t1,t2);}
/* csc.scm: 165  quotewrap */
f_479(t1,t2);}

/* f_3206 in k546 in k542 in k511 in k507 in k503 in k499 in k495 in k491 in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3206,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* quotewrap in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_479(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_479,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_486,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 127  string-any */
t4=C_retrieve(lf[25]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,*((C_word*)lf[26]+1),t2);}

/* k484 in quotewrap in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm: 128  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[23],((C_word*)t0)[2],lf[24]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* prefix in k454 in k450 in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_466(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_466,NULL,4,t1,t2,t3,t4);}
if(C_truep(C_retrieve2(lf[14],"chicken-prefix"))){
t5=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[14],"chicken-prefix"),t3);
/* csc.scm: 123  make-pathname */
t6=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* quit in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_437(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_437,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_441,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_448,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 113  current-error-port */
t6=C_retrieve(lf[13]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k446 in quit in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 113  fprintf */
t2=C_retrieve(lf[11]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],t1,lf[12],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k439 in quit in k433 in k3316 in k3320 in k3324 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 114  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[318] = {
{"toplevelcsc.scm",(void*)C_toplevel},
{"f_389csc.scm",(void*)f_389},
{"f_392csc.scm",(void*)f_392},
{"f_395csc.scm",(void*)f_395},
{"f_398csc.scm",(void*)f_398},
{"f_401csc.scm",(void*)f_401},
{"f_404csc.scm",(void*)f_404},
{"f_407csc.scm",(void*)f_407},
{"f_410csc.scm",(void*)f_410},
{"f_413csc.scm",(void*)f_413},
{"f_416csc.scm",(void*)f_416},
{"f_419csc.scm",(void*)f_419},
{"f_3326csc.scm",(void*)f_3326},
{"f_3322csc.scm",(void*)f_3322},
{"f_3318csc.scm",(void*)f_3318},
{"f_3314csc.scm",(void*)f_3314},
{"f_3310csc.scm",(void*)f_3310},
{"f_435csc.scm",(void*)f_435},
{"f_452csc.scm",(void*)f_452},
{"f_456csc.scm",(void*)f_456},
{"f_3294csc.scm",(void*)f_3294},
{"f_3290csc.scm",(void*)f_3290},
{"f_493csc.scm",(void*)f_493},
{"f_3276csc.scm",(void*)f_3276},
{"f_3280csc.scm",(void*)f_3280},
{"f_3272csc.scm",(void*)f_3272},
{"f_3268csc.scm",(void*)f_3268},
{"f_497csc.scm",(void*)f_497},
{"f_3258csc.scm",(void*)f_3258},
{"f_501csc.scm",(void*)f_501},
{"f_3248csc.scm",(void*)f_3248},
{"f_505csc.scm",(void*)f_505},
{"f_3235csc.scm",(void*)f_3235},
{"f_509csc.scm",(void*)f_509},
{"f_3222csc.scm",(void*)f_3222},
{"f_513csc.scm",(void*)f_513},
{"f_544csc.scm",(void*)f_544},
{"f_548csc.scm",(void*)f_548},
{"f_3191csc.scm",(void*)f_3191},
{"f_556csc.scm",(void*)f_556},
{"f_3181csc.scm",(void*)f_3181},
{"f_561csc.scm",(void*)f_561},
{"f_587csc.scm",(void*)f_587},
{"f_591csc.scm",(void*)f_591},
{"f_3155csc.scm",(void*)f_3155},
{"f_3159csc.scm",(void*)f_3159},
{"f_3151csc.scm",(void*)f_3151},
{"f_3147csc.scm",(void*)f_3147},
{"f_3143csc.scm",(void*)f_3143},
{"f_3139csc.scm",(void*)f_3139},
{"f_599csc.scm",(void*)f_599},
{"f_3122csc.scm",(void*)f_3122},
{"f_3126csc.scm",(void*)f_3126},
{"f_3118csc.scm",(void*)f_3118},
{"f_3114csc.scm",(void*)f_3114},
{"f_3110csc.scm",(void*)f_3110},
{"f_3106csc.scm",(void*)f_3106},
{"f_607csc.scm",(void*)f_607},
{"f_3093csc.scm",(void*)f_3093},
{"f_616csc.scm",(void*)f_616},
{"f_3082csc.scm",(void*)f_3082},
{"f_3078csc.scm",(void*)f_3078},
{"f_624csc.scm",(void*)f_624},
{"f_3065csc.scm",(void*)f_3065},
{"f_632csc.scm",(void*)f_632},
{"f_3058csc.scm",(void*)f_3058},
{"f_3032csc.scm",(void*)f_3032},
{"f_3048csc.scm",(void*)f_3048},
{"f_3044csc.scm",(void*)f_3044},
{"f_3040csc.scm",(void*)f_3040},
{"f_3036csc.scm",(void*)f_3036},
{"f_3025csc.scm",(void*)f_3025},
{"f_3021csc.scm",(void*)f_3021},
{"f_3011csc.scm",(void*)f_3011},
{"f_3007csc.scm",(void*)f_3007},
{"f_637csc.scm",(void*)f_637},
{"f_2994csc.scm",(void*)f_2994},
{"f_2990csc.scm",(void*)f_2990},
{"f_2986csc.scm",(void*)f_2986},
{"f_735csc.scm",(void*)f_735},
{"f_917csc.scm",(void*)f_917},
{"f_1402csc.scm",(void*)f_1402},
{"f_1643csc.scm",(void*)f_1643},
{"f_1646csc.scm",(void*)f_1646},
{"f_1649csc.scm",(void*)f_1649},
{"f_2031csc.scm",(void*)f_2031},
{"f_1700csc.scm",(void*)f_1700},
{"f_1709csc.scm",(void*)f_1709},
{"f_1886csc.scm",(void*)f_1886},
{"f_1994csc.scm",(void*)f_1994},
{"f_2000csc.scm",(void*)f_2000},
{"f_1897csc.scm",(void*)f_1897},
{"f_1908csc.scm",(void*)f_1908},
{"f_1984csc.scm",(void*)f_1984},
{"f_1976csc.scm",(void*)f_1976},
{"f_1959csc.scm",(void*)f_1959},
{"f_1935csc.scm",(void*)f_1935},
{"f_1940csc.scm",(void*)f_1940},
{"f_1922csc.scm",(void*)f_1922},
{"f_1891csc.scm",(void*)f_1891},
{"f_1856csc.scm",(void*)f_1856},
{"f_1787csc.scm",(void*)f_1787},
{"f_1839csc.scm",(void*)f_1839},
{"f_1835csc.scm",(void*)f_1835},
{"f_1820csc.scm",(void*)f_1820},
{"f_1818csc.scm",(void*)f_1818},
{"f_1814csc.scm",(void*)f_1814},
{"f_1791csc.scm",(void*)f_1791},
{"f_1777csc.scm",(void*)f_1777},
{"f_1764csc.scm",(void*)f_1764},
{"f_1747csc.scm",(void*)f_1747},
{"f_1733csc.scm",(void*)f_1733},
{"f_1719csc.scm",(void*)f_1719},
{"f_1681csc.scm",(void*)f_1681},
{"f_1687csc.scm",(void*)f_1687},
{"f_1690csc.scm",(void*)f_1690},
{"f_1636csc.scm",(void*)f_1636},
{"f_1640csc.scm",(void*)f_1640},
{"f_1590csc.scm",(void*)f_1590},
{"f_1620csc.scm",(void*)f_1620},
{"f_1612csc.scm",(void*)f_1612},
{"f_1600csc.scm",(void*)f_1600},
{"f_1579csc.scm",(void*)f_1579},
{"f_1554csc.scm",(void*)f_1554},
{"f_1566csc.scm",(void*)f_1566},
{"f_1558csc.scm",(void*)f_1558},
{"f_1541csc.scm",(void*)f_1541},
{"f_1515csc.scm",(void*)f_1515},
{"f_1527csc.scm",(void*)f_1527},
{"f_1519csc.scm",(void*)f_1519},
{"f_1494csc.scm",(void*)f_1494},
{"f_1498csc.scm",(void*)f_1498},
{"f_1477csc.scm",(void*)f_1477},
{"f_1460csc.scm",(void*)f_1460},
{"f_1443csc.scm",(void*)f_1443},
{"f_1426csc.scm",(void*)f_1426},
{"f_1385csc.scm",(void*)f_1385},
{"f_1375csc.scm",(void*)f_1375},
{"f_1365csc.scm",(void*)f_1365},
{"f_1355csc.scm",(void*)f_1355},
{"f_1345csc.scm",(void*)f_1345},
{"f_1335csc.scm",(void*)f_1335},
{"f_1314csc.scm",(void*)f_1314},
{"f_1290csc.scm",(void*)f_1290},
{"f_1301csc.scm",(void*)f_1301},
{"f_1293csc.scm",(void*)f_1293},
{"f_1277csc.scm",(void*)f_1277},
{"f_1266csc.scm",(void*)f_1266},
{"f_1226csc.scm",(void*)f_1226},
{"f_1230csc.scm",(void*)f_1230},
{"f_1233csc.scm",(void*)f_1233},
{"f_1135csc.scm",(void*)f_1135},
{"f_1153csc.scm",(void*)f_1153},
{"f_1138csc.scm",(void*)f_1138},
{"f_1078csc.scm",(void*)f_1078},
{"f_1066csc.scm",(void*)f_1066},
{"f_1054csc.scm",(void*)f_1054},
{"f_1042csc.scm",(void*)f_1042},
{"f_1009csc.scm",(void*)f_1009},
{"f_998csc.scm",(void*)f_998},
{"f_967csc.scm",(void*)f_967},
{"f_960csc.scm",(void*)f_960},
{"f_951csc.scm",(void*)f_951},
{"f_944csc.scm",(void*)f_944},
{"f_932csc.scm",(void*)f_932},
{"f_920csc.scm",(void*)f_920},
{"f_746csc.scm",(void*)f_746},
{"f_750csc.scm",(void*)f_750},
{"f_908csc.scm",(void*)f_908},
{"f_875csc.scm",(void*)f_875},
{"f_901csc.scm",(void*)f_901},
{"f_878csc.scm",(void*)f_878},
{"f_894csc.scm",(void*)f_894},
{"f_881csc.scm",(void*)f_881},
{"f_884csc.scm",(void*)f_884},
{"f_753csc.scm",(void*)f_753},
{"f_838csc.scm",(void*)f_838},
{"f_848csc.scm",(void*)f_848},
{"f_841csc.scm",(void*)f_841},
{"f_2109csc.scm",(void*)f_2109},
{"f_2113csc.scm",(void*)f_2113},
{"f_2360csc.scm",(void*)f_2360},
{"f_2363csc.scm",(void*)f_2363},
{"f_2354csc.scm",(void*)f_2354},
{"f_2116csc.scm",(void*)f_2116},
{"f_2119csc.scm",(void*)f_2119},
{"f_2291csc.scm",(void*)f_2291},
{"f_2333csc.scm",(void*)f_2333},
{"f_2299csc.scm",(void*)f_2299},
{"f_2314csc.scm",(void*)f_2314},
{"f_2319csc.scm",(void*)f_2319},
{"f_2303csc.scm",(void*)f_2303},
{"f_2311csc.scm",(void*)f_2311},
{"f_2307csc.scm",(void*)f_2307},
{"f_2295csc.scm",(void*)f_2295},
{"f_2287csc.scm",(void*)f_2287},
{"f_2283csc.scm",(void*)f_2283},
{"f_2279csc.scm",(void*)f_2279},
{"f_2122csc.scm",(void*)f_2122},
{"f_2126csc.scm",(void*)f_2126},
{"f_2130csc.scm",(void*)f_2130},
{"f_2136csc.scm",(void*)f_2136},
{"f_2144csc.scm",(void*)f_2144},
{"f_2148csc.scm",(void*)f_2148},
{"f_2261csc.scm",(void*)f_2261},
{"f_2153csc.scm",(void*)f_2153},
{"f_2222csc.scm",(void*)f_2222},
{"f_2229csc.scm",(void*)f_2229},
{"f_2209csc.scm",(void*)f_2209},
{"f_2155csc.scm",(void*)f_2155},
{"f_2139csc.scm",(void*)f_2139},
{"f_2101csc.scm",(void*)f_2101},
{"f_800csc.scm",(void*)f_800},
{"f_803csc.scm",(void*)f_803},
{"f_810csc.scm",(void*)f_810},
{"f_756csc.scm",(void*)f_756},
{"f_2394csc.scm",(void*)f_2394},
{"f_2398csc.scm",(void*)f_2398},
{"f_2435csc.scm",(void*)f_2435},
{"f_2447csc.scm",(void*)f_2447},
{"f_2439csc.scm",(void*)f_2439},
{"f_2443csc.scm",(void*)f_2443},
{"f_2423csc.scm",(void*)f_2423},
{"f_2419csc.scm",(void*)f_2419},
{"f_2401csc.scm",(void*)f_2401},
{"f_2378csc.scm",(void*)f_2378},
{"f_2392csc.scm",(void*)f_2392},
{"f_2382csc.scm",(void*)f_2382},
{"f_762csc.scm",(void*)f_762},
{"f_777csc.scm",(void*)f_777},
{"f_794csc.scm",(void*)f_794},
{"f_790csc.scm",(void*)f_790},
{"f_768csc.scm",(void*)f_768},
{"f_2595csc.scm",(void*)f_2595},
{"f_2589csc.scm",(void*)f_2589},
{"f_2587csc.scm",(void*)f_2587},
{"f_2583csc.scm",(void*)f_2583},
{"f_2474csc.scm",(void*)f_2474},
{"f_2477csc.scm",(void*)f_2477},
{"f_2571csc.scm",(void*)f_2571},
{"f_2575csc.scm",(void*)f_2575},
{"f_2579csc.scm",(void*)f_2579},
{"f_2563csc.scm",(void*)f_2563},
{"f_2555csc.scm",(void*)f_2555},
{"f_2551csc.scm",(void*)f_2551},
{"f_2547csc.scm",(void*)f_2547},
{"f_2480csc.scm",(void*)f_2480},
{"f_2492csc.scm",(void*)f_2492},
{"f_2525csc.scm",(void*)f_2525},
{"f_2521csc.scm",(void*)f_2521},
{"f_2517csc.scm",(void*)f_2517},
{"f_2513csc.scm",(void*)f_2513},
{"f_2509csc.scm",(void*)f_2509},
{"f_2505csc.scm",(void*)f_2505},
{"f_2483csc.scm",(void*)f_2483},
{"f_706csc.scm",(void*)f_706},
{"f_711csc.scm",(void*)f_711},
{"f_715csc.scm",(void*)f_715},
{"f_667csc.scm",(void*)f_667},
{"f_685csc.scm",(void*)f_685},
{"f_660csc.scm",(void*)f_660},
{"f_665csc.scm",(void*)f_665},
{"f_2976csc.scm",(void*)f_2976},
{"f_2982csc.scm",(void*)f_2982},
{"f_2979csc.scm",(void*)f_2979},
{"f_2960csc.scm",(void*)f_2960},
{"f_2964csc.scm",(void*)f_2964},
{"f_2928csc.scm",(void*)f_2928},
{"f_2932csc.scm",(void*)f_2932},
{"f_2955csc.scm",(void*)f_2955},
{"f_2936csc.scm",(void*)f_2936},
{"f_2939csc.scm",(void*)f_2939},
{"f_2899csc.scm",(void*)f_2899},
{"f_2925csc.scm",(void*)f_2925},
{"f_2911csc.scm",(void*)f_2911},
{"f_2906csc.scm",(void*)f_2906},
{"f_2850csc.scm",(void*)f_2850},
{"f_2852csc.scm",(void*)f_2852},
{"f_2882csc.scm",(void*)f_2882},
{"f_2889csc.scm",(void*)f_2889},
{"f_2875csc.scm",(void*)f_2875},
{"f_2846csc.scm",(void*)f_2846},
{"f_2832csc.scm",(void*)f_2832},
{"f_2842csc.scm",(void*)f_2842},
{"f_2750csc.scm",(void*)f_2750},
{"f_2754csc.scm",(void*)f_2754},
{"f_2802csc.scm",(void*)f_2802},
{"f_2796csc.scm",(void*)f_2796},
{"f_2765csc.scm",(void*)f_2765},
{"f_2761csc.scm",(void*)f_2761},
{"f_2698csc.scm",(void*)f_2698},
{"f_2744csc.scm",(void*)f_2744},
{"f_2738csc.scm",(void*)f_2738},
{"f_2736csc.scm",(void*)f_2736},
{"f_2732csc.scm",(void*)f_2732},
{"f_2706csc.scm",(void*)f_2706},
{"f_2601csc.scm",(void*)f_2601},
{"f_2605csc.scm",(void*)f_2605},
{"f_2611csc.scm",(void*)f_2611},
{"f_2616csc.scm",(void*)f_2616},
{"f_2637csc.scm",(void*)f_2637},
{"f_2675csc.scm",(void*)f_2675},
{"f_2657csc.scm",(void*)f_2657},
{"f_2661csc.scm",(void*)f_2661},
{"f_2630csc.scm",(void*)f_2630},
{"f_2634csc.scm",(void*)f_2634},
{"f_2449csc.scm",(void*)f_2449},
{"f_2461csc.scm",(void*)f_2461},
{"f_2457csc.scm",(void*)f_2457},
{"f_3201csc.scm",(void*)f_3201},
{"f_3206csc.scm",(void*)f_3206},
{"f_479csc.scm",(void*)f_479},
{"f_486csc.scm",(void*)f_486},
{"f_466csc.scm",(void*)f_466},
{"f_437csc.scm",(void*)f_437},
{"f_448csc.scm",(void*)f_448},
{"f_441csc.scm",(void*)f_441},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
