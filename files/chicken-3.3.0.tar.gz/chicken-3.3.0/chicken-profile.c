/* Generated from chicken-profile.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-06-28 12:20
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10664	compiled 2008-06-28 on galinha (Linux)
   command line: chicken-profile.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -output-file chicken-profile.c
   used units: library eval data_structures extras srfi_69 srfi_1 srfi_13 srfi_69 posix utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[92];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_163)
static void C_ccall f_163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_166)
static void C_ccall f_166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_169)
static void C_ccall f_169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_172)
static void C_ccall f_172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_175)
static void C_ccall f_175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_178)
static void C_ccall f_178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_181)
static void C_ccall f_181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_184)
static void C_ccall f_184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_187)
static void C_ccall f_187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_190)
static void C_ccall f_190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_246)
static void C_fcall f_246(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_485)
static void C_fcall f_485(C_word t0,C_word t1) C_noret;
C_noret_decl(f_479)
static void C_ccall f_479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_671)
static void C_ccall f_671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_675)
static void C_ccall f_675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_679)
static void C_ccall f_679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_636)
static void C_fcall f_636(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_646)
static void C_ccall f_646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_438)
static void C_ccall f_438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_421)
static void C_ccall f_421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_414)
static void C_ccall f_414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_360)
static void C_ccall f_360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_353)
static void C_fcall f_353(C_word t0) C_noret;
C_noret_decl(f_341)
static void C_fcall f_341(C_word t0) C_noret;
C_noret_decl(f_352)
static void C_ccall f_352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_345)
static void C_ccall f_345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_320)
static void C_fcall f_320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_340)
static void C_ccall f_340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_324)
static void C_ccall f_324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_301)
static void C_fcall f_301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_263)
static void C_ccall f_263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_281)
static void C_ccall f_281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_289)
static void C_ccall f_289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_293)
static void C_ccall f_293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_279)
static void C_ccall f_279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_266)
static void C_ccall f_266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_256)
static void C_fcall f_256(C_word t0,C_word t1) C_noret;
C_noret_decl(f_895)
static void C_ccall f_895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_898)
static void C_ccall f_898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1084)
static void C_ccall f_1084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1102)
static void C_fcall f_1102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1109)
static void C_fcall f_1109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1082)
static void C_ccall f_1082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_904)
static void C_ccall f_904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_907)
static void C_fcall f_907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_911)
static void C_ccall f_911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_920)
static void C_ccall f_920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_940)
static void C_ccall f_940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_937)
static void C_ccall f_937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_933)
static void C_ccall f_933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_835)
static void C_fcall f_835(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_846)
static void C_ccall f_846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_878)
static void C_ccall f_878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_882)
static void C_ccall f_882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_870)
static void C_ccall f_870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_854)
static void C_ccall f_854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_755)
static void C_ccall f_755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_755)
static void C_ccall f_755r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_787)
static void C_fcall f_787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_782)
static void C_fcall f_782(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_757)
static void C_fcall f_757(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_688)
static void C_ccall f_688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_692)
static void C_ccall f_692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_702)
static void C_ccall f_702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_704)
static void C_fcall f_704(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_729)
static void C_ccall f_729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_714)
static void C_ccall f_714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_721)
static void C_ccall f_721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_695)
static void C_ccall f_695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_604)
static void C_ccall f_604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_612)
static void C_ccall f_612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_616)
static void C_ccall f_616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_575)
static void C_ccall f_575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_546)
static void C_ccall f_546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_511)
static void C_ccall f_511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_199)
static void C_fcall f_199(C_word t0) C_noret;
C_noret_decl(f_210)
static void C_ccall f_210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_203)
static void C_ccall f_203(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_246)
static void C_fcall trf_246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_246(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_246(t0,t1,t2);}

C_noret_decl(trf_485)
static void C_fcall trf_485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_485(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_485(t0,t1);}

C_noret_decl(trf_636)
static void C_fcall trf_636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_636(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_636(t0,t1,t2);}

C_noret_decl(trf_353)
static void C_fcall trf_353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_353(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_353(t0);}

C_noret_decl(trf_341)
static void C_fcall trf_341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_341(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_341(t0);}

C_noret_decl(trf_320)
static void C_fcall trf_320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_320(t0,t1);}

C_noret_decl(trf_301)
static void C_fcall trf_301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_301(t0,t1);}

C_noret_decl(trf_256)
static void C_fcall trf_256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_256(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_256(t0,t1);}

C_noret_decl(trf_1102)
static void C_fcall trf_1102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1102(t0,t1);}

C_noret_decl(trf_1109)
static void C_fcall trf_1109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1109(t0,t1);}

C_noret_decl(trf_907)
static void C_fcall trf_907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_907(t0,t1);}

C_noret_decl(trf_835)
static void C_fcall trf_835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_835(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_835(t0,t1,t2);}

C_noret_decl(trf_787)
static void C_fcall trf_787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_787(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_787(t0,t1);}

C_noret_decl(trf_782)
static void C_fcall trf_782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_782(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_782(t0,t1,t2);}

C_noret_decl(trf_757)
static void C_fcall trf_757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_757(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_757(t0,t1,t2,t3);}

C_noret_decl(trf_704)
static void C_fcall trf_704(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_704(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_704(t0,t1,t2);}

C_noret_decl(trf_199)
static void C_fcall trf_199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_199(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_199(t0);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(396)){
C_save(t1);
C_rereclaim2(396*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,92);
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],7,"display");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\001\242)\012 -no-unused                remove procedures that are never called\012 -top "
"N                    display only the top N entries\012 -help                     s"
"how this text and exit\012 -version                  show version and exit\012 -releas"
"e                  show release number and exit\012\012 FILENAME defaults to the `PROF"
"ILE.<number>\047, selecting the one with\012 the highest modification time, in case mu"
"ltiple profiles exist.\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\001\315Usage: chicken-profile [FILENAME | OPTION] ...\012\012 -sort-by-calls            "
"sort output by call frequency\012 -sort-by-time             sort output by procedur"
"e execution time\012 -sort-by-avg              sort output by average procedure exe"
"cution time\012 -sort-by-name             sort output alphabetically by procedure n"
"ame\012 -decimals DDD             set number of decimals for seconds, average and\012 "
"                          percent columns (three digits, default: ");
lf[14]=C_h_intern(&lf[14],19,"\003sysprint-to-string");
lf[19]=C_h_intern(&lf[19],8,"string<\077");
lf[20]=C_h_intern(&lf[20],14,"symbol->string");
lf[22]=C_h_intern(&lf[22],17,"hash-table->alist");
lf[23]=C_h_intern(&lf[23],4,"read");
lf[24]=C_h_intern(&lf[24],15,"hash-table-set!");
lf[25]=C_h_intern(&lf[25],3,"map");
lf[26]=C_h_intern(&lf[26],22,"hash-table-ref/default");
lf[27]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\000\376\377\016");
lf[28]=C_h_intern(&lf[28],15,"make-hash-table");
lf[29]=C_h_intern(&lf[29],3,"eq\077");
lf[31]=C_h_intern(&lf[31],13,"string-append");
lf[32]=C_h_intern(&lf[32],11,"make-string");
lf[33]=C_h_intern(&lf[33],9,"\003syserror");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_h_intern(&lf[38],9,"substring");
lf[39]=C_h_intern(&lf[39],8,"truncate");
lf[40]=C_h_intern(&lf[40],4,"expt");
lf[41]=C_h_intern(&lf[41],25,"\003sysimplicit-exit-handler");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\011procedure");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005calls");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\007seconds");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\007average");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\007percent");
lf[47]=C_h_intern(&lf[47],5,"print");
lf[48]=C_h_intern(&lf[48],11,"string-join");
lf[49]=C_h_intern(&lf[49],12,"\003sysfor-each");
lf[50]=C_h_intern(&lf[50],6,"reduce");
lf[51]=C_h_intern(&lf[51],1,"+");
lf[52]=C_h_intern(&lf[52],3,"max");
lf[53]=C_h_intern(&lf[53],7,"\003sysmap");
lf[54]=C_h_intern(&lf[54],13,"string-length");
lf[55]=C_h_intern(&lf[55],4,"fold");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\010overflow");
lf[57]=C_h_intern(&lf[57],28,"\003syssymbol->qualified-string");
lf[58]=C_h_intern(&lf[58],6,"remove");
lf[59]=C_h_intern(&lf[59],4,"take");
lf[60]=C_h_intern(&lf[60],4,"sort");
lf[61]=C_h_intern(&lf[61],6,"append");
lf[62]=C_h_intern(&lf[62],20,"with-input-from-file");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\011reading `");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\006\047 ...\012");
lf[65]=C_h_intern(&lf[65],5,"error");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\021no PROFILEs found");
lf[67]=C_h_intern(&lf[67],22,"file-modification-time");
lf[68]=C_h_intern(&lf[68],4,"glob");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\011PROFILE.*");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\032missing argument to option");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid argument to option");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\032chicken-profile - Version ");
lf[73]=C_h_intern(&lf[73],15,"chicken-version");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\012-no-unused");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\004-top");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\016-sort-by-calls");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-time");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\014-sort-by-avg");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-name");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\011-decimals");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[91]=C_h_intern(&lf[91],22,"command-line-arguments");
C_register_lf2(lf,92,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_163,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k161 */
static void C_ccall f_163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_166,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k164 in k161 */
static void C_ccall f_166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_169,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k167 in k164 in k161 */
static void C_ccall f_169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_172,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k170 in k167 in k164 in k161 */
static void C_ccall f_172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_175,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_178,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_181,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_184,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_187,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_190,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_190,2,t0,t1);}
t2=lf[0]=C_SCHEME_FALSE;;
t3=lf[1]=C_SCHEME_FALSE;;
t4=lf[2]=C_SCHEME_FALSE;;
t5=lf[3]=C_fix(3);;
t6=lf[4]=C_fix(3);;
t7=lf[5]=C_fix(3);;
t8=lf[6]=C_fix(0);;
t9=C_mutate(&lf[7],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_199,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[15],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_511,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[16],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_546,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[17],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_575,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[18],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_604,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[0],lf[16]);
t15=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_688,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[30],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_755,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[35],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_835,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1144,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1154,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 234  command-line-arguments */
t20=C_retrieve(lf[91]);
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}

/* k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1154,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_246,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_246(t5,((C_word*)t0)[2],t1);}

/* loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_246(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[41],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_246,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_256,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(lf[1])){
t4=t3;
f_256(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_263,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 73   glob */
t5=C_retrieve(lf[68]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[69]);}}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_301,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_320,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_341,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_353,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_360,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_equalp(t3,lf[74]))){
/* g1129 */
f_353(t11);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[75]))){
/* g1129 */
f_353(t11);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[76]))){
/* g1129 */
f_353(t11);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[77]))){
/* g1228 */
f_341(t11);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[78]))){
/* g1228 */
f_341(t11);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[79]))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_414,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_421,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 98   chicken-version */
t14=C_retrieve(lf[73]);
((C_proc2)C_retrieve_proc(t14))(2,t14,t13);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[80]))){
t12=lf[2]=C_SCHEME_TRUE;;
t13=t11;
f_360(2,t13,t12);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[81]))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_438,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* next-number24 */
t13=t8;
f_320(t13,t12);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[82]))){
t12=C_mutate(&lf[0],lf[15]);
t13=t11;
f_360(2,t13,t12);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[83]))){
t12=C_mutate(&lf[0],lf[16]);
t13=t11;
f_360(2,t13,t12);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[84]))){
t12=C_mutate(&lf[0],lf[17]);
t13=t11;
f_360(2,t13,t12);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[85]))){
t12=C_mutate(&lf[0],lf[18]);
t13=t11;
f_360(2,t13,t12);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[86]))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_479,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* next-arg23 */
t13=t7;
f_301(t13,t12);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_485,a[2]=t3,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_i_string_length(t3);
if(C_truep((C_word)C_i_greaterp(t13,C_fix(1)))){
t14=(C_word)C_i_string_ref(t3,C_fix(0));
t15=t12;
f_485(t15,(C_word)C_eqp(C_make_character(45),t14));}
else{
t14=t12;
f_485(t14,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}

/* k483 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_485(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[90],((C_word*)t0)[2]);}
else{
if(C_truep(lf[1])){
/* print-usage */
f_199(((C_word*)t0)[3]);}
else{
t2=C_mutate(&lf[1],((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_360(2,t3,t2);}}}

/* k477 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_479,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_nequalp(t2,C_fix(3)))){
t3=C_mutate(&lf[87],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_636,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_671,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 148  arg-digit */
t5=C_retrieve2(lf[87],"arg-digit");
f_636(t5,t4,C_fix(0));}
else{
/* chicken-profile.scm: 151  error */
t3=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[89],t1);}}

/* k669 in k477 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_671,2,t0,t1);}
t2=C_mutate(&lf[3],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_675,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 149  arg-digit */
t4=C_retrieve2(lf[87],"arg-digit");
f_636(t4,t3,C_fix(1));}

/* k673 in k669 in k477 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_675,2,t0,t1);}
t2=C_mutate(&lf[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 150  arg-digit */
t4=C_retrieve2(lf[87],"arg-digit");
f_636(t4,t3,C_fix(2));}

/* k677 in k673 in k669 in k477 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[5],t1);
t3=((C_word*)t0)[2];
f_360(2,t3,t2);}

/* arg-digit in k477 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_636(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_636,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(48));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_646,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 145  <= */
C_less_or_equal_p(5,0,t6,C_fix(0),t5,C_fix(9));}

/* k644 in arg-digit in k477 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_nequalp(((C_word*)t0)[4],C_fix(9));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_fix(8):((C_word*)t0)[4]));}
else{
/* chicken-profile.scm: 147  error */
t2=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[88],((C_word*)t0)[2]);}}

/* k436 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[6],t1);
t3=((C_word*)t0)[2];
f_360(2,t3,t2);}

/* k419 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 98   print */
t2=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k412 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 99   exit */
t2=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k358 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 111  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_246(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* g11 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_353(C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_353,NULL,1,t1);}
/* chicken-profile.scm: 93   print-usage */
f_199(t1);}

/* g12 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_341(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_341,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_345,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_352,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 95   chicken-version */
t4=C_retrieve(lf[73]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k350 in g12 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 95   print */
t2=*((C_word*)lf[47]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[72],t1);}

/* k343 in g12 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 96   exit */
t2=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* next-number in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_320,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_324,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_340,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 90   next-arg */
t4=((C_word*)t0)[2];
f_301(t4,t3);}

/* k338 in next-number in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 90   string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k322 in next-number in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_greaterp(t1,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* chicken-profile.scm: 91   error */
t3=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],lf[71],((C_word*)t0)[2]);}}

/* next-arg in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_301,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* chicken-profile.scm: 85   error */
t2=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[70],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k261 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_266,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-profile.scm: 75   error */
t3=*((C_word*)lf[65]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[66]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_279,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_281,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 76   sort */
t5=C_retrieve(lf[60]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t1,t4);}}

/* a280 in k261 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_281,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_289,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 78   file-modification-time */
t5=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k287 in a280 in k261 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_293,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 79   file-modification-time */
t3=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k291 in k287 in a280 in k261 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_greaterp(((C_word*)t0)[2],t1));}

/* k277 in k261 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_266(2,t2,(C_word)C_i_car(t1));}

/* k264 in k261 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[1],t1);
t3=((C_word*)t0)[2];
f_256(t3,t2);}

/* k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_256(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_256,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_895,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 184  print */
t4=*((C_word*)lf[47]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[63],lf[1],lf[64]);}

/* k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_898,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 185  with-input-from-file */
t3=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[1],lf[21]);}

/* k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_901,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1133,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 186  fold */
t4=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,C_fix(0),t1);}

/* a1132 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1133,4,t0,t1,t2,t3);}
t4=(C_word)C_i_caddr(t2);
/* chicken-profile.scm: 187  max */
t5=*((C_word*)lf[52]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_904,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1082,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1084,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1083 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1084,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_caddr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1102,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_greaterp(t3,C_fix(0));
t7=t5;
f_1102(t7,(C_truep(t6)?(C_word)C_a_i_divide(&a,2,t4,t3):C_SCHEME_FALSE));}
else{
t6=t5;
f_1102(t6,C_SCHEME_FALSE);}}

/* k1100 in a1083 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_1102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1102,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1109,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
t4=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t5=t3;
f_1109(t5,(C_word)C_a_i_times(&a,2,t4,C_fix(100)));}
else{
t4=t3;
f_1109(t4,C_SCHEME_FALSE);}}

/* k1107 in k1100 in a1083 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_1109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1109,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t2);
/* chicken-profile.scm: 191  append */
t4=*((C_word*)lf[61]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1080 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 190  sort */
t2=C_retrieve(lf[60]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[0]);}

/* k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_904,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_907,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1070,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_length(((C_word*)t3)[1]);
/* chicken-profile.scm: 200  < */
C_lessp(5,0,t5,C_fix(0),lf[6],t6);}

/* k1068 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1070,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 201  take */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],lf[6]);}
else{
t2=((C_word*)t0)[2];
f_907(t2,C_SCHEME_UNDEFINED);}}

/* k1072 in k1068 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_907(t3,t2);}

/* k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_907,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_990,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1048,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1050,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 212  remove */
t6=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)((C_word*)t0)[3])[1]);}

/* a1049 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1050,3,t0,t1,t2);}
if(C_truep((C_word)C_i_cadr(t2))){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_zerop(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[2]:C_SCHEME_FALSE));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1046 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a989 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_990(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_990,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_caddr(t2);
t5=(C_word)C_i_cadddr(t2);
t6=(C_word)C_i_list_ref(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1010,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
/* chicken-profile.scm: 207  ##sys#symbol->qualified-string */
t9=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}

/* k1008 in a989 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
/* chicken-profile.scm: 208  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1014(2,t3,lf[56]);}}

/* k1012 in k1008 in a989 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm: 209  format-real */
f_835(t2,t3,lf[3]);}

/* k1016 in k1012 in k1008 in a989 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm: 210  format-real */
f_835(t2,t3,lf[4]);}

/* k1020 in k1016 in k1012 in k1008 in a989 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1026,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm: 211  format-real */
f_835(t2,((C_word*)t0)[2],lf[5]);}

/* k1024 in k1020 in k1016 in k1012 in k1008 in a989 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1026,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k909 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_911,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_a_i_list(&a,5,lf[42],lf[43],lf[44],lf[45],lf[46]);
t4=(C_word)C_a_i_list(&a,5,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_920,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 220  make-string */
t6=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_fix(2),C_make_character(32));}

/* k918 in k909 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_972,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_a_i_list(&a,5,C_fix(0),C_fix(0),C_fix(0),C_fix(0),C_fix(0));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
/* chicken-profile.scm: 221  fold */
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t4,t5);}

/* a971 in k918 in k909 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_972,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_980,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[54]+1),t2);}

/* k978 in a971 in k918 in k909 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 223  map */
t2=*((C_word*)lf[25]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[52]+1),t1,((C_word*)t0)[2]);}

/* k921 in k918 in k909 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_925,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_940,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm: 228  print-row */
t4=t2;
f_925(3,t4,t3,((C_word*)t0)[2]);}

/* k938 in k921 in k918 in k909 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_943,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_950,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_958,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 229  reduce */
t5=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[51]+1),C_fix(0),((C_word*)t0)[2]);}

/* k956 in k938 in k921 in k918 in k909 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_958,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t4=(C_word)C_a_i_times(&a,2,C_fix(2),t3);
t5=(C_word)C_a_i_plus(&a,2,t1,t4);
/* chicken-profile.scm: 229  make-string */
t6=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],t5,C_make_character(45));}

/* k948 in k938 in k921 in k918 in k909 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 229  print */
t2=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k941 in k938 in k921 in k918 in k909 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* print-row in k921 in k918 in k909 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_925,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_933,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_937,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 227  map */
t5=*((C_word*)lf[25]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[30],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k935 in print-row in k921 in k918 in k909 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 227  string-join */
t2=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k931 in print-row in k921 in k918 in k909 in k905 in k902 in k899 in k896 in k893 in k254 in loop in k1152 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 227  print */
t2=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1142 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1147,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1150,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[41]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1148 in k1142 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1145 in k1142 in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format-real in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_835(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_835,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_889,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 172  truncate */
t5=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k887 in format-real in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_889,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_846,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 174  number->string */
C_number_to_string(3,0,t3,t2);}

/* k844 in k887 in format-real in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_846,2,t0,t1);}
t2=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(0));
t3=(C_truep(t2)?lf[36]:lf[37]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_854,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_858,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_870,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_878,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 180  - */
C_minus(5,0,t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(-1));}

/* k876 in k844 in k887 in format-real in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_882,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 180  expt */
t3=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(10),((C_word*)t0)[2]);}

/* k880 in k876 in k844 in k887 in format-real in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_882,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],t1);
/* chicken-profile.scm: 179  truncate */
t3=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k868 in k844 in k887 in format-real in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(t1);
/* chicken-profile.scm: 177  number->string */
C_number_to_string(3,0,((C_word*)t0)[2],t2);}

/* k856 in k844 in k887 in format-real in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_858,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* chicken-profile.scm: 176  substring */
t3=*((C_word*)lf[38]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,C_fix(1),t2);}

/* k852 in k844 in k887 in format-real in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 173  string-append */
t2=*((C_word*)lf[31]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* format-string in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_755r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_755r(t0,t1,t2,t3,t4);}}

static void C_ccall f_755r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_757,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_782,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_787,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-right7383 */
t8=t7;
f_787(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-padc7481 */
t10=t6;
f_782(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body7176 */
t12=t5;
f_757(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[34],t11);}}}}

/* def-right73 in format-string in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_787(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_787,NULL,2,t0,t1);}
/* def-padc7481 */
t2=((C_word*)t0)[2];
f_782(t2,t1,C_SCHEME_FALSE);}

/* def-padc74 in format-string in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_782(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_782,NULL,3,t0,t1,t2);}
/* body7176 */
t3=((C_word*)t0)[2];
f_757(t3,t1,t2,C_make_character(32));}

/* body71 in format-string in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_757(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_757,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_764,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[2],t4);
t7=(C_word)C_i_fixnum_max(C_fix(0),t6);
/* chicken-profile.scm: 166  make-string */
t8=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t7,t3);}

/* k762 in body71 in format-string in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* chicken-profile.scm: 168  string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* chicken-profile.scm: 169  string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

/* read-profile in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_692,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 154  make-hash-table */
t3=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,*((C_word*)lf[29]+1));}

/* k690 in read-profile in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_695,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_702,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 155  read */
t4=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k700 in k690 in read-profile in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_702,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_704,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_704(t5,((C_word*)t0)[2],t1);}

/* do57 in k700 in k690 in read-profile in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_704(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_704,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_714,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_729,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_731,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_745,a[2]=t6,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_car(t2);
/* chicken-profile.scm: 160  hash-table-ref/default */
t9=C_retrieve(lf[26]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,((C_word*)t0)[2],t8,lf[27]);}}

/* k743 in do57 in k700 in k690 in read-profile in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-profile.scm: 159  map */
t3=*((C_word*)lf[25]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* a730 in do57 in k700 in k690 in read-profile in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_731,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t2)?(C_truep(t3)?(C_word)C_a_i_plus(&a,2,t2,t3):C_SCHEME_FALSE):C_SCHEME_FALSE));}

/* k727 in do57 in k700 in k690 in read-profile in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 157  hash-table-set! */
t2=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k712 in do57 in k700 in k690 in read-profile in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 155  read */
t3=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k719 in k712 in do57 in k700 in k690 in read-profile in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_704(t2,((C_word*)t0)[2],t1);}

/* k693 in k690 in read-profile in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 162  hash-table->alist */
t2=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* sort-by-name in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_604,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_612,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-profile.scm: 135  symbol->string */
t6=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k610 in sort-by-name in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_616,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-profile.scm: 135  symbol->string */
t4=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k614 in k610 in sort-by-name in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 135  string<? */
t2=*((C_word*)lf[19]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sort-by-avg in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_575,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadddr(t2);
t5=(C_word)C_i_cadddr(t3);
if(C_truep((C_word)C_i_eqvp(t4,t5))){
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_greaterp(t4,t5));}}

/* sort-by-time in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_546,4,t0,t1,t2,t3);}
t4=(C_word)C_i_caddr(t2);
t5=(C_word)C_i_caddr(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_i_cadr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_greaterp(t4,t5));}}

/* sort-by-calls in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_511,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_cadr(t3);
if(C_truep((C_word)C_i_eqvp(t4,t5))){
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t4)?(C_truep(t5)?(C_word)C_i_greaterp(t4,t5):C_SCHEME_TRUE):C_SCHEME_TRUE));}}

/* print-usage in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_fcall f_199(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_199,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_203,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_210,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[10],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[5],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[11],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[4],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[12],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[3],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[13],t9);
/* chicken-profile.scm: 44   ##sys#print-to-string */
t11=C_retrieve(lf[14]);
((C_proc3)C_retrieve_proc(t11))(3,t11,t3,t10);}

/* k208 in print-usage in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 45   display */
t2=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k201 in print-usage in k188 in k185 in k182 in k179 in k176 in k173 in k170 in k167 in k164 in k161 */
static void C_ccall f_203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 65   exit */
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[107] = {
{"toplevelchicken-profile.scm",(void*)C_toplevel},
{"f_163chicken-profile.scm",(void*)f_163},
{"f_166chicken-profile.scm",(void*)f_166},
{"f_169chicken-profile.scm",(void*)f_169},
{"f_172chicken-profile.scm",(void*)f_172},
{"f_175chicken-profile.scm",(void*)f_175},
{"f_178chicken-profile.scm",(void*)f_178},
{"f_181chicken-profile.scm",(void*)f_181},
{"f_184chicken-profile.scm",(void*)f_184},
{"f_187chicken-profile.scm",(void*)f_187},
{"f_190chicken-profile.scm",(void*)f_190},
{"f_1154chicken-profile.scm",(void*)f_1154},
{"f_246chicken-profile.scm",(void*)f_246},
{"f_485chicken-profile.scm",(void*)f_485},
{"f_479chicken-profile.scm",(void*)f_479},
{"f_671chicken-profile.scm",(void*)f_671},
{"f_675chicken-profile.scm",(void*)f_675},
{"f_679chicken-profile.scm",(void*)f_679},
{"f_636chicken-profile.scm",(void*)f_636},
{"f_646chicken-profile.scm",(void*)f_646},
{"f_438chicken-profile.scm",(void*)f_438},
{"f_421chicken-profile.scm",(void*)f_421},
{"f_414chicken-profile.scm",(void*)f_414},
{"f_360chicken-profile.scm",(void*)f_360},
{"f_353chicken-profile.scm",(void*)f_353},
{"f_341chicken-profile.scm",(void*)f_341},
{"f_352chicken-profile.scm",(void*)f_352},
{"f_345chicken-profile.scm",(void*)f_345},
{"f_320chicken-profile.scm",(void*)f_320},
{"f_340chicken-profile.scm",(void*)f_340},
{"f_324chicken-profile.scm",(void*)f_324},
{"f_301chicken-profile.scm",(void*)f_301},
{"f_263chicken-profile.scm",(void*)f_263},
{"f_281chicken-profile.scm",(void*)f_281},
{"f_289chicken-profile.scm",(void*)f_289},
{"f_293chicken-profile.scm",(void*)f_293},
{"f_279chicken-profile.scm",(void*)f_279},
{"f_266chicken-profile.scm",(void*)f_266},
{"f_256chicken-profile.scm",(void*)f_256},
{"f_895chicken-profile.scm",(void*)f_895},
{"f_898chicken-profile.scm",(void*)f_898},
{"f_1133chicken-profile.scm",(void*)f_1133},
{"f_901chicken-profile.scm",(void*)f_901},
{"f_1084chicken-profile.scm",(void*)f_1084},
{"f_1102chicken-profile.scm",(void*)f_1102},
{"f_1109chicken-profile.scm",(void*)f_1109},
{"f_1082chicken-profile.scm",(void*)f_1082},
{"f_904chicken-profile.scm",(void*)f_904},
{"f_1070chicken-profile.scm",(void*)f_1070},
{"f_1074chicken-profile.scm",(void*)f_1074},
{"f_907chicken-profile.scm",(void*)f_907},
{"f_1050chicken-profile.scm",(void*)f_1050},
{"f_1048chicken-profile.scm",(void*)f_1048},
{"f_990chicken-profile.scm",(void*)f_990},
{"f_1010chicken-profile.scm",(void*)f_1010},
{"f_1014chicken-profile.scm",(void*)f_1014},
{"f_1018chicken-profile.scm",(void*)f_1018},
{"f_1022chicken-profile.scm",(void*)f_1022},
{"f_1026chicken-profile.scm",(void*)f_1026},
{"f_911chicken-profile.scm",(void*)f_911},
{"f_920chicken-profile.scm",(void*)f_920},
{"f_972chicken-profile.scm",(void*)f_972},
{"f_980chicken-profile.scm",(void*)f_980},
{"f_923chicken-profile.scm",(void*)f_923},
{"f_940chicken-profile.scm",(void*)f_940},
{"f_958chicken-profile.scm",(void*)f_958},
{"f_950chicken-profile.scm",(void*)f_950},
{"f_943chicken-profile.scm",(void*)f_943},
{"f_925chicken-profile.scm",(void*)f_925},
{"f_937chicken-profile.scm",(void*)f_937},
{"f_933chicken-profile.scm",(void*)f_933},
{"f_1144chicken-profile.scm",(void*)f_1144},
{"f_1150chicken-profile.scm",(void*)f_1150},
{"f_1147chicken-profile.scm",(void*)f_1147},
{"f_835chicken-profile.scm",(void*)f_835},
{"f_889chicken-profile.scm",(void*)f_889},
{"f_846chicken-profile.scm",(void*)f_846},
{"f_878chicken-profile.scm",(void*)f_878},
{"f_882chicken-profile.scm",(void*)f_882},
{"f_870chicken-profile.scm",(void*)f_870},
{"f_858chicken-profile.scm",(void*)f_858},
{"f_854chicken-profile.scm",(void*)f_854},
{"f_755chicken-profile.scm",(void*)f_755},
{"f_787chicken-profile.scm",(void*)f_787},
{"f_782chicken-profile.scm",(void*)f_782},
{"f_757chicken-profile.scm",(void*)f_757},
{"f_764chicken-profile.scm",(void*)f_764},
{"f_688chicken-profile.scm",(void*)f_688},
{"f_692chicken-profile.scm",(void*)f_692},
{"f_702chicken-profile.scm",(void*)f_702},
{"f_704chicken-profile.scm",(void*)f_704},
{"f_745chicken-profile.scm",(void*)f_745},
{"f_731chicken-profile.scm",(void*)f_731},
{"f_729chicken-profile.scm",(void*)f_729},
{"f_714chicken-profile.scm",(void*)f_714},
{"f_721chicken-profile.scm",(void*)f_721},
{"f_695chicken-profile.scm",(void*)f_695},
{"f_604chicken-profile.scm",(void*)f_604},
{"f_612chicken-profile.scm",(void*)f_612},
{"f_616chicken-profile.scm",(void*)f_616},
{"f_575chicken-profile.scm",(void*)f_575},
{"f_546chicken-profile.scm",(void*)f_546},
{"f_511chicken-profile.scm",(void*)f_511},
{"f_199chicken-profile.scm",(void*)f_199},
{"f_210chicken-profile.scm",(void*)f_210},
{"f_203chicken-profile.scm",(void*)f_203},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
