/* Generated from eval.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-06-28 11:49
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10664	compiled 2008-06-28 on galinha (Linux)
   command line: eval.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file ueval.c
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_EGG_HOME
# define C_INSTALL_EGG_HOME    "."
#endif

#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif


#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[524];
static double C_possibly_force_alignment;


/* from ##sys#clear-trace-buffer in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static C_word C_fcall stub1365(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1365(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_clear_trace_buffer();
return C_r;}

C_noret_decl(C_eval_toplevel)
C_externexport void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11465)
static void C_ccall f_11465(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11465)
static void C_ccall f_11465r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11469)
static void C_fcall f_11469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11493)
static void C_ccall f_11493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11487)
static void C_ccall f_11487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11477)
static void C_ccall f_11477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11475)
static void C_ccall f_11475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6079)
static void C_ccall f_6079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6258)
static void C_ccall f_6258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11459)
static void C_ccall f_11459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11455)
static void C_ccall f_11455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11451)
static void C_ccall f_11451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11447)
static void C_ccall f_11447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11437)
static void C_fcall f_11437(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6777)
static void C_fcall f_6777(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11415)
static void C_ccall f_11415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11407)
static void C_ccall f_11407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11409)
static void C_ccall f_11409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11376)
static void C_ccall f_11376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11396)
static void C_ccall f_11396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11392)
static void C_ccall f_11392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11382)
static void C_ccall f_11382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11379)
static void C_ccall f_11379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7142)
static void C_ccall f_7142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11322)
static void C_ccall f_11322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11336)
static void C_fcall f_11336(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11372)
static void C_ccall f_11372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11368)
static void C_ccall f_11368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11356)
static void C_ccall f_11356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11360)
static void C_ccall f_11360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11330)
static void C_ccall f_11330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7861)
static void C_ccall f_7861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11201)
static void C_ccall f_11201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11238)
static void C_fcall f_11238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11247)
static void C_ccall f_11247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11266)
static void C_ccall f_11266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11270)
static void C_ccall f_11270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11256)
static void C_ccall f_11256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11253)
static void C_ccall f_11253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11204)
static void C_fcall f_11204(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7864)
static void C_ccall f_7864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7922)
static void C_ccall f_7922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11199)
static void C_ccall f_11199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8257)
static void C_ccall f_8257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8261)
static void C_ccall f_8261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11195)
static void C_ccall f_11195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8264)
static void C_ccall f_8264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8268)
static void C_ccall f_8268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11098)
static void C_ccall f_11098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11104)
static void C_fcall f_11104(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11120)
static void C_ccall f_11120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11123)
static void C_ccall f_11123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11158)
static void C_ccall f_11158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11161)
static void C_ccall f_11161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11145)
static void C_ccall f_11145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11148)
static void C_ccall f_11148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11155)
static void C_ccall f_11155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8951)
static void C_ccall f_8951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11070)
static void C_ccall f_11070(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8954)
static void C_ccall f_8954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11027)
static void C_ccall f_11027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11049)
static void C_ccall f_11049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8957)
static void C_ccall f_8957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10830)
static void C_ccall f_10830(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10836)
static void C_fcall f_10836(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10852)
static void C_ccall f_10852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10928)
static void C_fcall f_10928(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10985)
static void C_ccall f_10985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10931)
static void C_ccall f_10931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10958)
static void C_ccall f_10958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10891)
static void C_ccall f_10891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10910)
static void C_ccall f_10910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10882)
static void C_ccall f_10882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8960)
static void C_ccall f_8960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10727)
static void C_ccall f_10727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10737)
static void C_ccall f_10737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10750)
static void C_fcall f_10750(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10766)
static void C_ccall f_10766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10804)
static void C_ccall f_10804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10802)
static void C_ccall f_10802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10794)
static void C_ccall f_10794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10748)
static void C_ccall f_10748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8963)
static void C_ccall f_8963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10674)
static void C_ccall f_10674(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10684)
static void C_ccall f_10684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10687)
static void C_ccall f_10687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10692)
static void C_fcall f_10692(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10717)
static void C_ccall f_10717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8966)
static void C_ccall f_8966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10604)
static void C_ccall f_10604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10614)
static void C_ccall f_10614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10617)
static void C_ccall f_10617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10664)
static void C_ccall f_10664(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10628)
static void C_ccall f_10628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10650)
static void C_ccall f_10650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10636)
static void C_ccall f_10636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10632)
static void C_ccall f_10632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8969)
static void C_ccall f_8969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10485)
static void C_ccall f_10485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10485)
static void C_ccall f_10485r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10489)
static void C_ccall f_10489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10492)
static void C_ccall f_10492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10495)
static void C_ccall f_10495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10586)
static void C_ccall f_10586(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10502)
static void C_ccall f_10502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10525)
static void C_fcall f_10525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10539)
static void C_ccall f_10539(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10537)
static void C_ccall f_10537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8972)
static void C_ccall f_8972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10193)
static void C_ccall f_10193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10403)
static void C_fcall f_10403(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10407)
static void C_ccall f_10407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10428)
static void C_ccall f_10428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10470)
static void C_ccall f_10470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10206)
static void C_fcall f_10206(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10394)
static void C_ccall f_10394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10398)
static void C_ccall f_10398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10377)
static void C_ccall f_10377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10381)
static void C_ccall f_10381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10366)
static void C_ccall f_10366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10358)
static void C_ccall f_10358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10347)
static void C_ccall f_10347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10313)
static void C_ccall f_10313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10294)
static void C_ccall f_10294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10267)
static void C_ccall f_10267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10224)
static void C_ccall f_10224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10220)
static void C_ccall f_10220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10196)
static void C_fcall f_10196(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10204)
static void C_ccall f_10204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8975)
static void C_ccall f_8975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10183)
static void C_ccall f_10183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8978)
static void C_ccall f_8978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9937)
static void C_ccall f_9937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10092)
static void C_fcall f_10092(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10163)
static void C_ccall f_10163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10108)
static void C_ccall f_10108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10106)
static void C_ccall f_10106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9950)
static void C_fcall f_9950(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10076)
static void C_ccall f_10076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10038)
static void C_ccall f_10038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9999)
static void C_ccall f_9999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9940)
static void C_fcall f_9940(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8981)
static void C_ccall f_8981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8985)
static void C_ccall f_8985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9934)
static void C_ccall f_9934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9007)
static void C_ccall f_9007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9367)
static void C_ccall f_9367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9792)
static void C_ccall f_9792(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9792)
static void C_ccall f_9792r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9910)
static void C_ccall f_9910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9913)
static void C_ccall f_9913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9900)
static void C_ccall f_9900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9795)
static void C_fcall f_9795(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9799)
static void C_fcall f_9799(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9810)
static void C_fcall f_9810(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9453)
static void C_ccall f_9453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9773)
static void C_ccall f_9773(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9773)
static void C_ccall f_9773r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9777)
static void C_ccall f_9777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9786)
static void C_ccall f_9786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9784)
static void C_ccall f_9784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9456)
static void C_ccall f_9456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9767)
static void C_ccall f_9767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9459)
static void C_ccall f_9459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9761)
static void C_ccall f_9761(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9462)
static void C_ccall f_9462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9752)
static void C_ccall f_9752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9759)
static void C_ccall f_9759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9742)
static void C_ccall f_9742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9727)
static void C_ccall f_9727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9731)
static void C_ccall f_9731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9736)
static void C_ccall f_9736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9740)
static void C_ccall f_9740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9705)
static void C_ccall f_9705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9709)
static void C_ccall f_9709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9714)
static void C_ccall f_9714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9718)
static void C_ccall f_9718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9725)
static void C_ccall f_9725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9679)
static void C_ccall f_9679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9685)
static void C_ccall f_9685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9689)
static void C_ccall f_9689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9703)
static void C_ccall f_9703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9692)
static void C_ccall f_9692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9699)
static void C_ccall f_9699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9663)
static void C_ccall f_9663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9669)
static void C_ccall f_9669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9677)
static void C_ccall f_9677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9626)
static void C_ccall f_9626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9630)
static void C_ccall f_9630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9635)
static void C_ccall f_9635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9639)
static void C_ccall f_9639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9661)
static void C_ccall f_9661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9657)
static void C_ccall f_9657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9653)
static void C_ccall f_9653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9642)
static void C_ccall f_9642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9649)
static void C_ccall f_9649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9600)
static void C_ccall f_9600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9606)
static void C_ccall f_9606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9610)
static void C_ccall f_9610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9624)
static void C_ccall f_9624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9613)
static void C_ccall f_9613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9620)
static void C_ccall f_9620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9587)
static C_word C_fcall f_9587(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9561)
static void C_ccall f_9561(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9565)
static void C_ccall f_9565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9570)
static void C_ccall f_9570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9574)
static void C_ccall f_9574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9585)
static void C_ccall f_9585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9581)
static void C_ccall f_9581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9545)
static void C_ccall f_9545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9551)
static void C_ccall f_9551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9559)
static void C_ccall f_9559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9533)
static void C_ccall f_9533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9539)
static void C_ccall f_9539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9543)
static void C_ccall f_9543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9524)
static void C_fcall f_9524(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9528)
static void C_ccall f_9528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9465)
static void C_fcall f_9465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9475)
static void C_ccall f_9475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9500)
static void C_ccall f_9500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9512)
static void C_ccall f_9512(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9512)
static void C_ccall f_9512r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9518)
static void C_ccall f_9518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9506)
static void C_ccall f_9506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9481)
static void C_ccall f_9481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9487)
static void C_ccall f_9487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9491)
static void C_ccall f_9491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9494)
static void C_ccall f_9494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9498)
static void C_ccall f_9498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9473)
static void C_ccall f_9473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9378)
static void C_ccall f_9378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9388)
static void C_ccall f_9388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9391)
static void C_ccall f_9391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9405)
static void C_fcall f_9405(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9423)
static void C_ccall f_9423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9392)
static void C_fcall f_9392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9369)
static void C_ccall f_9369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9028)
static void C_ccall f_9028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9072)
static void C_ccall f_9072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9075)
static void C_ccall f_9075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9352)
static void C_ccall f_9352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9356)
static void C_ccall f_9356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9360)
static void C_ccall f_9360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9157)
static void C_ccall f_9157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9163)
static void C_fcall f_9163(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9335)
static void C_ccall f_9335(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9341)
static void C_ccall f_9341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9170)
static void C_ccall f_9170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9173)
static void C_ccall f_9173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9330)
static void C_ccall f_9330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9185)
static void C_ccall f_9185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9188)
static void C_ccall f_9188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9203)
static void C_ccall f_9203(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9203)
static void C_ccall f_9203r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9221)
static void C_fcall f_9221(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9284)
static void C_ccall f_9284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9237)
static void C_ccall f_9237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9242)
static void C_ccall f_9242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9246)
static void C_ccall f_9246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9249)
static void C_ccall f_9249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9261)
static void C_ccall f_9261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9264)
static void C_ccall f_9264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9252)
static void C_ccall f_9252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9225)
static void C_ccall f_9225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9207)
static void C_ccall f_9207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9053)
static void C_fcall f_9053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9058)
static void C_ccall f_9058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9210)
static void C_ccall f_9210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9194)
static void C_ccall f_9194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9092)
static void C_ccall f_9092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9097)
static void C_ccall f_9097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9100)
static void C_ccall f_9100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9105)
static void C_ccall f_9105(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9105)
static void C_ccall f_9105r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9112)
static void C_ccall f_9112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9152)
static void C_ccall f_9152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9115)
static void C_ccall f_9115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9127)
static void C_fcall f_9127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9136)
static void C_ccall f_9136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9130)
static void C_ccall f_9130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9118)
static void C_ccall f_9118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9121)
static void C_ccall f_9121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9083)
static C_word C_fcall f_9083(C_word t0);
C_noret_decl(f_9077)
static C_word C_fcall f_9077(C_word t0);
C_noret_decl(f_9031)
static void C_fcall f_9031(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9037)
static void C_ccall f_9037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9025)
static void C_ccall f_9025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9009)
static void C_ccall f_9009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9023)
static void C_ccall f_9023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9020)
static void C_ccall f_9020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9013)
static void C_ccall f_9013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8990)
static void C_ccall f_8990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8994)
static void C_ccall f_8994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8559)
static void C_ccall f_8559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_8559)
static void C_ccall f_8559r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_8696)
static void C_fcall f_8696(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8701)
static void C_fcall f_8701(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8919)
static void C_ccall f_8919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8900)
static void C_ccall f_8900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8846)
static void C_ccall f_8846(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8717)
static void C_fcall f_8717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8722)
static void C_fcall f_8722(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8741)
static void C_ccall f_8741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8667)
static void C_ccall f_8667(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8673)
static C_word C_fcall f_8673(C_word t0);
C_noret_decl(f_8605)
static void C_ccall f_8605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8609)
static void C_ccall f_8609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8617)
static void C_fcall f_8617(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8640)
static void C_ccall f_8640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8562)
static void C_fcall f_8562(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8569)
static void C_ccall f_8569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8574)
static void C_fcall f_8574(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8578)
static void C_ccall f_8578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8603)
static void C_ccall f_8603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8592)
static void C_ccall f_8592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8596)
static void C_ccall f_8596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8585)
static void C_ccall f_8585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8523)
static void C_ccall f_8523(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8545)
static void C_ccall f_8545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8515)
static void C_ccall f_8515(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8515)
static void C_ccall f_8515r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8461)
static void C_ccall f_8461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8465)
static void C_ccall f_8465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8468)
static void C_ccall f_8468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8471)
static void C_ccall f_8471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8474)
static void C_ccall f_8474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8477)
static void C_ccall f_8477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8480)
static void C_ccall f_8480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8483)
static void C_ccall f_8483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8486)
static void C_ccall f_8486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8489)
static void C_ccall f_8489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8440)
static void C_fcall f_8440(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8444)
static void C_ccall f_8444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8447)
static void C_ccall f_8447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8416)
static void C_fcall f_8416(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8422)
static void C_fcall f_8422(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8432)
static void C_ccall f_8432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8293)
static void C_ccall f_8293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8293)
static void C_ccall f_8293r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8351)
static void C_ccall f_8351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8402)
static void C_ccall f_8402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8361)
static void C_ccall f_8361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8363)
static void C_fcall f_8363(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8387)
static void C_ccall f_8387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8373)
static void C_ccall f_8373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8334)
static void C_fcall f_8334(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8299)
static void C_fcall f_8299(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8321)
static void C_ccall f_8321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8312)
static void C_ccall f_8312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8274)
static void C_fcall f_8274(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8278)
static void C_ccall f_8278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8241)
static void C_fcall f_8241(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8243)
static void C_ccall f_8243(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8247)
static void C_ccall f_8247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8203)
static void C_ccall f_8203(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8203)
static void C_ccall f_8203r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8210)
static void C_ccall f_8210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8217)
static void C_ccall f_8217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8159)
static void C_ccall f_8159(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8159)
static void C_ccall f_8159r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8192)
static void C_ccall f_8192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8179)
static void C_ccall f_8179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8156)
static void C_ccall f_8156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8037)
static void C_ccall f_8037(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8037)
static void C_ccall f_8037r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8131)
static void C_ccall f_8131(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8141)
static void C_ccall f_8141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8129)
static void C_ccall f_8129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8058)
static void C_fcall f_8058(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8082)
static void C_fcall f_8082(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8101)
static void C_ccall f_8101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8076)
static void C_ccall f_8076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7929)
static void C_ccall f_7929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_7929)
static void C_ccall f_7929r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_7939)
static void C_ccall f_7939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7944)
static void C_fcall f_7944(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7971)
static void C_fcall f_7971(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8004)
static void C_ccall f_8004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7965)
static void C_ccall f_7965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7870)
static void C_ccall f_7870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7878)
static void C_fcall f_7878(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7898)
static void C_fcall f_7898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7822)
static void C_ccall f_7822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7423)
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7698)
static void C_fcall f_7698(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7707)
static void C_ccall f_7707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7733)
static void C_ccall f_7733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_fcall f_7735(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7768)
static void C_ccall f_7768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7758)
static void C_ccall f_7758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7753)
static void C_ccall f_7753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7447)
static void C_fcall f_7447(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7457)
static void C_ccall f_7457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7591)
static void C_ccall f_7591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7672)
static void C_ccall f_7672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7603)
static void C_ccall f_7603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7618)
static void C_fcall f_7618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7638)
static void C_ccall f_7638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7636)
static void C_ccall f_7636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7622)
static void C_fcall f_7622(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7614)
static void C_ccall f_7614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7551)
static void C_fcall f_7551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7559)
static void C_fcall f_7559(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7547)
static void C_ccall f_7547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7506)
static void C_fcall f_7506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7469)
static void C_ccall f_7469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7489)
static void C_ccall f_7489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7472)
static void C_fcall f_7472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7426)
static void C_fcall f_7426(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7441)
static void C_ccall f_7441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7435)
static void C_ccall f_7435(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7374)
static void C_ccall f_7374(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7380)
static void C_fcall f_7380(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7394)
static void C_ccall f_7394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7397)
static void C_fcall f_7397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7337)
static void C_ccall f_7337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7341)
static void C_ccall f_7341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7366)
static void C_ccall f_7366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7354)
static void C_ccall f_7354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7324)
static void C_ccall f_7324(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7324)
static void C_ccall f_7324r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7330)
static void C_ccall f_7330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7321)
static void C_ccall f_7321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7290)
static void C_ccall f_7290(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7290)
static void C_ccall f_7290r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7296)
static void C_ccall f_7296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7303)
static void C_ccall f_7303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7222)
static void C_ccall f_7222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7222)
static void C_ccall f_7222r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7285)
static void C_ccall f_7285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7226)
static void C_fcall f_7226(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7247)
static void C_ccall f_7247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7253)
static void C_ccall f_7253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7145)
static void C_ccall f_7145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7219)
static void C_ccall f_7219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7212)
static void C_ccall f_7212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7179)
static void C_ccall f_7179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7181)
static void C_fcall f_7181(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7194)
static void C_ccall f_7194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7148)
static void C_fcall f_7148(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7152)
static void C_ccall f_7152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7172)
static void C_ccall f_7172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7168)
static void C_ccall f_7168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7161)
static void C_ccall f_7161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6982)
static void C_ccall f_6982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7087)
static void C_fcall f_7087(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7104)
static void C_ccall f_7104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7004)
static void C_ccall f_7004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7009)
static void C_fcall f_7009(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7048)
static void C_ccall f_7048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6991)
static C_word C_fcall f_6991(C_word t0);
C_noret_decl(f_6985)
static void C_fcall f_6985(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6926)
static void C_ccall f_6926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6935)
static void C_fcall f_6935(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6953)
static void C_ccall f_6953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6904)
static void C_ccall f_6904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6791)
static void C_ccall f_6791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6795)
static void C_ccall f_6795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6887)
static void C_ccall f_6887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6891)
static void C_ccall f_6891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6804)
static void C_fcall f_6804(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6873)
static void C_ccall f_6873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6807)
static void C_ccall f_6807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6856)
static void C_ccall f_6856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6862)
static void C_ccall f_6862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6810)
static void C_ccall f_6810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6815)
static void C_fcall f_6815(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6828)
static void C_ccall f_6828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6831)
static void C_fcall f_6831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6772)
static void C_ccall f_6772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6769)
static void C_ccall f_6769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6766)
static void C_ccall f_6766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6723)
static void C_ccall f_6723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6693)
static void C_ccall f_6693(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6693)
static void C_ccall f_6693r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6648)
static void C_fcall f_6648(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6643)
static void C_fcall f_6643(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6308)
static void C_fcall f_6308(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6642)
static void C_ccall f_6642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6312)
static void C_fcall f_6312(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6576)
static void C_ccall f_6576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6591)
static void C_ccall f_6591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6594)
static void C_fcall f_6594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6597)
static void C_ccall f_6597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6603)
static void C_ccall f_6603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6606)
static void C_ccall f_6606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6612)
static void C_ccall f_6612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6567)
static void C_ccall f_6567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6558)
static void C_ccall f_6558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6543)
static void C_ccall f_6543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6515)
static void C_ccall f_6515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6502)
static void C_ccall f_6502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6360)
static void C_ccall f_6360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6376)
static void C_ccall f_6376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6472)
static void C_ccall f_6472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6379)
static void C_ccall f_6379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6382)
static void C_ccall f_6382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_fcall f_6387(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6397)
static void C_ccall f_6397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6443)
static void C_ccall f_6443(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6443)
static void C_ccall f_6443r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6456)
static void C_ccall f_6456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6409)
static void C_ccall f_6409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6427)
static void C_ccall f_6427(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6427)
static void C_ccall f_6427r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6400)
static void C_ccall f_6400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6369)
static void C_ccall f_6369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6337)
static void C_ccall f_6337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6260)
static void C_fcall f_6260(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6270)
static C_word C_fcall f_6270(C_word t0,C_word t1);
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6197)
static void C_fcall f_6197(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6210)
static void C_ccall f_6210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6180)
static void C_ccall f_6180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6109)
static void C_fcall f_6109(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6142)
static void C_ccall f_6142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6099)
static void C_fcall f_6099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6094)
static void C_ccall f_6094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5827)
static void C_fcall f_5827(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6032)
static void C_ccall f_6032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6036)
static void C_ccall f_6036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5977)
static void C_ccall f_5977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5983)
static void C_ccall f_5983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5987)
static void C_ccall f_5987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5998)
static void C_ccall f_5998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6002)
static void C_ccall f_6002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6006)
static void C_ccall f_6006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6010)
static void C_ccall f_6010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5938)
static void C_ccall f_5938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5942)
static void C_ccall f_5942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5953)
static void C_ccall f_5953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5900)
static void C_ccall f_5900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5903)
static void C_ccall f_5903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5904)
static void C_ccall f_5904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5915)
static void C_ccall f_5915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5922)
static void C_ccall f_5922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5887)
static void C_ccall f_5887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5853)
static void C_ccall f_5853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5801)
static C_word C_fcall f_5801(C_word t0,C_word t1);
C_noret_decl(f_4058)
static void C_fcall f_4058(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4217)
static void C_fcall f_4217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_fcall f_5621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5569)
static void C_ccall f_5569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5558)
static void C_ccall f_5558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5468)
static void C_fcall f_5468(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5490)
static void C_ccall f_5490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_fcall f_5420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5342)
static void C_ccall f_5342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5353)
static void C_ccall f_5353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5325)
static void C_ccall f_5325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_ccall f_5029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5317)
static void C_ccall f_5317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5755)
static void C_fcall f_5755(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5260)
static void C_ccall f_5260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_ccall f_5223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5129)
static void C_ccall f_5129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5135)
static void C_ccall f_5135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5135)
static void C_ccall f_5135r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5101)
static void C_ccall f_5101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_fcall f_4934(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4870)
static void C_ccall f_4870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4753)
static void C_ccall f_4753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4692)
static void C_ccall f_4692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4591)
static void C_ccall f_4591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4609)
static void C_ccall f_4609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4491)
static void C_ccall f_4491(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4495)
static void C_ccall f_4495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4343)
static void C_ccall f_4343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4301)
static void C_ccall f_4301(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4192)
static void C_ccall f_4192(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4120)
static void C_fcall f_4120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_fcall f_4115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_fcall f_4052(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4046)
static C_word C_fcall f_4046(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4040)
static C_word C_fcall f_4040(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3987)
static void C_fcall f_3987(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_fcall f_4006(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_fcall f_4015(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_fcall f_3875(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_fcall f_3833(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3839)
static void C_fcall f_3839(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3957)
static C_word C_fcall f_3957(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3810)
static void C_ccall f_3810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_fcall f_3735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3662)
static void C_fcall f_3662(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3678)
static void C_fcall f_3678(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3619)
static void C_fcall f_3619(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3550)
static void C_fcall f_3550(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3506)
static C_word C_fcall f_3506(C_word t0,C_word t1);
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_fcall f_3421(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3330)
static void C_fcall f_3330(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3282)
static void C_fcall f_3282(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_fcall f_3277(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2846)
static void C_fcall f_2846(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3029)
static void C_fcall f_3029(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3035)
static void C_fcall f_3035(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3086)
static void C_fcall f_3086(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3151)
static void C_ccall f_3151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_fcall f_2849(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_fcall f_2861(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2880)
static void C_fcall f_2880(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2347)
static void C_fcall f_2347(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2787)
static void C_fcall f_2787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_fcall f_2706(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_fcall f_2660(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_fcall f_2663(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_fcall f_2623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_fcall f_2591(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_fcall f_2533(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_fcall f_2365(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_fcall f_2377(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_fcall f_2368(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_fcall f_2328(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2288)
static void C_fcall f_2288(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2307)
static void C_fcall f_2307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2239)
static void C_fcall f_2239(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2157)
static void C_fcall f_2157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_fcall f_1996(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_fcall f_2024(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_fcall f_1850(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_fcall f_1882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_fcall f_1899(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1918)
static void C_fcall f_1918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_fcall f_1879(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735r(C_word t0,C_word t1,C_word t3) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_9742,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))),*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9727,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9705,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9679,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9663,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9626,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9600,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9561,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9545,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x,s=0,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
return C_truep(C_callback_wrapper((void *)f_9533,0));}

C_noret_decl(trf_11469)
static void C_fcall trf_11469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11469(t0,t1);}

C_noret_decl(trf_11437)
static void C_fcall trf_11437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11437(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11437(t0,t1);}

C_noret_decl(trf_6777)
static void C_fcall trf_6777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6777(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6777(t0,t1);}

C_noret_decl(trf_11336)
static void C_fcall trf_11336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11336(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11336(t0,t1,t2);}

C_noret_decl(trf_11238)
static void C_fcall trf_11238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11238(t0,t1);}

C_noret_decl(trf_11204)
static void C_fcall trf_11204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11204(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11204(t0,t1);}

C_noret_decl(trf_11104)
static void C_fcall trf_11104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11104(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11104(t0,t1,t2);}

C_noret_decl(trf_10836)
static void C_fcall trf_10836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10836(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10836(t0,t1,t2);}

C_noret_decl(trf_10928)
static void C_fcall trf_10928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10928(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10928(t0,t1);}

C_noret_decl(trf_10750)
static void C_fcall trf_10750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10750(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10750(t0,t1,t2);}

C_noret_decl(trf_10692)
static void C_fcall trf_10692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10692(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10692(t0,t1,t2);}

C_noret_decl(trf_10525)
static void C_fcall trf_10525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10525(t0,t1);}

C_noret_decl(trf_10403)
static void C_fcall trf_10403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10403(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10403(t0,t1,t2);}

C_noret_decl(trf_10206)
static void C_fcall trf_10206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10206(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10206(t0,t1,t2,t3);}

C_noret_decl(trf_10196)
static void C_fcall trf_10196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10196(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10196(t0,t1,t2,t3);}

C_noret_decl(trf_10092)
static void C_fcall trf_10092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10092(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10092(t0,t1,t2);}

C_noret_decl(trf_9950)
static void C_fcall trf_9950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9950(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9950(t0,t1,t2);}

C_noret_decl(trf_9940)
static void C_fcall trf_9940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9940(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9940(t0,t1,t2);}

C_noret_decl(trf_9795)
static void C_fcall trf_9795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9795(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9795(t0,t1,t2);}

C_noret_decl(trf_9799)
static void C_fcall trf_9799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9799(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9799(t0,t1);}

C_noret_decl(trf_9810)
static void C_fcall trf_9810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9810(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9810(t0,t1);}

C_noret_decl(trf_9524)
static void C_fcall trf_9524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9524(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9524(t0,t1,t2);}

C_noret_decl(trf_9465)
static void C_fcall trf_9465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9465(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9465(t0,t1);}

C_noret_decl(trf_9405)
static void C_fcall trf_9405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9405(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9405(t0,t1);}

C_noret_decl(trf_9392)
static void C_fcall trf_9392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9392(t0,t1);}

C_noret_decl(trf_9163)
static void C_fcall trf_9163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9163(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9163(t0,t1);}

C_noret_decl(trf_9221)
static void C_fcall trf_9221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9221(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9221(t0,t1,t2,t3);}

C_noret_decl(trf_9053)
static void C_fcall trf_9053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9053(t0,t1);}

C_noret_decl(trf_9127)
static void C_fcall trf_9127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9127(t0,t1);}

C_noret_decl(trf_9031)
static void C_fcall trf_9031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9031(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9031(t0,t1);}

C_noret_decl(trf_8696)
static void C_fcall trf_8696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8696(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8696(t0,t1);}

C_noret_decl(trf_8701)
static void C_fcall trf_8701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8701(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8701(t0,t1,t2,t3);}

C_noret_decl(trf_8717)
static void C_fcall trf_8717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8717(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8717(t0,t1);}

C_noret_decl(trf_8722)
static void C_fcall trf_8722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8722(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8722(t0,t1,t2,t3);}

C_noret_decl(trf_8617)
static void C_fcall trf_8617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8617(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8617(t0,t1,t2);}

C_noret_decl(trf_8562)
static void C_fcall trf_8562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8562(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8562(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8574)
static void C_fcall trf_8574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8574(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8574(t0,t1,t2);}

C_noret_decl(trf_8440)
static void C_fcall trf_8440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8440(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8440(t0,t1,t2,t3);}

C_noret_decl(trf_8416)
static void C_fcall trf_8416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8416(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8416(t0,t1,t2);}

C_noret_decl(trf_8422)
static void C_fcall trf_8422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8422(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8422(t0,t1,t2);}

C_noret_decl(trf_8363)
static void C_fcall trf_8363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8363(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8363(t0,t1,t2);}

C_noret_decl(trf_8334)
static void C_fcall trf_8334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8334(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8334(t0,t1,t2);}

C_noret_decl(trf_8299)
static void C_fcall trf_8299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8299(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8299(t0,t1,t2,t3);}

C_noret_decl(trf_8274)
static void C_fcall trf_8274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8274(t0,t1);}

C_noret_decl(trf_8241)
static void C_fcall trf_8241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8241(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8241(t0,t1);}

C_noret_decl(trf_8058)
static void C_fcall trf_8058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8058(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8058(t0,t1,t2,t3);}

C_noret_decl(trf_8082)
static void C_fcall trf_8082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8082(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8082(t0,t1,t2,t3);}

C_noret_decl(trf_7944)
static void C_fcall trf_7944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7944(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7944(t0,t1,t2);}

C_noret_decl(trf_7971)
static void C_fcall trf_7971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7971(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7971(t0,t1,t2);}

C_noret_decl(trf_7878)
static void C_fcall trf_7878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7878(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7878(t0,t1,t2);}

C_noret_decl(trf_7898)
static void C_fcall trf_7898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7898(t0,t1);}

C_noret_decl(trf_7698)
static void C_fcall trf_7698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7698(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7698(t0,t1);}

C_noret_decl(trf_7735)
static void C_fcall trf_7735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7735(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7735(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7447)
static void C_fcall trf_7447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7447(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7447(t0,t1,t2);}

C_noret_decl(trf_7618)
static void C_fcall trf_7618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7618(t0,t1);}

C_noret_decl(trf_7622)
static void C_fcall trf_7622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7622(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7622(t0,t1);}

C_noret_decl(trf_7551)
static void C_fcall trf_7551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7551(t0,t1);}

C_noret_decl(trf_7559)
static void C_fcall trf_7559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7559(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7559(t0,t1);}

C_noret_decl(trf_7506)
static void C_fcall trf_7506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7506(t0,t1);}

C_noret_decl(trf_7472)
static void C_fcall trf_7472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7472(t0,t1);}

C_noret_decl(trf_7426)
static void C_fcall trf_7426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7426(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7426(t0,t1,t2);}

C_noret_decl(trf_7380)
static void C_fcall trf_7380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7380(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7380(t0,t1,t2);}

C_noret_decl(trf_7397)
static void C_fcall trf_7397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7397(t0,t1);}

C_noret_decl(trf_7226)
static void C_fcall trf_7226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7226(t0,t1);}

C_noret_decl(trf_7181)
static void C_fcall trf_7181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7181(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7181(t0,t1,t2);}

C_noret_decl(trf_7148)
static void C_fcall trf_7148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7148(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7148(t0,t1,t2);}

C_noret_decl(trf_7087)
static void C_fcall trf_7087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7087(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7087(t0,t1,t2);}

C_noret_decl(trf_7009)
static void C_fcall trf_7009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7009(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7009(t0,t1,t2);}

C_noret_decl(trf_6985)
static void C_fcall trf_6985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6985(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6985(t0,t1);}

C_noret_decl(trf_6935)
static void C_fcall trf_6935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6935(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6935(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6804)
static void C_fcall trf_6804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6804(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6804(t0,t1);}

C_noret_decl(trf_6815)
static void C_fcall trf_6815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6815(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6815(t0,t1,t2);}

C_noret_decl(trf_6831)
static void C_fcall trf_6831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6831(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6831(t0,t1);}

C_noret_decl(trf_6648)
static void C_fcall trf_6648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6648(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6648(t0,t1);}

C_noret_decl(trf_6643)
static void C_fcall trf_6643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6643(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6643(t0,t1,t2);}

C_noret_decl(trf_6308)
static void C_fcall trf_6308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6308(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6308(t0,t1,t2,t3);}

C_noret_decl(trf_6312)
static void C_fcall trf_6312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6312(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6312(t0,t1);}

C_noret_decl(trf_6594)
static void C_fcall trf_6594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6594(t0,t1);}

C_noret_decl(trf_6387)
static void C_fcall trf_6387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6387(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6387(t0,t1,t2);}

C_noret_decl(trf_6260)
static void C_fcall trf_6260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6260(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6260(t0,t1);}

C_noret_decl(trf_6197)
static void C_fcall trf_6197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6197(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6197(t0,t1,t2);}

C_noret_decl(trf_6109)
static void C_fcall trf_6109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6109(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6109(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6099)
static void C_fcall trf_6099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6099(t0,t1);}

C_noret_decl(trf_5827)
static void C_fcall trf_5827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5827(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5827(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4058)
static void C_fcall trf_4058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4058(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4058(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4217)
static void C_fcall trf_4217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4217(t0,t1);}

C_noret_decl(trf_5621)
static void C_fcall trf_5621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5621(t0,t1);}

C_noret_decl(trf_5468)
static void C_fcall trf_5468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5468(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5468(t0,t1,t2);}

C_noret_decl(trf_5420)
static void C_fcall trf_5420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5420(t0,t1);}

C_noret_decl(trf_5755)
static void C_fcall trf_5755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5755(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5755(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4934)
static void C_fcall trf_4934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4934(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4934(t0,t1,t2,t3);}

C_noret_decl(trf_4120)
static void C_fcall trf_4120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4120(t0,t1);}

C_noret_decl(trf_4115)
static void C_fcall trf_4115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4115(t0,t1);}

C_noret_decl(trf_4052)
static void C_fcall trf_4052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4052(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4052(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3987)
static void C_fcall trf_3987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3987(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3987(t0,t1,t2,t3);}

C_noret_decl(trf_4006)
static void C_fcall trf_4006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4006(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4006(t0,t1);}

C_noret_decl(trf_4015)
static void C_fcall trf_4015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4015(t0,t1);}

C_noret_decl(trf_3875)
static void C_fcall trf_3875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3875(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3875(t0,t1,t2,t3);}

C_noret_decl(trf_3833)
static void C_fcall trf_3833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3833(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3833(t0,t1,t2);}

C_noret_decl(trf_3839)
static void C_fcall trf_3839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3839(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3839(t0,t1,t2,t3);}

C_noret_decl(trf_3735)
static void C_fcall trf_3735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3735(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3735(t0,t1,t2);}

C_noret_decl(trf_3662)
static void C_fcall trf_3662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3662(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3662(t0,t1,t2,t3);}

C_noret_decl(trf_3678)
static void C_fcall trf_3678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3678(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3678(t0,t1,t2,t3);}

C_noret_decl(trf_3619)
static void C_fcall trf_3619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3619(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3619(t0,t1,t2);}

C_noret_decl(trf_3550)
static void C_fcall trf_3550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3550(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3550(t0,t1,t2);}

C_noret_decl(trf_3421)
static void C_fcall trf_3421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3421(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3421(t0,t1,t2,t3);}

C_noret_decl(trf_3330)
static void C_fcall trf_3330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3330(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3330(t0,t1,t2,t3);}

C_noret_decl(trf_3282)
static void C_fcall trf_3282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3282(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3282(t0,t1);}

C_noret_decl(trf_3277)
static void C_fcall trf_3277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3277(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3277(t0,t1,t2);}

C_noret_decl(trf_2846)
static void C_fcall trf_2846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2846(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2846(t0,t1,t2);}

C_noret_decl(trf_3029)
static void C_fcall trf_3029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3029(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3029(t0,t1,t2);}

C_noret_decl(trf_3035)
static void C_fcall trf_3035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3035(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3035(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3086)
static void C_fcall trf_3086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3086(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3086(t0,t1,t2);}

C_noret_decl(trf_2849)
static void C_fcall trf_2849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2849(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2849(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2861)
static void C_fcall trf_2861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2861(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2861(t0,t1,t2,t3);}

C_noret_decl(trf_2880)
static void C_fcall trf_2880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2880(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2880(t0,t1);}

C_noret_decl(trf_2347)
static void C_fcall trf_2347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2347(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2347(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2787)
static void C_fcall trf_2787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2787(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2787(t0,t1);}

C_noret_decl(trf_2706)
static void C_fcall trf_2706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2706(t0,t1);}

C_noret_decl(trf_2660)
static void C_fcall trf_2660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2660(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2660(t0,t1);}

C_noret_decl(trf_2663)
static void C_fcall trf_2663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2663(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2663(t0,t1);}

C_noret_decl(trf_2623)
static void C_fcall trf_2623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2623(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2623(t0,t1);}

C_noret_decl(trf_2591)
static void C_fcall trf_2591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2591(t0,t1);}

C_noret_decl(trf_2533)
static void C_fcall trf_2533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2533(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2533(t0,t1);}

C_noret_decl(trf_2365)
static void C_fcall trf_2365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2365(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2365(t0,t1);}

C_noret_decl(trf_2377)
static void C_fcall trf_2377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2377(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2377(t0,t1);}

C_noret_decl(trf_2368)
static void C_fcall trf_2368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2368(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2368(t0,t1);}

C_noret_decl(trf_2328)
static void C_fcall trf_2328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2328(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2328(t0,t1,t2);}

C_noret_decl(trf_2288)
static void C_fcall trf_2288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2288(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2288(t0,t1,t2);}

C_noret_decl(trf_2307)
static void C_fcall trf_2307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2307(t0,t1);}

C_noret_decl(trf_2239)
static void C_fcall trf_2239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2239(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2239(t0,t1,t2);}

C_noret_decl(trf_2157)
static void C_fcall trf_2157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2157(t0,t1);}

C_noret_decl(trf_1996)
static void C_fcall trf_1996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1996(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1996(t0,t1,t2,t3);}

C_noret_decl(trf_2024)
static void C_fcall trf_2024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2024(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2024(t0,t1,t2);}

C_noret_decl(trf_1850)
static void C_fcall trf_1850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1850(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1850(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1882)
static void C_fcall trf_1882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1882(t0,t1);}

C_noret_decl(trf_1899)
static void C_fcall trf_1899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1899(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1899(t0,t1,t2);}

C_noret_decl(trf_1918)
static void C_fcall trf_1918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1918(t0,t1);}

C_noret_decl(trf_1879)
static void C_fcall trf_1879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1879(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1879(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(7682)){
C_save(t1);
C_rereclaim2(7682*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,524);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscore-library-modules");
lf[3]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\007lolevel\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\003tcp\376\003\000\000\002\376\001\000\000\005regex\376\003\000\000"
"\002\376\001\000\000\014regex-extras\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\005match\376\003\000\000\002\376\001\000\000\017data-structures\376\003\000\000\002\376\001"
"\000\000\005ports\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\006srfi-4\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002\376\001\000\000\007srfi-14\376\003\000\000\002\376"
"\001\000\000\007srfi-18\376\003\000\000\002\376\001\000\000\007srfi-69\376\377\016");
lf[4]=C_h_intern(&lf[4],28,"\003sysexplicit-library-modules");
lf[6]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012libchicken\376\377\016");
lf[8]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014cygchicken-0\376\377\016");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\006.dylib");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\004.dll");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003.sl");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\022CHICKEN_REPOSITORY");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022chicken-ffi-macros\376\003\000\000\002\376\001\000\000\023chicken-more-macros\376\377\016");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\006srfi-2\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\007srfi-10\376\003\000\000\002\376\001\000\000\007srfi"
"-12\376\003\000\000\002\376\001\000\000\007srfi-23\376\003\000\000\002\376\001\000\000\007srfi-28\376\003\000\000\002\376\001\000\000\007srfi-30\376\003\000\000\002\376\001\000\000\007srfi-31\376\003\000\000\002\376\001\000\000"
"\007srfi-39\376\377\016");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\006srfi-8\376\003\000\000\002\376\001\000\000\006srfi-9\376\003\000\000\002\376\001\000\000\007srfi-11\376\003\000\000\002\376\001\000\000\007srfi-"
"15\376\003\000\000\002\376\001\000\000\007srfi-16\376\003\000\000\002\376\001\000\000\007srfi-17\376\003\000\000\002\376\001\000\000\007srfi-26\376\003\000\000\002\376\001\000\000\007srfi-55\376\377\016");
lf[31]=C_h_intern(&lf[31],18,"\003syschicken-prefix");
lf[32]=C_h_intern(&lf[32],17,"\003sysstring-append");
lf[33]=C_h_intern(&lf[33],6,"getenv");
lf[34]=C_h_intern(&lf[34],12,"chicken-home");
lf[35]=C_h_intern(&lf[35],17,"\003syspeek-c-string");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\015share/chicken");
lf[37]=C_h_intern(&lf[37],21,"\003sysmacro-environment");
lf[38]=C_h_intern(&lf[38],20,"\003sysregister-macro-2");
lf[39]=C_h_intern(&lf[39],19,"\003syshash-table-set!");
lf[40]=C_h_intern(&lf[40],18,"\003sysregister-macro");
lf[41]=C_h_intern(&lf[41],14,"\003syscopy-macro");
lf[42]=C_h_intern(&lf[42],18,"\003syshash-table-ref");
lf[43]=C_h_intern(&lf[43],6,"macro\077");
lf[44]=C_h_intern(&lf[44],15,"undefine-macro!");
lf[45]=C_h_intern(&lf[45],13,"string-append");
lf[46]=C_h_intern(&lf[46],17,"\003sysmacroexpand-0");
lf[47]=C_h_intern(&lf[47],9,"\003sysabort");
lf[48]=C_h_intern(&lf[48],9,"condition");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[52]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[53]=C_h_intern(&lf[53],3,"exn");
lf[54]=C_h_intern(&lf[54],22,"with-exception-handler");
lf[55]=C_h_intern(&lf[55],30,"call-with-current-continuation");
lf[56]=C_h_intern(&lf[56],21,"\003syssyntax-error-hook");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[58]=C_h_intern(&lf[58],3,"let");
lf[59]=C_h_intern(&lf[59],16,"\004coreloop-lambda");
lf[60]=C_h_intern(&lf[60],6,"letrec");
lf[61]=C_h_intern(&lf[61],8,"\004coreapp");
lf[62]=C_h_intern(&lf[62],7,"\003sysmap");
lf[63]=C_h_intern(&lf[63],4,"cadr");
lf[64]=C_h_intern(&lf[64],16,"\003syscheck-syntax");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[66]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[67]=C_h_intern(&lf[67],10,"\003syssetter");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_h_intern(&lf[69],4,"set!");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[71]=C_h_intern(&lf[71],9,"\004coreset!");
lf[72]=C_h_intern(&lf[72],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[73]=C_h_intern(&lf[73],41,"\003sysinterpreter-toplevel-macroexpand-hook");
lf[74]=C_h_intern(&lf[74],23,"\003sysmacroexpand-1-local");
lf[75]=C_h_intern(&lf[75],25,"\003sysenable-runtime-macros");
lf[76]=C_h_intern(&lf[76],11,"macroexpand");
lf[77]=C_h_intern(&lf[77],13,"macroexpand-1");
lf[78]=C_h_intern(&lf[78],25,"\003sysextended-lambda-list\077");
lf[79]=C_h_intern(&lf[79],6,"#!rest");
lf[80]=C_h_intern(&lf[80],10,"#!optional");
lf[81]=C_h_intern(&lf[81],5,"#!key");
lf[82]=C_h_intern(&lf[82],7,"reverse");
lf[83]=C_h_intern(&lf[83],6,"gensym");
lf[84]=C_h_intern(&lf[84],31,"\003sysexpand-extended-lambda-list");
lf[85]=C_h_intern(&lf[85],9,":optional");
lf[86]=C_h_intern(&lf[86],13,"let-optionals");
lf[87]=C_h_intern(&lf[87],14,"let-optionals*");
lf[88]=C_h_intern(&lf[88],10,"\003sysappend");
lf[89]=C_h_intern(&lf[89],4,"let*");
lf[90]=C_h_intern(&lf[90],5,"quote");
lf[91]=C_h_intern(&lf[91],15,"\003sysget-keyword");
lf[92]=C_h_intern(&lf[92],6,"lambda");
lf[93]=C_h_intern(&lf[93],15,"string->keyword");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[104]=C_h_intern(&lf[104],3,"map");
lf[105]=C_h_intern(&lf[105],21,"\003syscanonicalize-body");
lf[106]=C_h_intern(&lf[106],5,"begin");
lf[107]=C_h_intern(&lf[107],6,"define");
lf[108]=C_h_intern(&lf[108],13,"define-values");
lf[109]=C_h_intern(&lf[109],20,"\003syscall-with-values");
lf[110]=C_h_intern(&lf[110],14,"\004coreundefined");
lf[111]=C_h_intern(&lf[111],25,"\003sysexpand-curried-define");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[119]=C_h_intern(&lf[119],20,"\003sysmatch-expression");
lf[120]=C_h_intern(&lf[120],15,"\003syshash-symbol");
lf[121]=C_h_intern(&lf[121],22,"\003syshash-table-update!");
lf[122]=C_h_intern(&lf[122],23,"\003syshash-table-for-each");
lf[123]=C_h_intern(&lf[123],12,"\003sysfor-each");
lf[124]=C_h_intern(&lf[124],21,"\003syshash-table->alist");
lf[125]=C_h_intern(&lf[125],3,"vec");
lf[126]=C_h_intern(&lf[126],28,"\003sysarbitrary-unbound-symbol");
lf[127]=C_h_intern(&lf[127],23,"\003syshash-table-location");
lf[128]=C_h_intern(&lf[128],20,"\003syseval-environment");
lf[129]=C_h_intern(&lf[129],26,"\003sysenvironment-is-mutable");
lf[130]=C_h_intern(&lf[130],18,"\003syseval-decorator");
lf[131]=C_h_intern(&lf[131],20,"\003sysmake-lambda-info");
lf[132]=C_h_intern(&lf[132],17,"get-output-string");
lf[133]=C_h_intern(&lf[133],5,"write");
lf[134]=C_h_intern(&lf[134],18,"open-output-string");
lf[135]=C_h_intern(&lf[135],19,"\003sysdecorate-lambda");
lf[136]=C_h_intern(&lf[136],19,"\003sysunbound-in-eval");
lf[137]=C_h_intern(&lf[137],20,"\003syseval-debug-level");
lf[138]=C_h_intern(&lf[138],21,"\003sysalias-global-hook");
lf[139]=C_h_intern(&lf[139],6,"cadadr");
lf[140]=C_h_intern(&lf[140],20,"with-input-from-file");
lf[141]=C_h_intern(&lf[141],7,"display");
lf[142]=C_h_intern(&lf[142],22,"\003syscompile-to-closure");
lf[143]=C_h_intern(&lf[143],18,"\003syscurrent-thread");
lf[144]=C_h_intern(&lf[144],9,"\003syserror");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\020unbound variable");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000!reference to undefined identifier");
lf[147]=C_h_intern(&lf[147],32,"\003syssymbol-has-toplevel-binding\077");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[149]=C_h_intern(&lf[149],15,"\004coreglobal-ref");
lf[150]=C_h_intern(&lf[150],10,"\004corecheck");
lf[151]=C_h_intern(&lf[151],14,"\004coreimmutable");
lf[152]=C_h_intern(&lf[152],2,"if");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[154]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000 assignment to immutable variable");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\042assignment of undefined identifier");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[160]=C_h_intern(&lf[160],15,"\003sysmake-vector");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[162]=C_h_intern(&lf[162],1,"\077");
lf[163]=C_h_intern(&lf[163],10,"\003sysvector");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[166]=C_h_intern(&lf[166],25,"\003sysdecompose-lambda-list");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[168]=C_h_intern(&lf[168],17,"\004corenamed-lambda");
lf[169]=C_h_intern(&lf[169],23,"\004corerequire-for-syntax");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[171]=C_h_intern(&lf[171],11,"\003sysrequire");
lf[172]=C_h_intern(&lf[172],31,"\003syslookup-runtime-requirements");
lf[173]=C_h_intern(&lf[173],22,"\004corerequire-extension");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[175]=C_h_intern(&lf[175],22,"\003sysdo-the-right-thing");
lf[176]=C_h_intern(&lf[176],24,"\004coreelaborationtimeonly");
lf[177]=C_h_intern(&lf[177],23,"\004coreelaborationtimetoo");
lf[178]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[179]=C_h_intern(&lf[179],19,"\004corecompiletimetoo");
lf[180]=C_h_intern(&lf[180],20,"\004corecompiletimeonly");
lf[181]=C_h_intern(&lf[181],13,"\004corecallunit");
lf[182]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[183]=C_h_intern(&lf[183],12,"\004coredeclare");
lf[184]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[185]=C_h_intern(&lf[185],10,"\000compiling");
lf[186]=C_h_intern(&lf[186],12,"\003sysfeatures");
lf[187]=C_h_intern(&lf[187],28,"\010compilerprocess-declaration");
lf[188]=C_h_intern(&lf[188],8,"\003syswarn");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000,declarations are ignored in interpreted code");
lf[190]=C_h_intern(&lf[190],18,"\004coredefine-inline");
lf[191]=C_h_intern(&lf[191],20,"\004coredefine-constant");
lf[192]=C_h_intern(&lf[192],14,"\004coreprimitive");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000&can not evaluate compiler-special-form");
lf[194]=C_h_intern(&lf[194],8,"location");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000&can not evaluate compiler-special-form");
lf[196]=C_h_intern(&lf[196],11,"\004coreinline");
lf[197]=C_h_intern(&lf[197],20,"\004coreinline_allocate");
lf[198]=C_h_intern(&lf[198],19,"\004coreforeign-lambda");
lf[199]=C_h_intern(&lf[199],28,"\004coredefine-foreign-variable");
lf[200]=C_h_intern(&lf[200],29,"\004coredefine-external-variable");
lf[201]=C_h_intern(&lf[201],17,"\004corelet-location");
lf[202]=C_h_intern(&lf[202],22,"\004coreforeign-primitive");
lf[203]=C_h_intern(&lf[203],20,"\004coreforeign-lambda*");
lf[204]=C_h_intern(&lf[204],24,"\004coredefine-foreign-type");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal non-atomic object");
lf[206]=C_h_intern(&lf[206],11,"\003sysnumber\077");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[208]=C_h_intern(&lf[208],16,"\003syseval-handler");
lf[209]=C_h_intern(&lf[209],12,"eval-handler");
lf[210]=C_h_intern(&lf[210],4,"eval");
lf[211]=C_h_intern(&lf[211],24,"\003syssyntax-error-culprit");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\032illegal lambda-list syntax");
lf[213]=C_h_intern(&lf[213],12,"load-verbose");
lf[214]=C_h_intern(&lf[214],14,"\003sysabort-load");
lf[215]=C_h_intern(&lf[215],27,"\003syscurrent-source-filename");
lf[216]=C_h_intern(&lf[216],21,"\003syscurrent-load-path");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[218]=C_h_intern(&lf[218],22,"set-dynamic-load-mode!");
lf[219]=C_h_intern(&lf[219],21,"\003sysset-dlopen-flags!");
lf[220]=C_h_intern(&lf[220],6,"global");
lf[221]=C_h_intern(&lf[221],5,"local");
lf[222]=C_h_intern(&lf[222],4,"lazy");
lf[223]=C_h_intern(&lf[223],3,"now");
lf[224]=C_h_intern(&lf[224],15,"\003syssignal-hook");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid dynamic-load mode");
lf[226]=C_h_intern(&lf[226],4,"read");
lf[227]=C_h_intern(&lf[227],7,"newline");
lf[228]=C_h_intern(&lf[228],15,"open-input-file");
lf[229]=C_h_intern(&lf[229],16,"close-input-port");
lf[230]=C_h_intern(&lf[230],8,"\003sysload");
lf[231]=C_h_intern(&lf[231],31,"\003sysread-error-with-line-number");
lf[232]=C_h_intern(&lf[232],19,"\003sysundefined-value");
lf[233]=C_h_intern(&lf[233],17,"\003sysdisplay-times");
lf[234]=C_h_intern(&lf[234],14,"\003sysstop-timer");
lf[235]=C_h_intern(&lf[235],15,"\003sysstart-timer");
lf[236]=C_h_intern(&lf[236],4,"load");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\036unable to load compiled module");
lf[238]=C_h_intern(&lf[238],9,"peek-char");
lf[239]=C_h_intern(&lf[239],16,"\003sysdynamic-wind");
lf[240]=C_h_intern(&lf[240],13,"\003syssubstring");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[242]=C_h_intern(&lf[242],9,"\003sysdload");
lf[243]=C_h_intern(&lf[243],17,"\003sysmake-c-string");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[245]=C_h_intern(&lf[245],11,"\000file-error");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\021can not open file");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\012; loading ");
lf[249]=C_h_intern(&lf[249],13,"\003sysfile-info");
lf[250]=C_h_intern(&lf[250],26,"\003sysload-dynamic-extension");
lf[251]=C_h_intern(&lf[251],11,"\000type-error");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a port or string");
lf[253]=C_h_intern(&lf[253],5,"port\077");
lf[254]=C_h_intern(&lf[254],20,"\003sysexpand-home-path");
lf[255]=C_h_intern(&lf[255],13,"load-relative");
lf[256]=C_h_intern(&lf[256],12,"load-noisily");
lf[257]=C_h_intern(&lf[257],8,"\000printer");
lf[258]=C_h_intern(&lf[258],5,"\000time");
lf[259]=C_h_intern(&lf[259],10,"\000evaluator");
lf[260]=C_h_intern(&lf[260],26,"\003sysload-library-extension");
lf[261]=C_h_intern(&lf[261],6,"cygwin");
lf[262]=C_h_intern(&lf[262],34,"\003sysdefault-dynamic-load-libraries");
lf[263]=C_h_intern(&lf[263],22,"dynamic-load-libraries");
lf[264]=C_h_intern(&lf[264],16,"\003sysload-library");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\022; loading library ");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[269]=C_h_intern(&lf[269],24,"\003sysstring->c-identifier");
lf[270]=C_h_intern(&lf[270],16,"\003sys->feature-id");
lf[271]=C_h_intern(&lf[271],12,"load-library");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\026unable to load library");
lf[274]=C_h_intern(&lf[274],31,"\003syscanonicalize-extension-path");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension path");
lf[276]=C_h_intern(&lf[276],18,"\003syssymbol->string");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[280]=C_h_intern(&lf[280],19,"\003sysrepository-path");
lf[281]=C_h_intern(&lf[281],15,"repository-path");
lf[282]=C_h_intern(&lf[282],12,"file-exists\077");
lf[283]=C_h_intern(&lf[283],18,"\003sysfind-extension");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[285]=C_h_intern(&lf[285],21,"\003sysinclude-pathnames");
lf[286]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[287]=C_h_intern(&lf[287],21,"\003sysloaded-extensions");
lf[288]=C_h_intern(&lf[288],14,"string->symbol");
lf[289]=C_h_intern(&lf[289],18,"\003sysload-extension");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\026can not load extension");
lf[291]=C_h_intern(&lf[291],11,"\003sysprovide");
lf[292]=C_h_intern(&lf[292],7,"provide");
lf[293]=C_h_intern(&lf[293],13,"\003sysprovided\077");
lf[294]=C_h_intern(&lf[294],9,"provided\077");
lf[295]=C_h_intern(&lf[295],7,"require");
lf[296]=C_h_intern(&lf[296],25,"\003sysextension-information");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[299]=C_h_intern(&lf[299],21,"extension-information");
lf[300]=C_h_intern(&lf[300],18,"require-at-runtime");
lf[301]=C_h_intern(&lf[301],12,"vector->list");
lf[302]=C_h_intern(&lf[302],11,"lset-adjoin");
lf[303]=C_h_intern(&lf[303],3,"eq\077");
lf[304]=C_h_intern(&lf[304],26,"\010compilerfile-requirements");
lf[305]=C_h_intern(&lf[305],19,"syntax-requirements");
lf[306]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[307]=C_h_intern(&lf[307],18,"chicken-ffi-macros");
lf[308]=C_h_intern(&lf[308],19,"chicken-more-macros");
lf[309]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[310]=C_h_intern(&lf[310],28,"\003sysresolve-include-filename");
lf[311]=C_h_intern(&lf[311],4,"uses");
lf[312]=C_h_intern(&lf[312],6,"syntax");
lf[313]=C_h_intern(&lf[313],17,"require-extension");
lf[314]=C_h_intern(&lf[314],12,"\003sysfeature\077");
lf[315]=C_h_intern(&lf[315],24,"\003sysextension-specifiers");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\035undefined extension specifier");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid extension specifier");
lf[318]=C_h_intern(&lf[318],24,"set-extension-specifier!");
lf[319]=C_h_intern(&lf[319],11,"string-copy");
lf[322]=C_h_intern(&lf[322],11,"environment");
lf[324]=C_h_intern(&lf[324],18,"\003syscopy-env-table");
lf[325]=C_h_intern(&lf[325],23,"\003sysenvironment-symbols");
lf[326]=C_h_intern(&lf[326],18,"\003syswalk-namespace");
lf[327]=C_h_intern(&lf[327],23,"interaction-environment");
lf[328]=C_h_intern(&lf[328],25,"scheme-report-environment");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[330]=C_h_intern(&lf[330],11,"make-vector");
lf[331]=C_h_intern(&lf[331],16,"null-environment");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\013 major GCs\012");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\013 minor GCs\012");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\013 mutations\012");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\027 seconds in (major) GC\012");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\021 seconds elapsed\012");
lf[340]=C_h_intern(&lf[340],24,"\003sysline-number-database");
lf[341]=C_h_intern(&lf[341],13,"\000syntax-error");
lf[342]=C_h_intern(&lf[342],12,"syntax-error");
lf[343]=C_h_intern(&lf[343],15,"get-line-number");
lf[344]=C_h_intern(&lf[344],8,"keyword\077");
lf[345]=C_h_intern(&lf[345],14,"symbol->string");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[354]=C_h_intern(&lf[354],1,"_");
lf[355]=C_h_intern(&lf[355],4,"pair");
lf[356]=C_h_intern(&lf[356],5,"pair\077");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[358]=C_h_intern(&lf[358],8,"variable");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[360]=C_h_intern(&lf[360],6,"symbol");
lf[361]=C_h_intern(&lf[361],7,"symbol\077");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[363]=C_h_intern(&lf[363],4,"list");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[365]=C_h_intern(&lf[365],6,"number");
lf[366]=C_h_intern(&lf[366],7,"number\077");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[368]=C_h_intern(&lf[368],6,"string");
lf[369]=C_h_intern(&lf[369],7,"string\077");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[371]=C_h_intern(&lf[371],11,"lambda-list");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[376]=C_h_intern(&lf[376],18,"\003sysrepl-eval-hook");
lf[377]=C_h_intern(&lf[377],27,"\003sysrepl-print-length-limit");
lf[378]=C_h_intern(&lf[378],18,"\003sysrepl-read-hook");
lf[379]=C_h_intern(&lf[379],19,"\003sysrepl-print-hook");
lf[380]=C_h_intern(&lf[380],16,"\003syswrite-char-0");
lf[381]=C_h_intern(&lf[381],9,"\003sysprint");
lf[382]=C_h_intern(&lf[382],27,"\003syswith-print-length-limit");
lf[383]=C_h_intern(&lf[383],11,"repl-prompt");
lf[384]=C_h_intern(&lf[384],20,"\003sysread-prompt-hook");
lf[385]=C_h_intern(&lf[385],16,"\003sysflush-output");
lf[386]=C_h_intern(&lf[386],19,"\003sysstandard-output");
lf[387]=C_h_intern(&lf[387],22,"\003sysclear-trace-buffer");
lf[388]=C_h_intern(&lf[388],16,"print-call-chain");
lf[389]=C_h_intern(&lf[389],12,"flush-output");
lf[390]=C_h_intern(&lf[390],5,"reset");
lf[391]=C_h_intern(&lf[391],4,"repl");
lf[392]=C_h_intern(&lf[392],18,"\003sysstandard-error");
lf[393]=C_h_intern(&lf[393],18,"\003sysstandard-input");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\005Error");
lf[397]=C_h_intern(&lf[397],17,"\003syserror-handler");
lf[398]=C_h_intern(&lf[398],20,"\003syswarnings-enabled");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\005 (in ");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000FWarning: the following toplevel variables are referenced but unbound:\012");
lf[402]=C_h_intern(&lf[402],15,"\003sysread-char-0");
lf[403]=C_h_intern(&lf[403],15,"\003syspeek-char-0");
lf[404]=C_h_intern(&lf[404],21,"\003sysenable-qualifiers");
lf[405]=C_h_intern(&lf[405],17,"\003sysreset-handler");
lf[406]=C_h_intern(&lf[406],28,"\003syssharp-comma-reader-ctors");
lf[407]=C_h_intern(&lf[407],18,"define-reader-ctor");
lf[408]=C_h_intern(&lf[408],18,"\003sysuser-read-hook");
lf[409]=C_h_intern(&lf[409],9,"read-char");
lf[410]=C_h_intern(&lf[410],14,"\003sysread-error");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000!invalid sharp-comma external form");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000!undefined sharp-comma constructor");
lf[415]=C_h_intern(&lf[415],19,"print-error-message");
lf[417]=C_h_intern(&lf[417],6,"\003sysgc");
lf[419]=C_h_intern(&lf[419],13,"thread-yield!");
lf[422]=C_h_intern(&lf[422],17,"open-input-string");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000(Error: not enough room for result string");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\010No error");
lf[433]=C_h_intern(&lf[433],15,"\003sysmake-string");
lf[434]=C_h_intern(&lf[434],6,"module");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\031modules are not supported");
lf[436]=C_h_intern(&lf[436],13,"define-syntax");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\042highlevel macros are not supported");
lf[438]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[439]=C_h_intern(&lf[439],12,"define-macro");
lf[440]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[441]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[442]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\004#;> ");
lf[444]=C_h_intern(&lf[444],14,"make-parameter");
lf[445]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007\000srfi-8\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-2\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\010\000s"
"rfi-10\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001\000\000\010\000srfi-61\376\377\016");
lf[446]=C_h_intern(&lf[446],11,"cond-expand");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[448]=C_h_intern(&lf[448],3,"and");
lf[449]=C_h_intern(&lf[449],2,"or");
lf[450]=C_h_intern(&lf[450],3,"not");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[452]=C_h_intern(&lf[452],4,"else");
lf[453]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[454]=C_h_intern(&lf[454],16,"\003sysmake-promise");
lf[455]=C_h_intern(&lf[455],5,"delay");
lf[456]=C_h_intern(&lf[456],16,"\003syslist->vector");
lf[457]=C_h_intern(&lf[457],7,"unquote");
lf[458]=C_h_intern(&lf[458],8,"\003syslist");
lf[459]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\007unquote\376\377\016");
lf[460]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\007unquote\376\377\016");
lf[461]=C_h_intern(&lf[461],10,"quasiquote");
lf[462]=C_h_intern(&lf[462],8,"\003syscons");
lf[463]=C_h_intern(&lf[463],16,"unquote-splicing");
lf[464]=C_h_intern(&lf[464],1,"a");
lf[465]=C_h_intern(&lf[465],1,"b");
lf[466]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[467]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[468]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[469]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[470]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[471]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[472]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[473]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\002do");
lf[475]=C_h_intern(&lf[475],2,"do");
lf[476]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[477]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[478]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[479]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[480]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[481]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[482]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[483]=C_h_intern(&lf[483],4,"eqv\077");
lf[484]=C_h_intern(&lf[484],4,"case");
lf[485]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[486]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[487]=C_h_intern(&lf[487],2,"=>");
lf[488]=C_h_intern(&lf[488],9,"\003sysapply");
lf[489]=C_h_intern(&lf[489],4,"cond");
lf[490]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[491]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[492]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[493]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[494]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[495]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[496]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[497]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[498]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\014dynamic-wind\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\004eval\376\003"
"\000\000\002\376\001\000\000\031scheme-report-environment\376\003\000\000\002\376\001\000\000\020null-environment\376\003\000\000\002\376\001\000\000\027interaction"
"-environment\376\377\016");
lf[499]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376"
"\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000"
"\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005"
"caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaa"
"r\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadad"
"r\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000\000\002\376\001\000\000\006cdadd"
"r\376\003\000\000\002\376\001\000\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\010set-c"
"ar!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\006lengt"
"h\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\007reverse\376\003\000\000\002\376\001\000\000"
"\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004assq\376\003\000\000\002\376\001\000\000\004assv\376\003\000\000\002\376\001\000\000\005assoc\376\003"
"\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\007number\077"
"\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010complex\077\376\003\000\000\002\376\001\000\000\010ine"
"xact\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\005zero\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001\000\000\005even\077\376\003\000\000\002\376\001\000\000\011po"
"sitive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\001+\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376"
"\001\000\000\001*\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001"
"\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002\376\001\000\000\003lcm\376\003\000\000\002\376\001\000"
"\000\003abs\376\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000\005round\376\003\000\000\002\376\001\000\000\016"
"exact->inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log\376\003\000\000\002\376\001\000\000\004expt\376\003"
"\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asin\376\003\000\000\002\376\001\000\000\004acos\376"
"\003\000\000\002\376\001\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000\000\002\376\001\000\000\005char\077\376\003\000\000"
"\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000\000\002\376\001\000\000\007char<=\077\376\003"
"\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000\012char-ci>=\077\376\003\000\000\002"
"\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespace\077\376\003\000\000\002\376\001\000\000\015cha"
"r-numeric\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\020char-lower-case\077\376\003\000\000\002\376\001\000\000\013char-upc"
"ase\376\003\000\000\002\376\001\000\000\015char-downcase\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integer->char\376\003\000\000\002\376\001\000"
"\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376\003\000\000\002\376\001\000\000\011string>"
"=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376\003\000\000\002\376\001\000\000\013string-"
"ci>\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\013make-string\376\003\000\000\002\376\001\000\000\015s"
"tring-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string-set!\376\003\000\000\002\376\001\000\000\015string-append\376\003\000\000"
"\002\376\001\000\000\013string-copy\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\011substring"
"\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000\002\376\001\000\000\012vector-ref"
"\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\015vector-length\376\003\000\000"
"\002\376\001\000\000\014vector->list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000\000\002\376\001\000\000\012procedur"
"e\077\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\005force\376\003\000\000\002\376\001\000\000\036call-wi"
"th-current-continuation\376\003\000\000\002\376\001\000\000\013input-port\077\376\003\000\000\002\376\001\000\000\014output-port\077\376\003\000\000\002\376\001\000\000\022curr"
"ent-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\024call-with-input-file\376\003\000\000\002\376\001"
"\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002"
"\376\001\000\000\020close-input-port\376\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\004load\376\003\000\000\002\376\001\000\000\004read\376\003\000\000"
"\002\376\001\000\000\013eof-object\077\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007"
"display\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\024with-input-from-file\376\003\000\000\002\376"
"\001\000\000\023with-output-to-file\376\003\000\000\002\376\001\000\000\024\003syscall-with-values\376\003\000\000\002\376\001\000\000\012\003sysvalues\376\003\000\000\002\376\001"
"\000\000\020\003sysdynamic-wind\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\020\003syslist->vector\376\003\000\000\002\376\001\000\000\010\003syslis"
"t\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\020\003sysmake-promise\376\377\016");
lf[500]=C_h_intern(&lf[500],18,"\003sysnumber->string");
lf[501]=C_h_intern(&lf[501],5,"error");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid extension version");
lf[503]=C_h_intern(&lf[503],7,"version");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\0003installed extension does not match required version");
lf[505]=C_h_intern(&lf[505],9,"string>=\077");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid version specification");
lf[507]=C_h_intern(&lf[507],12,"list->vector");
lf[508]=C_h_intern(&lf[508],18,"\003sysstring->symbol");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\005srfi-");
lf[510]=C_h_intern(&lf[510],4,"srfi");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[512]=C_h_intern(&lf[512],14,"build-platform");
lf[513]=C_h_intern(&lf[513],7,"windows");
lf[514]=C_h_intern(&lf[514],6,"macosx");
lf[515]=C_h_intern(&lf[515],4,"hpux");
lf[516]=C_h_intern(&lf[516],4,"hppa");
lf[517]=C_h_intern(&lf[517],12,"machine-type");
lf[518]=C_h_intern(&lf[518],16,"software-version");
lf[519]=C_h_intern(&lf[519],13,"software-type");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\012C_toplevel");
lf[521]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[523]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
C_register_lf2(lf,524,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate((C_word*)lf[2]+1,lf[3]);
t4=C_set_block_item(lf[4],0,C_SCHEME_END_OF_LIST);
t5=C_mutate(&lf[5],lf[6]);
t6=C_mutate(&lf[7],lf[8]);
t7=C_mutate(&lf[9],lf[10]);
t8=C_mutate(&lf[11],lf[12]);
t9=C_mutate(&lf[13],lf[14]);
t10=C_mutate(&lf[15],lf[16]);
t11=C_mutate(&lf[17],lf[18]);
t12=C_mutate(&lf[19],lf[20]);
t13=C_mutate(&lf[21],lf[22]);
t14=C_mutate(&lf[23],lf[24]);
t15=C_mutate(&lf[25],lf[26]);
t16=C_mutate(&lf[27],lf[28]);
t17=C_mutate(&lf[29],lf[30]);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1731,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 136  getenv */
t19=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,lf[24]);}

/* k1729 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1734,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(C_word)C_block_size(t1);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_subchar(t1,t4);
t6=(C_word)C_u_i_memq(t5,lf[521]);
t7=(C_truep(t6)?lf[522]:lf[523]);
/* eval.scm: 137  ##sys#string-append */
t8=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t2,t1,t7);}
else{
t3=t2;
f_1734(2,t3,C_SCHEME_FALSE);}}

/* k1732 in k1729 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1734,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1735,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=*((C_word*)lf[33]+1);
t4=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1762,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 157  make-vector */
t6=*((C_word*)lf[330]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1774 in k1732 in k1729 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[71],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1,t1);
t3=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1778,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1794,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1810,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1820,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1838,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[45]+1);
t9=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1847,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2217,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2220,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2223,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2230,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2266,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2282,tmp=(C_word)a,a+=2,tmp));
t17=*((C_word*)lf[82]+1);
t18=*((C_word*)lf[83]+1);
t19=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2325,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[82]+1);
t21=*((C_word*)lf[104]+1);
t22=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2844,a[2]=t21,a[3]=t20,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3327,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3418,tmp=(C_word)a,a+=2,tmp));
t25=C_SCHEME_FALSE;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_FALSE;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[120]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3478,a[2]=t28,a[3]=t26,tmp=(C_word)a,a+=4,tmp));
t30=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3493,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3538,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[121]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3593,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[122]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3613,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3656,tmp=(C_word)a,a+=2,tmp));
t35=(C_word)C_slot(lf[126],C_fix(0));
t36=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3723,a[2]=t35,tmp=(C_word)a,a+=3,tmp));
t37=C_set_block_item(lf[128],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[129],0,C_SCHEME_FALSE);
t39=C_mutate((C_word*)lf[130]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3783,tmp=(C_word)a,a+=2,tmp));
t40=C_set_block_item(lf[136],0,C_SCHEME_FALSE);
t41=C_set_block_item(lf[137],0,C_fix(1));
t42=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3824,tmp=(C_word)a,a+=2,tmp));
t43=*((C_word*)lf[43]+1);
t44=*((C_word*)lf[133]+1);
t45=*((C_word*)lf[139]+1);
t46=*((C_word*)lf[82]+1);
t47=*((C_word*)lf[134]+1);
t48=*((C_word*)lf[132]+1);
t49=*((C_word*)lf[140]+1);
t50=(C_word)C_slot(lf[126],C_fix(0));
t51=*((C_word*)lf[141]+1);
t52=C_mutate((C_word*)lf[142]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3830,a[2]=t45,a[3]=t50,tmp=(C_word)a,a+=4,tmp));
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6079,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11465,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1061 make-parameter */
t55=*((C_word*)lf[444]+1);
((C_proc3)(void*)(*((C_word*)t55+1)))(3,t55,t53,t54);}

/* a11464 in k1774 in k1732 in k1729 */
static void C_ccall f_11465(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_11465r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_11465r(t0,t1,t2,t3);}}

static void C_ccall f_11465r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[129]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11469,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_slot(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_i_check_structure(t9,lf[322]);
t11=(C_word)C_slot(t9,C_fix(1));
t12=C_set_block_item(t7,0,t11);
t13=(C_word)C_slot(t9,C_fix(2));
t14=C_set_block_item(t5,0,t13);
t15=t8;
f_11469(t15,t14);}
else{
t10=t8;
f_11469(t10,C_SCHEME_UNDEFINED);}}
else{
t9=t8;
f_11469(t9,C_SCHEME_UNDEFINED);}}

/* k11467 in a11464 in k1774 in k1732 in k1729 */
static void C_fcall f_11469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11469,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11475,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11477,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11493,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1071 ##sys#dynamic-wind */
t14=*((C_word*)lf[239]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a11492 in k11467 in a11464 in k1774 in k1732 in k1729 */
static void C_ccall f_11493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11493,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[129]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[128]+1));
t4=C_mutate((C_word*)lf[129]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[128]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[232]+1));}

/* a11486 in k11467 in a11464 in k1774 in k1732 in k1729 */
static void C_ccall f_11487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11487,2,t0,t1);}
/* eval.scm: 1073 ##sys#compile-to-closure */
t2=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* a11476 in k11467 in a11464 in k1774 in k1732 in k1729 */
static void C_ccall f_11477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11477,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[129]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[128]+1));
t4=C_mutate((C_word*)lf[129]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[128]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[232]+1));}

/* k11473 in k11467 in a11464 in k1774 in k1732 in k1729 */
static void C_ccall f_11475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6079,2,t0,t1);}
t2=C_mutate((C_word*)lf[208]+1,t1);
t3=C_mutate((C_word*)lf[209]+1,*((C_word*)lf[208]+1));
t4=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6082,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[82]+1);
t6=C_mutate((C_word*)lf[166]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6096,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6178,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 1105 make-parameter */
t9=*((C_word*)lf[444]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6178,2,t0,t1);}
t2=C_mutate((C_word*)lf[213]+1,t1);
t3=C_mutate((C_word*)lf[214]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6180,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[215],0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[216]+1,lf[217]);
t6=C_mutate((C_word*)lf[218]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6185,tmp=(C_word)a,a+=2,tmp));
t7=*((C_word*)lf[226]+1);
t8=*((C_word*)lf[133]+1);
t9=*((C_word*)lf[141]+1);
t10=*((C_word*)lf[227]+1);
t11=*((C_word*)lf[210]+1);
t12=*((C_word*)lf[228]+1);
t13=*((C_word*)lf[229]+1);
t14=*((C_word*)lf[45]+1);
t15=*((C_word*)lf[213]+1);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6258,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t9,a[5]=t12,a[6]=t13,a[7]=t8,a[8]=t10,a[9]=t7,a[10]=t11,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1137 ##sys#make-c-string */
t17=*((C_word*)lf[243]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[520]);}

/* k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6260,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[230]+1,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6306,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp));
t4=C_mutate((C_word*)lf[236]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6693,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[255]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6715,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[256]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6751,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6777,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11459,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1227 software-type */
t9=*((C_word*)lf[519]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* k11457 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11459,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[513]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6777(t3,lf[12]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11455,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1228 software-version */
t4=*((C_word*)lf[518]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11453 in k11457 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11455,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[514]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6777(t3,lf[10]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11451,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1229 software-version */
t5=*((C_word*)lf[518]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k11449 in k11453 in k11457 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11451,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[515]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11447,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1230 machine-type */
t4=*((C_word*)lf[517]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_11437(t3,C_SCHEME_FALSE);}}

/* k11445 in k11449 in k11453 in k11457 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_11437(t2,(C_word)C_eqp(t1,lf[516]));}

/* k11435 in k11453 in k11457 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_11437(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6777(t2,(C_truep(t1)?lf[14]:lf[15]));}

/* k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6777(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6777,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[260]+1,t1);
t3=C_mutate((C_word*)lf[250]+1,lf[15]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6782,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1236 build-platform */
t5=*((C_word*)lf[512]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6782,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[261]);
t3=(C_truep(t2)?lf[8]:lf[6]);
t4=C_mutate((C_word*)lf[262]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6789,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11407,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11415,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,*((C_word*)lf[262]+1));}

/* a11414 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11415,3,t0,t1,t2);}
/* ##sys#string-append */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[260]+1));}

/* k11405 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11409,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1241 make-parameter */
t3=*((C_word*)lf[444]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a11408 in k11405 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11409,3,t0,t1,t2);}
t3=(C_word)C_i_check_list(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6789,2,t0,t1);}
t2=C_mutate((C_word*)lf[263]+1,t1);
t3=*((C_word*)lf[213]+1);
t4=*((C_word*)lf[45]+1);
t5=*((C_word*)lf[263]+1);
t6=*((C_word*)lf[141]+1);
t7=C_mutate((C_word*)lf[264]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6791,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[271]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6897,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[82]+1);
t10=C_mutate(&lf[273],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6926,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[45]+1);
t12=C_mutate((C_word*)lf[274]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6982,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7142,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11376,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1329 getenv */
t15=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,lf[22]);}

/* k11374 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_11379(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11382,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11392,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11396,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_fudge(C_fix(42));
t7=(C_truep(t6)?t6:C_fix(3));
/* eval.scm: 1333 ##sys#number->string */
t8=*((C_word*)lf[500]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}}

/* k11394 in k11374 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1331 ##sys#string-append */
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[511],t1);}

/* k11390 in k11374 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1330 ##sys#chicken-prefix */
t2=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11380 in k11374 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11382,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_11379(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_EGG_HOME),C_fix(0));}}

/* k11377 in k11374 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1328 make-parameter */
t2=*((C_word*)lf[444]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7142,2,t0,t1);}
t2=C_mutate((C_word*)lf[280]+1,t1);
t3=C_mutate((C_word*)lf[281]+1,*((C_word*)lf[280]+1));
t4=*((C_word*)lf[282]+1);
t5=*((C_word*)lf[45]+1);
t6=C_mutate((C_word*)lf[283]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7145,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t7=C_set_block_item(lf[287],0,C_SCHEME_END_OF_LIST);
t8=*((C_word*)lf[288]+1);
t9=C_mutate((C_word*)lf[289]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7222,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[291]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7290,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[292]+1,*((C_word*)lf[291]+1));
t12=C_mutate((C_word*)lf[293]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7310,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[294]+1,*((C_word*)lf[293]+1));
t14=C_mutate((C_word*)lf[171]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7324,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[295]+1,*((C_word*)lf[171]+1));
t16=*((C_word*)lf[140]+1);
t17=*((C_word*)lf[282]+1);
t18=*((C_word*)lf[45]+1);
t19=*((C_word*)lf[226]+1);
t20=C_mutate((C_word*)lf[296]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7337,a[2]=t18,a[3]=t17,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=C_mutate((C_word*)lf[299]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7368,tmp=(C_word)a,a+=2,tmp));
t22=*((C_word*)lf[140]+1);
t23=*((C_word*)lf[226]+1);
t24=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7374,tmp=(C_word)a,a+=2,tmp));
t25=*((C_word*)lf[301]+1);
t26=C_mutate((C_word*)lf[175]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7423,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t27=C_set_block_item(lf[315],0,C_SCHEME_END_OF_LIST);
t28=C_mutate((C_word*)lf[318]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7822,tmp=(C_word)a,a+=2,tmp));
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7861,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t30=*((C_word*)lf[507]+1);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11322,a[2]=t30,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1520 set-extension-specifier! */
t32=*((C_word*)lf[318]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,t29,lf[510],t31);}

/* a11321 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11322,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11330,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11336,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_11336(t9,t4,t5);}

/* loop in a11321 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_11336(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11336,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_check_exact_2(t3,lf[313]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11356,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11368,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11372,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1530 number->string */
C_number_to_string(3,0,t7,t3);}}

/* k11370 in loop in a11321 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1530 ##sys#string-append */
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[509],t1);}

/* k11366 in loop in a11321 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1530 ##sys#string->symbol */
t2=*((C_word*)lf[508]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11354 in loop in a11321 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11360,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1531 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_11336(t4,t2,t3);}

/* k11358 in k11354 in loop in a11321 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11360,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11328 in a11321 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1524 list->vector */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7864,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11201,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1536 set-extension-specifier! */
t4=*((C_word*)lf[318]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[503],t3);}

/* a11200 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11201,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11204,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11238,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[503]);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_u_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_u_i_cdddr(t2);
t11=t5;
f_11238(t11,(C_word)C_i_nullp(t10));}
else{
t10=t5;
f_11238(t10,C_SCHEME_FALSE);}}
else{
t9=t5;
f_11238(t9,C_SCHEME_FALSE);}}
else{
t8=t5;
f_11238(t8,C_SCHEME_FALSE);}}
else{
t6=t5;
f_11238(t6,C_SCHEME_FALSE);}}

/* k11236 in a11200 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_11238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11238,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11247,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1546 extension-information */
t5=*((C_word*)lf[299]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* syntax-error */
t2=*((C_word*)lf[342]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[313],lf[506],((C_word*)t0)[4]);}}

/* k11245 in k11236 in a11200 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11247,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_assq(lf[503],t1):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11253,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11256,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11266,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* eval.scm: 1548 ->string */
f_11204(t5,t6);}
else{
t5=t4;
f_11256(2,t5,C_SCHEME_FALSE);}}

/* k11264 in k11245 in k11236 in a11200 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11270,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1548 ->string */
f_11204(t2,((C_word*)t0)[2]);}

/* k11268 in k11264 in k11245 in k11236 in a11200 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1548 string>=? */
t2=*((C_word*)lf[505]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11254 in k11245 in k11236 in a11200 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_11253(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1549 error */
t2=*((C_word*)lf[501]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[504],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11251 in k11245 in k11236 in a11200 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ->string in a11200 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_11204(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11204,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* eval.scm: 1542 ##sys#number->string */
t3=*((C_word*)lf[500]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
/* eval.scm: 1543 error */
t3=*((C_word*)lf[501]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[502],t2);}}}}

/* k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7864,2,t0,t1);}
t2=*((C_word*)lf[319]+1);
t3=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7866,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7922,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1570 make-vector */
t5=*((C_word*)lf[330]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7922,2,t0,t1);}
t2=C_mutate(&lf[320],t1);
t3=lf[321]=C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[322],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[323],t4);
t6=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7929,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8037,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8156,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8159,tmp=(C_word)a,a+=2,tmp));
t10=*((C_word*)lf[330]+1);
t11=C_mutate((C_word*)lf[331]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8203,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8241,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8257,a[2]=t12,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11199,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1651 initb */
f_8241(t14,lf[320]);}

/* k11197 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[499]);}

/* k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1672 ##sys#copy-env-table */
t3=*((C_word*)lf[324]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[320],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8261,2,t0,t1);}
t2=C_mutate(&lf[321],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8264,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11195,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1674 initb */
f_8241(t4,lf[321]);}

/* k11193 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[498]);}

/* k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8268,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1681 chicken-home */
t3=*((C_word*)lf[34]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8268,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[285]+1,t2);
t4=*((C_word*)lf[45]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8274,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8293,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[141]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8416,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8440,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[233]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8461,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(lf[340],0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8515,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(lf[211],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[342]+1,*((C_word*)lf[56]+1));
t15=C_mutate((C_word*)lf[343]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8523,tmp=(C_word)a,a+=2,tmp));
t16=*((C_word*)lf[45]+1);
t17=*((C_word*)lf[344]+1);
t18=*((C_word*)lf[343]+1);
t19=*((C_word*)lf[345]+1);
t20=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8559,a[2]=t17,a[3]=t18,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8951,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11098,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1842 ##sys#register-macro-2 */
t23=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t21,lf[107],t22);}

/* a11097 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11098,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11104,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_11104(t6,t1,t2);}

/* loop in a11097 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_11104(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11104,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11145,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1853 ##sys#check-syntax */
t7=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[107],t3,lf[493]);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11158,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1857 ##sys#check-syntax */
t7=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[107],t3,lf[495]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11120,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1849 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[107],t3,lf[360]);}}

/* k11118 in loop in a11097 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1850 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[4],lf[497]);}

/* k11121 in k11118 in loop in a11097 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11123,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[4]):lf[496]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],((C_word*)t0)[2],t3));}

/* k11156 in loop in a11097 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1858 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[3],lf[494]);}

/* k11159 in k11156 in loop in a11097 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11161,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[92],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[71],t2,t5));}

/* k11143 in loop in a11097 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1854 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[2],lf[492]);}

/* k11146 in k11143 in loop in a11097 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11155,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1855 ##sys#expand-curried-define */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11153 in k11146 in k11143 in loop in a11097 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1855 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11104(t2,((C_word*)t0)[2],t1);}

/* k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8954,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11070,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1861 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[448],t3);}

/* a11069 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11070(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11070,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(C_word)C_a_i_cons(&a,2,lf[448],t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,4,lf[152],t5,t7,C_SCHEME_FALSE));}}}

/* k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8957,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11027,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1872 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[449],t4);}

/* a11026 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11027,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11049,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1882 gensym */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}}

/* k11047 in a11026 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_11049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11049,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[449],((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,4,lf[152],t1,t1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[58],t3,t5));}

/* k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8960,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10830,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1886 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[489],t4);}

/* a10829 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10830(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10830,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10836,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10836(t6,t1,t2);}

/* expand in a10829 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_10836(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10836,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10852,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1895 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[489],t3,lf[490]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[491]);}}

/* k10850 in expand in a10829 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10852,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[452],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[106],t4));}
else{
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10882,a[2]=t6,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1897 expand */
t8=((C_word*)((C_word*)t0)[4])[1];
f_10836(t8,t7,((C_word*)t0)[3]);}
else{
t6=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_eqp(lf[487],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10891,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1899 gensym */
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[6]))){
t9=(C_word)C_i_length(((C_word*)t0)[6]);
t10=(C_word)C_eqp(t9,C_fix(4));
if(C_truep(t10)){
t11=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
t12=t8;
f_10928(t12,(C_word)C_eqp(lf[487],t11));}
else{
t11=t8;
f_10928(t11,C_SCHEME_FALSE);}}
else{
t9=t8;
f_10928(t9,C_SCHEME_FALSE);}}}}}

/* k10926 in k10850 in expand in a10829 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_10928(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10928,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1905 gensym */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,lf[106],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10985,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1914 expand */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10836(t6,t5,((C_word*)t0)[3]);}}

/* k10983 in k10926 in k10850 in expand in a10829 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10985,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[152],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10929 in k10926 in k10850 in expand in a10829 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10931,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,3,lf[488],t4,t1);
t6=(C_word)C_u_i_cadddr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_list(&a,3,lf[488],t6,t1);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10958,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1911 expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10836(t9,t8,((C_word*)t0)[2]);}

/* k10956 in k10929 in k10926 in k10850 in expand in a10829 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10958,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[152],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[2],t3));}

/* k10889 in k10850 in expand in a10829 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10891,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,t5,t1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10910,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1903 expand */
t8=((C_word*)((C_word*)t0)[3])[1];
f_10836(t8,t7,((C_word*)t0)[2]);}

/* k10908 in k10889 in k10850 in expand in a10829 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10910,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[152],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t2));}

/* k10880 in k10850 in expand in a10829 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10882,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[449],((C_word*)t0)[2],t1));}

/* k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10727,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1916 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[484],t4);}

/* a10726 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10727,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10737,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1922 gensym */
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k10735 in a10726 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10737,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10748,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10750,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10750(t8,t4,((C_word*)t0)[2]);}

/* expand in k10735 in a10726 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_10750(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10750,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10766,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1929 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[484],t3,lf[485]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[486]);}}

/* k10764 in expand in k10735 in a10726 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10766,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[452],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[106],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10804,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* eval.scm: 1932 ##sys#map */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a10803 in k10764 in expand in k10735 in a10726 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10804,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[90],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[483],((C_word*)t0)[2],t3));}

/* k10800 in k10764 in expand in k10735 in a10726 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10802,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[449],t1);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,lf[106],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10794,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1934 expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10750(t6,t5,((C_word*)t0)[2]);}

/* k10792 in k10800 in k10764 in expand in k10735 in a10726 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10794,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[152],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10746 in k10735 in a10726 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10748,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t1));}

/* k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8966,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10674,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1936 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[89],t3);}

/* a10673 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10674(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10674,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10684,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1941 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[89],t3,lf[482]);}

/* k10682 in a10673 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1942 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[89],((C_word*)t0)[4],lf[481]);}

/* k10685 in k10682 in a10673 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10687,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10692,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_10692(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k10685 in k10682 in a10673 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_10692(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10692,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[58],t4));}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10717,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1946 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k10715 in expand in k10685 in k10682 in a10673 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10717,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t1));}

/* k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8969,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10604,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1948 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[60],t3);}

/* a10603 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10604,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10614,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1953 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],t3,lf[480]);}

/* k10612 in a10603 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1954 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[60],((C_word*)t0)[3],lf[479]);}

/* k10615 in k10612 in a10603 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10664,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1955 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10663 in k10615 in k10612 in a10603 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10664(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10664,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[478]));}

/* k10626 in k10615 in k10612 in a10603 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10632,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10636,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10650,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1956 ##sys#map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a10649 in k10626 in k10615 in k10612 in a10603 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10650,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[71],t3,t4));}

/* k10634 in k10626 in k10615 in k10612 in a10603 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10636,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[58],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k10630 in k10626 in k10615 in k10612 in a10603 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10632,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[58],t2));}

/* k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8972,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10485,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1959 ##sys#register-macro */
t5=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[475],t4);}

/* a10484 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_10485r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10485r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10485r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10489,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1963 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[475],t2,lf[477]);}

/* k10487 in a10484 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1964 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[475],((C_word*)t0)[6],lf[476]);}

/* k10490 in k10487 in a10484 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10495,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1965 gensym */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[474]);}

/* k10493 in k10490 in k10487 in a10484 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10586,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1966 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a10585 in k10493 in k10490 in k10487 in a10484 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10586(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10586,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k10500 in k10493 in k10490 in k10487 in a10484 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10502,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
t5=(C_truep(t4)?lf[472]:(C_word)C_a_i_cons(&a,2,lf[106],t3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10525,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=t6;
f_10525(t8,lf[473]);}
else{
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t9=t6;
f_10525(t9,(C_word)C_a_i_cons(&a,2,lf[58],t8));}}

/* k10523 in k10500 in k10493 in k10490 in k10487 in a10484 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_10525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10525,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10539,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1977 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10538 in k10523 in k10500 in k10493 in k10490 in k10487 in a10484 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10539(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10539,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u_i_car(t2));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_u_i_car(t7));}}

/* k10535 in k10523 in k10500 in k10493 in k10490 in k10487 in a10484 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10537,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],t2);
t4=(C_word)C_a_i_list(&a,3,lf[106],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,4,lf[152],((C_word*)t0)[5],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[58],((C_word*)t0)[7],((C_word*)t0)[2],t5));}

/* k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8975,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[301]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10193,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1983 ##sys#register-macro */
t5=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[461],t4);}

/* a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10193,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10196,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10206,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10403,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
/* eval.scm: 2044 walk */
t12=((C_word*)t4)[1];
f_10196(t12,t1,t2,C_fix(0));}

/* simplify in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_10403(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10403,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10407,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2031 ##sys#match-expression */
t4=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[470],lf[471]);}

/* k10405 in simplify in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10407,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[464],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[458],t3);
/* eval.scm: 2032 simplify */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10403(t5,((C_word*)t0)[3],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2033 ##sys#match-expression */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[468],lf[469]);}}

/* k10426 in k10405 in simplify in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10428,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[465],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_u_i_assq(lf[464],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[458],t7);
/* eval.scm: 2037 simplify */
t9=((C_word*)((C_word*)t0)[4])[1];
f_10403(t9,((C_word*)t0)[3],t8);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2040 ##sys#match-expression */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[466],lf[467]);}}

/* k10468 in k10426 in k10405 in simplify in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[464],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_10206(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[72],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10206,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10220,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10224,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1993 vector->list */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t4,lf[457]);
if(C_truep(t6)){
t7=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_slot(t5,C_fix(0));
t9=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10267,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 2005 walk */
t12=((C_word*)((C_word*)t0)[3])[1];
f_10196(t12,t10,t8,t11);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[460]);}}
else{
t7=(C_word)C_eqp(t4,lf[461]);
if(C_truep(t7)){
t8=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[90],lf[461]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10294,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t5,C_fix(0));
t12=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 2010 walk */
t13=((C_word*)((C_word*)t0)[3])[1];
f_10196(t13,t10,t11,t12);}
else{
t9=(C_word)C_a_i_list(&a,2,lf[90],lf[461]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10313,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2011 walk */
t11=((C_word*)((C_word*)t0)[3])[1];
f_10196(t11,t10,t5,t3);}}
else{
t8=(C_truep((C_word)C_blockp(t4))?(C_word)C_pairp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_slot(t4,C_fix(0));
t10=(C_word)C_slot(t4,C_fix(1));
t11=(C_word)C_eqp(t9,lf[463]);
t12=(C_truep(t11)?(C_truep((C_word)C_blockp(t10))?(C_word)C_pairp(t10):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=(C_word)C_slot(t10,C_fix(0));
t14=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10347,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2022 walk */
t16=((C_word*)((C_word*)t0)[3])[1];
f_10196(t16,t15,t5,t3);}
else{
t15=(C_word)C_a_i_list(&a,2,lf[90],lf[463]);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10366,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 2024 walk */
t18=((C_word*)((C_word*)t0)[3])[1];
f_10196(t18,t16,t13,t17);}}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10377,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2026 walk */
t14=((C_word*)((C_word*)t0)[3])[1];
f_10196(t14,t13,t4,t3);}}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10394,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2027 walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_10196(t10,t9,t4,t3);}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[90],t2));}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[90],t2));}}

/* k10392 in walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10398,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2027 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10196(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10396 in k10392 in walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10398,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[462],((C_word*)t0)[2],t1));}

/* k10375 in walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10381,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2026 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10196(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10379 in k10375 in walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10381,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[462],((C_word*)t0)[2],t1));}

/* k10364 in walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10366,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[458],((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10358,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2025 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_10196(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10356 in k10364 in walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10358,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[462],((C_word*)t0)[2],t1));}

/* k10345 in walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10347,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[88],((C_word*)t0)[2],t1));}

/* k10311 in walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10313,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[462],((C_word*)t0)[2],t1));}

/* k10292 in walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10294,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[458],((C_word*)t0)[2],t1));}

/* k10265 in walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10267,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[458],lf[459],t1));}

/* k10222 in walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1993 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10196(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10218 in walk1 in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10220,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[456],t1));}

/* walk in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_10196(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10196,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10204,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1988 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10206(t5,t4,t2,t3);}

/* k10202 in walk in a10192 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1988 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10403(t2,((C_word*)t0)[2],t1);}

/* k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8978,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10183,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2046 ##sys#register-macro */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[455],t3);}

/* a10182 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10183,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[454],t3));}

/* k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8981,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9937,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2050 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[446],t3);}

/* a9936 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9937,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9940,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9950,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10092,a[2]=t3,a[3]=t5,a[4]=t8,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_10092(t10,t1,t2);}

/* expand in a9936 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_10092(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10092,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10106,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10108,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_eqp(t6,lf[452]);
if(C_truep(t7)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(t8,C_SCHEME_END_OF_LIST);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?lf[453]:(C_word)C_a_i_cons(&a,2,lf[106],t8)));}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10163,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2095 test */
t9=((C_word*)((C_word*)t0)[3])[1];
f_9950(t9,t8,t6);}}
else{
/* eval.scm: 2088 err */
t6=((C_word*)t0)[2];
f_9940(t6,t1,t4);}}
else{
/* eval.scm: 2083 err */
t4=((C_word*)t0)[2];
f_9940(t4,t1,t2);}}}

/* k10161 in expand in a9936 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10163,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[106],t2));}
else{
/* eval.scm: 2096 expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10092(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a10107 in expand in a9936 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10108,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k10104 in expand in a9936 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[144]+1),lf[451],t1);}

/* test in a9936 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9950(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9950,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 2058 ##sys#feature? */
t3=*((C_word*)lf[314]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_eqp(t4,lf[448]);
if(C_truep(t5)){
t6=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9999,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 2066 test */
t17=t7;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2068 err */
t7=((C_word*)t0)[2];
f_9940(t7,t1,t2);}}}
else{
t6=(C_word)C_eqp(t4,lf[449]);
if(C_truep(t6)){
t7=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10038,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 2072 test */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2074 err */
t8=((C_word*)t0)[2];
f_9940(t8,t1,t2);}}}
else{
t7=(C_word)C_eqp(t4,lf[450]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10076,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_u_i_cadr(t2);
/* eval.scm: 2075 test */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2076 err */
t8=((C_word*)t0)[2];
f_9940(t8,t1,t2);}}}}
else{
/* eval.scm: 2059 err */
t3=((C_word*)t0)[2];
f_9940(t3,t1,t2);}}}

/* k10074 in test in a9936 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k10036 in test in a9936 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_10038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10038,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[449],t2);
/* eval.scm: 2073 test */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9950(t4,((C_word*)t0)[4],t3);}}

/* k9997 in test in a9936 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9999,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[448],t2);
/* eval.scm: 2067 test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9950(t4,((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* err in a9936 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9940(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9940,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[446],((C_word*)t0)[2]);
/* eval.scm: 2055 ##sys#error */
t4=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[447],t2,t3);}

/* k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8985,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2102 append */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[445],*((C_word*)lf[186]+1));}

/* k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8985,2,t0,t1);}
t2=C_mutate((C_word*)lf[186]+1,t1);
t3=C_set_block_item(lf[376],0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[377],0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[378],0,C_SCHEME_FALSE);
t6=C_mutate((C_word*)lf[379]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8990,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9934,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2116 make-parameter */
t9=*((C_word*)lf[444]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a9933 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9934,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[443]);}

/* k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9007,2,t0,t1);}
t2=C_mutate((C_word*)lf[383]+1,t1);
t3=*((C_word*)lf[383]+1);
t4=C_mutate((C_word*)lf[384]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9009,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[387]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9025,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[210]+1);
t7=*((C_word*)lf[226]+1);
t8=*((C_word*)lf[55]+1);
t9=*((C_word*)lf[388]+1);
t10=*((C_word*)lf[389]+1);
t11=*((C_word*)lf[213]+1);
t12=*((C_word*)lf[390]+1);
t13=C_mutate((C_word*)lf[391]+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9028,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t11,a[6]=t9,a[7]=t10,tmp=(C_word)a,a+=8,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9367,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2232 make-vector */
t15=*((C_word*)lf[330]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9367,2,t0,t1);}
t2=C_mutate((C_word*)lf[406]+1,t1);
t3=C_mutate((C_word*)lf[407]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9369,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[408]+1);
t5=*((C_word*)lf[409]+1);
t6=*((C_word*)lf[226]+1);
t7=C_mutate((C_word*)lf[408]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9378,a[2]=t4,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9453,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9792,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2261 ##sys#register-macro */
t10=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,lf[439],t9);}

/* a9791 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9792(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_9792r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9792r(t0,t1,t2,t3);}}

static void C_ccall f_9792r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(14);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9795,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9900,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2272 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[439],t3,lf[440]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9910,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2275 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[439],t2,lf[442]);}}

/* k9908 in a9791 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2276 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[439],((C_word*)t0)[4],lf[441]);}

/* k9911 in k9908 in a9791 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9913,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[92],t4);
/* eval.scm: 2277 expand */
f_9795(((C_word*)t0)[2],t2,t5);}

/* k9898 in a9791 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
/* eval.scm: 2273 expand */
f_9795(((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* expand in a9791 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9795(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9795,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9799,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(lf[92],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_u_i_cadr(t3);
t9=t4;
f_9799(t9,(C_word)C_i_symbolp(t8));}
else{
t8=t4;
f_9799(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_9799(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_9799(t5,C_SCHEME_FALSE);}}

/* k9797 in expand in a9791 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9799(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[64],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9799,NULL,2,t0,t1);}
t2=(C_truep(*((C_word*)lf[75]+1))?lf[177]:lf[176]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9810,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[92],t8);
t10=t3;
f_9810(t10,(C_word)C_a_i_list(&a,3,lf[38],t4,t9));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t6=t3;
f_9810(t6,(C_word)C_a_i_list(&a,3,lf[41],t4,t5));}
else{
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t5=t3;
f_9810(t5,(C_word)C_a_i_list(&a,3,lf[40],t4,((C_word*)t0)[2]));}}}

/* k9808 in k9797 in expand in a9791 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9810(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9810,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9456,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9773,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2279 ##sys#register-macro */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[313],t3);}

/* a9772 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9773(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_9773r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9773r(t0,t1,t2);}}

static void C_ccall f_9773r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9777,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2282 ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[313],t2,lf[438]);}

/* k9775 in a9772 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9784,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9786,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9785 in k9775 in a9772 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9786,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k9782 in k9775 in a9772 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9784,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[173],t1));}

/* k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9459,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9767,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2288 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[436],t3);}

/* a9766 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9767,3,t0,t1,t2);}
/* eval.scm: 2291 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[436],lf[437]);}

/* k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9462,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9761,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2293 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[434],t3);}

/* a9760 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9761(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9761,3,t0,t1,t2);}
/* eval.scm: 2296 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[434],lf[435]);}

/* k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9462,2,t0,t1);}
t2=lf[413]=C_SCHEME_FALSE;;
t3=C_mutate(&lf[414],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9465,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[416],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9524,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[418],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9533,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[420],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9545,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[421],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9561,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[423],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9587,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[425],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9600,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[426],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9626,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[427],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9663,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[428],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9679,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[429],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9705,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[430],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9727,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[431],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9742,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[131]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9752,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9752,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9759,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2403 ##sys#make-string */
t5=*((C_word*)lf[433]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k9757 in ##sys#make-lambda-info in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9742,4,t0,t1,t2,t3);}
t4=lf[413];
t5=(C_truep(t4)?t4:lf[432]);
/* eval.scm: 2396 store-string */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_9587(t5,t3,t2));}

/* CHICKEN_load in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9727,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9731,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k9729 in CHICKEN_load in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9736,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2393 run-safe */
f_9465(((C_word*)t0)[2],t2);}

/* a9735 in k9729 in CHICKEN_load in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9740,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2393 load */
t3=*((C_word*)lf[236]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9738 in a9735 in k9729 in CHICKEN_load in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9705,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9709,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9707 in CHICKEN_read in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9709,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9714,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2387 run-safe */
f_9465(((C_word*)t0)[2],t3);}

/* a9713 in k9707 in CHICKEN_read in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9718,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2389 open-input-string */
t3=*((C_word*)lf[422]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9716 in a9713 in k9707 in CHICKEN_read in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2390 read */
t3=*((C_word*)lf[226]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k9723 in k9716 in a9713 in k9707 in CHICKEN_read in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2390 store-result */
f_9524(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9679,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9685,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2380 run-safe */
f_9465(t1,t6);}

/* a9684 in CHICKEN_apply_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2382 open-output-string */
t3=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9687 in a9684 in CHICKEN_apply_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9692,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9703,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9701 in k9687 in a9684 in CHICKEN_apply_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2383 write */
t2=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9690 in k9687 in a9684 in CHICKEN_apply_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9699,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2384 get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9697 in k9690 in k9687 in a9684 in CHICKEN_apply_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2384 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9587(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9663,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9669,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2375 run-safe */
f_9465(t1,t5);}

/* a9668 in CHICKEN_apply in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9677,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9675 in a9668 in CHICKEN_apply in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2375 store-result */
f_9524(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9626,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9630,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k9628 in CHICKEN_eval_string_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9630,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9635,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2366 run-safe */
f_9465(((C_word*)t0)[2],t4);}

/* a9634 in k9628 in CHICKEN_eval_string_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2368 open-output-string */
t3=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9637 in a9634 in k9628 in CHICKEN_eval_string_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9642,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9653,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9657,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9661,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2369 open-input-string */
t6=*((C_word*)lf[422]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k9659 in k9637 in a9634 in k9628 in CHICKEN_eval_string_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2369 read */
t2=*((C_word*)lf[226]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9655 in k9637 in a9634 in k9628 in CHICKEN_eval_string_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2369 eval */
t2=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9651 in k9637 in a9634 in k9628 in CHICKEN_eval_string_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2369 write */
t2=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9640 in k9637 in a9634 in k9628 in CHICKEN_eval_string_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9649,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2370 get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9647 in k9640 in k9637 in a9634 in k9628 in CHICKEN_eval_string_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2370 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9587(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9600,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9606,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2357 run-safe */
f_9465(t1,t5);}

/* a9605 in CHICKEN_eval_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2359 open-output-string */
t3=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9608 in a9605 in CHICKEN_eval_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9613,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9624,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2360 eval */
t4=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9622 in k9608 in a9605 in CHICKEN_eval_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2360 write */
t2=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9611 in k9608 in a9605 in CHICKEN_eval_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2361 get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9618 in k9611 in k9608 in a9605 in CHICKEN_eval_to_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2361 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9587(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static C_word C_fcall f_9587(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[413],lf[424]);
return(C_SCHEME_FALSE);}
else{
return((C_word)C_copy_result_string(t1,t3,t4));}}

/* CHICKEN_eval_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9561(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9561,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9565,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9563 in CHICKEN_eval_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9565,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9570,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2338 run-safe */
f_9465(((C_word*)t0)[2],t3);}

/* a9569 in k9563 in CHICKEN_eval_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9574,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2340 open-input-string */
t3=*((C_word*)lf[422]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9572 in a9569 in k9563 in CHICKEN_eval_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9585,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2341 read */
t4=*((C_word*)lf[226]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k9583 in k9572 in a9569 in k9563 in CHICKEN_eval_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2341 eval */
t2=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9579 in k9572 in a9569 in k9563 in CHICKEN_eval_string in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2341 store-result */
f_9524(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9545,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9551,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2333 run-safe */
f_9465(t1,t4);}

/* a9550 in CHICKEN_eval in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9559,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2335 eval */
t3=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9557 in a9550 in CHICKEN_eval in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2335 store-result */
f_9524(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9539,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2330 run-safe */
f_9465(t1,t2);}

/* a9538 in CHICKEN_yield in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9543,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2330 thread-yield! */
t3=*((C_word*)lf[419]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9541 in a9538 in CHICKEN_yield in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9524(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9524,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9528,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2324 ##sys#gc */
t5=*((C_word*)lf[417]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}

/* k9526 in store-result in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* run-safe in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9465(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9465,NULL,2,t1,t2);}
t3=lf[413]=C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9473,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9475,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2312 call-with-current-continuation */
t6=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a9474 in run-safe in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9475,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9481,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9500,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2312 with-exception-handler */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a9499 in a9474 in run-safe in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9506,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9512,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2312 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a9511 in a9499 in a9474 in run-safe in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9512(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_9512r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9512r(t0,t1,t2);}}

static void C_ccall f_9512r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9518,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2312 g1481 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9517 in a9511 in a9499 in a9474 in run-safe in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9518,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a9505 in a9499 in a9474 in run-safe in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9506,2,t0,t1);}
/* eval.scm: 2317 thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a9480 in a9474 in run-safe in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9481,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9487,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2312 g1481 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9486 in a9480 in a9474 in run-safe in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9491,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2313 open-output-string */
t3=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9489 in a9486 in a9480 in a9474 in run-safe in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9494,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2314 print-error-message */
t3=*((C_word*)lf[415]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k9492 in k9489 in a9486 in a9480 in a9474 in run-safe in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9498,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2315 get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9496 in k9492 in k9489 in a9486 in a9480 in a9474 in run-safe in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[413],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k9471 in run-safe in k9460 in k9457 in k9454 in k9451 in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9378,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9388,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2244 read-char */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* eval.scm: 2256 old */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k9386 in ##sys#user-read-hook in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9391,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2245 read */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9389 in k9386 in ##sys#user-read-hook in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9392,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9405,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_9405(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_9405(t6,(C_word)C_i_not(t5));}}

/* k9403 in k9389 in k9386 in ##sys#user-read-hook in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9405,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 2248 err */
t2=((C_word*)t0)[5];
f_9392(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9423,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2252 ##sys#hash-table-ref */
t4=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[406]+1),t2);}
else{
/* eval.scm: 2251 err */
t3=((C_word*)t0)[5];
f_9392(t3,((C_word*)t0)[4]);}}}

/* k9421 in k9403 in k9389 in k9386 in ##sys#user-read-hook in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 2255 ##sys#read-error */
t2=*((C_word*)lf[410]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[412],((C_word*)t0)[2]);}}

/* err in k9389 in k9386 in ##sys#user-read-hook in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9392,NULL,2,t0,t1);}
/* eval.scm: 2246 ##sys#read-error */
t2=*((C_word*)lf[410]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[411],((C_word*)t0)[2]);}

/* define-reader-ctor in k9365 in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9369,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[407]);
/* eval.scm: 2236 ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[406]+1),t2,t3);}

/* repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9031,tmp=(C_word)a,a+=2,tmp);
t3=*((C_word*)lf[393]+1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[386]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[392]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9072,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t8,a[11]=t6,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 2146 ##sys#error-handler */
t10=*((C_word*)lf[397]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9075,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 2147 ##sys#reset-handler */
t3=*((C_word*)lf[405]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9075,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[136]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9077,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9083,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9092,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9157,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9352,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2161 ##sys#dynamic-wind */
t10=*((C_word*)lf[239]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t7,t8,t9);}

/* a9351 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9356,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2224 load-verbose */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k9354 in a9351 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9356,2,t0,t1);}
t2=C_mutate((C_word*)lf[136]+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9360,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2226 ##sys#error-handler */
t4=*((C_word*)lf[397]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9358 in k9354 in a9351 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2227 ##sys#reset-handler */
t2=*((C_word*)lf[405]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9157,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_9163(t5,t1);}

/* loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9163(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9163,NULL,2,t0,t1);}
t2=f_9077(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9170,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9335,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2184 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9334 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9335(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9335,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9341,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2186 ##sys#reset-handler */
t4=*((C_word*)lf[405]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9340 in a9334 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9341,2,t0,t1);}
t2=C_set_block_item(lf[231],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[404],0,C_SCHEME_TRUE);
t4=f_9083(((C_word*)t0)[3]);
/* eval.scm: 2191 c */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,C_SCHEME_FALSE);}

/* k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2192 ##sys#read-prompt-hook */
t3=*((C_word*)lf[384]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[378]+1);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9176,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9185,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9330,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2195 ##sys#peek-char-0 */
t4=*((C_word*)lf[403]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[393]+1));}}

/* k9328 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 2196 ##sys#read-char-0 */
t3=*((C_word*)lf[402]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[393]+1));}
else{
t3=((C_word*)t0)[2];
f_9185(2,t3,C_SCHEME_UNDEFINED);}}

/* k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2197 ##sys#clear-trace-buffer */
t3=*((C_word*)lf[387]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9188,2,t0,t1);}
t2=C_set_block_item(lf[136],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9194,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9203,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2199 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9203(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_9203r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9203r(t0,t1,t2);}}

static void C_ccall f_9203r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9207,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(*((C_word*)lf[398]+1))?(C_word)C_i_pairp(*((C_word*)lf[136]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9221,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_9221(t8,t3,*((C_word*)lf[136]+1),C_SCHEME_END_OF_LIST);}
else{
t5=t3;
f_9207(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9221(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9221,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9225,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9237,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2204 ##sys#print */
t6=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[401],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}
else{
t5=t4;
f_9225(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_u_i_memq(t5,t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9284,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9284(2,t8,t6);}
else{
t8=(C_word)C_u_i_caar(t2);
/* eval.scm: 2218 ##sys#symbol-has-toplevel-binding? */
t9=*((C_word*)lf[147]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}}

/* k9282 in loop in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9284,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 2219 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9221(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* eval.scm: 2220 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9221(t5,((C_word*)t0)[3],t2,t4);}}

/* k9235 in loop in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9242,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9241 in k9235 in loop in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9242,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9246,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2209 ##sys#print */
t4=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[400],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}

/* k9244 in a9241 in k9235 in loop in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* eval.scm: 2210 ##sys#print */
t4=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[392]+1));}

/* k9247 in k9244 in a9241 in k9235 in loop in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9252,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9261,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2212 ##sys#print */
t4=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[399],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}
else{
t3=t2;
f_9252(2,t3,C_SCHEME_UNDEFINED);}}

/* k9259 in k9247 in k9244 in a9241 in k9235 in loop in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9264,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 2213 ##sys#print */
t4=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[392]+1));}

/* k9262 in k9259 in k9247 in k9244 in a9241 in k9235 in loop in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2214 ##sys#write-char-0 */
t2=*((C_word*)lf[380]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(41),*((C_word*)lf[392]+1));}

/* k9250 in k9247 in k9244 in a9241 in k9235 in loop in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2215 ##sys#write-char-0 */
t2=*((C_word*)lf[380]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[392]+1));}

/* k9223 in loop in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(9));}

/* k9205 in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9053,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_9053(t6,t4);}
else{
t6=(C_word)C_u_i_car(t3);
t7=t5;
f_9053(t7,(C_word)C_eqp(C_SCHEME_UNDEFINED,t6));}}

/* k9051 in k9205 in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9053,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_9210(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9058,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* a9057 in k9051 in k9205 in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9058,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[379]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[386]+1));}

/* k9208 in k9205 in a9202 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2222 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9163(t2,((C_word*)t0)[2]);}

/* a9193 in k9186 in k9183 in k9174 in k9171 in k9168 in loop in a9156 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9194,2,t0,t1);}
t2=*((C_word*)lf[376]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,((C_word*)t0)[2]);}

/* a9091 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9097,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 2163 load-verbose */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9095 in a9091 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9097,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9100,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2164 load-verbose */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}

/* k9098 in k9095 in a9091 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9105,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2165 ##sys#error-handler */
t3=*((C_word*)lf[397]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* a9104 in k9098 in k9095 in a9091 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9105(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_9105r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9105r(t0,t1,t2,t3);}}

static void C_ccall f_9105r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=f_9083(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9112,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 2168 ##sys#print */
t6=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[396],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}

/* k9110 in a9104 in k9098 in k9095 in a9091 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9152,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2170 ##sys#print */
t4=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[395],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}
else{
t3=t2;
f_9115(2,t3,C_SCHEME_UNDEFINED);}}

/* k9150 in k9110 in a9104 in k9098 in k9095 in a9091 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2171 ##sys#print */
t2=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}

/* k9113 in k9110 in a9104 in k9098 in k9095 in a9091 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9118,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9127,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=t3;
f_9127(t5,(C_word)C_i_nullp(t4));}
else{
t4=t3;
f_9127(t4,C_SCHEME_FALSE);}}

/* k9125 in k9113 in k9110 in a9104 in k9098 in k9095 in a9091 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9127,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2174 ##sys#print */
t3=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[394],C_SCHEME_FALSE,*((C_word*)lf[392]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2177 ##sys#write-char-0 */
t3=*((C_word*)lf[380]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[392]+1));}}

/* k9134 in k9125 in k9113 in k9110 in a9104 in k9098 in k9095 in a9091 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2178 write-err */
f_9031(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9128 in k9125 in k9113 in k9110 in a9104 in k9098 in k9095 in a9091 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2175 write-err */
f_9031(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9116 in k9113 in k9110 in a9104 in k9098 in k9095 in a9091 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2179 print-call-chain */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[392]+1));}

/* k9119 in k9116 in k9113 in k9110 in a9104 in k9098 in k9095 in a9091 in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2180 flush-output */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[392]+1));}

/* resetports in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static C_word C_fcall f_9083(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate((C_word*)lf[393]+1,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[386]+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[392]+1,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k9073 in k9070 in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static C_word C_fcall f_9077(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[393]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[386]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[392]+1));
return(t3);}

/* write-err in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_9031(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9031,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9037,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a9036 in write-err in repl in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9037,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[379]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[392]+1));}

/* ##sys#clear-trace-buffer in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9025,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1365(C_SCHEME_UNDEFINED));}

/* ##sys#read-prompt-hook in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9013,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9020,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9023,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2121 repl-prompt */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k9021 in ##sys#read-prompt-hook in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k9018 in ##sys#read-prompt-hook in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2121 ##sys#print */
t2=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,*((C_word*)lf[386]+1));}

/* k9011 in ##sys#read-prompt-hook in k9005 in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_9013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2122 ##sys#flush-output */
t2=*((C_word*)lf[385]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[386]+1));}

/* ##sys#repl-print-hook in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8990,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8994,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8999,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2113 ##sys#with-print-length-limit */
t6=*((C_word*)lf[382]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[377]+1),t5);}

/* a8998 in ##sys#repl-print-hook in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8999,2,t0,t1);}
/* ##sys#print */
t2=*((C_word*)lf[381]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k8992 in ##sys#repl-print-hook in k8983 in k8979 in k8976 in k8973 in k8970 in k8967 in k8964 in k8961 in k8958 in k8955 in k8952 in k8949 in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2114 ##sys#write-char-0 */
t2=*((C_word*)lf[380]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5rv,(void*)f_8559r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_8559r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_8559r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8574,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8562,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8605,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8667,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8696,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t8,a[6]=t9,a[7]=t7,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_notvemptyp(t5))){
t11=(C_word)C_slot(t5,C_fix(0));
t12=C_mutate((C_word*)lf[211]+1,t11);
t13=t10;
f_8696(t13,t12);}
else{
t11=t10;
f_8696(t11,C_SCHEME_UNDEFINED);}}

/* k8694 in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8696(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8696,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8701,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_8701(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k8694 in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8701(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a;
loop:
a=C_alloc(19);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8701,NULL,4,t0,t1,t2,t3);}
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_vectorp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_block_size(t3);
t7=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t8=(C_truep(t7)?(C_word)C_slot(t3,C_fix(1)):C_fix(0));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8717,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_eqp(t6,C_fix(1));
if(C_truep(t10)){
t11=t9;
f_8717(t11,C_fix(1));}
else{
t11=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t12=t9;
f_8717(t12,(C_truep(t11)?(C_word)C_slot(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_blockp(t3))){
if(C_truep((C_word)C_symbolp(t3))){
t5=t3;
t6=(C_word)C_eqp(t5,lf[354]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_eqp(t5,lf[355]);
if(C_truep(t7)){
/* eval.scm: 1825 test */
t8=((C_word*)t0)[4];
f_8562(t8,t1,t2,*((C_word*)lf[356]+1),lf[357]);}
else{
t8=(C_word)C_eqp(t5,lf[358]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8846,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1826 test */
t10=((C_word*)t0)[4];
f_8562(t10,t1,t2,t9,lf[359]);}
else{
t9=(C_word)C_eqp(t5,lf[360]);
if(C_truep(t9)){
/* eval.scm: 1827 test */
t10=((C_word*)t0)[4];
f_8562(t10,t1,t2,*((C_word*)lf[361]+1),lf[362]);}
else{
t10=(C_word)C_eqp(t5,lf[363]);
if(C_truep(t10)){
/* eval.scm: 1828 test */
t11=((C_word*)t0)[4];
f_8562(t11,t1,t2,((C_word*)t0)[3],lf[364]);}
else{
t11=(C_word)C_eqp(t5,lf[365]);
if(C_truep(t11)){
/* eval.scm: 1829 test */
t12=((C_word*)t0)[4];
f_8562(t12,t1,t2,*((C_word*)lf[366]+1),lf[367]);}
else{
t12=(C_word)C_eqp(t5,lf[368]);
if(C_truep(t12)){
/* eval.scm: 1830 test */
t13=((C_word*)t0)[4];
f_8562(t13,t1,t2,*((C_word*)lf[369]+1),lf[370]);}
else{
t13=(C_word)C_eqp(t5,lf[371]);
if(C_truep(t13)){
/* eval.scm: 1831 test */
t14=((C_word*)t0)[4];
f_8562(t14,t1,t2,((C_word*)t0)[2],lf[372]);}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8900,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1832 test */
t15=((C_word*)t0)[4];
f_8562(t15,t1,t2,t14,lf[373]);}}}}}}}}}
else{
t5=(C_word)C_i_not((C_word)C_blockp(t2));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t6)){
/* eval.scm: 1834 err */
t7=((C_word*)t0)[6];
f_8574(t7,t1,lf[374]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8919,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 1836 walk */
t30=t7;
t31=t8;
t32=t9;
t1=t30;
t2=t31;
t3=t32;
goto loop;}}}
else{
t5=(C_word)C_eqp(t3,t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1821 err */
t6=((C_word*)t0)[6];
f_8574(t6,t1,lf[375]);}}}}

/* k8917 in walk in k8694 in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1837 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8701(t4,((C_word*)t0)[2],t2,t3);}

/* a8899 in walk in k8694 in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8900,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* a8845 in walk in k8694 in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8846(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8846,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_symbolp(t2));}

/* k8715 in walk in k8694 in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8717,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8722,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_8722(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do1218 in k8715 in walk in k8694 in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8722(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8722,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* eval.scm: 1814 err */
t5=((C_word*)t0)[6];
f_8574(t5,t1,lf[351]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8741,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* eval.scm: 1816 err */
t6=((C_word*)t0)[6];
f_8574(t6,t5,lf[352]);}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* eval.scm: 1818 err */
t8=((C_word*)t0)[6];
f_8574(t8,t5,lf[353]);}
else{
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1819 walk */
t9=((C_word*)((C_word*)t0)[3])[1];
f_8701(t9,t5,t8,((C_word*)t0)[2]);}}}}

/* k8739 in do1218 in k8715 in walk in k8694 in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8722(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8667(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8667,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8673,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_8673(t2));}

/* loop in proper-list? in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static C_word C_fcall f_8673(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_pairp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8605,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8609,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1781 ##sys#extended-lambda-list? */
t4=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8607 in lambda-list? in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8609,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8617,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_8617(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k8607 in lambda-list? in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8617(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8617,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8640,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1785 keyword? */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_symbolp(t4)));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1790 loop */
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k8638 in loop in k8607 in lambda-list? in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8562(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8562,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8569,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1769 pred */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k8567 in test in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1769 err */
t2=((C_word*)t0)[3];
f_8574(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8574(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8574,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[211]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8578,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1773 get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k8576 in err in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8585,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8592,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1776 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8603,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1777 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k8601 in k8576 in err in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1777 string-append */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[349],t1,lf[350],((C_word*)t0)[2]);}

/* k8590 in k8576 in err in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8596,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1776 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k8594 in k8590 in k8576 in err in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1776 string-append */
t2=((C_word*)t0)[5];
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[4],lf[346],((C_word*)t0)[3],lf[347],t1,lf[348],((C_word*)t0)[2]);}

/* k8583 in k8576 in err in ##sys#check-syntax in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1774 ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8523(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8523,3,t0,t1,t2);}
if(C_truep(*((C_word*)lf[340]+1))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8545,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1755 ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[340]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k8543 in get-line-number in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8515(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_8515r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8515r(t0,t1,t2);}}

static void C_ccall f_8515r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[224]+1),lf[341],t2);}

/* ##sys#display-times in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8461,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8465,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1730 display-rj */
t5=((C_word*)t0)[2];
f_8440(t5,t3,t4,C_fix(8));}

/* k8463 in ##sys#display-times in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1731 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[339]);}

/* k8466 in k8463 in ##sys#display-times in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1732 display-rj */
t4=((C_word*)t0)[2];
f_8440(t4,t2,t3,C_fix(8));}

/* k8469 in k8466 in k8463 in ##sys#display-times in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1733 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[338]);}

/* k8472 in k8469 in k8466 in k8463 in ##sys#display-times in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1734 display-rj */
t4=((C_word*)t0)[2];
f_8440(t4,t2,t3,C_fix(8));}

/* k8475 in k8472 in k8469 in k8466 in k8463 in ##sys#display-times in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1735 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[337]);}

/* k8478 in k8475 in k8472 in k8469 in k8466 in k8463 in ##sys#display-times in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1736 display-rj */
t4=((C_word*)t0)[2];
f_8440(t4,t2,t3,C_fix(8));}

/* k8481 in k8478 in k8475 in k8472 in k8469 in k8466 in k8463 in ##sys#display-times in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1737 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[336]);}

/* k8484 in k8481 in k8478 in k8475 in k8472 in k8469 in k8466 in k8463 in ##sys#display-times in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8489,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1738 display-rj */
t4=((C_word*)t0)[2];
f_8440(t4,t2,t3,C_fix(8));}

/* k8487 in k8484 in k8481 in k8478 in k8475 in k8472 in k8469 in k8466 in k8463 in ##sys#display-times in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1739 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[335]);}

/* display-rj in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8440(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8440,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8444,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_8444(2,t5,lf[334]);}
else{
/* eval.scm: 1725 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k8442 in display-rj in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8444,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8447,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1727 spaces */
t5=((C_word*)t0)[2];
f_8416(t5,t3,t4);}

/* k8445 in k8442 in display-rj in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1728 display */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8416(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8416,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8422,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8422(t6,t1,t2);}

/* do1148 in spaces in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8422(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8422,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8432,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1722 display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k8430 in do1148 in spaces in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8422(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4rv,(void*)f_8293r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_8293r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8293r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8299,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8334,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8351,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1703 test */
t12=t10;
f_8334(t12,t11,t2);}

/* k8349 in ##sys#resolve-include-filename in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8351,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8361,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8402,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1705 ##sys#repository-path */
t4=*((C_word*)lf[280]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_8361(2,t3,*((C_word*)lf[285]+1));}}}

/* k8400 in k8349 in ##sys#resolve-include-filename in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8402,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1705 ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],*((C_word*)lf[285]+1),t2);}

/* k8359 in k8349 in ##sys#resolve-include-filename in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8361,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8363,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_8363(t5,((C_word*)t0)[2],t1);}

/* loop in k8359 in k8349 in ##sys#resolve-include-filename in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8363(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8363,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8373,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8387,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1708 string-append */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,lf[333],((C_word*)t0)[5]);}}

/* k8385 in loop in k8359 in k8349 in ##sys#resolve-include-filename in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1708 test */
t2=((C_word*)t0)[3];
f_8334(t2,((C_word*)t0)[2],t1);}

/* k8371 in loop in k8359 in k8349 in ##sys#resolve-include-filename in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1711 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8363(t3,((C_word*)t0)[4],t2);}}

/* test in ##sys#resolve-include-filename in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8334(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8334,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[17],*((C_word*)lf[250]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[250]+1),lf[17]));
/* eval.scm: 1698 test2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8299(t4,t1,t2,t3);}

/* test2 in ##sys#resolve-include-filename in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8299(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8299,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8312,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1692 exists? */
f_8274(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8315,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* eval.scm: 1693 ##sys#string-append */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}}

/* k8313 in test2 in ##sys#resolve-include-filename in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8321,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1694 exists? */
f_8274(t2,t1);}

/* k8319 in k8313 in test2 in ##sys#resolve-include-filename in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1696 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8299(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k8310 in test2 in ##sys#resolve-include-filename in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8274(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8274,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8278,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1687 ##sys#file-info */
t4=*((C_word*)lf[249]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8276 in exists? in k8266 in k8262 in k8259 in k8255 in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8241(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8241,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8243,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_8243 in initb in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8243(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8243,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8247,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1648 ##sys#hash-table-location */
t4=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8245 */
static void C_ccall f_8247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8203(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8203r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8203r(t0,t1,t2,t3);}}

static void C_ccall f_8203r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[331]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8210,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t2,C_fix(4));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greaterp(t2,C_fix(5)));
if(C_truep(t7)){
/* eval.scm: 1639 ##sys#error */
t8=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[331],lf[332],t2);}
else{
t8=t5;
f_8210(2,t8,C_SCHEME_UNDEFINED);}}

/* k8208 in null-environment in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1642 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8215 in k8208 in null-environment in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8217,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(0)):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[322],t1,t3));}

/* scheme-report-environment in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8159(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8159r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8159r(t0,t1,t2,t3);}}

static void C_ccall f_8159r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_exact_2(t2,lf[328]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=t2;
switch(t7){
case C_fix(4):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8179,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1630 ##sys#copy-env-table */
t9=*((C_word*)lf[324]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[320],C_SCHEME_TRUE,t6);
case C_fix(5):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8192,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1631 ##sys#copy-env-table */
t9=*((C_word*)lf[324]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[321],C_SCHEME_TRUE,t6);
default:
/* eval.scm: 1632 ##sys#error */
t8=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[328],lf[329],t2);}}

/* k8190 in scheme-report-environment in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8192,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[322],t1,((C_word*)t0)[2]));}

/* k8177 in scheme-report-environment in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8179,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[322],t1,((C_word*)t0)[2]));}

/* interaction-environment in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8156,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[323]);}

/* ##sys#environment-symbols in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8037(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8037r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8037r(t0,t1,t2,t3);}}

static void C_ccall f_8037r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(18);
t4=(C_word)C_i_check_structure(t2,lf[322]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t7)){
t8=(C_word)C_fix((C_word)C_header_size(t7));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8058,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8058(t12,t1,C_fix(0),C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8129,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8131,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1617 ##sys#walk-namespace */
t12=*((C_word*)lf[326]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}

/* a8130 in ##sys#environment-symbols in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8131(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8131,3,t0,t1,t2);}
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8141,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_8141(2,t5,t3);}
else{
/* eval.scm: 1619 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k8139 in a8130 in ##sys#environment-symbols in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8141,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8127 in ##sys#environment-symbols in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* do1079 in ##sys#environment-symbols in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8058(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8058,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8076,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(((C_word*)t0)[3],t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8082,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_8082(t10,t5,t6,t3);}}

/* loop in do1079 in ##sys#environment-symbols in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_8082(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8082,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_i_not(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8101,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_8101(2,t8,t6);}
else{
/* eval.scm: 1611 pred */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t5);}}}

/* k8099 in loop in do1079 in ##sys#environment-symbols in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8101,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* eval.scm: 1612 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8082(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1613 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8082(t3,((C_word*)t0)[2],t2,((C_word*)t0)[4]);}}

/* k8074 in do1079 in ##sys#environment-symbols in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_8058(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#copy-env-table in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5rv,(void*)f_7929r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_7929r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_7929r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7939,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t2,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1578 ##sys#make-vector */
t10=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t8,C_SCHEME_END_OF_LIST);}

/* k7937 in ##sys#copy-env-table in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7939,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7944(t5,((C_word*)t0)[2],C_fix(0));}

/* do1062 in k7937 in ##sys#copy-env-table in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7944(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7944,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7965,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7971,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_7971(t8,t3,t4);}}

/* copy in do1062 in k7937 in ##sys#copy-env-table in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7971(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7971,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_i_not(((C_word*)t0)[5]);
t6=(C_truep(t5)?t5:(C_word)C_u_i_memq(t4,((C_word*)t0)[5]));
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:(C_word)C_slot(t3,C_fix(2)));
t9=(C_word)C_a_i_vector(&a,3,t4,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8004,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1593 copy */
t14=t10;
t15=t11;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1594 copy */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k8002 in copy in do1062 in k7937 in ##sys#copy-env-table in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_8004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8004,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7963 in do1062 in k7937 in ##sys#copy-env-table in k7920 in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7944(t4,((C_word*)t0)[2],t3);}

/* ##sys#string->c-identifier in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7866,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7870,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1559 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7868 in ##sys#string->c-identifier in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7870,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7878,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7878(t6,((C_word*)t0)[2],C_fix(0));}

/* do1047 in k7868 in ##sys#string->c-identifier in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7878(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7878,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7898,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_alphabeticp(t3))){
t5=t4;
f_7898(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_char_numericp(t3);
t6=(C_word)C_i_not(t5);
t7=t4;
f_7898(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,C_fix(0))));}}}

/* k7896 in do1047 in k7868 in ##sys#string->c-identifier in k7862 in k7859 in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],C_make_character(95)):C_SCHEME_UNDEFINED);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7878(t4,((C_word*)t0)[2],t3);}

/* set-extension-specifier! in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7822,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[318]);
t5=(C_word)C_u_i_assq(t2,*((C_word*)lf[315]+1));
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7840,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t5,C_fix(1),t7));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7854,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,*((C_word*)lf[315]+1));
t9=C_mutate((C_word*)lf[315]+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* a7853 in set-extension-specifier! in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7854,3,t0,t1,t2);}
/* eval.scm: 1514 proc */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* a7839 in set-extension-specifier! in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7840,3,t0,t1,t2);}
/* eval.scm: 1512 proc */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7423,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7426,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7447,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7698,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_u_i_car(t2);
t8=t6;
f_7698(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_7698(t7,C_SCHEME_FALSE);}}

/* k7696 in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7698(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7698,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_u_i_assq(t2,*((C_word*)lf[315]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7707,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[6]);}
else{
/* eval.scm: 1500 ##sys#error */
t4=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],lf[316],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
/* eval.scm: 1502 doit */
t2=((C_word*)t0)[2];
f_7447(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
/* eval.scm: 1503 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[317],((C_word*)t0)[6]);}}}

/* k7705 in k7696 in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7707,2,t0,t1);}
if(C_truep((C_word)C_i_stringp(t1))){
t2=(C_word)C_a_i_list(&a,2,lf[236],t1);
/* eval.scm: 1488 values */
C_values(4,0,((C_word*)t0)[4],t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7733,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1490 vector->list */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
/* eval.scm: 1499 ##sys#do-the-right-thing */
t2=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3]);}}}

/* k7731 in k7705 in k7696 in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7733,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7735,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7735(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k7731 in k7705 in k7696 in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7735(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7735,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7753,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1494 reverse */
t6=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7758,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7768,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1495 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a7767 in loop in k7731 in k7705 in k7696 in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7768,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t6=(C_truep(t3)?t3:((C_word*)t0)[3]);
/* eval.scm: 1496 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7735(t7,t1,t4,t5,t6);}

/* a7757 in loop in k7731 in k7705 in k7696 in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7758,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* eval.scm: 1495 ##sys#do-the-right-thing */
t3=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k7751 in loop in k7731 in k7705 in k7696 in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7753,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1494 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7447(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7447,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_memq(t2,lf[28]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7457(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
t5=t4;
f_7457(2,t5,(C_word)C_u_i_memq(t2,lf[30]));}
else{
/* eval.scm: 1441 ##sys#feature? */
t5=*((C_word*)lf[314]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}}

/* k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[47],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7457,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1442 values */
C_values(4,0,((C_word*)t0)[5],lf[306],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[307]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[308]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7469,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1444 ##sys#->feature-id */
t4=*((C_word*)lf[270]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[2]+1)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7506,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,2,lf[311],((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,lf[90],t4);
t6=t3;
f_7506(t6,(C_word)C_a_i_list(&a,2,lf[183],t5));}
else{
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[4]);
t5=t3;
f_7506(t5,(C_word)C_a_i_list(&a,2,lf[271],t4));}}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[4]+1)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7533,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1456 ##sys#extension-information */
t4=*((C_word*)lf[296]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[313]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1466 ##sys#extension-information */
t4=*((C_word*)lf[296]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[313]);}}}}}

/* k7589 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7591,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[312],t1);
t3=(C_word)C_u_i_assq(lf[300],t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7603,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
/* eval.scm: 1470 add-req */
t5=((C_word*)t0)[2];
f_7426(t5,t4,((C_word*)t0)[3]);}
else{
t5=t4;
f_7603(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7672,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1482 add-req */
t3=((C_word*)t0)[2];
f_7426(t3,t2,((C_word*)t0)[3]);}}

/* k7670 in k7589 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7672,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[171],t2);
/* eval.scm: 1483 values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_FALSE);}

/* k7601 in k7589 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7614,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[169],t4);
t6=t3;
f_7618(t6,(C_word)C_a_i_list(&a,1,t5));}
else{
t4=t3;
f_7618(t4,C_SCHEME_END_OF_LIST);}}

/* k7616 in k7601 in k7589 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7618,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7622,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[4])?C_SCHEME_FALSE:((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_7622(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7636,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7638,tmp=(C_word)a,a+=2,tmp);
t6=(C_truep(((C_word*)t0)[4])?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* map */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a7637 in k7616 in k7601 in k7589 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7638,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k7634 in k7616 in k7601 in k7589 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7636,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[171],t1);
t3=((C_word*)t0)[2];
f_7622(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k7620 in k7616 in k7601 in k7589 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7622(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1427 ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7612 in k7601 in k7589 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7614,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1471 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7531 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7533,2,t0,t1);}
t2=(C_word)C_u_i_assq(lf[312],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7547,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,lf[169],t5);
t7=t4;
f_7551(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t4;
f_7551(t5,C_SCHEME_END_OF_LIST);}}

/* k7549 in k7531 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7551,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7559,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_list(&a,2,lf[311],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,2,lf[90],t3);
t5=t2;
f_7559(t5,(C_word)C_a_i_list(&a,2,lf[183],t4));}
else{
t3=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t4=t2;
f_7559(t4,(C_word)C_a_i_list(&a,2,lf[271],t3));}}

/* k7557 in k7549 in k7531 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7559(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7559,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1427 ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7545 in k7531 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7547,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1458 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7504 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1450 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7467 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7472,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(t1,*((C_word*)lf[186]+1)))){
t3=t2;
f_7472(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7481,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7489,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7493,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1446 ##sys#symbol->string */
t6=*((C_word*)lf[276]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k7491 in k7467 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1446 ##sys#resolve-include-filename */
t2=*((C_word*)lf[310]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7487 in k7467 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1446 ##sys#load */
t2=*((C_word*)lf[230]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7479 in k7467 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7481,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[186]+1));
t3=C_mutate((C_word*)lf[186]+1,t2);
t4=((C_word*)t0)[2];
f_7472(t4,t3);}

/* k7470 in k7467 in k7455 in doit in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1448 values */
C_values(4,0,((C_word*)t0)[2],lf[309],C_SCHEME_TRUE);}

/* add-req in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7426(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7426,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7435,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7441,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1432 ##sys#hash-table-update! */
t5=*((C_word*)lf[121]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,*((C_word*)lf[304]+1),lf[305],t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a7440 in add-req in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7441,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a7434 in add-req in ##sys#do-the-right-thing in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7435(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7435,3,t0,t1,t2);}
/* lset-adjoin */
t3=*((C_word*)lf[302]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[303]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7374(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7374,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7380,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7380(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7380(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7380,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7394,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 1421 ##sys#extension-information */
t5=*((C_word*)lf[296]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k7392 in loop1 in ##sys#lookup-runtime-requirements in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_assq(lf[300],t1);
t4=t2;
f_7397(t4,(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE));}
else{
t3=t2;
f_7397(t3,C_SCHEME_FALSE);}}

/* k7395 in k7392 in loop1 in ##sys#lookup-runtime-requirements in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7397,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7404,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1425 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7380(t5,t3,t4);}

/* k7402 in k7395 in k7392 in loop1 in ##sys#lookup-runtime-requirements in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1420 append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-information in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7368(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7368,3,t0,t1,t2);}
/* eval.scm: 1411 ##sys#extension-information */
t3=*((C_word*)lf[296]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[299]);}

/* ##sys#extension-information in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7337,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1404 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[274]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k7339 in ##sys#extension-information in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7366,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1405 ##sys#repository-path */
t4=*((C_word*)lf[280]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7364 in k7339 in ##sys#extension-information in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1405 string-append */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],t1,lf[297],((C_word*)t0)[2],lf[298]);}

/* k7342 in k7339 in ##sys#extension-information in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7347,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7362,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1406 string-append */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[20]);}

/* k7360 in k7342 in k7339 in ##sys#extension-information in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1406 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7345 in k7342 in k7339 in ##sys#extension-information in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7347,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7354,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7354 in k7345 in k7342 in k7339 in ##sys#extension-information in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7354,3,t0,t1,t2);}
/* with-input-from-file952 */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#require in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7324(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7324r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7324r(t0,t1,t2);}}

static void C_ccall f_7324r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7330,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7329 in ##sys#require in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7330,3,t0,t1,t2);}
/* ##sys#load-extension */
t3=*((C_word*)lf[289]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[295]);}

/* ##sys#provided? in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7310,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7321,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1385 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[274]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[294]);}

/* k7319 in ##sys#provided? in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[287]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7290(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7290r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7290r(t0,t1,t2);}}

static void C_ccall f_7290r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7296,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7295 in ##sys#provide in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7296,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[292]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7303,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1378 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[274]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[292]);}

/* k7301 in a7295 in ##sys#provide in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7303,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[287]+1));
t3=C_mutate((C_word*)lf[287]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_7222r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7222r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7222r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7226,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t5)[1]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7285,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1359 string->symbol */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t5)[1]);}
else{
t7=t6;
f_7226(t7,(C_word)C_i_check_symbol_2(((C_word*)t5)[1],t3));}}

/* k7283 in ##sys#load-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7226(t3,t2);}

/* k7224 in ##sys#load-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7226,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1361 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[274]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}

/* k7227 in k7224 in ##sys#load-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7229,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[287]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[2]+1)))){
/* eval.scm: 1364 ##sys#load-library */
t3=*((C_word*)lf[264]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7247,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1366 ##sys#find-extension */
t4=*((C_word*)lf[283]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k7245 in k7227 in k7224 in ##sys#load-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7247,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7253,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1368 ##sys#load */
t3=*((C_word*)lf[230]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_u_i_car(t2));
if(C_truep(t4)){
/* eval.scm: 1371 ##sys#error */
t5=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[3],lf[290],((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}

/* k7251 in k7245 in k7227 in k7224 in ##sys#load-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7253,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[287]+1));
t3=C_mutate((C_word*)lf[287]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* ##sys#find-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7145,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7148,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7179,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7219,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1347 ##sys#repository-path */
t7=*((C_word*)lf[280]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k7217 in ##sys#find-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7219,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7212,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1348 ##sys#append */
t4=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[285]+1),lf[286]);}
else{
t4=t3;
f_7212(2,t4,C_SCHEME_END_OF_LIST);}}

/* k7210 in k7217 in ##sys#find-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1347 ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7177 in ##sys#find-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7179,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7181,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7181(t5,((C_word*)t0)[2],t1);}

/* loop in k7177 in ##sys#find-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7181(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7181,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7194,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1351 check */
t5=((C_word*)t0)[2];
f_7148(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7192 in loop in k7177 in ##sys#find-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1352 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7181(t3,((C_word*)t0)[4],t2);}}

/* check in ##sys#find-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7148(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7148,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7152,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1343 string-append */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[284],((C_word*)t0)[2]);}

/* k7150 in check in ##sys#find-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7158,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7172,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1344 ##sys#string-append */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,*((C_word*)lf[250]+1));}

/* k7170 in k7150 in check in ##sys#find-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1344 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7156 in k7150 in check in ##sys#find-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7161(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7168,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1345 ##sys#string-append */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[17]);}}

/* k7166 in k7156 in k7150 in check in ##sys#find-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1345 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7159 in k7156 in k7150 in check in ##sys#find-extension in k7140 in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##sys#canonicalize-extension-path in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6982,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6985,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6991,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7004,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t7=t6;
f_7004(2,t7,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1304 ##sys#symbol->string */
t7=*((C_word*)lf[276]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7087,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7087(t10,t6,t2);}
else{
t7=t6;
f_7004(2,t7,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7087(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7087,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[277]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7104,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1311 ##sys#symbol->string */
t5=*((C_word*)lf[276]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_7104(2,t5,t3);}
else{
/* eval.scm: 1313 err */
t5=((C_word*)t0)[2];
f_6985(t5,t4);}}}}

/* k7102 in loop in ##sys#canonicalize-extension-path in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7104,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[278]:lf[279]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7112,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1317 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7087(t7,t5,t6);}

/* k7110 in k7102 in loop in ##sys#canonicalize-extension-path in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1309 string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7002 in ##sys#canonicalize-extension-path in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7004,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7009,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7009(t5,((C_word*)t0)[2],t1);}

/* check in k7002 in ##sys#canonicalize-extension-path in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_7009(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7009,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1320 err */
t5=((C_word*)t0)[4];
f_6985(t5,t1);}
else{
t5=(C_word)C_subchar(t2,C_fix(0));
t6=f_6991(t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7035,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1322 ##sys#substring */
t8=*((C_word*)lf[240]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(1),t3);}
else{
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t8=(C_word)C_subchar(t2,t7);
t9=f_6991(t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7048,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1324 ##sys#substring */
t12=*((C_word*)lf[240]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t10,t2,C_fix(0),t11);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t2);}}}}

/* k7046 in check in k7002 in ##sys#canonicalize-extension-path in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1324 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7009(t2,((C_word*)t0)[2],t1);}

/* k7033 in check in k7002 in ##sys#canonicalize-extension-path in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1322 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7009(t2,((C_word*)t0)[2],t1);}

/* sep? in ##sys#canonicalize-extension-path in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static C_word C_fcall f_6991(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(92),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(47),t1)));}

/* err in ##sys#canonicalize-extension-path in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6985(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6985,NULL,2,t0,t1);}
/* eval.scm: 1301 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[275],((C_word*)t0)[2]);}

/* ##sys#split-at-separator in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6926,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6935,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_6935(t8,t1,C_SCHEME_END_OF_LIST,C_fix(0),C_fix(0));}

/* loop in ##sys#split-at-separator in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6935(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6935,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6953,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1289 ##sys#substring */
t6=*((C_word*)lf[240]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[4],t4,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[4],t3),((C_word*)t0)[3]);
if(C_truep(t5)){
t6=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6973,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1292 ##sys#substring */
t8=*((C_word*)lf[240]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[4],t4,t3);}
else{
t6=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1293 loop */
t11=t1;
t12=t2;
t13=t6;
t14=t4;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}}

/* k6971 in loop in ##sys#split-at-separator in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6973,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 1292 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6935(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],((C_word*)t0)[2]);}

/* k6951 in loop in ##sys#split-at-separator in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6953,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* eval.scm: 1289 reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6897(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6897r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6897r(t0,t1,t2,t3);}}

static void C_ccall f_6897r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_symbol_2(t2,lf[271]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6904,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
/* eval.scm: 1280 ##sys#load-library */
t8=*((C_word*)lf[264]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t2,t7);}

/* k6902 in load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6904,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k6912 in k6902 in load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1281 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[271],lf[272],((C_word*)t0)[2],t1);}

/* ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6791,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6795,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1253 ##sys#->feature-id */
t5=*((C_word*)lf[270]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6795,2,t0,t1);}
t2=(C_word)C_u_i_memq(t1,*((C_word*)lf[186]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6804,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_6804(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6887,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1258 ##sys#string-append */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[260]+1));}}}

/* k6885 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6891,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1259 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6889 in k6885 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6891,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6804(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6802 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6804(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6804,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6807,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6869,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6873,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1264 ##sys#string->c-identifier */
t6=*((C_word*)lf[269]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6871 in k6802 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1262 string-append */
t2=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[267],t1,lf[268]);}

/* k6867 in k6802 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1261 ##sys#make-c-string */
t2=*((C_word*)lf[243]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6805 in k6802 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6810,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6856,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1266 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6854 in k6805 in k6802 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6856,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1267 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[266]);}
else{
t2=((C_word*)t0)[3];
f_6810(2,t2,C_SCHEME_UNDEFINED);}}

/* k6857 in k6854 in k6805 in k6802 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6862,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1268 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6860 in k6857 in k6854 in k6805 in k6802 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1269 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[265]);}

/* k6808 in k6805 in k6802 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6810,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6815,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6815(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6808 in k6805 in k6802 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6815(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6815,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6828,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6849,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1272 ##sys#make-c-string */
t6=*((C_word*)lf[243]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k6847 in loop in k6808 in k6805 in k6802 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1272 ##sys#dload */
t2=*((C_word*)lf[242]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k6826 in loop in k6808 in k6805 in k6802 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6828,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6831,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[186]+1)))){
t3=t2;
f_6831(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],*((C_word*)lf[186]+1));
t4=C_mutate((C_word*)lf[186]+1,t3);
t5=t2;
f_6831(t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1275 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6815(t3,((C_word*)t0)[5],t2);}}

/* k6829 in k6826 in loop in k6808 in k6805 in k6802 in k6793 in ##sys#load-library in k6787 in k6780 in k6775 in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* load-noisily in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6751(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6751r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6751r(t0,t1,t2,t3);}}

static void C_ccall f_6751r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6755,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6772,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[259],t3,t5);}

/* a6771 in load-noisily in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6772,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6753 in load-noisily in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6758,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6769,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[258],((C_word*)t0)[2],t3);}

/* a6768 in k6753 in load-noisily in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6769,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6756 in k6753 in load-noisily in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6761,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6766,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[257],((C_word*)t0)[2],t3);}

/* a6765 in k6756 in k6753 in load-noisily in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6766,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6759 in k6756 in k6753 in load-noisily in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1224 ##sys#load */
t2=*((C_word*)lf[230]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1);}

/* load-relative in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6715(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6715r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6715r(t0,t1,t2,t3);}}

static void C_ccall f_6715r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6723,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_subchar(t2,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t5,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t6=t4;
f_6723(2,t6,t2);}
else{
/* eval.scm: 1220 ##sys#string-append */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[216]+1),t2);}}

/* k6721 in load-relative in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
/* eval.scm: 1217 ##sys#load */
t5=*((C_word*)lf[230]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t1,t4,C_SCHEME_FALSE);}

/* load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6693(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6693r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6693r(t0,t1,t2,t3);}}

static void C_ccall f_6693r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* eval.scm: 1214 ##sys#load */
t6=*((C_word*)lf[230]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t5,C_SCHEME_FALSE);}

/* ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr5r,(void*)f_6306r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6306r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6306r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(23);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6643,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6648,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer749827 */
t10=t9;
f_6648(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer750825 */
t12=t8;
f_6643(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body747752 */
t14=t7;
f_6308(t14,t1,t10,t12);}}}

/* def-timer749 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6648(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6648,NULL,2,t0,t1);}
/* def-printer750825 */
t2=((C_word*)t0)[2];
f_6643(t2,t1,C_SCHEME_FALSE);}

/* def-printer750 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6643(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6643,NULL,3,t0,t1,t2);}
/* body747752 */
t3=((C_word*)t0)[2];
f_6308(t3,t1,t2,C_SCHEME_FALSE);}

/* body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6308(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6308,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],tmp=(C_word)a,a+=18,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6642,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1149 ##sys#expand-home-path */
t6=*((C_word*)lf[254]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}
else{
t5=t4;
f_6312(t5,C_SCHEME_UNDEFINED);}}

/* k6640 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6312(t3,t2);}

/* k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6312(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6312,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6576,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1152 port? */
t6=*((C_word*)lf[253]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}

/* k6574 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6576,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6315(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1154 ##sys#file-info */
t3=*((C_word*)lf[249]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
/* eval.scm: 1145 ##sys#signal-hook */
t3=*((C_word*)lf[224]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[251],lf[236],lf[252],t2);}}}

/* k6589 in k6574 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t2;
f_6594(t6,(C_word)C_i_not(t3));}
else{
t4=t2;
f_6594(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6594(t3,C_SCHEME_FALSE);}}

/* k6592 in k6589 in k6574 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6594(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6594,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6315(2,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6597,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1160 ##sys#string-append */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[250]+1));}}

/* k6595 in k6592 in k6589 in k6574 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1161 ##sys#file-info */
t3=*((C_word*)lf[249]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6601 in k6595 in k6592 in k6589 in k6574 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6603,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6315(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1163 ##sys#string-append */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[17]);}}

/* k6604 in k6601 in k6595 in k6592 in k6589 in k6574 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1164 ##sys#file-info */
t3=*((C_word*)lf[249]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6610 in k6604 in k6601 in k6595 in k6592 in k6589 in k6574 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6315(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[5];
f_6315(2,t3,(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[2])[1]));}}

/* k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6315,2,t0,t1);}
t2=((C_word*)t0)[17];
t3=(C_truep(t2)?t2:((C_word*)t0)[16]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6321,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t3,a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t1,a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 1169 ##sys#signal-hook */
t7=*((C_word*)lf[224]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,lf[245],lf[236],lf[246],((C_word*)((C_word*)t0)[6])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6567,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1170 load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k6565 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6567,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6558,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1171 display */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[248]);}
else{
t3=((C_word*)t0)[2];
f_6321(2,t3,C_SCHEME_UNDEFINED);}}

/* k6556 in k6565 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1172 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6559 in k6556 in k6565 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1173 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[247]);}

/* k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6543,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1175 ##sys#make-c-string */
t5=*((C_word*)lf[243]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_6324(2,t3,C_SCHEME_FALSE);}}

/* k6541 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1175 ##sys#dload */
t2=*((C_word*)lf[242]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6513 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6515,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6324(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1176 has-sep? */
f_6260(t2,((C_word*)t0)[3]);}}

/* k6537 in k6513 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6539,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6324(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6531,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6535,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1177 ##sys#string-append */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[244],((C_word*)t0)[2]);}}

/* k6533 in k6537 in k6513 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1177 ##sys#make-c-string */
t2=*((C_word*)lf[243]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6529 in k6537 in k6513 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1177 ##sys#dload */
t2=*((C_word*)lf[242]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6327,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_6327(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 1178 call-with-current-continuation */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6332,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[13];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6336,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t4,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[13])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6502,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1184 has-sep? */
f_6260(t8,((C_word*)t0)[13]);}
else{
t8=t7;
f_6336(2,t8,C_SCHEME_FALSE);}}

/* k6500 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(t1,C_fix(1));
/* eval.scm: 1185 ##sys#substring */
t3=*((C_word*)lf[240]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_6336(2,t2,lf[241]);}}

/* k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6336,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6337,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6346,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t13,a[7]=t11,a[8]=t9,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t15=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6360,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6487,a[2]=t13,a[3]=t11,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* ##sys#dynamic-wind */
t17=*((C_word*)lf[239]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[2],t14,t15,t16);}

/* a6486 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6487,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[231]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[215]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[216]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[214]+1));
t6=C_mutate((C_word*)lf[231]+1,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[215]+1,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[216]+1,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[214]+1,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[232]+1));}

/* a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6364,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 1187 open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6364(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6369,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6372,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6478,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1188 ##sys#dynamic-wind */
t5=*((C_word*)lf[239]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a6477 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6478,2,t0,t1);}
/* eval.scm: 1210 close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6376,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1191 peek-char */
t3=*((C_word*)lf[238]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6472,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_6379(2,t4,C_SCHEME_UNDEFINED);}}

/* k6470 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1193 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[236],lf[237],((C_word*)t0)[2],t1);}

/* k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1194 read */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6382,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6387(t5,((C_word*)t0)[2],t1);}

/* do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6387(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6387,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1197 printer */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_6397(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6395 in do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6400,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6409,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1198 ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}

/* a6442 in k6395 in do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6443(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_6443r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6443r(t0,t1,t2);}}

static void C_ccall f_6443r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a6451 in a6442 in k6395 in do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6452,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6456,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1207 write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k6454 in a6451 in a6442 in k6395 in do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1208 newline */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6408 in k6395 in do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6409,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6416,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1201 ##sys#start-timer */
t3=*((C_word*)lf[235]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 1202 evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}}

/* k6414 in a6408 in k6395 in do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6421,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6427,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1201 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6426 in k6414 in a6408 in k6395 in do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6427(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6427r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6427r(t0,t1,t2);}}

static void C_ccall f_6427r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6431,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6438,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1201 ##sys#stop-timer */
t5=*((C_word*)lf[234]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6436 in a6426 in k6414 in a6408 in k6395 in do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1201 ##sys#display-times */
t2=*((C_word*)lf[233]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6429 in a6426 in k6414 in a6408 in k6395 in do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6420 in k6414 in a6408 in k6395 in do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6421,2,t0,t1);}
/* eval.scm: 1201 evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k6398 in k6395 in do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6407,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1195 read */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6405 in k6398 in k6395 in do800 in k6380 in k6377 in k6374 in a6371 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_6387(t2,((C_word*)t0)[2],t1);}

/* a6368 in k6362 in a6359 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6369,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a6345 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6346,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[231]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[215]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[216]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[214]+1));
t6=C_mutate((C_word*)lf[231]+1,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[215]+1,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[216]+1,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[214]+1,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[232]+1));}

/* f_6337 in k6334 in a6331 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6337,2,t0,t1);}
/* eval.scm: 1186 abrt */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k6325 in k6322 in k6319 in k6313 in k6310 in body747 in ##sys#load in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* has-sep? in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6260(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6260,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6270,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6270(t5,t4));}

/* loop in has-sep? in k6256 in k6176 in k6077 in k1774 in k1732 in k1729 */
static C_word C_fcall f_6270(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_truep((C_word)C_eqp(t2,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
return(t1);}
else{
t3=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* set-dynamic-load-mode! in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6185,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6192,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6197,a[2]=t6,a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6197(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6197(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6197,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6210,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[220]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t4;
f_6210(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[221]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=t4;
f_6210(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[222]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=t4;
f_6210(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[223]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=t4;
f_6210(2,t10,t9);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1124 ##sys#signal-hook */
t10=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t4,lf[218],lf[225],t9);}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6208 in loop in set-dynamic-load-mode! in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1125 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6197(t3,((C_word*)t0)[2],t2);}

/* k6190 in set-dynamic-load-mode! in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1126 ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[219]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_6180 in k6176 in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6180,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6096,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6099,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6109,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_6109(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6109(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6109,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6123,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1094 reverse */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6142,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 1096 reverse */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_fixnum_plus(t4,C_fix(1));
/* eval.scm: 1098 loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 1097 err */
t6=((C_word*)t0)[2];
f_6099(t6,t1);}}}
else{
/* eval.scm: 1095 err */
t6=((C_word*)t0)[2];
f_6099(t6,t1);}}}

/* k6140 in loop in ##sys#decompose-lambda-list in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1096 k */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6121 in loop in ##sys#decompose-lambda-list in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1094 k */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k6077 in k1774 in k1732 in k1729 */
static void C_fcall f_6099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6099,NULL,2,t0,t1);}
t2=C_set_block_item(lf[211],0,C_SCHEME_FALSE);
/* eval.scm: 1091 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[212],((C_word*)t0)[2]);}

/* eval in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6082(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6082r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6082r(t0,t1,t2,t3);}}

static void C_ccall f_6082r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6090,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1079 ##sys#eval-handler */
t5=*((C_word*)lf[208]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6088 in eval in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6094,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1080 ##sys#interpreter-toplevel-macroexpand-hook */
t3=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6092 in k6088 in eval in k6077 in k1774 in k1732 in k1729 */
static void C_ccall f_6094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_3830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+37)){
C_save_and_reclaim((void*)tr5r,(void*)f_3830r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3830r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3830r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a=C_alloc(37);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3833,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3875,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3987,a[2]=t7,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4040,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4046,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4052,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4058,a[2]=t9,a[3]=t13,a[4]=t7,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=t15,a[8]=t17,a[9]=t12,a[10]=((C_word*)t0)[3],a[11]=t6,tmp=(C_word)a,a+=12,tmp));
t19=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5827,a[2]=t15,a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t20=(C_word)C_fixnum_greaterp(*((C_word*)lf[137]+1),C_fix(0));
t21=(C_word)C_i_nullp(t5);
t22=(C_truep(t21)?C_SCHEME_FALSE:(C_word)C_u_i_car(t5));
/* eval.scm: 1058 compile */
t23=((C_word*)t15)[1];
f_4058(t23,t1,t2,t3,C_SCHEME_FALSE,t20,t22);}

/* compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_5827(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5827,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5831,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1022 compile */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4058(t8,t6,t7,t3,C_SCHEME_FALSE,t4,t5);}

/* k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[64],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5831,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5801,tmp=(C_word)a,a+=2,tmp);
t4=f_5801(t2,C_fix(0));
t5=((C_word*)t0)[8];
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 1027 ##sys#syntax-error-hook */
t6=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[7],lf[207],((C_word*)t0)[8]);
case C_fix(0):
t6=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5853,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
case C_fix(1):
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5872,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1031 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4058(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(2):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5900,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1035 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4058(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(3):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5935,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1040 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4058(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(4):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5977,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1046 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4058(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
default:
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6020,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6044,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1053 ##sys#map */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}}

/* a6043 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_6044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6044,3,t0,t1,t2);}
/* eval.scm: 1053 compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4058(t3,t1,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6018 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_6020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6020,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6021,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_6021 in k6018 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_6021(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6021,3,t0,t1,t2);}
t3=f_4040(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6032,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6030 */
static void C_ccall f_6032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6036,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6038,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1056 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6037 in k6030 */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6038,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k6034 in k6030 */
static void C_ccall f_6036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5975 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1047 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4058(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5978 in k5975 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1048 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4058(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(2)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7]);}

/* k5981 in k5978 in k5975 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5986,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1049 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4058(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(3)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* k5984 in k5981 in k5978 in k5975 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5986,2,t0,t1);}
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp));}

/* f_5987 in k5984 in k5981 in k5978 in k5975 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5987,3,t0,t1,t2);}
t3=f_4040(((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5996 */
static void C_ccall f_5998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k6000 in k5996 */
static void C_ccall f_6002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6004 in k6000 in k5996 */
static void C_ccall f_6006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6008 in k6004 in k6000 in k5996 */
static void C_ccall f_6010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6013,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6011 in k6008 in k6004 in k6000 in k5996 */
static void C_ccall f_6013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5933 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1041 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4058(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5936 in k5933 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5941,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 1042 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4058(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(2)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7]);}

/* k5939 in k5936 in k5933 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5941,2,t0,t1);}
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));}

/* f_5942 in k5939 in k5936 in k5933 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5942,3,t0,t1,t2);}
t3=f_4040(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5951 */
static void C_ccall f_5953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5955 in k5951 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5959 in k5955 in k5951 */
static void C_ccall f_5961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5964,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5962 in k5959 in k5955 in k5951 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5898 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5903,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1036 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4058(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5901 in k5898 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5903,2,t0,t1);}
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5904,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));}

/* f_5904 in k5901 in k5898 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5904,3,t0,t1,t2);}
t3=f_4040(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5915,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5913 */
static void C_ccall f_5915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5917 in k5913 */
static void C_ccall f_5919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5922,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5920 in k5917 in k5913 */
static void C_ccall f_5922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5870 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5872,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5873,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_5873 in k5870 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5873,3,t0,t1,t2);}
t3=f_4040(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5884,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5882 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5887,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5885 in k5882 */
static void C_ccall f_5887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_5853 in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5853,3,t0,t1,t2);}
t3=f_4040(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5863,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1030 fn */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5861 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in k5829 in compile-call in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static C_word C_fcall f_5801(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_4058(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4058,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_symbolp(t2))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4070,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4076,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 667  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t7,t8);}
else{
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=t4,a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=((C_word*)t0)[8],a[12]=t6,a[13]=t5,a[14]=((C_word*)t0)[9],a[15]=t1,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 689  ##sys#number? */
t8=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}}

/* k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4161,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4168,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4176,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4184,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_fix(2));
t4=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4192,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4194,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp)));}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[16]))){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[16])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4205,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4207,tmp=(C_word)a,a+=2,tmp)));}
else{
t2=(C_word)C_charp(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=t3;
f_4217(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[16]);
t5=t3;
f_4217(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[16])));}}}}

/* k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_4217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4217,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4218,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_4046(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[11],tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 708  defined? */
t6=((C_word*)t0)[4];
f_3875(t6,t5,t4,((C_word*)t0)[10]);}
else{
t3=f_4046(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
/* eval.scm: 999  compile-call */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5827(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[10],((C_word*)t0)[13],((C_word*)t0)[12]);}}
else{
/* eval.scm: 704  ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[16],lf[205],((C_word*)t0)[15]);}}}

/* k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4246,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 709  compile-call */
t2=((C_word*)((C_word*)t0)[16])[1];
f_5827(t2,((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4252,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* eval.scm: 710  macroexpand-1-checked */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3987(t3,t2,((C_word*)t0)[14],((C_word*)t0)[13]);}}

/* k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word ab[121],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4252,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[15]);
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[90]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4267,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 715  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[90],((C_word*)t0)[15],lf[148],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[149]);
if(C_truep(t4)){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
if(C_truep(*((C_word*)lf[128]+1))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 730  ##sys#hash-table-location */
t7=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,*((C_word*)lf[128]+1),t5,C_SCHEME_TRUE);}
else{
t6=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4349,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[150]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 735  compile */
t7=((C_word*)((C_word*)t0)[12])[1];
f_4058(t7,((C_word*)t0)[13],t6,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[151]);
if(C_truep(t6)){
t7=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 738  compile */
t8=((C_word*)((C_word*)t0)[12])[1];
f_4058(t8,((C_word*)t0)[13],t7,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[110]);
if(C_truep(t7)){
t8=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4383,tmp=(C_word)a,a+=2,tmp));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[152]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4393,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 743  ##sys#check-syntax */
t10=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,lf[152],((C_word*)t0)[15],lf[154],C_SCHEME_FALSE);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[106]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 752  ##sys#check-syntax */
t11=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,lf[106],((C_word*)t0)[15],lf[156],C_SCHEME_FALSE);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[69]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[14],lf[71]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4558,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 768  ##sys#check-syntax */
t13=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t12,lf[69],((C_word*)t0)[15],lf[159],C_SCHEME_FALSE);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[58]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4667,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 792  ##sys#check-syntax */
t14=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,lf[58],((C_word*)t0)[15],lf[161],C_SCHEME_FALSE);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[92]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5005,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 842  ##sys#check-syntax */
t15=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t15+1)))(6,t15,t14,lf[92],((C_word*)t0)[15],lf[167],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[59]);
if(C_truep(t14)){
t15=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t16=(C_word)C_a_i_cons(&a,2,lf[92],t15);
/* eval.scm: 936  compile */
t17=((C_word*)((C_word*)t0)[12])[1];
f_4058(t17,((C_word*)t0)[13],t16,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[168]);
if(C_truep(t15)){
t16=(C_word)C_u_i_cddr(((C_word*)t0)[15]);
t17=(C_word)C_a_i_cons(&a,2,lf[92],t16);
t18=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 939  compile */
t19=((C_word*)((C_word*)t0)[12])[1];
f_4058(t19,((C_word*)t0)[13],t17,((C_word*)t0)[11],t18,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[169]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5407,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5438,tmp=(C_word)a,a+=2,tmp);
t19=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
/* map */
t20=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t17,t18,t19);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[173]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5462,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t19=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5468,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=((C_word*)t21)[1];
f_5468(t23,t18,t19);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[176]);
t19=(C_truep(t18)?t18:(C_word)C_eqp(((C_word*)t0)[14],lf[177]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5514,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5520,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 961  ##sys#compile-to-closure */
t23=*((C_word*)lf[142]+1);
((C_proc6)(void*)(*((C_word*)t23+1)))(6,t23,t21,t22,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[179]);
if(C_truep(t20)){
t21=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 965  compile */
t22=((C_word*)((C_word*)t0)[12])[1];
f_4058(t22,((C_word*)t0)[13],t21,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[180]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(((C_word*)t0)[14],lf[181]));
if(C_truep(t22)){
/* eval.scm: 968  compile */
t23=((C_word*)((C_word*)t0)[12])[1];
f_4058(t23,((C_word*)t0)[13],lf[182],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[183]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5558,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_u_i_memq(lf[185],*((C_word*)lf[186]+1)))){
t25=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5569,tmp=(C_word)a,a+=2,tmp);
t26=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
/* for-each */
t27=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t24,t25,t26);}
else{
/* eval.scm: 973  ##sys#warn */
t25=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t24,lf[189],((C_word*)t0)[15]);}}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[190]);
t25=(C_truep(t24)?t24:(C_word)C_eqp(((C_word*)t0)[14],lf[191]));
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5608,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 977  cadadr */
t27=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t27+1)))(3,t27,t26,((C_word*)t0)[15]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[14],lf[192]);
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5621,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t26)){
t28=t27;
f_5621(t28,t26);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[14],lf[196]);
if(C_truep(t28)){
t29=t27;
f_5621(t29,t28);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[14],lf[197]);
if(C_truep(t29)){
t30=t27;
f_5621(t30,t29);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[14],lf[198]);
if(C_truep(t30)){
t31=t27;
f_5621(t31,t30);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[14],lf[199]);
if(C_truep(t31)){
t32=t27;
f_5621(t32,t31);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[14],lf[200]);
if(C_truep(t32)){
t33=t27;
f_5621(t33,t32);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[14],lf[201]);
if(C_truep(t33)){
t34=t27;
f_5621(t34,t33);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[14],lf[202]);
if(C_truep(t34)){
t35=t27;
f_5621(t35,t34);}
else{
t35=(C_word)C_eqp(((C_word*)t0)[14],lf[203]);
t36=t27;
f_5621(t36,(C_truep(t35)?t35:(C_word)C_eqp(((C_word*)t0)[14],lf[204])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}
else{
/* eval.scm: 995  compile */
t3=((C_word*)((C_word*)t0)[12])[1];
f_4058(t3,((C_word*)t0)[13],t1,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k5619 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_5621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 984  ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[193],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[61]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 987  compile-call */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5827(t4,((C_word*)t0)[8],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[194]);
if(C_truep(t3)){
/* eval.scm: 991  ##sys#syntax-error-hook */
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[8],lf[195],((C_word*)t0)[7]);}
else{
/* eval.scm: 993  compile-call */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5827(t4,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k5606 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5608,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[69],t3);
/* eval.scm: 977  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4058(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5568 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5569,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
/* eval.scm: 972  ##compiler#process-declaration */
t4=*((C_word*)lf[187]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* k5556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 974  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4058(t2,((C_word*)t0)[5],lf[184],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5518 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5512 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 962  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4058(t2,((C_word*)t0)[5],lf[178],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_5468(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5468,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[174]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5480,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5490,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 956  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}}

/* a5489 in loop in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5490,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5498,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 957  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5468(t6,t4,t5);}

/* k5496 in a5489 in loop in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5498,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[106],((C_word*)t0)[2],t1));}

/* a5479 in loop in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5480,2,t0,t1);}
t2=(C_word)C_u_i_cadar(((C_word*)t0)[2]);
/* eval.scm: 956  ##sys#do-the-right-thing */
t3=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* k5460 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 952  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4058(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5437 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5438,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5445,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 942  ##sys#compile-to-closure */
t4=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k5443 in a5437 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k5405 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5410,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_apply(4,0,t2,*((C_word*)lf[171]+1),t1);}

/* k5408 in k5405 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5413,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 944  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[172]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5411 in k5408 in k5405 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_5420(t3,lf[170]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5430,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5432,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}}

/* a5431 in k5411 in k5408 in k5405 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5432,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k5428 in k5411 in k5408 in k5405 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5430,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5420(t2,(C_word)C_a_i_cons(&a,2,lf[171],t1));}

/* k5418 in k5411 in k5408 in k5405 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_5420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 945  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4058(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5005,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[8];
t9=(C_truep(t8)?t8:lf[162]);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t4)[1]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5017,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[8],a[9]=t10,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5342,a[2]=t11,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 846  ##sys#extended-lambda-list? */
t13=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t4)[1]);}

/* k5340 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5342,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5347,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 847  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_5017(2,t2,C_SCHEME_UNDEFINED);}}

/* a5352 in k5340 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5353,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a5346 in k5340 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5347,2,t0,t1);}
/* eval.scm: 849  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[56]+1));}

/* k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 852  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[166]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5022,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5029,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t4,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5325,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5331,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=((C_word*)t0)[6];
t10=(C_truep(t9)?t9:((C_word*)t0)[5]);
/* eval.scm: 858  ##sys#canonicalize-body */
t11=*((C_word*)lf[105]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t7,((C_word*)((C_word*)t0)[2])[1],t8,((C_word*)t0)[4],t10);}

/* a5330 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5331,3,t0,t1,t2);}
/* defined?323 */
t3=((C_word*)t0)[3];
f_3875(t3,t1,t2,((C_word*)t0)[2]);}

/* k5323 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[6];
t3=(C_truep(t2)?t2:((C_word*)t0)[5]);
/* eval.scm: 857  ##sys#compile-to-closure */
t4=*((C_word*)lf[142]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[86],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5029,2,t0,t1);}
t2=((C_word*)t0)[8];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(1):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(2):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(3):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)):(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp))));}}

/* f_5287 in k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5287,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5293,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 927  decorate */
f_4052(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5292 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5293r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5293r(t0,t1,t2);}}

static void C_ccall f_5293r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5317,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,*((C_word*)lf[163]+1),t2);}
else{
/* eval.scm: 931  ##sys#error */
t5=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[165],((C_word*)t0)[4],t3);}}

/* k5315 in a5292 */
static void C_ccall f_5317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5317,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5264 in k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5264,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5270,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 920  decorate */
f_4052(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5269 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr2r,(void*)f_5270r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5270r(t0,t1,t2);}}

static void C_ccall f_5270r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(17);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5282,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5286,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t6=t4;
f_5286(2,t6,(C_word)C_a_i_list(&a,1,t2));}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5755,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5755(t9,t4,t5,C_fix(0),t2,C_SCHEME_FALSE);}}

/* do613 in a5269 */
static void C_fcall f_5755(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5755,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t6)){
t7=(C_word)C_a_i_list(&a,1,t4);
t8=(C_word)C_i_setslot(t5,C_fix(1),t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5784,a[2]=t4,a[3]=t8,a[4]=t7,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t10=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t10)){
/* eval.scm: 1008 ##sys#error */
t11=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t9,lf[164],t2,t3);}
else{
t11=t9;
f_5784(2,t11,(C_word)C_slot(t4,C_fix(1)));}}}

/* k5782 in do613 in a5269 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[6])[1];
f_5755(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5284 in a5269 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[163]+1),t1);}

/* k5280 in a5269 */
static void C_ccall f_5282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5282,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5242 in k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5242,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5248,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 913  decorate */
f_4052(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5247 */
static void C_ccall f_5248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5248,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5260,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 915  ##sys#vector */
t7=*((C_word*)lf[163]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k5258 in a5247 */
static void C_ccall f_5260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5260,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5223 in k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5223,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5229,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 908  decorate */
f_4052(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5228 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_5229r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5229r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5229r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_5195 in k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5195,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5201,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 902  decorate */
f_4052(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5200 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5201,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5176 in k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5176,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5182,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 897  decorate */
f_4052(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5181 */
static void C_ccall f_5182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5182r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5182r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5182r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_5148 in k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5148,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5154,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 891  decorate */
f_4052(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5153 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5154,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5129 in k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5129,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5135,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 886  decorate */
f_4052(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5134 */
static void C_ccall f_5135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5135r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5135r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5135r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5101 in k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5101,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5107,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 880  decorate */
f_4052(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5106 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5107,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_5082 in k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5082,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5088,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 875  decorate */
f_4052(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5087 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5088r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5088r(t0,t1,t2,t3);}}

static void C_ccall f_5088r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5058 in k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5058,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5064,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 870  decorate */
f_4052(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5063 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5064,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_5039 in k5027 in a5021 in k5015 in k5003 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5039,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5045,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 865  decorate */
f_4052(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5044 */
static void C_ccall f_5045(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5045r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5045r(t0,t1,t2);}}

static void C_ccall f_5045r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4667,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[10]);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4992,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4991 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4992,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4676,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4682,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4986,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 798  ##sys#canonicalize-body */
t7=*((C_word*)lf[105]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,t5,t6,((C_word*)t0)[4],((C_word*)t0)[6]);}

/* a4985 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4986,3,t0,t1,t2);}
/* defined?323 */
t3=((C_word*)t0)[3];
f_3875(t3,t1,t2,((C_word*)t0)[2]);}

/* k4978 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 797  ##sys#compile-to-closure */
t2=*((C_word*)lf[142]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4682,2,t0,t1);}
switch(((C_word*)t0)[10]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4691,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 803  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4058(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4725,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 806  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4058(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 810  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4058(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 818  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4058(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
default:
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4917,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}}

/* a4963 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4964,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 832  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4058(t5,t1,t3,((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4915 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4917,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4918,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4918 in k4915 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4918,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 834  ##sys#make-vector */
t4=*((C_word*)lf[160]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4920 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4934,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4934(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* do495 in k4920 */
static void C_fcall f_4934(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4934,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4959,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4957 in do495 in k4920 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4934(t5,((C_word*)t0)[2],t3,t4);}

/* k4923 in k4920 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4925,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4839 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 819  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k4900 in k4839 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 819  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4058(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4842 in k4839 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4844,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4850,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 821  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4058(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k4848 in k4842 in k4839 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 822  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4884 in k4848 in k4842 in k4839 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 822  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4058(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4851 in k4848 in k4842 in k4839 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4853,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_4854 in k4851 in k4848 in k4842 in k4839 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4854,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4868 */
static void C_ccall f_4870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k4872 in k4868 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4878,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4876 in k4872 in k4868 */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4880 in k4876 in k4872 in k4868 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4882,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4772 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4820,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 811  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k4818 in k4772 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 811  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4058(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4775 in k4772 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4777,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 813  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4058(t6,t3,t4,((C_word*)t0)[4],t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4781 in k4775 in k4772 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4783,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));}

/* f_4784 in k4781 in k4775 in k4772 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4784,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4800,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4798 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4802 in k4798 */
static void C_ccall f_4804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4806 in k4802 in k4798 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4808,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4723 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4728,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4753,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 807  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4751 in k4723 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 807  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4058(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4726 in k4723 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4729,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4729 in k4726 in k4723 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4729,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4745,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4743 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4747 in k4743 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4749,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4689 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4691,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4692,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_4692 in k4689 in k4680 in k4674 in k4665 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4692,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4708,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4706 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4558,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4572,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4571 in k4556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4572,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 771  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4058(t6,t4,t5,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4574 in a4571 in k4556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4633,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4646,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp)));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4585,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 773  ##sys#alias-global-hook */
t4=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k4583 in k4574 in a4571 in k4556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4585,2,t0,t1);}
if(C_truep(*((C_word*)lf[128]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4591,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 775  ##sys#hash-table-location */
t3=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[128]+1),t1,*((C_word*)lf[129]+1));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}}

/* f_4618 in k4583 in k4574 in a4571 in k4556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4618,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4624 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k4589 in k4583 in k4574 in a4571 in k4556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4594(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 779  ##sys#error */
t3=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[158],((C_word*)t0)[2]);}}

/* k4592 in k4589 in k4583 in k4574 in a4571 in k4556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4594,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}

/* f_4610 in k4592 in k4589 in k4583 in k4574 in a4571 in k4556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4610,2,t0,t1);}
/* eval.scm: 782  ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[157],((C_word*)t0)[2]);}

/* f_4601 in k4592 in k4589 in k4583 in k4574 in a4571 in k4556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4601,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4607 */
static void C_ccall f_4609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_4646 in k4574 in a4571 in k4556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4646,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4654,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4652 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_4633 in k4574 in a4571 in k4556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4633,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4643 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4565 in k4556 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4566,2,t0,t1);}
/* eval.scm: 770  lookup */
f_3833(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4448 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4450,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 756  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_4058(t4,((C_word*)t0)[5],lf[155],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 757  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4058(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 758  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4058(t6,t4,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 762  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4058(t6,t4,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4507 in k4448 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 763  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4058(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4510 in k4507 in k4448 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4515,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,lf[106],t4);
/* eval.scm: 764  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4058(t6,t2,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4513 in k4510 in k4507 in k4448 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4515,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_4516 in k4513 in k4510 in k4507 in k4448 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4516,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4518 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4521 in k4518 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4485 in k4448 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4490,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 759  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4058(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4488 in k4485 in k4448 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4490,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4491,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_4491 in k4488 in k4485 in k4448 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4491(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4491,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4495,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4493 */
static void C_ccall f_4495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4391 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 744  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4058(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4394 in k4391 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 745  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4058(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4397 in k4394 in k4391 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4402,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[6]);
/* eval.scm: 747  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4058(t5,t2,t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* eval.scm: 748  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4058(t4,t2,lf[153],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4400 in k4397 in k4394 in k4391 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4402,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4403 in k4400 in k4397 in k4394 in k4391 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4403,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4408 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_4383 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4383,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_4349 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k4341 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4343,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4344,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_4344 in k4341 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k4265 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4267,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4277,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4285,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4293,tmp=(C_word)a,a+=2,tmp));
case C_fix(2):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4301,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_TRUE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4309,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_FALSE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4317,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4325,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4327,a[2]=t2,tmp=(C_word)a,a+=3,tmp)));}}

/* f_4327 in k4265 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4327,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4325 in k4265 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4325,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_4317 in k4265 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4309 in k4265 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4309(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4309,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4301 in k4265 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4301(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4301,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4293 in k4265 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4293,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4285 in k4265 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4285,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4277 in k4265 in k4250 in k4244 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4277,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_4218 in k4215 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4218,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4207 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4207,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4205 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4205,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4194 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4194,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4192 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4192(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4192,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4184 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4184,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4176 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4176,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4168 in k4159 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* a4075 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4076,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4142,a[2]=t3,tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4151,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp)));}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 669  ##sys#alias-global-hook */
t6=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k4084 in a4075 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
if(C_truep(*((C_word*)lf[128]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4092,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 671  ##sys#hash-table-location */
t3=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[128]+1),t1,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4115,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4120,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[136]+1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4135,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 684  ##sys#symbol-has-toplevel-binding? */
t5=*((C_word*)lf[147]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}
else{
t4=t3;
f_4120(t4,C_SCHEME_FALSE);}}}

/* k4133 in k4084 in a4075 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4120(t2,(C_word)C_i_not(t1));}

/* k4118 in k4084 in a4075 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_4120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4120,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,*((C_word*)lf[136]+1));
t4=C_mutate((C_word*)lf[136]+1,t3);
t5=((C_word*)t0)[2];
f_4115(t5,t4);}
else{
t2=((C_word*)t0)[2];
f_4115(t2,C_SCHEME_UNDEFINED);}}

/* k4113 in k4084 in a4075 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_4115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4115,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4116,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_4116 in k4113 in k4084 in a4075 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4116,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* k4090 in k4084 in a4075 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4095(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 672  ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[146],((C_word*)t0)[2]);}}

/* k4093 in k4090 in k4084 in a4075 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));}

/* f_4096 in k4093 in k4090 in k4084 in a4075 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4096,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* eval.scm: 679  ##sys#error */
t4=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[145],((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_4151 in a4075 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4151,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_4142 in a4075 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4142,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a4069 in compile in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
/* eval.scm: 667  lookup */
f_3833(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* decorate in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_4052(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4052,NULL,5,t1,t2,t3,t4,t5);}
/* eval.scm: 663  ##sys#eval-decorator */
t6=*((C_word*)lf[130]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}

/* emit-syntax-trace-info in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static C_word C_fcall f_4046(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[143]+1)):C_SCHEME_UNDEFINED));}

/* emit-trace-info in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static C_word C_fcall f_4040(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_eval_trace_info(t2,t3,*((C_word*)lf[143]+1)):C_SCHEME_UNDEFINED));}

/* macroexpand-1-checked in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_3987(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3987,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3991,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 643  ##sys#macroexpand-1-local */
t5=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}

/* k3989 in macroexpand-1-checked in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,lf[58]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 646  defined? */
t6=((C_word*)t0)[2];
f_3875(t6,t5,lf[58],((C_word*)t0)[3]);}
else{
t5=t3;
f_4006(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k4036 in k3989 in macroexpand-1-checked in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4006(t2,(C_word)C_i_not(t1));}

/* k4004 in k3989 in macroexpand-1-checked in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_4006(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4006,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_4015(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_4015(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* k4013 in k4004 in k3989 in macroexpand-1-checked in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_4015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 649  macroexpand-1-checked */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3987(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* defined? in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_3875(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3875,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3881,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3887,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3886 in defined? in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3887,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* a3880 in defined? in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3881,2,t0,t1);}
/* eval.scm: 618  lookup */
f_3833(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lookup in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_3833(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3833,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3839,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3839(t7,t1,t3,C_fix(0));}

/* loop in lookup in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static void C_fcall f_3839(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3839,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 613  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3957,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=f_3957(t6,t4,C_fix(0));
if(C_truep(t7)){
/* eval.scm: 614  values */
C_values(4,0,t1,t3,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 615  loop */
t11=t1;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in loop in lookup in ##sys#compile-to-closure in k1774 in k1732 in k1729 */
static C_word C_fcall f_3957(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##sys#alias-global-hook in k1774 in k1732 in k1729 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3824,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#eval-decorator in k1774 in k1732 in k1729 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3783,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3789,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3802,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 583  ##sys#decorate-lambda */
t8=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,t6,t7);}

/* a3801 in ##sys#eval-decorator in k1774 in k1732 in k1729 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3802,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3810,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3814,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 590  open-output-string */
t6=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3812 in a3801 in ##sys#eval-decorator in k1774 in k1732 in k1729 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3817,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 591  write */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3815 in k3812 in a3801 in ##sys#eval-decorator in k1774 in k1732 in k1729 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3820,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 592  get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3818 in k3815 in k3812 in a3801 in ##sys#eval-decorator in k1774 in k1732 in k1729 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 589  ##sys#make-lambda-info */
t2=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3808 in a3801 in ##sys#eval-decorator in k1774 in k1732 in k1729 */
static void C_ccall f_3810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a3788 in ##sys#eval-decorator in k1774 in k1732 in k1729 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3789,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_lambdainfop(t2)));}

/* ##sys#hash-table-location in k1774 in k1732 in k1729 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3723,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3727,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 563  ##sys#hash-symbol */
t7=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k3725 in ##sys#hash-table-location in k1774 in k1732 in k1729 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3727,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3735,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3735(t6,((C_word*)t0)[2],t2);}

/* loop in k3725 in ##sys#hash-table-location in k1774 in k1732 in k1729 */
static void C_fcall f_3735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3735,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 574  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table->alist in k1774 in k1732 in k1729 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3656,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3662,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3662(t7,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in ##sys#hash-table->alist in k1774 in k1732 in k1729 */
static void C_fcall f_3662(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3662,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(*((C_word*)lf[125]+1),t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3678,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3678(t8,t1,t4,t3);}}

/* loop2 in loop in ##sys#hash-table->alist in k1774 in k1732 in k1729 */
static void C_fcall f_3678(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3678,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 555  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3662(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* eval.scm: 556  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* ##sys#hash-table-for-each in k1774 in k1732 in k1729 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3613,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3619,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3619(t8,t1,C_fix(0));}

/* do269 in ##sys#hash-table-for-each in k1774 in k1732 in k1729 */
static void C_fcall f_3619(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3619,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3629,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3638,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* eval.scm: 543  ##sys#for-each */
t6=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3637 in do269 in ##sys#hash-table-for-each in k1774 in k1732 in k1729 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3638,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 544  p */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3627 in do269 in ##sys#hash-table-for-each in k1774 in k1732 in k1729 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3619(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-update! in k1774 in k1732 in k1729 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3593,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3601,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3605,a[2]=t5,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 537  ##sys#hash-table-ref */
t8=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,t3);}

/* k3603 in ##sys#hash-table-update! in k1774 in k1732 in k1729 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3608(2,t3,t1);}
else{
/* eval.scm: 537  valufunc */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3606 in k3603 in ##sys#hash-table-update! in k1774 in k1732 in k1729 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 537  updtfunc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3599 in ##sys#hash-table-update! in k1774 in k1732 in k1729 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 537  ##sys#hash-table-set! */
t2=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#hash-table-set! in k1774 in k1732 in k1729 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3538,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3542,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 526  ##sys#hash-symbol */
t6=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k3540 in ##sys#hash-table-set! in k1774 in k1732 in k1729 */
static void C_ccall f_3542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3542,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3550,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3550(t6,((C_word*)t0)[2],t2);}

/* loop in k3540 in ##sys#hash-table-set! in k1774 in k1732 in k1729 */
static void C_fcall f_3550(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3550,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 534  loop */
t11=t1;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-ref in k1774 in k1732 in k1729 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3493,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3497,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 516  ##sys#hash-symbol */
t5=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k3495 in ##sys#hash-table-ref in k1774 in k1732 in k1729 */
static void C_ccall f_3497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3497,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3506,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3506(t3,t2));}

/* loop in k3495 in ##sys#hash-table-ref in k1774 in k1732 in k1729 */
static C_word C_fcall f_3506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return((C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}}

/* ##sys#hash-symbol in k1774 in k1732 in k1729 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3478,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_hash_string(t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_modulo(t6,t3));}}

/* ##sys#expand-curried-define in k1774 in k1732 in k1729 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3418,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3421,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3473,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 493  loop */
t10=((C_word*)t7)[1];
f_3421(t10,t9,t2,t3);}

/* k3471 in ##sys#expand-curried-define in k1774 in k1732 in k1729 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3473,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k1774 in k1732 in k1729 */
static void C_fcall f_3421(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(15);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3421,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[92],t8));}
else{
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
t8=(C_word)C_a_i_cons(&a,2,lf[92],t7);
t9=(C_word)C_a_i_list(&a,1,t8);
/* eval.scm: 492  loop */
t15=t1;
t16=t5;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* ##sys#match-expression in k1774 in k1732 in k1729 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3327,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3330,a[2]=t8,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3416,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 480  mwalk */
t11=((C_word*)t8)[1];
f_3330(t11,t10,t2,t3);}

/* k3414 in ##sys#match-expression in k1774 in k1732 in k1729 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in ##sys#match-expression in k1774 in k1732 in k1729 */
static void C_fcall f_3330(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3330,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t3));
t5=(C_truep(t4)?t4:(C_word)C_i_not((C_word)C_pairp(t3)));
if(C_truep(t5)){
t6=(C_word)C_u_i_assq(t3,((C_word*)((C_word*)t0)[4])[1]);
if(C_truep(t6)){
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_equalp(t2,t7));}
else{
if(C_truep((C_word)C_u_i_memq(t3,((C_word*)t0)[3]))){
t7=(C_word)C_a_i_cons(&a,2,t3,t2);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)((C_word*)t0)[4])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_TRUE);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_eqp(t2,t3));}}}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3385,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t2,C_fix(0));
t10=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 477  mwalk */
t17=t8;
t18=t9;
t19=t10;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k3383 in mwalk in ##sys#match-expression in k1774 in k1732 in k1729 */
static void C_ccall f_3385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 478  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3330(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_2844r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2844r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2844r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(12);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2846,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3282,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-me154207 */
t8=t7;
f_3282(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-container155205 */
t10=t6;
f_3277(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body152157 */
t12=t5;
f_2846(t12,t1,t8);}}}

/* def-me154 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_fcall f_3282(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3282,NULL,2,t0,t1);}
/* def-container155205 */
t2=((C_word*)t0)[2];
f_3277(t2,t1,C_SCHEME_FALSE);}

/* def-container155 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_fcall f_3277(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3277,NULL,3,t0,t1,t2);}
/* body152157 */
t3=((C_word*)t0)[2];
f_2846(t3,t1,t2);}

/* body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_fcall f_2846(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2846,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2849,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3029,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
/* eval.scm: 461  expand */
t9=((C_word*)t6)[1];
f_3029(t9,t1,((C_word*)t0)[2]);}

/* expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_fcall f_3029(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3029,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3035(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_fcall f_3035(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3035,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_slot(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3069,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t10,a[7]=t2,a[8]=t6,a[9]=t5,a[10]=t4,a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t10))){
/* eval.scm: 427  lookup */
t12=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t10);}
else{
t12=t11;
f_3069(2,t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 426  fini */
t11=((C_word*)((C_word*)t0)[5])[1];
f_2849(t11,t1,t3,t4,t5,t6,t2);}}
else{
/* eval.scm: 422  fini */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2849(t7,t1,t3,t4,t5,t6,t2);}}

/* k3067 in loop in expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3069,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 428  fini */
t2=((C_word*)((C_word*)t0)[13])[1];
f_2849(t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(lf[107],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3081,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 430  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[107],((C_word*)t0)[3],lf[116],C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(lf[108],((C_word*)t0)[6]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3199,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 451  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[108],((C_word*)t0)[3],lf[117],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(lf[106],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3227,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 454  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[106],((C_word*)t0)[3],lf[118],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3241,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 457  ##sys#macroexpand-0 */
t6=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}}}}}

/* k3239 in k3067 in loop in expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3241,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* eval.scm: 459  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_2849(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* eval.scm: 460  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3035(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k3225 in k3067 in loop in expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3234,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 455  ##sys#append */
t4=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k3232 in k3225 in k3067 in loop in expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 455  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3035(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3197 in k3067 in loop in expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3199,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_u_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* eval.scm: 452  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3035(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k3079 in k3067 in loop in expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3081,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3086,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3086(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k3079 in k3067 in loop in expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_fcall f_3086(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3086,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3133,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 442  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[107],t2,lf[112],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 445  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[107],t2,lf[113],C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 434  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[107],t2,lf[115],C_SCHEME_FALSE);}}

/* k3097 in loop2 in k3079 in k3067 in loop in expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3099,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_caddr(((C_word*)t0)[8]):lf[114]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* eval.scm: 435  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_3035(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3149 in loop2 in k3079 in k3067 in loop in expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3151,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[92],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[7]);
/* eval.scm: 446  loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3035(t9,((C_word*)t0)[5],((C_word*)t0)[4],t3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3131 in loop2 in k3079 in k3067 in loop in expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* eval.scm: 443  ##sys#expand-curried-define */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k3142 in k3131 in loop2 in k3079 in k3067 in loop in expand in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3144,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[107],t1);
/* eval.scm: 443  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3086(t3,((C_word*)t0)[2],t2);}

/* fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_fcall f_2849(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2849,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2861,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2861(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2931,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 406  reverse */
t10=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}}

/* k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3009,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3021,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[88]+1),t1,((C_word*)t0)[3]);}

/* k3019 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 407  ##sys#map */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3008 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3009,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[110]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2946,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2950,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2999,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3007,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 409  reverse */
t6=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k3005 in k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 409  map */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2998 in k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2999,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],t2,t3));}

/* k2948 in k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2954,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2993,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 416  reverse */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2991 in k2948 in k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2997,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 417  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2995 in k2991 in k2948 in k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 410  map */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2959 in k2948 in k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2960,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2964,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 411  ##sys#map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[83]+1),t2);}

/* k2962 in a2959 in k2948 in k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2964,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2983,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2985,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 415  map */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a2984 in k2962 in a2959 in k2948 in k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2985,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],t2,t3));}

/* k2981 in k2962 in a2959 in k2948 in k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2983,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[92],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[2],t3));}

/* k2956 in k2948 in k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2952 in k2948 in k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2944 in k2940 in k2929 in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2946,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[58],t2));}

/* loop in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_fcall f_2861(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2861,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_a_i_list(&a,2,lf[107],lf[108]);
t8=t5;
f_2880(t8,(C_word)C_u_i_memq(t6,t7));}
else{
t6=t5;
f_2880(t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[106],((C_word*)t0)[2]));}}

/* k2878 in loop in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_fcall f_2880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2880,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2887,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2891,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 404  reverse */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
/* eval.scm: 405  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2861(t4,((C_word*)t0)[8],t2,t3);}}

/* k2889 in k2878 in loop in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2899,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 404  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3029(t3,t2,((C_word*)t0)[2]);}

/* k2897 in k2889 in k2878 in loop in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2899,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 404  ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2885 in k2878 in loop in fini in body152 in ##sys#canonicalize-body in k1774 in k1732 in k1729 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[106],t1));}

/* ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2325,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2328,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2347,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t9,a[8]=t7,tmp=(C_word)a,a+=9,tmp));
t13=((C_word*)t11)[1];
f_2347(t13,t1,C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_fcall f_2347(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word *a;
loop:
a=C_alloc(85);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2347,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2361,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[8],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 322  reverse */
t9=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
/* eval.scm: 322  reverse */
t8=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* eval.scm: 345  err */
t7=((C_word*)t0)[4];
f_2328(t7,t1,lf[94]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2591,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t8)){
t9=t7;
f_2591(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[8])+1,t6);
t10=t7;
f_2591(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_slot(t6,C_fix(0));
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(t7,lf[80]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t11)){
t12=t10;
f_2623(t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2642,a[2]=t10,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 357  gensym */
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}
else{
t10=(C_word)C_eqp(t7,lf[79]);
if(C_truep(t10)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(1)))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[7],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t12=(C_word)C_slot(t8,C_fix(0));
t13=t11;
f_2660(t13,(C_word)C_i_symbolp(t12));}
else{
t12=t11;
f_2660(t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 369  err */
t11=((C_word*)t0)[4];
f_2328(t11,t1,lf[97]);}}
else{
t11=(C_word)C_eqp(t7,lf[81]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2706,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t13=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t13)){
t14=t12;
f_2706(t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2725,a[2]=t12,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 371  gensym */
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}}
else{
if(C_truep((C_word)C_i_symbolp(t7))){
t12=t2;
switch(t12){
case C_fix(0):
t13=(C_word)C_a_i_cons(&a,2,t7,t3);
/* eval.scm: 378  loop */
t34=t1;
t35=C_fix(0);
t36=t13;
t37=C_SCHEME_END_OF_LIST;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(1):
t13=(C_word)C_a_i_list(&a,2,t7,C_SCHEME_FALSE);
t14=(C_word)C_a_i_cons(&a,2,t13,t4);
/* eval.scm: 379  loop */
t34=t1;
t35=C_fix(1);
t36=t3;
t37=t14;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(2):
/* eval.scm: 380  err */
t13=((C_word*)t0)[4];
f_2328(t13,t1,lf[99]);
default:
t13=(C_word)C_a_i_list(&a,1,t7);
t14=(C_word)C_a_i_cons(&a,2,t13,t5);
/* eval.scm: 381  loop */
t34=t1;
t35=C_fix(3);
t36=t3;
t37=t4;
t38=t14;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;}}
else{
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2787,a[2]=t5,a[3]=t8,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t7,a[8]=t1,a[9]=((C_word*)t0)[4],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t7))){
t13=(C_word)C_i_length(t7);
t14=t12;
f_2787(t14,(C_word)C_eqp(C_fix(2),t13));}
else{
t13=t12;
f_2787(t13,C_SCHEME_FALSE);}}}}}}
else{
/* eval.scm: 351  err */
t7=((C_word*)t0)[4];
f_2328(t7,t1,lf[103]);}}}}

/* k2785 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_fcall f_2787(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2787,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* eval.scm: 384  err */
t3=((C_word*)t0)[9];
f_2328(t3,((C_word*)t0)[8],lf[100]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* eval.scm: 385  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2347(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* eval.scm: 386  err */
t3=((C_word*)t0)[9];
f_2328(t3,((C_word*)t0)[8],lf[101]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* eval.scm: 387  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2347(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* eval.scm: 388  err */
t2=((C_word*)t0)[9];
f_2328(t2,((C_word*)t0)[8],lf[102]);}}

/* k2723 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2706(t3,t2);}

/* k2704 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_fcall f_2706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* eval.scm: 373  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2347(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 374  err */
t2=((C_word*)t0)[2];
f_2328(t2,((C_word*)t0)[6],lf[98]);}}

/* k2658 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_fcall f_2660(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2660,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2663,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_2663(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(0));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_2663(t6,t5);}}
else{
/* eval.scm: 368  err */
t2=((C_word*)t0)[2];
f_2328(t2,((C_word*)t0)[6],lf[96]);}}

/* k2661 in k2658 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_fcall f_2663(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 367  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2347(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k2640 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2623(t3,t2);}

/* k2621 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_fcall f_2623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* eval.scm: 359  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2347(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 360  err */
t3=((C_word*)t0)[2];
f_2328(t3,((C_word*)t0)[5],lf[95]);}}

/* k2589 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_fcall f_2591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* eval.scm: 349  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2347(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k2568 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 322  ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2359 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2365,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t3=t2;
f_2365(t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2504,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2563,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 333  reverse */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}}

/* k2561 in k2359 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2505 in k2359 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2506,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2559,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* eval.scm: 312  string->keyword */
t6=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k2557 in a2505 in k2359 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2559,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[90],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[92],t6);
t8=t3;
f_2533(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t5=t3;
f_2533(t5,C_SCHEME_END_OF_LIST);}}

/* k2531 in k2557 in a2505 in k2359 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_fcall f_2533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2533,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[91],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t4));}

/* k2502 in k2359 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2504,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[89],t2);
t4=((C_word*)t0)[2];
f_2365(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2363 in k2359 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_fcall f_2365(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2365,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t3=t2;
f_2368(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=t3;
f_2377(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=t3;
f_2377(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_2377(t5,C_SCHEME_FALSE);}}}}

/* k2375 in k2363 in k2359 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_fcall f_2377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2377,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_caar(((C_word*)t0)[8]);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[85],((C_word*)((C_word*)t0)[7])[1],t3);
t5=(C_word)C_a_i_list(&a,2,t2,t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,lf[58],t7);
t9=((C_word*)t0)[5];
f_2368(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[3]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2433,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 339  reverse */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[8]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2456,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 341  reverse */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[8]);}}}

/* k2454 in k2375 in k2363 in k2359 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2456,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* eval.scm: 341  ##sys#append */
t5=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k2450 in k2375 in k2363 in k2359 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[87],t3);
t5=((C_word*)t0)[2];
f_2368(t5,(C_word)C_a_i_list(&a,1,t4));}

/* k2431 in k2375 in k2363 in k2359 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2433,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[86],t3);
t5=((C_word*)t0)[2];
f_2368(t5,(C_word)C_a_i_list(&a,1,t4));}

/* k2366 in k2363 in k2359 in loop in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_fcall f_2368(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 321  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k1774 in k1732 in k1729 */
static void C_fcall f_2328(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2328,NULL,3,t0,t1,t2);}
/* eval.scm: 311  errh */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k1774 in k1732 in k1729 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2282,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2288,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2288(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k1774 in k1732 in k1729 */
static void C_fcall f_2288(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2288,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[79]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2307(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[80]);
t7=t5;
f_2307(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[81])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2305 in loop in ##sys#extended-lambda-list? in k1774 in k1732 in k1729 */
static void C_fcall f_2307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 305  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2288(t3,((C_word*)t0)[4],t2);}}

/* macroexpand-1 in k1774 in k1732 in k1729 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2266r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2266r(t0,t1,t2,t3);}}

static void C_ccall f_2266r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
/* eval.scm: 285  ##sys#macroexpand-0 */
t6=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t5);}

/* macroexpand in k1774 in k1732 in k1729 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2230r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2230r(t0,t1,t2,t3);}}

static void C_ccall f_2230r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2239,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2239(t9,t1,t2);}

/* loop in macroexpand in k1774 in k1732 in k1729 */
static void C_fcall f_2239(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2239,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2245,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a2250 in loop in macroexpand in k1774 in k1732 in k1729 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2251,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* eval.scm: 281  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2239(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a2244 in loop in macroexpand in k1774 in k1732 in k1729 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2245,2,t0,t1);}
/* eval.scm: 279  ##sys#macroexpand-0 */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#macroexpand-1-local in k1774 in k1732 in k1729 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2223,4,t0,t1,t2,t3);}
/* eval.scm: 266  ##sys#macroexpand-0 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* ##sys#interpreter-toplevel-macroexpand-hook in k1774 in k1732 in k1729 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2220,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#compiler-toplevel-macroexpand-hook in k1774 in k1732 in k1729 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2217,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1847,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1850,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1996,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(0));
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(C_word)C_eqp(t6,lf[58]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2084,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 235  ##sys#check-syntax */
t10=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,lf[58],t7,lf[66]);}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2157,a[2]=t6,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_truep((C_word)C_eqp(t6,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,lf[71]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(t7))){
t10=(C_word)C_slot(t7,C_fix(0));
t11=t9;
f_2157(t11,(C_word)C_i_pairp(t10));}
else{
t10=t9;
f_2157(t10,C_SCHEME_FALSE);}}
else{
t10=t9;
f_2157(t10,C_SCHEME_FALSE);}}}
else{
/* eval.scm: 258  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* eval.scm: 259  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k2155 in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_fcall f_2157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2157,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 251  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[69],((C_word*)t0)[6],lf[70]);}
else{
/* eval.scm: 257  expand */
t2=((C_word*)t0)[4];
f_1996(t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2161 in k2155 in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2170,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_a_i_list(&a,2,lf[67],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 253  append */
t8=*((C_word*)lf[68]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t2,t5,t6,t7);}

/* k2168 in k2161 in k2155 in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 252  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k2082 in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2084,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 238  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[58],((C_word*)t0)[4],lf[65]);}
else{
/* eval.scm: 246  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2094 in k2082 in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2138,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2144,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a2143 in k2094 in k2082 in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2144,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k2136 in k2094 in k2082 in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2138,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[59],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[60],t6,((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2118,a[2]=((C_word*)t0)[3],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 244  ##sys#map */
t9=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[63]+1),((C_word*)t0)[2]);}

/* k2116 in k2136 in k2094 in k2082 in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2118,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],t2);
/* eval.scm: 240  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_fcall f_1996(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1996,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_assq(t3,((C_word*)t0)[3]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2010,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t4,C_fix(1));
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2016,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 219  ##sys#hash-table-ref */
t6=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[37]+1),t3);}}

/* k2014 in expand in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2016,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2024,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2024(t5,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
/* eval.scm: 228  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* scan in k2014 in expand in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_fcall f_2024(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2024,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2038,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 225  call-handler */
t4=((C_word*)t0)[6];
f_1850(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 226  scan */
t6=t1;
t7=t3;
t1=t6;
t2=t7;
goto loop;}
else{
/* eval.scm: 227  ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[57],((C_word*)t0)[3]);}}}

/* k2036 in scan in k2014 in expand in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 225  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k2008 in expand in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 218  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_fcall f_1850(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1850,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1857,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1859,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
t7=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1859,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1865,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1972,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1971 in a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1983 in a1971 in a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1984r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1984r(t0,t1,t2);}}

static void C_ccall f_1984r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1990,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g4547 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1989 in a1983 in a1971 in a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1977 in a1971 in a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1978,2,t0,t1);}
/* eval.scm: 215  handler */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1864 in a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1865,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1871,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* g4547 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1870 in a1864 in a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1879,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[4],lf[48]))){
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=t3;
f_1882(t5,(C_word)C_i_memv(lf[53],t4));}
else{
t4=t3;
f_1882(t4,C_SCHEME_FALSE);}}

/* k1880 in a1870 in a1864 in a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_fcall f_1882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1882,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1893,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1899,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1899(t8,t3,t4);}
else{
t2=((C_word*)t0)[4];
f_1879(t2,((C_word*)t0)[5]);}}

/* copy in k1880 in a1870 in a1864 in a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_fcall f_1899(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1899,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_equalp(lf[52],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_u_i_car(t4);
t7=t5;
f_1918(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_1918(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_1918(t6,C_SCHEME_FALSE);}}}

/* k1916 in copy in k1880 in a1870 in a1864 in a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_fcall f_1918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1918,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* eval.scm: 209  string-append */
t5=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,lf[50],t3,lf[51],t4);}
else{
/* eval.scm: 213  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1899(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k1927 in k1916 in copy in k1880 in a1870 in a1864 in a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1929,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[49],t3));}

/* k1891 in k1880 in a1870 in a1864 in a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1879(t2,(C_word)C_a_i_record(&a,3,lf[48],((C_word*)t0)[2],t1));}

/* k1877 in a1870 in a1864 in a1858 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_fcall f_1879(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 193  ##sys#abort */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1855 in call-handler in ##sys#macroexpand-0 in k1774 in k1732 in k1729 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k1774 in k1732 in k1729 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1838,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[44]);
t4=t2;
/* eval.scm: 178  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t4,C_SCHEME_FALSE);}

/* macro? in k1774 in k1732 in k1729 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1820,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[43]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1830,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 175  ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[37]+1),t2);}

/* k1828 in macro? in k1774 in k1732 in k1729 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#copy-macro in k1774 in k1732 in k1729 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1810,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1818,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 171  ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[37]+1),t2);}

/* k1816 in ##sys#copy-macro in k1774 in k1732 in k1729 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 171  ##sys#hash-table-set! */
t2=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[37]+1),((C_word*)t0)[2],t1);}

/* ##sys#register-macro in k1774 in k1732 in k1729 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1794,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1800,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 166  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t2,t4);}

/* a1799 in ##sys#register-macro in k1774 in k1732 in k1729 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1800,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
C_apply(4,0,t1,((C_word*)t0)[2],t3);}

/* ##sys#register-macro-2 in k1774 in k1732 in k1729 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1778,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 160  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t2,t4);}

/* a1783 in ##sys#register-macro-2 in k1774 in k1732 in k1729 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1784,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 162  handler */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* chicken-home in k1732 in k1729 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1766,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 151  ##sys#chicken-prefix */
t3=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[36]);}

/* k1764 in chicken-home in k1732 in k1729 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1766,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

/* ##sys#chicken-prefix in k1732 in k1729 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1735r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1735r(t0,t1,t2);}}

static void C_ccall f_1735r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t4)){
/* eval.scm: 143  ##sys#string-append */
t5=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[2]);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[938] = {
{"topleveleval.scm",(void*)C_eval_toplevel},
{"f_1731eval.scm",(void*)f_1731},
{"f_1734eval.scm",(void*)f_1734},
{"f_1776eval.scm",(void*)f_1776},
{"f_11465eval.scm",(void*)f_11465},
{"f_11469eval.scm",(void*)f_11469},
{"f_11493eval.scm",(void*)f_11493},
{"f_11487eval.scm",(void*)f_11487},
{"f_11477eval.scm",(void*)f_11477},
{"f_11475eval.scm",(void*)f_11475},
{"f_6079eval.scm",(void*)f_6079},
{"f_6178eval.scm",(void*)f_6178},
{"f_6258eval.scm",(void*)f_6258},
{"f_11459eval.scm",(void*)f_11459},
{"f_11455eval.scm",(void*)f_11455},
{"f_11451eval.scm",(void*)f_11451},
{"f_11447eval.scm",(void*)f_11447},
{"f_11437eval.scm",(void*)f_11437},
{"f_6777eval.scm",(void*)f_6777},
{"f_6782eval.scm",(void*)f_6782},
{"f_11415eval.scm",(void*)f_11415},
{"f_11407eval.scm",(void*)f_11407},
{"f_11409eval.scm",(void*)f_11409},
{"f_6789eval.scm",(void*)f_6789},
{"f_11376eval.scm",(void*)f_11376},
{"f_11396eval.scm",(void*)f_11396},
{"f_11392eval.scm",(void*)f_11392},
{"f_11382eval.scm",(void*)f_11382},
{"f_11379eval.scm",(void*)f_11379},
{"f_7142eval.scm",(void*)f_7142},
{"f_11322eval.scm",(void*)f_11322},
{"f_11336eval.scm",(void*)f_11336},
{"f_11372eval.scm",(void*)f_11372},
{"f_11368eval.scm",(void*)f_11368},
{"f_11356eval.scm",(void*)f_11356},
{"f_11360eval.scm",(void*)f_11360},
{"f_11330eval.scm",(void*)f_11330},
{"f_7861eval.scm",(void*)f_7861},
{"f_11201eval.scm",(void*)f_11201},
{"f_11238eval.scm",(void*)f_11238},
{"f_11247eval.scm",(void*)f_11247},
{"f_11266eval.scm",(void*)f_11266},
{"f_11270eval.scm",(void*)f_11270},
{"f_11256eval.scm",(void*)f_11256},
{"f_11253eval.scm",(void*)f_11253},
{"f_11204eval.scm",(void*)f_11204},
{"f_7864eval.scm",(void*)f_7864},
{"f_7922eval.scm",(void*)f_7922},
{"f_11199eval.scm",(void*)f_11199},
{"f_8257eval.scm",(void*)f_8257},
{"f_8261eval.scm",(void*)f_8261},
{"f_11195eval.scm",(void*)f_11195},
{"f_8264eval.scm",(void*)f_8264},
{"f_8268eval.scm",(void*)f_8268},
{"f_11098eval.scm",(void*)f_11098},
{"f_11104eval.scm",(void*)f_11104},
{"f_11120eval.scm",(void*)f_11120},
{"f_11123eval.scm",(void*)f_11123},
{"f_11158eval.scm",(void*)f_11158},
{"f_11161eval.scm",(void*)f_11161},
{"f_11145eval.scm",(void*)f_11145},
{"f_11148eval.scm",(void*)f_11148},
{"f_11155eval.scm",(void*)f_11155},
{"f_8951eval.scm",(void*)f_8951},
{"f_11070eval.scm",(void*)f_11070},
{"f_8954eval.scm",(void*)f_8954},
{"f_11027eval.scm",(void*)f_11027},
{"f_11049eval.scm",(void*)f_11049},
{"f_8957eval.scm",(void*)f_8957},
{"f_10830eval.scm",(void*)f_10830},
{"f_10836eval.scm",(void*)f_10836},
{"f_10852eval.scm",(void*)f_10852},
{"f_10928eval.scm",(void*)f_10928},
{"f_10985eval.scm",(void*)f_10985},
{"f_10931eval.scm",(void*)f_10931},
{"f_10958eval.scm",(void*)f_10958},
{"f_10891eval.scm",(void*)f_10891},
{"f_10910eval.scm",(void*)f_10910},
{"f_10882eval.scm",(void*)f_10882},
{"f_8960eval.scm",(void*)f_8960},
{"f_10727eval.scm",(void*)f_10727},
{"f_10737eval.scm",(void*)f_10737},
{"f_10750eval.scm",(void*)f_10750},
{"f_10766eval.scm",(void*)f_10766},
{"f_10804eval.scm",(void*)f_10804},
{"f_10802eval.scm",(void*)f_10802},
{"f_10794eval.scm",(void*)f_10794},
{"f_10748eval.scm",(void*)f_10748},
{"f_8963eval.scm",(void*)f_8963},
{"f_10674eval.scm",(void*)f_10674},
{"f_10684eval.scm",(void*)f_10684},
{"f_10687eval.scm",(void*)f_10687},
{"f_10692eval.scm",(void*)f_10692},
{"f_10717eval.scm",(void*)f_10717},
{"f_8966eval.scm",(void*)f_8966},
{"f_10604eval.scm",(void*)f_10604},
{"f_10614eval.scm",(void*)f_10614},
{"f_10617eval.scm",(void*)f_10617},
{"f_10664eval.scm",(void*)f_10664},
{"f_10628eval.scm",(void*)f_10628},
{"f_10650eval.scm",(void*)f_10650},
{"f_10636eval.scm",(void*)f_10636},
{"f_10632eval.scm",(void*)f_10632},
{"f_8969eval.scm",(void*)f_8969},
{"f_10485eval.scm",(void*)f_10485},
{"f_10489eval.scm",(void*)f_10489},
{"f_10492eval.scm",(void*)f_10492},
{"f_10495eval.scm",(void*)f_10495},
{"f_10586eval.scm",(void*)f_10586},
{"f_10502eval.scm",(void*)f_10502},
{"f_10525eval.scm",(void*)f_10525},
{"f_10539eval.scm",(void*)f_10539},
{"f_10537eval.scm",(void*)f_10537},
{"f_8972eval.scm",(void*)f_8972},
{"f_10193eval.scm",(void*)f_10193},
{"f_10403eval.scm",(void*)f_10403},
{"f_10407eval.scm",(void*)f_10407},
{"f_10428eval.scm",(void*)f_10428},
{"f_10470eval.scm",(void*)f_10470},
{"f_10206eval.scm",(void*)f_10206},
{"f_10394eval.scm",(void*)f_10394},
{"f_10398eval.scm",(void*)f_10398},
{"f_10377eval.scm",(void*)f_10377},
{"f_10381eval.scm",(void*)f_10381},
{"f_10366eval.scm",(void*)f_10366},
{"f_10358eval.scm",(void*)f_10358},
{"f_10347eval.scm",(void*)f_10347},
{"f_10313eval.scm",(void*)f_10313},
{"f_10294eval.scm",(void*)f_10294},
{"f_10267eval.scm",(void*)f_10267},
{"f_10224eval.scm",(void*)f_10224},
{"f_10220eval.scm",(void*)f_10220},
{"f_10196eval.scm",(void*)f_10196},
{"f_10204eval.scm",(void*)f_10204},
{"f_8975eval.scm",(void*)f_8975},
{"f_10183eval.scm",(void*)f_10183},
{"f_8978eval.scm",(void*)f_8978},
{"f_9937eval.scm",(void*)f_9937},
{"f_10092eval.scm",(void*)f_10092},
{"f_10163eval.scm",(void*)f_10163},
{"f_10108eval.scm",(void*)f_10108},
{"f_10106eval.scm",(void*)f_10106},
{"f_9950eval.scm",(void*)f_9950},
{"f_10076eval.scm",(void*)f_10076},
{"f_10038eval.scm",(void*)f_10038},
{"f_9999eval.scm",(void*)f_9999},
{"f_9940eval.scm",(void*)f_9940},
{"f_8981eval.scm",(void*)f_8981},
{"f_8985eval.scm",(void*)f_8985},
{"f_9934eval.scm",(void*)f_9934},
{"f_9007eval.scm",(void*)f_9007},
{"f_9367eval.scm",(void*)f_9367},
{"f_9792eval.scm",(void*)f_9792},
{"f_9910eval.scm",(void*)f_9910},
{"f_9913eval.scm",(void*)f_9913},
{"f_9900eval.scm",(void*)f_9900},
{"f_9795eval.scm",(void*)f_9795},
{"f_9799eval.scm",(void*)f_9799},
{"f_9810eval.scm",(void*)f_9810},
{"f_9453eval.scm",(void*)f_9453},
{"f_9773eval.scm",(void*)f_9773},
{"f_9777eval.scm",(void*)f_9777},
{"f_9786eval.scm",(void*)f_9786},
{"f_9784eval.scm",(void*)f_9784},
{"f_9456eval.scm",(void*)f_9456},
{"f_9767eval.scm",(void*)f_9767},
{"f_9459eval.scm",(void*)f_9459},
{"f_9761eval.scm",(void*)f_9761},
{"f_9462eval.scm",(void*)f_9462},
{"f_9752eval.scm",(void*)f_9752},
{"f_9759eval.scm",(void*)f_9759},
{"f_9742eval.scm",(void*)f_9742},
{"f_9727eval.scm",(void*)f_9727},
{"f_9731eval.scm",(void*)f_9731},
{"f_9736eval.scm",(void*)f_9736},
{"f_9740eval.scm",(void*)f_9740},
{"f_9705eval.scm",(void*)f_9705},
{"f_9709eval.scm",(void*)f_9709},
{"f_9714eval.scm",(void*)f_9714},
{"f_9718eval.scm",(void*)f_9718},
{"f_9725eval.scm",(void*)f_9725},
{"f_9679eval.scm",(void*)f_9679},
{"f_9685eval.scm",(void*)f_9685},
{"f_9689eval.scm",(void*)f_9689},
{"f_9703eval.scm",(void*)f_9703},
{"f_9692eval.scm",(void*)f_9692},
{"f_9699eval.scm",(void*)f_9699},
{"f_9663eval.scm",(void*)f_9663},
{"f_9669eval.scm",(void*)f_9669},
{"f_9677eval.scm",(void*)f_9677},
{"f_9626eval.scm",(void*)f_9626},
{"f_9630eval.scm",(void*)f_9630},
{"f_9635eval.scm",(void*)f_9635},
{"f_9639eval.scm",(void*)f_9639},
{"f_9661eval.scm",(void*)f_9661},
{"f_9657eval.scm",(void*)f_9657},
{"f_9653eval.scm",(void*)f_9653},
{"f_9642eval.scm",(void*)f_9642},
{"f_9649eval.scm",(void*)f_9649},
{"f_9600eval.scm",(void*)f_9600},
{"f_9606eval.scm",(void*)f_9606},
{"f_9610eval.scm",(void*)f_9610},
{"f_9624eval.scm",(void*)f_9624},
{"f_9613eval.scm",(void*)f_9613},
{"f_9620eval.scm",(void*)f_9620},
{"f_9587eval.scm",(void*)f_9587},
{"f_9561eval.scm",(void*)f_9561},
{"f_9565eval.scm",(void*)f_9565},
{"f_9570eval.scm",(void*)f_9570},
{"f_9574eval.scm",(void*)f_9574},
{"f_9585eval.scm",(void*)f_9585},
{"f_9581eval.scm",(void*)f_9581},
{"f_9545eval.scm",(void*)f_9545},
{"f_9551eval.scm",(void*)f_9551},
{"f_9559eval.scm",(void*)f_9559},
{"f_9533eval.scm",(void*)f_9533},
{"f_9539eval.scm",(void*)f_9539},
{"f_9543eval.scm",(void*)f_9543},
{"f_9524eval.scm",(void*)f_9524},
{"f_9528eval.scm",(void*)f_9528},
{"f_9465eval.scm",(void*)f_9465},
{"f_9475eval.scm",(void*)f_9475},
{"f_9500eval.scm",(void*)f_9500},
{"f_9512eval.scm",(void*)f_9512},
{"f_9518eval.scm",(void*)f_9518},
{"f_9506eval.scm",(void*)f_9506},
{"f_9481eval.scm",(void*)f_9481},
{"f_9487eval.scm",(void*)f_9487},
{"f_9491eval.scm",(void*)f_9491},
{"f_9494eval.scm",(void*)f_9494},
{"f_9498eval.scm",(void*)f_9498},
{"f_9473eval.scm",(void*)f_9473},
{"f_9378eval.scm",(void*)f_9378},
{"f_9388eval.scm",(void*)f_9388},
{"f_9391eval.scm",(void*)f_9391},
{"f_9405eval.scm",(void*)f_9405},
{"f_9423eval.scm",(void*)f_9423},
{"f_9392eval.scm",(void*)f_9392},
{"f_9369eval.scm",(void*)f_9369},
{"f_9028eval.scm",(void*)f_9028},
{"f_9072eval.scm",(void*)f_9072},
{"f_9075eval.scm",(void*)f_9075},
{"f_9352eval.scm",(void*)f_9352},
{"f_9356eval.scm",(void*)f_9356},
{"f_9360eval.scm",(void*)f_9360},
{"f_9157eval.scm",(void*)f_9157},
{"f_9163eval.scm",(void*)f_9163},
{"f_9335eval.scm",(void*)f_9335},
{"f_9341eval.scm",(void*)f_9341},
{"f_9170eval.scm",(void*)f_9170},
{"f_9173eval.scm",(void*)f_9173},
{"f_9176eval.scm",(void*)f_9176},
{"f_9330eval.scm",(void*)f_9330},
{"f_9185eval.scm",(void*)f_9185},
{"f_9188eval.scm",(void*)f_9188},
{"f_9203eval.scm",(void*)f_9203},
{"f_9221eval.scm",(void*)f_9221},
{"f_9284eval.scm",(void*)f_9284},
{"f_9237eval.scm",(void*)f_9237},
{"f_9242eval.scm",(void*)f_9242},
{"f_9246eval.scm",(void*)f_9246},
{"f_9249eval.scm",(void*)f_9249},
{"f_9261eval.scm",(void*)f_9261},
{"f_9264eval.scm",(void*)f_9264},
{"f_9252eval.scm",(void*)f_9252},
{"f_9225eval.scm",(void*)f_9225},
{"f_9207eval.scm",(void*)f_9207},
{"f_9053eval.scm",(void*)f_9053},
{"f_9058eval.scm",(void*)f_9058},
{"f_9210eval.scm",(void*)f_9210},
{"f_9194eval.scm",(void*)f_9194},
{"f_9092eval.scm",(void*)f_9092},
{"f_9097eval.scm",(void*)f_9097},
{"f_9100eval.scm",(void*)f_9100},
{"f_9105eval.scm",(void*)f_9105},
{"f_9112eval.scm",(void*)f_9112},
{"f_9152eval.scm",(void*)f_9152},
{"f_9115eval.scm",(void*)f_9115},
{"f_9127eval.scm",(void*)f_9127},
{"f_9136eval.scm",(void*)f_9136},
{"f_9130eval.scm",(void*)f_9130},
{"f_9118eval.scm",(void*)f_9118},
{"f_9121eval.scm",(void*)f_9121},
{"f_9083eval.scm",(void*)f_9083},
{"f_9077eval.scm",(void*)f_9077},
{"f_9031eval.scm",(void*)f_9031},
{"f_9037eval.scm",(void*)f_9037},
{"f_9025eval.scm",(void*)f_9025},
{"f_9009eval.scm",(void*)f_9009},
{"f_9023eval.scm",(void*)f_9023},
{"f_9020eval.scm",(void*)f_9020},
{"f_9013eval.scm",(void*)f_9013},
{"f_8990eval.scm",(void*)f_8990},
{"f_8999eval.scm",(void*)f_8999},
{"f_8994eval.scm",(void*)f_8994},
{"f_8559eval.scm",(void*)f_8559},
{"f_8696eval.scm",(void*)f_8696},
{"f_8701eval.scm",(void*)f_8701},
{"f_8919eval.scm",(void*)f_8919},
{"f_8900eval.scm",(void*)f_8900},
{"f_8846eval.scm",(void*)f_8846},
{"f_8717eval.scm",(void*)f_8717},
{"f_8722eval.scm",(void*)f_8722},
{"f_8741eval.scm",(void*)f_8741},
{"f_8667eval.scm",(void*)f_8667},
{"f_8673eval.scm",(void*)f_8673},
{"f_8605eval.scm",(void*)f_8605},
{"f_8609eval.scm",(void*)f_8609},
{"f_8617eval.scm",(void*)f_8617},
{"f_8640eval.scm",(void*)f_8640},
{"f_8562eval.scm",(void*)f_8562},
{"f_8569eval.scm",(void*)f_8569},
{"f_8574eval.scm",(void*)f_8574},
{"f_8578eval.scm",(void*)f_8578},
{"f_8603eval.scm",(void*)f_8603},
{"f_8592eval.scm",(void*)f_8592},
{"f_8596eval.scm",(void*)f_8596},
{"f_8585eval.scm",(void*)f_8585},
{"f_8523eval.scm",(void*)f_8523},
{"f_8545eval.scm",(void*)f_8545},
{"f_8515eval.scm",(void*)f_8515},
{"f_8461eval.scm",(void*)f_8461},
{"f_8465eval.scm",(void*)f_8465},
{"f_8468eval.scm",(void*)f_8468},
{"f_8471eval.scm",(void*)f_8471},
{"f_8474eval.scm",(void*)f_8474},
{"f_8477eval.scm",(void*)f_8477},
{"f_8480eval.scm",(void*)f_8480},
{"f_8483eval.scm",(void*)f_8483},
{"f_8486eval.scm",(void*)f_8486},
{"f_8489eval.scm",(void*)f_8489},
{"f_8440eval.scm",(void*)f_8440},
{"f_8444eval.scm",(void*)f_8444},
{"f_8447eval.scm",(void*)f_8447},
{"f_8416eval.scm",(void*)f_8416},
{"f_8422eval.scm",(void*)f_8422},
{"f_8432eval.scm",(void*)f_8432},
{"f_8293eval.scm",(void*)f_8293},
{"f_8351eval.scm",(void*)f_8351},
{"f_8402eval.scm",(void*)f_8402},
{"f_8361eval.scm",(void*)f_8361},
{"f_8363eval.scm",(void*)f_8363},
{"f_8387eval.scm",(void*)f_8387},
{"f_8373eval.scm",(void*)f_8373},
{"f_8334eval.scm",(void*)f_8334},
{"f_8299eval.scm",(void*)f_8299},
{"f_8315eval.scm",(void*)f_8315},
{"f_8321eval.scm",(void*)f_8321},
{"f_8312eval.scm",(void*)f_8312},
{"f_8274eval.scm",(void*)f_8274},
{"f_8278eval.scm",(void*)f_8278},
{"f_8241eval.scm",(void*)f_8241},
{"f_8243eval.scm",(void*)f_8243},
{"f_8247eval.scm",(void*)f_8247},
{"f_8203eval.scm",(void*)f_8203},
{"f_8210eval.scm",(void*)f_8210},
{"f_8217eval.scm",(void*)f_8217},
{"f_8159eval.scm",(void*)f_8159},
{"f_8192eval.scm",(void*)f_8192},
{"f_8179eval.scm",(void*)f_8179},
{"f_8156eval.scm",(void*)f_8156},
{"f_8037eval.scm",(void*)f_8037},
{"f_8131eval.scm",(void*)f_8131},
{"f_8141eval.scm",(void*)f_8141},
{"f_8129eval.scm",(void*)f_8129},
{"f_8058eval.scm",(void*)f_8058},
{"f_8082eval.scm",(void*)f_8082},
{"f_8101eval.scm",(void*)f_8101},
{"f_8076eval.scm",(void*)f_8076},
{"f_7929eval.scm",(void*)f_7929},
{"f_7939eval.scm",(void*)f_7939},
{"f_7944eval.scm",(void*)f_7944},
{"f_7971eval.scm",(void*)f_7971},
{"f_8004eval.scm",(void*)f_8004},
{"f_7965eval.scm",(void*)f_7965},
{"f_7866eval.scm",(void*)f_7866},
{"f_7870eval.scm",(void*)f_7870},
{"f_7878eval.scm",(void*)f_7878},
{"f_7898eval.scm",(void*)f_7898},
{"f_7822eval.scm",(void*)f_7822},
{"f_7854eval.scm",(void*)f_7854},
{"f_7840eval.scm",(void*)f_7840},
{"f_7423eval.scm",(void*)f_7423},
{"f_7698eval.scm",(void*)f_7698},
{"f_7707eval.scm",(void*)f_7707},
{"f_7733eval.scm",(void*)f_7733},
{"f_7735eval.scm",(void*)f_7735},
{"f_7768eval.scm",(void*)f_7768},
{"f_7758eval.scm",(void*)f_7758},
{"f_7753eval.scm",(void*)f_7753},
{"f_7447eval.scm",(void*)f_7447},
{"f_7457eval.scm",(void*)f_7457},
{"f_7591eval.scm",(void*)f_7591},
{"f_7672eval.scm",(void*)f_7672},
{"f_7603eval.scm",(void*)f_7603},
{"f_7618eval.scm",(void*)f_7618},
{"f_7638eval.scm",(void*)f_7638},
{"f_7636eval.scm",(void*)f_7636},
{"f_7622eval.scm",(void*)f_7622},
{"f_7614eval.scm",(void*)f_7614},
{"f_7533eval.scm",(void*)f_7533},
{"f_7551eval.scm",(void*)f_7551},
{"f_7559eval.scm",(void*)f_7559},
{"f_7547eval.scm",(void*)f_7547},
{"f_7506eval.scm",(void*)f_7506},
{"f_7469eval.scm",(void*)f_7469},
{"f_7493eval.scm",(void*)f_7493},
{"f_7489eval.scm",(void*)f_7489},
{"f_7481eval.scm",(void*)f_7481},
{"f_7472eval.scm",(void*)f_7472},
{"f_7426eval.scm",(void*)f_7426},
{"f_7441eval.scm",(void*)f_7441},
{"f_7435eval.scm",(void*)f_7435},
{"f_7374eval.scm",(void*)f_7374},
{"f_7380eval.scm",(void*)f_7380},
{"f_7394eval.scm",(void*)f_7394},
{"f_7397eval.scm",(void*)f_7397},
{"f_7404eval.scm",(void*)f_7404},
{"f_7368eval.scm",(void*)f_7368},
{"f_7337eval.scm",(void*)f_7337},
{"f_7341eval.scm",(void*)f_7341},
{"f_7366eval.scm",(void*)f_7366},
{"f_7344eval.scm",(void*)f_7344},
{"f_7362eval.scm",(void*)f_7362},
{"f_7347eval.scm",(void*)f_7347},
{"f_7354eval.scm",(void*)f_7354},
{"f_7324eval.scm",(void*)f_7324},
{"f_7330eval.scm",(void*)f_7330},
{"f_7310eval.scm",(void*)f_7310},
{"f_7321eval.scm",(void*)f_7321},
{"f_7290eval.scm",(void*)f_7290},
{"f_7296eval.scm",(void*)f_7296},
{"f_7303eval.scm",(void*)f_7303},
{"f_7222eval.scm",(void*)f_7222},
{"f_7285eval.scm",(void*)f_7285},
{"f_7226eval.scm",(void*)f_7226},
{"f_7229eval.scm",(void*)f_7229},
{"f_7247eval.scm",(void*)f_7247},
{"f_7253eval.scm",(void*)f_7253},
{"f_7145eval.scm",(void*)f_7145},
{"f_7219eval.scm",(void*)f_7219},
{"f_7212eval.scm",(void*)f_7212},
{"f_7179eval.scm",(void*)f_7179},
{"f_7181eval.scm",(void*)f_7181},
{"f_7194eval.scm",(void*)f_7194},
{"f_7148eval.scm",(void*)f_7148},
{"f_7152eval.scm",(void*)f_7152},
{"f_7172eval.scm",(void*)f_7172},
{"f_7158eval.scm",(void*)f_7158},
{"f_7168eval.scm",(void*)f_7168},
{"f_7161eval.scm",(void*)f_7161},
{"f_6982eval.scm",(void*)f_6982},
{"f_7087eval.scm",(void*)f_7087},
{"f_7104eval.scm",(void*)f_7104},
{"f_7112eval.scm",(void*)f_7112},
{"f_7004eval.scm",(void*)f_7004},
{"f_7009eval.scm",(void*)f_7009},
{"f_7048eval.scm",(void*)f_7048},
{"f_7035eval.scm",(void*)f_7035},
{"f_6991eval.scm",(void*)f_6991},
{"f_6985eval.scm",(void*)f_6985},
{"f_6926eval.scm",(void*)f_6926},
{"f_6935eval.scm",(void*)f_6935},
{"f_6973eval.scm",(void*)f_6973},
{"f_6953eval.scm",(void*)f_6953},
{"f_6897eval.scm",(void*)f_6897},
{"f_6904eval.scm",(void*)f_6904},
{"f_6914eval.scm",(void*)f_6914},
{"f_6791eval.scm",(void*)f_6791},
{"f_6795eval.scm",(void*)f_6795},
{"f_6887eval.scm",(void*)f_6887},
{"f_6891eval.scm",(void*)f_6891},
{"f_6804eval.scm",(void*)f_6804},
{"f_6873eval.scm",(void*)f_6873},
{"f_6869eval.scm",(void*)f_6869},
{"f_6807eval.scm",(void*)f_6807},
{"f_6856eval.scm",(void*)f_6856},
{"f_6859eval.scm",(void*)f_6859},
{"f_6862eval.scm",(void*)f_6862},
{"f_6810eval.scm",(void*)f_6810},
{"f_6815eval.scm",(void*)f_6815},
{"f_6849eval.scm",(void*)f_6849},
{"f_6828eval.scm",(void*)f_6828},
{"f_6831eval.scm",(void*)f_6831},
{"f_6751eval.scm",(void*)f_6751},
{"f_6772eval.scm",(void*)f_6772},
{"f_6755eval.scm",(void*)f_6755},
{"f_6769eval.scm",(void*)f_6769},
{"f_6758eval.scm",(void*)f_6758},
{"f_6766eval.scm",(void*)f_6766},
{"f_6761eval.scm",(void*)f_6761},
{"f_6715eval.scm",(void*)f_6715},
{"f_6723eval.scm",(void*)f_6723},
{"f_6693eval.scm",(void*)f_6693},
{"f_6306eval.scm",(void*)f_6306},
{"f_6648eval.scm",(void*)f_6648},
{"f_6643eval.scm",(void*)f_6643},
{"f_6308eval.scm",(void*)f_6308},
{"f_6642eval.scm",(void*)f_6642},
{"f_6312eval.scm",(void*)f_6312},
{"f_6576eval.scm",(void*)f_6576},
{"f_6591eval.scm",(void*)f_6591},
{"f_6594eval.scm",(void*)f_6594},
{"f_6597eval.scm",(void*)f_6597},
{"f_6603eval.scm",(void*)f_6603},
{"f_6606eval.scm",(void*)f_6606},
{"f_6612eval.scm",(void*)f_6612},
{"f_6315eval.scm",(void*)f_6315},
{"f_6567eval.scm",(void*)f_6567},
{"f_6558eval.scm",(void*)f_6558},
{"f_6561eval.scm",(void*)f_6561},
{"f_6321eval.scm",(void*)f_6321},
{"f_6543eval.scm",(void*)f_6543},
{"f_6515eval.scm",(void*)f_6515},
{"f_6539eval.scm",(void*)f_6539},
{"f_6535eval.scm",(void*)f_6535},
{"f_6531eval.scm",(void*)f_6531},
{"f_6324eval.scm",(void*)f_6324},
{"f_6332eval.scm",(void*)f_6332},
{"f_6502eval.scm",(void*)f_6502},
{"f_6336eval.scm",(void*)f_6336},
{"f_6487eval.scm",(void*)f_6487},
{"f_6360eval.scm",(void*)f_6360},
{"f_6364eval.scm",(void*)f_6364},
{"f_6478eval.scm",(void*)f_6478},
{"f_6372eval.scm",(void*)f_6372},
{"f_6376eval.scm",(void*)f_6376},
{"f_6472eval.scm",(void*)f_6472},
{"f_6379eval.scm",(void*)f_6379},
{"f_6382eval.scm",(void*)f_6382},
{"f_6387eval.scm",(void*)f_6387},
{"f_6397eval.scm",(void*)f_6397},
{"f_6443eval.scm",(void*)f_6443},
{"f_6452eval.scm",(void*)f_6452},
{"f_6456eval.scm",(void*)f_6456},
{"f_6409eval.scm",(void*)f_6409},
{"f_6416eval.scm",(void*)f_6416},
{"f_6427eval.scm",(void*)f_6427},
{"f_6438eval.scm",(void*)f_6438},
{"f_6431eval.scm",(void*)f_6431},
{"f_6421eval.scm",(void*)f_6421},
{"f_6400eval.scm",(void*)f_6400},
{"f_6407eval.scm",(void*)f_6407},
{"f_6369eval.scm",(void*)f_6369},
{"f_6346eval.scm",(void*)f_6346},
{"f_6337eval.scm",(void*)f_6337},
{"f_6327eval.scm",(void*)f_6327},
{"f_6260eval.scm",(void*)f_6260},
{"f_6270eval.scm",(void*)f_6270},
{"f_6185eval.scm",(void*)f_6185},
{"f_6197eval.scm",(void*)f_6197},
{"f_6210eval.scm",(void*)f_6210},
{"f_6192eval.scm",(void*)f_6192},
{"f_6180eval.scm",(void*)f_6180},
{"f_6096eval.scm",(void*)f_6096},
{"f_6109eval.scm",(void*)f_6109},
{"f_6142eval.scm",(void*)f_6142},
{"f_6123eval.scm",(void*)f_6123},
{"f_6099eval.scm",(void*)f_6099},
{"f_6082eval.scm",(void*)f_6082},
{"f_6090eval.scm",(void*)f_6090},
{"f_6094eval.scm",(void*)f_6094},
{"f_3830eval.scm",(void*)f_3830},
{"f_5827eval.scm",(void*)f_5827},
{"f_5831eval.scm",(void*)f_5831},
{"f_6044eval.scm",(void*)f_6044},
{"f_6020eval.scm",(void*)f_6020},
{"f_6021eval.scm",(void*)f_6021},
{"f_6032eval.scm",(void*)f_6032},
{"f_6038eval.scm",(void*)f_6038},
{"f_6036eval.scm",(void*)f_6036},
{"f_5977eval.scm",(void*)f_5977},
{"f_5980eval.scm",(void*)f_5980},
{"f_5983eval.scm",(void*)f_5983},
{"f_5986eval.scm",(void*)f_5986},
{"f_5987eval.scm",(void*)f_5987},
{"f_5998eval.scm",(void*)f_5998},
{"f_6002eval.scm",(void*)f_6002},
{"f_6006eval.scm",(void*)f_6006},
{"f_6010eval.scm",(void*)f_6010},
{"f_6013eval.scm",(void*)f_6013},
{"f_5935eval.scm",(void*)f_5935},
{"f_5938eval.scm",(void*)f_5938},
{"f_5941eval.scm",(void*)f_5941},
{"f_5942eval.scm",(void*)f_5942},
{"f_5953eval.scm",(void*)f_5953},
{"f_5957eval.scm",(void*)f_5957},
{"f_5961eval.scm",(void*)f_5961},
{"f_5964eval.scm",(void*)f_5964},
{"f_5900eval.scm",(void*)f_5900},
{"f_5903eval.scm",(void*)f_5903},
{"f_5904eval.scm",(void*)f_5904},
{"f_5915eval.scm",(void*)f_5915},
{"f_5919eval.scm",(void*)f_5919},
{"f_5922eval.scm",(void*)f_5922},
{"f_5872eval.scm",(void*)f_5872},
{"f_5873eval.scm",(void*)f_5873},
{"f_5884eval.scm",(void*)f_5884},
{"f_5887eval.scm",(void*)f_5887},
{"f_5853eval.scm",(void*)f_5853},
{"f_5863eval.scm",(void*)f_5863},
{"f_5801eval.scm",(void*)f_5801},
{"f_4058eval.scm",(void*)f_4058},
{"f_4161eval.scm",(void*)f_4161},
{"f_4217eval.scm",(void*)f_4217},
{"f_4246eval.scm",(void*)f_4246},
{"f_4252eval.scm",(void*)f_4252},
{"f_5621eval.scm",(void*)f_5621},
{"f_5608eval.scm",(void*)f_5608},
{"f_5569eval.scm",(void*)f_5569},
{"f_5558eval.scm",(void*)f_5558},
{"f_5520eval.scm",(void*)f_5520},
{"f_5514eval.scm",(void*)f_5514},
{"f_5468eval.scm",(void*)f_5468},
{"f_5490eval.scm",(void*)f_5490},
{"f_5498eval.scm",(void*)f_5498},
{"f_5480eval.scm",(void*)f_5480},
{"f_5462eval.scm",(void*)f_5462},
{"f_5438eval.scm",(void*)f_5438},
{"f_5445eval.scm",(void*)f_5445},
{"f_5407eval.scm",(void*)f_5407},
{"f_5410eval.scm",(void*)f_5410},
{"f_5413eval.scm",(void*)f_5413},
{"f_5432eval.scm",(void*)f_5432},
{"f_5430eval.scm",(void*)f_5430},
{"f_5420eval.scm",(void*)f_5420},
{"f_5005eval.scm",(void*)f_5005},
{"f_5342eval.scm",(void*)f_5342},
{"f_5353eval.scm",(void*)f_5353},
{"f_5347eval.scm",(void*)f_5347},
{"f_5017eval.scm",(void*)f_5017},
{"f_5022eval.scm",(void*)f_5022},
{"f_5331eval.scm",(void*)f_5331},
{"f_5325eval.scm",(void*)f_5325},
{"f_5029eval.scm",(void*)f_5029},
{"f_5287eval.scm",(void*)f_5287},
{"f_5293eval.scm",(void*)f_5293},
{"f_5317eval.scm",(void*)f_5317},
{"f_5264eval.scm",(void*)f_5264},
{"f_5270eval.scm",(void*)f_5270},
{"f_5755eval.scm",(void*)f_5755},
{"f_5784eval.scm",(void*)f_5784},
{"f_5286eval.scm",(void*)f_5286},
{"f_5282eval.scm",(void*)f_5282},
{"f_5242eval.scm",(void*)f_5242},
{"f_5248eval.scm",(void*)f_5248},
{"f_5260eval.scm",(void*)f_5260},
{"f_5223eval.scm",(void*)f_5223},
{"f_5229eval.scm",(void*)f_5229},
{"f_5195eval.scm",(void*)f_5195},
{"f_5201eval.scm",(void*)f_5201},
{"f_5176eval.scm",(void*)f_5176},
{"f_5182eval.scm",(void*)f_5182},
{"f_5148eval.scm",(void*)f_5148},
{"f_5154eval.scm",(void*)f_5154},
{"f_5129eval.scm",(void*)f_5129},
{"f_5135eval.scm",(void*)f_5135},
{"f_5101eval.scm",(void*)f_5101},
{"f_5107eval.scm",(void*)f_5107},
{"f_5082eval.scm",(void*)f_5082},
{"f_5088eval.scm",(void*)f_5088},
{"f_5058eval.scm",(void*)f_5058},
{"f_5064eval.scm",(void*)f_5064},
{"f_5039eval.scm",(void*)f_5039},
{"f_5045eval.scm",(void*)f_5045},
{"f_4667eval.scm",(void*)f_4667},
{"f_4992eval.scm",(void*)f_4992},
{"f_4676eval.scm",(void*)f_4676},
{"f_4986eval.scm",(void*)f_4986},
{"f_4980eval.scm",(void*)f_4980},
{"f_4682eval.scm",(void*)f_4682},
{"f_4964eval.scm",(void*)f_4964},
{"f_4917eval.scm",(void*)f_4917},
{"f_4918eval.scm",(void*)f_4918},
{"f_4922eval.scm",(void*)f_4922},
{"f_4934eval.scm",(void*)f_4934},
{"f_4959eval.scm",(void*)f_4959},
{"f_4925eval.scm",(void*)f_4925},
{"f_4841eval.scm",(void*)f_4841},
{"f_4902eval.scm",(void*)f_4902},
{"f_4844eval.scm",(void*)f_4844},
{"f_4850eval.scm",(void*)f_4850},
{"f_4886eval.scm",(void*)f_4886},
{"f_4853eval.scm",(void*)f_4853},
{"f_4854eval.scm",(void*)f_4854},
{"f_4870eval.scm",(void*)f_4870},
{"f_4874eval.scm",(void*)f_4874},
{"f_4878eval.scm",(void*)f_4878},
{"f_4882eval.scm",(void*)f_4882},
{"f_4774eval.scm",(void*)f_4774},
{"f_4820eval.scm",(void*)f_4820},
{"f_4777eval.scm",(void*)f_4777},
{"f_4783eval.scm",(void*)f_4783},
{"f_4784eval.scm",(void*)f_4784},
{"f_4800eval.scm",(void*)f_4800},
{"f_4804eval.scm",(void*)f_4804},
{"f_4808eval.scm",(void*)f_4808},
{"f_4725eval.scm",(void*)f_4725},
{"f_4753eval.scm",(void*)f_4753},
{"f_4728eval.scm",(void*)f_4728},
{"f_4729eval.scm",(void*)f_4729},
{"f_4745eval.scm",(void*)f_4745},
{"f_4749eval.scm",(void*)f_4749},
{"f_4691eval.scm",(void*)f_4691},
{"f_4692eval.scm",(void*)f_4692},
{"f_4708eval.scm",(void*)f_4708},
{"f_4558eval.scm",(void*)f_4558},
{"f_4572eval.scm",(void*)f_4572},
{"f_4576eval.scm",(void*)f_4576},
{"f_4585eval.scm",(void*)f_4585},
{"f_4618eval.scm",(void*)f_4618},
{"f_4626eval.scm",(void*)f_4626},
{"f_4591eval.scm",(void*)f_4591},
{"f_4594eval.scm",(void*)f_4594},
{"f_4610eval.scm",(void*)f_4610},
{"f_4601eval.scm",(void*)f_4601},
{"f_4609eval.scm",(void*)f_4609},
{"f_4646eval.scm",(void*)f_4646},
{"f_4654eval.scm",(void*)f_4654},
{"f_4633eval.scm",(void*)f_4633},
{"f_4645eval.scm",(void*)f_4645},
{"f_4566eval.scm",(void*)f_4566},
{"f_4450eval.scm",(void*)f_4450},
{"f_4509eval.scm",(void*)f_4509},
{"f_4512eval.scm",(void*)f_4512},
{"f_4515eval.scm",(void*)f_4515},
{"f_4516eval.scm",(void*)f_4516},
{"f_4520eval.scm",(void*)f_4520},
{"f_4523eval.scm",(void*)f_4523},
{"f_4487eval.scm",(void*)f_4487},
{"f_4490eval.scm",(void*)f_4490},
{"f_4491eval.scm",(void*)f_4491},
{"f_4495eval.scm",(void*)f_4495},
{"f_4393eval.scm",(void*)f_4393},
{"f_4396eval.scm",(void*)f_4396},
{"f_4399eval.scm",(void*)f_4399},
{"f_4402eval.scm",(void*)f_4402},
{"f_4403eval.scm",(void*)f_4403},
{"f_4410eval.scm",(void*)f_4410},
{"f_4383eval.scm",(void*)f_4383},
{"f_4349eval.scm",(void*)f_4349},
{"f_4343eval.scm",(void*)f_4343},
{"f_4344eval.scm",(void*)f_4344},
{"f_4267eval.scm",(void*)f_4267},
{"f_4327eval.scm",(void*)f_4327},
{"f_4325eval.scm",(void*)f_4325},
{"f_4317eval.scm",(void*)f_4317},
{"f_4309eval.scm",(void*)f_4309},
{"f_4301eval.scm",(void*)f_4301},
{"f_4293eval.scm",(void*)f_4293},
{"f_4285eval.scm",(void*)f_4285},
{"f_4277eval.scm",(void*)f_4277},
{"f_4218eval.scm",(void*)f_4218},
{"f_4207eval.scm",(void*)f_4207},
{"f_4205eval.scm",(void*)f_4205},
{"f_4194eval.scm",(void*)f_4194},
{"f_4192eval.scm",(void*)f_4192},
{"f_4184eval.scm",(void*)f_4184},
{"f_4176eval.scm",(void*)f_4176},
{"f_4168eval.scm",(void*)f_4168},
{"f_4076eval.scm",(void*)f_4076},
{"f_4086eval.scm",(void*)f_4086},
{"f_4135eval.scm",(void*)f_4135},
{"f_4120eval.scm",(void*)f_4120},
{"f_4115eval.scm",(void*)f_4115},
{"f_4116eval.scm",(void*)f_4116},
{"f_4092eval.scm",(void*)f_4092},
{"f_4095eval.scm",(void*)f_4095},
{"f_4096eval.scm",(void*)f_4096},
{"f_4151eval.scm",(void*)f_4151},
{"f_4142eval.scm",(void*)f_4142},
{"f_4070eval.scm",(void*)f_4070},
{"f_4052eval.scm",(void*)f_4052},
{"f_4046eval.scm",(void*)f_4046},
{"f_4040eval.scm",(void*)f_4040},
{"f_3987eval.scm",(void*)f_3987},
{"f_3991eval.scm",(void*)f_3991},
{"f_4038eval.scm",(void*)f_4038},
{"f_4006eval.scm",(void*)f_4006},
{"f_4015eval.scm",(void*)f_4015},
{"f_3875eval.scm",(void*)f_3875},
{"f_3887eval.scm",(void*)f_3887},
{"f_3881eval.scm",(void*)f_3881},
{"f_3833eval.scm",(void*)f_3833},
{"f_3839eval.scm",(void*)f_3839},
{"f_3957eval.scm",(void*)f_3957},
{"f_3824eval.scm",(void*)f_3824},
{"f_3783eval.scm",(void*)f_3783},
{"f_3802eval.scm",(void*)f_3802},
{"f_3814eval.scm",(void*)f_3814},
{"f_3817eval.scm",(void*)f_3817},
{"f_3820eval.scm",(void*)f_3820},
{"f_3810eval.scm",(void*)f_3810},
{"f_3789eval.scm",(void*)f_3789},
{"f_3723eval.scm",(void*)f_3723},
{"f_3727eval.scm",(void*)f_3727},
{"f_3735eval.scm",(void*)f_3735},
{"f_3656eval.scm",(void*)f_3656},
{"f_3662eval.scm",(void*)f_3662},
{"f_3678eval.scm",(void*)f_3678},
{"f_3613eval.scm",(void*)f_3613},
{"f_3619eval.scm",(void*)f_3619},
{"f_3638eval.scm",(void*)f_3638},
{"f_3629eval.scm",(void*)f_3629},
{"f_3593eval.scm",(void*)f_3593},
{"f_3605eval.scm",(void*)f_3605},
{"f_3608eval.scm",(void*)f_3608},
{"f_3601eval.scm",(void*)f_3601},
{"f_3538eval.scm",(void*)f_3538},
{"f_3542eval.scm",(void*)f_3542},
{"f_3550eval.scm",(void*)f_3550},
{"f_3493eval.scm",(void*)f_3493},
{"f_3497eval.scm",(void*)f_3497},
{"f_3506eval.scm",(void*)f_3506},
{"f_3478eval.scm",(void*)f_3478},
{"f_3418eval.scm",(void*)f_3418},
{"f_3473eval.scm",(void*)f_3473},
{"f_3421eval.scm",(void*)f_3421},
{"f_3327eval.scm",(void*)f_3327},
{"f_3416eval.scm",(void*)f_3416},
{"f_3330eval.scm",(void*)f_3330},
{"f_3385eval.scm",(void*)f_3385},
{"f_2844eval.scm",(void*)f_2844},
{"f_3282eval.scm",(void*)f_3282},
{"f_3277eval.scm",(void*)f_3277},
{"f_2846eval.scm",(void*)f_2846},
{"f_3029eval.scm",(void*)f_3029},
{"f_3035eval.scm",(void*)f_3035},
{"f_3069eval.scm",(void*)f_3069},
{"f_3241eval.scm",(void*)f_3241},
{"f_3227eval.scm",(void*)f_3227},
{"f_3234eval.scm",(void*)f_3234},
{"f_3199eval.scm",(void*)f_3199},
{"f_3081eval.scm",(void*)f_3081},
{"f_3086eval.scm",(void*)f_3086},
{"f_3099eval.scm",(void*)f_3099},
{"f_3151eval.scm",(void*)f_3151},
{"f_3133eval.scm",(void*)f_3133},
{"f_3144eval.scm",(void*)f_3144},
{"f_2849eval.scm",(void*)f_2849},
{"f_2931eval.scm",(void*)f_2931},
{"f_3021eval.scm",(void*)f_3021},
{"f_3009eval.scm",(void*)f_3009},
{"f_2942eval.scm",(void*)f_2942},
{"f_3007eval.scm",(void*)f_3007},
{"f_2999eval.scm",(void*)f_2999},
{"f_2950eval.scm",(void*)f_2950},
{"f_2993eval.scm",(void*)f_2993},
{"f_2997eval.scm",(void*)f_2997},
{"f_2960eval.scm",(void*)f_2960},
{"f_2964eval.scm",(void*)f_2964},
{"f_2985eval.scm",(void*)f_2985},
{"f_2983eval.scm",(void*)f_2983},
{"f_2958eval.scm",(void*)f_2958},
{"f_2954eval.scm",(void*)f_2954},
{"f_2946eval.scm",(void*)f_2946},
{"f_2861eval.scm",(void*)f_2861},
{"f_2880eval.scm",(void*)f_2880},
{"f_2891eval.scm",(void*)f_2891},
{"f_2899eval.scm",(void*)f_2899},
{"f_2887eval.scm",(void*)f_2887},
{"f_2325eval.scm",(void*)f_2325},
{"f_2347eval.scm",(void*)f_2347},
{"f_2787eval.scm",(void*)f_2787},
{"f_2725eval.scm",(void*)f_2725},
{"f_2706eval.scm",(void*)f_2706},
{"f_2660eval.scm",(void*)f_2660},
{"f_2663eval.scm",(void*)f_2663},
{"f_2642eval.scm",(void*)f_2642},
{"f_2623eval.scm",(void*)f_2623},
{"f_2591eval.scm",(void*)f_2591},
{"f_2570eval.scm",(void*)f_2570},
{"f_2361eval.scm",(void*)f_2361},
{"f_2563eval.scm",(void*)f_2563},
{"f_2506eval.scm",(void*)f_2506},
{"f_2559eval.scm",(void*)f_2559},
{"f_2533eval.scm",(void*)f_2533},
{"f_2504eval.scm",(void*)f_2504},
{"f_2365eval.scm",(void*)f_2365},
{"f_2377eval.scm",(void*)f_2377},
{"f_2456eval.scm",(void*)f_2456},
{"f_2452eval.scm",(void*)f_2452},
{"f_2433eval.scm",(void*)f_2433},
{"f_2368eval.scm",(void*)f_2368},
{"f_2328eval.scm",(void*)f_2328},
{"f_2282eval.scm",(void*)f_2282},
{"f_2288eval.scm",(void*)f_2288},
{"f_2307eval.scm",(void*)f_2307},
{"f_2266eval.scm",(void*)f_2266},
{"f_2230eval.scm",(void*)f_2230},
{"f_2239eval.scm",(void*)f_2239},
{"f_2251eval.scm",(void*)f_2251},
{"f_2245eval.scm",(void*)f_2245},
{"f_2223eval.scm",(void*)f_2223},
{"f_2220eval.scm",(void*)f_2220},
{"f_2217eval.scm",(void*)f_2217},
{"f_1847eval.scm",(void*)f_1847},
{"f_2157eval.scm",(void*)f_2157},
{"f_2163eval.scm",(void*)f_2163},
{"f_2170eval.scm",(void*)f_2170},
{"f_2084eval.scm",(void*)f_2084},
{"f_2096eval.scm",(void*)f_2096},
{"f_2144eval.scm",(void*)f_2144},
{"f_2138eval.scm",(void*)f_2138},
{"f_2118eval.scm",(void*)f_2118},
{"f_1996eval.scm",(void*)f_1996},
{"f_2016eval.scm",(void*)f_2016},
{"f_2024eval.scm",(void*)f_2024},
{"f_2038eval.scm",(void*)f_2038},
{"f_2010eval.scm",(void*)f_2010},
{"f_1850eval.scm",(void*)f_1850},
{"f_1859eval.scm",(void*)f_1859},
{"f_1972eval.scm",(void*)f_1972},
{"f_1984eval.scm",(void*)f_1984},
{"f_1990eval.scm",(void*)f_1990},
{"f_1978eval.scm",(void*)f_1978},
{"f_1865eval.scm",(void*)f_1865},
{"f_1871eval.scm",(void*)f_1871},
{"f_1882eval.scm",(void*)f_1882},
{"f_1899eval.scm",(void*)f_1899},
{"f_1918eval.scm",(void*)f_1918},
{"f_1929eval.scm",(void*)f_1929},
{"f_1893eval.scm",(void*)f_1893},
{"f_1879eval.scm",(void*)f_1879},
{"f_1857eval.scm",(void*)f_1857},
{"f_1838eval.scm",(void*)f_1838},
{"f_1820eval.scm",(void*)f_1820},
{"f_1830eval.scm",(void*)f_1830},
{"f_1810eval.scm",(void*)f_1810},
{"f_1818eval.scm",(void*)f_1818},
{"f_1794eval.scm",(void*)f_1794},
{"f_1800eval.scm",(void*)f_1800},
{"f_1778eval.scm",(void*)f_1778},
{"f_1784eval.scm",(void*)f_1784},
{"f_1762eval.scm",(void*)f_1762},
{"f_1766eval.scm",(void*)f_1766},
{"f_1735eval.scm",(void*)f_1735},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
