/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:03
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: posixunix.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file uposixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
#else
static C_TLS struct {
  char *gr_name, gr_passwd;
  int gr_gid;
  char *gr_mem[ 1 ];
} C_group = { "", "", 0, { "" } };
#endif
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)      C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)       (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)      C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)    (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_unsetenv(s)      (unsetenv((char *)C_data_pointer(s)), C_SCHEME_TRUE)
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
# define C_unsetenv(s)      C_fix(putenv((char *)C_data_pointer(s)))
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

/* It is assumed that 'int' is-a 'long' */
#define C_ftell(p)          C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_num_to_int(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define cpy_tmvec_to_tmstc08(ptm, v) \
    (memset((ptm), 0, sizeof(struct tm)), \
    (ptm)->tm_sec = C_unfix(C_block_item((v), 0)), \
    (ptm)->tm_min = C_unfix(C_block_item((v), 1)), \
    (ptm)->tm_hour = C_unfix(C_block_item((v), 2)), \
    (ptm)->tm_mday = C_unfix(C_block_item((v), 3)), \
    (ptm)->tm_mon = C_unfix(C_block_item((v), 4)), \
    (ptm)->tm_year = C_unfix(C_block_item((v), 5)), \
    (ptm)->tm_wday = C_unfix(C_block_item((v), 6)), \
    (ptm)->tm_yday = C_unfix(C_block_item((v), 7)), \
    (ptm)->tm_isdst = (C_block_item((v), 8) != C_SCHEME_FALSE))

#define cpy_tmvec_to_tmstc9(ptm, v) \
    (((struct tm *)ptm)->tm_gmtoff = C_unfix(C_block_item((v), 9)))

#define cpy_tmstc08_to_tmvec(v, ptm) \
    (C_set_block_item((v), 0, C_fix(((struct tm *)ptm)->tm_sec)), \
    C_set_block_item((v), 1, C_fix((ptm)->tm_min)), \
    C_set_block_item((v), 2, C_fix((ptm)->tm_hour)), \
    C_set_block_item((v), 3, C_fix((ptm)->tm_mday)), \
    C_set_block_item((v), 4, C_fix((ptm)->tm_mon)), \
    C_set_block_item((v), 5, C_fix((ptm)->tm_year)), \
    C_set_block_item((v), 6, C_fix((ptm)->tm_wday)), \
    C_set_block_item((v), 7, C_fix((ptm)->tm_yday)), \
    C_set_block_item((v), 8, ((ptm)->tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define cpy_tmstc9_to_tmvec(v, ptm) \
    (C_set_block_item((v), 9, C_fix((ptm)->tm_gmtoff)))

#define C_tm_set_08(v)  cpy_tmvec_to_tmstc08( &C_tm, (v) )
#define C_tm_set_9(v)   cpy_tmvec_to_tmstc9( &C_tm, (v) )

#define C_tm_get_08(v)  cpy_tmstc08_to_tmvec( (v), &C_tm )
#define C_tm_get_9(v)   cpy_tmstc9_to_tmvec( (v), &C_tm )

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  return v;
}

#else

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  C_tm_set_9( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  C_tm_get_9( v );
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[460];
static double C_possibly_force_alignment;


/* from k8162 in set-root-directory! in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall stub2194(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2194(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from sleep in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall stub1854(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1854(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall stub1851(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1851(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall stub1849(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1849(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub1744(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1744(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k7113 */
static C_word C_fcall stub1737(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1737(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub1732(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1732(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k7105 */
static C_word C_fcall stub1725(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1725(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k7089 in process-fork in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall stub1713(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1713(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub1700(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1700(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1642(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1642(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k6910 */
static C_word C_fcall stub1623(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1623(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from ttyname */
static C_word C_fcall stub1613(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1613(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from set-alarm! in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall stub1580(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1580(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from ex0 */
static C_word C_fcall stub1575(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1575(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1570(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1570(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = time(NULL);struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub1544(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1544(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub1514(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1514(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub1508(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1508(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub1487(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1487(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k6443 */
static C_word C_fcall stub1434(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1434(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k6385 */
static C_word C_fcall stub1403(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub1403(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from get */
static C_word C_fcall stub1385(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1385(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k5077 in k5073 in file-link in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall stub968(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub968(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k4791 in initialize-groups in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall stub874(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub874(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from _ensure-groups */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub831(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub831(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from _get-groups */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub827(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub827(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from group-member */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub800(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub800(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a8229 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall stub773(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub773(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a8247 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall stub767(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub767(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a8265 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall stub761(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub761(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a8283 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall stub755(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub755(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from fd_test */
static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from fd_set */
static C_word C_fcall stub121(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub121(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from fd_zero */
static C_word C_fcall stub116(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub116(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from fcntl */
static C_word C_fcall stub33(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub33(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from ##sys#file-select-one in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub26(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub26(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from ##sys#file-nonblocking! in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub22(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub22(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from strerror */
static C_word C_fcall stub12(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub12(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_ccall f_2472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8308)
static void C_ccall f_8308(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8324)
static void C_ccall f_8324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8312)
static void C_ccall f_8312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8302)
static void C_ccall f_8302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8287)
static void C_ccall f_8287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8284)
static void C_ccall f_8284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8279)
static void C_ccall f_8279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8266)
static void C_ccall f_8266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_ccall f_4486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8251)
static void C_ccall f_8251(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8261)
static void C_ccall f_8261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8248)
static void C_ccall f_8248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8233)
static void C_ccall f_8233(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8243)
static void C_ccall f_8243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8230)
static void C_ccall f_8230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8209)
static void C_ccall f_8209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8225)
static void C_ccall f_8225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8191)
static void C_ccall f_8191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8198)
static void C_ccall f_8198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8168)
static void C_ccall f_8168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8164)
static void C_ccall f_8164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7916)
static void C_ccall f_7916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7916)
static void C_ccall f_7916r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8093)
static void C_fcall f_8093(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8099)
static void C_ccall f_8099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8088)
static void C_fcall f_8088(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8083)
static void C_fcall f_8083(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7918)
static void C_fcall f_7918(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8070)
static void C_ccall f_8070(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8078)
static void C_ccall f_8078(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7925)
static void C_fcall f_7925(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8058)
static void C_ccall f_8058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8052)
static void C_ccall f_8052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7935)
static void C_ccall f_7935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7937)
static void C_fcall f_7937(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7956)
static void C_ccall f_7956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8038)
static void C_ccall f_8038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8045)
static void C_ccall f_8045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8032)
static void C_ccall f_8032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7971)
static void C_ccall f_7971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8025)
static void C_ccall f_8025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8022)
static void C_ccall f_8022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8012)
static void C_ccall f_8012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7988)
static void C_ccall f_7988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8010)
static void C_ccall f_8010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7996)
static void C_ccall f_7996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8003)
static void C_ccall f_8003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8000)
static void C_ccall f_8000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7983)
static void C_ccall f_7983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7981)
static void C_ccall f_7981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8059)
static void C_ccall f_8059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7859)
static void C_ccall f_7859(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7859)
static void C_ccall f_7859r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7871)
static void C_fcall f_7871(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_fcall f_7866(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7861)
static void C_fcall f_7861(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7814)
static void C_fcall f_7814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7809)
static void C_fcall f_7809(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7804)
static void C_fcall f_7804(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7725)
static void C_fcall f_7725(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7796)
static void C_ccall f_7796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7800)
static void C_ccall f_7800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7762)
static void C_fcall f_7762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7776)
static void C_ccall f_7776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7770)
static void C_ccall f_7770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7727)
static C_word C_fcall f_7727(C_word t0,C_word t1);
C_noret_decl(f_7736)
static C_word C_fcall f_7736(C_word t0,C_word t1);
C_noret_decl(f_7667)
static void C_ccall f_7667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7710)
static void C_ccall f_7710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7690)
static void C_ccall f_7690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7706)
static void C_ccall f_7706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7694)
static void C_ccall f_7694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7702)
static void C_ccall f_7702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7698)
static void C_ccall f_7698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7673)
static void C_ccall f_7673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7656)
static void C_fcall f_7656(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7660)
static void C_ccall f_7660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7645)
static void C_fcall f_7645(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7649)
static void C_ccall f_7649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7600)
static void C_fcall f_7600(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7604)
static void C_ccall f_7604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7607)
static void C_ccall f_7607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7610)
static void C_ccall f_7610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7617)
static void C_fcall f_7617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7623)
static void C_ccall f_7623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7627)
static void C_ccall f_7627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7644)
static void C_fcall f_7644(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7630)
static void C_ccall f_7630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7640)
static void C_fcall f_7640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7633)
static void C_ccall f_7633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7621)
static void C_ccall f_7621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7567)
static void C_fcall f_7567(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7580)
static void C_ccall f_7580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7492)
static void C_ccall f_7492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7553)
static void C_fcall f_7553(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7533)
static void C_fcall f_7533(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7548)
static void C_ccall f_7548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7542)
static void C_ccall f_7542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7496)
static void C_fcall f_7496(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7498)
static void C_ccall f_7498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7447)
static void C_ccall f_7447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7466)
static void C_ccall f_7466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7470)
static void C_ccall f_7470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7434)
static void C_ccall f_7434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7425)
static void C_ccall f_7425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7429)
static void C_ccall f_7429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7398)
static void C_ccall f_7398(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7398)
static void C_ccall f_7398r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7395)
static void C_ccall f_7395(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7392)
static void C_ccall f_7392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7389)
static void C_ccall f_7389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7314)
static void C_ccall f_7314(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7314)
static void C_ccall f_7314r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7341)
static void C_ccall f_7341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7297)
static void C_ccall f_7297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7252)
static void C_fcall f_7252(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7247)
static void C_fcall f_7247(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7120)
static void C_fcall f_7120(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7130)
static void C_ccall f_7130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7138)
static void C_fcall f_7138(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7184)
static void C_fcall f_7184(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7151)
static void C_ccall f_7151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7176)
static void C_ccall f_7176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7154)
static void C_ccall f_7154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6960)
static void C_ccall f_6960(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6960)
static void C_ccall f_6960r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6966)
static void C_fcall f_6966(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6987)
static void C_ccall f_6987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6994)
static void C_ccall f_6994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7001)
static void C_ccall f_7001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7003)
static void C_fcall f_7003(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7020)
static void C_ccall f_7020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7030)
static void C_ccall f_7030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7034)
static void C_ccall f_7034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6981)
static void C_ccall f_6981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6948)
static void C_ccall f_6948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6913)
static void C_ccall f_6913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6917)
static void C_ccall f_6917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6937)
static void C_ccall f_6937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6941)
static void C_ccall f_6941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6894)
static void C_ccall f_6894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6898)
static void C_ccall f_6898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_fcall f_6867(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6871)
static void C_ccall f_6871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6855)
static void C_ccall f_6855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6799)
static void C_ccall f_6799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6770)
static void C_ccall f_6770(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6770)
static void C_ccall f_6770r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6747)
static void C_ccall f_6747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6732)
static void C_ccall f_6732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6736)
static void C_ccall f_6736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6693)
static void C_ccall f_6693(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6693)
static void C_ccall f_6693r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6710)
static void C_ccall f_6710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6631)
static void C_ccall f_6631(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6631)
static void C_ccall f_6631r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6657)
static void C_ccall f_6657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6647)
static void C_ccall f_6647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6587)
static void C_ccall f_6587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_ccall f_6545(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6545)
static void C_ccall f_6545r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6549)
static void C_ccall f_6549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6518)
static void C_ccall f_6518(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6518)
static void C_ccall f_6518r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6522)
static void C_ccall f_6522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6499)
static void C_fcall f_6499(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_6395)
static void C_ccall f_6395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6401)
static void C_ccall f_6401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6307)
static void C_ccall f_6307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6313)
static void C_fcall f_6313(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6325)
static void C_fcall f_6325(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6343)
static void C_ccall f_6343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6275)
static void C_ccall f_6275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6286)
static void C_ccall f_6286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6249)
static void C_ccall f_6249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6273)
static void C_ccall f_6273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6256)
static void C_ccall f_6256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6213)
static void C_fcall f_6213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6234)
static void C_ccall f_6234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6230)
static void C_ccall f_6230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6156)
static void C_ccall f_6156(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6156)
static void C_ccall f_6156r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6160)
static void C_ccall f_6160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6145)
static void C_ccall f_6145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6126)
static void C_ccall f_6126(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6126)
static void C_ccall f_6126r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6130)
static void C_ccall f_6130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6108)
static void C_fcall f_6108(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6037)
static void C_fcall f_6037(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_fcall f_6062(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5998)
static void C_ccall f_5998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6026)
static void C_ccall f_6026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5938)
static void C_fcall f_5938(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_fcall f_5933(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5928)
static void C_fcall f_5928(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5744)
static void C_fcall f_5744(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5872)
static void C_fcall f_5872(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5840)
static void C_ccall f_5840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5796)
static void C_fcall f_5796(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5832)
static void C_ccall f_5832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5811)
static void C_ccall f_5811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5821)
static void C_ccall f_5821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5750)
static void C_fcall f_5750(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5785)
static void C_ccall f_5785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5766)
static void C_ccall f_5766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5667)
static void C_fcall f_5667(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5662)
static void C_fcall f_5662(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5657)
static void C_fcall f_5657(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5652)
static void C_fcall f_5652(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5265)
static void C_fcall f_5265(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5531)
static void C_fcall f_5531(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5583)
static void C_ccall f_5583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5457)
static void C_fcall f_5457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5459)
static void C_fcall f_5459(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5307)
static void C_fcall f_5307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5319)
static void C_fcall f_5319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5365)
static void C_ccall f_5365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static C_word C_fcall f_5299(C_word t0);
C_noret_decl(f_5276)
static void C_fcall f_5276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5243)
static void C_fcall f_5243(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5246)
static void C_ccall f_5246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5191)
static void C_ccall f_5191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5230)
static void C_ccall f_5230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5213)
static void C_ccall f_5213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_fcall f_5148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5111)
static void C_fcall f_5111(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5086)
static void C_ccall f_5086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5040)
static void C_ccall f_5040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4918)
static void C_fcall f_4918(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_fcall f_4740(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4672)
static void C_ccall f_4672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_fcall f_4683(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_fcall f_4597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4611)
static void C_ccall f_4611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_fcall f_4620(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4556)
static void C_ccall f_4556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4542)
static void C_ccall f_4542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4503)
static void C_fcall f_4503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4453)
static void C_ccall f_4453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4457)
static void C_ccall f_4457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4377)
static void C_fcall f_4377(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4349)
static C_word C_fcall f_4349(C_word t0);
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4291)
static void C_ccall f_4291(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_fcall f_4053(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_fcall f_4047(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_fcall f_3845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_fcall f_3864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3908)
static void C_fcall f_3908(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_fcall f_3734(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_fcall f_3802(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3662)
static void C_fcall f_3662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3701)
static void C_ccall f_3701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_fcall f_3646(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3536)
static void C_fcall f_3536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_fcall f_3531(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3433)
static void C_fcall f_3433(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_fcall f_3464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_fcall f_3486(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_fcall f_3270(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3282)
static void C_fcall f_3282(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_fcall f_3289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3014)
static void C_fcall f_3014(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2979)
static C_word C_fcall f_2979(C_word t0,C_word t1);
C_noret_decl(f_2774)
static void C_fcall f_2774(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static C_word C_fcall f_2937(C_word t0,C_word t1);
C_noret_decl(f_2780)
static void C_fcall f_2780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_fcall f_2783(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_fcall f_2881(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2894)
static void C_fcall f_2894(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_fcall f_2822(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_fcall f_2840(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2853)
static void C_fcall f_2853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2826)
static void C_fcall f_2826(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8093)
static void C_fcall trf_8093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8093(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8093(t0,t1);}

C_noret_decl(trf_8088)
static void C_fcall trf_8088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8088(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8088(t0,t1,t2);}

C_noret_decl(trf_8083)
static void C_fcall trf_8083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8083(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8083(t0,t1,t2,t3);}

C_noret_decl(trf_7918)
static void C_fcall trf_7918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7918(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7918(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7925)
static void C_fcall trf_7925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7925(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7925(t0,t1);}

C_noret_decl(trf_7937)
static void C_fcall trf_7937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7937(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7937(t0,t1,t2,t3);}

C_noret_decl(trf_7871)
static void C_fcall trf_7871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7871(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7871(t0,t1);}

C_noret_decl(trf_7866)
static void C_fcall trf_7866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7866(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7866(t0,t1,t2);}

C_noret_decl(trf_7861)
static void C_fcall trf_7861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7861(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7861(t0,t1,t2,t3);}

C_noret_decl(trf_7814)
static void C_fcall trf_7814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7814(t0,t1);}

C_noret_decl(trf_7809)
static void C_fcall trf_7809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7809(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7809(t0,t1,t2);}

C_noret_decl(trf_7804)
static void C_fcall trf_7804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7804(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7804(t0,t1,t2,t3);}

C_noret_decl(trf_7725)
static void C_fcall trf_7725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7725(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7725(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7762)
static void C_fcall trf_7762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7762(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7762(t0,t1);}

C_noret_decl(trf_7656)
static void C_fcall trf_7656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7656(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7656(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7645)
static void C_fcall trf_7645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7645(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7645(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7600)
static void C_fcall trf_7600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7600(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7600(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_7617)
static void C_fcall trf_7617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7617(t0,t1);}

C_noret_decl(trf_7644)
static void C_fcall trf_7644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7644(t0,t1);}

C_noret_decl(trf_7640)
static void C_fcall trf_7640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7640(t0,t1);}

C_noret_decl(trf_7567)
static void C_fcall trf_7567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7567(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7567(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7553)
static void C_fcall trf_7553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7553(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7553(t0,t1,t2,t3);}

C_noret_decl(trf_7533)
static void C_fcall trf_7533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7533(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7533(t0,t1,t2);}

C_noret_decl(trf_7496)
static void C_fcall trf_7496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7496(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7496(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_7252)
static void C_fcall trf_7252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7252(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7252(t0,t1);}

C_noret_decl(trf_7247)
static void C_fcall trf_7247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7247(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7247(t0,t1,t2);}

C_noret_decl(trf_7120)
static void C_fcall trf_7120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7120(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7120(t0,t1,t2,t3);}

C_noret_decl(trf_7138)
static void C_fcall trf_7138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7138(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7138(t0,t1,t2,t3);}

C_noret_decl(trf_7184)
static void C_fcall trf_7184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7184(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7184(t0,t1,t2,t3);}

C_noret_decl(trf_6966)
static void C_fcall trf_6966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6966(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6966(t0,t1,t2);}

C_noret_decl(trf_7003)
static void C_fcall trf_7003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7003(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7003(t0,t1,t2);}

C_noret_decl(trf_6867)
static void C_fcall trf_6867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6867(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6867(t0,t1,t2);}

C_noret_decl(trf_6499)
static void C_fcall trf_6499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6499(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6499(t0,t1,t2);}

C_noret_decl(trf_6313)
static void C_fcall trf_6313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6313(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6313(t0,t1,t2);}

C_noret_decl(trf_6325)
static void C_fcall trf_6325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6325(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6325(t0,t1,t2);}

C_noret_decl(trf_6213)
static void C_fcall trf_6213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6213(t0,t1);}

C_noret_decl(trf_6108)
static void C_fcall trf_6108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6108(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6108(t0,t1,t2,t3);}

C_noret_decl(trf_6037)
static void C_fcall trf_6037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6037(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6037(t0,t1,t2,t3);}

C_noret_decl(trf_6062)
static void C_fcall trf_6062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6062(t0,t1);}

C_noret_decl(trf_5938)
static void C_fcall trf_5938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5938(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5938(t0,t1);}

C_noret_decl(trf_5933)
static void C_fcall trf_5933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5933(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5933(t0,t1,t2);}

C_noret_decl(trf_5928)
static void C_fcall trf_5928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5928(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5928(t0,t1,t2,t3);}

C_noret_decl(trf_5744)
static void C_fcall trf_5744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5744(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5744(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5872)
static void C_fcall trf_5872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5872(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5872(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5796)
static void C_fcall trf_5796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5796(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5796(t0,t1);}

C_noret_decl(trf_5750)
static void C_fcall trf_5750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5750(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5750(t0,t1,t2,t3);}

C_noret_decl(trf_5667)
static void C_fcall trf_5667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5667(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5667(t0,t1);}

C_noret_decl(trf_5662)
static void C_fcall trf_5662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5662(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5662(t0,t1,t2);}

C_noret_decl(trf_5657)
static void C_fcall trf_5657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5657(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5657(t0,t1,t2,t3);}

C_noret_decl(trf_5652)
static void C_fcall trf_5652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5652(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5652(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5265)
static void C_fcall trf_5265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5265(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5265(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5531)
static void C_fcall trf_5531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5531(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5531(t0,t1,t2);}

C_noret_decl(trf_5457)
static void C_fcall trf_5457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5457(t0,t1);}

C_noret_decl(trf_5459)
static void C_fcall trf_5459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5459(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5459(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5307)
static void C_fcall trf_5307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5307(t0,t1);}

C_noret_decl(trf_5319)
static void C_fcall trf_5319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5319(t0,t1);}

C_noret_decl(trf_5276)
static void C_fcall trf_5276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5276(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5276(t0,t1);}

C_noret_decl(trf_5243)
static void C_fcall trf_5243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5243(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5243(t0,t1);}

C_noret_decl(trf_5148)
static void C_fcall trf_5148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5148(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5148(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5111)
static void C_fcall trf_5111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5111(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5111(t0,t1,t2);}

C_noret_decl(trf_4918)
static void C_fcall trf_4918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4918(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4918(t0,t1,t2,t3);}

C_noret_decl(trf_4740)
static void C_fcall trf_4740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4740(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4740(t0,t1,t2,t3);}

C_noret_decl(trf_4683)
static void C_fcall trf_4683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4683(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4683(t0,t1,t2);}

C_noret_decl(trf_4597)
static void C_fcall trf_4597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4597(t0,t1);}

C_noret_decl(trf_4620)
static void C_fcall trf_4620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4620(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4620(t0,t1,t2);}

C_noret_decl(trf_4503)
static void C_fcall trf_4503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4503(t0,t1);}

C_noret_decl(trf_4377)
static void C_fcall trf_4377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4377(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4377(t0,t1,t2,t3);}

C_noret_decl(trf_4053)
static void C_fcall trf_4053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4053(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4053(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4047)
static void C_fcall trf_4047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4047(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4047(t0,t1);}

C_noret_decl(trf_3845)
static void C_fcall trf_3845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3845(t0,t1);}

C_noret_decl(trf_3864)
static void C_fcall trf_3864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3864(t0,t1);}

C_noret_decl(trf_3908)
static void C_fcall trf_3908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3908(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3908(t0,t1);}

C_noret_decl(trf_3734)
static void C_fcall trf_3734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3734(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3734(t0,t1,t2,t3);}

C_noret_decl(trf_3802)
static void C_fcall trf_3802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3802(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3802(t0,t1);}

C_noret_decl(trf_3662)
static void C_fcall trf_3662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3662(t0,t1);}

C_noret_decl(trf_3646)
static void C_fcall trf_3646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3646(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3646(t0,t1);}

C_noret_decl(trf_3536)
static void C_fcall trf_3536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3536(t0,t1);}

C_noret_decl(trf_3531)
static void C_fcall trf_3531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3531(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3531(t0,t1,t2);}

C_noret_decl(trf_3433)
static void C_fcall trf_3433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3433(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3433(t0,t1,t2,t3);}

C_noret_decl(trf_3464)
static void C_fcall trf_3464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3464(t0,t1);}

C_noret_decl(trf_3486)
static void C_fcall trf_3486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3486(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3486(t0,t1);}

C_noret_decl(trf_3270)
static void C_fcall trf_3270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3270(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3270(t0,t1);}

C_noret_decl(trf_3282)
static void C_fcall trf_3282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3282(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3282(t0,t1,t2);}

C_noret_decl(trf_3289)
static void C_fcall trf_3289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3289(t0,t1);}

C_noret_decl(trf_3014)
static void C_fcall trf_3014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3014(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3014(t0,t1,t2,t3);}

C_noret_decl(trf_2774)
static void C_fcall trf_2774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2774(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2774(t0,t1);}

C_noret_decl(trf_2780)
static void C_fcall trf_2780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2780(t0,t1);}

C_noret_decl(trf_2783)
static void C_fcall trf_2783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2783(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2783(t0,t1);}

C_noret_decl(trf_2881)
static void C_fcall trf_2881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2881(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2881(t0,t1,t2);}

C_noret_decl(trf_2894)
static void C_fcall trf_2894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2894(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2894(t0,t1);}

C_noret_decl(trf_2822)
static void C_fcall trf_2822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2822(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2822(t0,t1);}

C_noret_decl(trf_2840)
static void C_fcall trf_2840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2840(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2840(t0,t1,t2);}

C_noret_decl(trf_2853)
static void C_fcall trf_2853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2853(t0,t1);}

C_noret_decl(trf_2826)
static void C_fcall trf_2826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2826(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2826(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3370)){
C_save(t1);
C_rereclaim2(3370*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,460);
lf[0]=C_h_intern(&lf[0],13,"string-append");
lf[2]=C_h_intern(&lf[2],15,"\003syssignal-hook");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[4]=C_h_intern(&lf[4],17,"\003syspeek-c-string");
lf[5]=C_h_intern(&lf[5],16,"\003sysupdate-errno");
lf[6]=C_h_intern(&lf[6],15,"\003sysposix-error");
lf[7]=C_h_intern(&lf[7],21,"\003sysfile-nonblocking!");
lf[8]=C_h_intern(&lf[8],19,"\003sysfile-select-one");
lf[9]=C_h_intern(&lf[9],8,"pipe/buf");
lf[10]=C_h_intern(&lf[10],11,"fcntl/dupfd");
lf[11]=C_h_intern(&lf[11],11,"fcntl/getfd");
lf[12]=C_h_intern(&lf[12],11,"fcntl/setfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfl");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfl");
lf[15]=C_h_intern(&lf[15],11,"open/rdonly");
lf[16]=C_h_intern(&lf[16],11,"open/wronly");
lf[17]=C_h_intern(&lf[17],9,"open/rdwr");
lf[18]=C_h_intern(&lf[18],9,"open/read");
lf[19]=C_h_intern(&lf[19],10,"open/write");
lf[20]=C_h_intern(&lf[20],10,"open/creat");
lf[21]=C_h_intern(&lf[21],11,"open/append");
lf[22]=C_h_intern(&lf[22],9,"open/excl");
lf[23]=C_h_intern(&lf[23],11,"open/noctty");
lf[24]=C_h_intern(&lf[24],13,"open/nonblock");
lf[25]=C_h_intern(&lf[25],10,"open/trunc");
lf[26]=C_h_intern(&lf[26],9,"open/sync");
lf[27]=C_h_intern(&lf[27],10,"open/fsync");
lf[28]=C_h_intern(&lf[28],11,"open/binary");
lf[29]=C_h_intern(&lf[29],9,"open/text");
lf[30]=C_h_intern(&lf[30],10,"perm/irusr");
lf[31]=C_h_intern(&lf[31],10,"perm/iwusr");
lf[32]=C_h_intern(&lf[32],10,"perm/ixusr");
lf[33]=C_h_intern(&lf[33],10,"perm/irgrp");
lf[34]=C_h_intern(&lf[34],10,"perm/iwgrp");
lf[35]=C_h_intern(&lf[35],10,"perm/ixgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iroth");
lf[37]=C_h_intern(&lf[37],10,"perm/iwoth");
lf[38]=C_h_intern(&lf[38],10,"perm/ixoth");
lf[39]=C_h_intern(&lf[39],10,"perm/irwxu");
lf[40]=C_h_intern(&lf[40],10,"perm/irwxg");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxo");
lf[42]=C_h_intern(&lf[42],10,"perm/isvtx");
lf[43]=C_h_intern(&lf[43],10,"perm/isuid");
lf[44]=C_h_intern(&lf[44],10,"perm/isgid");
lf[45]=C_h_intern(&lf[45],12,"file-control");
lf[46]=C_h_intern(&lf[46],11,"\000file-error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[48]=C_h_intern(&lf[48],9,"file-open");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[50]=C_h_intern(&lf[50],17,"\003sysmake-c-string");
lf[51]=C_h_intern(&lf[51],20,"\003sysexpand-home-path");
lf[52]=C_h_intern(&lf[52],10,"file-close");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[54]=C_h_intern(&lf[54],11,"make-string");
lf[55]=C_h_intern(&lf[55],9,"file-read");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[57]=C_h_intern(&lf[57],11,"\000type-error");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[59]=C_h_intern(&lf[59],10,"file-write");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],12,"file-mkstemp");
lf[63]=C_h_intern(&lf[63],13,"\003syssubstring");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[65]=C_h_intern(&lf[65],11,"file-select");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[67]=C_h_intern(&lf[67],8,"seek/set");
lf[68]=C_h_intern(&lf[68],8,"seek/end");
lf[69]=C_h_intern(&lf[69],8,"seek/cur");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[73]=C_h_intern(&lf[73],9,"file-stat");
lf[74]=C_h_intern(&lf[74],9,"file-size");
lf[75]=C_h_intern(&lf[75],22,"file-modification-time");
lf[76]=C_h_intern(&lf[76],16,"file-access-time");
lf[77]=C_h_intern(&lf[77],16,"file-change-time");
lf[78]=C_h_intern(&lf[78],10,"file-owner");
lf[79]=C_h_intern(&lf[79],16,"file-permissions");
lf[80]=C_h_intern(&lf[80],13,"regular-file\077");
lf[81]=C_h_intern(&lf[81],14,"symbolic-link\077");
lf[82]=C_h_intern(&lf[82],13,"stat-regular\077");
lf[83]=C_h_intern(&lf[83],15,"stat-directory\077");
lf[84]=C_h_intern(&lf[84],17,"character-device\077");
lf[85]=C_h_intern(&lf[85],17,"stat-char-device\077");
lf[86]=C_h_intern(&lf[86],13,"block-device\077");
lf[87]=C_h_intern(&lf[87],18,"stat-block-device\077");
lf[88]=C_h_intern(&lf[88],5,"fifo\077");
lf[89]=C_h_intern(&lf[89],10,"stat-fifo\077");
lf[90]=C_h_intern(&lf[90],13,"stat-symlink\077");
lf[91]=C_h_intern(&lf[91],7,"socket\077");
lf[92]=C_h_intern(&lf[92],12,"stat-socket\077");
lf[93]=C_h_intern(&lf[93],18,"set-file-position!");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[95]=C_h_intern(&lf[95],6,"stream");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[97]=C_h_intern(&lf[97],5,"port\077");
lf[98]=C_h_intern(&lf[98],13,"\000bounds-error");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[100]=C_h_intern(&lf[100],13,"file-position");
lf[101]=C_h_intern(&lf[101],18,"decompose-pathname");
lf[102]=C_h_intern(&lf[102],18,"pathname-directory");
lf[103]=C_h_intern(&lf[103],16,"create-directory");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[105]=C_h_intern(&lf[105],13,"make-pathname");
lf[106]=C_h_intern(&lf[106],16,"change-directory");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[108]=C_h_intern(&lf[108],16,"delete-directory");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[110]=C_h_intern(&lf[110],10,"string-ref");
lf[111]=C_h_intern(&lf[111],6,"string");
lf[112]=C_h_intern(&lf[112],9,"directory");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[114]=C_h_intern(&lf[114],16,"\003sysmake-pointer");
lf[115]=C_h_intern(&lf[115],17,"current-directory");
lf[116]=C_h_intern(&lf[116],10,"directory\077");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[118]=C_h_intern(&lf[118],5,"null\077");
lf[119]=C_h_intern(&lf[119],6,"char=\077");
lf[120]=C_h_intern(&lf[120],8,"string=\077");
lf[121]=C_h_intern(&lf[121],16,"char-alphabetic\077");
lf[122]=C_h_intern(&lf[122],18,"string-intersperse");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[124]=C_h_intern(&lf[124],24,"get-environment-variable");
lf[125]=C_h_intern(&lf[125],17,"current-user-name");
lf[126]=C_h_intern(&lf[126],9,"condition");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[128]=C_h_intern(&lf[128],22,"with-exception-handler");
lf[129]=C_h_intern(&lf[129],30,"call-with-current-continuation");
lf[130]=C_h_intern(&lf[130],14,"canonical-path");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[134]=C_h_intern(&lf[134],7,"reverse");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[138]=C_h_intern(&lf[138],12,"string-split");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[146]=C_h_intern(&lf[146],9,"\003syserror");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[149]=C_h_intern(&lf[149],13,"\003sysmake-port");
lf[150]=C_h_intern(&lf[150],21,"\003sysstream-port-class");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[152]=C_h_intern(&lf[152],15,"open-input-pipe");
lf[153]=C_h_intern(&lf[153],5,"\000text");
lf[154]=C_h_intern(&lf[154],7,"\000binary");
lf[155]=C_h_intern(&lf[155],16,"open-output-pipe");
lf[156]=C_h_intern(&lf[156],16,"close-input-pipe");
lf[157]=C_h_intern(&lf[157],23,"close-input/output-pipe");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[159]=C_h_intern(&lf[159],14,"\003syscheck-port");
lf[160]=C_h_intern(&lf[160],17,"close-output-pipe");
lf[161]=C_h_intern(&lf[161],20,"call-with-input-pipe");
lf[162]=C_h_intern(&lf[162],21,"call-with-output-pipe");
lf[163]=C_h_intern(&lf[163],20,"with-input-from-pipe");
lf[164]=C_h_intern(&lf[164],18,"\003sysstandard-input");
lf[165]=C_h_intern(&lf[165],19,"with-output-to-pipe");
lf[166]=C_h_intern(&lf[166],19,"\003sysstandard-output");
lf[167]=C_h_intern(&lf[167],11,"create-pipe");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[169]=C_h_intern(&lf[169],11,"signal/term");
lf[170]=C_h_intern(&lf[170],11,"signal/kill");
lf[171]=C_h_intern(&lf[171],10,"signal/int");
lf[172]=C_h_intern(&lf[172],10,"signal/hup");
lf[173]=C_h_intern(&lf[173],10,"signal/fpe");
lf[174]=C_h_intern(&lf[174],10,"signal/ill");
lf[175]=C_h_intern(&lf[175],11,"signal/segv");
lf[176]=C_h_intern(&lf[176],11,"signal/abrt");
lf[177]=C_h_intern(&lf[177],11,"signal/trap");
lf[178]=C_h_intern(&lf[178],11,"signal/quit");
lf[179]=C_h_intern(&lf[179],11,"signal/alrm");
lf[180]=C_h_intern(&lf[180],13,"signal/vtalrm");
lf[181]=C_h_intern(&lf[181],11,"signal/prof");
lf[182]=C_h_intern(&lf[182],9,"signal/io");
lf[183]=C_h_intern(&lf[183],10,"signal/urg");
lf[184]=C_h_intern(&lf[184],11,"signal/chld");
lf[185]=C_h_intern(&lf[185],11,"signal/cont");
lf[186]=C_h_intern(&lf[186],11,"signal/stop");
lf[187]=C_h_intern(&lf[187],11,"signal/tstp");
lf[188]=C_h_intern(&lf[188],11,"signal/pipe");
lf[189]=C_h_intern(&lf[189],11,"signal/xcpu");
lf[190]=C_h_intern(&lf[190],11,"signal/xfsz");
lf[191]=C_h_intern(&lf[191],11,"signal/usr1");
lf[192]=C_h_intern(&lf[192],11,"signal/usr2");
lf[193]=C_h_intern(&lf[193],12,"signal/winch");
lf[194]=C_h_intern(&lf[194],12,"signals-list");
lf[195]=C_h_intern(&lf[195],18,"\003sysinterrupt-hook");
lf[196]=C_h_intern(&lf[196],14,"signal-handler");
lf[197]=C_h_intern(&lf[197],19,"set-signal-handler!");
lf[198]=C_h_intern(&lf[198],16,"set-signal-mask!");
lf[199]=C_h_intern(&lf[199],14,"\000process-error");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[201]=C_h_intern(&lf[201],11,"signal-mask");
lf[202]=C_h_intern(&lf[202],14,"signal-masked\077");
lf[203]=C_h_intern(&lf[203],12,"signal-mask!");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[205]=C_h_intern(&lf[205],14,"signal-unmask!");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[207]=C_h_intern(&lf[207],18,"system-information");
lf[208]=C_h_intern(&lf[208],25,"\003syspeek-nonnull-c-string");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[210]=C_h_intern(&lf[210],15,"current-user-id");
lf[211]=C_h_intern(&lf[211],25,"current-effective-user-id");
lf[212]=C_h_intern(&lf[212],16,"current-group-id");
lf[213]=C_h_intern(&lf[213],26,"current-effective-group-id");
lf[214]=C_h_intern(&lf[214],16,"user-information");
lf[215]=C_h_intern(&lf[215],6,"vector");
lf[216]=C_h_intern(&lf[216],4,"list");
lf[217]=C_h_intern(&lf[217],27,"current-effective-user-name");
lf[218]=C_h_intern(&lf[218],17,"group-information");
lf[219]=C_h_intern(&lf[219],10,"get-groups");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[223]=C_h_intern(&lf[223],11,"set-groups!");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[226]=C_h_intern(&lf[226],17,"initialize-groups");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[228]=C_h_intern(&lf[228],10,"errno/perm");
lf[229]=C_h_intern(&lf[229],11,"errno/noent");
lf[230]=C_h_intern(&lf[230],10,"errno/srch");
lf[231]=C_h_intern(&lf[231],10,"errno/intr");
lf[232]=C_h_intern(&lf[232],8,"errno/io");
lf[233]=C_h_intern(&lf[233],12,"errno/noexec");
lf[234]=C_h_intern(&lf[234],10,"errno/badf");
lf[235]=C_h_intern(&lf[235],11,"errno/child");
lf[236]=C_h_intern(&lf[236],11,"errno/nomem");
lf[237]=C_h_intern(&lf[237],11,"errno/acces");
lf[238]=C_h_intern(&lf[238],11,"errno/fault");
lf[239]=C_h_intern(&lf[239],10,"errno/busy");
lf[240]=C_h_intern(&lf[240],12,"errno/notdir");
lf[241]=C_h_intern(&lf[241],11,"errno/isdir");
lf[242]=C_h_intern(&lf[242],11,"errno/inval");
lf[243]=C_h_intern(&lf[243],11,"errno/mfile");
lf[244]=C_h_intern(&lf[244],11,"errno/nospc");
lf[245]=C_h_intern(&lf[245],11,"errno/spipe");
lf[246]=C_h_intern(&lf[246],10,"errno/pipe");
lf[247]=C_h_intern(&lf[247],11,"errno/again");
lf[248]=C_h_intern(&lf[248],10,"errno/rofs");
lf[249]=C_h_intern(&lf[249],11,"errno/exist");
lf[250]=C_h_intern(&lf[250],16,"errno/wouldblock");
lf[251]=C_h_intern(&lf[251],10,"errno/2big");
lf[252]=C_h_intern(&lf[252],12,"errno/deadlk");
lf[253]=C_h_intern(&lf[253],9,"errno/dom");
lf[254]=C_h_intern(&lf[254],10,"errno/fbig");
lf[255]=C_h_intern(&lf[255],11,"errno/ilseq");
lf[256]=C_h_intern(&lf[256],11,"errno/mlink");
lf[257]=C_h_intern(&lf[257],17,"errno/nametoolong");
lf[258]=C_h_intern(&lf[258],11,"errno/nfile");
lf[259]=C_h_intern(&lf[259],11,"errno/nodev");
lf[260]=C_h_intern(&lf[260],11,"errno/nolck");
lf[261]=C_h_intern(&lf[261],11,"errno/nosys");
lf[262]=C_h_intern(&lf[262],14,"errno/notempty");
lf[263]=C_h_intern(&lf[263],11,"errno/notty");
lf[264]=C_h_intern(&lf[264],10,"errno/nxio");
lf[265]=C_h_intern(&lf[265],11,"errno/range");
lf[266]=C_h_intern(&lf[266],10,"errno/xdev");
lf[267]=C_h_intern(&lf[267],16,"change-file-mode");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[269]=C_h_intern(&lf[269],17,"change-file-owner");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[271]=C_h_intern(&lf[271],17,"file-read-access\077");
lf[272]=C_h_intern(&lf[272],18,"file-write-access\077");
lf[273]=C_h_intern(&lf[273],20,"file-execute-access\077");
lf[274]=C_h_intern(&lf[274],14,"create-session");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[276]=C_h_intern(&lf[276],16,"process-group-id");
lf[277]=C_h_intern(&lf[277],20,"create-symbolic-link");
lf[278]=C_h_intern(&lf[278],18,"create-symbol-link");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[280]=C_h_intern(&lf[280],9,"substring");
lf[281]=C_h_intern(&lf[281],18,"read-symbolic-link");
lf[282]=C_h_intern(&lf[282],12,"canonicalize");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[284]=C_h_intern(&lf[284],9,"file-link");
lf[285]=C_h_intern(&lf[285],9,"hard-link");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[287]=C_h_intern(&lf[287],12,"fileno/stdin");
lf[288]=C_h_intern(&lf[288],13,"fileno/stdout");
lf[289]=C_h_intern(&lf[289],13,"fileno/stderr");
lf[290]=C_h_intern(&lf[290],7,"\000append");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[298]=C_h_intern(&lf[298],16,"open-input-file*");
lf[299]=C_h_intern(&lf[299],17,"open-output-file*");
lf[300]=C_h_intern(&lf[300],12,"port->fileno");
lf[301]=C_h_intern(&lf[301],6,"socket");
lf[302]=C_h_intern(&lf[302],20,"\003systcp-port->fileno");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[305]=C_h_intern(&lf[305],25,"\003syspeek-unsigned-integer");
lf[306]=C_h_intern(&lf[306],16,"duplicate-fileno");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[308]=C_h_intern(&lf[308],15,"make-input-port");
lf[309]=C_h_intern(&lf[309],14,"set-port-name!");
lf[310]=C_h_intern(&lf[310],21,"\003syscustom-input-port");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[312]=C_h_intern(&lf[312],17,"\003systhread-yield!");
lf[313]=C_h_intern(&lf[313],25,"\003systhread-block-for-i/o!");
lf[314]=C_h_intern(&lf[314],18,"\003syscurrent-thread");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[319]=C_h_intern(&lf[319],17,"\003sysstring-append");
lf[320]=C_h_intern(&lf[320],15,"\003sysmake-string");
lf[321]=C_h_intern(&lf[321],20,"\003sysscan-buffer-line");
lf[322]=C_h_intern(&lf[322],4,"noop");
lf[323]=C_h_intern(&lf[323],16,"make-output-port");
lf[324]=C_h_intern(&lf[324],22,"\003syscustom-output-port");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[327]=C_h_intern(&lf[327],13,"file-truncate");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[330]=C_h_intern(&lf[330],4,"lock");
lf[331]=C_h_intern(&lf[331],9,"file-lock");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[333]=C_h_intern(&lf[333],18,"file-lock/blocking");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[335]=C_h_intern(&lf[335],14,"file-test-lock");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[337]=C_h_intern(&lf[337],11,"file-unlock");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[339]=C_h_intern(&lf[339],11,"create-fifo");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[342]=C_h_intern(&lf[342],13,"\003sysfile-info");
lf[343]=C_h_intern(&lf[343],6,"setenv");
lf[344]=C_h_intern(&lf[344],8,"unsetenv");
lf[345]=C_h_intern(&lf[345],25,"get-environment-variables");
lf[346]=C_h_intern(&lf[346],19,"current-environment");
lf[347]=C_h_intern(&lf[347],9,"prot/read");
lf[348]=C_h_intern(&lf[348],10,"prot/write");
lf[349]=C_h_intern(&lf[349],9,"prot/exec");
lf[350]=C_h_intern(&lf[350],9,"prot/none");
lf[351]=C_h_intern(&lf[351],9,"map/fixed");
lf[352]=C_h_intern(&lf[352],10,"map/shared");
lf[353]=C_h_intern(&lf[353],11,"map/private");
lf[354]=C_h_intern(&lf[354],13,"map/anonymous");
lf[355]=C_h_intern(&lf[355],8,"map/file");
lf[356]=C_h_intern(&lf[356],18,"map-file-to-memory");
lf[357]=C_h_intern(&lf[357],4,"mmap");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[359]=C_h_intern(&lf[359],20,"\003syspointer->address");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[361]=C_h_intern(&lf[361],16,"\003sysnull-pointer");
lf[362]=C_h_intern(&lf[362],22,"unmap-file-from-memory");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[364]=C_h_intern(&lf[364],26,"memory-mapped-file-pointer");
lf[365]=C_h_intern(&lf[365],19,"memory-mapped-file\077");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[368]=C_h_intern(&lf[368],19,"seconds->local-time");
lf[369]=C_h_intern(&lf[369],18,"\003sysdecode-seconds");
lf[370]=C_h_intern(&lf[370],15,"current-seconds");
lf[371]=C_h_intern(&lf[371],17,"seconds->utc-time");
lf[372]=C_h_intern(&lf[372],15,"seconds->string");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[374]=C_h_intern(&lf[374],12,"time->string");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[377]=C_h_intern(&lf[377],12,"string->time");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[379]=C_h_intern(&lf[379],19,"local-time->seconds");
lf[380]=C_h_intern(&lf[380],15,"\003syscons-flonum");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[382]=C_h_intern(&lf[382],17,"utc-time->seconds");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[384]=C_h_intern(&lf[384],27,"local-timezone-abbreviation");
lf[385]=C_h_intern(&lf[385],5,"_exit");
lf[386]=C_h_intern(&lf[386],10,"set-alarm!");
lf[387]=C_h_intern(&lf[387],19,"set-buffering-mode!");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[389]=C_h_intern(&lf[389],5,"\000full");
lf[390]=C_h_intern(&lf[390],5,"\000line");
lf[391]=C_h_intern(&lf[391],5,"\000none");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[393]=C_h_intern(&lf[393],14,"terminal-port\077");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[396]=C_h_intern(&lf[396],13,"terminal-name");
lf[397]=C_h_intern(&lf[397],13,"terminal-size");
lf[398]=C_h_intern(&lf[398],6,"\000error");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[400]=C_h_intern(&lf[400],17,"\003sysmake-locative");
lf[401]=C_h_intern(&lf[401],8,"location");
lf[402]=C_h_intern(&lf[402],13,"get-host-name");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[404]=C_h_intern(&lf[404],6,"regexp");
lf[405]=C_h_intern(&lf[405],12,"string-match");
lf[406]=C_h_intern(&lf[406],12,"glob->regexp");
lf[407]=C_h_intern(&lf[407],4,"glob");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[410]=C_h_intern(&lf[410],12,"process-fork");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[412]=C_h_intern(&lf[412],24,"pathname-strip-directory");
lf[413]=C_h_intern(&lf[413],15,"process-execute");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[415]=C_h_intern(&lf[415],16,"\003sysprocess-wait");
lf[416]=C_h_intern(&lf[416],12,"process-wait");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[418]=C_h_intern(&lf[418],18,"current-process-id");
lf[419]=C_h_intern(&lf[419],17,"parent-process-id");
lf[420]=C_h_intern(&lf[420],5,"sleep");
lf[421]=C_h_intern(&lf[421],14,"process-signal");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[423]=C_h_intern(&lf[423],17,"\003sysshell-command");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[426]=C_h_intern(&lf[426],27,"\003sysshell-command-arguments");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[428]=C_h_intern(&lf[428],11,"process-run");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[430]=C_h_intern(&lf[430],11,"\003sysprocess");
lf[431]=C_h_intern(&lf[431],7,"process");
lf[432]=C_h_intern(&lf[432],8,"process*");
lf[433]=C_h_intern(&lf[433],13,"pathname-file");
lf[434]=C_h_intern(&lf[434],10,"find-files");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[438]=C_h_intern(&lf[438],16,"\003sysdynamic-wind");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[440]=C_h_intern(&lf[440],7,"regexp\077");
lf[441]=C_h_intern(&lf[441],19,"set-root-directory!");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[444]=C_h_intern(&lf[444],21,"set-process-group-id!");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[446]=C_h_intern(&lf[446],18,"getter-with-setter");
lf[447]=C_h_intern(&lf[447],26,"effective-group-id!-setter");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[449]=C_h_intern(&lf[449],12,"set-user-id!");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[451]=C_h_intern(&lf[451],25,"effective-user-id!-setter");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[454]=C_h_intern(&lf[454],23,"\003sysuser-interrupt-hook");
lf[455]=C_h_intern(&lf[455],11,"make-vector");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[458]=C_h_intern(&lf[458],17,"register-feature!");
lf[459]=C_h_intern(&lf[459],5,"posix");
C_register_lf2(lf,460,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2460,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2458 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2463,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2461 in k2458 */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2464 in k2461 in k2458 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2469,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2472,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2475,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2478,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 503  register-feature! */
t3=*((C_word*)lf[458]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[459]);}

/* k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word ab[70],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2478,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=C_mutate(&lf[1] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2485,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! posix-error ...) */,lf[1]);
t5=C_mutate((C_word*)lf[7]+1 /* (set! file-nonblocking! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2503,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[8]+1 /* (set! file-select-one ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2506,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[9]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[10]+1 /* (set! fcntl/dupfd ...) */,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[11]+1 /* (set! fcntl/getfd ...) */,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[12]+1 /* (set! fcntl/setfd ...) */,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[13]+1 /* (set! fcntl/getfl ...) */,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[14]+1 /* (set! fcntl/setfl ...) */,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[15]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[16]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[17]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[18]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[19]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[20]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[21]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[22]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[23]+1 /* (set! open/noctty ...) */,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[24]+1 /* (set! open/nonblock ...) */,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[25]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[26]+1 /* (set! open/sync ...) */,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[27]+1 /* (set! open/fsync ...) */,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[28]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[29]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[30]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[31]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[32]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[33]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[34]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[35]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[36]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[37]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[38]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[39]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[40]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[41]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[42]+1 /* (set! perm/isvtx ...) */,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[43]+1 /* (set! perm/isuid ...) */,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[44]+1 /* (set! perm/isgid ...) */,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[45]+1 /* (set! file-control ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2547,tmp=(C_word)a,a+=2,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[48]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2586,a[2]=t45,tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[52]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2624,tmp=(C_word)a,a+=2,tmp));
t48=*((C_word*)lf[54]+1);
t49=C_mutate((C_word*)lf[55]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=t48,tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[59]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2681,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[62]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2720,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[65]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2758,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[67]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t54=C_mutate((C_word*)lf[68]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t55=C_mutate((C_word*)lf[69]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t56=C_mutate(&lf[70] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3014,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[73]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3051,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[74]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3076,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[75]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3082,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[76]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3088,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[77]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3094,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[78]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3100,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[79]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3106,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[80]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3112,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[81]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3121,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[82]+1 /* (set! stat-regular? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3130,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[83]+1 /* (set! stat-directory? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3139,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[84]+1 /* (set! character-device? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3148,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[85]+1 /* (set! stat-char-device? ...) */,*((C_word*)lf[84]+1));
t70=C_mutate((C_word*)lf[86]+1 /* (set! block-device? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3158,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[87]+1 /* (set! stat-block-device? ...) */,*((C_word*)lf[86]+1));
t72=C_mutate((C_word*)lf[88]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3168,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[89]+1 /* (set! stat-fifo? ...) */,*((C_word*)lf[88]+1));
t74=C_mutate((C_word*)lf[90]+1 /* (set! stat-symlink? ...) */,*((C_word*)lf[81]+1));
t75=C_mutate((C_word*)lf[91]+1 /* (set! socket? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3179,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[92]+1 /* (set! stat-socket? ...) */,*((C_word*)lf[91]+1));
t77=C_mutate((C_word*)lf[93]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3189,tmp=(C_word)a,a+=2,tmp));
t78=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3249,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t79=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8308,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 850  getter-with-setter */
t80=*((C_word*)lf[446]+1);
((C_proc4)(void*)(*((C_word*)t80+1)))(4,t80,t78,t79,*((C_word*)lf[93]+1));}

/* a8307 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8308(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8308,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8312,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8324,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 852  port? */
t5=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k8322 in a8307 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[95]);
t4=((C_word*)t0)[2];
f_8312(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_8312(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 859  ##sys#signal-hook */
t2=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[57],lf[100],lf[457],((C_word*)t0)[3]);}}}

/* k8310 in a8307 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8315,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_lessp(t1,C_fix(0)))){
/* posixunix.scm: 861  posix-error */
t3=lf[1];
f_2485(6,t3,t2,lf[46],lf[100],lf[456],((C_word*)t0)[2]);}
else{
t3=t2;
f_8315(2,t3,C_SCHEME_UNDEFINED);}}

/* k8313 in k8310 in a8307 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[145],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=C_mutate((C_word*)lf[100]+1 /* (set! file-position ...) */,t1);
t3=*((C_word*)lf[101]+1);
t4=*((C_word*)lf[102]+1);
t5=C_mutate((C_word*)lf[103]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3251,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=C_mutate((C_word*)lf[106]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3383,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[108]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3407,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[110]+1);
t9=*((C_word*)lf[54]+1);
t10=*((C_word*)lf[111]+1);
t11=C_mutate((C_word*)lf[112]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3431,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t12=C_mutate((C_word*)lf[116]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3585,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[54]+1);
t14=C_mutate((C_word*)lf[115]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3605,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[118]+1);
t16=*((C_word*)lf[119]+1);
t17=*((C_word*)lf[120]+1);
t18=*((C_word*)lf[121]+1);
t19=*((C_word*)lf[110]+1);
t20=*((C_word*)lf[0]+1);
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3646,tmp=(C_word)a,a+=2,tmp);
t22=*((C_word*)lf[124]+1);
t23=*((C_word*)lf[125]+1);
t24=*((C_word*)lf[115]+1);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3662,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=C_mutate((C_word*)lf[130]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3718,a[2]=t18,a[3]=t16,a[4]=t22,a[5]=t23,a[6]=t25,a[7]=t17,a[8]=t15,a[9]=t19,a[10]=t21,a[11]=t20,tmp=(C_word)a,a+=12,tmp));
t27=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4047,tmp=(C_word)a,a+=2,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4053,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[152]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4068,a[2]=t27,a[3]=t28,tmp=(C_word)a,a+=4,tmp));
t30=C_mutate((C_word*)lf[155]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4104,a[2]=t27,a[3]=t28,tmp=(C_word)a,a+=4,tmp));
t31=C_mutate((C_word*)lf[156]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4140,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[160]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[156]+1));
t33=*((C_word*)lf[152]+1);
t34=*((C_word*)lf[155]+1);
t35=*((C_word*)lf[156]+1);
t36=*((C_word*)lf[160]+1);
t37=C_mutate((C_word*)lf[161]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4156,a[2]=t33,a[3]=t35,tmp=(C_word)a,a+=4,tmp));
t38=C_mutate((C_word*)lf[162]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4180,a[2]=t34,a[3]=t36,tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[163]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4204,a[2]=t33,a[3]=t35,tmp=(C_word)a,a+=4,tmp));
t40=C_mutate((C_word*)lf[165]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4224,a[2]=t34,a[3]=t36,tmp=(C_word)a,a+=4,tmp));
t41=C_mutate((C_word*)lf[167]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4244,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[169]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t43=C_mutate((C_word*)lf[170]+1 /* (set! signal/kill ...) */,C_fix((C_word)SIGKILL));
t44=C_mutate((C_word*)lf[171]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[172]+1 /* (set! signal/hup ...) */,C_fix((C_word)SIGHUP));
t46=C_mutate((C_word*)lf[173]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t47=C_mutate((C_word*)lf[174]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t48=C_mutate((C_word*)lf[175]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t49=C_mutate((C_word*)lf[176]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t50=C_mutate((C_word*)lf[177]+1 /* (set! signal/trap ...) */,C_fix((C_word)SIGTRAP));
t51=C_mutate((C_word*)lf[178]+1 /* (set! signal/quit ...) */,C_fix((C_word)SIGQUIT));
t52=C_mutate((C_word*)lf[179]+1 /* (set! signal/alrm ...) */,C_fix((C_word)SIGALRM));
t53=C_mutate((C_word*)lf[180]+1 /* (set! signal/vtalrm ...) */,C_fix((C_word)SIGVTALRM));
t54=C_mutate((C_word*)lf[181]+1 /* (set! signal/prof ...) */,C_fix((C_word)SIGPROF));
t55=C_mutate((C_word*)lf[182]+1 /* (set! signal/io ...) */,C_fix((C_word)SIGIO));
t56=C_mutate((C_word*)lf[183]+1 /* (set! signal/urg ...) */,C_fix((C_word)SIGURG));
t57=C_mutate((C_word*)lf[184]+1 /* (set! signal/chld ...) */,C_fix((C_word)SIGCHLD));
t58=C_mutate((C_word*)lf[185]+1 /* (set! signal/cont ...) */,C_fix((C_word)SIGCONT));
t59=C_mutate((C_word*)lf[186]+1 /* (set! signal/stop ...) */,C_fix((C_word)SIGSTOP));
t60=C_mutate((C_word*)lf[187]+1 /* (set! signal/tstp ...) */,C_fix((C_word)SIGTSTP));
t61=C_mutate((C_word*)lf[188]+1 /* (set! signal/pipe ...) */,C_fix((C_word)SIGPIPE));
t62=C_mutate((C_word*)lf[189]+1 /* (set! signal/xcpu ...) */,C_fix((C_word)SIGXCPU));
t63=C_mutate((C_word*)lf[190]+1 /* (set! signal/xfsz ...) */,C_fix((C_word)SIGXFSZ));
t64=C_mutate((C_word*)lf[191]+1 /* (set! signal/usr1 ...) */,C_fix((C_word)SIGUSR1));
t65=C_mutate((C_word*)lf[192]+1 /* (set! signal/usr2 ...) */,C_fix((C_word)SIGUSR2));
t66=C_mutate((C_word*)lf[193]+1 /* (set! signal/winch ...) */,C_fix((C_word)SIGWINCH));
t67=(C_word)C_a_i_list(&a,25,*((C_word*)lf[169]+1),*((C_word*)lf[170]+1),*((C_word*)lf[171]+1),*((C_word*)lf[172]+1),*((C_word*)lf[173]+1),*((C_word*)lf[174]+1),*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1),*((C_word*)lf[188]+1),*((C_word*)lf[189]+1),*((C_word*)lf[190]+1),*((C_word*)lf[191]+1),*((C_word*)lf[192]+1),*((C_word*)lf[193]+1));
t68=C_mutate((C_word*)lf[194]+1 /* (set! signals-list ...) */,t67);
t69=*((C_word*)lf[195]+1);
t70=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[2],a[3]=t69,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1170 make-vector */
t71=*((C_word*)lf[455]+1);
((C_proc4)(void*)(*((C_word*)t71+1)))(4,t71,t70,C_fix(256),C_SCHEME_FALSE);}

/* k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4289,2,t0,t1);}
t2=C_mutate((C_word*)lf[196]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4291,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[197]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4300,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[195]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[198]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4331,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[201]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4371,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[202]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4403,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[203]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4409,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[205]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4424,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8302,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1226 set-signal-handler! */
t12=*((C_word*)lf[197]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,*((C_word*)lf[171]+1),t11);}

/* a8301 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8302,3,t0,t1,t2);}
/* posixunix.scm: 1228 ##sys#user-interrupt-hook */
t3=*((C_word*)lf[454]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4440,2,t0,t1);}
t2=C_mutate((C_word*)lf[207]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4442,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4482,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8284,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8287,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1252 getter-with-setter */
t6=*((C_word*)lf[446]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a8286 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8287,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8297,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1256 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8295 in a8286 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1257 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[449],lf[453],((C_word*)t0)[2]);}

/* a8283 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8284,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub755(C_SCHEME_UNDEFINED));}

/* k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4482,2,t0,t1);}
t2=C_mutate((C_word*)lf[210]+1 /* (set! current-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4486,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8266,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8269,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1260 getter-with-setter */
t6=*((C_word*)lf[446]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a8268 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8269,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8279,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1264 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8277 in a8268 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1265 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[451],lf[452],((C_word*)t0)[2]);}

/* a8265 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8266,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub761(C_SCHEME_UNDEFINED));}

/* k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4486,2,t0,t1);}
t2=C_mutate((C_word*)lf[211]+1 /* (set! current-effective-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8248,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8251,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1269 getter-with-setter */
t6=*((C_word*)lf[446]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a8250 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8251(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8251,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8261,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1273 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8259 in a8250 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1274 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[449],lf[450],((C_word*)t0)[2]);}

/* a8247 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8248,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub767(C_SCHEME_UNDEFINED));}

/* k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4490,2,t0,t1);}
t2=C_mutate((C_word*)lf[212]+1 /* (set! current-group-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4494,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8230,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8233,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1277 getter-with-setter */
t6=*((C_word*)lf[446]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a8232 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8233(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8233,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8243,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1281 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8241 in a8232 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1282 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[447],lf[448],((C_word*)t0)[2]);}

/* a8229 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8230,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub773(C_SCHEME_UNDEFINED));}

/* k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4494,2,t0,t1);}
t2=C_mutate((C_word*)lf[213]+1 /* (set! current-effective-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[214]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4496,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[125]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4556,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[217]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4570,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[218]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4590,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[219]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4668,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[223]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4731,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[226]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4797,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[228]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t11=C_mutate((C_word*)lf[229]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t12=C_mutate((C_word*)lf[230]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t13=C_mutate((C_word*)lf[231]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t14=C_mutate((C_word*)lf[232]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t15=C_mutate((C_word*)lf[233]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t16=C_mutate((C_word*)lf[234]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t17=C_mutate((C_word*)lf[235]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t18=C_mutate((C_word*)lf[236]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t19=C_mutate((C_word*)lf[237]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t20=C_mutate((C_word*)lf[238]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t21=C_mutate((C_word*)lf[239]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t22=C_mutate((C_word*)lf[240]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t23=C_mutate((C_word*)lf[241]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t24=C_mutate((C_word*)lf[242]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t25=C_mutate((C_word*)lf[243]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t26=C_mutate((C_word*)lf[244]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t27=C_mutate((C_word*)lf[245]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t28=C_mutate((C_word*)lf[246]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t29=C_mutate((C_word*)lf[247]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t30=C_mutate((C_word*)lf[248]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t31=C_mutate((C_word*)lf[249]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t32=C_mutate((C_word*)lf[250]+1 /* (set! errno/wouldblock ...) */,C_fix((C_word)EWOULDBLOCK));
t33=C_set_block_item(lf[251] /* errno/2big */,0,C_fix(0));
t34=C_set_block_item(lf[252] /* errno/deadlk */,0,C_fix(0));
t35=C_set_block_item(lf[253] /* errno/dom */,0,C_fix(0));
t36=C_set_block_item(lf[254] /* errno/fbig */,0,C_fix(0));
t37=C_set_block_item(lf[255] /* errno/ilseq */,0,C_fix(0));
t38=C_set_block_item(lf[256] /* errno/mlink */,0,C_fix(0));
t39=C_set_block_item(lf[257] /* errno/nametoolong */,0,C_fix(0));
t40=C_set_block_item(lf[258] /* errno/nfile */,0,C_fix(0));
t41=C_set_block_item(lf[259] /* errno/nodev */,0,C_fix(0));
t42=C_set_block_item(lf[260] /* errno/nolck */,0,C_fix(0));
t43=C_set_block_item(lf[261] /* errno/nosys */,0,C_fix(0));
t44=C_set_block_item(lf[262] /* errno/notempty */,0,C_fix(0));
t45=C_set_block_item(lf[263] /* errno/notty */,0,C_fix(0));
t46=C_set_block_item(lf[264] /* errno/nxio */,0,C_fix(0));
t47=C_set_block_item(lf[265] /* errno/range */,0,C_fix(0));
t48=C_set_block_item(lf[266] /* errno/xdev */,0,C_fix(0));
t49=C_mutate((C_word*)lf[267]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4861,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[269]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4888,tmp=(C_word)a,a+=2,tmp));
t51=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4918,tmp=(C_word)a,a+=2,tmp);
t52=C_mutate((C_word*)lf[271]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4942,a[2]=t51,tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[272]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4948,a[2]=t51,tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[273]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4954,a[2]=t51,tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[274]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4960,tmp=(C_word)a,a+=2,tmp));
t56=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t57=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8191,tmp=(C_word)a,a+=2,tmp);
t58=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8209,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1497 getter-with-setter */
t59=*((C_word*)lf[446]+1);
((C_proc4)(void*)(*((C_word*)t59+1)))(4,t59,t56,t57,t58);}

/* a8208 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8209,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[444]);
t5=(C_word)C_i_check_exact_2(t3,lf[444]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8225,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1509 ##sys#update-errno */
t7=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k8223 in a8208 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1510 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[444],lf[445],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8190 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8191,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[276]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8198,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8204,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1502 ##sys#update-errno */
t7=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_8198(2,t6,C_SCHEME_UNDEFINED);}}

/* k8202 in a8190 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1503 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[276],lf[443],((C_word*)t0)[2]);}

/* k8196 in a8190 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4977,2,t0,t1);}
t2=C_mutate((C_word*)lf[276]+1 /* (set! process-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[277]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4979,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[280]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5016,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_u_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1530 make-string */
t7=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word ab[182],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5016,2,t0,t1);}
t2=C_mutate((C_word*)lf[281]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5017,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[284]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5086,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[287]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[288]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[289]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5111,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5148,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[298]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5163,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[299]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5177,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t11=C_mutate((C_word*)lf[300]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5191,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[306]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5236,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[308]+1);
t14=*((C_word*)lf[309]+1);
t15=C_mutate((C_word*)lf[310]+1 /* (set! custom-input-port ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5263,a[2]=t13,a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=*((C_word*)lf[323]+1);
t17=*((C_word*)lf[309]+1);
t18=C_mutate((C_word*)lf[324]+1 /* (set! custom-output-port ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5742,a[2]=t16,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=C_mutate((C_word*)lf[327]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5998,tmp=(C_word)a,a+=2,tmp));
t20=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6037,tmp=(C_word)a,a+=2,tmp);
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6108,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate((C_word*)lf[331]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6126,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[333]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6141,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[335]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6156,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t25=C_mutate((C_word*)lf[337]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6178,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[339]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6206,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[88]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6249,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[343]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6275,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[344]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6292,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[345]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6307,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[346]+1 /* (set! current-environment ...) */,*((C_word*)lf[345]+1));
t32=C_mutate((C_word*)lf[347]+1 /* (set! prot/read ...) */,C_fix((C_word)PROT_READ));
t33=C_mutate((C_word*)lf[348]+1 /* (set! prot/write ...) */,C_fix((C_word)PROT_WRITE));
t34=C_mutate((C_word*)lf[349]+1 /* (set! prot/exec ...) */,C_fix((C_word)PROT_EXEC));
t35=C_mutate((C_word*)lf[350]+1 /* (set! prot/none ...) */,C_fix((C_word)PROT_NONE));
t36=C_mutate((C_word*)lf[351]+1 /* (set! map/fixed ...) */,C_fix((C_word)MAP_FIXED));
t37=C_mutate((C_word*)lf[352]+1 /* (set! map/shared ...) */,C_fix((C_word)MAP_SHARED));
t38=C_mutate((C_word*)lf[353]+1 /* (set! map/private ...) */,C_fix((C_word)MAP_PRIVATE));
t39=C_mutate((C_word*)lf[354]+1 /* (set! map/anonymous ...) */,C_fix((C_word)MAP_ANON));
t40=C_mutate((C_word*)lf[355]+1 /* (set! map/file ...) */,C_fix((C_word)MAP_FILE));
t41=C_mutate((C_word*)lf[356]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6391,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[362]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6449,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[364]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6484,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[365]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6493,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate(&lf[366] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6499,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[368]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6518,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[371]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6545,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[372]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6577,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[374]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6631,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[377]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6693,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[379]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6732,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[382]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6747,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[384]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6762,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[385]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6770,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[386]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6786,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[387]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6789,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[393]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6848,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate(&lf[394] /* (set! terminal-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6867,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[396]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6894,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[397]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6913,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[402]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6948,tmp=(C_word)a,a+=2,tmp));
t62=*((C_word*)lf[404]+1);
t63=*((C_word*)lf[405]+1);
t64=*((C_word*)lf[406]+1);
t65=*((C_word*)lf[112]+1);
t66=*((C_word*)lf[105]+1);
t67=*((C_word*)lf[101]+1);
t68=C_mutate((C_word*)lf[407]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6960,a[2]=t64,a[3]=t62,a[4]=t65,a[5]=t63,a[6]=t66,a[7]=t67,tmp=(C_word)a,a+=8,tmp));
t69=C_mutate((C_word*)lf[410]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7069,tmp=(C_word)a,a+=2,tmp));
t70=*((C_word*)lf[412]+1);
t71=C_mutate((C_word*)lf[413]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7118,a[2]=t70,tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[415]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7297,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[416]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7314,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[418]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7389,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[419]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7392,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[420]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7395,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[421]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7398,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[423]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7425,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[426]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7434,tmp=(C_word)a,a+=2,tmp));
t80=*((C_word*)lf[410]+1);
t81=*((C_word*)lf[413]+1);
t82=C_mutate((C_word*)lf[428]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7440,a[2]=t80,a[3]=t81,tmp=(C_word)a,a+=4,tmp));
t83=*((C_word*)lf[167]+1);
t84=*((C_word*)lf[416]+1);
t85=*((C_word*)lf[410]+1);
t86=*((C_word*)lf[413]+1);
t87=*((C_word*)lf[306]+1);
t88=*((C_word*)lf[52]+1);
t89=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7496,a[2]=t84,tmp=(C_word)a,a+=3,tmp);
t90=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7533,a[2]=t83,tmp=(C_word)a,a+=3,tmp);
t91=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7553,a[2]=t88,tmp=(C_word)a,a+=3,tmp);
t92=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7567,a[2]=t88,tmp=(C_word)a,a+=3,tmp);
t93=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7600,a[2]=t90,a[3]=t85,a[4]=t92,a[5]=t86,tmp=(C_word)a,a+=6,tmp);
t94=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7645,a[2]=t91,tmp=(C_word)a,a+=3,tmp);
t95=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7656,a[2]=t91,tmp=(C_word)a,a+=3,tmp);
t96=C_mutate((C_word*)lf[430]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7667,a[2]=t95,a[3]=t89,a[4]=t94,a[5]=t93,tmp=(C_word)a,a+=6,tmp));
t97=C_set_block_item(lf[431] /* process */,0,C_SCHEME_UNDEFINED);
t98=C_set_block_item(lf[432] /* process* */,0,C_SCHEME_UNDEFINED);
t99=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7725,tmp=(C_word)a,a+=2,tmp);
t100=C_mutate((C_word*)lf[431]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7802,a[2]=t99,tmp=(C_word)a,a+=3,tmp));
t101=C_mutate((C_word*)lf[432]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7859,a[2]=t99,tmp=(C_word)a,a+=3,tmp));
t102=*((C_word*)lf[407]+1);
t103=*((C_word*)lf[405]+1);
t104=*((C_word*)lf[105]+1);
t105=*((C_word*)lf[433]+1);
t106=*((C_word*)lf[116]+1);
t107=C_mutate((C_word*)lf[434]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7916,a[2]=t106,a[3]=t105,a[4]=t104,a[5]=t102,a[6]=t103,tmp=(C_word)a,a+=7,tmp));
t108=C_mutate((C_word*)lf[441]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8168,tmp=(C_word)a,a+=2,tmp));
t109=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t109+1)))(2,t109,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8168,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[441]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8164,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* ##sys#make-c-string */
t6=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t6=t5;
f_8164(2,t6,C_SCHEME_FALSE);}}

/* k8162 in set-root-directory! in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub2194(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2395 posix-error */
t3=lf[1];
f_2485(6,t3,((C_word*)t0)[3],lf[46],lf[441],lf[442],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_7916r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7916r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7916r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8083,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8088,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8093,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action21182183 */
t9=t8;
f_8093(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id21192181 */
t11=t7;
f_8088(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit21202178 */
t13=t6;
f_8083(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body21162125 */
t15=t5;
f_7918(t15,t1,t9,t11,t13);}}}}

/* def-action2118 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_8093(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8093,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8099,tmp=(C_word)a,a+=2,tmp);
/* def-id21192181 */
t3=((C_word*)t0)[2];
f_8088(t3,t1,t2);}

/* a8098 in def-action2118 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8099,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id2119 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_8088(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8088,NULL,3,t0,t1,t2);}
/* def-limit21202178 */
t3=((C_word*)t0)[2];
f_8083(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit2120 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_8083(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8083,NULL,4,t0,t1,t2,t3);}
/* body21162125 */
t4=((C_word*)t0)[2];
f_7918(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7918(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7918,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[8],lf[434]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7925,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=t7,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_7925(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8078,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp):t4));}
else{
t10=t8;
f_7925(t10,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8070,tmp=(C_word)a,a+=2,tmp));}}

/* f_8070 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8070(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8070,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_8078 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8078(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8078,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7925(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7925,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t2)){
t4=t3;
f_8058(2,t4,t2);}
else{
/* posixunix.scm: 2367 regexp? */
t4=*((C_word*)lf[440]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[12]);}}

/* k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8058,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8059,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t2,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8052,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2370 make-pathname */
t5=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[439]);}

/* k8050 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2370 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7935,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7937,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7937(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7937(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7937,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t4,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=t5,a[12]=t1,a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2376 directory? */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7956,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8032,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2377 pathname-file */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8038,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2384 pproc */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}}

/* k8036 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8038,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8045,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2384 action */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2385 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7937(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k8043 in k8036 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2384 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7937(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8030 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8032,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[435]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[436]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2377 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_7937(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2378 lproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k7969 in k8030 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7971,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7981,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7983,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8012,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[438]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8022,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8025,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2383 pproc */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}}

/* k8023 in k7969 in k8030 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2383 action */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8022(2,t2,((C_word*)t0)[2]);}}

/* k8020 in k7969 in k8030 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2383 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7937(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8011 in k7969 in k8030 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8012,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a7987 in k7969 in k8030 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7996,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8010,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2381 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],lf[437]);}

/* k8008 in a7987 in k7969 in k8030 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2381 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7994 in a7987 in k7969 in k8030 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8000,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8003,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2382 pproc */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k8001 in k7994 in a7987 in k7969 in k8030 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2382 action */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8000(2,t2,((C_word*)t0)[2]);}}

/* k7998 in k7994 in a7987 in k7969 in k8030 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2381 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7937(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7982 in k7969 in k8030 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7983,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k7979 in k7969 in k8030 in k7954 in loop in k7933 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2379 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7937(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8059 in k8056 in k7923 in body2116 in find-files in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_8059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8059,3,t0,t1,t2);}
/* posixunix.scm: 2368 string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7859(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_7859r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7859r(t0,t1,t2,t3);}}

static void C_ccall f_7859r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7861,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7866,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7871,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args20852096 */
t7=t6;
f_7871(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env20862094 */
t9=t5;
f_7866(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body20832091 */
t11=t4;
f_7861(t11,t1,t7,t9);}}}

/* def-args2085 in process* in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7871(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7871,NULL,2,t0,t1);}
/* def-env20862094 */
t2=((C_word*)t0)[2];
f_7866(t2,t1,C_SCHEME_FALSE);}

/* def-env2086 in process* in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7866(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7866,NULL,3,t0,t1,t2);}
/* body20832091 */
t3=((C_word*)t0)[2];
f_7861(t3,t1,t2,C_SCHEME_FALSE);}

/* body2083 in process* in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7861(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7861,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2344 %process */
f_7725(t1,lf[432],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_7802r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7802r(t0,t1,t2,t3);}}

static void C_ccall f_7802r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7804,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7809,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7814,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args20542065 */
t7=t6;
f_7814(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env20552063 */
t9=t5;
f_7809(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body20522060 */
t11=t4;
f_7804(t11,t1,t7,t9);}}}

/* def-args2054 in process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7814,NULL,2,t0,t1);}
/* def-env20552063 */
t2=((C_word*)t0)[2];
f_7809(t2,t1,C_SCHEME_FALSE);}

/* def-env2055 in process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7809(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7809,NULL,3,t0,t1,t2);}
/* body20522060 */
t3=((C_word*)t0)[2];
f_7804(t3,t1,t2,C_SCHEME_FALSE);}

/* body2052 in process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7804(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7804,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2341 %process */
f_7725(t1,lf[431],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7725(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7725,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7736,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7727,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7762,a[2]=t1,a[3]=t3,a[4]=t8,a[5]=t7,a[6]=t2,a[7]=t10,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2330 chkstrlst */
t13=t12;
f_7762(t13,f_7727(t10,((C_word*)t8)[1]));}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7796,a[2]=t12,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2332 ##sys#shell-command-arguments */
t14=*((C_word*)lf[426]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,((C_word*)t7)[1]);}}

/* k7794 in %process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7796,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2333 ##sys#shell-command */
t4=*((C_word*)lf[423]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7798 in k7794 in %process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7762(t3,t2);}

/* k7760 in %process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7762(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7762,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[8])?f_7727(((C_word*)t0)[7],((C_word*)t0)[8]):C_SCHEME_UNDEFINED);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7776,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a7775 in k7760 in %process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7776,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2337 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2338 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a7769 in k7760 in %process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7770,2,t0,t1);}
/* posixunix.scm: 2335 ##sys#process */
t2=*((C_word*)lf[430]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall f_7727(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_check_list_2(t1,((C_word*)t0)[3]);
return(f_7736(((C_word*)t0)[2],t1));}

/* loop2012 in %process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall f_7736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]);
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* ##sys#process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7667,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7673,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a7678 in ##sys#process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7679,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7690,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7710,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2311 make-on-close */
t12=((C_word*)t0)[3];
f_7496(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k7708 in a7678 in ##sys#process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2310 input-port */
t2=((C_word*)t0)[7];
f_7645(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7688 in a7678 in ##sys#process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7694,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2313 make-on-close */
t4=((C_word*)t0)[6];
f_7496(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k7704 in k7688 in a7678 in ##sys#process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2312 output-port */
t2=((C_word*)t0)[7];
f_7656(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7692 in k7688 in a7678 in ##sys#process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7698,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7702,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2316 make-on-close */
t4=((C_word*)t0)[3];
f_7496(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k7700 in k7692 in k7688 in a7678 in ##sys#process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2315 input-port */
t2=((C_word*)t0)[7];
f_7645(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7696 in k7692 in k7688 in a7678 in ##sys#process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2309 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7672 in ##sys#process in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7673,2,t0,t1);}
/* posixunix.scm: 2304 spawn */
t2=((C_word*)t0)[8];
f_7600(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7656(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7656,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7660,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2300 connect-parent */
t8=((C_word*)t0)[2];
f_7553(t8,t7,t4,t5);}

/* k7658 in output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2301 ##sys#custom-output-port */
t2=*((C_word*)lf[324]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7645(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7645,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7649,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2296 connect-parent */
t8=((C_word*)t0)[2];
f_7553(t8,t7,t4,t5);}

/* k7647 in input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2297 ##sys#custom-input-port */
t2=*((C_word*)lf[310]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7600(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7600,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2283 needed-pipe */
t9=((C_word*)t0)[2];
f_7533(t9,t8,t6);}

/* k7602 in spawn in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2284 needed-pipe */
t3=((C_word*)t0)[2];
f_7533(t3,t2,((C_word*)t0)[5]);}

/* k7605 in k7602 in spawn in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7610,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2285 needed-pipe */
t3=((C_word*)t0)[2];
f_7533(t3,t2,((C_word*)t0)[6]);}

/* k7608 in k7605 in k7602 in spawn in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=((C_word*)t0)[4];
if(C_truep(t3)){
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_u_i_car(t3);
t6=t2;
f_7617(t6,(C_word)C_a_i_cons(&a,2,t4,t5));}
else{
t4=t2;
f_7617(t4,C_SCHEME_FALSE);}}

/* k7615 in k7608 in k7605 in k7602 in spawn in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7617,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7621,a[2]=((C_word*)t0)[12],a[3]=t1,a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2288 process-fork */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a7622 in k7615 in k7608 in k7605 in k7602 in spawn in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7627,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2290 connect-child */
t3=((C_word*)t0)[8];
f_7567(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[287]+1));}

/* k7625 in a7622 in k7615 in k7608 in k7605 in k7602 in spawn in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7630,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7644,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_u_i_car(t4);
t7=t3;
f_7644(t7,(C_word)C_a_i_cons(&a,2,t5,t6));}
else{
t5=t3;
f_7644(t5,C_SCHEME_FALSE);}}

/* k7642 in k7625 in a7622 in k7615 in k7608 in k7605 in k7602 in spawn in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7644(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2291 connect-child */
t2=((C_word*)t0)[4];
f_7567(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],*((C_word*)lf[288]+1));}

/* k7628 in k7625 in a7622 in k7615 in k7608 in k7605 in k7602 in spawn in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7633,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7640,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_u_i_car(t4);
t7=t3;
f_7640(t7,(C_word)C_a_i_cons(&a,2,t5,t6));}
else{
t5=t3;
f_7640(t5,C_SCHEME_FALSE);}}

/* k7638 in k7628 in k7625 in a7622 in k7615 in k7608 in k7605 in k7602 in spawn in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2292 connect-child */
t2=((C_word*)t0)[4];
f_7567(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],*((C_word*)lf[289]+1));}

/* k7631 in k7628 in k7625 in a7622 in k7615 in k7608 in k7605 in k7602 in spawn in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2293 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7619 in k7615 in k7608 in k7605 in k7602 in spawn in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2286 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* connect-child in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7567(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7567,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7580,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2274 file-close */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k7578 in connect-child in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7580,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7492,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2248 duplicate-fileno */
t6=*((C_word*)lf[306]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k7490 in k7578 in connect-child in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2249 file-close */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7553(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7553,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7566,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2268 file-close */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k7564 in connect-parent in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7533(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7533,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7542,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7548,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a7547 in needed-pipe in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7548,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a7541 in needed-pipe in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7542,2,t0,t1);}
/* posixunix.scm: 2263 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* make-on-close in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7496(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7496,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7498,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,tmp=(C_word)a,a+=9,tmp));}

/* f_7498 in make-on-close in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7498,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_slot(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_slot(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7519,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a7518 */
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7519,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2258 ##sys#signal-hook */
t5=*((C_word*)lf[2]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[199],((C_word*)t0)[3],lf[429],((C_word*)t0)[2],t4);}}

/* a7512 */
static void C_ccall f_7513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7513,2,t0,t1);}
/* posixunix.scm: 2256 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7440(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7440r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7440r(t0,t1,t2,t3);}}

static void C_ccall f_7440r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7447,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2212 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k7445 in process-run in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7447,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2214 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2216 ##sys#shell-command */
t4=*((C_word*)lf[423]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k7464 in k7445 in process-run in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7470,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2216 ##sys#shell-command-arguments */
t3=*((C_word*)lf[426]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7468 in k7464 in k7445 in process-run in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2216 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7434,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[427],t2));}

/* ##sys#shell-command in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7429,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2202 get-environment-variable */
t3=*((C_word*)lf[124]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[425]);}

/* k7427 in ##sys#shell-command in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[424]));}

/* process-signal in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7398(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7398r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7398r(t0,t1,t2,t3);}}

static void C_ccall f_7398r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[421]);
t7=(C_word)C_i_check_exact_2(t5,lf[421]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2199 posix-error */
t10=lf[1];
f_2485(7,t10,t1,lf[199],lf[421],lf[422],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7395(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7395,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub1854(C_SCHEME_UNDEFINED,t2));}

/* parent-process-id in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7392,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1851(C_SCHEME_UNDEFINED));}

/* current-process-id in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7389,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1849(C_SCHEME_UNDEFINED));}

/* process-wait in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7314(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_7314r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7314r(t0,t1,t2);}}

static void C_ccall f_7314r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(7);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t2,C_fix(1)));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[416]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7341,a[2]=t8,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7347,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t13,t14);}

/* a7346 in process-wait in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7347,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2185 posix-error */
t6=lf[1];
f_2485(6,t6,t1,lf[199],lf[416],lf[417],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2186 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a7340 in process-wait in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7341,2,t0,t1);}
/* posixunix.scm: 2183 ##sys#process-wait */
t2=*((C_word*)lf[415]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7297,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 2170 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_7118r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7118r(t0,t1,t2,t3);}}

static void C_ccall f_7118r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7120,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7247,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7252,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist17611808 */
t7=t6;
f_7252(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist17621806 */
t9=t5;
f_7247(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body17591767 */
t11=t4;
f_7120(t11,t1,t7,t9);}}}

/* def-arglist1761 in process-execute in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7252(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7252,NULL,2,t0,t1);}
/* def-envlist17621806 */
t2=((C_word*)t0)[2];
f_7247(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist1762 in process-execute in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7247(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7247,NULL,3,t0,t1,t2);}
/* body17591767 */
t3=((C_word*)t0)[2];
f_7120(t3,t1,t2,C_SCHEME_FALSE);}

/* body1759 in process-execute in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7120(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7120,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[413]);
t5=(C_word)C_i_check_list_2(t2,lf[413]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7130,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2138 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}

/* k7128 in body1759 in process-execute in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7130,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=t1;
t4=(C_truep(t3)?t3:C_SCHEME_FALSE);
t5=(C_word)stub1725(C_SCHEME_UNDEFINED,C_fix(0),t4,t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7138,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_7138(t9,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* doloop1771 in k7128 in body1759 in process-execute in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7138(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7138,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=(C_truep(C_SCHEME_FALSE)?C_SCHEME_FALSE:C_SCHEME_FALSE);
t6=(C_word)stub1725(C_SCHEME_UNDEFINED,t4,t5,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7151,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t8=(C_word)C_i_check_list_2(((C_word*)t0)[4],lf[413]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7184,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t10)[1];
f_7184(t12,t7,((C_word*)t0)[4],C_fix(0));}
else{
t8=t7;
f_7151(2,t8,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[413]);
t6=(C_word)C_block_size(t4);
t7=t3;
t8=(C_truep(t4)?t4:C_SCHEME_FALSE);
t9=(C_word)stub1725(C_SCHEME_UNDEFINED,t7,t8,t6);
t10=(C_word)C_slot(t2,C_fix(1));
t11=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t21=t1;
t22=t10;
t23=t11;
t1=t21;
t2=t22;
t3=t23;
goto loop;}}

/* doloop1779 in doloop1771 in k7128 in body1759 in process-execute in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7184(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7184,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
t5=t3;
t6=(C_truep(C_SCHEME_FALSE)?C_SCHEME_FALSE:C_SCHEME_FALSE);
t7=t4;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub1737(C_SCHEME_UNDEFINED,t5,t6,C_fix(0)));}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[413]);
t6=(C_word)C_block_size(t4);
t7=t3;
t8=(C_truep(t4)?t4:C_SCHEME_FALSE);
t9=(C_word)stub1737(C_SCHEME_UNDEFINED,t7,t8,t6);
t10=(C_word)C_slot(t2,C_fix(1));
t11=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t16=t1;
t17=t10;
t18=t11;
t1=t16;
t2=t17;
t3=t18;
goto loop;}}

/* k7149 in doloop1771 in k7128 in body1759 in process-execute in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7176,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2152 ##sys#expand-home-path */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k7174 in k7149 in doloop1771 in k7128 in body1759 in process-execute in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2152 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7152 in k7149 in doloop1771 in k7128 in body1759 in process-execute in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub1732(C_SCHEME_UNDEFINED);
t5=(C_word)stub1744(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2159 posix-error */
t6=lf[1];
f_2485(6,t6,((C_word*)t0)[3],lf[199],lf[413],lf[414],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* process-fork in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7069(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7069r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7069r(t0,t1,t2);}}

static void C_ccall f_7069r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub1700(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2123 posix-error */
t5=lf[1];
f_2485(5,t5,t1,lf[199],lf[410],lf[411]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7091,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=t8;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k7089 in process-fork in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1713(C_SCHEME_UNDEFINED,C_fix(0)));}

/* glob in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6960(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_6960r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6960r(t0,t1,t2);}}

static void C_ccall f_6960r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_6966(t6,t1,t2);}

/* conc-loop in glob in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_6966(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6966,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6981,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a6986 in conc-loop in glob in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6987,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7061,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[409]);
/* posixunix.scm: 2108 make-pathname */
t8=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k7059 in a6986 in conc-loop in glob in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2108 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6989 in a6986 in conc-loop in glob in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2109 regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6992 in k6989 in a6986 in conc-loop in glob in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7001,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[408]);
/* posixunix.scm: 2110 directory */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k6999 in k6992 in k6989 in a6986 in conc-loop in glob in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7001,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7003,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7003(t5,((C_word*)t0)[2],t1);}

/* loop in k6999 in k6992 in k6989 in a6986 in conc-loop in glob in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_7003(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7003,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* posixunix.scm: 2111 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_6966(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7020,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixunix.scm: 2112 string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k7018 in loop in k6999 in k6992 in k6989 in a6986 in conc-loop in glob in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7020,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7030,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(t1);
/* posixunix.scm: 2113 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* posixunix.scm: 2114 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7003(t3,((C_word*)t0)[6],t2);}}

/* k7028 in k7018 in loop in k6999 in k6992 in k6989 in a6986 in conc-loop in glob in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7034,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 2113 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7003(t4,t2,t3);}

/* k7032 in k7028 in k7018 in loop in k6999 in k6992 in k6989 in a6986 in conc-loop in glob in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_7034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7034,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a6980 in conc-loop in glob in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6981,2,t0,t1);}
/* posixunix.scm: 2107 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6952,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub1642(t3),C_fix(0));}

/* k6950 in get-host-name in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6955,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6955(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2089 posix-error */
t3=lf[1];
f_2485(5,t3,t2,lf[398],lf[402],lf[403]);}}

/* k6953 in k6950 in get-host-name in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6913,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6917,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2070 ##sys#terminal-check */
f_6867(t3,lf[397],t2);}

/* k6915 in terminal-size in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6917,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6937,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
t5=*((C_word*)lf[400]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t2,C_fix(0),C_SCHEME_FALSE,lf[401]);}

/* k6935 in k6915 in terminal-size in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[400]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[401]);}

/* k6939 in k6935 in k6915 in terminal-size in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_pointer_argumentp(t3);
t5=(C_word)C_i_foreign_pointer_argumentp(t1);
t6=(C_word)stub1623(C_SCHEME_UNDEFINED,t2,t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* posixunix.scm: 2077 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2078 posix-error */
t8=lf[1];
f_2485(6,t8,((C_word*)t0)[4],lf[398],lf[397],lf[399],((C_word*)t0)[6]);}}

/* terminal-name in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6894,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6898,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2062 ##sys#terminal-check */
f_6867(t3,lf[396],t2);}

/* k6896 in terminal-name in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6898,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-nonnull-c-string */
t5=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub1613(t4,t3),C_fix(0));}

/* ##sys#terminal-check in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_6867(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6867,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6871,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2054 ##sys#check-port */
t5=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k6869 in ##sys#terminal-check in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[95],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2057 ##sys#error */
t5=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[395],((C_word*)t0)[4]);}}

/* terminal-port? in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6848,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6852,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2049 ##sys#check-port */
t4=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[393]);}

/* k6850 in terminal-port? in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2050 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k6853 in k6850 in terminal-port? in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_6789r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_6789r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6789r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6793,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2034 ##sys#check-port */
t6=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[387]);}

/* k6791 in set-buffering-mode! in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6793,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[389]);
if(C_truep(t6)){
t7=t5;
f_6799(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[390]);
if(C_truep(t7)){
t8=t5;
f_6799(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[391]);
if(C_truep(t8)){
t9=t5;
f_6799(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 2040 ##sys#error */
t9=*((C_word*)lf[146]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[387],lf[392],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k6797 in k6791 in set-buffering-mode! in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[387]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[95],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 2046 ##sys#error */
t6=*((C_word*)lf[146]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[387],lf[388],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6786,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub1580(C_SCHEME_UNDEFINED,t2));}

/* _exit in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6770(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_6770r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_6770r(t0,t1,t2);}}

static void C_ccall f_6770r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub1575(C_SCHEME_UNDEFINED,t4));}

/* local-timezone-abbreviation in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6762,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub1570(t2),C_fix(0));}

/* utc-time->seconds in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6747,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6751,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2002 check-time-vector */
f_6499(t3,lf[382],t2);}

/* k6749 in utc-time->seconds in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 2004 ##sys#cons-flonum */
t2=*((C_word*)lf[380]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2005 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[382],lf[383],((C_word*)t0)[3]);}}

/* local-time->seconds in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6732,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6736,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1996 check-time-vector */
f_6499(t3,lf[379],t2);}

/* k6734 in local-time->seconds in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 1998 ##sys#cons-flonum */
t2=*((C_word*)lf[380]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1999 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[379],lf[381],((C_word*)t0)[3]);}}

/* string->time in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6693(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6693r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6693r(t0,t1,t2,t3);}}

static void C_ccall f_6693r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?lf[378]:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[377]);
t7=(C_word)C_i_check_string_2(t5,lf[377]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6710,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1993 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k6708 in string->time in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6714,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1993 ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6712 in k6708 in string->time in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6714,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub1544(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6631(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6631r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6631r(t0,t1,t2,t3);}}

static void C_ccall f_6631r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6638,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1977 check-time-vector */
f_6499(t6,lf[374],t2);}

/* k6636 in time->string in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6638,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[374]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6657,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1981 ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub1508(t4,t3),C_fix(0));}}

/* k6658 in k6636 in time->string in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1985 ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1986 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[374],lf[376],((C_word*)t0)[2]);}}

/* k6655 in k6636 in time->string in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6657,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub1514(t3,t2,t1),C_fix(0));}

/* k6645 in k6636 in time->string in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1982 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[374],lf[375],((C_word*)t0)[2]);}}

/* seconds->string in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_6577r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_6577r(t0,t1,t2);}}

static void C_ccall f_6577r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6581,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* posixunix.scm: 1966 current-seconds */
t4=*((C_word*)lf[370]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=t3;
f_6581(2,t4,(C_word)C_slot(t2,C_fix(0)));}}

/* k6579 in seconds->string in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6581,2,t0,t1);}
t2=(C_word)C_i_check_number_2(t1,lf[372]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6587,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=t1;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub1487(t5,t4),C_fix(0));}

/* k6585 in k6579 in seconds->string in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1970 ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1971 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[372],lf[373],((C_word*)t0)[2]);}}

/* seconds->utc-time in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6545(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_6545r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_6545r(t0,t1,t2);}}

static void C_ccall f_6545r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6549,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* posixunix.scm: 1960 current-seconds */
t4=*((C_word*)lf[370]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=t3;
f_6549(2,t4,(C_word)C_slot(t2,C_fix(0)));}}

/* k6547 in seconds->utc-time in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_number_2(t1,lf[371]);
/* posixunix.scm: 1962 ##sys#decode-seconds */
t3=*((C_word*)lf[369]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* seconds->local-time in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6518(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_6518r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_6518r(t0,t1,t2);}}

static void C_ccall f_6518r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6522,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* posixunix.scm: 1956 current-seconds */
t4=*((C_word*)lf[370]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=t3;
f_6522(2,t4,(C_word)C_slot(t2,C_fix(0)));}}

/* k6520 in seconds->local-time in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_number_2(t1,lf[368]);
/* posixunix.scm: 1958 ##sys#decode-seconds */
t3=*((C_word*)lf[369]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* check-time-vector in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_6499(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6499,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1954 ##sys#error */
t6=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[367],t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* memory-mapped-file? in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6493,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[357]));}

/* memory-mapped-file-pointer in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6484,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[357],lf[364]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6449(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6449r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6449r(t0,t1,t2,t3);}}

static void C_ccall f_6449r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
t4=(C_word)C_i_check_structure_2(t2,lf[357],lf[362]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)stub1434(C_SCHEME_UNDEFINED,t8,t6);
t10=(C_word)C_eqp(C_fix(0),t9);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1940 posix-error */
t11=lf[1];
f_2485(7,t11,t1,lf[46],lf[362],lf[363],t2,t6);}}

/* map-file-to-memory in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_6391r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_6391r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_6391r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6395,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_6395(2,t10,t2);}
else{
/* posixunix.scm: 1925 ##sys#null-pointer */
t10=*((C_word*)lf[361]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k6393 in map-file-to-memory in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6395,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6401,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_6401(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1928 ##sys#signal-hook */
t6=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[57],lf[356],lf[360],t1);}}

/* k6399 in k6393 in map-file-to-memory in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6401,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)stub1403(t7,t8,t3,t4,t5,t6,((C_word*)t0)[3]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6407,a[2]=((C_word*)t0)[7],a[3]=t9,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t10,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1930 ##sys#pointer->address */
t12=*((C_word*)lf[359]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t9);}

/* k6418 in k6399 in k6393 in map-file-to-memory in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1931 posix-error */
t3=lf[1];
f_2485(11,t3,((C_word*)t0)[8],lf[46],lf[356],lf[358],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_6407(2,t3,C_SCHEME_UNDEFINED);}}

/* k6405 in k6399 in k6393 in map-file-to-memory in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6407,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[357],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* get-environment-variables in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6307,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6313,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6313(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_6313(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6313,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6317,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub1385(t5,t4),C_fix(0));}

/* k6315 in loop in get-environment-variables in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6317,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6325,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6325(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k6315 in loop in get-environment-variables in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_6325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6325,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1889 ##sys#substring */
t5=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1892 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k6349 in scan in k6315 in loop in get-environment-variables in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6355,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1890 ##sys#substring */
t5=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k6353 in k6349 in scan in k6315 in loop in get-environment-variables in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6355,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6343,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1891 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6313(t5,t3,t4);}

/* k6341 in k6353 in k6349 in scan in k6315 in loop in get-environment-variables in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6343,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6292,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[344]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6300,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1878 ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6298 in unsetenv in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_unsetenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6275,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[343]);
t5=(C_word)C_i_check_string_2(t3,lf[343]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6286,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1873 ##sys#make-c-string */
t7=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k6284 in setenv in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6290,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1873 ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6288 in k6284 in setenv in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6249,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6256,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6273,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1861 ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k6271 in fifo? in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1861 ##sys#file-info */
t2=*((C_word*)lf[342]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6254 in fifo? in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1864 posix-error */
t2=lf[1];
f_2485(6,t2,((C_word*)t0)[3],lf[46],lf[88],lf[341],((C_word*)t0)[2]);}}

/* create-fifo in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6206r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6206r(t0,t1,t2,t3);}}

static void C_ccall f_6206r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[339]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6213,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_6213(t6,(C_word)C_slot(t3,C_fix(0)));}
else{
t6=(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_6213(t7,(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k6211 in create-fifo in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_6213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6213,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[339]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6234,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1855 ##sys#expand-home-path */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k6232 in k6211 in create-fifo in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1855 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6228 in k6211 in create-fifo in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1856 posix-error */
t3=lf[1];
f_2485(7,t3,((C_word*)t0)[3],lf[46],lf[339],lf[340],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6178,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[330],lf[337]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1845 posix-error */
t9=lf[1];
f_2485(6,t9,t1,lf[46],lf[337],lf[338],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6156(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6156r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6156r(t0,t1,t2,t3);}}

static void C_ccall f_6156r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6160,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1836 setup */
f_6037(t4,t2,t3,lf[335]);}

/* k6158 in file-test-lock in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1838 err */
f_6108(((C_word*)t0)[3],lf[336],t1,lf[335]);}}

/* file-lock/blocking in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6141r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6141r(t0,t1,t2,t3);}}

static void C_ccall f_6141r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6145,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1830 setup */
f_6037(t4,t2,t3,lf[333]);}

/* k6143 in file-lock/blocking in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1832 err */
f_6108(((C_word*)t0)[2],lf[334],t1,lf[333]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6126(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6126r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6126r(t0,t1,t2,t3);}}

static void C_ccall f_6126r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6130,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1824 setup */
f_6037(t4,t2,t3,lf[331]);}

/* k6128 in file-lock in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1826 err */
f_6108(((C_word*)t0)[2],lf[332],t1,lf[331]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_6108(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6108,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1821 posix-error */
t8=lf[1];
f_2485(8,t8,t1,lf[46],t4,t2,t5,t6,t7);}

/* setup in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_6037(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6037,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_u_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_u_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t8,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6056,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1813 ##sys#check-port */
t16=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}

/* k6054 in setup in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6056,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_6062(t6,t5);}
else{
t5=t3;
f_6062(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k6060 in k6054 in setup in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_6062(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6062,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[330],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5998,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[327]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6015,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6022,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6026,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1796 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_6015(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1798 ##sys#error */
t6=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[327],lf[329],t2);}}}

/* k6024 in file-truncate in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1796 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6020 in file-truncate in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6015(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k6013 in file-truncate in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_6015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1800 posix-error */
t2=lf[1];
f_2485(7,t2,((C_word*)t0)[4],lf[46],lf[327],lf[328],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr5r,(void*)f_5742r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5742r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5742r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5928,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5933,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5938,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?12281294 */
t10=t9;
f_5938(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi12291292 */
t12=t8;
f_5933(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close12301289 */
t14=t7;
f_5928(t14,t1,t10,t12);}
else{
t14=(C_word)C_u_i_car(t13);
t15=(C_word)C_slot(t13,C_fix(1));
/* body12261235 */
t16=t6;
f_5744(t16,t1,t10,t12,t14);}}}}

/* def-nonblocking?1228 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5938(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5938,NULL,2,t0,t1);}
/* def-bufi12291292 */
t2=((C_word*)t0)[2];
f_5933(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1229 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5933(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5933,NULL,3,t0,t1,t2);}
/* def-on-close12301289 */
t3=((C_word*)t0)[2];
f_5928(t3,t1,t2,C_fix(0));}

/* def-on-close1230 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5928(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5928,NULL,4,t0,t1,t2,t3);}
/* body12261235 */
t4=((C_word*)t0)[2];
f_5744(t4,t1,t2,t3,*((C_word*)lf[322]+1));}

/* body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5744(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5744,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5748,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1738 ##sys#file-nonblocking! */
t6=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_5748(2,t6,C_SCHEME_UNDEFINED);}}

/* k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5748,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5750,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_5796(t11,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5840,a[2]=t3,tmp=(C_word)a,a+=3,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5854,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1757 ##sys#make-string */
t12=*((C_word*)lf[320]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_5854(2,t12,((C_word*)t0)[6]);}}}

/* k5852 in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5854,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_5796(t4,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5855,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));}

/* f_5855 in k5852 in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5855,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5872,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_5872(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1773 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5750(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_5872(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5872,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5882,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1763 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5750(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_u_fixnum_difference(t4,t2);
/* posixunix.scm: 1768 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k5880 in loop */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1765 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_5872(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_5840 in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5840,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1756 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5750(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5794 in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5796(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5796,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5800,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5805,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5811,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5832,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1776 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t5,t6,t7,t8);}

/* a5831 in k5794 in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5832,2,t0,t1);}
/* posixunix.scm: 1786 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* a5810 in k5794 in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5811,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5821,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1783 posix-error */
t3=lf[1];
f_2485(7,t3,t2,lf[46],((C_word*)t0)[3],lf[326],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_5821(2,t3,C_SCHEME_UNDEFINED);}}}

/* k5819 in a5810 in k5794 in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1784 on-close */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a5804 in k5794 in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5805,3,t0,t1,t2);}
/* posixunix.scm: 1778 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* k5798 in k5794 in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5800,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5803,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1787 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k5801 in k5798 in k5794 in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5750(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5750,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5766,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1746 ##sys#thread-yield! */
t8=*((C_word*)lf[312]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1748 posix-error */
t7=lf[1];
f_2485(7,t7,t1,((C_word*)t0)[3],lf[46],lf[325],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5785,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1750 ##sys#substring */
t7=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k5783 in poke in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1750 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5750(t3,((C_word*)t0)[2],t1,t2);}

/* k5764 in poke in k5746 in body1226 in ##sys#custom-output-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1747 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5750(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5263(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr5r,(void*)f_5263r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5263r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5263r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(19);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5652,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5657,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5662,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5667,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?10551199 */
t11=t10;
f_5667(t11,t1);}
else{
t11=(C_word)C_u_i_car(t5);
t12=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi10561197 */
t13=t9;
f_5662(t13,t1,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close10571194 */
t15=t8;
f_5657(t15,t1,t11,t13);}
else{
t15=(C_word)C_u_i_car(t14);
t16=(C_word)C_slot(t14,C_fix(1));
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?10581190 */
t17=t7;
f_5652(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_u_i_car(t16);
t18=(C_word)C_slot(t16,C_fix(1));
/* body10531063 */
t19=t6;
f_5265(t19,t1,t11,t13,t15,t17);}}}}}

/* def-nonblocking?1055 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5667(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5667,NULL,2,t0,t1);}
/* def-bufi10561197 */
t2=((C_word*)t0)[2];
f_5662(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1056 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5662(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5662,NULL,3,t0,t1,t2);}
/* def-on-close10571194 */
t3=((C_word*)t0)[2];
f_5657(t3,t1,t2,C_fix(1));}

/* def-on-close1057 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5657(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5657,NULL,4,t0,t1,t2,t3);}
/* def-more?10581190 */
t4=((C_word*)t0)[2];
f_5652(t4,t1,t2,t3,*((C_word*)lf[322]+1));}

/* def-more?1058 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5652(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5652,NULL,5,t0,t1,t2,t3,t4);}
/* body10531063 */
t5=((C_word*)t0)[2];
f_5265(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5265(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5265,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5269,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1612 ##sys#file-nonblocking! */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_5269(2,t7,C_SCHEME_UNDEFINED);}}

/* k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5269,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1614 ##sys#make-string */
t5=*((C_word*)lf[320]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_5275(2,t5,((C_word*)t0)[10]);}}

/* k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5275,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5276,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5299,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5307,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5389,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5394,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5407,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5419,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,tmp=(C_word)a,a+=7,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5440,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5449,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5525,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1662 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)(void*)(*((C_word*)t18+1)))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a5524 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5525,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5531,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_5531(t7,t1,C_SCHEME_FALSE);}

/* loop in a5524 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5531(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5531,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5611,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5627,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1727 fetch */
t5=((C_word*)t0)[5];
f_5307(t5,t4);}}

/* k5625 in loop in a5524 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1729 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5531(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a5616 in loop in a5524 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5617,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1724 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5531(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a5610 in loop in a5524 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5611,2,t0,t1);}
/* posixunix.scm: 1722 ##sys#scan-buffer-line */
t2=*((C_word*)lf[321]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a5524 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5533,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5540,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_5540(2,t8,(C_truep(t7)?t7:lf[318]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5583,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1704 ##sys#make-string */
t8=*((C_word*)lf[320]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k5581 in bumper in loop in a5524 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_u_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1710 ##sys#string-append */
t6=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=((C_word*)t0)[2];
f_5540(2,t6,t1);}}

/* k5538 in bumper in loop in a5524 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5540,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5550,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1714 fetch */
t5=((C_word*)t0)[3];
f_5307(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_u_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1719 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k5548 in k5538 in bumper in loop in a5524 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1715 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5448 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5449,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5457,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_5457(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_5457(t8,(C_word)C_u_fixnum_difference(t7,t5));}}

/* k5455 in a5448 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5457,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5459,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5459(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k5455 in a5448 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5459(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5459,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_u_fixnum_difference(t2,t8);
t14=(C_word)C_u_fixnum_plus(t3,t8);
t15=(C_word)C_u_fixnum_plus(t4,t8);
/* posixunix.scm: 1690 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5507,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1692 fetch */
t7=((C_word*)t0)[2];
f_5307(t7,t6);}}}

/* k5505 in loop in k5455 in a5448 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1695 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5459(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a5439 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5444,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1680 fetch */
t3=((C_word*)t0)[2];
f_5307(t3,t2);}

/* k5442 in a5439 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1681 peek */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_5299(((C_word*)t0)[2]));}

/* a5418 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5419,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5429,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1677 posix-error */
t3=lf[1];
f_2485(7,t3,t2,lf[46],((C_word*)t0)[3],lf[317],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_5429(2,t3,C_SCHEME_UNDEFINED);}}}

/* k5427 in a5418 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1678 on-close */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a5406 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1672 ready? */
t3=((C_word*)t0)[2];
f_5276(t3,t1);}}

/* a5393 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5398,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1664 fetch */
t3=((C_word*)t0)[2];
f_5307(t3,t2);}

/* k5396 in a5393 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_5299(((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k5387 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5389,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5392,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1731 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k5390 in k5387 in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5307,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5319,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5319(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5319,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5335,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1639 ##sys#thread-block-for-i/o! */
t6=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[314]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1642 posix-error */
t5=lf[1];
f_2485(7,t5,t1,lf[46],((C_word*)t0)[6],lf[315],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5356,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1646 more? */
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k5354 in loop in fetch in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5356,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5359,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1648 ##sys#thread-yield! */
t3=*((C_word*)lf[312]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5365,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_5365(2,t8,t7);}
else{
/* posixunix.scm: 1654 posix-error */
t7=lf[1];
f_2485(7,t7,t4,lf[46],((C_word*)t0)[3],lf[316],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_5365(2,t6,C_SCHEME_UNDEFINED);}}}

/* k5363 in k5354 in loop in fetch in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5357 in k5354 in loop in fetch in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1649 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5319(t2,((C_word*)t0)[2]);}

/* k5333 in loop in fetch in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1640 ##sys#thread-yield! */
t3=*((C_word*)lf[312]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5336 in k5333 in loop in fetch in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1641 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5319(t2,((C_word*)t0)[2]);}

/* peek in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall f_5299(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5276,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1620 ##sys#file-select-one */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5278 in ready? in k5273 in k5267 in body1053 in ##sys#custom-input-port in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* posixunix.scm: 1624 posix-error */
t4=lf[1];
f_2485(7,t4,((C_word*)t0)[5],lf[46],((C_word*)t0)[4],lf[311],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t1));}}

/* duplicate-fileno in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5236r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5236r(t0,t1,t2,t3);}}

static void C_ccall f_5236r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[306]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5243,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_5243(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[306]);
t8=t5;
f_5243(t8,(C_word)C_dup2(t2,t6));}}

/* k5241 in duplicate-fileno in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5243(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5243,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5246,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1605 posix-error */
t3=lf[1];
f_2485(6,t3,t2,lf[46],lf[306],lf[307],((C_word*)t0)[2]);}
else{
t3=t2;
f_5246(2,t3,C_SCHEME_UNDEFINED);}}

/* k5244 in k5241 in duplicate-fileno in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5191,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5195,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1587 ##sys#check-port */
t4=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[300]);}

/* k5193 in port->fileno in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5195,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[301],t2);
if(C_truep(t3)){
/* posixunix.scm: 1588 ##sys#tcp-port->fileno */
t4=*((C_word*)lf[302]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1589 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k5228 in k5193 in port->fileno in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5230,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1594 posix-error */
t2=lf[1];
f_2485(6,t2,((C_word*)t0)[3],lf[57],lf[300],lf[303],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5213,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1592 posix-error */
t4=lf[1];
f_2485(6,t4,t3,lf[46],lf[300],lf[304],((C_word*)t0)[2]);}
else{
t4=t3;
f_5213(2,t4,C_SCHEME_UNDEFINED);}}}

/* k5211 in k5228 in k5193 in port->fileno in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5177(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5177r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5177r(t0,t1,t2,t3);}}

static void C_ccall f_5177r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[299]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5189,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1583 mode */
f_5111(t5,C_SCHEME_FALSE,t3);}

/* k5187 in open-output-file* in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5189,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1583 check */
f_5148(((C_word*)t0)[2],lf[299],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5163(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5163r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5163r(t0,t1,t2,t3);}}

static void C_ccall f_5163r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[298]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5175,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1579 mode */
f_5111(t5,C_SCHEME_TRUE,t3);}

/* k5173 in open-input-file* in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5175,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1579 check */
f_5148(((C_word*)t0)[2],lf[298],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5148(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5148,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1572 posix-error */
t6=lf[1];
f_2485(6,t6,t1,lf[46],t2,lf[296],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5161,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1573 ##sys#make-port */
t7=*((C_word*)lf[149]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[150]+1),lf[297],lf[95]);}}

/* k5159 in check in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_5111(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5111,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5119,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[290]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1566 ##sys#error */
t8=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[291],t5);}
else{
t8=t4;
f_5119(2,t8,lf[292]);}}
else{
/* posixunix.scm: 1567 ##sys#error */
t7=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[293],t5);}}
else{
t5=t4;
f_5119(2,t5,(C_truep(t2)?lf[294]:lf[295]));}}

/* k5117 in mode in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1562 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5086,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[284]);
t5=(C_word)C_i_check_string_2(t3,lf[284]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5075,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t9=t8;
f_5075(2,t9,C_SCHEME_FALSE);}}

/* k5073 in file-link in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5079,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_5079(2,t3,C_SCHEME_FALSE);}}

/* k5077 in k5073 in file-link in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub968(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1547 posix-error */
t3=lf[1];
f_2485(7,t3,((C_word*)t0)[4],lf[46],lf[285],lf[286],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5017(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5017r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5017r(t0,t1,t2,t3);}}

static void C_ccall f_5017r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(10);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[281]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5028,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5056,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1533 ##sys#expand-home-path */
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k5054 in read-symbolic-link in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1533 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5026 in read-symbolic-link in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5028,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5031,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1535 posix-error */
t4=lf[1];
f_2485(6,t4,t3,lf[46],lf[281],lf[283],((C_word*)t0)[2]);}
else{
t4=t3;
f_5031(2,t4,C_SCHEME_UNDEFINED);}}

/* k5029 in k5026 in read-symbolic-link in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5034,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1536 substring */
t3=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5032 in k5029 in k5026 in read-symbolic-link in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5040,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 1537 symbolic-link? */
t3=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t3=t2;
f_5040(2,t3,C_SCHEME_FALSE);}}

/* k5038 in k5032 in k5029 in k5026 in read-symbolic-link in k5014 in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 1538 read-symbolic-link */
t2=*((C_word*)lf[281]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[282]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* create-symbolic-link in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4979,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[277]);
t5=(C_word)C_i_check_string_2(t3,lf[277]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5000,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5012,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1521 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5010 in create-symbolic-link in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1521 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4998 in create-symbolic-link in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5008,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1522 ##sys#expand-home-path */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5006 in k4998 in create-symbolic-link in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1522 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5002 in k4998 in create-symbolic-link in k4975 in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1524 posix-error */
t3=lf[1];
f_2485(7,t3,((C_word*)t0)[4],lf[46],lf[278],lf[279],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* create-session in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4960,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4964,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4970,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1492 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4964(2,t4,C_SCHEME_UNDEFINED);}}

/* k4968 in create-session in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1493 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[274],lf[275]);}

/* k4962 in create-session in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4954,3,t0,t1,t2);}
/* posixunix.scm: 1487 check */
f_4918(t1,t2,C_fix((C_word)X_OK),lf[273]);}

/* file-write-access? in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4948,3,t0,t1,t2);}
/* posixunix.scm: 1486 check */
f_4918(t1,t2,C_fix((C_word)W_OK),lf[272]);}

/* file-read-access? in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4942,3,t0,t1,t2);}
/* posixunix.scm: 1485 check */
f_4918(t1,t2,C_fix((C_word)R_OK),lf[271]);}

/* check in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_4918(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4918,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4936,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4940,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1482 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4938 in check in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1482 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4934 in check in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4936,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4928,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_4928(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1483 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4926 in k4934 in check in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4888,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[269]);
t6=(C_word)C_i_check_exact_2(t3,lf[269]);
t7=(C_word)C_i_check_exact_2(t4,lf[269]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4912,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4916,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1472 ##sys#expand-home-path */
t10=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k4914 in change-file-owner in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1472 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4910 in change-file-owner in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1473 posix-error */
t3=lf[1];
f_2485(8,t3,((C_word*)t0)[3],lf[46],lf[269],lf[270],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4861,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[267]);
t5=(C_word)C_i_check_exact_2(t3,lf[267]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4882,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4886,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1464 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4884 in change-file-mode in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1464 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4880 in change-file-mode in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1465 posix-error */
t3=lf[1];
f_2485(7,t3,((C_word*)t0)[3],lf[46],lf[267],lf[268],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4797,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[226]);
t5=(C_word)C_i_check_exact_2(t3,lf[226]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4793,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t9=t8;
f_4793(2,t9,C_SCHEME_FALSE);}}

/* k4791 in initialize-groups in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4793,2,t0,t1);}
t2=(C_word)stub874(C_SCHEME_UNDEFINED,t1,((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1385 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4811 in k4791 in initialize-groups in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1386 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[226],lf[227],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4731,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4735,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
if(C_truep((C_word)stub831(C_SCHEME_UNDEFINED,t4))){
t5=t3;
f_4735(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1368 ##sys#error */
t5=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[223],lf[225]);}}

/* k4733 in set-groups! in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4740,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4740(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop857 in k4733 in set-groups! in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_4740(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4740,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4756,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1373 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[223]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k4754 in doloop857 in k4733 in set-groups! in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1374 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[223],lf[224],((C_word*)t0)[2]);}

/* get-groups in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4668,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4672,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4726,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1354 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4672(2,t4,C_SCHEME_UNDEFINED);}}

/* k4724 in get-groups in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1355 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[219],lf[222]);}

/* k4670 in get-groups in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)stub831(C_SCHEME_UNDEFINED,((C_word*)t0)[3]))){
t3=t2;
f_4675(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1357 ##sys#error */
t3=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[219],lf[221]);}}

/* k4673 in k4670 in get-groups in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)stub827(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4707,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1359 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_4678(2,t4,C_SCHEME_UNDEFINED);}}

/* k4705 in k4673 in k4670 in get-groups in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1360 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[219],lf[220]);}

/* k4676 in k4673 in k4670 in get-groups in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4683,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4683(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k4676 in k4673 in k4670 in get-groups in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_4683(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4683,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4697,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1364 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k4695 in loop in k4676 in k4673 in k4670 in get-groups in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4697,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* group-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4590r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4590r(t0,t1,t2,t3);}}

static void C_ccall f_4590r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4597,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t7=t6;
f_4597(t7,(C_word)C_getgrgid(t2));}
else{
t7=(C_word)C_i_check_string_2(t2,lf[218]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4648,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1328 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}

/* k4646 in group-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4597(t2,(C_word)C_getgrnam(t1));}

/* k4595 in group-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_4597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4597,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4605 in k4595 in group-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4611,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k4609 in k4605 in k4595 in group-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4615,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4620,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4620(t6,t2,C_fix(0));}

/* loop in k4609 in k4605 in k4595 in group-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_4620(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4620,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub800(t5,t4),C_fix(0));}

/* k4622 in loop in k4609 in k4605 in k4595 in group-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4634,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1337 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4620(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k4632 in k4622 in loop in k4609 in k4605 in k4595 in group-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4634,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4613 in k4609 in k4605 in k4595 in group-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[215]+1):*((C_word*)lf[216]+1));
t3=t2;
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4578,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4582,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1313 current-effective-user-id */
t4=*((C_word*)lf[211]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4580 in current-effective-user-name in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1313 user-information */
t2=*((C_word*)lf[214]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4576 in current-effective-user-name in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4564,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4568,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1310 current-user-id */
t4=*((C_word*)lf[210]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4566 in current-user-name in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1310 user-information */
t2=*((C_word*)lf[214]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4562 in current-user-name in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_list_ref(t1,C_fix(0)));}

/* user-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4496r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4496r(t0,t1,t2,t3);}}

static void C_ccall f_4496r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4503,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t7=t6;
f_4503(t7,(C_word)C_getpwuid(t2));}
else{
t7=(C_word)C_i_check_string_2(t2,lf[214]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4542,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1298 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}

/* k4540 in user-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4503(t2,(C_word)C_getpwnam(t1));}

/* k4501 in user-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_4503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4503,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4511 in k4501 in user-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4517,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k4515 in k4511 in k4501 in user-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4521,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k4519 in k4515 in k4511 in k4501 in user-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4525,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k4523 in k4519 in k4515 in k4511 in k4501 in user-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4529,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k4527 in k4523 in k4519 in k4515 in k4511 in k4501 in user-information in k4492 in k4488 in k4484 in k4480 in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[215]+1):*((C_word*)lf[216]+1));
t3=t2;
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* system-information in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4446,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4475,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1243 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4446(2,t3,C_SCHEME_UNDEFINED);}}

/* k4473 in system-information in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1244 ##sys#error */
t2=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[207],lf[209]);}

/* k4444 in system-information in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4453,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k4451 in k4444 in system-information in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4457,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k4455 in k4451 in k4444 in system-information in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4461,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k4459 in k4455 in k4451 in k4444 in system-information in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4465,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k4463 in k4459 in k4455 in k4451 in k4444 in system-information in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4469,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k4467 in k4463 in k4459 in k4455 in k4451 in k4444 in system-information in k4438 in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4469,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4424,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[205]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1222 posix-error */
t5=lf[1];
f_2485(5,t5,t1,lf[199],lf[205],lf[206]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4409,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[203]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1216 posix-error */
t5=lf[1];
f_2485(5,t5,t1,lf[199],lf[203],lf[204]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4403,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[202]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4371,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4377,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4377(t5,t1,*((C_word*)lf[194]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_4377(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4377,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 1206 loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4331,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[198]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4349,tmp=(C_word)a,a+=2,tmp);
t6=f_4349(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1199 posix-error */
t7=lf[1];
f_2485(5,t7,t1,lf[199],lf[198],lf[200]);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* loop715 in set-signal-mask! in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall f_4349(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_check_exact_2(t2,lf[198]);
t4=(C_word)C_sigaddset(t2);
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4313,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4323,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1185 h */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1187 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k4321 in ##sys#interrupt-hook in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1186 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4300,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[197]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k4287 in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4291(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4291,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[196]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4248,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1102 posix-error */
t3=lf[1];
f_2485(5,t3,t2,lf[46],lf[167],lf[168]);}
else{
t3=t2;
f_4248(2,t3,C_SCHEME_UNDEFINED);}}

/* k4246 in create-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1103 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4224r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4224r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4224r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[166]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4228,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4226 in with-output-to-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4228,2,t0,t1);}
t2=C_mutate((C_word*)lf[166]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4234,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1090 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4233 in k4226 in with-output-to-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4234r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4234r(t0,t1,t2);}}

static void C_ccall f_4234r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4238,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1092 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4236 in a4233 in k4226 in with-output-to-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[166]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4204r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4204r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4204r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[164]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4208,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4206 in with-input-from-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4208,2,t0,t1);}
t2=C_mutate((C_word*)lf[164]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4214,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1080 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4213 in k4206 in with-input-from-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4214r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4214r(t0,t1,t2);}}

static void C_ccall f_4214r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4218,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1082 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4216 in a4213 in k4206 in with-input-from-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[164]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4180r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4180r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4180r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4184,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4182 in call-with-output-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4189,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4195,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1070 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4194 in k4182 in call-with-output-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4195r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4195r(t0,t1,t2);}}

static void C_ccall f_4195r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4199,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1073 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4197 in a4194 in k4182 in call-with-output-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4188 in k4182 in call-with-output-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4189,2,t0,t1);}
/* posixunix.scm: 1071 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4156r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4156r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4156r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4160,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4158 in call-with-input-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4165,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4171,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1062 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4170 in k4158 in call-with-input-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4171r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4171r(t0,t1,t2);}}

static void C_ccall f_4171r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4175,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1065 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4173 in a4170 in k4158 in call-with-input-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4164 in k4158 in call-with-input-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
/* posixunix.scm: 1063 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4140,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4144,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1049 ##sys#check-port */
t4=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[156]);}

/* k4142 in close-input-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4144,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4147,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1051 posix-error */
t5=lf[1];
f_2485(6,t5,t3,lf[46],lf[157],lf[158],((C_word*)t0)[3]);}
else{
t5=t3;
f_4147(2,t5,C_SCHEME_UNDEFINED);}}

/* k4145 in k4142 in close-input-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4104r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4104r(t0,t1,t2,t3);}}

static void C_ccall f_4104r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[155]);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):lf[153]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4118,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[153]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4125,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1044 ##sys#make-c-string */
t10=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=(C_word)C_eqp(t6,lf[154]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4135,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1045 ##sys#make-c-string */
t11=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t2);}
else{
/* posixunix.scm: 1046 badmode */
f_4047(t7,t6);}}}

/* k4133 in open-output-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4135,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4118(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k4123 in open-output-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4125,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4118(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k4116 in open-output-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1040 check */
f_4053(((C_word*)t0)[3],lf[155],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4068r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4068r(t0,t1,t2,t3);}}

static void C_ccall f_4068r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[152]);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):lf[153]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4082,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[153]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4089,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1033 ##sys#make-c-string */
t10=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=(C_word)C_eqp(t6,lf[154]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4099,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1034 ##sys#make-c-string */
t11=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t2);}
else{
/* posixunix.scm: 1035 badmode */
f_4047(t7,t6);}}}

/* k4097 in open-input-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4099,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4082(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k4087 in open-input-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4089,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4082(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k4080 in open-input-pipe in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1029 check */
f_4053(((C_word*)t0)[3],lf[152],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_4053(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4053,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1021 posix-error */
t6=lf[1];
f_2485(6,t6,t1,lf[46],t2,lf[148],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4066,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1022 ##sys#make-port */
t7=*((C_word*)lf[149]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[150]+1),lf[151],lf[95]);}}

/* k4064 in check in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_4047(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4047,NULL,2,t1,t2);}
/* posixunix.scm: 1018 ##sys#error */
t3=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[147],t2);}

/* canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3718,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[130]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3725,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3839,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 966  cwd */
t8=((C_word*)t0)[6];
f_3662(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[11],a[9]=t2,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4025,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 968  sref */
t10=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_3845(t9,C_SCHEME_FALSE);}}}

/* k4023 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3845(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3845,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
f_3725(2,t2,((C_word*)t0)[9]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3858,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 971  cwd */
t5=((C_word*)t0)[7];
f_3662(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4011,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 972  sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[9],C_fix(0));}}}

/* k4009 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 972  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k3998 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4000,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 973  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[4];
f_3864(t2,C_SCHEME_FALSE);}}

/* k4005 in k3998 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3864(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3864,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3871,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 975  get-environment-variable */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[143]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 980  cwd */
t5=((C_word*)t0)[5];
f_3662(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3993,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 981  sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k3991 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 981  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3970 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3989,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 982  sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3908(t2,C_SCHEME_FALSE);}}

/* k3987 in k3970 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 982  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3976 in k3970 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3978,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 983  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3908(t2,C_SCHEME_FALSE);}}

/* k3983 in k3976 in k3970 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3908(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3906 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3908(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3908,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[8]);
/* posixunix.scm: 984  ##sys#substring */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[7],((C_word*)t0)[8],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3969,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 985  sref */
t5=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k3967 in k3906 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 985  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k3946 in k3906 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3954,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3965,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 986  sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3921(2,t2,C_SCHEME_FALSE);}}

/* k3963 in k3946 in k3906 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 986  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3952 in k3946 in k3906 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3954,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 987  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3921(2,t2,C_SCHEME_FALSE);}}

/* k3959 in k3952 in k3946 in k3906 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 987  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3919 in k3906 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[6]);
/* posixunix.scm: 988  ##sys#substring */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[5],((C_word*)t0)[6],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3945,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 989  sref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[6],C_fix(0));}}

/* k3943 in k3919 in k3906 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
f_3725(2,t4,((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 992  cwd */
t5=((C_word*)t0)[2];
f_3662(t5,t4);}}

/* k3939 in k3943 in k3919 in k3906 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 992  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[145],((C_word*)t0)[2]);}

/* k3900 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 980  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[144],((C_word*)t0)[2]);}

/* k3869 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3874,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3874(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3889,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 976  user */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3887 in k3869 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 976  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[142],t1);}

/* k3872 in k3869 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3878,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 977  ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k3876 in k3872 in k3869 in k3862 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 974  sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3856 in k3843 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 971  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[141],((C_word*)t0)[2]);}

/* k3837 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 966  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[140]);}

/* k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=t1;
/* string-split */
t4=*((C_word*)lf[138]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,lf[139]);}

/* k3730 in k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3732,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3734,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3734(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k3730 in k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3734(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3734,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 995  null? */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3739 in loop in k3730 in k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3741,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3747,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 996  null? */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3802,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 1007 string=? */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[137],t5);}}

/* k3803 in k3739 in loop in k3730 in k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3805,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3802(t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 1009 string=? */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[136],t3);}}

/* k3812 in k3803 in k3739 in loop in k3730 in k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3814,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3802(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_3802(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k3800 in k3739 in loop in k3730 in k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3802(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1005 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3734(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3745 in k3739 in loop in k3730 in k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[131]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3783,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 998  sref */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k3781 in k3745 in k3739 in loop in k3730 in k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3783,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3760,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3764,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_cons(&a,2,lf[133],((C_word*)t0)[2]);
/* posixunix.scm: 1001 reverse */
t7=*((C_word*)lf[134]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3775,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3779,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1004 reverse */
t6=*((C_word*)lf[134]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3777 in k3781 in k3745 in k3739 in loop in k3730 in k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1004 isperse */
f_3646(((C_word*)t0)[2],t1);}

/* k3773 in k3781 in k3745 in k3739 in loop in k3730 in k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1002 sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[135],t1);}

/* k3762 in k3781 in k3745 in k3739 in loop in k3730 in k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1001 isperse */
f_3646(((C_word*)t0)[2],t1);}

/* k3758 in k3781 in k3745 in k3739 in loop in k3730 in k3723 in canonical-path in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 999  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[132],t1);}

/* cwd in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3662,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3669,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3671,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a3670 in cwd in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3671,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3677,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3695,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a3694 in a3670 in cwd in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3701,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3707,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a3706 in a3694 in a3670 in cwd in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3707(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3707r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3707r(t0,t1,t2);}}

static void C_ccall f_3707r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3713,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k569572 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a3712 in a3706 in a3694 in a3670 in cwd in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3713,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3700 in a3694 in a3670 in cwd in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3701,2,t0,t1);}
/* posixunix.scm: 961  cw */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a3676 in a3670 in cwd in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3677,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3683,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k569572 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a3682 in a3676 in a3670 in cwd in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[126]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[127]);}

/* k3667 in cwd in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* isperse in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3646(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3646,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[123]);}

/* current-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3605r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3605r(t0,t1,t2);}}

static void C_ccall f_3605r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(t4)){
/* posixunix.scm: 940  change-directory */
t5=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3618,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 941  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}}

/* k3616 in current-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 944  ##sys#substring */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 945  posix-error */
t3=lf[1];
f_2485(5,t3,((C_word*)t0)[2],lf[46],lf[115],lf[117]);}}

/* directory? in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3585,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[116]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 934  ##sys#expand-home-path */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3590 in directory? in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3603,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 869  ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3601 in k3590 in directory? in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_stat(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_mk_bool(C_isdir):C_SCHEME_FALSE));}

/* directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_3431r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3431r(t0,t1,t2);}}

static void C_ccall f_3431r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3531,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3536,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec457498 */
t6=t5;
f_3536(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?458496 */
t8=t4;
f_3531(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body455463 */
t10=t3;
f_3433(t10,t1,t6,t8);}}}

/* def-spec457 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3536,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3544,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 907  current-directory */
t3=*((C_word*)lf[115]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3542 in def-spec457 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?458496 */
t2=((C_word*)t0)[3];
f_3531(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?458 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3531(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3531,NULL,3,t0,t1,t2);}
/* body455463 */
t3=((C_word*)t0)[2];
f_3433(t3,t1,t2,C_SCHEME_FALSE);}

/* body455 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3433(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3433,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[112]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 909  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}

/* k3438 in body455 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 910  ##sys#make-pointer */
t3=*((C_word*)lf[114]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3441 in k3438 in body455 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 911  ##sys#make-pointer */
t3=*((C_word*)lf[114]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3444 in k3441 in k3438 in body455 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3530,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 912  ##sys#expand-home-path */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k3528 in k3444 in k3441 in k3438 in body455 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 912  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3448 in k3444 in k3441 in k3438 in body455 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3450,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 914  posix-error */
t3=lf[1];
f_2485(6,t3,((C_word*)t0)[7],lf[46],lf[112],lf[113],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3464(t6,((C_word*)t0)[7]);}}

/* loop in k3448 in k3444 in k3441 in k3438 in body455 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3464,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 922  ##sys#substring */
t5=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k3472 in loop in k3448 in k3444 in k3441 in k3438 in body455 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 923  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fix(0));}

/* k3475 in k3472 in loop in k3448 in k3444 in k3441 in k3438 in body455 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3480,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 924  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_3480(2,t3,C_SCHEME_FALSE);}}

/* k3478 in k3475 in k3472 in loop in k3448 in k3444 in k3441 in k3438 in body455 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3486,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_3486(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
t6=(C_truep(t5)?(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]):C_SCHEME_FALSE);
t7=t2;
f_3486(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_3486(t4,C_SCHEME_FALSE);}}

/* k3484 in k3478 in k3475 in k3472 in loop in k3448 in k3444 in k3441 in k3438 in body455 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3486(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3486,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 929  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3464(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 930  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3464(t3,t2);}}

/* k3494 in k3484 in k3478 in k3475 in k3472 in loop in k3448 in k3444 in k3441 in k3438 in body455 in directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3407,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[108]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3425,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3429,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 900  ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3427 in delete-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 900  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3423 in delete-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_rmdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 901  posix-error */
t4=lf[1];
f_2485(6,t4,((C_word*)t0)[3],lf[46],lf[108],lf[109],((C_word*)t0)[2]);}}

/* change-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3383,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[106]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3401,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3405,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 894  ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3403 in change-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 894  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3399 in change-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_chdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 895  posix-error */
t4=lf[1];
f_2485(6,t4,((C_word*)t0)[3],lf[46],lf[106],lf[107],((C_word*)t0)[2]);}}

/* create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3251r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3251r(t0,t1,t2,t3);}}

static void C_ccall f_3251r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[103]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 881  ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3261,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3270,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_3270(t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3365,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 869  ##sys#make-c-string */
t6=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t1);}}

/* k3363 in k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_stat(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=((C_word*)t0)[2];
f_3270(t4,(C_truep(t3)?C_mk_bool(C_isdir):C_SCHEME_FALSE));}

/* k3268 in k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3270(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3270,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3280,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3333,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 873  ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}}

/* k3352 in k3268 in k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_mkdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 874  posix-error */
t4=lf[1];
f_2485(6,t4,((C_word*)t0)[3],lf[46],lf[103],lf[104],((C_word*)t0)[2]);}}

/* a3332 in k3268 in k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3333,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
/* posixunix.scm: 885  make-pathname */
t5=*((C_word*)lf[105]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* a3326 in k3268 in k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
/* posixunix.scm: 884  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k3278 in k3268 in k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3280,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3282,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3282(t5,((C_word*)t0)[2],t1);}

/* loop in k3278 in k3268 in k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3282(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3282,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t2;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3325,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 869  ##sys#make-c-string */
t6=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=t3;
f_3289(t4,C_SCHEME_FALSE);}}

/* k3323 in loop in k3278 in k3268 in k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_stat(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(C_truep(t3)?C_mk_bool(C_isdir):C_SCHEME_FALSE);
t5=((C_word*)t0)[2];
f_3289(t5,(C_word)C_i_not(t4));}

/* k3287 in loop in k3278 in k3268 in k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3289,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3292,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3310,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 887  pathname-directory */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3308 in k3287 in loop in k3278 in k3268 in k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 887  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3282(t2,((C_word*)t0)[2],t1);}

/* k3290 in k3287 in loop in k3278 in k3268 in k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3292,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3306,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 873  ##sys#make-c-string */
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3304 in k3290 in k3287 in loop in k3278 in k3268 in k3259 in create-directory in k3247 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_mkdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 874  posix-error */
t4=lf[1];
f_2485(6,t4,((C_word*)t0)[3],lf[46],lf[103],lf[104],((C_word*)t0)[2]);}}

/* set-file-position! in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3189r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3189r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3189r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[93]);
t8=(C_word)C_i_check_exact_2(t6,lf[93]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3202,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_negativep(t3))){
/* posixunix.scm: 839  ##sys#signal-hook */
t10=*((C_word*)lf[2]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[98],lf[93],lf[99],t3,t2);}
else{
t10=t9;
f_3202(2,t10,C_SCHEME_UNDEFINED);}}

/* k3200 in set-file-position! in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3208,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 840  port? */
t4=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k3212 in k3200 in set-file-position! in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[95]);
t4=((C_word*)t0)[4];
f_3208(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_3208(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 846  ##sys#signal-hook */
t2=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[57],lf[93],lf[96],((C_word*)t0)[5]);}}}

/* k3206 in k3200 in set-file-position! in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 847  posix-error */
t2=lf[1];
f_2485(7,t2,((C_word*)t0)[4],lf[46],lf[93],lf[94],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* socket? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3179,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[91]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3186,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 828  ##sys#stat */
f_3014(t4,t2,C_SCHEME_FALSE,lf[91]);}

/* k3184 in socket? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* f_3168 in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3168,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3175,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 820  ##sys#stat */
f_3014(t4,t2,C_SCHEME_FALSE,lf[89]);}

/* k3173 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* block-device? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3158,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3165,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 813  ##sys#stat */
f_3014(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k3163 in block-device? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* character-device? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3148,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3155,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 806  ##sys#stat */
f_3014(t4,t2,C_SCHEME_FALSE,lf[84]);}

/* k3153 in character-device? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* stat-directory? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3139,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[83]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3146,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 801  ##sys#stat */
f_3014(t4,t2,C_SCHEME_FALSE,lf[83]);}

/* k3144 in stat-directory? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isdir));}

/* stat-regular? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3130,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[82]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3137,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 796  ##sys#stat */
f_3014(t4,t2,C_SCHEME_FALSE,lf[82]);}

/* k3135 in stat-regular? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* symbolic-link? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3121,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[81]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3128,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 791  ##sys#stat */
f_3014(t4,t2,C_SCHEME_TRUE,lf[81]);}

/* k3126 in symbolic-link? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3112,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[80]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3119,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 786  ##sys#stat */
f_3014(t4,t2,C_SCHEME_TRUE,lf[80]);}

/* k3117 in regular-file? in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3106,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3110,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 782  ##sys#stat */
f_3014(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k3108 in file-permissions in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3100,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3104,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 781  ##sys#stat */
f_3014(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k3102 in file-owner in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3094,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3098,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 780  ##sys#stat */
f_3014(t3,t2,C_SCHEME_FALSE,lf[77]);}

/* k3096 in file-change-time in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3098,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3088,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3092,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 779  ##sys#stat */
f_3014(t3,t2,C_SCHEME_FALSE,lf[76]);}

/* k3090 in file-access-time in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3092,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3082,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3086,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 778  ##sys#stat */
f_3014(t3,t2,C_SCHEME_FALSE,lf[75]);}

/* k3084 in file-modification-time in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3086,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3076,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3080,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 777  ##sys#stat */
f_3014(t3,t2,C_SCHEME_FALSE,lf[74]);}

/* k3078 in file-size in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3080,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3051r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3051r(t0,t1,t2,t3);}}

static void C_ccall f_3051r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3055,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* posixunix.scm: 770  ##sys#stat */
f_3014(t4,t2,t6,lf[73]);}

/* k3053 in file-stat in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_3014(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3014,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3018,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_3018(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3039,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3046,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 761  ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 765  ##sys#signal-hook */
t6=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[57],lf[72],t2);}}}

/* k3044 in ##sys#stat in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 761  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3037 in ##sys#stat in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3018(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k3016 in ##sys#stat in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 767  posix-error */
t2=lf[1];
f_2485(6,t2,((C_word*)t0)[4],lf[46],((C_word*)t0)[3],lf[71],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2758r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2758r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2758r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(12);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=(C_word)stub116(C_SCHEME_UNDEFINED,C_fix(0));
t10=(C_word)stub116(C_SCHEME_UNDEFINED,C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2774,a[2]=t6,a[3]=t8,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t11)){
t13=t12;
f_2774(t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
t14=t2;
t15=t12;
f_2774(t15,(C_word)stub121(C_SCHEME_UNDEFINED,C_fix(0),t14));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[65]);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2979,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t15=t12;
f_2774(t15,f_2979(t14,t2));}}}

/* loop150 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall f_2979(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_check_exact_2(t2,lf[65]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[2])[1],t2));
t5=(C_word)stub121(C_SCHEME_UNDEFINED,C_fix(0),t2);
t6=(C_word)C_slot(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* k2772 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_2774(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2774,NULL,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2780(t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[6]);
t5=((C_word*)t0)[6];
t6=t3;
f_2780(t6,(C_word)stub121(C_SCHEME_UNDEFINED,C_fix(1),t5));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[6],lf[65]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2937,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=t3;
f_2780(t6,f_2937(t5,((C_word*)t0)[6]));}}}

/* loop175 in k2772 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static C_word C_fcall f_2937(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_check_exact_2(t2,lf[65]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[2])[1],t2));
t5=(C_word)stub121(C_SCHEME_UNDEFINED,C_fix(1),t2);
t6=(C_word)C_slot(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* k2778 in k2772 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_2780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2780,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2783,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[65]);
t4=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_2783(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_2783(t4,(C_word)C_C_select(t3));}}

/* k2781 in k2778 in k2772 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_2783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2783,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 716  posix-error */
t2=lf[1];
f_2485(7,t2,((C_word*)t0)[4],lf[46],lf[65],lf[66],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[3]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[2]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 717  values */
C_values(4,0,((C_word*)t0)[4],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t4=((C_word*)t0)[3];
t5=t3;
f_2822(t5,(C_word)stub127(C_SCHEME_UNDEFINED,C_fix(0),t4));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2879,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2881,a[2]=t5,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_2881(t10,t6,((C_word*)t0)[3]);}}
else{
t4=t3;
f_2822(t4,C_SCHEME_FALSE);}}}}

/* loop205 in k2781 in k2778 in k2772 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_2881(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2881,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2894,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)stub127(C_SCHEME_UNDEFINED,C_fix(0),t3))){
t5=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t4;
f_2894(t7,t6);}
else{
t5=t4;
f_2894(t5,C_SCHEME_UNDEFINED);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2892 in loop205 in k2781 in k2778 in k2772 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_2894(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2881(t3,((C_word*)t0)[2],t2);}

/* k2877 in k2781 in k2778 in k2772 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2822(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2820 in k2781 in k2778 in k2772 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_2822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2822,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2826,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
t4=t2;
f_2826(t4,(C_word)stub127(C_SCHEME_UNDEFINED,C_fix(1),t3));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2838,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2840,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2840(t9,t5,((C_word*)t0)[2]);}}
else{
t3=t2;
f_2826(t3,C_SCHEME_FALSE);}}

/* loop221 in k2820 in k2781 in k2778 in k2772 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_2840(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2840,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2853,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)stub127(C_SCHEME_UNDEFINED,C_fix(1),t3))){
t5=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t4;
f_2853(t7,t6);}
else{
t5=t4;
f_2853(t5,C_SCHEME_UNDEFINED);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2851 in loop221 in k2820 in k2781 in k2778 in k2772 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_2853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2840(t3,((C_word*)t0)[2],t2);}

/* k2836 in k2820 in k2781 in k2778 in k2772 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2826(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2824 in k2820 in k2781 in k2778 in k2772 in file-select in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_fcall f_2826(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 719  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-mkstemp in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2720,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[62]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2727,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 668  ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2725 in file-mkstemp in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2727,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2733,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 672  posix-error */
t6=lf[1];
f_2485(6,t6,t4,lf[46],lf[62],lf[64],((C_word*)t0)[2]);}
else{
t6=t4;
f_2733(2,t6,C_SCHEME_UNDEFINED);}}

/* k2731 in k2725 in file-mkstemp in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 673  ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k2738 in k2731 in k2725 in file-mkstemp in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 673  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2681r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2681r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2681r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[59]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2688,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_2688(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 657  ##sys#signal-hook */
t8=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[57],lf[59],lf[61],t3);}}

/* k2686 in file-write in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2688,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[59]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2697,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 662  posix-error */
t8=lf[1];
f_2485(7,t8,t6,lf[46],lf[59],lf[60],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_2697(2,t8,C_SCHEME_UNDEFINED);}}

/* k2695 in k2686 in file-write in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2639r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2639r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2639r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[55]);
t6=(C_word)C_i_check_exact_2(t3,lf[55]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2649,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_2649(2,t8,(C_word)C_slot(t4,C_fix(0)));}
else{
/* posixunix.scm: 645  make-string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k2647 in file-read in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_2652(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 647  ##sys#signal-hook */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[57],lf[55],lf[58],t1);}}

/* k2650 in k2647 in file-read in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2655,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 650  posix-error */
t5=lf[1];
f_2485(7,t5,t3,lf[46],lf[55],lf[56],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_2655(2,t5,C_SCHEME_UNDEFINED);}}

/* k2653 in k2650 in k2647 in file-read in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2655,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2624,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[52]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 638  posix-error */
t4=lf[1];
f_2485(6,t4,t1,lf[46],lf[52],lf[53],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2586r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2586r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2586r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[48]);
t8=(C_word)C_i_check_exact_2(t3,lf[48]);
t9=(C_word)C_i_check_exact_2(t6,lf[48]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2603,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2616,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 629  ##sys#expand-home-path */
t12=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k2614 in file-open in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 629  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2601 in file-open in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2603,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2606,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 631  posix-error */
t5=lf[1];
f_2485(8,t5,t3,lf[46],lf[48],lf[49],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_2606(2,t5,C_SCHEME_UNDEFINED);}}

/* k2604 in k2601 in file-open in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2547r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2547r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2547r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_fix(0):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_exact_2(t2,lf[45]);
t8=(C_word)C_i_check_exact_2(t3,lf[45]);
t9=t2;
t10=t3;
t11=(C_word)stub33(C_SCHEME_UNDEFINED,t9,t10,t6);
t12=(C_word)C_eqp(t11,C_fix(-1));
if(C_truep(t12)){
/* posixunix.scm: 619  posix-error */
t13=lf[1];
f_2485(7,t13,t1,lf[46],lf[45],lf[47],t2,t3);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t11);}}

/* ##sys#file-select-one in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2506,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub26(C_SCHEME_UNDEFINED,t2));}

/* ##sys#file-nonblocking! in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2503,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub22(C_SCHEME_UNDEFINED,t2));}

/* posix-error in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_2485r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2485r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2485r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2489,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 509  ##sys#update-errno */
t7=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k2487 in posix-error in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,(C_word)stub12(t4,t1),C_fix(0));}

/* k2498 in k2487 in posix-error in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 510  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[3],t1);}

/* k2494 in k2487 in posix-error in k2476 in k2473 in k2470 in k2467 in k2464 in k2461 in k2458 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[2]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[609] = {
{"toplevel:posixunix_scm",(void*)C_posix_toplevel},
{"f_2460:posixunix_scm",(void*)f_2460},
{"f_2463:posixunix_scm",(void*)f_2463},
{"f_2466:posixunix_scm",(void*)f_2466},
{"f_2469:posixunix_scm",(void*)f_2469},
{"f_2472:posixunix_scm",(void*)f_2472},
{"f_2475:posixunix_scm",(void*)f_2475},
{"f_2478:posixunix_scm",(void*)f_2478},
{"f_8308:posixunix_scm",(void*)f_8308},
{"f_8324:posixunix_scm",(void*)f_8324},
{"f_8312:posixunix_scm",(void*)f_8312},
{"f_8315:posixunix_scm",(void*)f_8315},
{"f_3249:posixunix_scm",(void*)f_3249},
{"f_4289:posixunix_scm",(void*)f_4289},
{"f_8302:posixunix_scm",(void*)f_8302},
{"f_4440:posixunix_scm",(void*)f_4440},
{"f_8287:posixunix_scm",(void*)f_8287},
{"f_8297:posixunix_scm",(void*)f_8297},
{"f_8284:posixunix_scm",(void*)f_8284},
{"f_4482:posixunix_scm",(void*)f_4482},
{"f_8269:posixunix_scm",(void*)f_8269},
{"f_8279:posixunix_scm",(void*)f_8279},
{"f_8266:posixunix_scm",(void*)f_8266},
{"f_4486:posixunix_scm",(void*)f_4486},
{"f_8251:posixunix_scm",(void*)f_8251},
{"f_8261:posixunix_scm",(void*)f_8261},
{"f_8248:posixunix_scm",(void*)f_8248},
{"f_4490:posixunix_scm",(void*)f_4490},
{"f_8233:posixunix_scm",(void*)f_8233},
{"f_8243:posixunix_scm",(void*)f_8243},
{"f_8230:posixunix_scm",(void*)f_8230},
{"f_4494:posixunix_scm",(void*)f_4494},
{"f_8209:posixunix_scm",(void*)f_8209},
{"f_8225:posixunix_scm",(void*)f_8225},
{"f_8191:posixunix_scm",(void*)f_8191},
{"f_8204:posixunix_scm",(void*)f_8204},
{"f_8198:posixunix_scm",(void*)f_8198},
{"f_4977:posixunix_scm",(void*)f_4977},
{"f_5016:posixunix_scm",(void*)f_5016},
{"f_8168:posixunix_scm",(void*)f_8168},
{"f_8164:posixunix_scm",(void*)f_8164},
{"f_7916:posixunix_scm",(void*)f_7916},
{"f_8093:posixunix_scm",(void*)f_8093},
{"f_8099:posixunix_scm",(void*)f_8099},
{"f_8088:posixunix_scm",(void*)f_8088},
{"f_8083:posixunix_scm",(void*)f_8083},
{"f_7918:posixunix_scm",(void*)f_7918},
{"f_8070:posixunix_scm",(void*)f_8070},
{"f_8078:posixunix_scm",(void*)f_8078},
{"f_7925:posixunix_scm",(void*)f_7925},
{"f_8058:posixunix_scm",(void*)f_8058},
{"f_8052:posixunix_scm",(void*)f_8052},
{"f_7935:posixunix_scm",(void*)f_7935},
{"f_7937:posixunix_scm",(void*)f_7937},
{"f_7956:posixunix_scm",(void*)f_7956},
{"f_8038:posixunix_scm",(void*)f_8038},
{"f_8045:posixunix_scm",(void*)f_8045},
{"f_8032:posixunix_scm",(void*)f_8032},
{"f_7971:posixunix_scm",(void*)f_7971},
{"f_8025:posixunix_scm",(void*)f_8025},
{"f_8022:posixunix_scm",(void*)f_8022},
{"f_8012:posixunix_scm",(void*)f_8012},
{"f_7988:posixunix_scm",(void*)f_7988},
{"f_8010:posixunix_scm",(void*)f_8010},
{"f_7996:posixunix_scm",(void*)f_7996},
{"f_8003:posixunix_scm",(void*)f_8003},
{"f_8000:posixunix_scm",(void*)f_8000},
{"f_7983:posixunix_scm",(void*)f_7983},
{"f_7981:posixunix_scm",(void*)f_7981},
{"f_8059:posixunix_scm",(void*)f_8059},
{"f_7859:posixunix_scm",(void*)f_7859},
{"f_7871:posixunix_scm",(void*)f_7871},
{"f_7866:posixunix_scm",(void*)f_7866},
{"f_7861:posixunix_scm",(void*)f_7861},
{"f_7802:posixunix_scm",(void*)f_7802},
{"f_7814:posixunix_scm",(void*)f_7814},
{"f_7809:posixunix_scm",(void*)f_7809},
{"f_7804:posixunix_scm",(void*)f_7804},
{"f_7725:posixunix_scm",(void*)f_7725},
{"f_7796:posixunix_scm",(void*)f_7796},
{"f_7800:posixunix_scm",(void*)f_7800},
{"f_7762:posixunix_scm",(void*)f_7762},
{"f_7776:posixunix_scm",(void*)f_7776},
{"f_7770:posixunix_scm",(void*)f_7770},
{"f_7727:posixunix_scm",(void*)f_7727},
{"f_7736:posixunix_scm",(void*)f_7736},
{"f_7667:posixunix_scm",(void*)f_7667},
{"f_7679:posixunix_scm",(void*)f_7679},
{"f_7710:posixunix_scm",(void*)f_7710},
{"f_7690:posixunix_scm",(void*)f_7690},
{"f_7706:posixunix_scm",(void*)f_7706},
{"f_7694:posixunix_scm",(void*)f_7694},
{"f_7702:posixunix_scm",(void*)f_7702},
{"f_7698:posixunix_scm",(void*)f_7698},
{"f_7673:posixunix_scm",(void*)f_7673},
{"f_7656:posixunix_scm",(void*)f_7656},
{"f_7660:posixunix_scm",(void*)f_7660},
{"f_7645:posixunix_scm",(void*)f_7645},
{"f_7649:posixunix_scm",(void*)f_7649},
{"f_7600:posixunix_scm",(void*)f_7600},
{"f_7604:posixunix_scm",(void*)f_7604},
{"f_7607:posixunix_scm",(void*)f_7607},
{"f_7610:posixunix_scm",(void*)f_7610},
{"f_7617:posixunix_scm",(void*)f_7617},
{"f_7623:posixunix_scm",(void*)f_7623},
{"f_7627:posixunix_scm",(void*)f_7627},
{"f_7644:posixunix_scm",(void*)f_7644},
{"f_7630:posixunix_scm",(void*)f_7630},
{"f_7640:posixunix_scm",(void*)f_7640},
{"f_7633:posixunix_scm",(void*)f_7633},
{"f_7621:posixunix_scm",(void*)f_7621},
{"f_7567:posixunix_scm",(void*)f_7567},
{"f_7580:posixunix_scm",(void*)f_7580},
{"f_7492:posixunix_scm",(void*)f_7492},
{"f_7553:posixunix_scm",(void*)f_7553},
{"f_7566:posixunix_scm",(void*)f_7566},
{"f_7533:posixunix_scm",(void*)f_7533},
{"f_7548:posixunix_scm",(void*)f_7548},
{"f_7542:posixunix_scm",(void*)f_7542},
{"f_7496:posixunix_scm",(void*)f_7496},
{"f_7498:posixunix_scm",(void*)f_7498},
{"f_7519:posixunix_scm",(void*)f_7519},
{"f_7513:posixunix_scm",(void*)f_7513},
{"f_7440:posixunix_scm",(void*)f_7440},
{"f_7447:posixunix_scm",(void*)f_7447},
{"f_7466:posixunix_scm",(void*)f_7466},
{"f_7470:posixunix_scm",(void*)f_7470},
{"f_7434:posixunix_scm",(void*)f_7434},
{"f_7425:posixunix_scm",(void*)f_7425},
{"f_7429:posixunix_scm",(void*)f_7429},
{"f_7398:posixunix_scm",(void*)f_7398},
{"f_7395:posixunix_scm",(void*)f_7395},
{"f_7392:posixunix_scm",(void*)f_7392},
{"f_7389:posixunix_scm",(void*)f_7389},
{"f_7314:posixunix_scm",(void*)f_7314},
{"f_7347:posixunix_scm",(void*)f_7347},
{"f_7341:posixunix_scm",(void*)f_7341},
{"f_7297:posixunix_scm",(void*)f_7297},
{"f_7118:posixunix_scm",(void*)f_7118},
{"f_7252:posixunix_scm",(void*)f_7252},
{"f_7247:posixunix_scm",(void*)f_7247},
{"f_7120:posixunix_scm",(void*)f_7120},
{"f_7130:posixunix_scm",(void*)f_7130},
{"f_7138:posixunix_scm",(void*)f_7138},
{"f_7184:posixunix_scm",(void*)f_7184},
{"f_7151:posixunix_scm",(void*)f_7151},
{"f_7176:posixunix_scm",(void*)f_7176},
{"f_7154:posixunix_scm",(void*)f_7154},
{"f_7069:posixunix_scm",(void*)f_7069},
{"f_7091:posixunix_scm",(void*)f_7091},
{"f_6960:posixunix_scm",(void*)f_6960},
{"f_6966:posixunix_scm",(void*)f_6966},
{"f_6987:posixunix_scm",(void*)f_6987},
{"f_7061:posixunix_scm",(void*)f_7061},
{"f_6991:posixunix_scm",(void*)f_6991},
{"f_6994:posixunix_scm",(void*)f_6994},
{"f_7001:posixunix_scm",(void*)f_7001},
{"f_7003:posixunix_scm",(void*)f_7003},
{"f_7020:posixunix_scm",(void*)f_7020},
{"f_7030:posixunix_scm",(void*)f_7030},
{"f_7034:posixunix_scm",(void*)f_7034},
{"f_6981:posixunix_scm",(void*)f_6981},
{"f_6948:posixunix_scm",(void*)f_6948},
{"f_6952:posixunix_scm",(void*)f_6952},
{"f_6955:posixunix_scm",(void*)f_6955},
{"f_6913:posixunix_scm",(void*)f_6913},
{"f_6917:posixunix_scm",(void*)f_6917},
{"f_6937:posixunix_scm",(void*)f_6937},
{"f_6941:posixunix_scm",(void*)f_6941},
{"f_6894:posixunix_scm",(void*)f_6894},
{"f_6898:posixunix_scm",(void*)f_6898},
{"f_6867:posixunix_scm",(void*)f_6867},
{"f_6871:posixunix_scm",(void*)f_6871},
{"f_6848:posixunix_scm",(void*)f_6848},
{"f_6852:posixunix_scm",(void*)f_6852},
{"f_6855:posixunix_scm",(void*)f_6855},
{"f_6789:posixunix_scm",(void*)f_6789},
{"f_6793:posixunix_scm",(void*)f_6793},
{"f_6799:posixunix_scm",(void*)f_6799},
{"f_6786:posixunix_scm",(void*)f_6786},
{"f_6770:posixunix_scm",(void*)f_6770},
{"f_6762:posixunix_scm",(void*)f_6762},
{"f_6747:posixunix_scm",(void*)f_6747},
{"f_6751:posixunix_scm",(void*)f_6751},
{"f_6732:posixunix_scm",(void*)f_6732},
{"f_6736:posixunix_scm",(void*)f_6736},
{"f_6693:posixunix_scm",(void*)f_6693},
{"f_6710:posixunix_scm",(void*)f_6710},
{"f_6714:posixunix_scm",(void*)f_6714},
{"f_6631:posixunix_scm",(void*)f_6631},
{"f_6638:posixunix_scm",(void*)f_6638},
{"f_6660:posixunix_scm",(void*)f_6660},
{"f_6657:posixunix_scm",(void*)f_6657},
{"f_6647:posixunix_scm",(void*)f_6647},
{"f_6577:posixunix_scm",(void*)f_6577},
{"f_6581:posixunix_scm",(void*)f_6581},
{"f_6587:posixunix_scm",(void*)f_6587},
{"f_6545:posixunix_scm",(void*)f_6545},
{"f_6549:posixunix_scm",(void*)f_6549},
{"f_6518:posixunix_scm",(void*)f_6518},
{"f_6522:posixunix_scm",(void*)f_6522},
{"f_6499:posixunix_scm",(void*)f_6499},
{"f_6493:posixunix_scm",(void*)f_6493},
{"f_6484:posixunix_scm",(void*)f_6484},
{"f_6449:posixunix_scm",(void*)f_6449},
{"f_6391:posixunix_scm",(void*)f_6391},
{"f_6395:posixunix_scm",(void*)f_6395},
{"f_6401:posixunix_scm",(void*)f_6401},
{"f_6420:posixunix_scm",(void*)f_6420},
{"f_6407:posixunix_scm",(void*)f_6407},
{"f_6307:posixunix_scm",(void*)f_6307},
{"f_6313:posixunix_scm",(void*)f_6313},
{"f_6317:posixunix_scm",(void*)f_6317},
{"f_6325:posixunix_scm",(void*)f_6325},
{"f_6351:posixunix_scm",(void*)f_6351},
{"f_6355:posixunix_scm",(void*)f_6355},
{"f_6343:posixunix_scm",(void*)f_6343},
{"f_6292:posixunix_scm",(void*)f_6292},
{"f_6300:posixunix_scm",(void*)f_6300},
{"f_6275:posixunix_scm",(void*)f_6275},
{"f_6286:posixunix_scm",(void*)f_6286},
{"f_6290:posixunix_scm",(void*)f_6290},
{"f_6249:posixunix_scm",(void*)f_6249},
{"f_6273:posixunix_scm",(void*)f_6273},
{"f_6256:posixunix_scm",(void*)f_6256},
{"f_6206:posixunix_scm",(void*)f_6206},
{"f_6213:posixunix_scm",(void*)f_6213},
{"f_6234:posixunix_scm",(void*)f_6234},
{"f_6230:posixunix_scm",(void*)f_6230},
{"f_6178:posixunix_scm",(void*)f_6178},
{"f_6156:posixunix_scm",(void*)f_6156},
{"f_6160:posixunix_scm",(void*)f_6160},
{"f_6141:posixunix_scm",(void*)f_6141},
{"f_6145:posixunix_scm",(void*)f_6145},
{"f_6126:posixunix_scm",(void*)f_6126},
{"f_6130:posixunix_scm",(void*)f_6130},
{"f_6108:posixunix_scm",(void*)f_6108},
{"f_6037:posixunix_scm",(void*)f_6037},
{"f_6056:posixunix_scm",(void*)f_6056},
{"f_6062:posixunix_scm",(void*)f_6062},
{"f_5998:posixunix_scm",(void*)f_5998},
{"f_6026:posixunix_scm",(void*)f_6026},
{"f_6022:posixunix_scm",(void*)f_6022},
{"f_6015:posixunix_scm",(void*)f_6015},
{"f_5742:posixunix_scm",(void*)f_5742},
{"f_5938:posixunix_scm",(void*)f_5938},
{"f_5933:posixunix_scm",(void*)f_5933},
{"f_5928:posixunix_scm",(void*)f_5928},
{"f_5744:posixunix_scm",(void*)f_5744},
{"f_5748:posixunix_scm",(void*)f_5748},
{"f_5854:posixunix_scm",(void*)f_5854},
{"f_5855:posixunix_scm",(void*)f_5855},
{"f_5872:posixunix_scm",(void*)f_5872},
{"f_5882:posixunix_scm",(void*)f_5882},
{"f_5840:posixunix_scm",(void*)f_5840},
{"f_5796:posixunix_scm",(void*)f_5796},
{"f_5832:posixunix_scm",(void*)f_5832},
{"f_5811:posixunix_scm",(void*)f_5811},
{"f_5821:posixunix_scm",(void*)f_5821},
{"f_5805:posixunix_scm",(void*)f_5805},
{"f_5800:posixunix_scm",(void*)f_5800},
{"f_5803:posixunix_scm",(void*)f_5803},
{"f_5750:posixunix_scm",(void*)f_5750},
{"f_5785:posixunix_scm",(void*)f_5785},
{"f_5766:posixunix_scm",(void*)f_5766},
{"f_5263:posixunix_scm",(void*)f_5263},
{"f_5667:posixunix_scm",(void*)f_5667},
{"f_5662:posixunix_scm",(void*)f_5662},
{"f_5657:posixunix_scm",(void*)f_5657},
{"f_5652:posixunix_scm",(void*)f_5652},
{"f_5265:posixunix_scm",(void*)f_5265},
{"f_5269:posixunix_scm",(void*)f_5269},
{"f_5275:posixunix_scm",(void*)f_5275},
{"f_5525:posixunix_scm",(void*)f_5525},
{"f_5531:posixunix_scm",(void*)f_5531},
{"f_5627:posixunix_scm",(void*)f_5627},
{"f_5617:posixunix_scm",(void*)f_5617},
{"f_5611:posixunix_scm",(void*)f_5611},
{"f_5533:posixunix_scm",(void*)f_5533},
{"f_5583:posixunix_scm",(void*)f_5583},
{"f_5540:posixunix_scm",(void*)f_5540},
{"f_5550:posixunix_scm",(void*)f_5550},
{"f_5449:posixunix_scm",(void*)f_5449},
{"f_5457:posixunix_scm",(void*)f_5457},
{"f_5459:posixunix_scm",(void*)f_5459},
{"f_5507:posixunix_scm",(void*)f_5507},
{"f_5440:posixunix_scm",(void*)f_5440},
{"f_5444:posixunix_scm",(void*)f_5444},
{"f_5419:posixunix_scm",(void*)f_5419},
{"f_5429:posixunix_scm",(void*)f_5429},
{"f_5407:posixunix_scm",(void*)f_5407},
{"f_5394:posixunix_scm",(void*)f_5394},
{"f_5398:posixunix_scm",(void*)f_5398},
{"f_5389:posixunix_scm",(void*)f_5389},
{"f_5392:posixunix_scm",(void*)f_5392},
{"f_5307:posixunix_scm",(void*)f_5307},
{"f_5319:posixunix_scm",(void*)f_5319},
{"f_5356:posixunix_scm",(void*)f_5356},
{"f_5365:posixunix_scm",(void*)f_5365},
{"f_5359:posixunix_scm",(void*)f_5359},
{"f_5335:posixunix_scm",(void*)f_5335},
{"f_5338:posixunix_scm",(void*)f_5338},
{"f_5299:posixunix_scm",(void*)f_5299},
{"f_5276:posixunix_scm",(void*)f_5276},
{"f_5280:posixunix_scm",(void*)f_5280},
{"f_5236:posixunix_scm",(void*)f_5236},
{"f_5243:posixunix_scm",(void*)f_5243},
{"f_5246:posixunix_scm",(void*)f_5246},
{"f_5191:posixunix_scm",(void*)f_5191},
{"f_5195:posixunix_scm",(void*)f_5195},
{"f_5230:posixunix_scm",(void*)f_5230},
{"f_5213:posixunix_scm",(void*)f_5213},
{"f_5177:posixunix_scm",(void*)f_5177},
{"f_5189:posixunix_scm",(void*)f_5189},
{"f_5163:posixunix_scm",(void*)f_5163},
{"f_5175:posixunix_scm",(void*)f_5175},
{"f_5148:posixunix_scm",(void*)f_5148},
{"f_5161:posixunix_scm",(void*)f_5161},
{"f_5111:posixunix_scm",(void*)f_5111},
{"f_5119:posixunix_scm",(void*)f_5119},
{"f_5086:posixunix_scm",(void*)f_5086},
{"f_5075:posixunix_scm",(void*)f_5075},
{"f_5079:posixunix_scm",(void*)f_5079},
{"f_5017:posixunix_scm",(void*)f_5017},
{"f_5056:posixunix_scm",(void*)f_5056},
{"f_5028:posixunix_scm",(void*)f_5028},
{"f_5031:posixunix_scm",(void*)f_5031},
{"f_5034:posixunix_scm",(void*)f_5034},
{"f_5040:posixunix_scm",(void*)f_5040},
{"f_4979:posixunix_scm",(void*)f_4979},
{"f_5012:posixunix_scm",(void*)f_5012},
{"f_5000:posixunix_scm",(void*)f_5000},
{"f_5008:posixunix_scm",(void*)f_5008},
{"f_5004:posixunix_scm",(void*)f_5004},
{"f_4960:posixunix_scm",(void*)f_4960},
{"f_4970:posixunix_scm",(void*)f_4970},
{"f_4964:posixunix_scm",(void*)f_4964},
{"f_4954:posixunix_scm",(void*)f_4954},
{"f_4948:posixunix_scm",(void*)f_4948},
{"f_4942:posixunix_scm",(void*)f_4942},
{"f_4918:posixunix_scm",(void*)f_4918},
{"f_4940:posixunix_scm",(void*)f_4940},
{"f_4936:posixunix_scm",(void*)f_4936},
{"f_4928:posixunix_scm",(void*)f_4928},
{"f_4888:posixunix_scm",(void*)f_4888},
{"f_4916:posixunix_scm",(void*)f_4916},
{"f_4912:posixunix_scm",(void*)f_4912},
{"f_4861:posixunix_scm",(void*)f_4861},
{"f_4886:posixunix_scm",(void*)f_4886},
{"f_4882:posixunix_scm",(void*)f_4882},
{"f_4797:posixunix_scm",(void*)f_4797},
{"f_4793:posixunix_scm",(void*)f_4793},
{"f_4813:posixunix_scm",(void*)f_4813},
{"f_4731:posixunix_scm",(void*)f_4731},
{"f_4735:posixunix_scm",(void*)f_4735},
{"f_4740:posixunix_scm",(void*)f_4740},
{"f_4756:posixunix_scm",(void*)f_4756},
{"f_4668:posixunix_scm",(void*)f_4668},
{"f_4726:posixunix_scm",(void*)f_4726},
{"f_4672:posixunix_scm",(void*)f_4672},
{"f_4675:posixunix_scm",(void*)f_4675},
{"f_4707:posixunix_scm",(void*)f_4707},
{"f_4678:posixunix_scm",(void*)f_4678},
{"f_4683:posixunix_scm",(void*)f_4683},
{"f_4697:posixunix_scm",(void*)f_4697},
{"f_4590:posixunix_scm",(void*)f_4590},
{"f_4648:posixunix_scm",(void*)f_4648},
{"f_4597:posixunix_scm",(void*)f_4597},
{"f_4607:posixunix_scm",(void*)f_4607},
{"f_4611:posixunix_scm",(void*)f_4611},
{"f_4620:posixunix_scm",(void*)f_4620},
{"f_4624:posixunix_scm",(void*)f_4624},
{"f_4634:posixunix_scm",(void*)f_4634},
{"f_4615:posixunix_scm",(void*)f_4615},
{"f_4570:posixunix_scm",(void*)f_4570},
{"f_4582:posixunix_scm",(void*)f_4582},
{"f_4578:posixunix_scm",(void*)f_4578},
{"f_4556:posixunix_scm",(void*)f_4556},
{"f_4568:posixunix_scm",(void*)f_4568},
{"f_4564:posixunix_scm",(void*)f_4564},
{"f_4496:posixunix_scm",(void*)f_4496},
{"f_4542:posixunix_scm",(void*)f_4542},
{"f_4503:posixunix_scm",(void*)f_4503},
{"f_4513:posixunix_scm",(void*)f_4513},
{"f_4517:posixunix_scm",(void*)f_4517},
{"f_4521:posixunix_scm",(void*)f_4521},
{"f_4525:posixunix_scm",(void*)f_4525},
{"f_4529:posixunix_scm",(void*)f_4529},
{"f_4442:posixunix_scm",(void*)f_4442},
{"f_4475:posixunix_scm",(void*)f_4475},
{"f_4446:posixunix_scm",(void*)f_4446},
{"f_4453:posixunix_scm",(void*)f_4453},
{"f_4457:posixunix_scm",(void*)f_4457},
{"f_4461:posixunix_scm",(void*)f_4461},
{"f_4465:posixunix_scm",(void*)f_4465},
{"f_4469:posixunix_scm",(void*)f_4469},
{"f_4424:posixunix_scm",(void*)f_4424},
{"f_4409:posixunix_scm",(void*)f_4409},
{"f_4403:posixunix_scm",(void*)f_4403},
{"f_4371:posixunix_scm",(void*)f_4371},
{"f_4377:posixunix_scm",(void*)f_4377},
{"f_4331:posixunix_scm",(void*)f_4331},
{"f_4349:posixunix_scm",(void*)f_4349},
{"f_4313:posixunix_scm",(void*)f_4313},
{"f_4323:posixunix_scm",(void*)f_4323},
{"f_4300:posixunix_scm",(void*)f_4300},
{"f_4291:posixunix_scm",(void*)f_4291},
{"f_4244:posixunix_scm",(void*)f_4244},
{"f_4248:posixunix_scm",(void*)f_4248},
{"f_4224:posixunix_scm",(void*)f_4224},
{"f_4228:posixunix_scm",(void*)f_4228},
{"f_4234:posixunix_scm",(void*)f_4234},
{"f_4238:posixunix_scm",(void*)f_4238},
{"f_4204:posixunix_scm",(void*)f_4204},
{"f_4208:posixunix_scm",(void*)f_4208},
{"f_4214:posixunix_scm",(void*)f_4214},
{"f_4218:posixunix_scm",(void*)f_4218},
{"f_4180:posixunix_scm",(void*)f_4180},
{"f_4184:posixunix_scm",(void*)f_4184},
{"f_4195:posixunix_scm",(void*)f_4195},
{"f_4199:posixunix_scm",(void*)f_4199},
{"f_4189:posixunix_scm",(void*)f_4189},
{"f_4156:posixunix_scm",(void*)f_4156},
{"f_4160:posixunix_scm",(void*)f_4160},
{"f_4171:posixunix_scm",(void*)f_4171},
{"f_4175:posixunix_scm",(void*)f_4175},
{"f_4165:posixunix_scm",(void*)f_4165},
{"f_4140:posixunix_scm",(void*)f_4140},
{"f_4144:posixunix_scm",(void*)f_4144},
{"f_4147:posixunix_scm",(void*)f_4147},
{"f_4104:posixunix_scm",(void*)f_4104},
{"f_4135:posixunix_scm",(void*)f_4135},
{"f_4125:posixunix_scm",(void*)f_4125},
{"f_4118:posixunix_scm",(void*)f_4118},
{"f_4068:posixunix_scm",(void*)f_4068},
{"f_4099:posixunix_scm",(void*)f_4099},
{"f_4089:posixunix_scm",(void*)f_4089},
{"f_4082:posixunix_scm",(void*)f_4082},
{"f_4053:posixunix_scm",(void*)f_4053},
{"f_4066:posixunix_scm",(void*)f_4066},
{"f_4047:posixunix_scm",(void*)f_4047},
{"f_3718:posixunix_scm",(void*)f_3718},
{"f_4025:posixunix_scm",(void*)f_4025},
{"f_3845:posixunix_scm",(void*)f_3845},
{"f_4011:posixunix_scm",(void*)f_4011},
{"f_4000:posixunix_scm",(void*)f_4000},
{"f_4007:posixunix_scm",(void*)f_4007},
{"f_3864:posixunix_scm",(void*)f_3864},
{"f_3993:posixunix_scm",(void*)f_3993},
{"f_3972:posixunix_scm",(void*)f_3972},
{"f_3989:posixunix_scm",(void*)f_3989},
{"f_3978:posixunix_scm",(void*)f_3978},
{"f_3985:posixunix_scm",(void*)f_3985},
{"f_3908:posixunix_scm",(void*)f_3908},
{"f_3969:posixunix_scm",(void*)f_3969},
{"f_3948:posixunix_scm",(void*)f_3948},
{"f_3965:posixunix_scm",(void*)f_3965},
{"f_3954:posixunix_scm",(void*)f_3954},
{"f_3961:posixunix_scm",(void*)f_3961},
{"f_3921:posixunix_scm",(void*)f_3921},
{"f_3945:posixunix_scm",(void*)f_3945},
{"f_3941:posixunix_scm",(void*)f_3941},
{"f_3902:posixunix_scm",(void*)f_3902},
{"f_3871:posixunix_scm",(void*)f_3871},
{"f_3889:posixunix_scm",(void*)f_3889},
{"f_3874:posixunix_scm",(void*)f_3874},
{"f_3878:posixunix_scm",(void*)f_3878},
{"f_3858:posixunix_scm",(void*)f_3858},
{"f_3839:posixunix_scm",(void*)f_3839},
{"f_3725:posixunix_scm",(void*)f_3725},
{"f_3732:posixunix_scm",(void*)f_3732},
{"f_3734:posixunix_scm",(void*)f_3734},
{"f_3741:posixunix_scm",(void*)f_3741},
{"f_3805:posixunix_scm",(void*)f_3805},
{"f_3814:posixunix_scm",(void*)f_3814},
{"f_3802:posixunix_scm",(void*)f_3802},
{"f_3747:posixunix_scm",(void*)f_3747},
{"f_3783:posixunix_scm",(void*)f_3783},
{"f_3779:posixunix_scm",(void*)f_3779},
{"f_3775:posixunix_scm",(void*)f_3775},
{"f_3764:posixunix_scm",(void*)f_3764},
{"f_3760:posixunix_scm",(void*)f_3760},
{"f_3662:posixunix_scm",(void*)f_3662},
{"f_3671:posixunix_scm",(void*)f_3671},
{"f_3695:posixunix_scm",(void*)f_3695},
{"f_3707:posixunix_scm",(void*)f_3707},
{"f_3713:posixunix_scm",(void*)f_3713},
{"f_3701:posixunix_scm",(void*)f_3701},
{"f_3677:posixunix_scm",(void*)f_3677},
{"f_3683:posixunix_scm",(void*)f_3683},
{"f_3669:posixunix_scm",(void*)f_3669},
{"f_3646:posixunix_scm",(void*)f_3646},
{"f_3605:posixunix_scm",(void*)f_3605},
{"f_3618:posixunix_scm",(void*)f_3618},
{"f_3585:posixunix_scm",(void*)f_3585},
{"f_3592:posixunix_scm",(void*)f_3592},
{"f_3603:posixunix_scm",(void*)f_3603},
{"f_3431:posixunix_scm",(void*)f_3431},
{"f_3536:posixunix_scm",(void*)f_3536},
{"f_3544:posixunix_scm",(void*)f_3544},
{"f_3531:posixunix_scm",(void*)f_3531},
{"f_3433:posixunix_scm",(void*)f_3433},
{"f_3440:posixunix_scm",(void*)f_3440},
{"f_3443:posixunix_scm",(void*)f_3443},
{"f_3446:posixunix_scm",(void*)f_3446},
{"f_3530:posixunix_scm",(void*)f_3530},
{"f_3450:posixunix_scm",(void*)f_3450},
{"f_3464:posixunix_scm",(void*)f_3464},
{"f_3474:posixunix_scm",(void*)f_3474},
{"f_3477:posixunix_scm",(void*)f_3477},
{"f_3480:posixunix_scm",(void*)f_3480},
{"f_3486:posixunix_scm",(void*)f_3486},
{"f_3496:posixunix_scm",(void*)f_3496},
{"f_3407:posixunix_scm",(void*)f_3407},
{"f_3429:posixunix_scm",(void*)f_3429},
{"f_3425:posixunix_scm",(void*)f_3425},
{"f_3383:posixunix_scm",(void*)f_3383},
{"f_3405:posixunix_scm",(void*)f_3405},
{"f_3401:posixunix_scm",(void*)f_3401},
{"f_3251:posixunix_scm",(void*)f_3251},
{"f_3261:posixunix_scm",(void*)f_3261},
{"f_3365:posixunix_scm",(void*)f_3365},
{"f_3270:posixunix_scm",(void*)f_3270},
{"f_3354:posixunix_scm",(void*)f_3354},
{"f_3333:posixunix_scm",(void*)f_3333},
{"f_3327:posixunix_scm",(void*)f_3327},
{"f_3280:posixunix_scm",(void*)f_3280},
{"f_3282:posixunix_scm",(void*)f_3282},
{"f_3325:posixunix_scm",(void*)f_3325},
{"f_3289:posixunix_scm",(void*)f_3289},
{"f_3310:posixunix_scm",(void*)f_3310},
{"f_3292:posixunix_scm",(void*)f_3292},
{"f_3306:posixunix_scm",(void*)f_3306},
{"f_3189:posixunix_scm",(void*)f_3189},
{"f_3202:posixunix_scm",(void*)f_3202},
{"f_3214:posixunix_scm",(void*)f_3214},
{"f_3208:posixunix_scm",(void*)f_3208},
{"f_3179:posixunix_scm",(void*)f_3179},
{"f_3186:posixunix_scm",(void*)f_3186},
{"f_3168:posixunix_scm",(void*)f_3168},
{"f_3175:posixunix_scm",(void*)f_3175},
{"f_3158:posixunix_scm",(void*)f_3158},
{"f_3165:posixunix_scm",(void*)f_3165},
{"f_3148:posixunix_scm",(void*)f_3148},
{"f_3155:posixunix_scm",(void*)f_3155},
{"f_3139:posixunix_scm",(void*)f_3139},
{"f_3146:posixunix_scm",(void*)f_3146},
{"f_3130:posixunix_scm",(void*)f_3130},
{"f_3137:posixunix_scm",(void*)f_3137},
{"f_3121:posixunix_scm",(void*)f_3121},
{"f_3128:posixunix_scm",(void*)f_3128},
{"f_3112:posixunix_scm",(void*)f_3112},
{"f_3119:posixunix_scm",(void*)f_3119},
{"f_3106:posixunix_scm",(void*)f_3106},
{"f_3110:posixunix_scm",(void*)f_3110},
{"f_3100:posixunix_scm",(void*)f_3100},
{"f_3104:posixunix_scm",(void*)f_3104},
{"f_3094:posixunix_scm",(void*)f_3094},
{"f_3098:posixunix_scm",(void*)f_3098},
{"f_3088:posixunix_scm",(void*)f_3088},
{"f_3092:posixunix_scm",(void*)f_3092},
{"f_3082:posixunix_scm",(void*)f_3082},
{"f_3086:posixunix_scm",(void*)f_3086},
{"f_3076:posixunix_scm",(void*)f_3076},
{"f_3080:posixunix_scm",(void*)f_3080},
{"f_3051:posixunix_scm",(void*)f_3051},
{"f_3055:posixunix_scm",(void*)f_3055},
{"f_3014:posixunix_scm",(void*)f_3014},
{"f_3046:posixunix_scm",(void*)f_3046},
{"f_3039:posixunix_scm",(void*)f_3039},
{"f_3018:posixunix_scm",(void*)f_3018},
{"f_2758:posixunix_scm",(void*)f_2758},
{"f_2979:posixunix_scm",(void*)f_2979},
{"f_2774:posixunix_scm",(void*)f_2774},
{"f_2937:posixunix_scm",(void*)f_2937},
{"f_2780:posixunix_scm",(void*)f_2780},
{"f_2783:posixunix_scm",(void*)f_2783},
{"f_2881:posixunix_scm",(void*)f_2881},
{"f_2894:posixunix_scm",(void*)f_2894},
{"f_2879:posixunix_scm",(void*)f_2879},
{"f_2822:posixunix_scm",(void*)f_2822},
{"f_2840:posixunix_scm",(void*)f_2840},
{"f_2853:posixunix_scm",(void*)f_2853},
{"f_2838:posixunix_scm",(void*)f_2838},
{"f_2826:posixunix_scm",(void*)f_2826},
{"f_2720:posixunix_scm",(void*)f_2720},
{"f_2727:posixunix_scm",(void*)f_2727},
{"f_2733:posixunix_scm",(void*)f_2733},
{"f_2740:posixunix_scm",(void*)f_2740},
{"f_2681:posixunix_scm",(void*)f_2681},
{"f_2688:posixunix_scm",(void*)f_2688},
{"f_2697:posixunix_scm",(void*)f_2697},
{"f_2639:posixunix_scm",(void*)f_2639},
{"f_2649:posixunix_scm",(void*)f_2649},
{"f_2652:posixunix_scm",(void*)f_2652},
{"f_2655:posixunix_scm",(void*)f_2655},
{"f_2624:posixunix_scm",(void*)f_2624},
{"f_2586:posixunix_scm",(void*)f_2586},
{"f_2616:posixunix_scm",(void*)f_2616},
{"f_2603:posixunix_scm",(void*)f_2603},
{"f_2606:posixunix_scm",(void*)f_2606},
{"f_2547:posixunix_scm",(void*)f_2547},
{"f_2506:posixunix_scm",(void*)f_2506},
{"f_2503:posixunix_scm",(void*)f_2503},
{"f_2485:posixunix_scm",(void*)f_2485},
{"f_2489:posixunix_scm",(void*)f_2489},
{"f_2500:posixunix_scm",(void*)f_2500},
{"f_2496:posixunix_scm",(void*)f_2496},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
