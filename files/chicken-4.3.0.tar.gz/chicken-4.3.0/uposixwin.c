/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:03
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: posixwin.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file uposixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

/* It is assumed that 'int' is-a 'long' */
#define C_ftell(p)          C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_num_to_int(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set(v) (C_tm_set_08(v), &C_tm)

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[397];
static double C_possibly_force_alignment;


/* from k4687 */
static C_word C_fcall stub969(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub969(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from current-process-id in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static C_word C_fcall stub944(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub944(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k4329 */
static C_word C_fcall stub818(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub818(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k4323 */
static C_word C_fcall stub808(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub808(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from ex0 */
static C_word C_fcall stub707(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub707(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub702(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub702(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (_daylight ? _tzname[1] : _tzname[0]);
return(z);
C_ret:
#undef return

return C_r;}

/* from strftime */
static C_word C_fcall stub673(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub673(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub667(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub667(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub647(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub647(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from get */
static C_word C_fcall stub600(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub600(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from strerror */
static C_word C_fcall stub12(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub12(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5667)
static void C_ccall f_5667(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5683)
static void C_ccall f_5683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5674)
static void C_ccall f_5674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5648)
static void C_ccall f_5648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5584)
static void C_ccall f_5584(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5482)
static void C_ccall f_5482(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5434)
static void C_ccall f_5434(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5320)
static void C_fcall f_5320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5315)
static void C_fcall f_5315(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5310)
static void C_fcall f_5310(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5171)
static void C_fcall f_5171(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5178)
static void C_fcall f_5178(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_fcall f_5190(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5224)
static void C_ccall f_5224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5253)
static void C_ccall f_5253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5234)
static void C_ccall f_5234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5149)
static void C_ccall f_5149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5142)
static void C_ccall f_5142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5146)
static void C_ccall f_5146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5111)
static void C_ccall f_5111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5085)
static void C_ccall f_5085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4979)
static void C_fcall f_4979(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_fcall f_4974(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4969)
static void C_fcall f_4969(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4964)
static void C_fcall f_4964(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4902)
static void C_fcall f_4902(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4897)
static void C_fcall f_4897(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4892)
static void C_fcall f_4892(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4887)
static void C_fcall f_4887(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4807)
static void C_fcall f_4807(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_fcall f_4844(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4809)
static C_word C_fcall f_4809(C_word t0,C_word t1);
C_noret_decl(f_4818)
static C_word C_fcall f_4818(C_word t0,C_word t1);
C_noret_decl(f_4711)
static void C_ccall f_4711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4770)
static void C_ccall f_4770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4541)
static void C_fcall f_4541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4536)
static void C_fcall f_4536(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4531)
static void C_fcall f_4531(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4519)
static void C_fcall f_4519(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4457)
static void C_fcall f_4457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_fcall f_4452(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4447)
static void C_fcall f_4447(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4435)
static void C_fcall f_4435(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_fcall f_4418(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_fcall f_4382(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_fcall f_4332(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4344)
static void C_fcall f_4344(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4241)
static void C_fcall f_4241(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4284)
static void C_fcall f_4284(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_fcall f_4246(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_fcall f_4255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4135)
static void C_fcall f_4135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_fcall f_4172(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3914)
static void C_ccall f_3914(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3914)
static void C_ccall f_3914r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_fcall f_3836(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3776)
static void C_fcall f_3776(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_fcall f_3788(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3715)
static void C_fcall f_3715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3627)
static void C_fcall f_3627(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_fcall f_3590(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3545)
static void C_fcall f_3545(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3348)
static void C_ccall f_3348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3348)
static void C_ccall f_3348r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3352)
static void C_ccall f_3352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3342)
static void C_ccall f_3342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3171)
static void C_fcall f_3171(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3165)
static void C_fcall f_3165(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_fcall f_2942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_fcall f_2972(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3014)
static void C_fcall f_3014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_fcall f_2812(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2891)
static void C_fcall f_2891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_fcall f_2740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_fcall f_2724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2604)
static void C_fcall f_2604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_fcall f_2599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2498)
static void C_fcall f_2498(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_fcall f_2532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_fcall f_2554(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_ccall f_2339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_fcall f_2351(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_fcall f_2378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2387)
static void C_ccall f_2387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_fcall f_2212(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_fcall f_2086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_5320)
static void C_fcall trf_5320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5320(t0,t1);}

C_noret_decl(trf_5315)
static void C_fcall trf_5315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5315(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5315(t0,t1,t2);}

C_noret_decl(trf_5310)
static void C_fcall trf_5310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5310(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5310(t0,t1,t2,t3);}

C_noret_decl(trf_5171)
static void C_fcall trf_5171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5171(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5171(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5178)
static void C_fcall trf_5178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5178(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5178(t0,t1);}

C_noret_decl(trf_5190)
static void C_fcall trf_5190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5190(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5190(t0,t1,t2,t3);}

C_noret_decl(trf_4979)
static void C_fcall trf_4979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4979(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4979(t0,t1);}

C_noret_decl(trf_4974)
static void C_fcall trf_4974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4974(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4974(t0,t1,t2);}

C_noret_decl(trf_4969)
static void C_fcall trf_4969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4969(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4969(t0,t1,t2,t3);}

C_noret_decl(trf_4964)
static void C_fcall trf_4964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4964(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4964(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4902)
static void C_fcall trf_4902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4902(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4902(t0,t1);}

C_noret_decl(trf_4897)
static void C_fcall trf_4897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4897(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4897(t0,t1,t2);}

C_noret_decl(trf_4892)
static void C_fcall trf_4892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4892(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4892(t0,t1,t2,t3);}

C_noret_decl(trf_4887)
static void C_fcall trf_4887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4887(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4887(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4807)
static void C_fcall trf_4807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4807(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4807(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4844)
static void C_fcall trf_4844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4844(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4844(t0,t1);}

C_noret_decl(trf_4541)
static void C_fcall trf_4541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4541(t0,t1);}

C_noret_decl(trf_4536)
static void C_fcall trf_4536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4536(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4536(t0,t1,t2);}

C_noret_decl(trf_4531)
static void C_fcall trf_4531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4531(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4531(t0,t1,t2,t3);}

C_noret_decl(trf_4519)
static void C_fcall trf_4519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4519(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4519(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4457)
static void C_fcall trf_4457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4457(t0,t1);}

C_noret_decl(trf_4452)
static void C_fcall trf_4452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4452(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4452(t0,t1,t2);}

C_noret_decl(trf_4447)
static void C_fcall trf_4447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4447(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4447(t0,t1,t2,t3);}

C_noret_decl(trf_4435)
static void C_fcall trf_4435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4435(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4435(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4418)
static void C_fcall trf_4418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4418(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4418(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4382)
static void C_fcall trf_4382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4382(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4382(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4332)
static void C_fcall trf_4332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4332(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4332(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4344)
static void C_fcall trf_4344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4344(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4344(t0,t1,t2,t3);}

C_noret_decl(trf_4241)
static void C_fcall trf_4241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4241(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4241(t0,t1,t2,t3);}

C_noret_decl(trf_4284)
static void C_fcall trf_4284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4284(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4284(t0,t1,t2,t3);}

C_noret_decl(trf_4246)
static void C_fcall trf_4246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4246(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4246(t0,t1,t2);}

C_noret_decl(trf_4255)
static void C_fcall trf_4255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4255(t0,t1,t2);}

C_noret_decl(trf_4135)
static void C_fcall trf_4135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4135(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4135(t0,t1,t2);}

C_noret_decl(trf_4172)
static void C_fcall trf_4172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4172(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4172(t0,t1,t2);}

C_noret_decl(trf_3836)
static void C_fcall trf_3836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3836(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3836(t0,t1,t2);}

C_noret_decl(trf_3776)
static void C_fcall trf_3776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3776(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3776(t0,t1,t2);}

C_noret_decl(trf_3788)
static void C_fcall trf_3788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3788(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3788(t0,t1,t2);}

C_noret_decl(trf_3715)
static void C_fcall trf_3715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3715(t0,t1);}

C_noret_decl(trf_3627)
static void C_fcall trf_3627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3627(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3627(t0,t1,t2,t3);}

C_noret_decl(trf_3590)
static void C_fcall trf_3590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3590(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3590(t0,t1,t2);}

C_noret_decl(trf_3545)
static void C_fcall trf_3545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3545(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3545(t0,t1,t2,t3);}

C_noret_decl(trf_3171)
static void C_fcall trf_3171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3171(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3171(t0,t1,t2,t3);}

C_noret_decl(trf_3165)
static void C_fcall trf_3165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3165(t0,t1);}

C_noret_decl(trf_2942)
static void C_fcall trf_2942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2942(t0,t1);}

C_noret_decl(trf_2972)
static void C_fcall trf_2972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2972(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2972(t0,t1);}

C_noret_decl(trf_3014)
static void C_fcall trf_3014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3014(t0,t1);}

C_noret_decl(trf_2812)
static void C_fcall trf_2812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2812(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2812(t0,t1,t2,t3);}

C_noret_decl(trf_2891)
static void C_fcall trf_2891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2891(t0,t1);}

C_noret_decl(trf_2740)
static void C_fcall trf_2740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2740(t0,t1);}

C_noret_decl(trf_2724)
static void C_fcall trf_2724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2724(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2724(t0,t1);}

C_noret_decl(trf_2604)
static void C_fcall trf_2604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2604(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2604(t0,t1);}

C_noret_decl(trf_2599)
static void C_fcall trf_2599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2599(t0,t1,t2);}

C_noret_decl(trf_2498)
static void C_fcall trf_2498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2498(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2498(t0,t1,t2,t3);}

C_noret_decl(trf_2532)
static void C_fcall trf_2532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2532(t0,t1);}

C_noret_decl(trf_2554)
static void C_fcall trf_2554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2554(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2554(t0,t1);}

C_noret_decl(trf_2351)
static void C_fcall trf_2351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2351(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2351(t0,t1,t2);}

C_noret_decl(trf_2378)
static void C_fcall trf_2378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2378(t0,t1);}

C_noret_decl(trf_2212)
static void C_fcall trf_2212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2212(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2212(t0,t1);}

C_noret_decl(trf_2086)
static void C_fcall trf_2086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2086(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr9rv)
static void C_fcall tr9rv(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9rv(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n+1);
t9=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3130)){
C_save(t1);
C_rereclaim2(3130*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,397);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000/this function is not available on this platform");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],8,"pipe/buf");
lf[10]=C_h_intern(&lf[10],11,"open/rdonly");
lf[11]=C_h_intern(&lf[11],11,"open/wronly");
lf[12]=C_h_intern(&lf[12],9,"open/rdwr");
lf[13]=C_h_intern(&lf[13],9,"open/read");
lf[14]=C_h_intern(&lf[14],10,"open/write");
lf[15]=C_h_intern(&lf[15],10,"open/creat");
lf[16]=C_h_intern(&lf[16],11,"open/append");
lf[17]=C_h_intern(&lf[17],9,"open/excl");
lf[18]=C_h_intern(&lf[18],10,"open/trunc");
lf[19]=C_h_intern(&lf[19],11,"open/binary");
lf[20]=C_h_intern(&lf[20],9,"open/text");
lf[21]=C_h_intern(&lf[21],14,"open/noinherit");
lf[22]=C_h_intern(&lf[22],10,"perm/irusr");
lf[23]=C_h_intern(&lf[23],10,"perm/iwusr");
lf[24]=C_h_intern(&lf[24],10,"perm/ixusr");
lf[25]=C_h_intern(&lf[25],10,"perm/irgrp");
lf[26]=C_h_intern(&lf[26],10,"perm/iwgrp");
lf[27]=C_h_intern(&lf[27],10,"perm/ixgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iroth");
lf[29]=C_h_intern(&lf[29],10,"perm/iwoth");
lf[30]=C_h_intern(&lf[30],10,"perm/ixoth");
lf[31]=C_h_intern(&lf[31],10,"perm/irwxu");
lf[32]=C_h_intern(&lf[32],10,"perm/irwxg");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxo");
lf[34]=C_h_intern(&lf[34],9,"file-open");
lf[35]=C_h_intern(&lf[35],11,"\000file-error");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[37]=C_h_intern(&lf[37],17,"\003sysmake-c-string");
lf[38]=C_h_intern(&lf[38],20,"\003sysexpand-home-path");
lf[39]=C_h_intern(&lf[39],10,"file-close");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[41]=C_h_intern(&lf[41],11,"make-string");
lf[42]=C_h_intern(&lf[42],9,"file-read");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[44]=C_h_intern(&lf[44],11,"\000type-error");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[46]=C_h_intern(&lf[46],10,"file-write");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[49]=C_h_intern(&lf[49],13,"string-length");
lf[50]=C_h_intern(&lf[50],12,"file-mkstemp");
lf[51]=C_h_intern(&lf[51],13,"\003syssubstring");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[53]=C_h_intern(&lf[53],8,"seek/set");
lf[54]=C_h_intern(&lf[54],8,"seek/end");
lf[55]=C_h_intern(&lf[55],8,"seek/cur");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[59]=C_h_intern(&lf[59],9,"file-stat");
lf[60]=C_h_intern(&lf[60],9,"file-size");
lf[61]=C_h_intern(&lf[61],22,"file-modification-time");
lf[62]=C_h_intern(&lf[62],16,"file-access-time");
lf[63]=C_h_intern(&lf[63],16,"file-change-time");
lf[64]=C_h_intern(&lf[64],10,"file-owner");
lf[65]=C_h_intern(&lf[65],16,"file-permissions");
lf[66]=C_h_intern(&lf[66],13,"regular-file\077");
lf[67]=C_h_intern(&lf[67],13,"\003sysfile-info");
lf[68]=C_h_intern(&lf[68],14,"symbolic-link\077");
lf[69]=C_h_intern(&lf[69],13,"stat-regular\077");
lf[70]=C_h_intern(&lf[70],15,"stat-directory\077");
lf[71]=C_h_intern(&lf[71],12,"stat-device\077");
lf[72]=C_h_intern(&lf[72],17,"character-device\077");
lf[73]=C_h_intern(&lf[73],13,"block-device\077");
lf[74]=C_h_intern(&lf[74],18,"stat-block-device\077");
lf[75]=C_h_intern(&lf[75],10,"stat-fifo\077");
lf[76]=C_h_intern(&lf[76],5,"fifo\077");
lf[77]=C_h_intern(&lf[77],13,"stat-symlink\077");
lf[78]=C_h_intern(&lf[78],7,"socket\077");
lf[79]=C_h_intern(&lf[79],12,"stat-socket\077");
lf[80]=C_h_intern(&lf[80],18,"set-file-position!");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[82]=C_h_intern(&lf[82],6,"stream");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[84]=C_h_intern(&lf[84],5,"port\077");
lf[85]=C_h_intern(&lf[85],13,"\000bounds-error");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[87]=C_h_intern(&lf[87],13,"file-position");
lf[88]=C_h_intern(&lf[88],16,"create-directory");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[90]=C_h_intern(&lf[90],12,"file-exists\077");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[92]=C_h_intern(&lf[92],12,"string-split");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[94]=C_h_intern(&lf[94],16,"change-directory");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[96]=C_h_intern(&lf[96],16,"delete-directory");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[98]=C_h_intern(&lf[98],6,"string");
lf[99]=C_h_intern(&lf[99],9,"directory");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[101]=C_h_intern(&lf[101],16,"\003sysmake-pointer");
lf[102]=C_h_intern(&lf[102],17,"current-directory");
lf[103]=C_h_intern(&lf[103],10,"directory\077");
lf[104]=C_h_intern(&lf[104],27,"\003sysplatform-fixup-pathname");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[106]=C_h_intern(&lf[106],5,"null\077");
lf[107]=C_h_intern(&lf[107],6,"char=\077");
lf[108]=C_h_intern(&lf[108],8,"string=\077");
lf[109]=C_h_intern(&lf[109],16,"char-alphabetic\077");
lf[110]=C_h_intern(&lf[110],10,"string-ref");
lf[111]=C_h_intern(&lf[111],18,"string-intersperse");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[113]=C_h_intern(&lf[113],17,"current-user-name");
lf[114]=C_h_intern(&lf[114],9,"condition");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\003c:\134");
lf[116]=C_h_intern(&lf[116],22,"with-exception-handler");
lf[117]=C_h_intern(&lf[117],30,"call-with-current-continuation");
lf[118]=C_h_intern(&lf[118],14,"canonical-path");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[120]=C_h_intern(&lf[120],7,"reverse");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\027Documents and Settings\134");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[130]=C_h_intern(&lf[130],9,"\003syserror");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[133]=C_h_intern(&lf[133],13,"\003sysmake-port");
lf[134]=C_h_intern(&lf[134],21,"\003sysstream-port-class");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[136]=C_h_intern(&lf[136],15,"open-input-pipe");
lf[137]=C_h_intern(&lf[137],5,"\000text");
lf[138]=C_h_intern(&lf[138],7,"\000binary");
lf[139]=C_h_intern(&lf[139],16,"open-output-pipe");
lf[140]=C_h_intern(&lf[140],16,"close-input-pipe");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[142]=C_h_intern(&lf[142],14,"\003syscheck-port");
lf[143]=C_h_intern(&lf[143],17,"close-output-pipe");
lf[144]=C_h_intern(&lf[144],20,"call-with-input-pipe");
lf[145]=C_h_intern(&lf[145],21,"call-with-output-pipe");
lf[146]=C_h_intern(&lf[146],20,"with-input-from-pipe");
lf[147]=C_h_intern(&lf[147],18,"\003sysstandard-input");
lf[148]=C_h_intern(&lf[148],19,"with-output-to-pipe");
lf[149]=C_h_intern(&lf[149],19,"\003sysstandard-output");
lf[150]=C_h_intern(&lf[150],11,"create-pipe");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[152]=C_h_intern(&lf[152],11,"signal/term");
lf[153]=C_h_intern(&lf[153],10,"signal/int");
lf[154]=C_h_intern(&lf[154],10,"signal/fpe");
lf[155]=C_h_intern(&lf[155],10,"signal/ill");
lf[156]=C_h_intern(&lf[156],11,"signal/segv");
lf[157]=C_h_intern(&lf[157],11,"signal/abrt");
lf[158]=C_h_intern(&lf[158],12,"signal/break");
lf[159]=C_h_intern(&lf[159],11,"signal/alrm");
lf[160]=C_h_intern(&lf[160],11,"signal/chld");
lf[161]=C_h_intern(&lf[161],11,"signal/cont");
lf[162]=C_h_intern(&lf[162],10,"signal/hup");
lf[163]=C_h_intern(&lf[163],9,"signal/io");
lf[164]=C_h_intern(&lf[164],11,"signal/kill");
lf[165]=C_h_intern(&lf[165],11,"signal/pipe");
lf[166]=C_h_intern(&lf[166],11,"signal/prof");
lf[167]=C_h_intern(&lf[167],11,"signal/quit");
lf[168]=C_h_intern(&lf[168],11,"signal/stop");
lf[169]=C_h_intern(&lf[169],11,"signal/trap");
lf[170]=C_h_intern(&lf[170],11,"signal/tstp");
lf[171]=C_h_intern(&lf[171],10,"signal/urg");
lf[172]=C_h_intern(&lf[172],11,"signal/usr1");
lf[173]=C_h_intern(&lf[173],11,"signal/usr2");
lf[174]=C_h_intern(&lf[174],13,"signal/vtalrm");
lf[175]=C_h_intern(&lf[175],12,"signal/winch");
lf[176]=C_h_intern(&lf[176],11,"signal/xcpu");
lf[177]=C_h_intern(&lf[177],11,"signal/xfsz");
lf[178]=C_h_intern(&lf[178],12,"signals-list");
lf[179]=C_h_intern(&lf[179],18,"\003sysinterrupt-hook");
lf[180]=C_h_intern(&lf[180],14,"signal-handler");
lf[181]=C_h_intern(&lf[181],19,"set-signal-handler!");
lf[182]=C_h_intern(&lf[182],10,"errno/perm");
lf[183]=C_h_intern(&lf[183],11,"errno/noent");
lf[184]=C_h_intern(&lf[184],10,"errno/srch");
lf[185]=C_h_intern(&lf[185],10,"errno/intr");
lf[186]=C_h_intern(&lf[186],8,"errno/io");
lf[187]=C_h_intern(&lf[187],12,"errno/noexec");
lf[188]=C_h_intern(&lf[188],10,"errno/badf");
lf[189]=C_h_intern(&lf[189],11,"errno/child");
lf[190]=C_h_intern(&lf[190],11,"errno/nomem");
lf[191]=C_h_intern(&lf[191],11,"errno/acces");
lf[192]=C_h_intern(&lf[192],11,"errno/fault");
lf[193]=C_h_intern(&lf[193],10,"errno/busy");
lf[194]=C_h_intern(&lf[194],11,"errno/exist");
lf[195]=C_h_intern(&lf[195],12,"errno/notdir");
lf[196]=C_h_intern(&lf[196],11,"errno/isdir");
lf[197]=C_h_intern(&lf[197],11,"errno/inval");
lf[198]=C_h_intern(&lf[198],11,"errno/mfile");
lf[199]=C_h_intern(&lf[199],11,"errno/nospc");
lf[200]=C_h_intern(&lf[200],11,"errno/spipe");
lf[201]=C_h_intern(&lf[201],10,"errno/pipe");
lf[202]=C_h_intern(&lf[202],11,"errno/again");
lf[203]=C_h_intern(&lf[203],10,"errno/rofs");
lf[204]=C_h_intern(&lf[204],10,"errno/nxio");
lf[205]=C_h_intern(&lf[205],10,"errno/2big");
lf[206]=C_h_intern(&lf[206],10,"errno/xdev");
lf[207]=C_h_intern(&lf[207],11,"errno/nodev");
lf[208]=C_h_intern(&lf[208],11,"errno/nfile");
lf[209]=C_h_intern(&lf[209],11,"errno/notty");
lf[210]=C_h_intern(&lf[210],10,"errno/fbig");
lf[211]=C_h_intern(&lf[211],11,"errno/mlink");
lf[212]=C_h_intern(&lf[212],9,"errno/dom");
lf[213]=C_h_intern(&lf[213],11,"errno/range");
lf[214]=C_h_intern(&lf[214],12,"errno/deadlk");
lf[215]=C_h_intern(&lf[215],17,"errno/nametoolong");
lf[216]=C_h_intern(&lf[216],11,"errno/nolck");
lf[217]=C_h_intern(&lf[217],11,"errno/nosys");
lf[218]=C_h_intern(&lf[218],14,"errno/notempty");
lf[219]=C_h_intern(&lf[219],11,"errno/ilseq");
lf[220]=C_h_intern(&lf[220],16,"change-file-mode");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[222]=C_h_intern(&lf[222],17,"file-read-access\077");
lf[223]=C_h_intern(&lf[223],18,"file-write-access\077");
lf[224]=C_h_intern(&lf[224],20,"file-execute-access\077");
lf[225]=C_h_intern(&lf[225],12,"fileno/stdin");
lf[226]=C_h_intern(&lf[226],13,"fileno/stdout");
lf[227]=C_h_intern(&lf[227],13,"fileno/stderr");
lf[228]=C_h_intern(&lf[228],7,"\000append");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[236]=C_h_intern(&lf[236],16,"open-input-file*");
lf[237]=C_h_intern(&lf[237],17,"open-output-file*");
lf[238]=C_h_intern(&lf[238],12,"port->fileno");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[241]=C_h_intern(&lf[241],25,"\003syspeek-unsigned-integer");
lf[242]=C_h_intern(&lf[242],16,"duplicate-fileno");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[244]=C_h_intern(&lf[244],6,"setenv");
lf[245]=C_h_intern(&lf[245],8,"unsetenv");
lf[246]=C_h_intern(&lf[246],9,"substring");
lf[247]=C_h_intern(&lf[247],25,"get-environment-variables");
lf[248]=C_h_intern(&lf[248],19,"current-environment");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[251]=C_h_intern(&lf[251],19,"seconds->local-time");
lf[252]=C_h_intern(&lf[252],18,"\003sysdecode-seconds");
lf[253]=C_h_intern(&lf[253],15,"current-seconds");
lf[254]=C_h_intern(&lf[254],17,"seconds->utc-time");
lf[255]=C_h_intern(&lf[255],15,"seconds->string");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[257]=C_h_intern(&lf[257],12,"time->string");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[260]=C_h_intern(&lf[260],19,"local-time->seconds");
lf[261]=C_h_intern(&lf[261],15,"\003syscons-flonum");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[263]=C_h_intern(&lf[263],27,"local-timezone-abbreviation");
lf[264]=C_h_intern(&lf[264],5,"_exit");
lf[265]=C_h_intern(&lf[265],14,"terminal-port\077");
lf[266]=C_h_intern(&lf[266],19,"set-buffering-mode!");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[268]=C_h_intern(&lf[268],5,"\000full");
lf[269]=C_h_intern(&lf[269],5,"\000line");
lf[270]=C_h_intern(&lf[270],5,"\000none");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[272]=C_h_intern(&lf[272],6,"regexp");
lf[273]=C_h_intern(&lf[273],12,"string-match");
lf[274]=C_h_intern(&lf[274],12,"glob->regexp");
lf[275]=C_h_intern(&lf[275],13,"make-pathname");
lf[276]=C_h_intern(&lf[276],18,"decompose-pathname");
lf[277]=C_h_intern(&lf[277],4,"glob");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[280]=C_h_intern(&lf[280],13,"spawn/overlay");
lf[281]=C_h_intern(&lf[281],10,"spawn/wait");
lf[282]=C_h_intern(&lf[282],12,"spawn/nowait");
lf[283]=C_h_intern(&lf[283],13,"spawn/nowaito");
lf[284]=C_h_intern(&lf[284],12,"spawn/detach");
lf[285]=C_h_intern(&lf[285],16,"char-whitespace\077");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[289]=C_h_intern(&lf[289],24,"pathname-strip-directory");
lf[292]=C_h_intern(&lf[292],15,"process-execute");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[294]=C_h_intern(&lf[294],13,"process-spawn");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[296]=C_h_intern(&lf[296],18,"current-process-id");
lf[297]=C_h_intern(&lf[297],17,"\003sysshell-command");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[299]=C_h_intern(&lf[299],24,"get-environment-variable");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[301]=C_h_intern(&lf[301],27,"\003sysshell-command-arguments");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[303]=C_h_intern(&lf[303],11,"process-run");
lf[304]=C_h_intern(&lf[304],11,"\003sysprocess");
lf[305]=C_h_intern(&lf[305],14,"\000process-error");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[307]=C_h_intern(&lf[307],17,"\003sysmake-locative");
lf[308]=C_h_intern(&lf[308],8,"location");
lf[309]=C_h_intern(&lf[309],7,"process");
lf[310]=C_h_intern(&lf[310],8,"process*");
lf[311]=C_h_intern(&lf[311],16,"\003sysprocess-wait");
lf[312]=C_h_intern(&lf[312],12,"process-wait");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[314]=C_h_intern(&lf[314],5,"sleep");
lf[315]=C_h_intern(&lf[315],13,"get-host-name");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[317]=C_h_intern(&lf[317],18,"system-information");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[321]=C_h_intern(&lf[321],13,"pathname-file");
lf[322]=C_h_intern(&lf[322],10,"find-files");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[326]=C_h_intern(&lf[326],16,"\003sysdynamic-wind");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[328]=C_h_intern(&lf[328],17,"change-file-owner");
lf[329]=C_h_intern(&lf[329],5,"error");
lf[330]=C_h_intern(&lf[330],11,"create-fifo");
lf[331]=C_h_intern(&lf[331],14,"create-session");
lf[332]=C_h_intern(&lf[332],20,"create-symbolic-link");
lf[333]=C_h_intern(&lf[333],26,"current-effective-group-id");
lf[334]=C_h_intern(&lf[334],25,"current-effective-user-id");
lf[335]=C_h_intern(&lf[335],27,"current-effective-user-name");
lf[336]=C_h_intern(&lf[336],16,"current-group-id");
lf[337]=C_h_intern(&lf[337],15,"current-user-id");
lf[338]=C_h_intern(&lf[338],18,"map-file-to-memory");
lf[339]=C_h_intern(&lf[339],9,"file-link");
lf[340]=C_h_intern(&lf[340],9,"file-lock");
lf[341]=C_h_intern(&lf[341],18,"file-lock/blocking");
lf[342]=C_h_intern(&lf[342],11,"file-select");
lf[343]=C_h_intern(&lf[343],14,"file-test-lock");
lf[344]=C_h_intern(&lf[344],13,"file-truncate");
lf[345]=C_h_intern(&lf[345],11,"file-unlock");
lf[346]=C_h_intern(&lf[346],10,"get-groups");
lf[347]=C_h_intern(&lf[347],17,"group-information");
lf[348]=C_h_intern(&lf[348],17,"initialize-groups");
lf[349]=C_h_intern(&lf[349],26,"memory-mapped-file-pointer");
lf[350]=C_h_intern(&lf[350],17,"parent-process-id");
lf[351]=C_h_intern(&lf[351],12,"process-fork");
lf[352]=C_h_intern(&lf[352],16,"process-group-id");
lf[353]=C_h_intern(&lf[353],14,"process-signal");
lf[354]=C_h_intern(&lf[354],18,"read-symbolic-link");
lf[355]=C_h_intern(&lf[355],10,"set-alarm!");
lf[356]=C_h_intern(&lf[356],13,"set-group-id!");
lf[357]=C_h_intern(&lf[357],11,"set-groups!");
lf[358]=C_h_intern(&lf[358],21,"set-process-group-id!");
lf[359]=C_h_intern(&lf[359],19,"set-root-directory!");
lf[360]=C_h_intern(&lf[360],16,"set-signal-mask!");
lf[361]=C_h_intern(&lf[361],12,"set-user-id!");
lf[362]=C_h_intern(&lf[362],11,"signal-mask");
lf[363]=C_h_intern(&lf[363],12,"signal-mask!");
lf[364]=C_h_intern(&lf[364],14,"signal-masked\077");
lf[365]=C_h_intern(&lf[365],14,"signal-unmask!");
lf[366]=C_h_intern(&lf[366],13,"terminal-name");
lf[367]=C_h_intern(&lf[367],13,"terminal-size");
lf[368]=C_h_intern(&lf[368],22,"unmap-file-from-memory");
lf[369]=C_h_intern(&lf[369],16,"user-information");
lf[370]=C_h_intern(&lf[370],17,"utc-time->seconds");
lf[371]=C_h_intern(&lf[371],12,"string->time");
lf[372]=C_h_intern(&lf[372],16,"errno/wouldblock");
lf[373]=C_h_intern(&lf[373],19,"memory-mapped-file\077");
lf[374]=C_h_intern(&lf[374],13,"map/anonymous");
lf[375]=C_h_intern(&lf[375],8,"map/file");
lf[376]=C_h_intern(&lf[376],9,"map/fixed");
lf[377]=C_h_intern(&lf[377],11,"map/private");
lf[378]=C_h_intern(&lf[378],10,"map/shared");
lf[379]=C_h_intern(&lf[379],10,"open/fsync");
lf[380]=C_h_intern(&lf[380],11,"open/noctty");
lf[381]=C_h_intern(&lf[381],13,"open/nonblock");
lf[382]=C_h_intern(&lf[382],9,"open/sync");
lf[383]=C_h_intern(&lf[383],10,"perm/isgid");
lf[384]=C_h_intern(&lf[384],10,"perm/isuid");
lf[385]=C_h_intern(&lf[385],10,"perm/isvtx");
lf[386]=C_h_intern(&lf[386],9,"prot/exec");
lf[387]=C_h_intern(&lf[387],9,"prot/none");
lf[388]=C_h_intern(&lf[388],9,"prot/read");
lf[389]=C_h_intern(&lf[389],10,"prot/write");
lf[390]=C_h_intern(&lf[390],11,"make-vector");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[393]=C_h_intern(&lf[393],18,"getter-with-setter");
lf[394]=C_h_intern(&lf[394],17,"stat-char-device\077");
lf[395]=C_h_intern(&lf[395],17,"register-feature!");
lf[396]=C_h_intern(&lf[396],5,"posix");
C_register_lf2(lf,397,create_ptable());
t2=C_mutate(&lf[0] /* (set! c1326 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1831,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1829 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1832 in k1829 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1835 in k1832 in k1829 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 932  register-feature! */
t3=*((C_word*)lf[395]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[396]);}

/* k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1849,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1856,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! posix-error ...) */,lf[3]);
t5=C_mutate((C_word*)lf[9]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[10]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[11]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[12]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[13]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[14]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[15]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[16]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[17]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[18]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[19]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[20]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[21]+1 /* (set! open/noinherit ...) */,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[22]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[23]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[24]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[25]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[26]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[27]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[28]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[29]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[30]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[31]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[32]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[33]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_u_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[34]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1902,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[39]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1943,tmp=(C_word)a,a+=2,tmp));
t34=*((C_word*)lf[41]+1);
t35=C_mutate((C_word*)lf[42]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1961,a[2]=t34,tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[46]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2006,tmp=(C_word)a,a+=2,tmp));
t37=*((C_word*)lf[49]+1);
t38=C_mutate((C_word*)lf[50]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2048,a[2]=t37,tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[53]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[54]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[55]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[56] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2086,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[59]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2124,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[60]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2148,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[61]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2154,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[62]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2160,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[63]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2166,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[64]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2172,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[65]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2178,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[66]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2184,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[68]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2207,tmp=(C_word)a,a+=2,tmp));
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2212,tmp=(C_word)a,a+=2,tmp);
t53=C_mutate((C_word*)lf[69]+1 /* (set! stat-regular? ...) */,*((C_word*)lf[66]+1));
t54=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2223,a[2]=t52,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1117 stat-type */
f_2212(t54,lf[70]);}

/* k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2223,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! stat-directory? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1118 stat-type */
f_2212(t3,lf[394]);}

/* k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2227,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* (set! stat-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1119 stat-type */
f_2212(t3,lf[72]);}

/* k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2231,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1 /* (set! character-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1120 stat-type */
f_2212(t3,lf[73]);}

/* k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2235,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* (set! block-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1121 stat-type */
f_2212(t3,lf[74]);}

/* k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! stat-block-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1122 stat-type */
f_2212(t3,lf[75]);}

/* k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! stat-fifo? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1123 stat-type */
f_2212(t3,lf[76]);}

/* k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2247,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! fifo? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1124 stat-type */
f_2212(t3,lf[77]);}

/* k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2251,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! stat-symlink? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1125 stat-type */
f_2212(t3,lf[78]);}

/* k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2255,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! socket? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2259,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1126 stat-type */
f_2212(t3,lf[79]);}

/* k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2259,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1 /* (set! stat-socket? ...) */,t1);
t3=C_mutate((C_word*)lf[80]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2261,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5667,tmp=(C_word)a,a+=2,tmp);
/* posixwin.scm: 1145 getter-with-setter */
t6=*((C_word*)lf[393]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[80]+1));}

/* a5666 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5667(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5667,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5671,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5683,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1147 port? */
t5=*((C_word*)lf[84]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5681 in a5666 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[82]);
t4=((C_word*)t0)[2];
f_5671(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_5671(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 1154 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[44],lf[87],lf[392],((C_word*)t0)[3]);}}}

/* k5669 in a5666 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5674,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_lessp(t1,C_fix(0)))){
/* posixwin.scm: 1156 posix-error */
t3=lf[3];
f_1856(6,t3,t2,lf[35],lf[87],lf[391],((C_word*)t0)[2]);}
else{
t3=t2;
f_5674(2,t3,C_SCHEME_UNDEFINED);}}

/* k5672 in k5669 in a5666 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word ab[87],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! file-position ...) */,t1);
t3=C_mutate((C_word*)lf[88]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2323,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[94]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2442,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[96]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2469,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[2]+1);
t7=*((C_word*)lf[41]+1);
t8=*((C_word*)lf[98]+1);
t9=C_mutate((C_word*)lf[99]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2496,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[103]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2653,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[41]+1);
t12=C_mutate((C_word*)lf[102]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[106]+1);
t14=*((C_word*)lf[107]+1);
t15=*((C_word*)lf[108]+1);
t16=*((C_word*)lf[109]+1);
t17=*((C_word*)lf[110]+1);
t18=*((C_word*)lf[2]+1);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2724,tmp=(C_word)a,a+=2,tmp);
t20=*((C_word*)lf[113]+1);
t21=*((C_word*)lf[102]+1);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2740,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
t23=C_mutate((C_word*)lf[118]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2796,a[2]=t16,a[3]=t14,a[4]=t20,a[5]=t22,a[6]=t15,a[7]=t13,a[8]=t17,a[9]=t19,a[10]=t18,tmp=(C_word)a,a+=11,tmp));
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3165,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3171,tmp=(C_word)a,a+=2,tmp);
t26=C_mutate((C_word*)lf[136]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3189,a[2]=t24,a[3]=t25,tmp=(C_word)a,a+=4,tmp));
t27=C_mutate((C_word*)lf[139]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3225,a[2]=t24,a[3]=t25,tmp=(C_word)a,a+=4,tmp));
t28=C_mutate((C_word*)lf[140]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3261,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[143]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[140]+1));
t30=*((C_word*)lf[136]+1);
t31=*((C_word*)lf[139]+1);
t32=*((C_word*)lf[140]+1);
t33=*((C_word*)lf[143]+1);
t34=C_mutate((C_word*)lf[144]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3280,a[2]=t30,a[3]=t32,tmp=(C_word)a,a+=4,tmp));
t35=C_mutate((C_word*)lf[145]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3304,a[2]=t31,a[3]=t33,tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[146]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3328,a[2]=t30,a[3]=t32,tmp=(C_word)a,a+=4,tmp));
t37=C_mutate((C_word*)lf[148]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3348,a[2]=t31,a[3]=t33,tmp=(C_word)a,a+=4,tmp));
t38=C_mutate((C_word*)lf[150]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3368,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[152]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t40=C_mutate((C_word*)lf[153]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t41=C_mutate((C_word*)lf[154]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t42=C_mutate((C_word*)lf[155]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t43=C_mutate((C_word*)lf[156]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t44=C_mutate((C_word*)lf[157]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t45=C_mutate((C_word*)lf[158]+1 /* (set! signal/break ...) */,C_fix((C_word)SIGBREAK));
t46=C_set_block_item(lf[159] /* signal/alrm */,0,C_fix(0));
t47=C_set_block_item(lf[160] /* signal/chld */,0,C_fix(0));
t48=C_set_block_item(lf[161] /* signal/cont */,0,C_fix(0));
t49=C_set_block_item(lf[162] /* signal/hup */,0,C_fix(0));
t50=C_set_block_item(lf[163] /* signal/io */,0,C_fix(0));
t51=C_set_block_item(lf[164] /* signal/kill */,0,C_fix(0));
t52=C_set_block_item(lf[165] /* signal/pipe */,0,C_fix(0));
t53=C_set_block_item(lf[166] /* signal/prof */,0,C_fix(0));
t54=C_set_block_item(lf[167] /* signal/quit */,0,C_fix(0));
t55=C_set_block_item(lf[168] /* signal/stop */,0,C_fix(0));
t56=C_set_block_item(lf[169] /* signal/trap */,0,C_fix(0));
t57=C_set_block_item(lf[170] /* signal/tstp */,0,C_fix(0));
t58=C_set_block_item(lf[171] /* signal/urg */,0,C_fix(0));
t59=C_set_block_item(lf[172] /* signal/usr1 */,0,C_fix(0));
t60=C_set_block_item(lf[173] /* signal/usr2 */,0,C_fix(0));
t61=C_set_block_item(lf[174] /* signal/vtalrm */,0,C_fix(0));
t62=C_set_block_item(lf[175] /* signal/winch */,0,C_fix(0));
t63=C_set_block_item(lf[176] /* signal/xcpu */,0,C_fix(0));
t64=C_set_block_item(lf[177] /* signal/xfsz */,0,C_fix(0));
t65=(C_word)C_a_i_list(&a,7,*((C_word*)lf[152]+1),*((C_word*)lf[153]+1),*((C_word*)lf[154]+1),*((C_word*)lf[155]+1),*((C_word*)lf[156]+1),*((C_word*)lf[157]+1),*((C_word*)lf[158]+1));
t66=C_mutate((C_word*)lf[178]+1 /* (set! signals-list ...) */,t65);
t67=*((C_word*)lf[179]+1);
t68=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3435,a[2]=((C_word*)t0)[2],a[3]=t67,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1474 make-vector */
t69=*((C_word*)lf[390]+1);
((C_proc4)(void*)(*((C_word*)t69+1)))(4,t69,t68,C_fix(256),C_SCHEME_FALSE);}

/* k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word t181;
C_word ab[226],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3435,2,t0,t1);}
t2=C_mutate((C_word*)lf[180]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3437,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[181]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3446,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[179]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[182]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[183]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[184]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[185]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[186]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[187]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[188]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[189]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[190]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[191]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[192]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[193]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[194]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[195]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[196]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[197]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[198]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[199]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[200]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[201]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[202]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[203]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[204]+1 /* (set! errno/nxio ...) */,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[205]+1 /* (set! errno/2big ...) */,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[206]+1 /* (set! errno/xdev ...) */,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[207]+1 /* (set! errno/nodev ...) */,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[208]+1 /* (set! errno/nfile ...) */,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[209]+1 /* (set! errno/notty ...) */,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[210]+1 /* (set! errno/fbig ...) */,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[211]+1 /* (set! errno/mlink ...) */,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[212]+1 /* (set! errno/dom ...) */,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[213]+1 /* (set! errno/range ...) */,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[214]+1 /* (set! errno/deadlk ...) */,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[215]+1 /* (set! errno/nametoolong ...) */,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[216]+1 /* (set! errno/nolck ...) */,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[217]+1 /* (set! errno/nosys ...) */,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[218]+1 /* (set! errno/notempty ...) */,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[219]+1 /* (set! errno/ilseq ...) */,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[220]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3515,tmp=(C_word)a,a+=2,tmp));
t44=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3545,tmp=(C_word)a,a+=2,tmp);
t45=C_mutate((C_word*)lf[222]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3569,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[223]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3575,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[224]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3581,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[225]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[226]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[227]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)2));
t51=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3590,tmp=(C_word)a,a+=2,tmp);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3627,tmp=(C_word)a,a+=2,tmp);
t53=C_mutate((C_word*)lf[236]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3645,a[2]=t51,a[3]=t52,tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[237]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3659,a[2]=t51,a[3]=t52,tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[238]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3673,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[242]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3708,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[244]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3738,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[245]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3755,tmp=(C_word)a,a+=2,tmp));
t59=*((C_word*)lf[246]+1);
t60=C_mutate((C_word*)lf[247]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3770,a[2]=t59,tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[248]+1 /* (set! current-environment ...) */,*((C_word*)lf[247]+1));
t62=C_mutate(&lf[249] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3836,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[251]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3855,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[254]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3882,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[255]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3914,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[257]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3965,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[260]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4025,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[263]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4040,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[264]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4048,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[265]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4064,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[266]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4070,tmp=(C_word)a,a+=2,tmp));
t72=*((C_word*)lf[272]+1);
t73=*((C_word*)lf[273]+1);
t74=*((C_word*)lf[274]+1);
t75=*((C_word*)lf[99]+1);
t76=*((C_word*)lf[275]+1);
t77=*((C_word*)lf[276]+1);
t78=C_mutate((C_word*)lf[277]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4129,a[2]=t74,a[3]=t72,a[4]=t75,a[5]=t73,a[6]=t76,a[7]=t77,tmp=(C_word)a,a+=8,tmp));
t79=C_mutate((C_word*)lf[280]+1 /* (set! spawn/overlay ...) */,C_fix((C_word)P_OVERLAY));
t80=C_mutate((C_word*)lf[281]+1 /* (set! spawn/wait ...) */,C_fix((C_word)P_WAIT));
t81=C_mutate((C_word*)lf[282]+1 /* (set! spawn/nowait ...) */,C_fix((C_word)P_NOWAIT));
t82=C_mutate((C_word*)lf[283]+1 /* (set! spawn/nowaito ...) */,C_fix((C_word)P_NOWAITO));
t83=C_mutate((C_word*)lf[284]+1 /* (set! spawn/detach ...) */,C_fix((C_word)P_DETACH));
t84=*((C_word*)lf[285]+1);
t85=*((C_word*)lf[49]+1);
t86=*((C_word*)lf[110]+1);
t87=*((C_word*)lf[2]+1);
t88=C_mutate(&lf[286] /* (set! $quote-args-list ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4241,a[2]=t87,a[3]=t85,a[4]=t86,a[5]=t84,tmp=(C_word)a,a+=6,tmp));
t89=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4320,tmp=(C_word)a,a+=2,tmp);
t90=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4326,tmp=(C_word)a,a+=2,tmp);
t91=*((C_word*)lf[289]+1);
t92=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4332,tmp=(C_word)a,a+=2,tmp);
t93=C_mutate(&lf[290] /* (set! $exec-setup ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4382,a[2]=t91,a[3]=t89,a[4]=t90,a[5]=t92,tmp=(C_word)a,a+=6,tmp));
t94=C_mutate(&lf[291] /* (set! $exec-teardown ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4418,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[292]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4433,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[294]+1 /* (set! process-spawn ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4517,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[296]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4601,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[297]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4604,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[301]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4625,tmp=(C_word)a,a+=2,tmp));
t100=*((C_word*)lf[294]+1);
t101=*((C_word*)lf[299]+1);
t102=C_mutate((C_word*)lf[303]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4631,a[2]=t100,tmp=(C_word)a,a+=3,tmp));
t103=C_mutate((C_word*)lf[304]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4711,tmp=(C_word)a,a+=2,tmp));
t104=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4807,tmp=(C_word)a,a+=2,tmp);
t105=C_mutate((C_word*)lf[309]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4885,a[2]=t104,tmp=(C_word)a,a+=3,tmp));
t106=C_mutate((C_word*)lf[310]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4962,a[2]=t104,tmp=(C_word)a,a+=3,tmp));
t107=C_mutate((C_word*)lf[311]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5039,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[312]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5051,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[314]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5108,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[315]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5111,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[317]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5123,tmp=(C_word)a,a+=2,tmp));
t112=C_mutate((C_word*)lf[113]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5154,tmp=(C_word)a,a+=2,tmp));
t113=*((C_word*)lf[277]+1);
t114=*((C_word*)lf[273]+1);
t115=*((C_word*)lf[275]+1);
t116=*((C_word*)lf[321]+1);
t117=*((C_word*)lf[103]+1);
t118=C_mutate((C_word*)lf[322]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5169,a[2]=t117,a[3]=t116,a[4]=t115,a[5]=t113,a[6]=t114,tmp=(C_word)a,a+=7,tmp));
t119=C_mutate((C_word*)lf[328]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5386,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[330]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5392,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[331]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5398,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[332]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5404,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[333]+1 /* (set! current-effective-group-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5410,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[334]+1 /* (set! current-effective-user-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5416,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[335]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5422,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[336]+1 /* (set! current-group-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5428,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[337]+1 /* (set! current-user-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5434,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[338]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5440,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[339]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5446,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[340]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5452,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[341]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5458,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[342]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5464,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[343]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5470,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[344]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5476,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[345]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5482,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[346]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5488,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[347]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5494,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[348]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5500,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[349]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5506,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[350]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5512,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[351]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5518,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[352]+1 /* (set! process-group-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5524,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[353]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5530,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[354]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5536,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[355]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5542,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[356]+1 /* (set! set-group-id! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5548,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[357]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5554,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[358]+1 /* (set! set-process-group-id! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5560,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[359]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5566,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[360]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5572,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[361]+1 /* (set! set-user-id! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5578,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[362]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5584,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[363]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5590,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[364]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5596,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[365]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5602,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[366]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5608,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[367]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5614,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[368]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5620,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[369]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5626,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[370]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5632,tmp=(C_word)a,a+=2,tmp));
t161=C_mutate((C_word*)lf[371]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5638,tmp=(C_word)a,a+=2,tmp));
t162=C_set_block_item(lf[372] /* errno/wouldblock */,0,C_fix(0));
t163=C_mutate((C_word*)lf[76]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5645,tmp=(C_word)a,a+=2,tmp));
t164=C_mutate((C_word*)lf[373]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5648,tmp=(C_word)a,a+=2,tmp));
t165=C_set_block_item(lf[374] /* map/anonymous */,0,C_fix(0));
t166=C_set_block_item(lf[375] /* map/file */,0,C_fix(0));
t167=C_set_block_item(lf[376] /* map/fixed */,0,C_fix(0));
t168=C_set_block_item(lf[377] /* map/private */,0,C_fix(0));
t169=C_set_block_item(lf[378] /* map/shared */,0,C_fix(0));
t170=C_set_block_item(lf[379] /* open/fsync */,0,C_fix(0));
t171=C_set_block_item(lf[380] /* open/noctty */,0,C_fix(0));
t172=C_set_block_item(lf[381] /* open/nonblock */,0,C_fix(0));
t173=C_set_block_item(lf[382] /* open/sync */,0,C_fix(0));
t174=C_set_block_item(lf[383] /* perm/isgid */,0,C_fix(0));
t175=C_set_block_item(lf[384] /* perm/isuid */,0,C_fix(0));
t176=C_set_block_item(lf[385] /* perm/isvtx */,0,C_fix(0));
t177=C_set_block_item(lf[386] /* prot/exec */,0,C_fix(0));
t178=C_set_block_item(lf[387] /* prot/none */,0,C_fix(0));
t179=C_set_block_item(lf[388] /* prot/read */,0,C_fix(0));
t180=C_set_block_item(lf[389] /* prot/write */,0,C_fix(0));
t181=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t181+1)))(2,t181,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5648,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5645,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* string->time in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5638,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[371],lf[0]);}

/* utc-time->seconds in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[370],lf[0]);}

/* user-information in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5626,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[369],lf[0]);}

/* unmap-file-from-memory in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5620,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[368],lf[0]);}

/* terminal-size in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5614,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[367],lf[0]);}

/* terminal-name in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5608,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[366],lf[0]);}

/* signal-unmask! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5602,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[365],lf[0]);}

/* signal-masked? in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5596,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[364],lf[0]);}

/* signal-mask! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5590,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[363],lf[0]);}

/* signal-mask in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5584(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5584,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[362],lf[0]);}

/* set-user-id! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5578(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5578,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[361],lf[0]);}

/* set-signal-mask! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5572,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[360],lf[0]);}

/* set-root-directory! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5566,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[359],lf[0]);}

/* set-process-group-id! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5560,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[358],lf[0]);}

/* set-groups! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[357],lf[0]);}

/* set-group-id! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[356],lf[0]);}

/* set-alarm! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[355],lf[0]);}

/* read-symbolic-link in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5536,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[354],lf[0]);}

/* process-signal in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5530,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[353],lf[0]);}

/* process-group-id in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5524,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[352],lf[0]);}

/* process-fork in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5518,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[351],lf[0]);}

/* parent-process-id in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5512,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[350],lf[0]);}

/* memory-mapped-file-pointer in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5506,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[349],lf[0]);}

/* initialize-groups in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5500,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[348],lf[0]);}

/* group-information in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[347],lf[0]);}

/* get-groups in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5488(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5488,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[346],lf[0]);}

/* file-unlock in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5482(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5482,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[345],lf[0]);}

/* file-truncate in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5476(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5476,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[344],lf[0]);}

/* file-test-lock in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5470,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[343],lf[0]);}

/* file-select in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5464,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[342],lf[0]);}

/* file-lock/blocking in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5458,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[341],lf[0]);}

/* file-lock in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5452,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[340],lf[0]);}

/* file-link in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5446,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[339],lf[0]);}

/* map-file-to-memory in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5440,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[338],lf[0]);}

/* current-user-id in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5434(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5434,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[337],lf[0]);}

/* current-group-id in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5428,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[336],lf[0]);}

/* current-effective-user-name in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5422,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[335],lf[0]);}

/* current-effective-user-id in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5416,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[334],lf[0]);}

/* current-effective-group-id in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5410,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[333],lf[0]);}

/* create-symbolic-link in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5404(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5404,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[332],lf[0]);}

/* create-session in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5398(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5398,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[331],lf[0]);}

/* create-fifo in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5392,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[330],lf[0]);}

/* change-file-owner in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5386(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5386,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[328],lf[0]);}

/* find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_5169r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5169r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5169r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5310,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5315,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5320,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action12181278 */
t9=t8;
f_5320(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id12191276 */
t11=t7;
f_5315(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit12201273 */
t13=t6;
f_5310(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body12161225 */
t15=t5;
f_5171(t15,t1,t9,t11,t13);}}}}

/* def-action1218 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_5320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5320,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5326,tmp=(C_word)a,a+=2,tmp);
/* def-id12191276 */
t3=((C_word*)t0)[2];
f_5315(t3,t1,t2);}

/* a5325 in def-action1218 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5326,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1219 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_5315(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5315,NULL,3,t0,t1,t2);}
/* def-limit12201273 */
t3=((C_word*)t0)[2];
f_5310(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1220 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_5310(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5310,NULL,4,t0,t1,t2,t3);}
/* body12161225 */
t4=((C_word*)t0)[2];
f_5171(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_5171(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5171,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[8],lf[322]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5178,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=t7,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_5178(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5305,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp):t4));}
else{
t10=t8;
f_5178(t10,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5297,tmp=(C_word)a,a+=2,tmp));}}

/* f_5297 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5297,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_5305 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5305,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_5178(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5178,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[12]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5289,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5188,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5285,a[2]=t4,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2057 make-pathname */
t6=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],lf[327]);}

/* k5283 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2057 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5188,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5190,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5190(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_5190(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5190,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5209,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=t5,a[12]=t1,a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* posixwin.scm: 2063 directory? */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k5207 in loop in k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5209,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5265,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 2064 pathname-file */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5271,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 2070 pproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k5269 in k5207 in loop in k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5271,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5278,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 2070 action */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 2071 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5190(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k5276 in k5269 in k5207 in loop in k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2070 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5190(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5263 in k5207 in loop in k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5265,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[323]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[324]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 2064 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_5190(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5224,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 2065 lproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k5222 in k5263 in k5207 in loop in k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5224,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5234,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5236,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5255,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[326]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 2069 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5190(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a5254 in k5222 in k5263 in k5207 in loop in k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5255,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a5240 in k5222 in k5263 in k5207 in loop in k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5249,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5253,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2068 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[325]);}

/* k5251 in a5240 in k5222 in k5263 in k5207 in loop in k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2068 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5247 in a5240 in k5222 in k5263 in k5207 in loop in k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2068 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5190(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5235 in k5222 in k5263 in k5207 in loop in k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5236,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k5232 in k5222 in k5263 in k5207 in loop in k5186 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2066 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5190(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_5289 in k5176 in body1216 in find-files in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5289,3,t0,t1,t2);}
/* posixwin.scm: 2055 string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5154,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5164,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2030 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5162 in current-user-name in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2031 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[113],lf[320]);}

/* system-information in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5123,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5134,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5149,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2021 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5147 in system-information in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2022 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[317],lf[319]);}

/* k5132 in system-information in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5138,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k5136 in k5132 in system-information in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5142,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k5140 in k5136 in k5132 in system-information in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5146,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k5144 in k5140 in k5136 in k5132 in system-information in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5146,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[318],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5111,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 2011 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[315],lf[316]);}}

/* sleep in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5108,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5051r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5051r(t0,t1,t2,t3);}}

static void C_ccall f_5051r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(7);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_check_exact_2(t2,lf[312]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5069,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5075,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a5074 in process-wait in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5075,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5085,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1993 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 1995 values */
C_values(5,0,t1,t2,t3,t4);}}

/* k5083 in a5074 in process-wait in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1994 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[305],lf[312],lf[313],((C_word*)t0)[2]);}

/* a5068 in process-wait in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5069,2,t0,t1);}
/* posixwin.scm: 1990 ##sys#process-wait */
t2=*((C_word*)lf[311]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5039,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
/* posixwin.scm: 1983 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
/* posixwin.scm: 1984 values */
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_4962r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4962r(t0,t1,t2,t3);}}

static void C_ccall f_4962r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4964,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4969,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4974,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4979,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args11521168 */
t8=t7;
f_4979(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env11531166 */
t10=t6;
f_4974(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf11541163 */
t12=t5;
f_4969(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body11501159 */
t14=t4;
f_4964(t14,t1,t8,t10,t12);}}}}

/* def-args1152 in process* in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4979(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4979,NULL,2,t0,t1);}
/* def-env11531166 */
t2=((C_word*)t0)[2];
f_4974(t2,t1,C_SCHEME_FALSE);}

/* def-env1153 in process* in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4974(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4974,NULL,3,t0,t1,t2);}
/* def-exactf11541163 */
t3=((C_word*)t0)[2];
f_4969(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1154 in process* in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4969(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4969,NULL,4,t0,t1,t2,t3);}
/* body11501159 */
t4=((C_word*)t0)[2];
f_4964(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1150 in process* in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4964(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4964,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1977 %process */
f_4807(t1,lf[310],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_4885r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4885r(t0,t1,t2,t3);}}

static void C_ccall f_4885r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4887,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4892,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4897,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4902,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args11131129 */
t8=t7;
f_4902(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env11141127 */
t10=t6;
f_4897(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf11151124 */
t12=t5;
f_4892(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body11111120 */
t14=t4;
f_4887(t14,t1,t8,t10,t12);}}}}

/* def-args1113 in process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4902(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4902,NULL,2,t0,t1);}
/* def-env11141127 */
t2=((C_word*)t0)[2];
f_4897(t2,t1,C_SCHEME_FALSE);}

/* def-env1114 in process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4897(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4897,NULL,3,t0,t1,t2);}
/* def-exactf11151124 */
t3=((C_word*)t0)[2];
f_4892(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1115 in process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4892(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4892,NULL,4,t0,t1,t2,t3);}
/* body11111120 */
t4=((C_word*)t0)[2];
f_4887(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1111 in process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4887(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4887,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1974 %process */
f_4807(t1,lf[309],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4807(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4807,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4818,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4809,a[2]=t11,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4844,a[2]=t1,a[3]=t10,a[4]=t3,a[5]=t9,a[6]=t8,a[7]=t2,a[8]=t12,a[9]=t6,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixwin.scm: 1962 chkstrlst */
t15=t14;
f_4844(t15,f_4809(t12,((C_word*)t9)[1]));}
else{
t15=C_set_block_item(t10,0,C_SCHEME_TRUE);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4879,a[2]=t14,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1965 ##sys#shell-command-arguments */
t17=*((C_word*)lf[301]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,((C_word*)t8)[1]);}}

/* k4877 in %process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4879,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1966 ##sys#shell-command */
t4=*((C_word*)lf[297]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4881 in k4877 in %process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4844(t3,t2);}

/* k4842 in %process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4844(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4844,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[9])?f_4809(((C_word*)t0)[8],((C_word*)t0)[9]):C_SCHEME_UNDEFINED);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4858,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4857 in k4842 in %process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4858,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixwin.scm: 1970 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixwin.scm: 1971 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a4851 in k4842 in %process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4852,2,t0,t1);}
/* posixwin.scm: 1968 ##sys#process */
t2=*((C_word*)lf[304]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static C_word C_fcall f_4809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_check_list_2(t1,((C_word*)t0)[3]);
return(f_4818(((C_word*)t0)[2],t1));}

/* loop1069 in %process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static C_word C_fcall f_4818(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]);
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr9rv,(void*)f_4711r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest_vector(a,C_rest_count(0));
f_4711r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_4711r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(14);
t10=(C_word)C_vemptyp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:(C_word)C_slot(t9,C_fix(0)));
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4718,a[2]=t2,a[3]=t6,a[4]=t7,a[5]=t8,a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4790,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_a_i_cons(&a,2,t3,t4);
/* posixwin.scm: 1934 $quote-args-list */
t15=lf[286];
f_4241(t15,t13,t14,t11);}

/* k4788 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1934 string-intersperse */
t2=*((C_word*)lf[111]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4716 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4718,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=((*(int *)C_data_pointer(t2))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t5=((*(int *)C_data_pointer(t4))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t7=((*(int *)C_data_pointer(t6))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=((*(int *)C_data_pointer(t8))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t10=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* ##sys#make-locative */
t11=*((C_word*)lf[307]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,t2,C_fix(0),C_SCHEME_FALSE,lf[308]);}

/* k4756 in k4716 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[307]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[308]);}

/* k4760 in k4756 in k4716 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[307]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[308]);}

/* k4764 in k4760 in k4756 in k4716 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[307]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[308]);}

/* k4768 in k4764 in k4760 in k4756 in k4716 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
t5=(C_truep(((C_word*)t0)[8])?C_fix(0):C_fix(4));
/* posixwin.scm: 1941 + */
C_plus(5,0,t2,t3,t4,t5);}

/* k4772 in k4768 in k4764 in k4760 in k4756 in k4716 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4774,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4665,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t9=t8;
f_4665(2,t9,C_SCHEME_FALSE);}}

/* k4663 in k4772 in k4768 in k4764 in k4760 in k4756 in k4716 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_4669(2,t3,C_SCHEME_FALSE);}}

/* k4667 in k4663 in k4772 in k4768 in k4764 in k4760 in k4756 in k4716 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4669,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
if(C_truep((C_word)stub969(C_SCHEME_UNDEFINED,((C_word*)t0)[13],t1,C_SCHEME_FALSE,t2,t3,t4,t5,((C_word*)t0)[12]))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 1944 open-input-file* */
t7=*((C_word*)lf[236]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t7=t6;
f_4731(2,t7,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1949 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4749 in k4667 in k4663 in k4772 in k4768 in k4764 in k4760 in k4756 in k4716 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1950 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[305],((C_word*)t0)[3],lf[306],((C_word*)t0)[2]);}

/* k4729 in k4667 in k4663 in k4772 in k4768 in k4764 in k4760 in k4756 in k4716 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4735,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1945 open-output-file* */
t3=*((C_word*)lf[237]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_4735(2,t3,C_SCHEME_FALSE);}}

/* k4733 in k4729 in k4667 in k4663 in k4772 in k4768 in k4764 in k4760 in k4756 in k4716 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1947 open-input-file* */
t3=*((C_word*)lf[236]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_4739(2,t3,C_SCHEME_FALSE);}}

/* k4737 in k4733 in k4729 in k4667 in k4663 in k4772 in k4768 in k4764 in k4760 in k4756 in k4716 in ##sys#process in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1943 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* process-run in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4631r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4631r(t0,t1,t2,t3);}}

static void C_ccall f_4631r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1905 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,*((C_word*)lf[282]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4648,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1906 ##sys#shell-command */
t7=*((C_word*)lf[297]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4646 in process-run in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4652,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1906 ##sys#shell-command-arguments */
t3=*((C_word*)lf[301]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4650 in k4646 in process-run in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1906 process-spawn */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[282]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4625,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[302],t2));}

/* ##sys#shell-command in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4608,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1889 get-environment-variable */
t3=*((C_word*)lf[299]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[300]);}

/* k4606 in ##sys#shell-command in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4608,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_get_shlcmd())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1893 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k4618 in k4606 in ##sys#shell-command in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1894 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[297],lf[298]);}

/* current-process-id in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub944(C_SCHEME_UNDEFINED));}

/* process-spawn in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_4517r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4517r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4517r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4519,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4531,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4536,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4541,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-arglst920937 */
t9=t8;
f_4541(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-envlst921935 */
t11=t7;
f_4536(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-exactf922932 */
t13=t6;
f_4531(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body918927 */
t15=t5;
f_4519(t15,t1,t9,t11,t13);}}}}

/* def-arglst920 in process-spawn in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4541,NULL,2,t0,t1);}
/* def-envlst921935 */
t2=((C_word*)t0)[2];
f_4536(t2,t1,C_SCHEME_FALSE);}

/* def-envlst921 in process-spawn in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4536(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4536,NULL,3,t0,t1,t2);}
/* def-exactf922932 */
t3=((C_word*)t0)[2];
f_4531(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf922 in process-spawn in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4531(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4531,NULL,4,t0,t1,t2,t3);}
/* body918927 */
t4=((C_word*)t0)[2];
f_4519(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body918 in process-spawn in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4519(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4519,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1880 $exec-setup */
t6=lf[290];
f_4382(t6,t5,lf[294],((C_word*)t0)[2],t2,t3,t4);}

/* k4521 in body918 in process-spawn in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_spawnvpe(((C_word*)t0)[4],t1):(C_word)C_spawnvp(((C_word*)t0)[4],t1));
/* posixwin.scm: 1881 $exec-teardown */
f_4418(((C_word*)t0)[3],lf[294],lf[295],((C_word*)t0)[2],t2);}

/* process-execute in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_4433r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4433r(t0,t1,t2,t3);}}

static void C_ccall f_4433r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4435,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4447,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4452,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4457,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglst878895 */
t8=t7;
f_4457(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-envlst879893 */
t10=t6;
f_4452(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf880890 */
t12=t5;
f_4447(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body876885 */
t14=t4;
f_4435(t14,t1,t8,t10,t12);}}}}

/* def-arglst878 in process-execute in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4457,NULL,2,t0,t1);}
/* def-envlst879893 */
t2=((C_word*)t0)[2];
f_4452(t2,t1,C_SCHEME_FALSE);}

/* def-envlst879 in process-execute in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4452(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4452,NULL,3,t0,t1,t2);}
/* def-exactf880890 */
t3=((C_word*)t0)[2];
f_4447(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf880 in process-execute in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4447(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4447,NULL,4,t0,t1,t2,t3);}
/* body876885 */
t4=((C_word*)t0)[2];
f_4435(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body876 in process-execute in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4435(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4435,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1875 $exec-setup */
t6=lf[290];
f_4382(t6,t5,lf[292],((C_word*)t0)[2],t2,t3,t4);}

/* k4437 in body876 in process-execute in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
/* posixwin.scm: 1876 $exec-teardown */
f_4418(((C_word*)t0)[3],lf[292],lf[293],((C_word*)t0)[2],t2);}

/* $exec-teardown in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4418(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4418,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4422,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1867 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k4420 in $exec-teardown in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
/* posixwin.scm: 1871 ##sys#error */
t5=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* $exec-setup in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4382(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4382,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4389,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1859 pathname-strip-directory */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}

/* k4387 in $exec-setup in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4389,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=t1;
t4=(C_truep(t3)?t3:C_SCHEME_FALSE);
t5=(C_word)stub808(C_SCHEME_UNDEFINED,C_fix(0),t4,t2);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t6,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1861 $quote-args-list */
t8=lf[286];
f_4241(t8,t7,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t8=t7;
f_4409(2,t8,C_SCHEME_FALSE);}}

/* k4407 in k4387 in $exec-setup in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1861 build-exec-argvec */
f_4332(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k4393 in k4387 in $exec-setup in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1862 build-exec-argvec */
f_4332(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k4396 in k4393 in k4387 in $exec-setup in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4405,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1864 ##sys#expand-home-path */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4403 in k4396 in k4393 in k4387 in $exec-setup in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1864 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4332(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4332,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4344,a[2]=t8,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_4344(t10,t1,t3,t5);}
else{
/* posixwin.scm: 1856 argvec-setter */
t6=t4;
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* doloop829 in build-exec-argvec in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4344(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4344,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1852 argvec-setter */
t4=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4363,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
/* posixwin.scm: 1855 argvec-setter */
t8=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t3,t4,t7);}}

/* k4361 in doloop829 in build-exec-argvec in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4344(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4326,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub818(C_SCHEME_UNDEFINED,t2,t5,t4));}

/* setarg in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4320,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub808(C_SCHEME_UNDEFINED,t2,t5,t4));}

/* $quote-args-list in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4241(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4241,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4284,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4284(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4284(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4284,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1833 reverse */
t4=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4312,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4315,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1838 needs-quoting? */
t8=((C_word*)t0)[2];
f_4246(t8,t7,t4);}}

/* k4313 in loop in $quote-args-list in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 1838 string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[287],((C_word*)t0)[2],lf[288]);}
else{
t2=((C_word*)t0)[3];
f_4312(2,t2,((C_word*)t0)[2]);}}

/* k4310 in loop in $quote-args-list in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4312,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* posixwin.scm: 1835 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4284(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4246(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4246,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4250,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1825 string-length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4248 in needs-quoting? in $quote-args-list in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4250,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4255,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_4255(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k4248 in needs-quoting? in $quote-args-list in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4255,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4279,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1829 string-ref */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k4277 in loop in k4248 in needs-quoting? in $quote-args-list in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1829 char-whitespace? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4266 in loop in k4248 in needs-quoting? in $quote-args-list in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1830 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4255(t3,((C_word*)t0)[4],t2);}}

/* glob in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_4129r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4129r(t0,t1,t2);}}

static void C_ccall f_4129r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_4135(t6,t1,t2);}

/* conc-loop in glob in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4135,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4150,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a4155 in conc-loop in glob in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4156,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4160,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4230,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[279]);
/* posixwin.scm: 1787 make-pathname */
t8=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k4228 in a4155 in conc-loop in glob in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1787 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4158 in a4155 in conc-loop in glob in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4163,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1788 regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4161 in k4158 in a4155 in conc-loop in glob in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4170,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[278]);
/* posixwin.scm: 1789 directory */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k4168 in k4161 in k4158 in a4155 in conc-loop in glob in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4170,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_4172(t5,((C_word*)t0)[2],t1);}

/* loop in k4168 in k4161 in k4158 in a4155 in conc-loop in glob in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_4172(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4172,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* posixwin.scm: 1790 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4135(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4189,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixwin.scm: 1791 string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k4187 in loop in k4168 in k4161 in k4158 in a4155 in conc-loop in glob in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4189,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4199,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(t1);
/* posixwin.scm: 1792 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* posixwin.scm: 1793 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4172(t3,((C_word*)t0)[6],t2);}}

/* k4197 in k4187 in loop in k4168 in k4161 in k4158 in a4155 in conc-loop in glob in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4203,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1792 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4172(t4,t2,t3);}

/* k4201 in k4197 in k4187 in loop in k4168 in k4161 in k4158 in a4155 in conc-loop in glob in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4203,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a4149 in conc-loop in glob in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4150,2,t0,t1);}
/* posixwin.scm: 1786 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4070r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4070r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4070r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4074,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1758 ##sys#check-port */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[266]);}

/* k4072 in set-buffering-mode! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4080,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[268]);
if(C_truep(t6)){
t7=t5;
f_4080(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[269]);
if(C_truep(t7)){
t8=t5;
f_4080(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[270]);
if(C_truep(t8)){
t9=t5;
f_4080(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1764 ##sys#error */
t9=*((C_word*)lf[130]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[266],lf[271],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k4078 in k4072 in set-buffering-mode! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[266]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[82],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixwin.scm: 1770 ##sys#error */
t6=*((C_word*)lf[130]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[266],lf[267],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* terminal-port? in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4064,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4068,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1748 ##sys#check-port */
t4=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[265]);}

/* k4066 in terminal-port? in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* _exit in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4048r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4048r(t0,t1,t2);}}

static void C_ccall f_4048r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub707(C_SCHEME_UNDEFINED,t4));}

/* local-timezone-abbreviation in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4040,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub702(t2),C_fix(0));}

/* local-time->seconds in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4025,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4029,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1730 check-time-vector */
f_3836(t3,lf[260],t2);}

/* k4027 in local-time->seconds in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixwin.scm: 1732 ##sys#cons-flonum */
t2=*((C_word*)lf[261]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1733 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[260],lf[262],((C_word*)t0)[3]);}}

/* time->string in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3965r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3965r(t0,t1,t2,t3);}}

static void C_ccall f_3965r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3972,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1718 check-time-vector */
f_3836(t6,lf[257],t2);}

/* k3970 in time->string in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[257]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3991,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1722 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub667(t4,t3),C_fix(0));}}

/* k3992 in k3970 in time->string in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1726 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1727 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[257],lf[259],((C_word*)t0)[2]);}}

/* k3989 in k3970 in time->string in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub673(t3,t2,t1),C_fix(0));}

/* k3979 in k3970 in time->string in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixwin.scm: 1723 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[257],lf[258],((C_word*)t0)[2]);}}

/* seconds->string in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3914(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3914r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3914r(t0,t1,t2);}}

static void C_ccall f_3914r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3918,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* posixwin.scm: 1708 current-seconds */
t4=*((C_word*)lf[253]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=t3;
f_3918(2,t4,(C_word)C_slot(t2,C_fix(0)));}}

/* k3916 in seconds->string in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3921,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=t1;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub647(t4,t3),C_fix(0));}

/* k3919 in k3916 in seconds->string in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1711 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1712 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[255],lf[256],((C_word*)t0)[2]);}}

/* seconds->utc-time in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3882r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3882r(t0,t1,t2);}}

static void C_ccall f_3882r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3886,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* posixwin.scm: 1702 current-seconds */
t4=*((C_word*)lf[253]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=t3;
f_3886(2,t4,(C_word)C_slot(t2,C_fix(0)));}}

/* k3884 in seconds->utc-time in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_number_2(t1,lf[254]);
/* posixwin.scm: 1704 ##sys#decode-seconds */
t3=*((C_word*)lf[252]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* seconds->local-time in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3855r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3855r(t0,t1,t2);}}

static void C_ccall f_3855r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3859,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* posixwin.scm: 1698 current-seconds */
t4=*((C_word*)lf[253]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=t3;
f_3859(2,t4,(C_word)C_slot(t2,C_fix(0)));}}

/* k3857 in seconds->local-time in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_number_2(t1,lf[251]);
/* posixwin.scm: 1700 ##sys#decode-seconds */
t3=*((C_word*)lf[252]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* check-time-vector in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_3836(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3836,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1696 ##sys#error */
t6=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[250],t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* get-environment-variables in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3770,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3776,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3776(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_3776(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3776,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3780,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub600(t5,t4),C_fix(0));}

/* k3778 in loop in get-environment-variables in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3780,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3788,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3788(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k3778 in loop in get-environment-variables in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_3788(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3788,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1685 substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1686 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k3812 in scan in k3778 in loop in get-environment-variables in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3818,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1685 substring */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k3816 in k3812 in scan in k3778 in loop in get-environment-variables in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3818,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3806,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1685 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3776(t5,t3,t4);}

/* k3804 in k3816 in k3812 in scan in k3778 in loop in get-environment-variables in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3806,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3755,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[245]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3763,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1673 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3761 in unsetenv in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3738,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[244]);
t5=(C_word)C_i_check_string_2(t3,lf[244]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3749,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1668 ##sys#make-c-string */
t7=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k3747 in setenv in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1668 ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3751 in k3747 in setenv in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3708r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3708r(t0,t1,t2,t3);}}

static void C_ccall f_3708r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[242]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3715,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_3715(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[242]);
t8=t5;
f_3715(t8,(C_word)C_dup2(t2,t6));}}

/* k3713 in duplicate-fileno in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_3715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3715,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3718,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1657 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_3718(2,t3,C_SCHEME_UNDEFINED);}}

/* k3722 in k3713 in duplicate-fileno in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1658 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[242],lf[243],((C_word*)t0)[2]);}

/* k3716 in k3713 in duplicate-fileno in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3673,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3677,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1639 ##sys#check-port */
t4=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[238]);}

/* k3675 in port->fileno in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1640 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[241]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k3704 in k3675 in port->fileno in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3706,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1646 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[44],lf[238],lf[239],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3686,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3692,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1643 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3686(2,t4,C_SCHEME_UNDEFINED);}}}

/* k3690 in k3704 in k3675 in port->fileno in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1644 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[238],lf[240],((C_word*)t0)[2]);}

/* k3684 in k3704 in k3675 in port->fileno in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3659r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3659r(t0,t1,t2,t3);}}

static void C_ccall f_3659r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[237]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3671,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1635 mode */
f_3590(t5,C_SCHEME_FALSE,t3);}

/* k3669 in open-output-file* in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3671,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1635 check */
f_3627(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3645r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3645r(t0,t1,t2,t3);}}

static void C_ccall f_3645r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[236]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3657,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1631 mode */
f_3590(t5,C_SCHEME_TRUE,t3);}

/* k3655 in open-input-file* in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3657,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1631 check */
f_3627(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_3627(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3627,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3631,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1622 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3629 in check in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3631,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1624 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[35],lf[234],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3643,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1625 ##sys#make-port */
t3=*((C_word*)lf[133]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[134]+1),lf[235],lf[82]);}}

/* k3641 in k3629 in check in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_3590(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3590,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3598,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[228]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1617 ##sys#error */
t8=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[229],t5);}
else{
t8=t4;
f_3598(2,t8,lf[230]);}}
else{
/* posixwin.scm: 1618 ##sys#error */
t7=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[231],t5);}}
else{
t5=t4;
f_3598(2,t5,(C_truep(t2)?lf[232]:lf[233]));}}

/* k3596 in mode in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1613 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3581,3,t0,t1,t2);}
/* posixwin.scm: 1597 check */
f_3545(t1,t2,C_fix((C_word)2),lf[224]);}

/* file-write-access? in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3575,3,t0,t1,t2);}
/* posixwin.scm: 1596 check */
f_3545(t1,t2,C_fix((C_word)4),lf[223]);}

/* file-read-access? in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3569,3,t0,t1,t2);}
/* posixwin.scm: 1595 check */
f_3545(t1,t2,C_fix((C_word)2),lf[222]);}

/* check in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_3545(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3545,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3563,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3567,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1592 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3565 in check in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1592 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3561 in check in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3563,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3555,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3555(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1593 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3553 in k3561 in check in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3515,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[220]);
t5=(C_word)C_i_check_exact_2(t3,lf[220]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3539,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3543,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1581 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3541 in change-file-mode in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1581 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3537 in change-file-mode in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3539,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1582 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3529 in k3537 in change-file-mode in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1583 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[220],lf[221],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3459,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3469,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1489 h */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1491 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k3467 in ##sys#interrupt-hook in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1490 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3446,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[181]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k3433 in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3437,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[180]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3368r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3368r(t0,t1,t2);}}

static void C_ccall f_3368r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?(C_word)C_u_fixnum_or(*((C_word*)lf[19]+1),*((C_word*)lf[21]+1)):(C_word)C_slot(t2,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3375,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t4),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3384,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1426 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_3375(2,t6,C_SCHEME_UNDEFINED);}}

/* k3382 in create-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1427 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[35],lf[150],lf[151]);}

/* k3373 in create-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1428 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3348r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3348r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3348r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[149]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3352,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k3350 in with-output-to-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3352,2,t0,t1);}
t2=C_mutate((C_word*)lf[149]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3358,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1411 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a3357 in k3350 in with-output-to-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_3358r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3358r(t0,t1,t2);}}

static void C_ccall f_3358r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3362,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1413 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3360 in a3357 in k3350 in with-output-to-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[149]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3328r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3328r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3328r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[147]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3332,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k3330 in with-input-from-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=C_mutate((C_word*)lf[147]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3338,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1401 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a3337 in k3330 in with-input-from-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_3338r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3338r(t0,t1,t2);}}

static void C_ccall f_3338r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3342,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1403 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3340 in a3337 in k3330 in with-input-from-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[147]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3304r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3304r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3304r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3308,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k3306 in call-with-output-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3313,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3319,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1391 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3318 in k3306 in call-with-output-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3319r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3319r(t0,t1,t2);}}

static void C_ccall f_3319r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3323,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1394 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3321 in a3318 in k3306 in call-with-output-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3312 in k3306 in call-with-output-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3313,2,t0,t1);}
/* posixwin.scm: 1392 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3280r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3280r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3280r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3284,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k3282 in call-with-input-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3289,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3295,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1383 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3294 in k3282 in call-with-input-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3295r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3295r(t0,t1,t2);}}

static void C_ccall f_3295r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3299,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1386 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3297 in a3294 in k3282 in call-with-input-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3288 in k3282 in call-with-input-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3289,2,t0,t1);}
/* posixwin.scm: 1384 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3261,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3265,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1370 ##sys#check-port */
t4=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[140]);}

/* k3263 in close-input-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3268,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1372 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3266 in k3263 in close-input-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 1373 ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[35],lf[140],lf[141],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_3225r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3225r(t0,t1,t2,t3);}}

static void C_ccall f_3225r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[139]);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):lf[137]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3239,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[137]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3246,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1365 ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=(C_word)C_eqp(t6,lf[138]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3256,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1366 ##sys#make-c-string */
t11=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t2);}
else{
/* posixwin.scm: 1367 badmode */
f_3165(t7,t6);}}}

/* k3254 in open-output-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3256,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3239(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k3244 in open-output-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3246,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3239(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k3237 in open-output-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1362 check */
f_3171(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_3189r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3189r(t0,t1,t2,t3);}}

static void C_ccall f_3189r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[136]);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):lf[137]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3203,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[137]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3210,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1355 ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=(C_word)C_eqp(t6,lf[138]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3220,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1356 ##sys#make-c-string */
t11=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t2);}
else{
/* posixwin.scm: 1357 badmode */
f_3165(t7,t6);}}}

/* k3218 in open-input-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3203(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k3208 in open-input-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3210,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3203(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k3201 in open-input-pipe in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1352 check */
f_3171(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_3171(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3171,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3175,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1342 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3173 in check in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3175,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1344 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[35],lf[132],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3187,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1345 ##sys#make-port */
t3=*((C_word*)lf[133]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[134]+1),lf[135],lf[82]);}}

/* k3185 in k3173 in check in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_3165(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3165,NULL,2,t1,t2);}
/* posixwin.scm: 1340 ##sys#error */
t3=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[131],t2);}

/* canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2796,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[118]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2803,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2936,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1279 cwd */
t8=((C_word*)t0)[5];
f_2740(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t4,a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3143,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1281 sref */
t10=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_2942(t9,C_SCHEME_FALSE);}}}

/* k3141 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_2942(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2942,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2949,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2953,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1283 cwd */
t4=((C_word*)t0)[6];
f_2740(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[7]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1286 cwd */
t5=((C_word*)t0)[6];
f_2740(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3118,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3129,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1287 sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[7],C_fix(0));}}}

/* k3127 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1287 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k3116 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3118,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3125,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1288 sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[4];
f_2972(t2,C_SCHEME_FALSE);}}

/* k3123 in k3116 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_2972(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2972(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2972,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2995,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1290 cwd */
t4=((C_word*)t0)[5];
f_2740(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[7]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3008,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1296 cwd */
t5=((C_word*)t0)[5];
f_2740(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3090,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3111,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1297 sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[7],C_fix(0));}}}

/* k3109 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1297 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3088 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3090,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3107,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1298 sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3014(t2,C_SCHEME_FALSE);}}

/* k3105 in k3088 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1298 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3094 in k3088 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3096,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3103,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1299 sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3014(t2,C_SCHEME_FALSE);}}

/* k3101 in k3094 in k3088 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3014(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_3014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3014,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
f_2803(2,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3020,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3087,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1301 sref */
t5=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[7],C_fix(0));}}

/* k3085 in k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1301 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k3064 in k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3066,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3072,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3083,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1302 sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3020(2,t2,C_SCHEME_FALSE);}}

/* k3081 in k3064 in k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1302 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3070 in k3064 in k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3072,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1303 sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3020(2,t2,C_SCHEME_FALSE);}}

/* k3077 in k3070 in k3064 in k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1303 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3018 in k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3020,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1305 ##sys#substring */
t3=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],C_fix(1),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1309 sref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],C_fix(0));}}

/* k3061 in k3018 in k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3063,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3048,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1311 cwd */
t6=((C_word*)t0)[2];
f_2740(t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1314 cwd */
t5=((C_word*)t0)[2];
f_2740(t5,t4);}}

/* k3057 in k3061 in k3018 in k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1314 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[129],((C_word*)t0)[2]);}

/* k3050 in k3061 in k3018 in k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1311 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3046 in k3061 in k3018 in k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1310 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3025 in k3018 in k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3031,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1307 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(3),t3);}

/* k3029 in k3025 in k3018 in k3012 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1304 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[128],t1);}

/* k3006 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1296 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[127],((C_word*)t0)[2]);}

/* k2993 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1290 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(3));}

/* k2977 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1292 user */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2981 in k2977 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2987,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1293 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k2985 in k2981 in k2977 in k2970 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1289 sappend */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[126],((C_word*)t0)[2],t1);}

/* k2964 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1286 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[125],((C_word*)t0)[2]);}

/* k2951 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1283 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k2947 in k2940 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1282 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2934 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1279 sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[124]);}

/* k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2922,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_block_size(t1);
/* posixwin.scm: 1315 ##sys#substring */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t1,C_fix(3),t4);}

/* k2920 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-split */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[123]);}

/* k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2810,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_2812(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2812(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2812,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* posixwin.scm: 1317 null? */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2817 in loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2819,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2825,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1318 null? */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2891,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* posixwin.scm: 1329 string=? */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[122],t5);}}

/* k2892 in k2817 in loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2894,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2891(t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* posixwin.scm: 1331 string=? */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[121],t3);}}

/* k2901 in k2892 in k2817 in loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2903,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2891(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_2891(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k2889 in k2817 in loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1327 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2812(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2823 in k2817 in loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2825,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1319 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],((C_word*)t0)[6],C_fix(0),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2872,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixwin.scm: 1320 sref */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[6],t4);}}

/* k2870 in k2823 in k2817 in loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1322 ##sys#substring */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],C_fix(0),C_fix(3));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1325 ##sys#substring */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],C_fix(0),C_fix(3));}}

/* k2858 in k2870 in k2823 in k2817 in loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2864,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2868,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1326 reverse */
t4=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2866 in k2858 in k2870 in k2823 in k2817 in loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1326 isperse */
f_2724(((C_word*)t0)[2],t1);}

/* k2862 in k2858 in k2870 in k2823 in k2817 in loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1324 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2839 in k2870 in k2823 in k2817 in loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2845,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2849,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[119],((C_word*)t0)[2]);
/* posixwin.scm: 1323 reverse */
t5=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k2847 in k2839 in k2870 in k2823 in k2817 in loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1323 isperse */
f_2724(((C_word*)t0)[2],t1);}

/* k2843 in k2839 in k2870 in k2823 in k2817 in loop in k2808 in k2801 in canonical-path in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1321 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cwd in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2740,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2747,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2749,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[117]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a2748 in cwd in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2749,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2755,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2773,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[116]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a2772 in a2748 in cwd in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2779,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2785,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a2784 in a2772 in a2748 in cwd in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2785r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2785r(t0,t1,t2);}}

static void C_ccall f_2785r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2791,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k367370 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a2790 in a2784 in a2772 in a2748 in cwd in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2778 in a2772 in a2748 in cwd in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2779,2,t0,t1);}
/* posixwin.scm: 1274 cw */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a2754 in a2748 in cwd in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2755,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2761,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k367370 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a2760 in a2754 in a2748 in cwd in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2761,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[114]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[115]);}

/* k2745 in cwd in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* isperse in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2724(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2724,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[112]);}

/* current-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2680r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2680r(t0,t1,t2);}}

static void C_ccall f_2680r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(t4)){
/* posixwin.scm: 1252 change-directory */
t5=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2693,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1253 make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}}

/* k2691 in current-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2693,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2696,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1255 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2694 in k2691 in current-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* posixwin.scm: 1257 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
/* posixwin.scm: 1258 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[35],lf[102],lf[105]);}}

/* directory? in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2653,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[103]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2660,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2674,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2678,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1245 ##sys#expand-home-path */
t7=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k2676 in directory? in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1245 ##sys#platform-fixup-pathname */
t2=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2672 in directory? in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1244 ##sys#file-info */
t2=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2658 in directory? in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_2496r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2496r(t0,t1,t2);}}

static void C_ccall f_2496r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2498,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2604,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec258300 */
t6=t5;
f_2604(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?259298 */
t8=t4;
f_2599(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body256264 */
t10=t3;
f_2498(t10,t1,t6,t8);}}}

/* def-spec258 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2604(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2604,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2612,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1215 current-directory */
t3=*((C_word*)lf[102]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2610 in def-spec258 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?259298 */
t2=((C_word*)t0)[3];
f_2599(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?259 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2599,NULL,3,t0,t1,t2);}
/* body256264 */
t3=((C_word*)t0)[2];
f_2498(t3,t1,t2,C_SCHEME_FALSE);}

/* body256 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2498(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2498,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[99]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2505,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1217 make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}

/* k2503 in body256 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1218 ##sys#make-pointer */
t3=*((C_word*)lf[101]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2506 in k2503 in body256 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1219 ##sys#make-pointer */
t3=*((C_word*)lf[101]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2509 in k2506 in k2503 in body256 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2598,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1220 ##sys#expand-home-path */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k2596 in k2509 in k2506 in k2503 in body256 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1220 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2513 in k2509 in k2506 in k2503 in body256 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2524,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1223 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2532(t6,((C_word*)t0)[6]);}}

/* loop in k2513 in k2509 in k2506 in k2503 in body256 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2532,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1232 ##sys#substring */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k2540 in loop in k2513 in k2509 in k2506 in k2503 in body256 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2542,2,t0,t1);}
t2=(C_word)C_subchar(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_subchar(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2554,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_2554(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
t9=(C_truep(t8)?(C_word)C_eqp(((C_word*)t0)[5],C_fix(2)):C_SCHEME_FALSE);
t10=t5;
f_2554(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t7=t5;
f_2554(t7,C_SCHEME_FALSE);}}

/* k2552 in k2540 in loop in k2513 in k2509 in k2506 in k2503 in body256 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2554(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2554,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1239 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2532(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1240 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2532(t3,t2);}}

/* k2562 in k2552 in k2540 in loop in k2513 in k2509 in k2506 in k2503 in body256 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2564,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2522 in k2513 in k2509 in k2506 in k2503 in body256 in directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1224 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[99],lf[100],((C_word*)t0)[2]);}

/* delete-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2469,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[96]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2490,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2494,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1207 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2492 in delete-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1207 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2488 in delete-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2490,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1208 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2480 in k2488 in delete-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1209 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[96],lf[97],((C_word*)t0)[2]);}

/* change-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2442,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[94]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2463,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2467,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1200 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2465 in change-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1200 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2461 in change-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2463,2,t0,t1);}
t2=(C_word)C_chdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1201 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2453 in k2461 in change-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1202 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[94],lf[95],((C_word*)t0)[2]);}

/* create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2323r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2323r(t0,t1,t2,t3);}}

static void C_ccall f_2323r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[88]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2333,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1192 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k2331 in create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
if(C_truep(((C_word*)t0)[3])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1181 string-split */
t3=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[93]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2428,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1164 ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k2426 in k2331 in create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2428,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1165 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2418 in k2426 in k2331 in create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1166 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[88],lf[89],((C_word*)t0)[2]);}

/* k2337 in k2331 in create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2339,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_slot(t1,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2351,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2351(t9,((C_word*)t0)[2],t5);}

/* loop206 in k2337 in k2331 in create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2351(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2351,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2365,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1185 string-append */
t5=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)((C_word*)t0)[3])[1],lf[91],t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2363 in loop206 in k2337 in k2331 in create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2365,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=((C_word*)((C_word*)t0)[5])[1];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2378,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2398,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1170 file-exists? */
t7=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}

/* k2396 in k2363 in loop206 in k2337 in k2331 in create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2398,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1171 ##sys#file-info */
t3=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2378(t2,C_SCHEME_FALSE);}}

/* k2399 in k2396 in k2363 in loop206 in k2337 in k2331 in create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
f_2378(t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
f_2378(t2,C_SCHEME_FALSE);}}

/* k2376 in k2363 in loop206 in k2337 in k2331 in create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2378(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2378,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2368(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1164 ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k2393 in k2376 in k2363 in loop206 in k2337 in k2331 in create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_2368(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1165 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2385 in k2393 in k2376 in k2363 in loop206 in k2337 in k2331 in create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1166 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[88],lf[89],((C_word*)t0)[2]);}

/* k2366 in k2363 in loop206 in k2337 in k2331 in create-directory in k2319 in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2351(t3,((C_word*)t0)[2],t2);}

/* set-file-position! in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2261r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2261r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2261r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[80]);
t8=(C_word)C_i_check_exact_2(t6,lf[80]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2274,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_negativep(t3))){
/* posixwin.scm: 1134 ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[85],lf[80],lf[86],t3,t2);}
else{
t10=t9;
f_2274(2,t10,C_SCHEME_UNDEFINED);}}

/* k2272 in set-file-position! in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1135 port? */
t4=*((C_word*)lf[84]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k2284 in k2272 in set-file-position! in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[82]);
t4=((C_word*)t0)[4];
f_2280(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_2280(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 1141 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[44],lf[80],lf[83],((C_word*)t0)[5]);}}}

/* k2278 in k2272 in set-file-position! in k2257 in k2253 in k2249 in k2245 in k2241 in k2237 in k2233 in k2229 in k2225 in k2221 in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1142 posix-error */
t2=lf[3];
f_1856(7,t2,((C_word*)t0)[4],lf[35],lf[80],lf[81],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* stat-type in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2212(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2212,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2214,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_2214 in stat-type in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2214,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* symbolic-link? in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2207,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[68]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2184,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[66]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2191,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2205,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1104 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2203 in regular-file? in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1104 ##sys#file-info */
t2=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2189 in regular-file? in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2178,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2182,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1100 ##sys#stat */
f_2086(t3,t2);}

/* k2180 in file-permissions in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2172,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2176,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1099 ##sys#stat */
f_2086(t3,t2);}

/* k2174 in file-owner in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2166,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2170,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1098 ##sys#stat */
f_2086(t3,t2);}

/* k2168 in file-change-time in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2170,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2160,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2164,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1097 ##sys#stat */
f_2086(t3,t2);}

/* k2162 in file-access-time in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2164,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2154,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2158,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1096 ##sys#stat */
f_2086(t3,t2);}

/* k2156 in file-modification-time in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2158,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2148,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2152,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1095 ##sys#stat */
f_2086(t3,t2);}

/* k2150 in file-size in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2124r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2124r(t0,t1,t2,t3);}}

static void C_ccall f_2124r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2131,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1089 ##sys#stat */
f_2086(t6,t2);}

/* k2129 in file-stat in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2131,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_fcall f_2086(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2086,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2090,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_2090(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2115,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2119,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1082 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1083 ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[44],lf[58],t2);}}}

/* k2117 in ##sys#stat in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1082 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2113 in ##sys#stat in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2090(2,t2,(C_word)C_stat(t1));}

/* k2088 in ##sys#stat in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2090,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1085 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2097 in k2088 in ##sys#stat in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1086 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[35],lf[57],((C_word*)t0)[2]);}

/* file-mkstemp in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2048,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[50]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1051 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2053 in file-mkstemp in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1053 string-length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k2056 in k2053 in file-mkstemp in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1055 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2061(2,t4,C_SCHEME_UNDEFINED);}}

/* k2076 in k2056 in k2053 in file-mkstemp in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1056 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[50],lf[52],((C_word*)t0)[2]);}

/* k2059 in k2056 in k2053 in file-mkstemp in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1057 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k2066 in k2059 in k2056 in k2053 in file-mkstemp in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1057 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2006r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2006r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2006r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[46]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2013,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_2013(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1038 ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[44],lf[46],lf[48],t3);}}

/* k2011 in file-write in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2013,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[46]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2022,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2028,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1043 ##sys#update-errno */
t9=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_2022(2,t8,C_SCHEME_UNDEFINED);}}

/* k2026 in k2011 in file-write in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1044 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[46],lf[47],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2020 in k2011 in file-write in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1961r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1961r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1961r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[42]);
t6=(C_word)C_i_check_exact_2(t3,lf[42]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1971,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1971(2,t8,(C_word)C_slot(t4,C_fix(0)));}
else{
/* posixwin.scm: 1025 make-string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k1969 in file-read in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1974(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1027 ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[44],lf[42],lf[45],t1);}}

/* k1972 in k1969 in file-read in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1974,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1977,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1030 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1977(2,t5,C_SCHEME_UNDEFINED);}}

/* k1984 in k1972 in k1969 in file-read in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1031 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[42],lf[43],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1975 in k1972 in k1969 in file-read in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1977,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1943,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[39]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1956,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1017 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1954 in file-close in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1018 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[39],lf[40],((C_word*)t0)[2]);}

/* file-open in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1902r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1902r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1902r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[34]);
t8=(C_word)C_i_check_exact_2(t3,lf[34]);
t9=(C_word)C_i_check_exact_2(t6,lf[34]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1919,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1935,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1007 ##sys#expand-home-path */
t12=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k1933 in file-open in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1007 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1917 in file-open in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1919,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1922,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1009 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1922(2,t5,C_SCHEME_UNDEFINED);}}

/* k1926 in k1917 in file-open in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1010 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[35],lf[34],lf[36],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1920 in k1917 in file-open in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1856r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1856r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1856r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1860,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 938  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1858 in posix-error in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1871,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,(C_word)stub12(t4,t1),C_fix(0));}

/* k1869 in k1858 in posix-error in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 939  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k1865 in k1858 in posix-error in k1847 in k1844 in k1841 in k1838 in k1835 in k1832 in k1829 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[456] = {
{"toplevel:posixwin_scm",(void*)C_posix_toplevel},
{"f_1831:posixwin_scm",(void*)f_1831},
{"f_1834:posixwin_scm",(void*)f_1834},
{"f_1837:posixwin_scm",(void*)f_1837},
{"f_1840:posixwin_scm",(void*)f_1840},
{"f_1843:posixwin_scm",(void*)f_1843},
{"f_1846:posixwin_scm",(void*)f_1846},
{"f_1849:posixwin_scm",(void*)f_1849},
{"f_2223:posixwin_scm",(void*)f_2223},
{"f_2227:posixwin_scm",(void*)f_2227},
{"f_2231:posixwin_scm",(void*)f_2231},
{"f_2235:posixwin_scm",(void*)f_2235},
{"f_2239:posixwin_scm",(void*)f_2239},
{"f_2243:posixwin_scm",(void*)f_2243},
{"f_2247:posixwin_scm",(void*)f_2247},
{"f_2251:posixwin_scm",(void*)f_2251},
{"f_2255:posixwin_scm",(void*)f_2255},
{"f_2259:posixwin_scm",(void*)f_2259},
{"f_5667:posixwin_scm",(void*)f_5667},
{"f_5683:posixwin_scm",(void*)f_5683},
{"f_5671:posixwin_scm",(void*)f_5671},
{"f_5674:posixwin_scm",(void*)f_5674},
{"f_2321:posixwin_scm",(void*)f_2321},
{"f_3435:posixwin_scm",(void*)f_3435},
{"f_5648:posixwin_scm",(void*)f_5648},
{"f_5645:posixwin_scm",(void*)f_5645},
{"f_5638:posixwin_scm",(void*)f_5638},
{"f_5632:posixwin_scm",(void*)f_5632},
{"f_5626:posixwin_scm",(void*)f_5626},
{"f_5620:posixwin_scm",(void*)f_5620},
{"f_5614:posixwin_scm",(void*)f_5614},
{"f_5608:posixwin_scm",(void*)f_5608},
{"f_5602:posixwin_scm",(void*)f_5602},
{"f_5596:posixwin_scm",(void*)f_5596},
{"f_5590:posixwin_scm",(void*)f_5590},
{"f_5584:posixwin_scm",(void*)f_5584},
{"f_5578:posixwin_scm",(void*)f_5578},
{"f_5572:posixwin_scm",(void*)f_5572},
{"f_5566:posixwin_scm",(void*)f_5566},
{"f_5560:posixwin_scm",(void*)f_5560},
{"f_5554:posixwin_scm",(void*)f_5554},
{"f_5548:posixwin_scm",(void*)f_5548},
{"f_5542:posixwin_scm",(void*)f_5542},
{"f_5536:posixwin_scm",(void*)f_5536},
{"f_5530:posixwin_scm",(void*)f_5530},
{"f_5524:posixwin_scm",(void*)f_5524},
{"f_5518:posixwin_scm",(void*)f_5518},
{"f_5512:posixwin_scm",(void*)f_5512},
{"f_5506:posixwin_scm",(void*)f_5506},
{"f_5500:posixwin_scm",(void*)f_5500},
{"f_5494:posixwin_scm",(void*)f_5494},
{"f_5488:posixwin_scm",(void*)f_5488},
{"f_5482:posixwin_scm",(void*)f_5482},
{"f_5476:posixwin_scm",(void*)f_5476},
{"f_5470:posixwin_scm",(void*)f_5470},
{"f_5464:posixwin_scm",(void*)f_5464},
{"f_5458:posixwin_scm",(void*)f_5458},
{"f_5452:posixwin_scm",(void*)f_5452},
{"f_5446:posixwin_scm",(void*)f_5446},
{"f_5440:posixwin_scm",(void*)f_5440},
{"f_5434:posixwin_scm",(void*)f_5434},
{"f_5428:posixwin_scm",(void*)f_5428},
{"f_5422:posixwin_scm",(void*)f_5422},
{"f_5416:posixwin_scm",(void*)f_5416},
{"f_5410:posixwin_scm",(void*)f_5410},
{"f_5404:posixwin_scm",(void*)f_5404},
{"f_5398:posixwin_scm",(void*)f_5398},
{"f_5392:posixwin_scm",(void*)f_5392},
{"f_5386:posixwin_scm",(void*)f_5386},
{"f_5169:posixwin_scm",(void*)f_5169},
{"f_5320:posixwin_scm",(void*)f_5320},
{"f_5326:posixwin_scm",(void*)f_5326},
{"f_5315:posixwin_scm",(void*)f_5315},
{"f_5310:posixwin_scm",(void*)f_5310},
{"f_5171:posixwin_scm",(void*)f_5171},
{"f_5297:posixwin_scm",(void*)f_5297},
{"f_5305:posixwin_scm",(void*)f_5305},
{"f_5178:posixwin_scm",(void*)f_5178},
{"f_5285:posixwin_scm",(void*)f_5285},
{"f_5188:posixwin_scm",(void*)f_5188},
{"f_5190:posixwin_scm",(void*)f_5190},
{"f_5209:posixwin_scm",(void*)f_5209},
{"f_5271:posixwin_scm",(void*)f_5271},
{"f_5278:posixwin_scm",(void*)f_5278},
{"f_5265:posixwin_scm",(void*)f_5265},
{"f_5224:posixwin_scm",(void*)f_5224},
{"f_5255:posixwin_scm",(void*)f_5255},
{"f_5241:posixwin_scm",(void*)f_5241},
{"f_5253:posixwin_scm",(void*)f_5253},
{"f_5249:posixwin_scm",(void*)f_5249},
{"f_5236:posixwin_scm",(void*)f_5236},
{"f_5234:posixwin_scm",(void*)f_5234},
{"f_5289:posixwin_scm",(void*)f_5289},
{"f_5154:posixwin_scm",(void*)f_5154},
{"f_5164:posixwin_scm",(void*)f_5164},
{"f_5123:posixwin_scm",(void*)f_5123},
{"f_5149:posixwin_scm",(void*)f_5149},
{"f_5134:posixwin_scm",(void*)f_5134},
{"f_5138:posixwin_scm",(void*)f_5138},
{"f_5142:posixwin_scm",(void*)f_5142},
{"f_5146:posixwin_scm",(void*)f_5146},
{"f_5111:posixwin_scm",(void*)f_5111},
{"f_5108:posixwin_scm",(void*)f_5108},
{"f_5051:posixwin_scm",(void*)f_5051},
{"f_5075:posixwin_scm",(void*)f_5075},
{"f_5085:posixwin_scm",(void*)f_5085},
{"f_5069:posixwin_scm",(void*)f_5069},
{"f_5039:posixwin_scm",(void*)f_5039},
{"f_4962:posixwin_scm",(void*)f_4962},
{"f_4979:posixwin_scm",(void*)f_4979},
{"f_4974:posixwin_scm",(void*)f_4974},
{"f_4969:posixwin_scm",(void*)f_4969},
{"f_4964:posixwin_scm",(void*)f_4964},
{"f_4885:posixwin_scm",(void*)f_4885},
{"f_4902:posixwin_scm",(void*)f_4902},
{"f_4897:posixwin_scm",(void*)f_4897},
{"f_4892:posixwin_scm",(void*)f_4892},
{"f_4887:posixwin_scm",(void*)f_4887},
{"f_4807:posixwin_scm",(void*)f_4807},
{"f_4879:posixwin_scm",(void*)f_4879},
{"f_4883:posixwin_scm",(void*)f_4883},
{"f_4844:posixwin_scm",(void*)f_4844},
{"f_4858:posixwin_scm",(void*)f_4858},
{"f_4852:posixwin_scm",(void*)f_4852},
{"f_4809:posixwin_scm",(void*)f_4809},
{"f_4818:posixwin_scm",(void*)f_4818},
{"f_4711:posixwin_scm",(void*)f_4711},
{"f_4790:posixwin_scm",(void*)f_4790},
{"f_4718:posixwin_scm",(void*)f_4718},
{"f_4758:posixwin_scm",(void*)f_4758},
{"f_4762:posixwin_scm",(void*)f_4762},
{"f_4766:posixwin_scm",(void*)f_4766},
{"f_4770:posixwin_scm",(void*)f_4770},
{"f_4774:posixwin_scm",(void*)f_4774},
{"f_4665:posixwin_scm",(void*)f_4665},
{"f_4669:posixwin_scm",(void*)f_4669},
{"f_4751:posixwin_scm",(void*)f_4751},
{"f_4731:posixwin_scm",(void*)f_4731},
{"f_4735:posixwin_scm",(void*)f_4735},
{"f_4739:posixwin_scm",(void*)f_4739},
{"f_4631:posixwin_scm",(void*)f_4631},
{"f_4648:posixwin_scm",(void*)f_4648},
{"f_4652:posixwin_scm",(void*)f_4652},
{"f_4625:posixwin_scm",(void*)f_4625},
{"f_4604:posixwin_scm",(void*)f_4604},
{"f_4608:posixwin_scm",(void*)f_4608},
{"f_4620:posixwin_scm",(void*)f_4620},
{"f_4601:posixwin_scm",(void*)f_4601},
{"f_4517:posixwin_scm",(void*)f_4517},
{"f_4541:posixwin_scm",(void*)f_4541},
{"f_4536:posixwin_scm",(void*)f_4536},
{"f_4531:posixwin_scm",(void*)f_4531},
{"f_4519:posixwin_scm",(void*)f_4519},
{"f_4523:posixwin_scm",(void*)f_4523},
{"f_4433:posixwin_scm",(void*)f_4433},
{"f_4457:posixwin_scm",(void*)f_4457},
{"f_4452:posixwin_scm",(void*)f_4452},
{"f_4447:posixwin_scm",(void*)f_4447},
{"f_4435:posixwin_scm",(void*)f_4435},
{"f_4439:posixwin_scm",(void*)f_4439},
{"f_4418:posixwin_scm",(void*)f_4418},
{"f_4422:posixwin_scm",(void*)f_4422},
{"f_4382:posixwin_scm",(void*)f_4382},
{"f_4389:posixwin_scm",(void*)f_4389},
{"f_4409:posixwin_scm",(void*)f_4409},
{"f_4395:posixwin_scm",(void*)f_4395},
{"f_4398:posixwin_scm",(void*)f_4398},
{"f_4405:posixwin_scm",(void*)f_4405},
{"f_4332:posixwin_scm",(void*)f_4332},
{"f_4344:posixwin_scm",(void*)f_4344},
{"f_4363:posixwin_scm",(void*)f_4363},
{"f_4326:posixwin_scm",(void*)f_4326},
{"f_4320:posixwin_scm",(void*)f_4320},
{"f_4241:posixwin_scm",(void*)f_4241},
{"f_4284:posixwin_scm",(void*)f_4284},
{"f_4315:posixwin_scm",(void*)f_4315},
{"f_4312:posixwin_scm",(void*)f_4312},
{"f_4246:posixwin_scm",(void*)f_4246},
{"f_4250:posixwin_scm",(void*)f_4250},
{"f_4255:posixwin_scm",(void*)f_4255},
{"f_4279:posixwin_scm",(void*)f_4279},
{"f_4268:posixwin_scm",(void*)f_4268},
{"f_4129:posixwin_scm",(void*)f_4129},
{"f_4135:posixwin_scm",(void*)f_4135},
{"f_4156:posixwin_scm",(void*)f_4156},
{"f_4230:posixwin_scm",(void*)f_4230},
{"f_4160:posixwin_scm",(void*)f_4160},
{"f_4163:posixwin_scm",(void*)f_4163},
{"f_4170:posixwin_scm",(void*)f_4170},
{"f_4172:posixwin_scm",(void*)f_4172},
{"f_4189:posixwin_scm",(void*)f_4189},
{"f_4199:posixwin_scm",(void*)f_4199},
{"f_4203:posixwin_scm",(void*)f_4203},
{"f_4150:posixwin_scm",(void*)f_4150},
{"f_4070:posixwin_scm",(void*)f_4070},
{"f_4074:posixwin_scm",(void*)f_4074},
{"f_4080:posixwin_scm",(void*)f_4080},
{"f_4064:posixwin_scm",(void*)f_4064},
{"f_4068:posixwin_scm",(void*)f_4068},
{"f_4048:posixwin_scm",(void*)f_4048},
{"f_4040:posixwin_scm",(void*)f_4040},
{"f_4025:posixwin_scm",(void*)f_4025},
{"f_4029:posixwin_scm",(void*)f_4029},
{"f_3965:posixwin_scm",(void*)f_3965},
{"f_3972:posixwin_scm",(void*)f_3972},
{"f_3994:posixwin_scm",(void*)f_3994},
{"f_3991:posixwin_scm",(void*)f_3991},
{"f_3981:posixwin_scm",(void*)f_3981},
{"f_3914:posixwin_scm",(void*)f_3914},
{"f_3918:posixwin_scm",(void*)f_3918},
{"f_3921:posixwin_scm",(void*)f_3921},
{"f_3882:posixwin_scm",(void*)f_3882},
{"f_3886:posixwin_scm",(void*)f_3886},
{"f_3855:posixwin_scm",(void*)f_3855},
{"f_3859:posixwin_scm",(void*)f_3859},
{"f_3836:posixwin_scm",(void*)f_3836},
{"f_3770:posixwin_scm",(void*)f_3770},
{"f_3776:posixwin_scm",(void*)f_3776},
{"f_3780:posixwin_scm",(void*)f_3780},
{"f_3788:posixwin_scm",(void*)f_3788},
{"f_3814:posixwin_scm",(void*)f_3814},
{"f_3818:posixwin_scm",(void*)f_3818},
{"f_3806:posixwin_scm",(void*)f_3806},
{"f_3755:posixwin_scm",(void*)f_3755},
{"f_3763:posixwin_scm",(void*)f_3763},
{"f_3738:posixwin_scm",(void*)f_3738},
{"f_3749:posixwin_scm",(void*)f_3749},
{"f_3753:posixwin_scm",(void*)f_3753},
{"f_3708:posixwin_scm",(void*)f_3708},
{"f_3715:posixwin_scm",(void*)f_3715},
{"f_3724:posixwin_scm",(void*)f_3724},
{"f_3718:posixwin_scm",(void*)f_3718},
{"f_3673:posixwin_scm",(void*)f_3673},
{"f_3677:posixwin_scm",(void*)f_3677},
{"f_3706:posixwin_scm",(void*)f_3706},
{"f_3692:posixwin_scm",(void*)f_3692},
{"f_3686:posixwin_scm",(void*)f_3686},
{"f_3659:posixwin_scm",(void*)f_3659},
{"f_3671:posixwin_scm",(void*)f_3671},
{"f_3645:posixwin_scm",(void*)f_3645},
{"f_3657:posixwin_scm",(void*)f_3657},
{"f_3627:posixwin_scm",(void*)f_3627},
{"f_3631:posixwin_scm",(void*)f_3631},
{"f_3643:posixwin_scm",(void*)f_3643},
{"f_3590:posixwin_scm",(void*)f_3590},
{"f_3598:posixwin_scm",(void*)f_3598},
{"f_3581:posixwin_scm",(void*)f_3581},
{"f_3575:posixwin_scm",(void*)f_3575},
{"f_3569:posixwin_scm",(void*)f_3569},
{"f_3545:posixwin_scm",(void*)f_3545},
{"f_3567:posixwin_scm",(void*)f_3567},
{"f_3563:posixwin_scm",(void*)f_3563},
{"f_3555:posixwin_scm",(void*)f_3555},
{"f_3515:posixwin_scm",(void*)f_3515},
{"f_3543:posixwin_scm",(void*)f_3543},
{"f_3539:posixwin_scm",(void*)f_3539},
{"f_3531:posixwin_scm",(void*)f_3531},
{"f_3459:posixwin_scm",(void*)f_3459},
{"f_3469:posixwin_scm",(void*)f_3469},
{"f_3446:posixwin_scm",(void*)f_3446},
{"f_3437:posixwin_scm",(void*)f_3437},
{"f_3368:posixwin_scm",(void*)f_3368},
{"f_3384:posixwin_scm",(void*)f_3384},
{"f_3375:posixwin_scm",(void*)f_3375},
{"f_3348:posixwin_scm",(void*)f_3348},
{"f_3352:posixwin_scm",(void*)f_3352},
{"f_3358:posixwin_scm",(void*)f_3358},
{"f_3362:posixwin_scm",(void*)f_3362},
{"f_3328:posixwin_scm",(void*)f_3328},
{"f_3332:posixwin_scm",(void*)f_3332},
{"f_3338:posixwin_scm",(void*)f_3338},
{"f_3342:posixwin_scm",(void*)f_3342},
{"f_3304:posixwin_scm",(void*)f_3304},
{"f_3308:posixwin_scm",(void*)f_3308},
{"f_3319:posixwin_scm",(void*)f_3319},
{"f_3323:posixwin_scm",(void*)f_3323},
{"f_3313:posixwin_scm",(void*)f_3313},
{"f_3280:posixwin_scm",(void*)f_3280},
{"f_3284:posixwin_scm",(void*)f_3284},
{"f_3295:posixwin_scm",(void*)f_3295},
{"f_3299:posixwin_scm",(void*)f_3299},
{"f_3289:posixwin_scm",(void*)f_3289},
{"f_3261:posixwin_scm",(void*)f_3261},
{"f_3265:posixwin_scm",(void*)f_3265},
{"f_3268:posixwin_scm",(void*)f_3268},
{"f_3225:posixwin_scm",(void*)f_3225},
{"f_3256:posixwin_scm",(void*)f_3256},
{"f_3246:posixwin_scm",(void*)f_3246},
{"f_3239:posixwin_scm",(void*)f_3239},
{"f_3189:posixwin_scm",(void*)f_3189},
{"f_3220:posixwin_scm",(void*)f_3220},
{"f_3210:posixwin_scm",(void*)f_3210},
{"f_3203:posixwin_scm",(void*)f_3203},
{"f_3171:posixwin_scm",(void*)f_3171},
{"f_3175:posixwin_scm",(void*)f_3175},
{"f_3187:posixwin_scm",(void*)f_3187},
{"f_3165:posixwin_scm",(void*)f_3165},
{"f_2796:posixwin_scm",(void*)f_2796},
{"f_3143:posixwin_scm",(void*)f_3143},
{"f_2942:posixwin_scm",(void*)f_2942},
{"f_3129:posixwin_scm",(void*)f_3129},
{"f_3118:posixwin_scm",(void*)f_3118},
{"f_3125:posixwin_scm",(void*)f_3125},
{"f_2972:posixwin_scm",(void*)f_2972},
{"f_3111:posixwin_scm",(void*)f_3111},
{"f_3090:posixwin_scm",(void*)f_3090},
{"f_3107:posixwin_scm",(void*)f_3107},
{"f_3096:posixwin_scm",(void*)f_3096},
{"f_3103:posixwin_scm",(void*)f_3103},
{"f_3014:posixwin_scm",(void*)f_3014},
{"f_3087:posixwin_scm",(void*)f_3087},
{"f_3066:posixwin_scm",(void*)f_3066},
{"f_3083:posixwin_scm",(void*)f_3083},
{"f_3072:posixwin_scm",(void*)f_3072},
{"f_3079:posixwin_scm",(void*)f_3079},
{"f_3020:posixwin_scm",(void*)f_3020},
{"f_3063:posixwin_scm",(void*)f_3063},
{"f_3059:posixwin_scm",(void*)f_3059},
{"f_3052:posixwin_scm",(void*)f_3052},
{"f_3048:posixwin_scm",(void*)f_3048},
{"f_3027:posixwin_scm",(void*)f_3027},
{"f_3031:posixwin_scm",(void*)f_3031},
{"f_3008:posixwin_scm",(void*)f_3008},
{"f_2995:posixwin_scm",(void*)f_2995},
{"f_2979:posixwin_scm",(void*)f_2979},
{"f_2983:posixwin_scm",(void*)f_2983},
{"f_2987:posixwin_scm",(void*)f_2987},
{"f_2966:posixwin_scm",(void*)f_2966},
{"f_2953:posixwin_scm",(void*)f_2953},
{"f_2949:posixwin_scm",(void*)f_2949},
{"f_2936:posixwin_scm",(void*)f_2936},
{"f_2803:posixwin_scm",(void*)f_2803},
{"f_2922:posixwin_scm",(void*)f_2922},
{"f_2810:posixwin_scm",(void*)f_2810},
{"f_2812:posixwin_scm",(void*)f_2812},
{"f_2819:posixwin_scm",(void*)f_2819},
{"f_2894:posixwin_scm",(void*)f_2894},
{"f_2903:posixwin_scm",(void*)f_2903},
{"f_2891:posixwin_scm",(void*)f_2891},
{"f_2825:posixwin_scm",(void*)f_2825},
{"f_2872:posixwin_scm",(void*)f_2872},
{"f_2860:posixwin_scm",(void*)f_2860},
{"f_2868:posixwin_scm",(void*)f_2868},
{"f_2864:posixwin_scm",(void*)f_2864},
{"f_2841:posixwin_scm",(void*)f_2841},
{"f_2849:posixwin_scm",(void*)f_2849},
{"f_2845:posixwin_scm",(void*)f_2845},
{"f_2740:posixwin_scm",(void*)f_2740},
{"f_2749:posixwin_scm",(void*)f_2749},
{"f_2773:posixwin_scm",(void*)f_2773},
{"f_2785:posixwin_scm",(void*)f_2785},
{"f_2791:posixwin_scm",(void*)f_2791},
{"f_2779:posixwin_scm",(void*)f_2779},
{"f_2755:posixwin_scm",(void*)f_2755},
{"f_2761:posixwin_scm",(void*)f_2761},
{"f_2747:posixwin_scm",(void*)f_2747},
{"f_2724:posixwin_scm",(void*)f_2724},
{"f_2680:posixwin_scm",(void*)f_2680},
{"f_2693:posixwin_scm",(void*)f_2693},
{"f_2696:posixwin_scm",(void*)f_2696},
{"f_2653:posixwin_scm",(void*)f_2653},
{"f_2678:posixwin_scm",(void*)f_2678},
{"f_2674:posixwin_scm",(void*)f_2674},
{"f_2660:posixwin_scm",(void*)f_2660},
{"f_2496:posixwin_scm",(void*)f_2496},
{"f_2604:posixwin_scm",(void*)f_2604},
{"f_2612:posixwin_scm",(void*)f_2612},
{"f_2599:posixwin_scm",(void*)f_2599},
{"f_2498:posixwin_scm",(void*)f_2498},
{"f_2505:posixwin_scm",(void*)f_2505},
{"f_2508:posixwin_scm",(void*)f_2508},
{"f_2511:posixwin_scm",(void*)f_2511},
{"f_2598:posixwin_scm",(void*)f_2598},
{"f_2515:posixwin_scm",(void*)f_2515},
{"f_2532:posixwin_scm",(void*)f_2532},
{"f_2542:posixwin_scm",(void*)f_2542},
{"f_2554:posixwin_scm",(void*)f_2554},
{"f_2564:posixwin_scm",(void*)f_2564},
{"f_2524:posixwin_scm",(void*)f_2524},
{"f_2469:posixwin_scm",(void*)f_2469},
{"f_2494:posixwin_scm",(void*)f_2494},
{"f_2490:posixwin_scm",(void*)f_2490},
{"f_2482:posixwin_scm",(void*)f_2482},
{"f_2442:posixwin_scm",(void*)f_2442},
{"f_2467:posixwin_scm",(void*)f_2467},
{"f_2463:posixwin_scm",(void*)f_2463},
{"f_2455:posixwin_scm",(void*)f_2455},
{"f_2323:posixwin_scm",(void*)f_2323},
{"f_2333:posixwin_scm",(void*)f_2333},
{"f_2428:posixwin_scm",(void*)f_2428},
{"f_2420:posixwin_scm",(void*)f_2420},
{"f_2339:posixwin_scm",(void*)f_2339},
{"f_2351:posixwin_scm",(void*)f_2351},
{"f_2365:posixwin_scm",(void*)f_2365},
{"f_2398:posixwin_scm",(void*)f_2398},
{"f_2401:posixwin_scm",(void*)f_2401},
{"f_2378:posixwin_scm",(void*)f_2378},
{"f_2395:posixwin_scm",(void*)f_2395},
{"f_2387:posixwin_scm",(void*)f_2387},
{"f_2368:posixwin_scm",(void*)f_2368},
{"f_2261:posixwin_scm",(void*)f_2261},
{"f_2274:posixwin_scm",(void*)f_2274},
{"f_2286:posixwin_scm",(void*)f_2286},
{"f_2280:posixwin_scm",(void*)f_2280},
{"f_2212:posixwin_scm",(void*)f_2212},
{"f_2214:posixwin_scm",(void*)f_2214},
{"f_2207:posixwin_scm",(void*)f_2207},
{"f_2184:posixwin_scm",(void*)f_2184},
{"f_2205:posixwin_scm",(void*)f_2205},
{"f_2191:posixwin_scm",(void*)f_2191},
{"f_2178:posixwin_scm",(void*)f_2178},
{"f_2182:posixwin_scm",(void*)f_2182},
{"f_2172:posixwin_scm",(void*)f_2172},
{"f_2176:posixwin_scm",(void*)f_2176},
{"f_2166:posixwin_scm",(void*)f_2166},
{"f_2170:posixwin_scm",(void*)f_2170},
{"f_2160:posixwin_scm",(void*)f_2160},
{"f_2164:posixwin_scm",(void*)f_2164},
{"f_2154:posixwin_scm",(void*)f_2154},
{"f_2158:posixwin_scm",(void*)f_2158},
{"f_2148:posixwin_scm",(void*)f_2148},
{"f_2152:posixwin_scm",(void*)f_2152},
{"f_2124:posixwin_scm",(void*)f_2124},
{"f_2131:posixwin_scm",(void*)f_2131},
{"f_2086:posixwin_scm",(void*)f_2086},
{"f_2119:posixwin_scm",(void*)f_2119},
{"f_2115:posixwin_scm",(void*)f_2115},
{"f_2090:posixwin_scm",(void*)f_2090},
{"f_2099:posixwin_scm",(void*)f_2099},
{"f_2048:posixwin_scm",(void*)f_2048},
{"f_2055:posixwin_scm",(void*)f_2055},
{"f_2058:posixwin_scm",(void*)f_2058},
{"f_2078:posixwin_scm",(void*)f_2078},
{"f_2061:posixwin_scm",(void*)f_2061},
{"f_2068:posixwin_scm",(void*)f_2068},
{"f_2006:posixwin_scm",(void*)f_2006},
{"f_2013:posixwin_scm",(void*)f_2013},
{"f_2028:posixwin_scm",(void*)f_2028},
{"f_2022:posixwin_scm",(void*)f_2022},
{"f_1961:posixwin_scm",(void*)f_1961},
{"f_1971:posixwin_scm",(void*)f_1971},
{"f_1974:posixwin_scm",(void*)f_1974},
{"f_1986:posixwin_scm",(void*)f_1986},
{"f_1977:posixwin_scm",(void*)f_1977},
{"f_1943:posixwin_scm",(void*)f_1943},
{"f_1956:posixwin_scm",(void*)f_1956},
{"f_1902:posixwin_scm",(void*)f_1902},
{"f_1935:posixwin_scm",(void*)f_1935},
{"f_1919:posixwin_scm",(void*)f_1919},
{"f_1928:posixwin_scm",(void*)f_1928},
{"f_1922:posixwin_scm",(void*)f_1922},
{"f_1856:posixwin_scm",(void*)f_1856},
{"f_1860:posixwin_scm",(void*)f_1860},
{"f_1871:posixwin_scm",(void*)f_1871},
{"f_1867:posixwin_scm",(void*)f_1867},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
