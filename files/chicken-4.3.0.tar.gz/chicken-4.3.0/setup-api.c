/* Generated from setup-api.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:03
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: setup-api.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature chicken-compile-shared -dynamic -emit-import-library setup-api -ignore-repository -output-file setup-api.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 regex utils posix srfi_13 extras ports data_structures files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[362];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,115,104,101,108,108,112,97,116,104,32,115,116,114,56,51,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,25),40,115,101,116,117,112,45,97,112,105,35,99,114,111,115,115,45,99,104,105,99,107,101,110,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,117,115,101,114,45,105,110,115,116,97,108,108,45,115,101,116,117,112,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,97,112,105,35,115,117,100,111,45,105,110,115,116,97,108,108,32,46,32,97,114,103,115,49,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,7),40,97,49,57,51,48,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,121,101,115,45,111,114,45,110,111,63,32,115,116,114,49,50,51,32,46,32,116,109,112,49,50,50,49,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,7),40,97,49,57,54,53,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,97,49,57,53,53,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,112,97,116,99,104,32,119,104,105,99,104,49,54,56,32,114,120,49,54,57,32,115,117,98,115,116,49,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,102,105,120,109,97,107,101,116,97,114,103,101,116,32,102,105,108,101,50,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,15),40,115,109,111,111,116,104,32,108,115,116,50,50,51,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,50,49,57,32,108,115,116,50,50,48,50,50,54,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,101,120,101,99,117,116,101,32,101,120,112,108,105,115,116,50,49,54,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,102,111,114,109,45,101,114,114,111,114,32,115,51,49,57,32,112,51,50,48,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,108,105,110,101,45,101,114,114,111,114,32,115,51,51,48,32,112,51,51,49,32,110,51,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,7),40,97,50,54,48,56,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,97,50,54,48,50,32,101,120,110,53,49,56,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,50,54,52,57,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,50,54,54,52,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,20),40,97,50,54,53,56,32,46,32,97,114,103,115,53,49,53,53,50,55,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,50,54,52,51,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,15),40,97,50,53,57,54,32,107,53,49,52,53,49,55,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,14),40,97,50,55,51,56,32,100,101,112,52,54,55,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,13),40,102,95,50,56,48,56,32,100,52,53,56,41,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,52,53,50,32,108,115,116,52,53,51,52,53,54,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,13),40,109,97,116,99,104,63,32,115,51,48,53,41,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,105,110,101,115,51,48,55,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,23),40,102,95,50,53,52,50,32,115,52,51,50,32,105,110,100,101,110,116,52,51,51,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,53,54,49,32,108,115,116,53,54,50,53,54,53,41,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,53,52,57,32,108,115,116,53,53,48,53,53,51,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,14),40,97,50,52,51,53,32,100,101,112,51,57,52,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,15),40,97,50,51,54,54,32,108,105,110,101,51,53,57,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,109,97,107,101,47,112,114,111,99,47,104,101,108,112,101,114,32,115,112,101,99,52,50,52,32,97,114,103,118,52,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,47,112,114,111,99,32,103,53,56,50,53,56,51,53,57,49,32,46,32,114,118,97,114,53,56,52,53,57,50,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,13),40,118,101,114,98,32,100,105,114,54,55,51,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,15),40,102,95,53,52,51,50,32,100,105,114,54,56,51,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,15),40,102,95,53,52,52,48,32,100,105,114,54,56,53,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,7),40,97,51,49,51,52,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,51,49,52,51,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,119,114,105,116,101,45,105,110,102,111,32,105,100,54,57,53,32,102,105,108,101,115,54,57,54,32,105,110,102,111,54,57,55,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,55,54,51,32,101,114,114,55,55,50,32,112,114,101,102,105,120,55,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,112,114,101,102,105,120,55,54,54,32,37,101,114,114,55,54,49,55,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,114,114,55,54,53,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,47),40,115,101,116,117,112,45,97,112,105,35,99,111,112,121,45,102,105,108,101,32,102,114,111,109,55,53,53,32,116,111,55,53,54,32,46,32,116,109,112,55,53,52,55,53,55,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,109,111,118,101,45,102,105,108,101,32,102,114,111,109,56,48,52,32,116,111,56,48,53,41,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,31),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,102,105,108,101,42,32,100,105,114,56,49,54,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,45,100,101,115,116,45,112,97,116,104,110,97,109,101,32,112,97,116,104,56,50,52,32,102,105,108,101,56,50,53,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,12),40,97,51,52,52,49,32,102,56,50,56,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,99,104,101,99,107,45,102,105,108,101,108,105,115,116,32,102,108,105,115,116,56,50,55,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,51,55,49,56,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,51,55,50,49,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,61),40,115,101,116,117,112,45,97,112,105,35,115,116,97,110,100,97,114,100,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,56,55,50,32,118,101,114,115,105,111,110,56,55,51,32,46,32,116,109,112,56,55,49,56,55,52,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,49,48,48,54,32,108,115,116,49,48,48,55,49,48,49,48,41,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,57,57,48,32,108,115,116,57,57,49,57,57,52,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,12),40,97,51,56,55,50,32,102,57,52,49,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,56),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,101,120,116,101,110,115,105,111,110,32,105,100,57,50,54,32,102,105,108,101,115,57,50,55,32,46,32,116,109,112,57,50,53,57,50,56,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,13),40,101,120,105,102,121,32,102,49,48,52,54,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,13),40,97,52,48,55,56,32,102,49,48,53,52,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,13),40,97,52,49,50,53,32,102,49,48,53,50,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,112,114,111,103,114,97,109,32,105,100,49,48,51,53,32,102,105,108,101,115,49,48,51,54,32,46,32,116,109,112,49,48,51,52,49,48,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,13),40,97,52,50,52,50,32,102,49,48,57,48,41,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,115,99,114,105,112,116,32,105,100,49,48,55,53,32,102,105,108,101,115,49,48,55,54,32,46,32,116,109,112,49,48,55,52,49,48,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,114,101,112,111,45,112,97,116,104,32,116,109,112,49,49,49,56,49,49,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,101,110,115,117,114,101,45,100,105,114,101,99,116,111,114,121,32,112,97,116,104,49,49,51,53,41,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,7),40,97,52,53,50,55,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,7),40,97,52,53,51,51,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,7),40,97,52,53,51,54,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,7),40,97,52,53,52,50,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,7),40,97,52,53,52,53,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,7),40,97,52,53,52,56,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,116,114,121,45,99,111,109,112,105,108,101,32,99,111,100,101,49,49,53,57,32,46,32,116,109,112,49,49,53,56,49,49,54,48,41,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,99,104,105,99,107,101,110,45,118,101,114,115,105,111,110,32,118,49,49,57,52,41,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,55),40,115,101,116,117,112,45,97,112,105,35,117,112,103,114,97,100,101,45,109,101,115,115,97,103,101,32,101,120,116,49,50,49,50,32,109,115,103,49,50,49,51,32,116,109,112,49,50,49,49,49,50,49,52,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,97,114,103,115,49,50,52,49,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,97,114,103,115,49,50,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,108,105,98,114,97,114,121,32,110,97,109,101,49,50,55,54,32,112,114,111,99,49,50,55,55,41,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,104,101,97,100,101,114,32,110,97,109,101,49,50,57,56,41};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,97,52,56,55,56,32,120,49,51,49,50,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,21),40,118,101,114,115,105,111,110,45,62,108,105,115,116,32,118,49,51,49,49,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,112,49,49,51,49,57,32,112,50,49,51,50,48,41,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,118,101,114,115,105,111,110,62,61,63,32,118,49,49,51,48,56,32,118,50,49,51,48,57,41,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,26),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,110,97,109,101,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,116,109,112,49,51,56,54,49,51,56,55,41,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,29),40,115,101,116,117,112,45,97,112,105,35,114,101,97,100,45,105,110,102,111,32,101,103,103,49,51,57,55,41,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,38),40,115,101,116,117,112,45,97,112,105,35,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,49,52,53,57,32,108,115,116,49,52,54,48,49,52,54,51,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,14),40,119,97,108,107,32,100,105,114,49,52,53,53,41,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,50),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,100,105,114,101,99,116,111,114,121,32,100,105,114,49,52,51,52,32,46,32,116,109,112,49,52,51,51,49,52,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,49,52,56,53,32,108,115,116,49,52,56,54,49,52,56,57,41,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,101,120,116,101,110,115,105,111,110,32,101,103,103,49,52,55,56,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,36,115,121,115,116,101,109,32,115,116,114,49,52,57,52,41,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,21),40,101,110,115,117,114,101,45,115,116,114,105,110,103,32,120,49,51,55,50,41,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,13),40,97,53,51,54,49,32,120,49,51,53,53,41,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5539)
static void C_ccall f_5539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5531)
static void C_ccall f_5531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1662)
static void C_ccall f_1662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_ccall f_1674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5499)
static void C_ccall f_5499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1680)
static void C_ccall f_1680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1691)
static void C_ccall f_1691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1701)
static void C_ccall f_1701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5477)
static void C_ccall f_5477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1704)
static void C_fcall f_1704(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_ccall f_1743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5362)
static void C_ccall f_5362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5378)
static void C_fcall f_5378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5408)
static void C_ccall f_5408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_fcall f_5385(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5337)
static void C_fcall f_5337(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5310)
static void C_fcall f_5310(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5320)
static void C_ccall f_5320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_fcall f_5202(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_fcall f_5214(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5227)
static void C_ccall f_5227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5184)
static void C_ccall f_5184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5197)
static void C_ccall f_5197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5105)
static void C_ccall f_5105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5153)
static void C_ccall f_5153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_fcall f_5112(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5117)
static void C_fcall f_5117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5140)
static void C_ccall f_5140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5124)
static void C_ccall f_5124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5099)
static void C_ccall f_5099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5037)
static void C_ccall f_5037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4870)
static void C_ccall f_4870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_fcall f_4907(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_fcall f_4873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4856)
static void C_ccall f_4856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4806)
static void C_ccall f_4806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_ccall f_4824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4674)
static void C_fcall f_4674(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4687)
static void C_fcall f_4687(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_fcall f_4705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4720)
static void C_fcall f_4720(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4730)
static void C_ccall f_4730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_fcall f_4587(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4591)
static void C_ccall f_4591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4622)
static void C_ccall f_4622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4435)
static void C_ccall f_4435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4549)
static void C_ccall f_4549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4453)
static void C_ccall f_4453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4528)
static void C_ccall f_4528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4491)
static void C_ccall f_4491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4378)
static void C_fcall f_4378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4429)
static void C_ccall f_4429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_fcall f_4320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4200)
static void C_ccall f_4200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_fcall f_4045(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3500)
static void C_fcall f_3500(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3973)
static void C_fcall f_3973(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3904)
static void C_fcall f_3904(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3843)
static void C_fcall f_3843(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3867)
static void C_ccall f_3867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3783)
static void C_fcall f_3783(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_ccall f_3774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3591)
static void C_fcall f_3591(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_fcall f_3436(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_fcall f_3458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_fcall f_3411(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3286)
static void C_fcall f_3286(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_fcall f_3277(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_fcall f_3189(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_fcall f_3058(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3071)
static void C_ccall f_3071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3031)
static void C_fcall f_3031(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_fcall f_2521(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_fcall f_2525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_fcall f_2923(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_fcall f_2873(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2248)
static void C_fcall f_2248(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2261)
static void C_fcall f_2261(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_fcall f_2783(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2687)
static void C_ccall f_2687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_fcall f_2315(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2335)
static void C_ccall f_2335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_fcall f_2293(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_fcall f_2197(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_fcall f_2095(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_fcall f_2136(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_fcall f_2143(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_ccall f_2041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_fcall f_1972(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_fcall f_1851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_fcall f_1873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1788)
static void C_fcall f_1788(C_word t0) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1704)
static void C_fcall trf_1704(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1704(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1704(t0,t1);}

C_noret_decl(trf_5378)
static void C_fcall trf_5378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5378(t0,t1);}

C_noret_decl(trf_5385)
static void C_fcall trf_5385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5385(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5385(t0,t1);}

C_noret_decl(trf_5337)
static void C_fcall trf_5337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5337(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5337(t0,t1);}

C_noret_decl(trf_5310)
static void C_fcall trf_5310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5310(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5310(t0,t1,t2);}

C_noret_decl(trf_5202)
static void C_fcall trf_5202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5202(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5202(t0,t1,t2);}

C_noret_decl(trf_5214)
static void C_fcall trf_5214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5214(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5214(t0,t1,t2);}

C_noret_decl(trf_5112)
static void C_fcall trf_5112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5112(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5112(t0,t1);}

C_noret_decl(trf_5117)
static void C_fcall trf_5117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5117(t0,t1);}

C_noret_decl(trf_4907)
static void C_fcall trf_4907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4907(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4907(t0,t1,t2,t3);}

C_noret_decl(trf_4873)
static void C_fcall trf_4873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4873(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4873(t0,t1);}

C_noret_decl(trf_4674)
static void C_fcall trf_4674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4674(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4674(t0,t1,t2);}

C_noret_decl(trf_4687)
static void C_fcall trf_4687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4687(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4687(t0,t1);}

C_noret_decl(trf_4705)
static void C_fcall trf_4705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4705(t0,t1);}

C_noret_decl(trf_4720)
static void C_fcall trf_4720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4720(t0,t1);}

C_noret_decl(trf_4587)
static void C_fcall trf_4587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4587(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4587(t0,t1,t2,t3);}

C_noret_decl(trf_4378)
static void C_fcall trf_4378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4378(t0,t1);}

C_noret_decl(trf_4320)
static void C_fcall trf_4320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4320(t0,t1);}

C_noret_decl(trf_4045)
static void C_fcall trf_4045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4045(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4045(t0,t1);}

C_noret_decl(trf_3500)
static void C_fcall trf_3500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3500(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3500(t0,t1);}

C_noret_decl(trf_3973)
static void C_fcall trf_3973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3973(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3973(t0,t1);}

C_noret_decl(trf_3904)
static void C_fcall trf_3904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3904(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3904(t0,t1);}

C_noret_decl(trf_3843)
static void C_fcall trf_3843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3843(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3843(t0,t1,t2);}

C_noret_decl(trf_3783)
static void C_fcall trf_3783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3783(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3783(t0,t1,t2);}

C_noret_decl(trf_3591)
static void C_fcall trf_3591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3591(t0,t1);}

C_noret_decl(trf_3436)
static void C_fcall trf_3436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3436(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3436(t0,t1);}

C_noret_decl(trf_3458)
static void C_fcall trf_3458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3458(t0,t1);}

C_noret_decl(trf_3411)
static void C_fcall trf_3411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3411(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3411(t0,t1,t2);}

C_noret_decl(trf_3286)
static void C_fcall trf_3286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3286(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3286(t0,t1);}

C_noret_decl(trf_3277)
static void C_fcall trf_3277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3277(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3277(t0,t1,t2);}

C_noret_decl(trf_3189)
static void C_fcall trf_3189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3189(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3189(t0,t1,t2,t3);}

C_noret_decl(trf_3058)
static void C_fcall trf_3058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3058(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3058(t0,t1,t2,t3);}

C_noret_decl(trf_3031)
static void C_fcall trf_3031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3031(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3031(t0,t1);}

C_noret_decl(trf_2521)
static void C_fcall trf_2521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2521(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2521(t0,t1,t2);}

C_noret_decl(trf_2525)
static void C_fcall trf_2525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2525(t0,t1);}

C_noret_decl(trf_2923)
static void C_fcall trf_2923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2923(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2923(t0,t1,t2);}

C_noret_decl(trf_2873)
static void C_fcall trf_2873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2873(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2873(t0,t1,t2);}

C_noret_decl(trf_2248)
static void C_fcall trf_2248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2248(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2248(t0,t1,t2);}

C_noret_decl(trf_2261)
static void C_fcall trf_2261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2261(t0,t1);}

C_noret_decl(trf_2783)
static void C_fcall trf_2783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2783(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2783(t0,t1,t2);}

C_noret_decl(trf_2315)
static void C_fcall trf_2315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2315(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2315(t0,t1,t2,t3);}

C_noret_decl(trf_2293)
static void C_fcall trf_2293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2293(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2293(t0,t1,t2);}

C_noret_decl(trf_2197)
static void C_fcall trf_2197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2197(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2197(t0,t1,t2);}

C_noret_decl(trf_2095)
static void C_fcall trf_2095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2095(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2095(t0,t1);}

C_noret_decl(trf_2136)
static void C_fcall trf_2136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2136(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2136(t0,t1);}

C_noret_decl(trf_2143)
static void C_fcall trf_2143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2143(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2143(t0,t1);}

C_noret_decl(trf_1972)
static void C_fcall trf_1972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1972(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1972(t0,t1);}

C_noret_decl(trf_1851)
static void C_fcall trf_1851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1851(t0,t1);}

C_noret_decl(trf_1873)
static void C_fcall trf_1873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1873(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1873(t0,t1);}

C_noret_decl(trf_1788)
static void C_fcall trf_1788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1788(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1788(t0);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1562)){
C_save(t1);
C_rereclaim2(1562*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,362);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\003csi");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\013chicken-bug");
lf[15]=C_h_intern(&lf[15],24,"setup-api#host-extension");
lf[17]=C_h_intern(&lf[17],24,"setup-api#chicken-prefix");
lf[18]=C_h_intern(&lf[18],19,"setup-api#shellpath");
lf[19]=C_h_intern(&lf[19],2,"qs");
lf[20]=C_h_intern(&lf[20],18,"normalize-pathname");
lf[21]=C_h_intern(&lf[21],23,"setup-api#cross-chicken");
lf[23]=C_h_intern(&lf[23],30,"setup-api#setup-root-directory");
lf[24]=C_h_intern(&lf[24],28,"setup-api#setup-verbose-mode");
lf[25]=C_h_intern(&lf[25],28,"setup-api#setup-install-mode");
lf[26]=C_h_intern(&lf[26],28,"setup-api#setup-verbose-flag");
lf[27]=C_h_intern(&lf[27],28,"setup-api#setup-install-flag");
lf[28]=C_h_intern(&lf[28],22,"setup-api#program-path");
lf[29]=C_h_intern(&lf[29],28,"setup-api#keep-intermediates");
lf[37]=C_h_intern(&lf[37],4,"copy");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\011del /Q /S");
lf[39]=C_h_intern(&lf[39],4,"move");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\006rm -fr");
lf[44]=C_h_intern(&lf[44],2,"mv");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\005mkdir");
lf[48]=C_h_intern(&lf[48],22,"setup-api#sudo-install");
lf[49]=C_h_intern(&lf[49],5,"print");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: cannot install as superuser with Windows");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo cp -r");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo rm -fr");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\007sudo mv");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo chmod");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo ranlib");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo mkdir");
lf[57]=C_h_intern(&lf[57],21,"setup-api#abort-setup");
lf[58]=C_h_intern(&lf[58],20,"setup-api#yes-or-no\077");
lf[59]=C_h_intern(&lf[59],19,"\003sysstandard-output");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\003yes");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[63]=C_h_intern(&lf[63],19,"\003syswrite-char/port");
lf[64]=C_h_intern(&lf[64],7,"display");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000$Please enter \042yes\042, \042no\042 or \042abort\042.");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[68]=C_h_intern(&lf[68],9,"read-line");
lf[69]=C_h_intern(&lf[69],12,"flush-output");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\002] ");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\020 (yes/no/abort) ");
lf[72]=C_h_intern(&lf[72],15,"\003sysget-keyword");
lf[73]=C_h_intern(&lf[73],6,"\000abort");
lf[74]=C_h_intern(&lf[74],8,"\000default");
lf[75]=C_h_intern(&lf[75],15,"setup-api#patch");
lf[76]=C_h_intern(&lf[76],10,"write-line");
lf[77]=C_h_intern(&lf[77],17,"string-substitute");
lf[78]=C_h_intern(&lf[78],20,"with-input-from-file");
lf[79]=C_h_intern(&lf[79],19,"with-output-to-file");
lf[81]=C_h_intern(&lf[81],17,"get-output-string");
lf[82]=C_h_intern(&lf[82],18,"open-output-string");
lf[83]=C_h_intern(&lf[83],21,"create-temporary-file");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\011patching ");
lf[86]=C_h_intern(&lf[86],21,"setup-api#run-verbose");
lf[88]=C_h_intern(&lf[88],26,"pathname-replace-extension");
lf[89]=C_h_intern(&lf[89],26,"\003sysload-dynamic-extension");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[92]=C_h_intern(&lf[92],18,"pathname-extension");
lf[93]=C_h_intern(&lf[93],17,"setup-api#execute");
lf[94]=C_h_intern(&lf[94],18,"string-intersperse");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[104]=C_h_intern(&lf[104],5,"cons*");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\023compiling-extension");
lf[107]=C_h_intern(&lf[107],8,"feature\077");
lf[108]=C_h_intern(&lf[108],14,"\000cross-chicken");
lf[109]=C_h_intern(&lf[109],13,"make-pathname");
lf[110]=C_h_intern(&lf[110],7,"\003sysmap");
lf[111]=C_h_intern(&lf[111],8,"->string");
lf[112]=C_h_intern(&lf[112],16,"\003sysflush-output");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[115]=C_h_intern(&lf[115],5,"error");
lf[116]=C_h_intern(&lf[116],5,"write");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\013 for line: ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[122]=C_h_intern(&lf[122],6,"signal");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\025make: Failed to make ");
lf[125]=C_h_intern(&lf[125],22,"with-exception-handler");
lf[126]=C_h_intern(&lf[126],30,"call-with-current-continuation");
lf[127]=C_h_intern(&lf[127],13,"string-append");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\010 changed");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\007 date: ");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\027 just because (reason: ");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\017 does not exist");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\007making ");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\006make: ");
lf[136]=C_h_intern(&lf[136],22,"file-modification-time");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\015 was not made");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\013dependancy ");
lf[139]=C_h_intern(&lf[139],12,"file-exists\077");
lf[140]=C_h_intern(&lf[140],3,"any");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\027don\047t know how to make ");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\011checking ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\006make: ");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\013make: made ");
lf[146]=C_h_intern(&lf[146],7,"reverse");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[149]=C_h_intern(&lf[149],4,"caar");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[151]=C_h_intern(&lf[151],27,"condition-property-accessor");
lf[152]=C_h_intern(&lf[152],3,"exn");
lf[153]=C_h_intern(&lf[153],7,"message");
lf[154]=C_h_intern(&lf[154],19,"condition-predicate");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\047argument is not a string or string list");
lf[156]=C_h_intern(&lf[156],5,"every");
lf[157]=C_h_intern(&lf[157],7,"string\077");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000#command part of line is not a thunk");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\037dependency item is not a string");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000!second part of line is not a list");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\0004line does not start with a string or list of strings");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000$list is not a list with 2 or 3 parts");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\036specification is an empty list");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\033specification is not a list");
lf[165]=C_h_intern(&lf[165],12,"vector->list");
lf[166]=C_h_intern(&lf[166],19,"setup-api#make/proc");
lf[167]=C_h_intern(&lf[167],9,"\003syserror");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\0000no matching clause in call to \047case-lambda\047 form");
lf[169]=C_h_intern(&lf[169],29,"setup-api#installation-prefix");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\026  creating directory `");
lf[171]=C_h_intern(&lf[171],16,"create-directory");
lf[172]=C_h_intern(&lf[172],2,"-p");
lf[173]=C_h_intern(&lf[173],34,"setup-api#create-directory/parents");
lf[175]=C_h_intern(&lf[175],5,"files");
lf[176]=C_h_intern(&lf[176],3,"a+r");
lf[177]=C_h_intern(&lf[177],2,"pp");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[179]=C_h_intern(&lf[179],15,"repository-path");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\015writing info ");
lf[184]=C_h_intern(&lf[184],10,"\003sysappend");
lf[185]=C_h_intern(&lf[185],19,"setup-api#copy-file");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[187]=C_h_intern(&lf[187],7,"warning");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[189]=C_h_intern(&lf[189],5,"glob\077");
lf[191]=C_h_intern(&lf[191],14,"string-prefix\077");
lf[192]=C_h_intern(&lf[192],19,"setup-api#move-file");
lf[193]=C_h_intern(&lf[193],22,"setup-api#remove-file*");
lf[195]=C_h_intern(&lf[195],18,"absolute-pathname\077");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid file-specification");
lf[198]=C_h_intern(&lf[198],28,"setup-api#standard-extension");
lf[199]=C_h_intern(&lf[199],7,"version");
lf[200]=C_h_intern(&lf[200],27,"setup-api#install-extension");
lf[201]=C_h_intern(&lf[201],6,"static");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[205]=C_h_intern(&lf[205],3,"-d0");
lf[206]=C_h_intern(&lf[206],3,"-O2");
lf[207]=C_h_intern(&lf[207],2,"-s");
lf[208]=C_h_intern(&lf[208],3,"csc");
lf[209]=C_h_intern(&lf[209],5,"-unit");
lf[210]=C_h_intern(&lf[210],2,"-j");
lf[211]=C_h_intern(&lf[211],3,"-d1");
lf[212]=C_h_intern(&lf[212],2,"-c");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\012import.scm");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\003scm");
lf[215]=C_h_intern(&lf[215],5,"\000info");
lf[216]=C_h_intern(&lf[216],7,"\000static");
lf[217]=C_h_intern(&lf[217],13,"documentation");
lf[218]=C_h_intern(&lf[218],8,"examples");
lf[219]=C_h_intern(&lf[219],7,"newline");
lf[220]=C_h_intern(&lf[220],4,"a+rx");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\037\012* Installing example files in ");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000%\012* Installing documentation files in ");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\021share/chicken/doc");
lf[226]=C_h_intern(&lf[226],6,"macosx");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[228]=C_h_intern(&lf[228],16,"software-version");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[230]=C_h_intern(&lf[230],25,"setup-api#install-program");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[237]=C_h_intern(&lf[237],24,"setup-api#install-script");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000Acannot create directory: a file with the same name already exists");
lf[242]=C_h_intern(&lf[242],10,"directory\077");
lf[243]=C_h_intern(&lf[243],3,"a+x");
lf[244]=C_h_intern(&lf[244],18,"pathname-directory");
lf[245]=C_h_intern(&lf[245],21,"setup-api#try-compile");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\012succeeded.");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\007failed.");
lf[248]=C_h_intern(&lf[248],6,"system");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\0042>&1");
lf[254]=C_h_intern(&lf[254],4,"conc");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\014 >/dev/null ");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[267]=C_h_intern(&lf[267],13,"\000compile-only");
lf[268]=C_h_intern(&lf[268],5,"\000verb");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[270]=C_h_intern(&lf[270],8,"\000ldflags");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[272]=C_h_intern(&lf[272],7,"\000cflags");
lf[273]=C_h_intern(&lf[273],3,"\000cc");
lf[274]=C_h_intern(&lf[274],4,"\000c++");
lf[275]=C_h_intern(&lf[275],34,"setup-api#required-chicken-version");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\026 or higher is required");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\020CHICKEN version ");
lf[278]=C_h_intern(&lf[278],20,"setup-api#version>=\077");
lf[279]=C_h_intern(&lf[279],15,"chicken-version");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000.and repeat the current installation operation.");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\022  chicken-install ");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\015 - please run");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\002\047 ");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\030the required extension `");
lf[288]=C_h_intern(&lf[288],36,"setup-api#required-extension-version");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\047, which is what this extension requires");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\016is older than ");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000%has no associated version information");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\020is not installed");
lf[293]=C_h_intern(&lf[293],21,"extension-information");
lf[294]=C_h_intern(&lf[294],30,"required-extension-information");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\023bad argument format");
lf[296]=C_h_intern(&lf[296],22,"setup-api#test-compile");
lf[297]=C_h_intern(&lf[297],22,"setup-api#find-library");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\017(); return 0; }");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\015int main() { ");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\003();");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\005char ");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\012extern \042C\042");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\022#ifdef __cplusplus");
lf[306]=C_h_intern(&lf[306],21,"setup-api#find-header");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\033>\012int main() { return 0; }\012");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\012#include <");
lf[309]=C_h_intern(&lf[309],19,"string-split-fields");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\006[-\134._]");
lf[311]=C_h_intern(&lf[311],6,"\000infix");
lf[312]=C_h_intern(&lf[312],8,"string>\077");
lf[313]=C_h_intern(&lf[313],36,"setup-api#extension-name-and-version");
lf[314]=C_h_intern(&lf[314],24,"setup-api#extension-name");
lf[315]=C_h_intern(&lf[315],27,"setup-api#extension-version");
lf[316]=C_h_intern(&lf[316],12,"string-null\077");
lf[317]=C_h_intern(&lf[317],19,"setup-api#read-info");
lf[318]=C_h_intern(&lf[318],4,"read");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\013.setup-info");
lf[320]=C_h_intern(&lf[320],36,"setup-api#create-temporary-directory");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install-");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\004/tmp");
lf[324]=C_h_intern(&lf[324],24,"get-environment-variable");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[328]=C_h_intern(&lf[328],26,"setup-api#remove-directory");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\014sudo rm -fr ");
lf[330]=C_h_intern(&lf[330],16,"delete-directory");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[333]=C_h_intern(&lf[333],11,"delete-file");
lf[334]=C_h_intern(&lf[334],9,"directory");
lf[335]=C_h_intern(&lf[335],16,"remove-directory");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000#cannot remove - directory not found");
lf[337]=C_h_intern(&lf[337],26,"setup-api#remove-extension");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000-shell command failed with nonzero exit status");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[342]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid extension-name-and-version");
lf[345]=C_h_intern(&lf[345],14,"make-parameter");
lf[346]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\026CHICKEN_INSTALL_PREFIX");
lf[348]=C_h_intern(&lf[348],4,"exit");
lf[349]=C_h_intern(&lf[349],17,"current-directory");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\012/usr/local");
lf[351]=C_h_intern(&lf[351],12,"string-match");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\012(.*)/bin/\077");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[354]=C_h_intern(&lf[354],17,"\003syspeek-c-string");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[357]=C_h_intern(&lf[357],17,"register-feature!");
lf[358]=C_h_intern(&lf[358],13,"chicken-setup");
lf[359]=C_h_intern(&lf[359],7,"windows");
lf[360]=C_h_intern(&lf[360],14,"build-platform");
lf[361]=C_h_intern(&lf[361],13,"software-type");
C_register_lf2(lf,362,create_ptable());
t2=C_mutate(&lf[0] /* (set! c666 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1607,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1605 */
static void C_ccall f_1607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1608 in k1605 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1613,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1611 in k1608 in k1605 */
static void C_ccall f_1613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1634,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1643,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[354]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5543,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[2],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5539,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[354]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5539,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[3],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[354]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5535,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[4],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[354]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_BUG_PROGRAM),C_fix(0));}

/* k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5531,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=C_mutate(&lf[6] /* (set! setup-api#*installed-executables* ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1658,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t9=*((C_word*)lf[354]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=C_mutate(&lf[7] /* (set! setup-api#*cc* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[354]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}

/* k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1662,2,t0,t1);}
t2=C_mutate(&lf[8] /* (set! setup-api#*cxx* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[354]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}

/* k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1666,2,t0,t1);}
t2=C_mutate(&lf[9] /* (set! setup-api#*target-cflags* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[354]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}

/* k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1670,2,t0,t1);}
t2=C_mutate(&lf[10] /* (set! setup-api#*target-libs* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1674,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[354]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}

/* k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1674,2,t0,t1);}
t2=C_mutate(&lf[11] /* (set! setup-api#*target-lib-home* ...) */,t1);
t3=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
t4=C_mutate(&lf[13] /* (set! setup-api#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1680,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5499,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 89   software-type");
((C_proc2)C_retrieve_symbol_proc(lf[361]))(2,*((C_word*)lf[361]+1),t6);}

/* k5497 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,lf[359]);
if(C_truep(t2)){
C_trace("setup-api.scm: 90   build-platform");
((C_proc2)C_retrieve_symbol_proc(lf[360]))(2,*((C_word*)lf[360]+1),((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
f_1680(2,t3,C_SCHEME_FALSE);}}

/* k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1680,2,t0,t1);}
t2=C_mutate(&lf[14] /* (set! setup-api#*windows* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1683,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 92   register-feature!");
((C_proc3)C_retrieve_symbol_proc(lf[357]))(3,*((C_word*)lf[357]+1),t3,lf[358]);}

/* k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1687,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 94   make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[345]))(3,*((C_word*)lf[345]+1),t2,C_SCHEME_FALSE);}

/* k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1687,2,t0,t1);}
t2=C_mutate((C_word*)lf[15]+1 /* (set! setup-api#host-extension ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1691,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 97   get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[324]))(3,*((C_word*)lf[324]+1),t3,lf[356]);}

/* k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1694,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
C_trace("setup-api.scm: 98   make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t2,t1,lf[355]);}
else{
t3=t2;
f_1694(2,t3,C_SCHEME_FALSE);}}

/* k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1697(2,t3,t1);}
else{
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[354]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1697,2,t0,t1);}
t2=C_mutate(&lf[16] /* (set! setup-api#*chicken-bin-path* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1701,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 102  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[324]))(3,*((C_word*)lf[324]+1),t3,lf[353]);}

/* k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1704,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1704(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5477,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 103  string-match");
((C_proc4)C_retrieve_symbol_proc(lf[351]))(4,*((C_word*)lf[351]+1),t3,lf[352],C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"));}}

/* k5475 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1704(t2,(C_truep(t1)?(C_word)C_i_cadr(t1):lf[350]));}

/* k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_1704(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1704,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1 /* (set! setup-api#chicken-prefix ...) */,t1);
t3=C_mutate((C_word*)lf[18]+1 /* (set! setup-api#shellpath ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1706,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[21]+1 /* (set! setup-api#cross-chicken ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1716,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 114  current-directory");
((C_proc2)C_retrieve_symbol_proc(lf[349]))(2,*((C_word*)lf[349]+1),t5);}

/* k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1725,2,t0,t1);}
t2=C_mutate(&lf[22] /* (set! setup-api#*base-directory* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 116  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[345]))(3,*((C_word*)lf[345]+1),t3,C_retrieve2(lf[22],"setup-api#*base-directory*"));}

/* k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=C_mutate((C_word*)lf[23]+1 /* (set! setup-api#setup-root-directory ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 117  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[345]))(3,*((C_word*)lf[345]+1),t3,C_SCHEME_FALSE);}

/* k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1733,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! setup-api#setup-verbose-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1737,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 118  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[345]))(3,*((C_word*)lf[345]+1),t3,C_SCHEME_TRUE);}

/* k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1737,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1 /* (set! setup-api#setup-install-mode ...) */,t1);
t3=C_mutate((C_word*)lf[26]+1 /* (set! setup-api#setup-verbose-flag ...) */,C_retrieve(lf[24]));
t4=C_mutate((C_word*)lf[27]+1 /* (set! setup-api#setup-install-flag ...) */,C_retrieve(lf[25]));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1743,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 121  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[345]))(3,*((C_word*)lf[345]+1),t5,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"));}

/* k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1743,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! setup-api#program-path ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1747,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 122  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[345]))(3,*((C_word*)lf[345]+1),t3,C_SCHEME_FALSE);}

/* k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1747,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! setup-api#keep-intermediates ...) */,t1);
t3=lf[30] /* setup-api#*copy-command* */ =C_SCHEME_UNDEFINED;;
t4=lf[31] /* setup-api#*remove-command* */ =C_SCHEME_UNDEFINED;;
t5=lf[32] /* setup-api#*move-command* */ =C_SCHEME_UNDEFINED;;
t6=lf[33] /* setup-api#*chmod-command* */ =C_SCHEME_UNDEFINED;;
t7=lf[34] /* setup-api#*ranlib-command* */ =C_SCHEME_UNDEFINED;;
t8=lf[35] /* setup-api#*mkdir-command* */ =C_SCHEME_UNDEFINED;;
t9=C_mutate(&lf[36] /* (set! setup-api#user-install-setup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[48]+1 /* (set! setup-api#sudo-install ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1814,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 177  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[345]))(3,*((C_word*)lf[345]+1),t11,C_retrieve(lf[348]));}

/* k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! setup-api#abort-setup ...) */,t1);
t3=C_mutate((C_word*)lf[58]+1 /* (set! setup-api#yes-or-no? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1839,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[75]+1 /* (set! setup-api#patch ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1937,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 212  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[345]))(3,*((C_word*)lf[345]+1),t5,C_SCHEME_TRUE);}

/* k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* (set! setup-api#run-verbose ...) */,t1);
t3=C_mutate(&lf[87] /* (set! setup-api#fixmaketarget ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[93]+1 /* (set! setup-api#execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2162,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[114] /* (set! setup-api#make:form-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2293,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[118] /* (set! setup-api#make:line-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2315,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[121] /* (set! setup-api#make:make/proc/helper ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2521,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[166]+1 /* (set! setup-api#make/proc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2952,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5471,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 419  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[324]))(3,*((C_word*)lf[324]+1),t10,lf[347]);}

/* k5469 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[17]));
C_trace("setup-api.scm: 418  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[345]))(3,*((C_word*)lf[345]+1),((C_word*)t0)[2],t2);}

/* k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[70],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3028,2,t0,t1);}
t2=C_mutate((C_word*)lf[169]+1 /* (set! setup-api#installation-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3031,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5432,a[2]=t3,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5440,a[2]=t3,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[173]+1 /* (set! setup-api#create-directory/parents ...) */,t4);
t6=C_mutate(&lf[174] /* (set! setup-api#write-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3058,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[185]+1 /* (set! setup-api#copy-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3187,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[192]+1 /* (set! setup-api#move-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3334,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[193]+1 /* (set! setup-api#remove-file* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3389,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[194] /* (set! setup-api#make-dest-pathname ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3411,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[196] /* (set! setup-api#check-filelist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3436,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[198]+1 /* (set! setup-api#standard-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3539,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[200]+1 /* (set! setup-api#install-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3725,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[230]+1 /* (set! setup-api#install-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4039,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[237]+1 /* (set! setup-api#install-script ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4190,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[180] /* (set! setup-api#repo-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4320,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[190] /* (set! setup-api#ensure-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4378,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[245]+1 /* (set! setup-api#try-compile ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4431,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[275]+1 /* (set! setup-api#required-chicken-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4555,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[280] /* (set! setup-api#upgrade-message ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4587,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[288]+1 /* (set! setup-api#required-extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4668,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[296]+1 /* (set! setup-api#test-compile ...) */,C_retrieve(lf[245]));
t23=C_mutate((C_word*)lf[297]+1 /* (set! setup-api#find-library ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4789,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[306]+1 /* (set! setup-api#find-header ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4848,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[278]+1 /* (set! setup-api#version>=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4870,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5035,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5362,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 712  make-parameter");
((C_proc4)C_retrieve_symbol_proc(lf[345]))(4,*((C_word*)lf[345]+1),t26,lf[346],t27);}

/* a5361 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5362,3,t0,t1,t2);}
t3=(C_word)C_i_not(t2);
t4=(C_truep(t3)?t3:(C_word)C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[342]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5378,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t6=(C_word)C_i_length(t2);
t7=t5;
f_5378(t7,(C_word)C_i_nequalp(C_fix(2),t6));}
else{
t6=t5;
f_5378(t6,C_SCHEME_FALSE);}}}

/* k5376 in a5361 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_5378(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5378,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5385,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5408,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 720  ensure-string");
f_5385(t5,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5415,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 722  warning");
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),t2,lf[344],((C_word*)t0)[3]);}}

/* k5413 in k5376 in a5361 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 723  extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[313]))(2,*((C_word*)lf[313]+1),((C_word*)t0)[2]);}

/* k5406 in k5376 in a5361 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5412,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 720  ensure-string");
f_5385(t2,((C_word*)t0)[2]);}

/* k5410 in k5406 in k5376 in a5361 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5412,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* ensure-string in k5376 in a5361 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_5385(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5385,NULL,2,t1,t2);}
t3=(C_word)C_i_not(t2);
t4=(C_truep(t3)?t3:(C_word)C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[343]);}
else{
C_trace("setup-api.scm: 719  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[111]))(3,*((C_word*)lf[111]+1),t1,t2);}}

/* k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5035,2,t0,t1);}
t2=C_mutate((C_word*)lf[313]+1 /* (set! setup-api#extension-name-and-version ...) */,t1);
t3=C_mutate((C_word*)lf[314]+1 /* (set! setup-api#extension-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5037,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[315]+1 /* (set! setup-api#extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5047,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[317]+1 /* (set! setup-api#read-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5091,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[320]+1 /* (set! setup-api#create-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5105,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[328]+1 /* (set! setup-api#remove-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5158,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[337]+1 /* (set! setup-api#remove-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5283,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[80] /* (set! setup-api#$system ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5337,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 786  user-install-setup");
f_1788(t10);}

/* k5358 in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* setup-api#$system in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_5337(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5337,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5341,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5354,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
C_trace("setup-api.scm: 778  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[127]+1)))(5,*((C_word*)lf[127]+1),t4,lf[340],t2,lf[341]);}
else{
t5=t4;
f_5354(2,t5,t2);}}

/* k5352 in setup-api#$system in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 776  system");
((C_proc3)C_retrieve_symbol_proc(lf[248]))(3,*((C_word*)lf[248]+1),((C_word*)t0)[2],t1);}

/* k5339 in setup-api#$system in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("setup-api.scm: 781  error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[339],t1,((C_word*)t0)[2]);}}

/* setup-api#remove-extension in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5283,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5335,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 771  read-info");
((C_proc3)C_retrieve_symbol_proc(lf[317]))(3,*((C_word*)lf[317]+1),t3,t2);}

/* k5333 in setup-api#remove-extension in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5335,2,t0,t1);}
t2=(C_word)C_i_assq(lf[175],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5310,a[2]=t6,a[3]=((C_word)li91),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5310(t8,t3,t4);}
else{
t4=t3;
f_5290(2,t4,C_SCHEME_FALSE);}}

/* loop1485 in k5333 in setup-api#remove-extension in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_5310(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5310,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5320,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("setup-api#remove-file*");
((C_proc3)C_retrieve_symbol_proc(lf[193]))(3,*((C_word*)lf[193]+1),t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5318 in loop1485 in k5333 in setup-api#remove-extension in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5310(t3,((C_word*)t0)[2],t2);}

/* k5288 in k5333 in setup-api#remove-extension in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5297,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5301,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 773  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[179]))(2,*((C_word*)lf[179]+1),t3);}

/* k5299 in k5288 in k5333 in setup-api#remove-extension in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 773  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[109]))(5,*((C_word*)lf[109]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[338]);}

/* k5295 in k5288 in k5333 in setup-api#remove-extension in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 773  remove-file*");
((C_proc3)C_retrieve_symbol_proc(lf[193]))(3,*((C_word*)lf[193]+1),((C_word*)t0)[2],t1);}

/* setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5158r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5158r(t0,t1,t2,t3);}}

static void C_ccall f_5158r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5162,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5162(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5162(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5262,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 751  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t2,((C_word*)t0)[2]);}

/* k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5262,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve2(lf[12],"setup-api#*sudo*"))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5184,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5202,a[2]=t3,a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5202(t5,((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-api.scm: 753  error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[4],lf[335],lf[336],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* walk in k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_5202(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5202,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 759  directory");
((C_proc4)C_retrieve_symbol_proc(lf[334]))(4,*((C_word*)lf[334]+1),t3,t2,C_SCHEME_TRUE);}

/* k5204 in walk in k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5209,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word)li88),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5214(t6,t2,t1);}

/* loop1459 in k5204 in walk in k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_5214(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5214,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5227,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_equal_p(lf[331],t3);
t6=(C_truep(t5)?t5:(C_word)C_i_string_equal_p(lf[332],t3));
if(C_truep(t6)){
t7=t4;
f_5227(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5243,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 763  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t7,((C_word*)t0)[2],t3);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5241 in loop1459 in k5204 in walk in k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5249,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 764  directory?");
((C_proc3)C_retrieve_symbol_proc(lf[242]))(3,*((C_word*)lf[242]+1),t2,t1);}

/* k5247 in k5241 in loop1459 in k5204 in walk in k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 765  walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_5202(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("setup-api.scm: 766  delete-file");
((C_proc3)C_retrieve_symbol_proc(lf[333]))(3,*((C_word*)lf[333]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5225 in loop1459 in k5204 in walk in k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5214(t3,((C_word*)t0)[2],t2);}

/* k5207 in k5204 in walk in k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 768  delete-directory");
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5182 in k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5187,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[329],t1);}

/* k5185 in k5182 in k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5197,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 756  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}

/* k5195 in k5185 in k5182 in k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5188 in k5185 in k5182 in k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5193,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k5191 in k5188 in k5185 in k5182 in k5260 in k5160 in setup-api#remove-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 756  $system");
f_5337(((C_word*)t0)[2],t1);}

/* setup-api#create-temporary-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5109,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 740  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[324]))(3,*((C_word*)lf[324]+1),t2,lf[327]);}

/* k5107 in setup-api#create-temporary-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5112,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_5112(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5147,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 741  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[324]))(3,*((C_word*)lf[324]+1),t3,lf[326]);}}

/* k5145 in k5107 in setup-api#create-temporary-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5147,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5112(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5153,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 742  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[324]))(3,*((C_word*)lf[324]+1),t2,lf[325]);}}

/* k5151 in k5145 in k5107 in setup-api#create-temporary-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5112(t2,(C_truep(t1)?t1:lf[323]));}

/* k5110 in k5107 in setup-api#create-temporary-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_5112(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5112,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5117,a[2]=t1,a[3]=t3,a[4]=((C_word)li86),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5117(t5,((C_word*)t0)[2]);}

/* loop in k5110 in k5107 in setup-api#create-temporary-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_5117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5117,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5124,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5140,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5144,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 746  number->string");
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k5142 in loop in k5110 in k5107 in setup-api#create-temporary-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 746  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),((C_word*)t0)[2],lf[322],t1);}

/* k5138 in loop in k5110 in k5107 in setup-api#create-temporary-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 746  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[109]))(5,*((C_word*)lf[109]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[321]);}

/* k5122 in loop in k5110 in k5107 in setup-api#create-temporary-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5130,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 747  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t2,t1);}

/* k5128 in k5122 in loop in k5110 in k5107 in setup-api#create-temporary-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5130,2,t0,t1);}
if(C_truep(t1)){
C_trace("setup-api.scm: 747  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_5117(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 748  create-directory");
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),t2,((C_word*)t0)[2]);}}

/* k5134 in k5128 in k5122 in loop in k5110 in k5107 in setup-api#create-temporary-directory in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#read-info in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5091,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5099,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5103,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 736  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[179]))(2,*((C_word*)lf[179]+1),t4);}

/* k5101 in setup-api#read-info in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 736  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[109]))(5,*((C_word*)lf[109]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[319]);}

/* k5097 in setup-api#read-info in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 735  with-input-from-file");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),((C_word*)t0)[2],t1,*((C_word*)lf[318]+1));}

/* setup-api#extension-version in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5047r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5047r(t0,t1,t2);}}

static void C_ccall f_5047r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5051,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_5051(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_5051(2,t5,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k5049 in setup-api#extension-version in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5070,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 729  extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[313]))(2,*((C_word*)lf[313]+1),t2);}

/* k5068 in k5049 in setup-api#extension-version in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5070,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5060,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 730  string-null?");
((C_proc3)C_retrieve_symbol_proc(lf[316]))(3,*((C_word*)lf[316]+1),t3,t2);}

/* k5058 in k5068 in k5049 in setup-api#extension-version in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-api.scm: 731  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[111]))(3,*((C_word*)lf[111]+1),((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* setup-api#extension-name in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5045,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 726  extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[313]))(2,*((C_word*)lf[313]+1),t2);}

/* k5043 in setup-api#extension-name in k5033 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(t1));}

/* setup-api#version>=? in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4870,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4873,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4901,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 696  version->list");
f_4873(t5,t2);}

/* k4899 in setup-api#version>=? in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4905,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 697  version->list");
f_4873(t2,((C_word*)t0)[2]);}

/* k4903 in k4899 in setup-api#version>=? in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4905,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4907,a[2]=t3,a[3]=((C_word)li81),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4907(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4903 in k4899 in setup-api#version>=? in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_4907(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4907,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_numberp(t5))){
t6=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_numberp(t6))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_greaterp(t7,t8);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t10=(C_word)C_i_car(t2);
t11=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_nequalp(t10,t11))){
t12=(C_word)C_i_cdr(t2);
t13=(C_word)C_i_cdr(t3);
C_trace("setup-api.scm: 704  loop");
t20=t1;
t21=t12;
t22=t13;
t1=t20;
t2=t21;
t3=t22;
goto loop;}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_numberp(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4987,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_car(t3);
C_trace("setup-api.scm: 706  string>?");
((C_proc4)C_retrieve_proc(*((C_word*)lf[312]+1)))(4,*((C_word*)lf[312]+1),t8,t9,t10);}}}}}

/* k4985 in loop in k4903 in k4899 in setup-api#version>=? in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_string_equal_p(t2,t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 709  loop");
t6=((C_word*)((C_word*)t0)[2])[1];
f_4907(t6,((C_word*)t0)[5],t4,t5);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* version->list in setup-api#version>=? in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_4873(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4873,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4879,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4890,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4894,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 695  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[111]))(3,*((C_word*)lf[111]+1),t5,t2);}

/* k4892 in version->list in setup-api#version>=? in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 695  string-split-fields");
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),((C_word*)t0)[2],lf[310],t1,lf[311]);}

/* k4888 in version->list in setup-api#version>=? in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4878 in version->list in setup-api#version>=? in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4879,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4883,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 694  string->number");
C_string_to_number(3,0,t3,t2);}

/* k4881 in a4878 in version->list in setup-api#version>=? in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* setup-api#find-header in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4848,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4856,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t3);}

/* k4854 in setup-api#find-header in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[308],t1);}

/* k4857 in k4854 in setup-api#find-header in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4862,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4860 in k4857 in k4854 in setup-api#find-header in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[307],((C_word*)t0)[2]);}

/* k4863 in k4860 in k4857 in k4854 in setup-api#find-header in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k4866 in k4863 in k4860 in k4857 in k4854 in setup-api#find-header in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 688  test-compile");
((C_proc5)C_retrieve_symbol_proc(lf[296]))(5,*((C_word*)lf[296]+1),((C_word*)t0)[2],t1,lf[267],C_SCHEME_TRUE);}

/* setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4789,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4797,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t4);}

/* k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4800,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[305],t1);}

/* k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[304],((C_word*)t0)[3]);}

/* k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[303],((C_word*)t0)[3]);}

/* k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k4813 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[302],((C_word*)t0)[3]);}

/* k4816 in k4813 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4819 in k4816 in k4813 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[301],((C_word*)t0)[3]);}

/* k4822 in k4819 in k4816 in k4813 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k4825 in k4822 in k4819 in k4816 in k4813 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[300],((C_word*)t0)[3]);}

/* k4828 in k4825 in k4822 in k4819 in k4816 in k4813 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4831 in k4828 in k4825 in k4822 in k4819 in k4816 in k4813 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[299],((C_word*)t0)[2]);}

/* k4834 in k4831 in k4828 in k4825 in k4822 in k4819 in k4816 in k4813 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4837 in k4834 in k4831 in k4828 in k4825 in k4822 in k4819 in k4816 in k4813 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k4840 in k4837 in k4834 in k4831 in k4828 in k4825 in k4822 in k4819 in k4816 in k4813 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4846,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 685  conc");
((C_proc4)C_retrieve_symbol_proc(lf[254]))(4,*((C_word*)lf[254]+1),t2,lf[298],((C_word*)t0)[2]);}

/* k4844 in k4840 in k4837 in k4834 in k4831 in k4828 in k4825 in k4822 in k4819 in k4816 in k4813 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in setup-api#find-library in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 683  test-compile");
((C_proc5)C_retrieve_symbol_proc(lf[296]))(5,*((C_word*)lf[296]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[270],t1);}

/* setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_4668r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4668r(t0,t1,t2);}}

static void C_ccall f_4668r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4674,a[2]=t4,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4674(t6,t1,t2);}

/* loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_4674(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4674,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4687,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=t3;
f_4687(t5,(C_word)C_i_greater_or_equalp(t4,C_fix(2)));}
else{
t4=t3;
f_4687(t4,C_SCHEME_FALSE);}}}

/* k4685 in loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_4687(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4687,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4699,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 665  extension-information");
((C_proc3)C_retrieve_symbol_proc(lf[293]))(3,*((C_word*)lf[293]+1),t5,t2);}
else{
C_trace("setup-api.scm: 678  error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[294],lf[295],((C_word*)t0)[4]);}}

/* k4697 in k4685 in loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4699,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[199],t1))){
t3=(C_word)C_i_assq(lf[199],t1);
t4=t2;
f_4705(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_4705(t3,C_SCHEME_FALSE);}}
else{
C_trace("setup-api.scm: 676  upgrade-message");
f_4587(((C_word*)t0)[6],((C_word*)t0)[5],lf[292],C_SCHEME_END_OF_LIST);}}

/* k4703 in k4697 in k4685 in loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_4705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4705,NULL,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4745,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 669  version>=?");
((C_proc4)C_retrieve_symbol_proc(lf[278]))(4,*((C_word*)lf[278]+1),t4,((C_word*)t0)[4],t1);}
else{
C_trace("setup-api.scm: 668  upgrade-message");
f_4587(((C_word*)t0)[6],((C_word*)t0)[5],lf[291],C_SCHEME_END_OF_LIST);}}

/* k4743 in k4703 in k4697 in k4685 in loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4745,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4756,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 669  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[111]))(3,*((C_word*)lf[111]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_4720(t2,C_SCHEME_FALSE);}}

/* k4754 in k4743 in k4703 in k4697 in k4685 in loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 669  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[111]))(3,*((C_word*)lf[111]+1),t2,((C_word*)t0)[2]);}

/* k4758 in k4754 in k4743 in k4703 in k4697 in k4685 in loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_4720(t3,(C_word)C_i_not(t2));}

/* k4718 in k4703 in k4697 in k4685 in loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_4720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4720,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t2);}
else{
C_trace("setup-api.scm: 675  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_4674(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k4725 in k4718 in k4703 in k4697 in k4685 in loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4730,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[290],t1);}

/* k4728 in k4725 in k4718 in k4703 in k4697 in k4685 in loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4731 in k4728 in k4725 in k4718 in k4703 in k4697 in k4685 in loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[289],((C_word*)t0)[2]);}

/* k4734 in k4731 in k4728 in k4725 in k4718 in k4703 in k4697 in k4685 in loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k4737 in k4734 in k4731 in k4728 in k4725 in k4718 in k4703 in k4697 in k4685 in loop in setup-api#required-extension-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4739,2,t0,t1);}
C_trace("setup-api.scm: 670  upgrade-message");
f_4587(((C_word*)t0)[4],((C_word*)t0)[3],t1,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_4587(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4587,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4591,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_4591(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4591(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t2);}

/* k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[287],t1);}

/* k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),t2,((C_word*)t0)[3],((C_word*)t0)[5]);}

/* k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[286],((C_word*)t0)[5]);}

/* k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k4608 in k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[285],((C_word*)t0)[4]);}

/* k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[284],((C_word*)t0)[4]);}

/* k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4625,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-api.scm: 656  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t3,lf[282],((C_word*)t0)[2]);}
else{
t4=t3;
f_4644(2,t4,lf[283]);}}

/* k4642 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[281],((C_word*)t0)[2]);}

/* k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k4638 in k4635 in k4632 in k4629 in k4626 in k4623 in k4620 in k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4589 in setup-api#upgrade-message in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 653  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* setup-api#required-chicken-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4555,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4562,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4585,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 649  chicken-version");
((C_proc2)C_retrieve_symbol_proc(lf[279]))(2,*((C_word*)lf[279]+1),t4);}

/* k4583 in setup-api#required-chicken-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 649  version>=?");
((C_proc4)C_retrieve_symbol_proc(lf[278]))(4,*((C_word*)lf[278]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4560 in setup-api#required-chicken-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4562,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4567 in k4560 in setup-api#required-chicken-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4572,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[277],t1);}

/* k4570 in k4567 in k4560 in setup-api#required-chicken-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4573 in k4570 in k4567 in k4560 in setup-api#required-chicken-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[276],((C_word*)t0)[2]);}

/* k4576 in k4573 in k4570 in k4567 in k4560 in setup-api#required-chicken-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4581,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k4579 in k4576 in k4573 in k4570 in k4567 in k4560 in setup-api#required-chicken-version in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 650  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4431r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4431r(t0,t1,t2,t3);}}

static void C_ccall f_4431r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4435,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[72]))(4,*((C_word*)lf[72]+1),t4,lf[274],t3);}

/* k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4549,a[2]=t1,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),t2,lf[273],((C_word*)t0)[2],t3);}

/* a4548 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4549,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[2])?C_retrieve2(lf[8],"setup-api#*cxx*"):C_retrieve2(lf[7],"setup-api#*cc*")));}

/* k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4546,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),t2,lf[272],((C_word*)t0)[2],t3);}

/* a4545 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4546,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[271]);}

/* k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4543,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),t2,lf[270],((C_word*)t0)[2],t3);}

/* a4542 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4543,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[269]);}

/* k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4537,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),t2,lf[268],((C_word*)t0)[2],t3);}

/* a4536 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
C_trace("setup-api.scm: 626  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t1);}

/* k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4534,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),t2,lf[267],((C_word*)t0)[2],t3);}

/* a4533 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4534,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 627  create-temporary-file");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[266]);}

/* k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api.scm: 628  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),t2,t1,lf[265]);}

/* k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4528,a[2]=((C_word*)t0)[2],a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 630  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[79]))(4,*((C_word*)lf[79]+1),t2,((C_word*)t0)[8],t3);}

/* a4527 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4528,2,t0,t1);}
C_trace("display");
((C_proc3)C_retrieve_proc(*((C_word*)lf[64]+1)))(3,*((C_word*)lf[64]+1),t1,((C_word*)t0)[2]);}

/* k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(((C_word*)t0)[5])?lf[250]:lf[251]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=t5;
f_4519(2,t6,lf[261]);}
else{
C_trace("setup-api.scm: 639  conc");
((C_proc8)C_retrieve_symbol_proc(lf[254]))(8,*((C_word*)lf[254]+1),t5,lf[262],C_retrieve2(lf[11],"setup-api#*target-lib-home*"),lf[263],((C_word*)t0)[2],lf[264],C_retrieve2(lf[10],"setup-api#*target-libs*"));}}

/* k4517 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?lf[252]:lf[253]);
C_trace("setup-api.scm: 632  conc");
((C_proc15)C_retrieve_symbol_proc(lf[254]))(15,*((C_word*)lf[254]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[255],((C_word*)t0)[4],lf[256],((C_word*)t0)[3],lf[257],C_retrieve2(lf[9],"setup-api#*target-cflags*"),lf[258],((C_word*)t0)[2],lf[259],t1,lf[260],t2);}

/* k4503 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4508,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-api.scm: 642  print");
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),t2,t1,lf[249]);}
else{
t3=t2;
f_4508(2,t3,C_SCHEME_UNDEFINED);}}

/* k4506 in k4503 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 631  system");
((C_proc3)C_retrieve_symbol_proc(lf[248]))(3,*((C_word*)lf[248]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4465,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_zerop(t1);
t4=(C_truep(t3)?lf[246]:lf[247]);
C_trace("setup-api.scm: 644  print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[49]+1)))(3,*((C_word*)lf[49]+1),t2,t4);}
else{
t3=t2;
f_4465(2,t3,C_SCHEME_UNDEFINED);}}

/* k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4468,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t3);}

/* k4473 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4478,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,C_retrieve2(lf[31],"setup-api#*remove-command*"),t1);}

/* k4476 in k4473 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k4479 in k4476 in k4473 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4491,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 645  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}

/* k4489 in k4479 in k4476 in k4473 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4482 in k4479 in k4476 in k4473 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k4485 in k4482 in k4479 in k4476 in k4473 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 645  $system");
f_5337(((C_word*)t0)[2],t1);}

/* k4466 in k4463 in k4460 in k4457 in k4454 in k4451 in k4448 in k4445 in k4442 in k4439 in k4436 in k4433 in setup-api#try-compile in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_zerop(((C_word*)t0)[2]));}

/* setup-api#ensure-directory in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_4378(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4378,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4382,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 615  pathname-directory");
((C_proc3)C_retrieve_symbol_proc(lf[244]))(3,*((C_word*)lf[244]+1),t3,t2);}

/* k4380 in setup-api#ensure-directory in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4391,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 616  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t3,t1);}
else{
t3=t2;
f_4385(2,t3,C_SCHEME_FALSE);}}

/* k4389 in k4380 in setup-api#ensure-directory in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4391,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 617  directory?");
((C_proc3)C_retrieve_symbol_proc(lf[242]))(3,*((C_word*)lf[242]+1),t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 620  create-directory/parents");
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2]);}}

/* k4401 in k4389 in k4380 in setup-api#ensure-directory in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[3];
f_4385(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4429,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 622  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}}

/* k4427 in k4401 in k4389 in k4380 in setup-api#ensure-directory in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4429,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[243],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t5);}

/* k4395 in k4389 in k4380 in setup-api#ensure-directory in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_4385(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("setup-api.scm: 618  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],lf[241]);}}

/* k4383 in k4380 in setup-api#ensure-directory in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#repo-path in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_4320(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4320,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4324,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4324(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4324(2,t5,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4322 in setup-api#repo-path in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4337,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 608  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[169]))(2,*((C_word*)lf[169]+1),t3);}
else{
C_trace("setup-api.scm: 610  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[179]))(2,*((C_word*)lf[179]+1),t2);}}

/* k4335 in k4322 in setup-api#repo-path in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4341,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t2);}

/* k4339 in k4335 in k4322 in setup-api#repo-path in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4344,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[240],t1);}

/* k4342 in k4339 in k4335 in k4322 in setup-api#repo-path in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_fudge(C_fix(42));
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,t3,((C_word*)t0)[2]);}

/* k4345 in k4342 in k4339 in k4335 in k4322 in setup-api#repo-path in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k4348 in k4345 in k4342 in k4339 in k4335 in k4322 in setup-api#repo-path in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 607  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4325 in k4322 in setup-api#repo-path in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4330,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 611  ensure-directory");
f_4378(t2,t1);}

/* k4328 in k4325 in k4322 in setup-api#repo-path in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4190r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4190r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4190r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4194,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_4194(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4194(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4200,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 586  setup-install-mode");
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t2);}

/* k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4200,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
C_trace("setup-api.scm: 587  check-filelist");
f_3436(t2,t4);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4201 in k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4206,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 588  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[169]))(2,*((C_word*)lf[169]+1),t2);}

/* k4204 in k4201 in k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4289,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 589  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t3,t1,lf[239]);}

/* k4287 in k4204 in k4201 in k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 589  ensure-directory");
f_4378(((C_word*)t0)[2],t1);}

/* k4207 in k4204 in k4201 in k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4243,a[2]=t1,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t4=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4242 in k4207 in k4204 in k4201 in k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4243,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4250,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 592  make-dest-pathname");
f_3411(t5,((C_word*)t0)[2],t2);}

/* k4248 in a4242 in k4207 in k4204 in k4201 in k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4253,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 593  copy-file");
((C_proc4)C_retrieve_symbol_proc(lf[185]))(4,*((C_word*)lf[185]+1),t2,((C_word*)t0)[2],t1);}

/* k4251 in k4248 in a4242 in k4207 in k4204 in k4201 in k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_4256(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4279,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 595  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}}

/* k4277 in k4251 in k4248 in a4242 in k4207 in k4204 in k4201 in k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4279,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[176],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t5);}

/* k4254 in k4251 in k4248 in a4242 in k4207 in k4204 in k4201 in k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4210 in k4207 in k4204 in k4201 in k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4215,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_4215(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4241,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 599  string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[94]))(4,*((C_word*)lf[94]+1),t3,t1,lf[238]);}}

/* k4239 in k4210 in k4207 in k4204 in k4201 in k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4241,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[220],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t5);}

/* k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4192 in setup-api#install-script in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 600  write-info");
f_3058(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4039r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4039r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4039r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4043,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_4043(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4043(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4045,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4059,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 564  setup-install-mode");
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t3);}

/* k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4059,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
C_trace("setup-api.scm: 565  check-filelist");
f_3436(t2,t4);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4065,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 566  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[169]))(2,*((C_word*)lf[169]+1),t2);}

/* k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4159,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 567  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t3,t1,lf[236]);}

/* k4157 in k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 567  ensure-directory");
f_4378(((C_word*)t0)[2],t1);}

/* k4066 in k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4071,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4126,a[2]=((C_word*)t0)[3],a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t4=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4071(2,t3,((C_word*)t0)[2]);}}

/* a4125 in k4066 in k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4126,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4140,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
C_trace("setup-api.scm: 571  exify");
f_4045(t3,t4);}
else{
C_trace("setup-api.scm: 572  exify");
f_4045(t1,t2);}}

/* k4138 in a4125 in k4066 in k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4144,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 571  exify");
f_4045(t2,t3);}

/* k4142 in k4138 in a4125 in k4066 in k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4144,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k4069 in k4066 in k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4079,a[2]=((C_word*)t0)[2],a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t4=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a4078 in k4069 in k4066 in k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4079,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4086,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 577  make-dest-pathname");
f_3411(t5,((C_word*)t0)[2],t2);}

/* k4084 in a4078 in k4069 in k4066 in k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4089,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 578  copy-file");
((C_proc4)C_retrieve_symbol_proc(lf[185]))(4,*((C_word*)lf[185]+1),t2,((C_word*)t0)[2],t1);}

/* k4087 in k4084 in a4078 in k4069 in k4066 in k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_4092(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4115,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 580  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}}

/* k4113 in k4087 in k4084 in a4078 in k4069 in k4066 in k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4115,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[176],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t5);}

/* k4090 in k4087 in k4084 in a4078 in k4069 in k4066 in k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4072 in k4069 in k4066 in k4063 in k4060 in k4057 in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 583  write-info");
f_3058(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* exify in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_4045(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4045,NULL,2,t1,t2);}
t3=(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))?lf[231]:C_SCHEME_FALSE);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3490,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3490(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3490(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3488 in exify in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3497,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 488  pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t2,((C_word*)t0)[2]);}

/* k3495 in k3488 in exify in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=t1;
if(C_truep(t3)){
if(C_truep((C_word)C_i_equalp(lf[232],t1))){
t4=t2;
f_3500(t4,C_retrieve(lf[89]));}
else{
t4=(C_word)C_i_equalp(lf[233],t1);
t5=t2;
f_3500(t5,(C_truep(t4)?(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))?lf[234]:lf[235]):t1));}}
else{
t4=t2;
f_3500(t4,((C_word*)t0)[2]);}}

/* k3498 in k3495 in k3488 in exify in k4041 in setup-api#install-program in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 487  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3725r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3725r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3725r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3729,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3729(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3729(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 518  setup-install-mode");
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t2);}

/* k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3735,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3738,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
C_trace("setup-api.scm: 519  check-filelist");
f_3436(t2,t4);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3741,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 520  repo-path");
f_4320(t2,C_SCHEME_END_OF_LIST);}

/* k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3744,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 521  repo-path");
f_4320(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3747,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3873,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word)li56),tmp=(C_word)a,a+=6,tmp);
C_trace("map");
t4=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3873,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3880,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 524  make-dest-pathname");
f_3411(t5,((C_word*)t0)[2],t2);}

/* k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3883,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3973,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve2(lf[14],"setup-api#*windows*");
if(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))){
t5=t3;
f_3973(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4002,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 526  pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t5,t1);}}

/* k4000 in k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3973(t2,(C_word)C_i_equalp(lf[229],t1));}

/* k3971 in k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3973(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3973,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 527  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3883(2,t2,C_SCHEME_UNDEFINED);}}

/* k3990 in k3971 in k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3992,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[31],"setup-api#*remove-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t4);}

/* k3881 in k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-api.scm: 528  copy-file");
((C_proc4)C_retrieve_symbol_proc(lf[185]))(4,*((C_word*)lf[185]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3884 in k3881 in k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3889(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3970,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 530  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[3]);}}

/* k3968 in k3884 in k3881 in k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3970,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[176],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t5);}

/* k3887 in k3884 in k3881 in k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3889,2,t0,t1);}
t2=(C_word)C_i_assq(lf[201],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 532  software-version");
((C_proc2)C_retrieve_symbol_proc(lf[228]))(2,*((C_word*)lf[228]+1),t5);}
else{
t4=t3;
f_3895(2,t4,C_SCHEME_FALSE);}}

/* k3945 in k3887 in k3884 in k3881 in k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[226]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_equalp(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 534  pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
f_3904(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_3904(t3,C_SCHEME_FALSE);}}

/* k3937 in k3945 in k3887 in k3884 in k3881 in k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3904(t2,(C_word)C_i_equalp(t1,lf[227]));}

/* k3902 in k3887 in k3884 in k3881 in k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3904(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3904,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3923,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 535  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3895(2,t2,C_SCHEME_UNDEFINED);}}

/* k3921 in k3902 in k3887 in k3884 in k3881 in k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3923,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*ranlib-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t4);}

/* k3893 in k3887 in k3884 in k3881 in k3878 in a3872 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 536  make-dest-pathname");
f_3411(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3750,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 538  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[169]))(2,*((C_word*)lf[169]+1),t2);}

/* k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3871,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 539  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t3,t1,lf[225]);}

/* k3869 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 539  ensure-directory");
f_4378(((C_word*)t0)[2],t1);}

/* k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3753,2,t0,t1);}
t2=(C_word)C_i_assq(lf[217],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3759,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3831,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 541  print");
((C_proc5)C_retrieve_proc(*((C_word*)lf[49]+1)))(5,*((C_word*)lf[49]+1),t4,lf[223],t1,lf[224]);}
else{
t4=t3;
f_3759(2,t4,C_SCHEME_FALSE);}}

/* k3829 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3834,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3843,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3843(t7,t2,t3);}

/* loop990 in k3829 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3843(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3843,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3856,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3867,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 544  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t5,((C_word*)t0)[2],t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3865 in loop990 in k3829 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 544  copy-file");
((C_proc5)C_retrieve_symbol_proc(lf[185]))(5,*((C_word*)lf[185]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k3854 in loop990 in k3829 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3843(t3,((C_word*)t0)[2],t2);}

/* k3832 in k3829 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 546  newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[219]+1)))(2,*((C_word*)lf[219]+1),((C_word*)t0)[2]);}

/* k3757 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3759,2,t0,t1);}
t2=(C_word)C_i_assq(lf[218],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3765,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3771,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 548  print");
((C_proc5)C_retrieve_proc(*((C_word*)lf[49]+1)))(5,*((C_word*)lf[49]+1),t4,lf[221],((C_word*)t0)[2],lf[222]);}
else{
t4=t3;
f_3765(2,t4,C_SCHEME_FALSE);}}

/* k3769 in k3757 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3774,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3783,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3783(t7,t2,t3);}

/* loop1006 in k3769 in k3757 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3783(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3783,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3796,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 551  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t4,((C_word*)t0)[2],t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3794 in loop1006 in k3769 in k3757 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3799,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 552  copy-file");
((C_proc5)C_retrieve_symbol_proc(lf[185]))(5,*((C_word*)lf[185]+1),t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k3797 in k3794 in loop1006 in k3769 in k3757 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3802(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[220],t3);
t5=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*chmod-command*"),t4);
t6=(C_word)C_a_i_list(&a,1,t5);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,t6);}}

/* k3800 in k3797 in k3794 in loop1006 in k3769 in k3757 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3783(t3,((C_word*)t0)[2],t2);}

/* k3772 in k3769 in k3757 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 556  newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[219]+1)))(2,*((C_word*)lf[219]+1),((C_word*)t0)[2]);}

/* k3763 in k3757 in k3751 in k3748 in k3745 in k3742 in k3739 in k3736 in k3733 in k3727 in setup-api#install-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 557  write-info");
f_3058(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_3539r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3539r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3539r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3543,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3722,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),t5,lf[216],t4,t6);}

/* a3721 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3722,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3546,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3719,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),t2,lf[215],((C_word*)t0)[2],t3);}

/* a3718 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3719,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3549,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 498  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[111]))(3,*((C_word*)lf[111]+1),t2,((C_word*)t0)[3]);}

/* k3547 in k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3552,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-api.scm: 499  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[109]))(5,*((C_word*)lf[109]+1),t2,C_SCHEME_FALSE,t1,lf[214]);}

/* k3550 in k3547 in k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 500  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[109]))(5,*((C_word*)lf[109]+1),t2,C_SCHEME_FALSE,((C_word*)t0)[2],lf[213]);}

/* k3553 in k3550 in k3547 in k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3558,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[210],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[211],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[206],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[207],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[208],t8);
t10=(C_word)C_a_i_list(&a,1,t9);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,t10);}

/* k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[40],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[209],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[210],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[211],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[206],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[212],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[208],t10);
t12=(C_word)C_a_i_list(&a,1,t11);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,t12);}
else{
t3=t2;
f_3561(2,t3,C_SCHEME_UNDEFINED);}}

/* k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[205],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[206],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[207],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[208],t6);
t8=(C_word)C_a_i_list(&a,1,t7);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,t8);}

/* k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 508  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),t2,((C_word*)t0)[2],lf[204]);}

/* k3612 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 509  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[109]))(5,*((C_word*)lf[109]+1),t2,C_SCHEME_FALSE,((C_word*)t0)[2],lf[203]);}

/* k3616 in k3612 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3618,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[8],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[199],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3583,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3587,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3591,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3606,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 512  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[109]))(5,*((C_word*)lf[109]+1),t8,C_SCHEME_FALSE,((C_word*)t0)[8],lf[202]);}
else{
t8=t7;
f_3591(t8,C_SCHEME_END_OF_LIST);}}

/* k3604 in k3616 in k3612 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[201],t2);
t4=((C_word*)t0)[2];
f_3591(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k3589 in k3616 in k3612 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[184]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3585 in k3616 in k3612 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[184]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3581 in k3616 in k3612 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in setup-api#standard-extension in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3583,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
C_trace("setup-api.scm: 505  install-extension");
((C_proc5)C_retrieve_symbol_proc(lf[200]))(5,*((C_word*)lf[200]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* setup-api#check-filelist in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3436(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3436,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3442,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t4=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a3441 in setup-api#check-filelist in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3442,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3455,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
C_trace("setup-api.scm: 481  every");
((C_proc4)C_retrieve_symbol_proc(lf[156]))(4,*((C_word*)lf[156]+1),t3,*((C_word*)lf[157]+1),t2);}
else{
t4=t3;
f_3455(2,t4,C_SCHEME_FALSE);}}}

/* k3453 in a3441 in setup-api#check-filelist in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
t5=t2;
f_3458(t5,(C_word)C_a_i_list(&a,2,t3,t4));}
else{
t3=t2;
f_3458(t3,C_SCHEME_FALSE);}}}

/* k3456 in k3453 in a3441 in setup-api#check-filelist in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
C_trace("setup-api.scm: 483  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[197],((C_word*)t0)[2]);}}

/* setup-api#make-dest-pathname in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3411(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3411,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cadr(t3);
C_trace("setup-api.scm: 473  make-dest-pathname");
t7=t1;
t8=t2;
t9=t4;
t1=t7;
t2=t8;
t3=t9;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3431,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 474  absolute-pathname?");
((C_proc3)C_retrieve_symbol_proc(lf[195]))(3,*((C_word*)lf[195]+1),t4,t3);}}

/* k3429 in setup-api#make-dest-pathname in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
C_trace("setup-api.scm: 476  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* setup-api#remove-file* in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3389,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3409,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 469  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,t2);}

/* k3407 in setup-api#remove-file* in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3409,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[31],"setup-api#*remove-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t4);}

/* setup-api#move-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3334,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_car(t2):t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3341,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_cadr(t2);
C_trace("setup-api.scm: 464  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t6,t3,t7);}
else{
t7=t6;
f_3341(2,t7,t3);}}

/* k3339 in setup-api#move-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 465  ensure-directory");
f_4378(t2,t1);}

/* k3342 in k3339 in setup-api#move-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3363,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 466  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k3361 in k3342 in k3339 in setup-api#move-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3371,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 466  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k3369 in k3361 in k3342 in k3339 in setup-api#move-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3371,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*move-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t5);}

/* setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3187r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3187r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3187r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3189,a[2]=t3,a[3]=t2,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3277,a[2]=t5,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3286,a[2]=t6,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-err765798");
t8=t7;
f_3286(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("def-prefix766796");
t10=t6;
f_3277(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("body763771");
t12=t5;
f_3189(t12,t1,t8,t10);}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-err765 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3286(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3286,NULL,2,t0,t1);}
C_trace("def-prefix766796");
t2=((C_word*)t0)[2];
f_3277(t2,t1,C_SCHEME_TRUE);}

/* def-prefix766 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3277(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3277,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3285,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 447  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[169]))(2,*((C_word*)lf[169]+1),t3);}

/* k3283 in def-prefix766 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("body763771");
t2=((C_word*)t0)[4];
f_3189(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body763 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3189(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3189,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(((C_word*)t0)[3]);
t5=(C_truep(t4)?(C_word)C_i_car(((C_word*)t0)[3]):((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3196,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 450  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t6,((C_word*)t0)[2],t7);}
else{
t7=t6;
f_3196(2,t7,((C_word*)t0)[2]);}}

/* k3194 in body763 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3260,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 451  string-prefix?");
((C_proc4)C_retrieve_symbol_proc(lf[191]))(4,*((C_word*)lf[191]+1),t3,((C_word*)t0)[2],t1);}

/* k3258 in k3194 in body763 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3199(2,t2,((C_word*)t0)[3]);}
else{
C_trace("setup-api.scm: 452  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k3197 in k3194 in body763 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 454  ensure-directory");
f_4378(t2,t1);}

/* k3200 in k3197 in k3194 in body763 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 455  glob?");
((C_proc3)C_retrieve_symbol_proc(lf[189]))(3,*((C_word*)lf[189]+1),t2,((C_word*)t0)[3]);}

/* k3206 in k3200 in k3197 in k3194 in body763 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3211(2,t3,t1);}
else{
C_trace("setup-api.scm: 455  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t2,((C_word*)t0)[3]);}}

/* k3209 in k3206 in k3200 in k3197 in k3194 in body763 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3211,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 457  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-api.scm: 459  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[5],lf[186],((C_word*)t0)[3]);}
else{
C_trace("setup-api.scm: 460  warning");
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),((C_word*)t0)[5],lf[188],((C_word*)t0)[3]);}}}

/* k3228 in k3209 in k3206 in k3200 in k3197 in k3194 in body763 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3238,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 457  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k3236 in k3228 in k3209 in k3206 in k3200 in k3197 in k3194 in body763 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3238,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[30],"setup-api#*copy-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t5);}

/* k3212 in k3209 in k3206 in k3200 in k3197 in k3194 in body763 in setup-api#copy-file in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3058(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3058,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3185,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t6=*((C_word*)lf[184]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_SCHEME_END_OF_LIST);}

/* k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3185,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[175],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3181,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t4=*((C_word*)lf[184]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3181,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3065,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3155,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 437  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t4);}

/* k3153 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3155,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[59]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t3,lf[183],t2);}
else{
t2=((C_word*)t0)[4];
f_3065(2,t2,C_SCHEME_UNDEFINED);}}

/* k3156 in k3153 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k3159 in k3156 in k3153 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[182],((C_word*)t0)[3]);}

/* k3162 in k3159 in k3156 in k3153 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3165 in k3162 in k3159 in k3156 in k3153 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[181],((C_word*)t0)[2]);}

/* k3168 in k3165 in k3162 in k3159 in k3156 in k3153 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 438  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[111]))(3,*((C_word*)lf[111]+1),t2,((C_word*)t0)[2]);}

/* k3066 in k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3152,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 439  repo-path");
f_4320(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k3150 in k3066 in k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3152,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2999,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("setup-api.scm: 414  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[179]))(2,*((C_word*)lf[179]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2999(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2997 in k3150 in k3066 in k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 415  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[109]))(5,*((C_word*)lf[109]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[178]);}

/* k3069 in k3066 in k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3074,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[12],"setup-api#*sudo*"))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3103,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 441  create-temporary-file");
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[2],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 444  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[79]))(4,*((C_word*)lf[79]+1),t2,t1,t3);}}

/* a3143 in k3069 in k3066 in k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3144,2,t0,t1);}
C_trace("pp");
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t1,((C_word*)t0)[2]);}

/* k3101 in k3069 in k3066 in k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3106,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3135,a[2]=((C_word*)t0)[2],a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 442  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[79]))(4,*((C_word*)lf[79]+1),t2,t1,t3);}

/* a3134 in k3101 in k3069 in k3066 in k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
C_trace("pp");
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t1,((C_word*)t0)[2]);}

/* k3104 in k3101 in k3069 in k3066 in k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 443  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k3123 in k3104 in k3101 in k3069 in k3066 in k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3133,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 443  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k3131 in k3123 in k3104 in k3101 in k3069 in k3066 in k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*move-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t5);}

/* k3072 in k3069 in k3066 in k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3074,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3100,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 445  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}}

/* k3098 in k3072 in k3069 in k3066 in k3063 in k3179 in k3183 in setup-api#write-info in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3100,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[176],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t5);}

/* f_5440 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5440,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5444,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 431  verb");
f_3031(t3,t2);}

/* k5442 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5467,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 432  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k5465 in k5442 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5467,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[172],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[35],"setup-api#*mkdir-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t5);}

/* f_5432 in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5432,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5436,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 428  verb");
f_3031(t3,t2);}

/* k5434 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 429  create-directory");
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* verb in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_3031(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3031,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3038,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 425  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t3);}

/* k3036 in verb in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3038,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[59]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3041,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t3,lf[170],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3039 in k3036 in verb in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3042 in k3039 in k3036 in verb in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k3045 in k3042 in k3039 in k3036 in verb in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k3048 in k3045 in k3042 in k3039 in k3036 in verb in k3026 in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#flush-output");
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#make/proc in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2952r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2952r(t0,t1,t2,t3);}}

static void C_ccall f_2952r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=(C_word)C_i_length(t3);
switch(t4){
case C_fix(0):
t5=t2;
C_trace("setup-api.scm: 373  make:make/proc/helper");
f_2521(t1,t5,C_SCHEME_END_OF_LIST);
case C_fix(1):
t5=t2;
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2984,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(t6))){
C_trace("setup-api.scm: 378  vector->list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t8,t6);}
else{
t9=t8;
f_2984(2,t9,t6);}
default:
C_trace("##sys#error");
t5=*((C_word*)lf[167]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[168]);}}

/* k2982 in setup-api#make/proc in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 375  make:make/proc/helper");
f_2521(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_2521(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2521,NULL,3,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2525,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2950,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 307  vector->list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_2525(t6,C_SCHEME_UNDEFINED);}}

/* k2948 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2525(t3,t2);}

/* k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_2525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2525,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2353,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2353(2,t6,t4);}
else{
C_trace("setup-api.scm: 279  make:form-error");
f_2293(t5,lf[164],t3);}}

/* k2351 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2353,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_pairp(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2362,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_2362(2,t4,t2);}
else{
C_trace("setup-api.scm: 280  make:form-error");
f_2293(t3,lf[163],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
f_2528(2,t2,C_SCHEME_FALSE);}}

/* k2360 in k2351 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2362,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2367,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 281  every");
((C_proc4)C_retrieve_symbol_proc(lf[156]))(4,*((C_word*)lf[156]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2528(2,t2,C_SCHEME_FALSE);}}

/* a2366 in k2360 in k2351 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2367,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2374,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
C_trace("setup-api.scm: 283  <=");
C_less_or_equal_p(5,0,t3,C_fix(2),t4,C_fix(3));}
else{
t4=t3;
f_2374(2,t4,C_SCHEME_FALSE);}}

/* k2372 in a2366 in k2360 in k2351 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2377(2,t3,t1);}
else{
C_trace("setup-api.scm: 284  make:form-error");
f_2293(t2,lf[162],((C_word*)t0)[3]);}}

/* k2375 in k2372 in a2366 in k2360 in k2351 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2377,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_stringp(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2386(2,t5,t3);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_listp(t5))){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("setup-api.scm: 287  every");
((C_proc4)C_retrieve_symbol_proc(lf[156]))(4,*((C_word*)lf[156]+1),t4,*((C_word*)lf[157]+1),t6);}
else{
t6=t4;
f_2386(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2384 in k2375 in k2372 in a2366 in k2360 in k2351 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2389(2,t3,t1);}
else{
C_trace("setup-api.scm: 288  make:form-error");
f_2293(t2,lf[161],((C_word*)t0)[3]);}}

/* k2387 in k2384 in k2375 in k2372 in a2366 in k2360 in k2351 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2389,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2398,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2398(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2428,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 291  make:line-error");
f_2315(t6,lf[160],t7,t2);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2426 in k2387 in k2384 in k2375 in k2372 in a2366 in k2360 in k2351 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2428,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2398(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2436,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("setup-api.scm: 292  every");
((C_proc4)C_retrieve_symbol_proc(lf[156]))(4,*((C_word*)lf[156]+1),((C_word*)t0)[3],t2,t3);}}

/* a2435 in k2426 in k2387 in k2384 in k2375 in k2372 in a2366 in k2360 in k2351 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2436,3,t0,t1,t2);}
t3=(C_word)C_i_stringp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
C_trace("setup-api.scm: 294  make:form-error");
f_2293(t1,lf[159],t2);}}

/* k2396 in k2387 in k2384 in k2375 in k2372 in a2366 in k2360 in k2351 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_closurep(t4);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_caddr(((C_word*)t0)[4]);
C_trace("setup-api.scm: 298  make:line-error");
f_2315(((C_word*)t0)[3],lf[158],t6,((C_word*)t0)[2]);}}}

/* k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_stringp(t3);
if(C_truep(t4)){
t5=t2;
f_2531(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2513,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 303  every");
((C_proc4)C_retrieve_symbol_proc(lf[156]))(4,*((C_word*)lf[156]+1),t5,*((C_word*)lf[157]+1),t3);}}

/* k2511 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2531(2,t2,t1);}
else{
C_trace("setup-api.scm: 304  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[155],((C_word*)t0)[2]);}}

/* k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2531,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t9,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 311  condition-predicate");
((C_proc3)C_retrieve_symbol_proc(lf[154]))(3,*((C_word*)lf[154]+1),t11,lf[152]);}

/* k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2536,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 312  condition-property-accessor");
((C_proc4)C_retrieve_symbol_proc(lf[151]))(4,*((C_word*)lf[151]+1),t3,lf[152],lf[153]);}

/* k2538 in k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2540,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word)li29),tmp=(C_word)a,a+=8,tmp));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[2])[1]))){
C_trace("setup-api.scm: 363  make-file");
t5=((C_word*)((C_word*)t0)[7])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[2])[1],lf[147]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2918,a[2]=t4,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 364  caar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[149]+1)))(3,*((C_word*)lf[149]+1),t5,((C_word*)t0)[4]);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[7],a[3]=t6,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2923(t8,t4,((C_word*)((C_word*)t0)[2])[1]);}}}

/* loop549 in k2538 in k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_2923(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2923,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2936,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 365  make-file");
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[150]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2934 in loop549 in k2538 in k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2923(t3,((C_word*)t0)[2],t2);}

/* k2916 in k2538 in k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 364  make-file");
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[148]);}

/* k2856 in k2538 in k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 366  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t2);}

/* k2862 in k2856 in k2538 in k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 369  reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2869 in k2862 in k2856 in k2538 in k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2873,a[2]=t3,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2873(t5,((C_word*)t0)[2],t1);}

/* loop561 in k2869 in k2862 in k2856 in k2538 in k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_2873(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2873,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=*((C_word*)lf[59]+1);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2886,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t5,lf[145],t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2884 in loop561 in k2869 in k2862 in k2856 in k2538 in k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2887 in k2884 in loop561 in k2869 in k2862 in k2856 in k2538 in k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2890 in k2887 in k2884 in loop561 in k2869 in k2862 in k2856 in k2538 in k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2873(t3,((C_word*)t0)[2],t2);}

/* f_2542 in k2538 in k2534 in k2529 in k2526 in k2523 in setup-api#make:make/proc/helper in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2542,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=t2;
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2239,a[2]=t5,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2248,a[2]=t7,a[3]=t9,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2248(t11,t4,t6);}

/* loop */
static void C_fcall f_2248(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2248,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_stringp(t5))){
t6=(C_word)C_i_car(t3);
t7=t4;
f_2261(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t4;
f_2261(t6,(C_word)C_i_car(t3));}}}

/* k2259 in loop */
static void C_fcall f_2261(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2261,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 271  any");
((C_proc4)C_retrieve_symbol_proc(lf[140]))(4,*((C_word*)lf[140]+1),t2,((C_word*)t0)[2],t1);}

/* k2265 in k2259 in loop */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 273  loop");
t3=((C_word*)((C_word*)t0)[2])[1];
f_2248(t3,((C_word*)t0)[5],t2);}}

/* match? */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2239,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,((C_word*)t0)[2]));}

/* k2544 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api.scm: 316  fixmaketarget");
f_2136(t2,((C_word*)t0)[7]);}

/* k2547 in k2544 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2852,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 317  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t3,t1);}

/* k2850 in k2547 in k2544 */
static void C_ccall f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 318  file-modification-time");
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2552(2,t2,C_SCHEME_FALSE);}}

/* k2550 in k2547 in k2544 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 319  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t3);}

/* k2832 in k2550 in k2547 in k2544 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2834,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[59]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t3,lf[144],t2);}
else{
t2=((C_word*)t0)[4];
f_2555(2,t2,C_SCHEME_UNDEFINED);}}

/* k2835 in k2832 in k2550 in k2547 in k2544 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2838 in k2835 in k2832 in k2550 in k2547 in k2544 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[143],((C_word*)t0)[3]);}

/* k2841 in k2838 in k2835 in k2832 in k2550 in k2547 in k2544 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2844 in k2841 in k2838 in k2835 in k2832 in k2550 in k2547 in k2544 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2555,2,t0,t1);}
if(C_truep(((C_word*)t0)[11])){
t2=(C_word)C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2564,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2783(t7,t3,t2);}
else{
if(C_truep(((C_word*)t0)[10])){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t2);}}}

/* k2820 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2825,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[142],t1);}

/* k2823 in k2820 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2826 in k2823 in k2820 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k2829 in k2826 in k2823 in k2820 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 361  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* loop452 in k2553 in k2550 in k2547 in k2544 */
static void C_fcall f_2783(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2783,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2793,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2807,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 323  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t5,lf[141],((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2805 in loop452 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2808,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_2808 in k2805 in loop452 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2808,3,t0,t1,t2);}
C_trace("setup-api.scm: 324  make-file");
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k2791 in loop452 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2783(t3,((C_word*)t0)[2],t2);}

/* k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2564,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_2570(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2739,a[2]=((C_word*)t0)[11],a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 328  any");
((C_proc4)C_retrieve_symbol_proc(lf[140]))(4,*((C_word*)lf[140]+1),t3,t4,((C_word*)t0)[2]);}}

/* a2738 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2739,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2743,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 329  fixmaketarget");
f_2136(t3,t2);}

/* k2741 in a2738 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2746,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2759,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 330  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t3,t1);}

/* k2757 in k2741 in a2738 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2759,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2746(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t2);}}

/* k2764 in k2757 in k2741 in a2738 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2769,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[138],t1);}

/* k2767 in k2764 in k2757 in k2741 in a2738 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2770 in k2767 in k2764 in k2757 in k2741 in a2738 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[137],((C_word*)t0)[2]);}

/* k2773 in k2770 in k2767 in k2764 in k2757 in k2741 in a2738 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2776 in k2773 in k2770 in k2767 in k2764 in k2757 in k2741 in a2738 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2757 in k2741 in a2738 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 331  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* k2744 in k2741 in a2738 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 332  file-modification-time");
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),t2,((C_word*)t0)[2]);}

/* k2754 in k2744 in k2741 in a2738 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_greaterp(t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2589,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 339  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t6);}}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[59]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t3,lf[135],t2);}
else{
t2=((C_word*)t0)[6];
f_2589(2,t2,C_SCHEME_UNDEFINED);}}

/* k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2676 in k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[134],((C_word*)t0)[5]);}

/* k2679 in k2676 in k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k2682 in k2679 in k2676 in k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2687,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
if(C_truep(t4)){
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
C_trace("setup-api.scm: 347  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[127]+1)))(5,*((C_word*)lf[127]+1),t3,lf[128],((C_word*)t0)[3],lf[129]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t5);}}
else{
C_trace("setup-api.scm: 345  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[127]+1)))(5,*((C_word*)lf[127]+1),t3,lf[132],((C_word*)t0)[2],lf[133]);}}

/* k2714 in k2682 in k2679 in k2676 in k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[131],t1);}

/* k2717 in k2714 in k2682 in k2679 in k2676 in k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2720 in k2717 in k2714 in k2682 in k2679 in k2676 in k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[130],((C_word*)t0)[3]);}

/* k2723 in k2720 in k2717 in k2714 in k2682 in k2679 in k2676 in k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2726 in k2723 in k2720 in k2717 in k2714 in k2682 in k2679 in k2676 in k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[2]);}

/* k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2682 in k2679 in k2676 in k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2682 in k2679 in k2676 in k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 349  string-append");
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),((C_word*)t0)[2],t1);}

/* k2692 in k2682 in k2679 in k2676 in k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2685 in k2682 in k2679 in k2676 in k2673 in k2670 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2595,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li23),tmp=(C_word)a,a+=7,tmp);
C_trace("call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,t3);}

/* a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2597,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2603,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li18),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2644,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li22),tmp=(C_word)a,a+=5,tmp);
C_trace("with-exception-handler");
((C_proc4)C_retrieve_symbol_proc(lf[125]))(4,*((C_word*)lf[125]+1),t1,t3,t4);}

/* a2643 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[3],a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[2],a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a2658 in a2643 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2659r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2659r(t0,t1,t2);}}

static void C_ccall f_2659r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2665,a[2]=t2,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
C_trace("k514517");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2664 in a2658 in a2643 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2665,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2649 in a2643 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=t2;
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* a2602 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2603,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li17),tmp=(C_word)a,a+=7,tmp);
C_trace("k514517");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2608 in a2602 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2609,2,t0,t1);}
t2=*((C_word*)lf[59]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t3,lf[124],t2);}

/* k2611 in a2608 in a2602 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,t3,((C_word*)t0)[5]);}

/* k2614 in k2611 in a2608 in a2602 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[123],((C_word*)t0)[4]);}

/* k2617 in k2614 in k2611 in a2608 in a2602 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2632,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 355  exn?");
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}

/* k2633 in k2617 in k2614 in k2611 in a2608 in a2602 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 356  exn-message");
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2632(2,t2,((C_word*)t0)[2]);}}

/* k2630 in k2617 in k2614 in k2611 in a2608 in a2602 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2620 in k2617 in k2614 in k2611 in a2608 in a2602 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2623 in k2620 in k2617 in k2614 in k2611 in a2608 in a2602 in a2596 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 358  signal");
((C_proc3)C_retrieve_symbol_proc(lf[122]))(3,*((C_word*)lf[122]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2593 in k2587 in k2568 in k2562 in k2553 in k2550 in k2547 in k2544 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* setup-api#make:line-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_2315(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2315,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2323,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t5);}

/* k2321 in setup-api#make:line-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],t1);}

/* k2324 in k2321 in setup-api#make:line-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[120],((C_word*)t0)[4]);}

/* k2327 in k2324 in k2321 in setup-api#make:line-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2332,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2330 in k2327 in k2324 in k2321 in setup-api#make:line-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[119],((C_word*)t0)[3]);}

/* k2333 in k2330 in k2327 in k2324 in k2321 in setup-api#make:line-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2338,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2336 in k2333 in k2330 in k2327 in k2324 in k2321 in setup-api#make:line-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k2339 in k2336 in k2333 in k2330 in k2327 in k2324 in k2321 in setup-api#make:line-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 276  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* setup-api#make:form-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_2293(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2293,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2301,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t4);}

/* k2299 in setup-api#make:form-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2304,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],t1);}

/* k2302 in k2299 in setup-api#make:form-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[117],((C_word*)t0)[3]);}

/* k2305 in k2302 in k2299 in setup-api#make:form-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2310,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2308 in k2305 in k2302 in k2299 in setup-api#make:form-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2313,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k2311 in k2308 in k2305 in k2302 in k2299 in setup-api#make:form-error in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 275  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2162,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2165,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2195,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t5=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k2193 in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2197,a[2]=t3,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2197(t5,((C_word*)t0)[2],t1);}

/* loop219 in k2193 in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_2197(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2197,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2210,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2223,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 245  run-verbose");
((C_proc2)C_retrieve_symbol_proc(lf[86]))(2,*((C_word*)lf[86]+1),t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2221 in loop219 in k2193 in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2223,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[59]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2226,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t3,lf[113],t2);}
else{
t2=((C_word*)t0)[3];
f_2210(2,t2,C_SCHEME_UNDEFINED);}}

/* k2224 in k2221 in loop219 in k2193 in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2227 in k2224 in k2221 in loop219 in k2193 in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2230 in k2227 in k2224 in k2221 in loop219 in k2193 in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#flush-output");
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2208 in loop219 in k2193 in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2213,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 246  $system");
f_5337(t2,((C_word*)t0)[2]);}

/* k2211 in k2208 in loop219 in k2193 in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2197(t3,((C_word*)t0)[2],t2);}

/* smooth in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2165,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2169,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t4=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[111]),t2);}

/* k2167 in smooth in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2180,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_string_equal_p(t3,lf[96]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2070,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2074,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2109,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_assoc(t3,C_retrieve2(lf[6],"setup-api#*installed-executables*"));
t8=(C_word)C_i_cdr(t7);
C_trace("setup-api.scm: 218  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t6,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"),t8);}
else{
t4=(C_word)C_i_assoc(t3,C_retrieve2(lf[6],"setup-api#*installed-executables*"));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2130,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t4);
C_trace("setup-api.scm: 230  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t5,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"),t6);}
else{
t5=t2;
f_2180(2,t5,t3);}}}

/* k2128 in k2167 in smooth in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 230  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),((C_word*)t0)[2],t1);}

/* k2107 in k2167 in smooth in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 217  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),((C_word*)t0)[2],t1);}

/* k2072 in k2167 in smooth in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2095,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2098,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 222  feature?");
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),t3,lf[108]);}

/* k2096 in k2072 in k2167 in smooth in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 223  host-extension");
((C_proc2)C_retrieve_symbol_proc(lf[15]))(2,*((C_word*)lf[15]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_2095(t2,C_SCHEME_FALSE);}}

/* k2103 in k2096 in k2072 in k2167 in smooth in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2095(t2,(C_word)C_i_not(t1));}

/* k2093 in k2072 in k2167 in smooth in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_2095(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2095,NULL,2,t0,t1);}
t2=(C_truep(t1)?lf[98]:lf[99]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2092,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 225  keep-intermediates");
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t3);}

/* k2090 in k2093 in k2072 in k2167 in smooth in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2092,2,t0,t1);}
t2=(C_truep(t1)?lf[100]:lf[101]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2089,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 226  host-extension");
((C_proc2)C_retrieve_symbol_proc(lf[15]))(2,*((C_word*)lf[15]+1),t3);}

/* k2087 in k2090 in k2093 in k2072 in k2167 in smooth in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[102]:lf[103]);
C_trace("setup-api.scm: 217  cons*");
((C_proc9)C_retrieve_symbol_proc(lf[104]))(9,*((C_word*)lf[104]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[105],lf[106],((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* k2068 in k2167 in smooth in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 216  string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[94]))(4,*((C_word*)lf[94]+1),((C_word*)t0)[2],t1,lf[97]);}

/* k2178 in k2167 in smooth in setup-api#execute in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
C_trace("setup-api.scm: 242  string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[94]))(4,*((C_word*)lf[94]+1),((C_word*)t0)[2],t3,lf[95]);}

/* setup-api#fixmaketarget in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_2136(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2136,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2143,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2160,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 234  pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t4,t2);}

/* k2158 in setup-api#fixmaketarget in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_equalp(lf[90],t1))){
t2=(C_word)C_i_string_equal_p(lf[91],C_retrieve(lf[89]));
t3=((C_word*)t0)[2];
f_2143(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_2143(t2,C_SCHEME_FALSE);}}

/* k2141 in setup-api#fixmaketarget in k2052 in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_2143(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 236  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_retrieve(lf[89]));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1937,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1941,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2038,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 195  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t6);}

/* k2036 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2038,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[59]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2041,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t3,lf[85],t2);}
else{
t2=((C_word*)t0)[3];
f_1941(2,t2,C_SCHEME_UNDEFINED);}}

/* k2039 in k2036 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2042 in k2039 in k2036 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[84],((C_word*)t0)[2]);}

/* k2045 in k2042 in k2039 in k2036 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
if(C_truep((C_word)C_i_listp(((C_word*)t0)[5]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li9),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 197  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[79]))(4,*((C_word*)lf[79]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 206  create-temporary-file");
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t2);}}

/* k1993 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1998,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,t1,t1);
C_trace("setup-api.scm: 207  patch");
((C_proc5)C_retrieve_symbol_proc(lf[75]))(5,*((C_word*)lf[75]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1996 in k1993 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t2);}

/* k2003 in k1996 in k1993 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,C_retrieve2(lf[32],"setup-api#*move-command*"),t1);}

/* k2006 in k2003 in k1996 in k1993 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k2009 in k2006 in k2003 in k1996 in k1993 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2031,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 209  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}

/* k2029 in k2009 in k2006 in k2003 in k1996 in k1993 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2012 in k2009 in k2006 in k2003 in k1996 in k1993 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k2015 in k2012 in k2009 in k2006 in k2003 in k1996 in k1993 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 210  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}

/* k2025 in k2015 in k2012 in k2009 in k2006 in k2003 in k1996 in k1993 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1996 in k1993 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2023,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2]);}

/* k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1996 in k1993 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 208  $system");
f_5337(((C_word*)t0)[2],t1);}

/* a1955 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1956,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 199  with-input-from-file");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t1,t2,t3);}

/* a1965 in a1955 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li7),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1972(t5,t1);}

/* loop in a1965 in a1955 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_1972(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1972,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 202  read-line");
((C_proc2)C_retrieve_symbol_proc(lf[68]))(2,*((C_word*)lf[68]+1),t2);}

/* k1974 in loop in a1965 in a1955 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1992,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 204  string-substitute");
((C_proc6)C_retrieve_symbol_proc(lf[77]))(6,*((C_word*)lf[77]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}}

/* k1990 in k1974 in loop in a1965 in a1955 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 204  write-line");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k1983 in k1974 in loop in a1965 in a1955 in k1939 in setup-api#patch in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 205  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_1972(t2,((C_word*)t0)[2]);}

/* setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1839r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1839r(t0,t1,t2,t3);}}

static void C_ccall f_1839r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1843,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[72]))(4,*((C_word*)lf[72]+1),t4,lf[74],t3);}

/* k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1931,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),t2,lf[73],((C_word*)t0)[2],t3);}

/* a1930 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
C_trace("setup-api.scm: 179  abort-setup");
((C_proc2)C_retrieve_symbol_proc(lf[57]))(2,*((C_word*)lf[57]+1),t1);}

/* k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li4),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1851(t5,((C_word*)t0)[2]);}

/* loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_1851(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1851,NULL,2,t0,t1);}
t2=*((C_word*)lf[59]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("write-char/port");
t4=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(10),t2);}

/* k1853 in loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1856 in k1853 in loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[71],((C_word*)t0)[2]);}

/* k1859 in k1856 in k1853 in loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[59]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t5=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(91),t3);}
else{
t3=t2;
f_1864(2,t3,C_SCHEME_UNDEFINED);}}

/* k1921 in k1859 in k1856 in k1853 in loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1924 in k1921 in k1859 in k1856 in k1853 in loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[3],lf[70],((C_word*)t0)[2]);}

/* k1862 in k1859 in k1856 in k1853 in loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 183  flush-output");
((C_proc2)C_retrieve_proc(*((C_word*)lf[69]+1)))(2,*((C_word*)lf[69]+1),t2);}

/* k1865 in k1862 in k1859 in k1856 in k1853 in loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 184  read-line");
((C_proc2)C_retrieve_symbol_proc(lf[68]))(2,*((C_word*)lf[68]+1),t2);}

/* k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_eofp(((C_word*)t3)[1]))){
t5=C_set_block_item(t3,0,lf[66]);
t6=t4;
f_1873(t6,t5);}
else{
t5=(C_truep(((C_word*)t0)[2])?(C_word)C_i_string_equal_p(lf[67],((C_word*)t3)[1]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_set_block_item(t3,0,((C_word*)t0)[2]);
t7=t4;
f_1873(t7,t6);}
else{
t6=t4;
f_1873(t6,C_SCHEME_UNDEFINED);}}}

/* k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_1873(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1873,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_string_ci_equal_p(lf[60],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_string_ci_equal_p(lf[61],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_string_ci_equal_p(lf[62],((C_word*)((C_word*)t0)[5])[1]))){
C_trace("setup-api.scm: 189  abort");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[4]);}
else{
t2=*((C_word*)lf[59]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1897,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t4=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(10),t2);}}}}

/* k1895 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t2,lf[65],((C_word*)t0)[2]);}

/* k1898 in k1895 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[63]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1901 in k1898 in k1895 in k1871 in k1868 in k1865 in k1862 in k1859 in k1856 in k1853 in loop in k1844 in k1841 in setup-api#yes-or-no? in k1835 in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 192  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_1851(t2,((C_word*)t0)[2]);}

/* setup-api#sudo-install in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1814r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1814r(t0,t1,t2);}}

static void C_ccall f_1814r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
if(C_truep((C_word)C_vemptyp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve2(lf[12],"setup-api#*sudo*"));}
else{
if(C_truep((C_word)C_i_vector_ref(t2,C_fix(0)))){
t3=t1;
t4=lf[12] /* setup-api#*sudo* */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t5=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
C_trace("setup-api.scm: 150  print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[49]+1)))(3,*((C_word*)lf[49]+1),t3,lf[50]);}
else{
t5=C_mutate(&lf[30] /* (set! setup-api#*copy-command* ...) */,lf[51]);
t6=C_mutate(&lf[31] /* (set! setup-api#*remove-command* ...) */,lf[52]);
t7=C_mutate(&lf[32] /* (set! setup-api#*move-command* ...) */,lf[53]);
t8=C_mutate(&lf[33] /* (set! setup-api#*chmod-command* ...) */,lf[54]);
t9=C_mutate(&lf[34] /* (set! setup-api#*ranlib-command* ...) */,lf[55]);
t10=C_mutate(&lf[35] /* (set! setup-api#*mkdir-command* ...) */,lf[56]);
t11=t3;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}}
else{
C_trace("setup-api.scm: 175  user-install-setup");
f_1788(t1);}}}

/* setup-api#user-install-setup in k1745 in k1741 in k1735 in k1731 in k1727 in k1723 in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_fcall f_1788(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1788,NULL,1,t1);}
t2=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t1;
t4=C_mutate(&lf[30] /* (set! setup-api#*copy-command* ...) */,lf[37]);
t5=C_mutate(&lf[31] /* (set! setup-api#*remove-command* ...) */,lf[38]);
t6=C_mutate(&lf[32] /* (set! setup-api#*move-command* ...) */,lf[39]);
t7=C_mutate(&lf[33] /* (set! setup-api#*chmod-command* ...) */,lf[40]);
t8=C_mutate(&lf[34] /* (set! setup-api#*ranlib-command* ...) */,lf[41]);
t9=t3;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t3=t1;
t4=C_mutate(&lf[30] /* (set! setup-api#*copy-command* ...) */,lf[42]);
t5=C_mutate(&lf[31] /* (set! setup-api#*remove-command* ...) */,lf[43]);
t6=C_mutate(&lf[32] /* (set! setup-api#*move-command* ...) */,lf[44]);
t7=C_mutate(&lf[33] /* (set! setup-api#*chmod-command* ...) */,lf[45]);
t8=C_mutate(&lf[34] /* (set! setup-api#*ranlib-command* ...) */,lf[46]);
t9=C_mutate(&lf[35] /* (set! setup-api#*mkdir-command* ...) */,lf[47]);
t10=t3;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* setup-api#cross-chicken in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1716,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fudge(C_fix(39)));}

/* setup-api#shellpath in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1706,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1714,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 109  normalize-pathname");
((C_proc3)C_retrieve_symbol_proc(lf[20]))(3,*((C_word*)lf[20]+1),t3,t2);}

/* k1712 in setup-api#shellpath in k1702 in k1699 in k1695 in k1692 in k1689 in k1685 in k1681 in k1678 in k1672 in k1668 in k1664 in k1660 in k1656 in k5529 in k5533 in k5537 in k5541 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 109  qs");
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[546] = {
{"toplevel:setup_api_scm",(void*)C_toplevel},
{"f_1607:setup_api_scm",(void*)f_1607},
{"f_1610:setup_api_scm",(void*)f_1610},
{"f_1613:setup_api_scm",(void*)f_1613},
{"f_1616:setup_api_scm",(void*)f_1616},
{"f_1619:setup_api_scm",(void*)f_1619},
{"f_1622:setup_api_scm",(void*)f_1622},
{"f_1625:setup_api_scm",(void*)f_1625},
{"f_1628:setup_api_scm",(void*)f_1628},
{"f_1631:setup_api_scm",(void*)f_1631},
{"f_1634:setup_api_scm",(void*)f_1634},
{"f_1637:setup_api_scm",(void*)f_1637},
{"f_1640:setup_api_scm",(void*)f_1640},
{"f_1643:setup_api_scm",(void*)f_1643},
{"f_1646:setup_api_scm",(void*)f_1646},
{"f_1649:setup_api_scm",(void*)f_1649},
{"f_5543:setup_api_scm",(void*)f_5543},
{"f_5539:setup_api_scm",(void*)f_5539},
{"f_5535:setup_api_scm",(void*)f_5535},
{"f_5531:setup_api_scm",(void*)f_5531},
{"f_1658:setup_api_scm",(void*)f_1658},
{"f_1662:setup_api_scm",(void*)f_1662},
{"f_1666:setup_api_scm",(void*)f_1666},
{"f_1670:setup_api_scm",(void*)f_1670},
{"f_1674:setup_api_scm",(void*)f_1674},
{"f_5499:setup_api_scm",(void*)f_5499},
{"f_1680:setup_api_scm",(void*)f_1680},
{"f_1683:setup_api_scm",(void*)f_1683},
{"f_1687:setup_api_scm",(void*)f_1687},
{"f_1691:setup_api_scm",(void*)f_1691},
{"f_1694:setup_api_scm",(void*)f_1694},
{"f_1697:setup_api_scm",(void*)f_1697},
{"f_1701:setup_api_scm",(void*)f_1701},
{"f_5477:setup_api_scm",(void*)f_5477},
{"f_1704:setup_api_scm",(void*)f_1704},
{"f_1725:setup_api_scm",(void*)f_1725},
{"f_1729:setup_api_scm",(void*)f_1729},
{"f_1733:setup_api_scm",(void*)f_1733},
{"f_1737:setup_api_scm",(void*)f_1737},
{"f_1743:setup_api_scm",(void*)f_1743},
{"f_1747:setup_api_scm",(void*)f_1747},
{"f_1837:setup_api_scm",(void*)f_1837},
{"f_2054:setup_api_scm",(void*)f_2054},
{"f_5471:setup_api_scm",(void*)f_5471},
{"f_3028:setup_api_scm",(void*)f_3028},
{"f_5362:setup_api_scm",(void*)f_5362},
{"f_5378:setup_api_scm",(void*)f_5378},
{"f_5415:setup_api_scm",(void*)f_5415},
{"f_5408:setup_api_scm",(void*)f_5408},
{"f_5412:setup_api_scm",(void*)f_5412},
{"f_5385:setup_api_scm",(void*)f_5385},
{"f_5035:setup_api_scm",(void*)f_5035},
{"f_5360:setup_api_scm",(void*)f_5360},
{"f_5337:setup_api_scm",(void*)f_5337},
{"f_5354:setup_api_scm",(void*)f_5354},
{"f_5341:setup_api_scm",(void*)f_5341},
{"f_5283:setup_api_scm",(void*)f_5283},
{"f_5335:setup_api_scm",(void*)f_5335},
{"f_5310:setup_api_scm",(void*)f_5310},
{"f_5320:setup_api_scm",(void*)f_5320},
{"f_5290:setup_api_scm",(void*)f_5290},
{"f_5301:setup_api_scm",(void*)f_5301},
{"f_5297:setup_api_scm",(void*)f_5297},
{"f_5158:setup_api_scm",(void*)f_5158},
{"f_5162:setup_api_scm",(void*)f_5162},
{"f_5262:setup_api_scm",(void*)f_5262},
{"f_5202:setup_api_scm",(void*)f_5202},
{"f_5206:setup_api_scm",(void*)f_5206},
{"f_5214:setup_api_scm",(void*)f_5214},
{"f_5243:setup_api_scm",(void*)f_5243},
{"f_5249:setup_api_scm",(void*)f_5249},
{"f_5227:setup_api_scm",(void*)f_5227},
{"f_5209:setup_api_scm",(void*)f_5209},
{"f_5184:setup_api_scm",(void*)f_5184},
{"f_5187:setup_api_scm",(void*)f_5187},
{"f_5197:setup_api_scm",(void*)f_5197},
{"f_5190:setup_api_scm",(void*)f_5190},
{"f_5193:setup_api_scm",(void*)f_5193},
{"f_5105:setup_api_scm",(void*)f_5105},
{"f_5109:setup_api_scm",(void*)f_5109},
{"f_5147:setup_api_scm",(void*)f_5147},
{"f_5153:setup_api_scm",(void*)f_5153},
{"f_5112:setup_api_scm",(void*)f_5112},
{"f_5117:setup_api_scm",(void*)f_5117},
{"f_5144:setup_api_scm",(void*)f_5144},
{"f_5140:setup_api_scm",(void*)f_5140},
{"f_5124:setup_api_scm",(void*)f_5124},
{"f_5130:setup_api_scm",(void*)f_5130},
{"f_5136:setup_api_scm",(void*)f_5136},
{"f_5091:setup_api_scm",(void*)f_5091},
{"f_5103:setup_api_scm",(void*)f_5103},
{"f_5099:setup_api_scm",(void*)f_5099},
{"f_5047:setup_api_scm",(void*)f_5047},
{"f_5051:setup_api_scm",(void*)f_5051},
{"f_5070:setup_api_scm",(void*)f_5070},
{"f_5060:setup_api_scm",(void*)f_5060},
{"f_5037:setup_api_scm",(void*)f_5037},
{"f_5045:setup_api_scm",(void*)f_5045},
{"f_4870:setup_api_scm",(void*)f_4870},
{"f_4901:setup_api_scm",(void*)f_4901},
{"f_4905:setup_api_scm",(void*)f_4905},
{"f_4907:setup_api_scm",(void*)f_4907},
{"f_4987:setup_api_scm",(void*)f_4987},
{"f_4873:setup_api_scm",(void*)f_4873},
{"f_4894:setup_api_scm",(void*)f_4894},
{"f_4890:setup_api_scm",(void*)f_4890},
{"f_4879:setup_api_scm",(void*)f_4879},
{"f_4883:setup_api_scm",(void*)f_4883},
{"f_4848:setup_api_scm",(void*)f_4848},
{"f_4856:setup_api_scm",(void*)f_4856},
{"f_4859:setup_api_scm",(void*)f_4859},
{"f_4862:setup_api_scm",(void*)f_4862},
{"f_4865:setup_api_scm",(void*)f_4865},
{"f_4868:setup_api_scm",(void*)f_4868},
{"f_4789:setup_api_scm",(void*)f_4789},
{"f_4797:setup_api_scm",(void*)f_4797},
{"f_4800:setup_api_scm",(void*)f_4800},
{"f_4803:setup_api_scm",(void*)f_4803},
{"f_4806:setup_api_scm",(void*)f_4806},
{"f_4809:setup_api_scm",(void*)f_4809},
{"f_4812:setup_api_scm",(void*)f_4812},
{"f_4815:setup_api_scm",(void*)f_4815},
{"f_4818:setup_api_scm",(void*)f_4818},
{"f_4821:setup_api_scm",(void*)f_4821},
{"f_4824:setup_api_scm",(void*)f_4824},
{"f_4827:setup_api_scm",(void*)f_4827},
{"f_4830:setup_api_scm",(void*)f_4830},
{"f_4833:setup_api_scm",(void*)f_4833},
{"f_4836:setup_api_scm",(void*)f_4836},
{"f_4839:setup_api_scm",(void*)f_4839},
{"f_4842:setup_api_scm",(void*)f_4842},
{"f_4846:setup_api_scm",(void*)f_4846},
{"f_4668:setup_api_scm",(void*)f_4668},
{"f_4674:setup_api_scm",(void*)f_4674},
{"f_4687:setup_api_scm",(void*)f_4687},
{"f_4699:setup_api_scm",(void*)f_4699},
{"f_4705:setup_api_scm",(void*)f_4705},
{"f_4745:setup_api_scm",(void*)f_4745},
{"f_4756:setup_api_scm",(void*)f_4756},
{"f_4760:setup_api_scm",(void*)f_4760},
{"f_4720:setup_api_scm",(void*)f_4720},
{"f_4727:setup_api_scm",(void*)f_4727},
{"f_4730:setup_api_scm",(void*)f_4730},
{"f_4733:setup_api_scm",(void*)f_4733},
{"f_4736:setup_api_scm",(void*)f_4736},
{"f_4739:setup_api_scm",(void*)f_4739},
{"f_4587:setup_api_scm",(void*)f_4587},
{"f_4591:setup_api_scm",(void*)f_4591},
{"f_4598:setup_api_scm",(void*)f_4598},
{"f_4601:setup_api_scm",(void*)f_4601},
{"f_4604:setup_api_scm",(void*)f_4604},
{"f_4607:setup_api_scm",(void*)f_4607},
{"f_4610:setup_api_scm",(void*)f_4610},
{"f_4613:setup_api_scm",(void*)f_4613},
{"f_4616:setup_api_scm",(void*)f_4616},
{"f_4619:setup_api_scm",(void*)f_4619},
{"f_4622:setup_api_scm",(void*)f_4622},
{"f_4625:setup_api_scm",(void*)f_4625},
{"f_4644:setup_api_scm",(void*)f_4644},
{"f_4628:setup_api_scm",(void*)f_4628},
{"f_4631:setup_api_scm",(void*)f_4631},
{"f_4634:setup_api_scm",(void*)f_4634},
{"f_4637:setup_api_scm",(void*)f_4637},
{"f_4640:setup_api_scm",(void*)f_4640},
{"f_4555:setup_api_scm",(void*)f_4555},
{"f_4585:setup_api_scm",(void*)f_4585},
{"f_4562:setup_api_scm",(void*)f_4562},
{"f_4569:setup_api_scm",(void*)f_4569},
{"f_4572:setup_api_scm",(void*)f_4572},
{"f_4575:setup_api_scm",(void*)f_4575},
{"f_4578:setup_api_scm",(void*)f_4578},
{"f_4581:setup_api_scm",(void*)f_4581},
{"f_4431:setup_api_scm",(void*)f_4431},
{"f_4435:setup_api_scm",(void*)f_4435},
{"f_4549:setup_api_scm",(void*)f_4549},
{"f_4438:setup_api_scm",(void*)f_4438},
{"f_4546:setup_api_scm",(void*)f_4546},
{"f_4441:setup_api_scm",(void*)f_4441},
{"f_4543:setup_api_scm",(void*)f_4543},
{"f_4444:setup_api_scm",(void*)f_4444},
{"f_4537:setup_api_scm",(void*)f_4537},
{"f_4447:setup_api_scm",(void*)f_4447},
{"f_4534:setup_api_scm",(void*)f_4534},
{"f_4450:setup_api_scm",(void*)f_4450},
{"f_4453:setup_api_scm",(void*)f_4453},
{"f_4456:setup_api_scm",(void*)f_4456},
{"f_4528:setup_api_scm",(void*)f_4528},
{"f_4459:setup_api_scm",(void*)f_4459},
{"f_4519:setup_api_scm",(void*)f_4519},
{"f_4505:setup_api_scm",(void*)f_4505},
{"f_4508:setup_api_scm",(void*)f_4508},
{"f_4462:setup_api_scm",(void*)f_4462},
{"f_4465:setup_api_scm",(void*)f_4465},
{"f_4475:setup_api_scm",(void*)f_4475},
{"f_4478:setup_api_scm",(void*)f_4478},
{"f_4481:setup_api_scm",(void*)f_4481},
{"f_4491:setup_api_scm",(void*)f_4491},
{"f_4484:setup_api_scm",(void*)f_4484},
{"f_4487:setup_api_scm",(void*)f_4487},
{"f_4468:setup_api_scm",(void*)f_4468},
{"f_4378:setup_api_scm",(void*)f_4378},
{"f_4382:setup_api_scm",(void*)f_4382},
{"f_4391:setup_api_scm",(void*)f_4391},
{"f_4403:setup_api_scm",(void*)f_4403},
{"f_4429:setup_api_scm",(void*)f_4429},
{"f_4397:setup_api_scm",(void*)f_4397},
{"f_4385:setup_api_scm",(void*)f_4385},
{"f_4320:setup_api_scm",(void*)f_4320},
{"f_4324:setup_api_scm",(void*)f_4324},
{"f_4337:setup_api_scm",(void*)f_4337},
{"f_4341:setup_api_scm",(void*)f_4341},
{"f_4344:setup_api_scm",(void*)f_4344},
{"f_4347:setup_api_scm",(void*)f_4347},
{"f_4350:setup_api_scm",(void*)f_4350},
{"f_4327:setup_api_scm",(void*)f_4327},
{"f_4330:setup_api_scm",(void*)f_4330},
{"f_4190:setup_api_scm",(void*)f_4190},
{"f_4194:setup_api_scm",(void*)f_4194},
{"f_4200:setup_api_scm",(void*)f_4200},
{"f_4203:setup_api_scm",(void*)f_4203},
{"f_4206:setup_api_scm",(void*)f_4206},
{"f_4289:setup_api_scm",(void*)f_4289},
{"f_4209:setup_api_scm",(void*)f_4209},
{"f_4243:setup_api_scm",(void*)f_4243},
{"f_4250:setup_api_scm",(void*)f_4250},
{"f_4253:setup_api_scm",(void*)f_4253},
{"f_4279:setup_api_scm",(void*)f_4279},
{"f_4256:setup_api_scm",(void*)f_4256},
{"f_4212:setup_api_scm",(void*)f_4212},
{"f_4241:setup_api_scm",(void*)f_4241},
{"f_4215:setup_api_scm",(void*)f_4215},
{"f_4039:setup_api_scm",(void*)f_4039},
{"f_4043:setup_api_scm",(void*)f_4043},
{"f_4059:setup_api_scm",(void*)f_4059},
{"f_4062:setup_api_scm",(void*)f_4062},
{"f_4065:setup_api_scm",(void*)f_4065},
{"f_4159:setup_api_scm",(void*)f_4159},
{"f_4068:setup_api_scm",(void*)f_4068},
{"f_4126:setup_api_scm",(void*)f_4126},
{"f_4140:setup_api_scm",(void*)f_4140},
{"f_4144:setup_api_scm",(void*)f_4144},
{"f_4071:setup_api_scm",(void*)f_4071},
{"f_4079:setup_api_scm",(void*)f_4079},
{"f_4086:setup_api_scm",(void*)f_4086},
{"f_4089:setup_api_scm",(void*)f_4089},
{"f_4115:setup_api_scm",(void*)f_4115},
{"f_4092:setup_api_scm",(void*)f_4092},
{"f_4074:setup_api_scm",(void*)f_4074},
{"f_4045:setup_api_scm",(void*)f_4045},
{"f_3490:setup_api_scm",(void*)f_3490},
{"f_3497:setup_api_scm",(void*)f_3497},
{"f_3500:setup_api_scm",(void*)f_3500},
{"f_3725:setup_api_scm",(void*)f_3725},
{"f_3729:setup_api_scm",(void*)f_3729},
{"f_3735:setup_api_scm",(void*)f_3735},
{"f_3738:setup_api_scm",(void*)f_3738},
{"f_3741:setup_api_scm",(void*)f_3741},
{"f_3744:setup_api_scm",(void*)f_3744},
{"f_3873:setup_api_scm",(void*)f_3873},
{"f_3880:setup_api_scm",(void*)f_3880},
{"f_4002:setup_api_scm",(void*)f_4002},
{"f_3973:setup_api_scm",(void*)f_3973},
{"f_3992:setup_api_scm",(void*)f_3992},
{"f_3883:setup_api_scm",(void*)f_3883},
{"f_3886:setup_api_scm",(void*)f_3886},
{"f_3970:setup_api_scm",(void*)f_3970},
{"f_3889:setup_api_scm",(void*)f_3889},
{"f_3947:setup_api_scm",(void*)f_3947},
{"f_3939:setup_api_scm",(void*)f_3939},
{"f_3904:setup_api_scm",(void*)f_3904},
{"f_3923:setup_api_scm",(void*)f_3923},
{"f_3895:setup_api_scm",(void*)f_3895},
{"f_3747:setup_api_scm",(void*)f_3747},
{"f_3750:setup_api_scm",(void*)f_3750},
{"f_3871:setup_api_scm",(void*)f_3871},
{"f_3753:setup_api_scm",(void*)f_3753},
{"f_3831:setup_api_scm",(void*)f_3831},
{"f_3843:setup_api_scm",(void*)f_3843},
{"f_3867:setup_api_scm",(void*)f_3867},
{"f_3856:setup_api_scm",(void*)f_3856},
{"f_3834:setup_api_scm",(void*)f_3834},
{"f_3759:setup_api_scm",(void*)f_3759},
{"f_3771:setup_api_scm",(void*)f_3771},
{"f_3783:setup_api_scm",(void*)f_3783},
{"f_3796:setup_api_scm",(void*)f_3796},
{"f_3799:setup_api_scm",(void*)f_3799},
{"f_3802:setup_api_scm",(void*)f_3802},
{"f_3774:setup_api_scm",(void*)f_3774},
{"f_3765:setup_api_scm",(void*)f_3765},
{"f_3539:setup_api_scm",(void*)f_3539},
{"f_3722:setup_api_scm",(void*)f_3722},
{"f_3543:setup_api_scm",(void*)f_3543},
{"f_3719:setup_api_scm",(void*)f_3719},
{"f_3546:setup_api_scm",(void*)f_3546},
{"f_3549:setup_api_scm",(void*)f_3549},
{"f_3552:setup_api_scm",(void*)f_3552},
{"f_3555:setup_api_scm",(void*)f_3555},
{"f_3558:setup_api_scm",(void*)f_3558},
{"f_3561:setup_api_scm",(void*)f_3561},
{"f_3564:setup_api_scm",(void*)f_3564},
{"f_3614:setup_api_scm",(void*)f_3614},
{"f_3618:setup_api_scm",(void*)f_3618},
{"f_3606:setup_api_scm",(void*)f_3606},
{"f_3591:setup_api_scm",(void*)f_3591},
{"f_3587:setup_api_scm",(void*)f_3587},
{"f_3583:setup_api_scm",(void*)f_3583},
{"f_3436:setup_api_scm",(void*)f_3436},
{"f_3442:setup_api_scm",(void*)f_3442},
{"f_3455:setup_api_scm",(void*)f_3455},
{"f_3458:setup_api_scm",(void*)f_3458},
{"f_3411:setup_api_scm",(void*)f_3411},
{"f_3431:setup_api_scm",(void*)f_3431},
{"f_3389:setup_api_scm",(void*)f_3389},
{"f_3409:setup_api_scm",(void*)f_3409},
{"f_3334:setup_api_scm",(void*)f_3334},
{"f_3341:setup_api_scm",(void*)f_3341},
{"f_3344:setup_api_scm",(void*)f_3344},
{"f_3363:setup_api_scm",(void*)f_3363},
{"f_3371:setup_api_scm",(void*)f_3371},
{"f_3187:setup_api_scm",(void*)f_3187},
{"f_3286:setup_api_scm",(void*)f_3286},
{"f_3277:setup_api_scm",(void*)f_3277},
{"f_3285:setup_api_scm",(void*)f_3285},
{"f_3189:setup_api_scm",(void*)f_3189},
{"f_3196:setup_api_scm",(void*)f_3196},
{"f_3260:setup_api_scm",(void*)f_3260},
{"f_3199:setup_api_scm",(void*)f_3199},
{"f_3202:setup_api_scm",(void*)f_3202},
{"f_3208:setup_api_scm",(void*)f_3208},
{"f_3211:setup_api_scm",(void*)f_3211},
{"f_3230:setup_api_scm",(void*)f_3230},
{"f_3238:setup_api_scm",(void*)f_3238},
{"f_3214:setup_api_scm",(void*)f_3214},
{"f_3058:setup_api_scm",(void*)f_3058},
{"f_3185:setup_api_scm",(void*)f_3185},
{"f_3181:setup_api_scm",(void*)f_3181},
{"f_3155:setup_api_scm",(void*)f_3155},
{"f_3158:setup_api_scm",(void*)f_3158},
{"f_3161:setup_api_scm",(void*)f_3161},
{"f_3164:setup_api_scm",(void*)f_3164},
{"f_3167:setup_api_scm",(void*)f_3167},
{"f_3170:setup_api_scm",(void*)f_3170},
{"f_3065:setup_api_scm",(void*)f_3065},
{"f_3068:setup_api_scm",(void*)f_3068},
{"f_3152:setup_api_scm",(void*)f_3152},
{"f_2999:setup_api_scm",(void*)f_2999},
{"f_3071:setup_api_scm",(void*)f_3071},
{"f_3144:setup_api_scm",(void*)f_3144},
{"f_3103:setup_api_scm",(void*)f_3103},
{"f_3135:setup_api_scm",(void*)f_3135},
{"f_3106:setup_api_scm",(void*)f_3106},
{"f_3125:setup_api_scm",(void*)f_3125},
{"f_3133:setup_api_scm",(void*)f_3133},
{"f_3074:setup_api_scm",(void*)f_3074},
{"f_3100:setup_api_scm",(void*)f_3100},
{"f_5440:setup_api_scm",(void*)f_5440},
{"f_5444:setup_api_scm",(void*)f_5444},
{"f_5467:setup_api_scm",(void*)f_5467},
{"f_5432:setup_api_scm",(void*)f_5432},
{"f_5436:setup_api_scm",(void*)f_5436},
{"f_3031:setup_api_scm",(void*)f_3031},
{"f_3038:setup_api_scm",(void*)f_3038},
{"f_3041:setup_api_scm",(void*)f_3041},
{"f_3044:setup_api_scm",(void*)f_3044},
{"f_3047:setup_api_scm",(void*)f_3047},
{"f_3050:setup_api_scm",(void*)f_3050},
{"f_2952:setup_api_scm",(void*)f_2952},
{"f_2984:setup_api_scm",(void*)f_2984},
{"f_2521:setup_api_scm",(void*)f_2521},
{"f_2950:setup_api_scm",(void*)f_2950},
{"f_2525:setup_api_scm",(void*)f_2525},
{"f_2353:setup_api_scm",(void*)f_2353},
{"f_2362:setup_api_scm",(void*)f_2362},
{"f_2367:setup_api_scm",(void*)f_2367},
{"f_2374:setup_api_scm",(void*)f_2374},
{"f_2377:setup_api_scm",(void*)f_2377},
{"f_2386:setup_api_scm",(void*)f_2386},
{"f_2389:setup_api_scm",(void*)f_2389},
{"f_2428:setup_api_scm",(void*)f_2428},
{"f_2436:setup_api_scm",(void*)f_2436},
{"f_2398:setup_api_scm",(void*)f_2398},
{"f_2528:setup_api_scm",(void*)f_2528},
{"f_2513:setup_api_scm",(void*)f_2513},
{"f_2531:setup_api_scm",(void*)f_2531},
{"f_2536:setup_api_scm",(void*)f_2536},
{"f_2540:setup_api_scm",(void*)f_2540},
{"f_2923:setup_api_scm",(void*)f_2923},
{"f_2936:setup_api_scm",(void*)f_2936},
{"f_2918:setup_api_scm",(void*)f_2918},
{"f_2858:setup_api_scm",(void*)f_2858},
{"f_2864:setup_api_scm",(void*)f_2864},
{"f_2871:setup_api_scm",(void*)f_2871},
{"f_2873:setup_api_scm",(void*)f_2873},
{"f_2886:setup_api_scm",(void*)f_2886},
{"f_2889:setup_api_scm",(void*)f_2889},
{"f_2892:setup_api_scm",(void*)f_2892},
{"f_2542:setup_api_scm",(void*)f_2542},
{"f_2248:setup_api_scm",(void*)f_2248},
{"f_2261:setup_api_scm",(void*)f_2261},
{"f_2267:setup_api_scm",(void*)f_2267},
{"f_2239:setup_api_scm",(void*)f_2239},
{"f_2546:setup_api_scm",(void*)f_2546},
{"f_2549:setup_api_scm",(void*)f_2549},
{"f_2852:setup_api_scm",(void*)f_2852},
{"f_2552:setup_api_scm",(void*)f_2552},
{"f_2834:setup_api_scm",(void*)f_2834},
{"f_2837:setup_api_scm",(void*)f_2837},
{"f_2840:setup_api_scm",(void*)f_2840},
{"f_2843:setup_api_scm",(void*)f_2843},
{"f_2846:setup_api_scm",(void*)f_2846},
{"f_2555:setup_api_scm",(void*)f_2555},
{"f_2822:setup_api_scm",(void*)f_2822},
{"f_2825:setup_api_scm",(void*)f_2825},
{"f_2828:setup_api_scm",(void*)f_2828},
{"f_2831:setup_api_scm",(void*)f_2831},
{"f_2783:setup_api_scm",(void*)f_2783},
{"f_2807:setup_api_scm",(void*)f_2807},
{"f_2808:setup_api_scm",(void*)f_2808},
{"f_2793:setup_api_scm",(void*)f_2793},
{"f_2564:setup_api_scm",(void*)f_2564},
{"f_2739:setup_api_scm",(void*)f_2739},
{"f_2743:setup_api_scm",(void*)f_2743},
{"f_2759:setup_api_scm",(void*)f_2759},
{"f_2766:setup_api_scm",(void*)f_2766},
{"f_2769:setup_api_scm",(void*)f_2769},
{"f_2772:setup_api_scm",(void*)f_2772},
{"f_2775:setup_api_scm",(void*)f_2775},
{"f_2778:setup_api_scm",(void*)f_2778},
{"f_2781:setup_api_scm",(void*)f_2781},
{"f_2746:setup_api_scm",(void*)f_2746},
{"f_2756:setup_api_scm",(void*)f_2756},
{"f_2570:setup_api_scm",(void*)f_2570},
{"f_2672:setup_api_scm",(void*)f_2672},
{"f_2675:setup_api_scm",(void*)f_2675},
{"f_2678:setup_api_scm",(void*)f_2678},
{"f_2681:setup_api_scm",(void*)f_2681},
{"f_2684:setup_api_scm",(void*)f_2684},
{"f_2716:setup_api_scm",(void*)f_2716},
{"f_2719:setup_api_scm",(void*)f_2719},
{"f_2722:setup_api_scm",(void*)f_2722},
{"f_2725:setup_api_scm",(void*)f_2725},
{"f_2728:setup_api_scm",(void*)f_2728},
{"f_2731:setup_api_scm",(void*)f_2731},
{"f_2734:setup_api_scm",(void*)f_2734},
{"f_2694:setup_api_scm",(void*)f_2694},
{"f_2687:setup_api_scm",(void*)f_2687},
{"f_2589:setup_api_scm",(void*)f_2589},
{"f_2597:setup_api_scm",(void*)f_2597},
{"f_2644:setup_api_scm",(void*)f_2644},
{"f_2659:setup_api_scm",(void*)f_2659},
{"f_2665:setup_api_scm",(void*)f_2665},
{"f_2650:setup_api_scm",(void*)f_2650},
{"f_2603:setup_api_scm",(void*)f_2603},
{"f_2609:setup_api_scm",(void*)f_2609},
{"f_2613:setup_api_scm",(void*)f_2613},
{"f_2616:setup_api_scm",(void*)f_2616},
{"f_2619:setup_api_scm",(void*)f_2619},
{"f_2635:setup_api_scm",(void*)f_2635},
{"f_2632:setup_api_scm",(void*)f_2632},
{"f_2622:setup_api_scm",(void*)f_2622},
{"f_2625:setup_api_scm",(void*)f_2625},
{"f_2595:setup_api_scm",(void*)f_2595},
{"f_2315:setup_api_scm",(void*)f_2315},
{"f_2323:setup_api_scm",(void*)f_2323},
{"f_2326:setup_api_scm",(void*)f_2326},
{"f_2329:setup_api_scm",(void*)f_2329},
{"f_2332:setup_api_scm",(void*)f_2332},
{"f_2335:setup_api_scm",(void*)f_2335},
{"f_2338:setup_api_scm",(void*)f_2338},
{"f_2341:setup_api_scm",(void*)f_2341},
{"f_2293:setup_api_scm",(void*)f_2293},
{"f_2301:setup_api_scm",(void*)f_2301},
{"f_2304:setup_api_scm",(void*)f_2304},
{"f_2307:setup_api_scm",(void*)f_2307},
{"f_2310:setup_api_scm",(void*)f_2310},
{"f_2313:setup_api_scm",(void*)f_2313},
{"f_2162:setup_api_scm",(void*)f_2162},
{"f_2195:setup_api_scm",(void*)f_2195},
{"f_2197:setup_api_scm",(void*)f_2197},
{"f_2223:setup_api_scm",(void*)f_2223},
{"f_2226:setup_api_scm",(void*)f_2226},
{"f_2229:setup_api_scm",(void*)f_2229},
{"f_2232:setup_api_scm",(void*)f_2232},
{"f_2210:setup_api_scm",(void*)f_2210},
{"f_2213:setup_api_scm",(void*)f_2213},
{"f_2165:setup_api_scm",(void*)f_2165},
{"f_2169:setup_api_scm",(void*)f_2169},
{"f_2130:setup_api_scm",(void*)f_2130},
{"f_2109:setup_api_scm",(void*)f_2109},
{"f_2074:setup_api_scm",(void*)f_2074},
{"f_2098:setup_api_scm",(void*)f_2098},
{"f_2105:setup_api_scm",(void*)f_2105},
{"f_2095:setup_api_scm",(void*)f_2095},
{"f_2092:setup_api_scm",(void*)f_2092},
{"f_2089:setup_api_scm",(void*)f_2089},
{"f_2070:setup_api_scm",(void*)f_2070},
{"f_2180:setup_api_scm",(void*)f_2180},
{"f_2136:setup_api_scm",(void*)f_2136},
{"f_2160:setup_api_scm",(void*)f_2160},
{"f_2143:setup_api_scm",(void*)f_2143},
{"f_1937:setup_api_scm",(void*)f_1937},
{"f_2038:setup_api_scm",(void*)f_2038},
{"f_2041:setup_api_scm",(void*)f_2041},
{"f_2044:setup_api_scm",(void*)f_2044},
{"f_2047:setup_api_scm",(void*)f_2047},
{"f_1941:setup_api_scm",(void*)f_1941},
{"f_1995:setup_api_scm",(void*)f_1995},
{"f_1998:setup_api_scm",(void*)f_1998},
{"f_2005:setup_api_scm",(void*)f_2005},
{"f_2008:setup_api_scm",(void*)f_2008},
{"f_2011:setup_api_scm",(void*)f_2011},
{"f_2031:setup_api_scm",(void*)f_2031},
{"f_2014:setup_api_scm",(void*)f_2014},
{"f_2017:setup_api_scm",(void*)f_2017},
{"f_2027:setup_api_scm",(void*)f_2027},
{"f_2020:setup_api_scm",(void*)f_2020},
{"f_2023:setup_api_scm",(void*)f_2023},
{"f_1956:setup_api_scm",(void*)f_1956},
{"f_1966:setup_api_scm",(void*)f_1966},
{"f_1972:setup_api_scm",(void*)f_1972},
{"f_1976:setup_api_scm",(void*)f_1976},
{"f_1992:setup_api_scm",(void*)f_1992},
{"f_1985:setup_api_scm",(void*)f_1985},
{"f_1839:setup_api_scm",(void*)f_1839},
{"f_1843:setup_api_scm",(void*)f_1843},
{"f_1931:setup_api_scm",(void*)f_1931},
{"f_1846:setup_api_scm",(void*)f_1846},
{"f_1851:setup_api_scm",(void*)f_1851},
{"f_1855:setup_api_scm",(void*)f_1855},
{"f_1858:setup_api_scm",(void*)f_1858},
{"f_1861:setup_api_scm",(void*)f_1861},
{"f_1923:setup_api_scm",(void*)f_1923},
{"f_1926:setup_api_scm",(void*)f_1926},
{"f_1864:setup_api_scm",(void*)f_1864},
{"f_1867:setup_api_scm",(void*)f_1867},
{"f_1870:setup_api_scm",(void*)f_1870},
{"f_1873:setup_api_scm",(void*)f_1873},
{"f_1897:setup_api_scm",(void*)f_1897},
{"f_1900:setup_api_scm",(void*)f_1900},
{"f_1903:setup_api_scm",(void*)f_1903},
{"f_1814:setup_api_scm",(void*)f_1814},
{"f_1788:setup_api_scm",(void*)f_1788},
{"f_1716:setup_api_scm",(void*)f_1716},
{"f_1706:setup_api_scm",(void*)f_1706},
{"f_1714:setup_api_scm",(void*)f_1714},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
