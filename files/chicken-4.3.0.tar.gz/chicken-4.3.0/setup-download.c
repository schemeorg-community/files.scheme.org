/* Generated from setup-download.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: setup-download.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature chicken-compile-shared -dynamic -emit-import-library setup-download -ignore-repository -output-file setup-download.c
   used units: library eval data_structures ports extras srfi_69 extras regex posix utils srfi_1 data_structures tcp srfi_13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[189];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,100,32,102,115,116,114,49,53,49,32,97,114,103,115,49,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,40),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,101,116,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,101,120,105,115,116,105,110,103,45,118,101,114,115,105,111,110,32,101,103,103,49,54,52,32,118,101,114,115,105,111,110,49,54,53,32,118,115,49,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,63),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,119,104,101,110,45,110,111,45,115,117,99,104,45,118,101,114,115,105,111,110,45,119,97,114,110,105,110,103,32,101,103,103,49,55,49,32,118,101,114,115,105,111,110,49,55,50,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,98,111,100,121,49,57,57,32,118,101,114,115,105,111,110,50,48,56,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,50,48,50,32,37,118,101,114,115,105,111,110,49,57,55,50,50,51,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,50,48,49,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,59),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,108,111,99,97,108,32,101,103,103,49,57,49,32,100,105,114,49,57,50,32,46,32,116,109,112,49,57,48,49,57,51,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,7),40,97,49,48,52,51,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,97,49,49,48,49,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,13),40,97,49,48,57,53,32,101,120,50,53,50,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,7),40,97,49,49,49,54,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,7),40,97,49,49,50,56,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,20),40,97,49,49,50,50,32,46,32,97,114,103,115,50,52,57,50,53,52,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,49,49,49,48,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,15),40,97,49,48,56,57,32,107,50,52,56,50,53,49,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,97,49,48,54,52,32,114,101,116,117,114,110,50,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,37),40,97,49,48,52,57,32,108,111,99,50,51,54,50,51,55,50,52,48,32,118,101,114,115,105,111,110,50,51,56,50,51,57,50,52,49,41,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,97,49,48,51,55,32,101,103,103,50,51,51,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,97,116,104,101,114,45,101,103,103,45,105,110,102,111,114,109,97,116,105,111,110,32,100,105,114,50,51,49,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,66),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,109,97,107,101,45,115,118,110,45,108,115,45,99,109,100,32,117,97,114,103,50,54,50,32,112,97,114,103,50,54,51,32,112,110,97,109,50,54,52,32,116,109,112,50,54,49,50,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,49,50,56,51,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,37),40,97,49,51,49,49,32,102,105,108,101,100,105,114,51,53,54,51,53,55,51,54,49,32,118,101,114,51,53,56,51,53,57,51,54,50,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,97,49,51,53,52,32,102,51,52,57,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,59),40,98,111,100,121,51,50,55,32,118,101,114,115,105,111,110,51,51,56,32,100,101,115,116,105,110,97,116,105,111,110,51,51,57,32,117,115,101,114,110,97,109,101,51,52,48,32,112,97,115,115,119,111,114,100,51,52,49,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,67),40,100,101,102,45,112,97,115,115,119,111,114,100,51,51,50,32,37,118,101,114,115,105,111,110,51,50,51,51,55,54,32,37,100,101,115,116,105,110,97,116,105,111,110,51,50,52,51,55,55,32,37,117,115,101,114,110,97,109,101,51,50,53,51,55,56,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,51),40,100,101,102,45,117,115,101,114,110,97,109,101,51,51,49,32,37,118,101,114,115,105,111,110,51,50,51,51,56,48,32,37,100,101,115,116,105,110,97,116,105,111,110,51,50,52,51,56,49,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,51,51,48,32,37,118,101,114,115,105,111,110,51,50,51,51,56,51,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,51,50,57,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,115,118,110,32,101,103,103,51,49,55,32,114,101,112,111,51,49,56,32,46,32,116,109,112,51,49,54,51,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,7),40,97,49,53,50,57,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,55,57,52,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,7),40,97,49,57,52,53,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,102,105,108,101,115,32,102,105,108,101,115,53,56,55,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,99,104,117,110,107,115,32,100,97,116,97,54,51,49,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,49,55,51,56,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,49,55,52,49,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,49,55,52,52,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,7),40,97,49,55,52,55,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,32),40,97,49,56,48,56,32,105,110,53,52,53,53,52,54,53,53,57,32,111,117,116,53,52,55,53,52,56,53,54,48,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,49),40,97,49,53,51,53,32,104,111,115,116,52,52,54,52,52,55,52,53,50,32,112,111,114,116,52,52,56,52,52,57,52,53,51,32,108,111,99,110,52,53,48,52,53,49,52,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,72),40,98,111,100,121,52,50,49,32,118,101,114,115,105,111,110,52,51,51,32,100,101,115,116,105,110,97,116,105,111,110,52,51,52,32,116,101,115,116,115,52,51,53,32,112,114,111,120,121,45,104,111,115,116,52,51,54,32,112,114,111,120,121,45,112,111,114,116,52,51,55,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,84),40,100,101,102,45,112,114,111,120,121,45,112,111,114,116,52,50,55,32,37,118,101,114,115,105,111,110,52,49,54,52,55,48,32,37,100,101,115,116,105,110,97,116,105,111,110,52,49,55,52,55,49,32,37,116,101,115,116,115,52,49,56,52,55,50,32,37,112,114,111,120,121,45,104,111,115,116,52,49,57,52,55,51,41,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,66),40,100,101,102,45,112,114,111,120,121,45,104,111,115,116,52,50,54,32,37,118,101,114,115,105,111,110,52,49,54,52,55,53,32,37,100,101,115,116,105,110,97,116,105,111,110,52,49,55,52,55,54,32,37,116,101,115,116,115,52,49,56,52,55,55,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,116,101,115,116,115,52,50,53,32,37,118,101,114,115,105,111,110,52,49,54,52,55,57,32,37,100,101,115,116,105,110,97,116,105,111,110,52,49,55,52,56,48,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,52,50,52,32,37,118,101,114,115,105,111,110,52,49,54,52,56,50,41,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,52,50,51,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,104,116,116,112,32,101,103,103,52,49,48,32,117,114,108,52,49,49,32,46,32,116,109,112,52,48,57,52,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,50,49,51,49,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,7),40,97,50,49,51,54,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,50,49,55,53,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,80),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,114,101,116,114,105,101,118,101,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,54,52,51,32,116,114,97,110,115,112,111,114,116,54,52,52,32,108,111,99,97,116,105,111,110,54,52,53,32,46,32,116,109,112,54,52,50,54,52,54,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,7),40,97,50,49,57,53,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,17),40,97,57,48,50,32,103,49,56,49,49,56,50,49,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,12),40,97,49,49,56,53,32,115,51,48,49,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,50,56,55,32,117,115,101,114,110,97,109,101,50,57,54,32,112,97,115,115,119,111,114,100,50,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,112,97,115,115,119,111,114,100,50,57,48,32,37,117,115,101,114,110,97,109,101,50,56,53,51,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,117,115,101,114,110,97,109,101,50,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,7),40,97,50,50,48,48,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,7),40,97,50,50,50,52,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,69),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,105,115,116,45,101,120,116,101,110,115,105,111,110,115,32,116,114,97,110,115,112,111,114,116,54,56,51,32,108,111,99,97,116,105,111,110,54,56,52,32,46,32,116,109,112,54,56,50,54,56,53,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_759)
static void C_ccall f_759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_762)
static void C_ccall f_762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_765)
static void C_ccall f_765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_768)
static void C_ccall f_768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_771)
static void C_ccall f_771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_774)
static void C_ccall f_774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_780)
static void C_ccall f_780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_783)
static void C_ccall f_783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_786)
static void C_ccall f_786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_789)
static void C_ccall f_789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_792)
static void C_ccall f_792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_795)
static void C_ccall f_795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_798)
static void C_ccall f_798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_801)
static void C_ccall f_801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_804)
static void C_ccall f_804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_807)
static void C_ccall f_807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_813)
static void C_ccall f_813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_818)
static void C_ccall f_818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_fcall f_1210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1205)
static void C_fcall f_1205(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1164)
static void C_fcall f_1164(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1168)
static void C_ccall f_1168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1198)
static void C_ccall f_1198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1194)
static void C_ccall f_1194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_911)
static void C_ccall f_911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_903)
static void C_ccall f_903(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1597)
static void C_fcall f_1597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_fcall f_1592(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1587)
static void C_fcall f_1587(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1582)
static void C_fcall f_1582(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1577)
static void C_fcall f_1577(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1521)
static void C_fcall f_1521(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1724)
static void C_ccall f_1724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1727)
static void C_ccall f_1727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_fcall f_2008(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_fcall f_1982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_fcall f_1995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_fcall f_2070(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_fcall f_1840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_fcall f_1848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_fcall f_1858(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1391)
static void C_fcall f_1391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_fcall f_1386(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1381)
static void C_fcall f_1381(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1376)
static void C_fcall f_1376(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1260)
static void C_fcall f_1260(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1264)
static void C_ccall f_1264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1273)
static void C_ccall f_1273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1346)
static void C_ccall f_1346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_ccall f_1322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_fcall f_1135(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1065)
static void C_ccall f_1065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1129)
static void C_ccall f_1129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1096)
static void C_ccall f_1096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1102)
static void C_ccall f_1102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1106)
static void C_ccall f_1106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_913)
static void C_ccall f_913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_913)
static void C_ccall f_913r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_981)
static void C_fcall f_981(C_word t0,C_word t1) C_noret;
C_noret_decl(f_976)
static void C_fcall f_976(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_915)
static void C_fcall f_915(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_919)
static void C_ccall f_919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_922)
static void C_ccall f_922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_962)
static void C_ccall f_962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_968)
static void C_ccall f_968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_938)
static void C_ccall f_938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_941)
static void C_ccall f_941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_956)
static void C_ccall f_956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_947)
static void C_ccall f_947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_884)
static void C_fcall f_884(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_857)
static void C_fcall f_857(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_873)
static void C_ccall f_873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_842)
static void C_fcall f_842(C_word t0) C_noret;
C_noret_decl(f_846)
static void C_ccall f_846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_855)
static void C_ccall f_855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_820)
static void C_fcall f_820(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_824)
static void C_ccall f_824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_827)
static void C_ccall f_827(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1210)
static void C_fcall trf_1210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1210(t0,t1);}

C_noret_decl(trf_1205)
static void C_fcall trf_1205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1205(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1205(t0,t1,t2);}

C_noret_decl(trf_1164)
static void C_fcall trf_1164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1164(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1164(t0,t1,t2,t3);}

C_noret_decl(trf_1597)
static void C_fcall trf_1597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1597(t0,t1);}

C_noret_decl(trf_1592)
static void C_fcall trf_1592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1592(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1592(t0,t1,t2);}

C_noret_decl(trf_1587)
static void C_fcall trf_1587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1587(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1587(t0,t1,t2,t3);}

C_noret_decl(trf_1582)
static void C_fcall trf_1582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1582(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1582(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1577)
static void C_fcall trf_1577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1577(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1577(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1521)
static void C_fcall trf_1521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1521(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1521(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2008)
static void C_fcall trf_2008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2008(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2008(t0,t1);}

C_noret_decl(trf_1982)
static void C_fcall trf_1982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1982(t0,t1);}

C_noret_decl(trf_1995)
static void C_fcall trf_1995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1995(t0,t1);}

C_noret_decl(trf_2070)
static void C_fcall trf_2070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2070(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2070(t0,t1,t2);}

C_noret_decl(trf_1840)
static void C_fcall trf_1840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1840(t0,t1);}

C_noret_decl(trf_1848)
static void C_fcall trf_1848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1848(t0,t1,t2);}

C_noret_decl(trf_1858)
static void C_fcall trf_1858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1858(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1858(t0,t1);}

C_noret_decl(trf_1391)
static void C_fcall trf_1391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1391(t0,t1);}

C_noret_decl(trf_1386)
static void C_fcall trf_1386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1386(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1386(t0,t1,t2);}

C_noret_decl(trf_1381)
static void C_fcall trf_1381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1381(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1381(t0,t1,t2,t3);}

C_noret_decl(trf_1376)
static void C_fcall trf_1376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1376(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1376(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1260)
static void C_fcall trf_1260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1260(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1260(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1135)
static void C_fcall trf_1135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1135(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1135(t0,t1,t2,t3,t4);}

C_noret_decl(trf_981)
static void C_fcall trf_981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_981(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_981(t0,t1);}

C_noret_decl(trf_976)
static void C_fcall trf_976(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_976(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_976(t0,t1,t2);}

C_noret_decl(trf_915)
static void C_fcall trf_915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_915(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_915(t0,t1,t2);}

C_noret_decl(trf_884)
static void C_fcall trf_884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_884(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_884(t0,t1,t2);}

C_noret_decl(trf_857)
static void C_fcall trf_857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_857(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_857(t0,t1,t2,t3);}

C_noret_decl(trf_842)
static void C_fcall trf_842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_842(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_842(t0);}

C_noret_decl(trf_820)
static void C_fcall trf_820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_820(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_820(t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(900)){
C_save(t1);
C_rereclaim2(900*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,189);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[5]=C_h_intern(&lf[5],12,"flush-output");
lf[6]=C_h_intern(&lf[6],7,"fprintf");
lf[7]=C_h_intern(&lf[7],18,"current-error-port");
lf[8]=C_h_intern(&lf[8],19,"current-output-port");
lf[9]=C_h_intern(&lf[9],34,"setup-download#temporary-directory");
lf[11]=C_h_intern(&lf[11],36,"setup-api#create-temporary-directory");
lf[13]=C_h_intern(&lf[13],5,"error");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\021version not found");
lf[15]=C_h_intern(&lf[15],4,"sort");
lf[16]=C_h_intern(&lf[16],20,"setup-api#version>=\077");
lf[18]=C_h_intern(&lf[18],7,"warning");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000-extension has no such version - using default");
lf[20]=C_h_intern(&lf[20],31,"setup-download#locate-egg/local");
lf[21]=C_h_intern(&lf[21],13,"make-pathname");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[24]=C_h_intern(&lf[24],10,"directory\077");
lf[25]=C_h_intern(&lf[25],12,"file-exists\077");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[27]=C_h_intern(&lf[27],9,"directory");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\004tags");
lf[29]=C_h_intern(&lf[29],9,"\003syserror");
lf[30]=C_h_intern(&lf[30],37,"setup-download#gather-egg-information");
lf[31]=C_h_intern(&lf[31],7,"version");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000.extension has syntactically invalid .meta file");
lf[33]=C_h_intern(&lf[33],20,"with-input-from-file");
lf[34]=C_h_intern(&lf[34],4,"read");
lf[35]=C_h_intern(&lf[35],22,"with-exception-handler");
lf[36]=C_h_intern(&lf[36],30,"call-with-current-continuation");
lf[37]=C_h_intern(&lf[37],14,"string->symbol");
lf[38]=C_h_intern(&lf[38],7,"call/cc");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[40]=C_h_intern(&lf[40],10,"filter-map");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004 -R ");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[44]=C_h_intern(&lf[44],4,"conc");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\007svn ls ");
lf[46]=C_h_intern(&lf[46],2,"qs");
lf[47]=C_h_intern(&lf[47],15,"\003sysget-keyword");
lf[48]=C_h_intern(&lf[48],11,"\000recursive\077");
lf[49]=C_h_intern(&lf[49],29,"setup-download#locate-egg/svn");
lf[50]=C_h_intern(&lf[50],13,"string-append");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\005tags/");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\006trunk/");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[58]=C_h_intern(&lf[58],6,"system");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\005 1>&2");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\013svn export ");
lf[63]=C_h_intern(&lf[63],13,"string-search");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\016^tags/([^/]+)/");
lf[65]=C_h_intern(&lf[65],20,"with-input-from-pipe");
lf[66]=C_h_intern(&lf[66],10,"read-lines");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\047checking available versions ...~%  ~a~%");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[74]=C_h_intern(&lf[74],30,"setup-download#locate-egg/http");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\020not a valid port");
lf[77]=C_h_intern(&lf[77],12,"string-match");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000#(http://)\077([^/:]+)(:([^:/]+))\077(/.+)");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[80]=C_h_intern(&lf[80],11,"tcp-connect");
lf[81]=C_h_intern(&lf[81],5,"abort");
lf[82]=C_h_intern(&lf[82],24,"make-composite-condition");
lf[83]=C_h_intern(&lf[83],23,"make-property-condition");
lf[84]=C_h_intern(&lf[84],20,"setup-download-error");
lf[85]=C_h_intern(&lf[85],3,"exn");
lf[86]=C_h_intern(&lf[86],7,"message");
lf[87]=C_h_intern(&lf[87],9,"arguments");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\011[Server] ");
lf[89]=C_h_intern(&lf[89],7,"reverse");
lf[90]=C_h_intern(&lf[90],17,"close-output-port");
lf[91]=C_h_intern(&lf[91],16,"close-input-port");
lf[92]=C_h_intern(&lf[92],16,"create-directory");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[94]=C_h_intern(&lf[94],7,"display");
lf[95]=C_h_intern(&lf[95],19,"with-output-to-file");
lf[96]=C_h_intern(&lf[96],20,"\003sysread-string/port");
lf[97]=C_h_intern(&lf[97],9,"read-line");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[99]=C_h_intern(&lf[99],14,"string-suffix\077");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\0001invalid file name - possibly corrupt transmission");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\023reading files ...~%");
lf[103]=C_h_intern(&lf[103],17,"open-input-string");
lf[104]=C_h_intern(&lf[104],26,"string-concatenate-reverse");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\024reading chunks ...~%");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000$[Tt]ransfer-[Ee]ncoding:\134s*chunked.*");
lf[108]=C_h_intern(&lf[108],12,"string-null\077");
lf[109]=C_h_intern(&lf[109],6,"signal");
lf[110]=C_h_intern(&lf[110],10,"http-fetch");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid response from server");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\003200");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\034HTTP/[0-9.]+\134s+([0-9]+)\134s+.*");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\026reading response ...~%");
lf[116]=C_h_intern(&lf[116],5,"\000port");
lf[117]=C_h_intern(&lf[117],7,"\000accept");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\003*/*");
lf[119]=C_h_intern(&lf[119],11,"\000proxy-host");
lf[120]=C_h_intern(&lf[120],11,"\000proxy-port");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\004GET ");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\011 HTTP/1.1");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\014Connection: ");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\014User-Agent: ");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\010Accept: ");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\006Host: ");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\020Content-length: ");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\007http://");
lf[136]=C_h_intern(&lf[136],15,"\000content-length");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\005close");
lf[139]=C_h_intern(&lf[139],11,"\000connection");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\023requesting ~s ...~%");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000&connecting to host ~s, port ~a ~a...~%");
lf[142]=C_h_intern(&lf[142],17,"get-output-string");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[144]=C_h_intern(&lf[144],19,"\003syswrite-char/port");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\005(via ");
lf[146]=C_h_intern(&lf[146],18,"open-output-string");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\012&tests=yes");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\006\077name=");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\011&version=");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[153]=C_h_intern(&lf[153],33,"setup-download#retrieve-extension");
lf[154]=C_h_intern(&lf[154],5,"local");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000)destination for transport `local\047 ignored");
lf[156]=C_h_intern(&lf[156],3,"svn");
lf[157]=C_h_intern(&lf[157],4,"http");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000/cannot retrieve extension unsupported transport");
lf[159]=C_h_intern(&lf[159],16,"\003sysdynamic-wind");
lf[160]=C_h_intern(&lf[160],6,"\000tests");
lf[161]=C_h_intern(&lf[161],9,"\000password");
lf[162]=C_h_intern(&lf[162],9,"\000username");
lf[163]=C_h_intern(&lf[163],12,"\000destination");
lf[164]=C_h_intern(&lf[164],6,"\000quiet");
lf[165]=C_h_intern(&lf[165],8,"\000version");
lf[166]=C_h_intern(&lf[166],30,"setup-download#list-extensions");
lf[167]=C_h_intern(&lf[167],18,"string-concatenate");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[169]=C_h_intern(&lf[169],7,"\003sysmap");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[171]=C_h_intern(&lf[171],12,"string-chomp");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\047listing extension directory ...~%  ~a~%");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000.cannot list extensions - unsupported transport");
lf[181]=C_h_intern(&lf[181],14,"make-parameter");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install ");
lf[183]=C_h_intern(&lf[183],15,"chicken-version");
lf[184]=C_h_intern(&lf[184],17,"tcp-write-timeout");
lf[185]=C_h_intern(&lf[185],16,"tcp-read-timeout");
lf[186]=C_h_intern(&lf[186],19,"tcp-connect-timeout");
lf[187]=C_h_intern(&lf[187],11,"\003sysrequire");
lf[188]=C_h_intern(&lf[188],9,"setup-api");
C_register_lf2(lf,189,create_ptable());
t2=C_mutate(&lf[0] /* (set! c229 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_759,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k757 */
static void C_ccall f_759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_762,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k760 in k757 */
static void C_ccall f_762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_765,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k763 in k760 in k757 */
static void C_ccall f_765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k766 in k763 in k760 in k757 */
static void C_ccall f_768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_771,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_774,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_777,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_780,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_786,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_789,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_792,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_795,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_798,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_801,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_804,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#require");
((C_proc3)C_retrieve_symbol_proc(lf[187]))(3,*((C_word*)lf[187]+1),t2,lf[188]);}

/* k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_807,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 45   tcp-connect-timeout");
((C_proc3)C_retrieve_symbol_proc(lf[186]))(3,*((C_word*)lf[186]+1),t2,C_fix(10000));}

/* k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_810,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 46   tcp-read-timeout");
((C_proc3)C_retrieve_symbol_proc(lf[185]))(3,*((C_word*)lf[185]+1),t2,C_fix(20000));}

/* k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_813,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 47   tcp-write-timeout");
((C_proc3)C_retrieve_symbol_proc(lf[184]))(3,*((C_word*)lf[184]+1),t2,C_fix(20000));}

/* k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_813,2,t0,t1);}
t2=lf[2] /* setup-download#*quiet* */ =C_SCHEME_FALSE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2232,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 50   chicken-version");
((C_proc2)C_retrieve_symbol_proc(lf[183]))(2,*((C_word*)lf[183]+1),t4);}

/* k2230 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 50   conc");
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[182],t1);}

/* k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_818,2,t0,t1);}
t2=C_mutate(&lf[3] /* (set! setup-download#*chicken-install-user-agent* ...) */,t1);
t3=C_mutate(&lf[4] /* (set! setup-download#d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_820,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_840,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 57   make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[181]))(3,*((C_word*)lf[181]+1),t4,C_SCHEME_FALSE);}

/* k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_840,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* (set! setup-download#temporary-directory ...) */,t1);
t3=C_mutate(&lf[10] /* (set! setup-download#get-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_842,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[12] /* (set! setup-download#existing-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_857,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[17] /* (set! setup-download#when-no-such-version-warning ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_884,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[20]+1 /* (set! setup-download#locate-egg/local ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_913,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[30]+1 /* (set! setup-download#gather-egg-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1029,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[41] /* (set! setup-download#make-svn-ls-cmd ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1135,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[49]+1 /* (set! setup-download#locate-egg/svn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1258,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[74]+1 /* (set! setup-download#locate-egg/http ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1519,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[153]+1 /* (set! setup-download#retrieve-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2102,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[166]+1 /* (set! setup-download#list-extensions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2181,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}

/* setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2181r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2181r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2181r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2185,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t5,lf[164],t4);}

/* k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[162],((C_word*)t0)[2]);}

/* k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[161],((C_word*)t0)[2]);}

/* k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2191,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2196,a[2]=t3,a[3]=t5,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2201,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li59),tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2225,a[2]=t5,a[3]=t3,a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#dynamic-wind");
t9=*((C_word*)lf[159]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a2224 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[18],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2201,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=(C_word)C_eqp(t2,lf[154]);
if(C_truep(t3)){
t4=t1;
t5=((C_word*)t0)[4];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_901,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_903,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_911,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 78   directory");
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t8,t5);}
else{
t4=(C_word)C_eqp(t2,lf[156]);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1164,a[2]=t6,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1205,a[2]=t8,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1210,a[2]=t9,a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
C_trace("def-username289305");
t11=t10;
f_1210(t11,t5);}
else{
t11=(C_word)C_i_car(t7);
t12=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t12))){
C_trace("def-password290303");
t13=t9;
f_1205(t13,t5,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
C_trace("body287295");
t15=t8;
f_1164(t15,t5,t11,t13);}
else{
C_trace("##sys#error");
t15=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t5,lf[0],t14);}}}}
else{
C_trace("setup-download.scm: 313  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t1,lf[180],((C_word*)t0)[5]);}}}

/* def-username289 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1210,NULL,2,t0,t1);}
C_trace("def-password290303");
t2=((C_word*)t0)[2];
f_1205(t2,t1,C_SCHEME_FALSE);}

/* def-password290 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1205(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1205,NULL,3,t0,t1,t2);}
C_trace("body287295");
t3=((C_word*)t0)[2];
f_1164(t3,t1,t2,C_SCHEME_FALSE);}

/* body287 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1164(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1164,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1168,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
C_trace("setup-download.scm: 119  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t4,lf[177],t2,lf[178]);}
else{
t5=t4;
f_1168(2,t5,lf[179]);}}

/* k1166 in body287 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-download.scm: 120  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t2,lf[174],((C_word*)t0)[2],lf[175]);}
else{
t3=t2;
f_1171(2,t3,lf[176]);}}

/* k1169 in k1166 in body287 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1174,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 121  make-svn-ls-cmd");
f_1135(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1172 in k1169 in k1166 in body287 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1177,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 122  d");
f_820(t2,lf[173],(C_word)C_a_i_list(&a,1,t1));}

/* k1175 in k1172 in k1169 in k1166 in body287 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1184,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1186,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1198,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 125  with-input-from-pipe");
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t4,((C_word*)t0)[2],C_retrieve(lf[66]));}

/* k1196 in k1175 in k1172 in k1169 in k1166 in body287 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[169]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1185 in k1175 in k1172 in k1169 in k1166 in body287 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1186,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1194,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 124  string-chomp");
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),t3,t2,lf[172]);}

/* k1192 in a1185 in k1175 in k1172 in k1169 in k1166 in body287 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 124  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),((C_word*)t0)[2],t1,lf[170]);}

/* k1182 in k1175 in k1172 in k1169 in k1166 in body287 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 123  string-concatenate");
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),((C_word*)t0)[2],t1);}

/* k909 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[169]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a902 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_903(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_903,3,t0,t1,t2);}
C_trace("string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t1,t2,lf[168]);}

/* k899 in a2200 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 78   string-concatenate");
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),((C_word*)t0)[2],t1);}

/* a2195 in k2189 in k2186 in k2183 in setup-download#list-extensions in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2196,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_2102r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2102r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2102r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2106,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t6,lf[165],t5);}

/* k2104 in setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[164],((C_word*)t0)[2]);}

/* k2107 in k2104 in setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[163],((C_word*)t0)[2]);}

/* k2110 in k2107 in k2104 in setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[162],((C_word*)t0)[2]);}

/* k2113 in k2110 in k2107 in k2104 in setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2118,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[161],((C_word*)t0)[2]);}

/* k2116 in k2113 in k2110 in k2107 in k2104 in setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[160],((C_word*)t0)[2]);}

/* k2119 in k2116 in k2113 in k2110 in k2107 in k2104 in setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[119],((C_word*)t0)[2]);}

/* k2122 in k2119 in k2116 in k2113 in k2110 in k2107 in k2104 in setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[120],((C_word*)t0)[2]);}

/* k2125 in k2122 in k2119 in k2116 in k2113 in k2110 in k2107 in k2104 in setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2127,2,t0,t1);}
t2=((C_word*)t0)[12];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2132,a[2]=t3,a[3]=t5,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2137,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word)li50),tmp=(C_word)a,a+=13,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2176,a[2]=t5,a[3]=t3,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#dynamic-wind");
t9=*((C_word*)lf[159]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a2175 in k2125 in k2122 in k2119 in k2116 in k2113 in k2110 in k2107 in k2104 in setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2136 in k2125 in k2122 in k2119 in k2116 in k2113 in k2110 in k2107 in k2104 in setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2137,2,t0,t1);}
t2=((C_word*)t0)[11];
t3=(C_word)C_eqp(t2,lf[154]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2147,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[7])){
C_trace("setup-download.scm: 296  warning");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t4,lf[155]);}
else{
t5=t4;
f_2147(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_eqp(t2,lf[156]);
if(C_truep(t4)){
C_trace("setup-download.scm: 299  locate-egg/svn");
((C_proc8)C_retrieve_symbol_proc(lf[49]))(8,*((C_word*)lf[49]+1),t1,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(t2,lf[157]);
if(C_truep(t5)){
C_trace("setup-download.scm: 301  locate-egg/http");
((C_proc9)C_retrieve_symbol_proc(lf[74]))(9,*((C_word*)lf[74]+1),t1,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("setup-download.scm: 303  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t1,lf[158],((C_word*)t0)[11]);}}}}

/* k2145 in a2136 in k2125 in k2122 in k2119 in k2116 in k2113 in k2110 in k2107 in k2104 in setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 297  locate-egg/local");
((C_proc6)C_retrieve_symbol_proc(lf[20]))(6,*((C_word*)lf[20]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2131 in k2125 in k2122 in k2119 in k2116 in k2113 in k2110 in k2107 in k2104 in setup-download#retrieve-extension in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2132,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+25)){
C_save_and_reclaim((void*)tr4r,(void*)f_1519r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1519r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1519r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(25);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1521,a[2]=t2,a[3]=t3,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1577,a[2]=t5,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1582,a[2]=t6,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1587,a[2]=t7,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1592,a[2]=t8,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1597,a[2]=t9,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-version423483");
t11=t10;
f_1597(t11,t1);}
else{
t11=(C_word)C_i_car(t4);
t12=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t12))){
C_trace("def-destination424481");
t13=t9;
f_1592(t13,t1,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
C_trace("def-tests425478");
t15=t8;
f_1587(t15,t1,t11,t13);}
else{
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_cdr(t14);
if(C_truep((C_word)C_i_nullp(t16))){
C_trace("def-proxy-host426474");
t17=t7;
f_1582(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_i_car(t16);
t18=(C_word)C_i_cdr(t16);
if(C_truep((C_word)C_i_nullp(t18))){
C_trace("def-proxy-port427469");
t19=t6;
f_1577(t19,t1,t11,t13,t15,t17);}
else{
t19=(C_word)C_i_car(t18);
t20=(C_word)C_i_cdr(t18);
if(C_truep((C_word)C_i_nullp(t20))){
C_trace("body421432");
t21=t5;
f_1521(t21,t1,t11,t13,t15,t17,t19);}
else{
C_trace("##sys#error");
t21=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t1,lf[0],t20);}}}}}}}

/* def-version423 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1597,NULL,2,t0,t1);}
C_trace("def-destination424481");
t2=((C_word*)t0)[2];
f_1592(t2,t1,C_SCHEME_FALSE);}

/* def-destination424 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1592(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1592,NULL,3,t0,t1,t2);}
C_trace("def-tests425478");
t3=((C_word*)t0)[2];
f_1587(t3,t1,t2,C_SCHEME_FALSE);}

/* def-tests425 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1587(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1587,NULL,4,t0,t1,t2,t3);}
C_trace("def-proxy-host426474");
t4=((C_word*)t0)[2];
f_1582(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* def-proxy-host426 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1582(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1582,NULL,5,t0,t1,t2,t3,t4);}
C_trace("def-proxy-port427469");
t5=((C_word*)t0)[2];
f_1577(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* def-proxy-port427 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1577(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1577,NULL,6,t0,t1,t2,t3,t4,t5);}
C_trace("body421432");
t6=((C_word*)t0)[2];
f_1521(t6,t1,t2,t3,t4,t5,C_SCHEME_FALSE);}

/* body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1521(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1521,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1525,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t8=t7;
f_1525(2,t8,t3);}
else{
C_trace("setup-download.scm: 165  get-temporary-directory");
f_842(t7);}}

/* k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[8],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li41),tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1536,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1566,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[7])){
C_trace("setup-download.scm: 170  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t6,lf[151],((C_word*)t0)[7]);}
else{
t7=t6;
f_1566(2,t7,lf[152]);}}

/* k1564 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?lf[148]:lf[149]);
C_trace("setup-download.scm: 167  string-append");
((C_proc7)C_retrieve_proc(*((C_word*)lf[50]+1)))(7,*((C_word*)lf[50]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[150],((C_word*)t0)[2],t1,t2);}

/* k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm: 172  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1559,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 173  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t3,t1);}

/* k1557 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1546(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("setup-download.scm: 173  create-directory");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[7];
t7=((C_word*)t0)[3];
t8=((C_word*)t0)[2];
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1790,a[2]=t2,a[3]=t5,a[4]=t6,a[5]=t4,a[6]=t8,a[7]=t3,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2019,a[2]=t4,a[3]=t3,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2022,a[2]=t7,a[3]=t8,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[146]))(2,*((C_word*)lf[146]+1),t11);}
else{
t11=t10;
f_2019(2,t11,lf[147]);}}

/* k2020 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),t2,lf[145],t1);}

/* k2023 in k2020 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2028,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2026 in k2023 in k2020 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[144]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(58),((C_word*)t0)[3]);}

/* k2029 in k2026 in k2023 in k2020 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2032 in k2029 in k2026 in k2023 in k2020 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),t2,lf[143],((C_word*)t0)[2]);}

/* k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[142]))(3,*((C_word*)lf[142]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2017 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2019,2,t0,t1);}
C_trace("setup-download.scm: 218  d");
f_820(((C_word*)t0)[4],lf[141],(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word)li31),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[4],a[8]=((C_word)li40),tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1809,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm: 223  d");
f_820(t6,lf[140],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[43],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1816,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2015,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve2(lf[3],"setup-download#*chicken-install-user-agent*");
t5=(C_word)C_a_i_list(&a,8,lf[116],((C_word*)t0)[6],lf[117],lf[118],lf[119],((C_word*)t0)[5],lf[120],((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1712,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1748,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t6,lf[116],t5,t7);}

/* a1747 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1748,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(80));}

/* k1710 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1745,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,lf[139],((C_word*)t0)[2],t3);}

/* a1744 in k1710 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1745,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[138]);}

/* k1713 in k1710 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,lf[117],((C_word*)t0)[2],t3);}

/* a1741 in k1713 in k1710 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1742,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[137]);}

/* k1716 in k1713 in k1710 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1739,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,lf[136],((C_word*)t0)[2],t3);}

/* a1738 in k1716 in k1713 in k1710 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* k1719 in k1716 in k1713 in k1710 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[119],((C_word*)t0)[2]);}

/* k1722 in k1719 in k1716 in k1713 in k1710 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1727,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[120],((C_word*)t0)[2]);}

/* k1725 in k1722 in k1719 in k1716 in k1713 in k1710 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1734,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("setup-download.scm: 197  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t2,lf[135],((C_word*)t0)[6],((C_word*)t0)[2]);}
else{
t3=t2;
f_1734(2,t3,((C_word*)t0)[2]);}}

/* k1732 in k1725 in k1722 in k1719 in k1716 in k1713 in k1710 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 194  conc");
((C_proc24)C_retrieve_symbol_proc(lf[44]))(24,*((C_word*)lf[44]+1),((C_word*)t0)[7],lf[121],t1,lf[122],lf[123],lf[124],((C_word*)t0)[6],lf[125],lf[126],C_retrieve2(lf[3],"setup-download#*chicken-install-user-agent*"),lf[127],lf[128],((C_word*)t0)[5],lf[129],lf[130],((C_word*)t0)[4],C_make_character(58),((C_word*)t0)[3],lf[131],lf[132],((C_word*)t0)[2],lf[133],lf[134]);}

/* k2013 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 224  display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 228  flush-output");
((C_proc3)C_retrieve_proc(*((C_word*)lf[5]+1)))(3,*((C_word*)lf[5]+1),t2,((C_word*)t0)[5]);}

/* k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 229  d");
f_820(t2,lf[115],C_SCHEME_END_OF_LIST);}

/* k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1822,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1825,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm: 231  read-line");
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t4,((C_word*)((C_word*)t0)[4])[1]);}

/* k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1828,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=t1;
if(C_truep((C_word)C_i_stringp(t3))){
C_trace("setup-download.scm: 209  string-match");
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t2,lf[114],t3);}
else{
t4=t2;
f_1828(2,t4,C_SCHEME_FALSE);}}

/* k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1831,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm: 233  d");
f_820(t2,lf[113],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=t3;
f_2008(t6,(C_word)C_i_string_equal_p(lf[112],t5));}
else{
t5=t3;
f_2008(t5,C_SCHEME_FALSE);}}

/* k2006 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_2008(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2008,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1834(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1698,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1702,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 181  make-property-condition");
((C_proc7)C_retrieve_symbol_proc(lf[83]))(7,*((C_word*)lf[83]+1),t4,lf[85],lf[86],lf[111],lf[87],t2);}}

/* k1700 in k2006 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1706,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 185  make-property-condition");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[110]);}

/* k1704 in k1700 in k2006 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 180  make-composite-condition");
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1696 in k2006 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 179  signal");
((C_proc3)C_retrieve_symbol_proc(lf[109]))(3,*((C_word*)lf[109]+1),((C_word*)t0)[2],t1);}

/* k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word)li35),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1982(t6,t2);}

/* loop in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1982,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 238  read-line");
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1984 in loop in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 239  string-null?");
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),t2,t1);}

/* k1990 in k1984 in loop in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2004,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
C_trace("setup-download.scm: 215  string-match");
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t3,lf[107],t4);}}

/* k2002 in k1990 in k1984 in loop in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1995(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_1995(t2,C_SCHEME_UNDEFINED);}}

/* k1993 in k1990 in k1984 in loop in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1995,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 241  d");
f_820(t2,lf[106],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k1996 in k1993 in k1990 in k1984 in loop in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 242  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_1982(t2,((C_word*)t0)[2]);}

/* k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1970,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 244  d");
f_820(t3,lf[105],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1840(t3,C_SCHEME_UNDEFINED);}}

/* k1968 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2070,a[2]=t3,a[3]=t5,a[4]=((C_word)li34),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2070(t7,t2,C_SCHEME_END_OF_LIST);}

/* get-chunks in k1968 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_2070(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2070,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2100,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 283  read-line");
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t4,((C_word*)t0)[2]);}

/* k2098 in get-chunks in k1968 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 283  string->number");
C_string_to_number(4,0,((C_word*)t0)[2],t1,C_fix(16));}

/* k2072 in get-chunks in k1968 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2074,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
C_trace("setup-download.scm: 285  string-concatenate-reverse");
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("read-string/port");
t3=C_retrieve(lf[96]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}}

/* k2084 in k2072 in get-chunks in k1968 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 287  read-line");
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t2,((C_word*)t0)[2]);}

/* k2087 in k2084 in k2072 in get-chunks in k1968 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2089,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
C_trace("setup-download.scm: 288  get-chunks");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2070(t3,((C_word*)t0)[2],t2);}

/* k1971 in k1968 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1976,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 246  close-input-port");
((C_proc3)C_retrieve_proc(*((C_word*)lf[91]+1)))(3,*((C_word*)lf[91]+1),t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k1974 in k1971 in k1968 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 247  open-input-string");
((C_proc3)C_retrieve_symbol_proc(lf[103]))(3,*((C_word*)lf[103]+1),t2,((C_word*)t0)[2]);}

/* k1978 in k1974 in k1971 in k1968 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1840(t3,t2);}

/* k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1840(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1840,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 248  d");
f_820(t2,lf[102],C_SCHEME_END_OF_LIST);}

/* k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li33),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1848(t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1848(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1848,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm: 250  read");
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
t4=t2;
f_1858(t4,(C_word)C_eqp(lf[13],t3));}
else{
t3=t2;
f_1858(t3,C_SCHEME_FALSE);}}

/* k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1858(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1858,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_cddr(((C_word*)t0)[8]);
t4=((C_word*)t0)[7];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2050,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2054,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2062,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 277  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t7,lf[88],t2);}
else{
t2=(C_word)C_eofp(((C_word*)t0)[8]);
t3=(C_truep(t2)?t2:(C_word)C_i_not(((C_word*)t0)[8]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 254  close-input-port");
((C_proc3)C_retrieve_proc(*((C_word*)lf[91]+1)))(3,*((C_word*)lf[91]+1),t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[8]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm: 259  string-suffix?");
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t4,lf[100],((C_word*)t0)[8]);}
else{
C_trace("setup-download.scm: 258  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[7],lf[101],((C_word*)t0)[8]);}}}}

/* k1900 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm: 260  read");
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm: 265  d");
f_820(t2,lf[98],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}}

/* k1919 in k1900 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm: 266  read");
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1922 in k1919 in k1900 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm: 267  read-line");
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1925 in k1922 in k1919 in k1900 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
C_trace("read-string/port");
t3=C_retrieve(lf[96]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1928 in k1925 in k1922 in k1919 in k1900 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1944,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 269  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k1942 in k1928 in k1925 in k1922 in k1919 in k1900 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1946,a[2]=((C_word*)t0)[3],a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 269  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],t1,t2);}

/* a1945 in k1942 in k1928 in k1925 in k1922 in k1919 in k1900 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1946,2,t0,t1);}
C_trace("display");
((C_proc3)C_retrieve_proc(*((C_word*)lf[94]+1)))(3,*((C_word*)lf[94]+1),t1,((C_word*)t0)[2]);}

/* k1931 in k1928 in k1925 in k1922 in k1919 in k1900 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
C_trace("setup-download.scm: 270  get-files");
t3=((C_word*)((C_word*)t0)[3])[1];
f_1848(t3,((C_word*)t0)[2],t2);}

/* k1903 in k1900 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm: 261  d");
f_820(t2,lf[93],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k1906 in k1903 in k1900 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1918,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 262  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1916 in k1906 in k1903 in k1900 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 262  create-directory");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t1);}

/* k1909 in k1906 in k1903 in k1900 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 263  get-files");
t2=((C_word*)((C_word*)t0)[4])[1];
f_1848(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1879 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 255  close-output-port");
((C_proc3)C_retrieve_proc(*((C_word*)lf[90]+1)))(3,*((C_word*)lf[90]+1),t2,((C_word*)t0)[2]);}

/* k1882 in k1879 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 256  reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[89]+1)))(3,*((C_word*)lf[89]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2060 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 275  make-property-condition");
((C_proc7)C_retrieve_symbol_proc(lf[83]))(7,*((C_word*)lf[83]+1),((C_word*)t0)[3],lf[85],lf[86],t1,lf[87],((C_word*)t0)[2]);}

/* k2052 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2058,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 279  make-property-condition");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[84]);}

/* k2056 in k2052 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 274  make-composite-condition");
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2048 in k1856 in k1850 in get-files in k1841 in k1838 in k1835 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in a1808 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 273  abort");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),((C_word*)t0)[2],t1);}

/* a1794 in k1788 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:((C_word*)t0)[4]);
t3=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:((C_word*)t0)[2]);
C_trace("setup-download.scm: 222  tcp-connect");
((C_proc4)C_retrieve_symbol_proc(lf[80]))(4,*((C_word*)lf[80]+1),t1,t2,t3);}

/* k1547 in k1544 in k1541 in k1538 in a1535 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[4];
t3=(C_truep(t2)?t2:lf[79]);
C_trace("setup-download.scm: 176  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a1529 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1473,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 154  string-match");
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t3,lf[78],t2);}

/* k1471 in a1529 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1473,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(t1):((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1484,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cadddr(t1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1497,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_list_ref(t1,C_fix(4));
C_trace("setup-download.scm: 158  string->number");
C_string_to_number(3,0,t5,t6);}
else{
t5=t3;
f_1484(2,t5,C_fix(80));}}

/* k1495 in k1471 in a1529 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1484(2,t2,t1);}
else{
t2=(C_word)C_i_list_ref(((C_word*)t0)[2],C_fix(4));
C_trace("setup-download.scm: 159  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[76],t2);}}

/* k1482 in k1471 in a1529 in k1523 in body421 in setup-download#locate-egg/http in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_list_ref(((C_word*)t0)[4],C_fix(5)):lf[75]);
C_trace("setup-download.scm: 155  values");
C_values(5,0,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_1258r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1258r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1258r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1260,a[2]=t3,a[3]=t2,a[4]=((C_word)li24),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1376,a[2]=t5,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1381,a[2]=t6,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1386,a[2]=t7,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1391,a[2]=t8,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-version329384");
t10=t9;
f_1391(t10,t1);}
else{
t10=(C_word)C_i_car(t4);
t11=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("def-destination330382");
t12=t8;
f_1386(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
C_trace("def-username331379");
t14=t7;
f_1381(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
C_trace("def-password332375");
t16=t6;
f_1376(t16,t1,t10,t12,t14);}
else{
t16=(C_word)C_i_car(t15);
t17=(C_word)C_i_cdr(t15);
if(C_truep((C_word)C_i_nullp(t17))){
C_trace("body327337");
t18=t5;
f_1260(t18,t1,t10,t12,t14,t16);}
else{
C_trace("##sys#error");
t18=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t1,lf[0],t17);}}}}}}

/* def-version329 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1391,NULL,2,t0,t1);}
C_trace("def-destination330382");
t2=((C_word*)t0)[2];
f_1386(t2,t1,C_SCHEME_FALSE);}

/* def-destination330 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1386(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1386,NULL,3,t0,t1,t2);}
C_trace("def-username331379");
t3=((C_word*)t0)[2];
f_1381(t3,t1,t2,C_SCHEME_FALSE);}

/* def-username331 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1381(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1381,NULL,4,t0,t1,t2,t3);}
C_trace("def-password332375");
t4=((C_word*)t0)[2];
f_1376(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* def-password332 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1376(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1376,NULL,5,t0,t1,t2,t3,t4);}
C_trace("body327337");
t5=((C_word*)t0)[2];
f_1260(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1260(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1260,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1264,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
C_trace("setup-download.scm: 128  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t6,lf[71],t4,lf[72]);}
else{
t7=t6;
f_1264(2,t7,lf[73]);}}

/* k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-download.scm: 129  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t2,lf[68],((C_word*)t0)[2],lf[69]);}
else{
t3=t2;
f_1267(2,t3,lf[70]);}}

/* k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1369,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 130  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[4],((C_word*)t0)[7]);}

/* k1367 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1369,2,t0,t1);}
C_trace("setup-download.scm: 130  make-svn-ls-cmd");
f_1135(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,2,lf[48],C_SCHEME_TRUE));}

/* k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1273,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm: 131  d");
f_820(t2,lf[67],(C_word)C_a_i_list(&a,1,t1));}

/* k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1276,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm: 132  with-input-from-pipe");
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t2,((C_word*)t0)[2],C_retrieve(lf[66]));}

/* k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1353,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1355,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 135  filter-map");
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),t3,t4,t1);}

/* a1354 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1355,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1359,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 136  string-search");
((C_proc4)C_retrieve_symbol_proc(lf[63]))(4,*((C_word*)lf[63]+1),t3,lf[64],t2);}

/* k1357 in a1354 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_cadr(t1):C_SCHEME_FALSE));}

/* k1351 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 133  existing-version");
f_857(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1277 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1284,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t1,a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li22),tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1311 in k1277 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1312,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1316,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1346,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_1346(2,t7,t5);}
else{
C_trace("setup-download.scm: 146  get-temporary-directory");
f_842(t6);}}

/* k1344 in a1311 in k1277 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 146  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1314 in a1311 in k1277 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1319,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1342,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 147  conc");
((C_proc7)C_retrieve_symbol_proc(lf[44]))(7,*((C_word*)lf[44]+1),t3,((C_word*)t0)[4],C_make_character(47),((C_word*)t0)[3],C_make_character(47),((C_word*)t0)[2]);}

/* k1340 in k1314 in a1311 in k1277 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_truep(C_retrieve2(lf[2],"setup-download#*quiet*"))?lf[60]:lf[61]);
C_trace("setup-download.scm: 115  conc");
((C_proc15)C_retrieve_symbol_proc(lf[44]))(15,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[62],t2,C_make_character(32),t3,C_make_character(32),C_make_character(34),t1,C_make_character(34),C_make_character(32),C_make_character(34),t4,C_make_character(34),t5);}

/* k1317 in k1314 in a1311 in k1277 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1322,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 148  d");
f_820(t2,lf[59],(C_word)C_a_i_list(&a,1,t1));}

/* k1320 in k1317 in k1314 in a1311 in k1277 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1338,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 149  system");
((C_proc3)C_retrieve_symbol_proc(lf[58]))(3,*((C_word*)lf[58]+1),t2,((C_word*)t0)[2]);}

/* k1336 in k1320 in k1317 in k1314 in a1311 in k1277 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
C_trace("setup-download.scm: 150  values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("setup-download.scm: 151  values");
C_values(4,0,((C_word*)t0)[4],C_SCHEME_FALSE,lf[57]);}}

/* a1283 in k1277 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1284,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1295,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 140  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t2,lf[51],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1298,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 142  when-no-such-version-warning");
f_884(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1296 in a1283 in k1277 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_member(lf[52],((C_word*)t0)[3]))){
C_trace("setup-download.scm: 144  values");
C_values(4,0,((C_word*)t0)[2],lf[53],lf[54]);}
else{
C_trace("setup-download.scm: 145  values");
C_values(4,0,((C_word*)t0)[2],lf[55],lf[56]);}}

/* k1293 in a1283 in k1277 in k1274 in k1271 in k1268 in k1265 in k1262 in body327 in setup-download#locate-egg/svn in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 140  values");
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* setup-download#make-svn-ls-cmd in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_1135(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1135,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1139,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t6,lf[48],t5);}

/* k1137 in setup-download#make-svn-ls-cmd in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1139,2,t0,t1);}
t2=(C_truep(t1)?lf[42]:lf[43]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1150,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 112  qs");
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,((C_word*)t0)[2]);}

/* k1148 in k1137 in setup-download#make-svn-ls-cmd in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 112  conc");
((C_proc8)C_retrieve_symbol_proc(lf[44]))(8,*((C_word*)lf[44]+1),((C_word*)t0)[5],lf[45],((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1029,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1033,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 94   directory");
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t3,t2);}

/* k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1038,a[2]=((C_word*)t0)[3],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 95   filter-map");
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[2],t2,t1);}

/* a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1038,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1044,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1050,a[2]=t2,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t3,t4);}

/* a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1050,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1054,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 98   make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t4,t2,((C_word*)t0)[2],lf[39]);}

/* k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1060,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 99   file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t2,t1);}

/* k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1060,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1065,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 100  call/cc");
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1064 in k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1065,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm: 102  string->symbol");
((C_proc3)C_retrieve_proc(*((C_word*)lf[37]+1)))(3,*((C_word*)lf[37]+1),t3,((C_word*)t0)[3]);}

/* k1071 in a1064 in k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1073,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[31],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1085,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1088,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp);
C_trace("call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t4,t5);}

/* a1089 in k1071 in a1064 in k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1090,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1096,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1111,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
C_trace("with-exception-handler");
((C_proc4)C_retrieve_symbol_proc(lf[35]))(4,*((C_word*)lf[35]+1),t1,t3,t4);}

/* a1110 in a1089 in k1071 in a1064 in k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[3],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1123,a[2]=((C_word*)t0)[2],a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a1122 in a1110 in a1089 in k1071 in a1064 in k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1123r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1123r(t0,t1,t2);}}

static void C_ccall f_1123r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1129,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
C_trace("k248251");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1128 in a1122 in a1110 in a1089 in k1071 in a1064 in k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1129,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1116 in a1110 in a1089 in k1071 in a1064 in k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1117,2,t0,t1);}
C_trace("setup-download.scm: 108  with-input-from-file");
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t1,((C_word*)t0)[2],*((C_word*)lf[34]+1));}

/* a1095 in a1089 in k1071 in a1064 in k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1096,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
C_trace("k248251");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1101 in a1095 in a1089 in k1071 in a1064 in k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1106,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 106  warning");
((C_proc4)C_retrieve_symbol_proc(lf[18]))(4,*((C_word*)lf[18]+1),t2,lf[32],((C_word*)t0)[2]);}

/* k1104 in a1101 in a1095 in a1089 in k1071 in a1064 in k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 107  return");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1086 in k1071 in a1064 in k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1083 in k1071 in a1064 in k1058 in k1052 in a1049 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1085,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* a1043 in a1037 in k1031 in setup-download#gather-egg-information in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
C_trace("setup-download.scm: 97   locate-egg/local");
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_913r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_913r(t0,t1,t2,t3,t4);}}

static void C_ccall f_913r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_915,a[2]=t3,a[3]=t2,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_976,a[2]=t5,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_981,a[2]=t6,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-version201224");
t8=t7;
f_981(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("def-destination202222");
t10=t6;
f_976(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("body199207");
t12=t5;
f_915(t12,t1,t8);}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-version201 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_981(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_981,NULL,2,t0,t1);}
C_trace("def-destination202222");
t2=((C_word*)t0)[2];
f_976(t2,t1,C_SCHEME_FALSE);}

/* def-destination202 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_976(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_976,NULL,3,t0,t1,t2);}
C_trace("body199207");
t3=((C_word*)t0)[2];
f_915(t3,t1,t2);}

/* body199 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_915(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_915,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_919,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 81   make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k917 in body199 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 82   make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,t1,lf[28]);}

/* k920 in k917 in body199 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_962,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 83   file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t3,t1);}

/* k960 in k920 in k917 in body199 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_962,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 83   directory?");
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_925(2,t2,C_SCHEME_FALSE);}}

/* k966 in k960 in k920 in k917 in body199 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_968,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 84   directory");
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_925(2,t2,C_SCHEME_FALSE);}}

/* k973 in k966 in k960 in k920 in k917 in body199 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 84   existing-version");
f_857(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k923 in k920 in k917 in body199 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_925,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_935,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 86   make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,((C_word*)t0)[5],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 87   make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,((C_word*)t0)[4],lf[26]);}}

/* k936 in k923 in k920 in k917 in body199 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_941,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 88   when-no-such-version-warning");
f_884(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k939 in k936 in k923 in k920 in k917 in body199 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_956,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 89   file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t3,((C_word*)t0)[3]);}

/* k954 in k939 in k936 in k923 in k920 in k917 in body199 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm: 89   directory?");
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_947(2,t2,C_SCHEME_FALSE);}}

/* k945 in k939 in k936 in k923 in k920 in k917 in body199 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm: 90   values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],lf[22]);}
else{
C_trace("setup-download.scm: 91   values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],lf[23]);}}

/* k933 in k923 in k920 in k917 in body199 in setup-download#locate-egg/local in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 86   values");
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* setup-download#when-no-such-version-warning in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_884(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_884,NULL,3,t1,t2,t3);}
if(C_truep(t3)){
C_trace("setup-download.scm: 75   warning");
((C_proc5)C_retrieve_symbol_proc(lf[18]))(5,*((C_word*)lf[18]+1),t1,lf[19],t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setup-download#existing-version in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_857(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_857,NULL,4,t1,t2,t3,t4);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_member(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
C_trace("setup-download.scm: 69   error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[13]+1)))(5,*((C_word*)lf[13]+1),t1,lf[14],t2,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_873,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 70   sort");
((C_proc4)C_retrieve_symbol_proc(lf[15]))(4,*((C_word*)lf[15]+1),t5,t4,C_retrieve(lf[16]));}}

/* k871 in setup-download#existing-version in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_pairp(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_car(t1):C_SCHEME_FALSE));}

/* setup-download#get-temporary-directory in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_842(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_842,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_846,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 60   temporary-directory");
((C_proc2)C_retrieve_symbol_proc(lf[9]))(2,*((C_word*)lf[9]+1),t2);}

/* k844 in setup-download#get-temporary-directory in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_846,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_852,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 61   setup-api#create-temporary-directory");
((C_proc2)C_retrieve_symbol_proc(lf[11]))(2,*((C_word*)lf[11]+1),t2);}}

/* k850 in k844 in setup-download#get-temporary-directory in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_855,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 62   temporary-directory");
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t2,t1);}

/* k853 in k850 in k844 in setup-download#get-temporary-directory in k838 in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-download#d in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_fcall f_820(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_820,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_824,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[2],"setup-download#*quiet*"))){
C_trace("setup-download.scm: 53   current-error-port");
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t4);}
else{
C_trace("setup-download.scm: 53   current-output-port");
((C_proc2)C_retrieve_proc(*((C_word*)lf[8]+1)))(2,*((C_word*)lf[8]+1),t4);}}

/* k822 in setup-download#d in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_827,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t2,C_retrieve(lf[6]),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k825 in k822 in setup-download#d in k816 in k811 in k808 in k805 in k802 in k799 in k796 in k793 in k790 in k787 in k784 in k781 in k778 in k775 in k772 in k769 in k766 in k763 in k760 in k757 */
static void C_ccall f_827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 55   flush-output");
((C_proc3)C_retrieve_proc(*((C_word*)lf[5]+1)))(3,*((C_word*)lf[5]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[223] = {
{"toplevel:setup_download_scm",(void*)C_toplevel},
{"f_759:setup_download_scm",(void*)f_759},
{"f_762:setup_download_scm",(void*)f_762},
{"f_765:setup_download_scm",(void*)f_765},
{"f_768:setup_download_scm",(void*)f_768},
{"f_771:setup_download_scm",(void*)f_771},
{"f_774:setup_download_scm",(void*)f_774},
{"f_777:setup_download_scm",(void*)f_777},
{"f_780:setup_download_scm",(void*)f_780},
{"f_783:setup_download_scm",(void*)f_783},
{"f_786:setup_download_scm",(void*)f_786},
{"f_789:setup_download_scm",(void*)f_789},
{"f_792:setup_download_scm",(void*)f_792},
{"f_795:setup_download_scm",(void*)f_795},
{"f_798:setup_download_scm",(void*)f_798},
{"f_801:setup_download_scm",(void*)f_801},
{"f_804:setup_download_scm",(void*)f_804},
{"f_807:setup_download_scm",(void*)f_807},
{"f_810:setup_download_scm",(void*)f_810},
{"f_813:setup_download_scm",(void*)f_813},
{"f_2232:setup_download_scm",(void*)f_2232},
{"f_818:setup_download_scm",(void*)f_818},
{"f_840:setup_download_scm",(void*)f_840},
{"f_2181:setup_download_scm",(void*)f_2181},
{"f_2185:setup_download_scm",(void*)f_2185},
{"f_2188:setup_download_scm",(void*)f_2188},
{"f_2191:setup_download_scm",(void*)f_2191},
{"f_2225:setup_download_scm",(void*)f_2225},
{"f_2201:setup_download_scm",(void*)f_2201},
{"f_1210:setup_download_scm",(void*)f_1210},
{"f_1205:setup_download_scm",(void*)f_1205},
{"f_1164:setup_download_scm",(void*)f_1164},
{"f_1168:setup_download_scm",(void*)f_1168},
{"f_1171:setup_download_scm",(void*)f_1171},
{"f_1174:setup_download_scm",(void*)f_1174},
{"f_1177:setup_download_scm",(void*)f_1177},
{"f_1198:setup_download_scm",(void*)f_1198},
{"f_1186:setup_download_scm",(void*)f_1186},
{"f_1194:setup_download_scm",(void*)f_1194},
{"f_1184:setup_download_scm",(void*)f_1184},
{"f_911:setup_download_scm",(void*)f_911},
{"f_903:setup_download_scm",(void*)f_903},
{"f_901:setup_download_scm",(void*)f_901},
{"f_2196:setup_download_scm",(void*)f_2196},
{"f_2102:setup_download_scm",(void*)f_2102},
{"f_2106:setup_download_scm",(void*)f_2106},
{"f_2109:setup_download_scm",(void*)f_2109},
{"f_2112:setup_download_scm",(void*)f_2112},
{"f_2115:setup_download_scm",(void*)f_2115},
{"f_2118:setup_download_scm",(void*)f_2118},
{"f_2121:setup_download_scm",(void*)f_2121},
{"f_2124:setup_download_scm",(void*)f_2124},
{"f_2127:setup_download_scm",(void*)f_2127},
{"f_2176:setup_download_scm",(void*)f_2176},
{"f_2137:setup_download_scm",(void*)f_2137},
{"f_2147:setup_download_scm",(void*)f_2147},
{"f_2132:setup_download_scm",(void*)f_2132},
{"f_1519:setup_download_scm",(void*)f_1519},
{"f_1597:setup_download_scm",(void*)f_1597},
{"f_1592:setup_download_scm",(void*)f_1592},
{"f_1587:setup_download_scm",(void*)f_1587},
{"f_1582:setup_download_scm",(void*)f_1582},
{"f_1577:setup_download_scm",(void*)f_1577},
{"f_1521:setup_download_scm",(void*)f_1521},
{"f_1525:setup_download_scm",(void*)f_1525},
{"f_1536:setup_download_scm",(void*)f_1536},
{"f_1566:setup_download_scm",(void*)f_1566},
{"f_1540:setup_download_scm",(void*)f_1540},
{"f_1543:setup_download_scm",(void*)f_1543},
{"f_1559:setup_download_scm",(void*)f_1559},
{"f_1546:setup_download_scm",(void*)f_1546},
{"f_2022:setup_download_scm",(void*)f_2022},
{"f_2025:setup_download_scm",(void*)f_2025},
{"f_2028:setup_download_scm",(void*)f_2028},
{"f_2031:setup_download_scm",(void*)f_2031},
{"f_2034:setup_download_scm",(void*)f_2034},
{"f_2037:setup_download_scm",(void*)f_2037},
{"f_2019:setup_download_scm",(void*)f_2019},
{"f_1790:setup_download_scm",(void*)f_1790},
{"f_1809:setup_download_scm",(void*)f_1809},
{"f_1813:setup_download_scm",(void*)f_1813},
{"f_1748:setup_download_scm",(void*)f_1748},
{"f_1712:setup_download_scm",(void*)f_1712},
{"f_1745:setup_download_scm",(void*)f_1745},
{"f_1715:setup_download_scm",(void*)f_1715},
{"f_1742:setup_download_scm",(void*)f_1742},
{"f_1718:setup_download_scm",(void*)f_1718},
{"f_1739:setup_download_scm",(void*)f_1739},
{"f_1721:setup_download_scm",(void*)f_1721},
{"f_1724:setup_download_scm",(void*)f_1724},
{"f_1727:setup_download_scm",(void*)f_1727},
{"f_1734:setup_download_scm",(void*)f_1734},
{"f_2015:setup_download_scm",(void*)f_2015},
{"f_1816:setup_download_scm",(void*)f_1816},
{"f_1819:setup_download_scm",(void*)f_1819},
{"f_1822:setup_download_scm",(void*)f_1822},
{"f_1825:setup_download_scm",(void*)f_1825},
{"f_1828:setup_download_scm",(void*)f_1828},
{"f_1831:setup_download_scm",(void*)f_1831},
{"f_2008:setup_download_scm",(void*)f_2008},
{"f_1702:setup_download_scm",(void*)f_1702},
{"f_1706:setup_download_scm",(void*)f_1706},
{"f_1698:setup_download_scm",(void*)f_1698},
{"f_1834:setup_download_scm",(void*)f_1834},
{"f_1982:setup_download_scm",(void*)f_1982},
{"f_1986:setup_download_scm",(void*)f_1986},
{"f_1992:setup_download_scm",(void*)f_1992},
{"f_2004:setup_download_scm",(void*)f_2004},
{"f_1995:setup_download_scm",(void*)f_1995},
{"f_1998:setup_download_scm",(void*)f_1998},
{"f_1837:setup_download_scm",(void*)f_1837},
{"f_1970:setup_download_scm",(void*)f_1970},
{"f_2070:setup_download_scm",(void*)f_2070},
{"f_2100:setup_download_scm",(void*)f_2100},
{"f_2074:setup_download_scm",(void*)f_2074},
{"f_2086:setup_download_scm",(void*)f_2086},
{"f_2089:setup_download_scm",(void*)f_2089},
{"f_1973:setup_download_scm",(void*)f_1973},
{"f_1976:setup_download_scm",(void*)f_1976},
{"f_1980:setup_download_scm",(void*)f_1980},
{"f_1840:setup_download_scm",(void*)f_1840},
{"f_1843:setup_download_scm",(void*)f_1843},
{"f_1848:setup_download_scm",(void*)f_1848},
{"f_1852:setup_download_scm",(void*)f_1852},
{"f_1858:setup_download_scm",(void*)f_1858},
{"f_1902:setup_download_scm",(void*)f_1902},
{"f_1921:setup_download_scm",(void*)f_1921},
{"f_1924:setup_download_scm",(void*)f_1924},
{"f_1927:setup_download_scm",(void*)f_1927},
{"f_1930:setup_download_scm",(void*)f_1930},
{"f_1944:setup_download_scm",(void*)f_1944},
{"f_1946:setup_download_scm",(void*)f_1946},
{"f_1933:setup_download_scm",(void*)f_1933},
{"f_1905:setup_download_scm",(void*)f_1905},
{"f_1908:setup_download_scm",(void*)f_1908},
{"f_1918:setup_download_scm",(void*)f_1918},
{"f_1911:setup_download_scm",(void*)f_1911},
{"f_1881:setup_download_scm",(void*)f_1881},
{"f_1884:setup_download_scm",(void*)f_1884},
{"f_2062:setup_download_scm",(void*)f_2062},
{"f_2054:setup_download_scm",(void*)f_2054},
{"f_2058:setup_download_scm",(void*)f_2058},
{"f_2050:setup_download_scm",(void*)f_2050},
{"f_1795:setup_download_scm",(void*)f_1795},
{"f_1549:setup_download_scm",(void*)f_1549},
{"f_1530:setup_download_scm",(void*)f_1530},
{"f_1473:setup_download_scm",(void*)f_1473},
{"f_1497:setup_download_scm",(void*)f_1497},
{"f_1484:setup_download_scm",(void*)f_1484},
{"f_1258:setup_download_scm",(void*)f_1258},
{"f_1391:setup_download_scm",(void*)f_1391},
{"f_1386:setup_download_scm",(void*)f_1386},
{"f_1381:setup_download_scm",(void*)f_1381},
{"f_1376:setup_download_scm",(void*)f_1376},
{"f_1260:setup_download_scm",(void*)f_1260},
{"f_1264:setup_download_scm",(void*)f_1264},
{"f_1267:setup_download_scm",(void*)f_1267},
{"f_1369:setup_download_scm",(void*)f_1369},
{"f_1270:setup_download_scm",(void*)f_1270},
{"f_1273:setup_download_scm",(void*)f_1273},
{"f_1276:setup_download_scm",(void*)f_1276},
{"f_1355:setup_download_scm",(void*)f_1355},
{"f_1359:setup_download_scm",(void*)f_1359},
{"f_1353:setup_download_scm",(void*)f_1353},
{"f_1279:setup_download_scm",(void*)f_1279},
{"f_1312:setup_download_scm",(void*)f_1312},
{"f_1346:setup_download_scm",(void*)f_1346},
{"f_1316:setup_download_scm",(void*)f_1316},
{"f_1342:setup_download_scm",(void*)f_1342},
{"f_1319:setup_download_scm",(void*)f_1319},
{"f_1322:setup_download_scm",(void*)f_1322},
{"f_1338:setup_download_scm",(void*)f_1338},
{"f_1284:setup_download_scm",(void*)f_1284},
{"f_1298:setup_download_scm",(void*)f_1298},
{"f_1295:setup_download_scm",(void*)f_1295},
{"f_1135:setup_download_scm",(void*)f_1135},
{"f_1139:setup_download_scm",(void*)f_1139},
{"f_1150:setup_download_scm",(void*)f_1150},
{"f_1029:setup_download_scm",(void*)f_1029},
{"f_1033:setup_download_scm",(void*)f_1033},
{"f_1038:setup_download_scm",(void*)f_1038},
{"f_1050:setup_download_scm",(void*)f_1050},
{"f_1054:setup_download_scm",(void*)f_1054},
{"f_1060:setup_download_scm",(void*)f_1060},
{"f_1065:setup_download_scm",(void*)f_1065},
{"f_1073:setup_download_scm",(void*)f_1073},
{"f_1090:setup_download_scm",(void*)f_1090},
{"f_1111:setup_download_scm",(void*)f_1111},
{"f_1123:setup_download_scm",(void*)f_1123},
{"f_1129:setup_download_scm",(void*)f_1129},
{"f_1117:setup_download_scm",(void*)f_1117},
{"f_1096:setup_download_scm",(void*)f_1096},
{"f_1102:setup_download_scm",(void*)f_1102},
{"f_1106:setup_download_scm",(void*)f_1106},
{"f_1088:setup_download_scm",(void*)f_1088},
{"f_1085:setup_download_scm",(void*)f_1085},
{"f_1044:setup_download_scm",(void*)f_1044},
{"f_913:setup_download_scm",(void*)f_913},
{"f_981:setup_download_scm",(void*)f_981},
{"f_976:setup_download_scm",(void*)f_976},
{"f_915:setup_download_scm",(void*)f_915},
{"f_919:setup_download_scm",(void*)f_919},
{"f_922:setup_download_scm",(void*)f_922},
{"f_962:setup_download_scm",(void*)f_962},
{"f_968:setup_download_scm",(void*)f_968},
{"f_975:setup_download_scm",(void*)f_975},
{"f_925:setup_download_scm",(void*)f_925},
{"f_938:setup_download_scm",(void*)f_938},
{"f_941:setup_download_scm",(void*)f_941},
{"f_956:setup_download_scm",(void*)f_956},
{"f_947:setup_download_scm",(void*)f_947},
{"f_935:setup_download_scm",(void*)f_935},
{"f_884:setup_download_scm",(void*)f_884},
{"f_857:setup_download_scm",(void*)f_857},
{"f_873:setup_download_scm",(void*)f_873},
{"f_842:setup_download_scm",(void*)f_842},
{"f_846:setup_download_scm",(void*)f_846},
{"f_852:setup_download_scm",(void*)f_852},
{"f_855:setup_download_scm",(void*)f_855},
{"f_820:setup_download_scm",(void*)f_820},
{"f_824:setup_download_scm",(void*)f_824},
{"f_827:setup_download_scm",(void*)f_827},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
