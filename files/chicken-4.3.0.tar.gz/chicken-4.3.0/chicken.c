/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: chicken.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file chicken.c
   used units: library eval data_structures ports extras srfi_69 chicken_syntax srfi_1 srfi_4 utils files extras data_structures support compiler optimizer compiler_syntax scrutinizer driver platform backend srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_syntax_toplevel)
C_externimport void C_ccall C_compiler_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scrutinizer_toplevel)
C_externimport void C_ccall C_scrutinizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[92];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_273)
static void C_ccall f_273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_276)
static void C_ccall f_276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_279)
static void C_ccall f_279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_282)
static void C_ccall f_282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_285)
static void C_ccall f_285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_288)
static void C_ccall f_288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_291)
static void C_ccall f_291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_294)
static void C_ccall f_294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_297)
static void C_ccall f_297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_300)
static void C_ccall f_300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_303)
static void C_ccall f_303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_306)
static void C_ccall f_306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_309)
static void C_ccall f_309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_312)
static void C_ccall f_312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_315)
static void C_ccall f_315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_318)
static void C_ccall f_318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_321)
static void C_ccall f_321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_324)
static void C_ccall f_324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_327)
static void C_ccall f_327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_330)
static void C_ccall f_330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_333)
static void C_ccall f_333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_336)
static void C_ccall f_336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_340)
static void C_ccall f_340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1217)
static void C_ccall f_1217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_fcall f_1220(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1223)
static void C_fcall f_1223(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1293)
static void C_ccall f_1293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1263)
static void C_fcall f_1263(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1259)
static void C_ccall f_1259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_343)
static void C_ccall f_343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1069)
static void C_ccall f_1069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1165)
static void C_ccall f_1165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1145)
static void C_ccall f_1145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1119)
static void C_fcall f_1119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_346)
static void C_ccall f_346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_919)
static void C_ccall f_919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_932)
static void C_ccall f_932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_946)
static void C_ccall f_946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_956)
static void C_ccall f_956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_349)
static void C_ccall f_349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_833)
static void C_ccall f_833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_871)
static void C_ccall f_871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_887)
static void C_ccall f_887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_896)
static void C_ccall f_896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_909)
static void C_ccall f_909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_905)
static void C_ccall f_905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_352)
static void C_ccall f_352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_759)
static void C_ccall f_759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_763)
static void C_ccall f_763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_766)
static void C_ccall f_766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_776)
static void C_ccall f_776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_792)
static void C_ccall f_792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_812)
static void C_ccall f_812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_757)
static void C_ccall f_757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_355)
static void C_ccall f_355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_730)
static void C_ccall f_730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_749)
static void C_ccall f_749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_728)
static void C_ccall f_728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_358)
static void C_ccall f_358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_361)
static void C_ccall f_361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_721)
static void C_ccall f_721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_717)
static void C_ccall f_717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_709)
static void C_ccall f_709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_699)
static void C_ccall f_699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_707)
static void C_ccall f_707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_365)
static void C_ccall f_365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_494)
static void C_ccall f_494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_506)
static void C_fcall f_506(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_689)
static void C_ccall f_689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_682)
static void C_ccall f_682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_604)
static void C_ccall f_604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_621)
static void C_ccall f_621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_607)
static void C_ccall f_607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_528)
static void C_ccall f_528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_591)
static void C_ccall f_591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_581)
static void C_ccall f_581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_571)
static void C_ccall f_571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_561)
static void C_ccall f_561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_531)
static void C_fcall f_531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_501)
static void C_ccall f_501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_482)
static void C_ccall f_482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_489)
static void C_ccall f_489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_ccall f_474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_480)
static void C_ccall f_480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_367)
static void C_ccall f_367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_373)
static void C_fcall f_373(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_408)
static void C_fcall f_408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_434)
static void C_ccall f_434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_430)
static void C_ccall f_430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_387)
static void C_ccall f_387(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1220)
static void C_fcall trf_1220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1220(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1220(t0,t1);}

C_noret_decl(trf_1223)
static void C_fcall trf_1223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1223(t0,t1);}

C_noret_decl(trf_1263)
static void C_fcall trf_1263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1263(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1263(t0,t1);}

C_noret_decl(trf_1119)
static void C_fcall trf_1119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1119(t0,t1);}

C_noret_decl(trf_506)
static void C_fcall trf_506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_506(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_506(t0,t1,t2);}

C_noret_decl(trf_531)
static void C_fcall trf_531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_531(t0,t1);}

C_noret_decl(trf_373)
static void C_fcall trf_373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_373(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_373(t0,t1,t2,t3,t4);}

C_noret_decl(trf_408)
static void C_fcall trf_408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_408(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1108)){
C_save(t1);
C_rereclaim2(1108*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,92);
lf[0]=C_h_intern(&lf[0],33,"\003syschicken-ffi-macro-environment");
lf[1]=C_h_intern(&lf[1],27,"\010compilercompiler-arguments");
lf[2]=C_h_intern(&lf[2],29,"\010compilerprocess-command-line");
lf[3]=C_h_intern(&lf[3],7,"reverse");
lf[4]=C_h_intern(&lf[4],14,"string->symbol");
lf[5]=C_h_intern(&lf[5],9,"substring");
lf[6]=C_h_intern(&lf[6],25,"\003sysimplicit-exit-handler");
lf[7]=C_h_intern(&lf[7],17,"user-options-pass");
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],19,"compile-source-file");
lf[10]=C_h_intern(&lf[10],14,"optimize-level");
lf[11]=C_h_intern(&lf[11],22,"optimize-leaf-routines");
lf[12]=C_h_intern(&lf[12],5,"cons*");
lf[13]=C_h_intern(&lf[13],6,"inline");
lf[14]=C_h_intern(&lf[14],5,"local");
lf[15]=C_h_intern(&lf[15],6,"unsafe");
lf[16]=C_h_intern(&lf[16],18,"disable-interrupts");
lf[17]=C_h_intern(&lf[17],8,"no-trace");
lf[18]=C_h_intern(&lf[18],5,"block");
lf[19]=C_h_intern(&lf[19],11,"lambda-lift");
lf[20]=C_h_intern(&lf[20],14,"no-lambda-info");
lf[21]=C_h_intern(&lf[21],11,"debug-level");
lf[22]=C_h_intern(&lf[22],25,"\010compilercompiler-warning");
lf[23]=C_h_intern(&lf[23],5,"usage");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[25]=C_h_intern(&lf[25],31,"\010compilervalid-compiler-options");
lf[26]=C_h_intern(&lf[26],45,"\010compilervalid-compiler-options-with-argument");
lf[27]=C_h_intern(&lf[27],4,"quit");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[30]=C_h_intern(&lf[30],4,"conc");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[32]=C_h_intern(&lf[32],6,"append");
lf[33]=C_h_intern(&lf[33],4,"argv");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[35]=C_h_intern(&lf[35],6,"remove");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[37]=C_h_intern(&lf[37],12,"string-split");
lf[38]=C_h_intern(&lf[38],24,"get-environment-variable");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[40]=C_h_intern(&lf[40],16,"\003sysmacro-subset");
lf[41]=C_h_intern(&lf[41],28,"\003sysextend-macro-environment");
lf[42]=C_h_intern(&lf[42],15,"foreign-declare");
lf[43]=C_h_intern(&lf[43],12,"\004coredeclare");
lf[44]=C_h_intern(&lf[44],10,"\003sysappend");
lf[45]=C_h_intern(&lf[45],16,"\003syscheck-syntax");
lf[46]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[47]=C_h_intern(&lf[47],18,"\003syser-transformer");
lf[48]=C_h_intern(&lf[48],13,"foreign-value");
lf[49]=C_h_intern(&lf[49],14,"symbol->string");
lf[50]=C_h_intern(&lf[50],12,"syntax-error");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a string or symbol");
lf[52]=C_h_intern(&lf[52],23,"define-foreign-variable");
lf[53]=C_h_intern(&lf[53],5,"begin");
lf[54]=C_h_intern(&lf[54],6,"gensym");
lf[55]=C_h_intern(&lf[55],5,"code_");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[57]=C_h_intern(&lf[57],12,"foreign-code");
lf[58]=C_h_intern(&lf[58],11,"\004coreinline");
lf[59]=C_h_intern(&lf[59],17,"get-output-string");
lf[60]=C_h_intern(&lf[60],7,"display");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000 \012; return C_SCHEME_UNDEFINED; }\012");
lf[62]=C_h_intern(&lf[62],18,"string-intersperse");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\005() { ");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\016static C_word ");
lf[66]=C_h_intern(&lf[66],18,"open-output-string");
lf[67]=C_h_intern(&lf[67],7,"declare");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[69]=C_h_intern(&lf[69],12,"let-location");
lf[70]=C_h_intern(&lf[70],17,"\004corelet-location");
lf[71]=C_h_intern(&lf[71],10,"fold-right");
lf[72]=C_h_intern(&lf[72],10,"append-map");
lf[73]=C_h_intern(&lf[73],7,"\003sysmap");
lf[74]=C_h_intern(&lf[74],3,"let");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\000\376\001\000\000\001_");
lf[76]=C_h_intern(&lf[76],15,"define-location");
lf[77]=C_h_intern(&lf[77],9,"\004coreset!");
lf[78]=C_h_intern(&lf[78],24,"define-external-variable");
lf[79]=C_h_intern(&lf[79],9,"\003syserror");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[81]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[82]=C_h_intern(&lf[82],15,"define-external");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[84]=C_h_intern(&lf[84],5,"quote");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[86]=C_h_intern(&lf[86],29,"\004coreforeign-callback-wrapper");
lf[87]=C_h_intern(&lf[87],6,"lambda");
lf[88]=C_h_intern(&lf[88],6,"define");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[91]=C_h_intern(&lf[91],21,"\003sysmacro-environment");
C_register_lf2(lf,92,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_273,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k271 */
static void C_ccall f_273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_276,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k274 in k271 */
static void C_ccall f_276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_279,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k277 in k274 in k271 */
static void C_ccall f_279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_282,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k280 in k277 in k274 in k271 */
static void C_ccall f_282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_285,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_288,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_297,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scrutinizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[91]))(2,*((C_word*)lf[91]+1),t2);}

/* k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_343,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1208,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1210,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t3,t4);}

/* a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1210,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1217,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* r37 */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[84]);}

/* k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_1220(t4,(C_word)C_i_stringp(t3));}
else{
t3=t2;
f_1220(t3,C_SCHEME_FALSE);}}

/* k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_fcall f_1220(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1220,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1223,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_1223(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_1223(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_1223(t4,C_SCHEME_FALSE);}}}

/* k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_fcall f_1223(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1223,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1229,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t2,lf[82],((C_word*)t0)[5],lf[83]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t2,lf[82],((C_word*)t0)[5],lf[89]);}
else{
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t2,lf[82],((C_word*)t0)[5],lf[90]);}}}

/* k1326 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_cadr(((C_word*)t0)[4]):(C_word)C_i_car(((C_word*)t0)[4]));
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1341,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* r37 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[88]);}

/* k1339 in k1326 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1341,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[84],t4);
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_car(((C_word*)t0)[5]):lf[85]);
t7=(C_truep(((C_word*)t0)[6])?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[84],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t5,a[10]=t6,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1439,tmp=(C_word)a,a+=2,tmp);
/* map */
t12=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[3]);}

/* a1438 in k1339 in k1326 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1439(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1439,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k1435 in k1339 in k1326 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1437,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[84],t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
/* r37 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[87]);}

/* k1399 in k1435 in k1339 in k1326 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1425,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1424 in k1399 in k1435 in k1339 in k1326 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1425,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k1407 in k1399 in k1435 in k1339 in k1326 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1413,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* ##sys#append */
t4=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k1411 in k1407 in k1399 in k1435 in k1339 in k1326 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1413,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[86],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t11));}

/* k1227 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1229,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r37 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[53]);}

/* k1237 in k1227 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r37 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[52]);}

/* k1311 in k1237 in k1227 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1313,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* r37 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[78]);}

/* k1291 in k1311 in k1237 in k1227 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1293,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1259,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1263,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_caddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[77],t12);
t14=t8;
f_1263(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t10=t8;
f_1263(t10,C_SCHEME_END_OF_LIST);}}

/* k1261 in k1291 in k1311 in k1237 in k1227 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_fcall f_1263(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1257 in k1291 in k1311 in k1237 in k1227 in k1221 in k1218 in k1215 in a1209 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1259,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1206 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[41]))(5,*((C_word*)lf[41]+1),((C_word*)t0)[2],lf[82],C_SCHEME_END_OF_LIST,t1);}

/* k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1069,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t3,t4);}

/* a1068 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1069,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1073,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t5,lf[76],t2,lf[81]);}

/* k1071 in a1068 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1073,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1085(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1085(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[80],t4);}}}

/* k1083 in k1071 in a1068 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1088,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1185,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
((C_proc2)C_retrieve_symbol_proc(lf[54]))(2,*((C_word*)lf[54]+1),t3);}

/* k1183 in k1083 in k1071 in a1068 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r77 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1086 in k1083 in k1071 in a1068 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r77 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k1093 in k1086 in k1083 in k1071 in a1068 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r77 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[52]);}

/* k1163 in k1093 in k1086 in k1083 in k1071 in a1068 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[49]+1)))(3,*((C_word*)lf[49]+1),t2,((C_word*)t0)[6]);}

/* k1179 in k1163 in k1093 in k1086 in k1083 in k1071 in a1068 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1181,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1145,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* r77 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[78]);}

/* k1143 in k1179 in k1163 in k1093 in k1086 in k1083 in k1071 in a1068 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1145,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1119,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t9=(C_word)C_i_car(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_cons(&a,2,lf[77],t11);
t13=t8;
f_1119(t13,(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST));}
else{
t9=t8;
f_1119(t9,C_SCHEME_END_OF_LIST);}}

/* k1117 in k1143 in k1179 in k1163 in k1093 in k1086 in k1083 in k1071 in a1068 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_fcall f_1119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1113 in k1143 in k1179 in k1163 in k1093 in k1086 in k1083 in k1071 in a1068 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1115,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1065 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[41]))(5,*((C_word*)lf[41]+1),((C_word*)t0)[2],lf[76],C_SCHEME_END_OF_LIST,t1);}

/* k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_917,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_919,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t3,t4);}

/* a918 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_919,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_923,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t5,lf[69],t2,lf[75]);}

/* k921 in a918 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_923,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_932,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* r98 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[74]);}

/* k930 in k921 in a918 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1055,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a1054 in k930 in k921 in a918 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1055,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1063,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
((C_proc2)C_retrieve_symbol_proc(lf[54]))(2,*((C_word*)lf[54]+1),t3);}

/* k1061 in a1054 in k930 in k921 in a918 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r98 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k933 in k930 in k921 in a918 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_946,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1031,tmp=(C_word)a,a+=2,tmp);
/* append-map */
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),t2,t3,((C_word*)t0)[3],t1);}

/* a1030 in k933 in k930 in k921 in a918 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1031,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k944 in k933 in k930 in k921 in a918 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_954,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_956,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t5=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1027 in k944 in k933 in k930 in k921 in a918 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1029,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
/* fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[71]))(6,*((C_word*)lf[71]+1),((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a955 in k944 in k933 in k930 in k921 in a918 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_956,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[70],t12));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=(C_word)C_a_i_cons(&a,2,t7,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[70],t11));}}

/* k952 in k944 in k933 in k930 in k921 in a918 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_954,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k915 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[41]))(5,*((C_word*)lf[41]+1),((C_word*)t0)[2],lf[69],C_SCHEME_END_OF_LIST,t1);}

/* k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_831,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_833,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t3,t4);}

/* a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_833,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_837,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t5,lf[57],t2,lf[68]);}

/* k835 in a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
((C_proc3)C_retrieve_symbol_proc(lf[54]))(3,*((C_word*)lf[54]+1),t2,lf[55]);}

/* k838 in k835 in a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r129 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k845 in k838 in k835 in a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_871,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r129 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[67]);}

/* k869 in k845 in k838 in k835 in a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[66]))(2,*((C_word*)lf[66]+1),t2);}

/* k885 in k869 in k845 in k838 in k835 in a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_890,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[60]+1)))(4,*((C_word*)lf[60]+1),t2,lf[65],t1);}

/* k888 in k885 in k869 in k845 in k838 in k835 in a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[60]+1)))(4,*((C_word*)lf[60]+1),t2,((C_word*)t0)[6],((C_word*)t0)[3]);}

/* k891 in k888 in k885 in k869 in k845 in k838 in k835 in a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[60]+1)))(4,*((C_word*)lf[60]+1),t2,lf[64],((C_word*)t0)[3]);}

/* k894 in k891 in k888 in k885 in k869 in k845 in k838 in k835 in a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_909,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),t3,t4,lf[63]);}

/* k907 in k894 in k891 in k888 in k885 in k869 in k845 in k838 in k835 in a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[60]+1)))(4,*((C_word*)lf[60]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k897 in k894 in k891 in k888 in k885 in k869 in k845 in k838 in k835 in a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[60]+1)))(4,*((C_word*)lf[60]+1),t2,lf[61],((C_word*)t0)[2]);}

/* k900 in k897 in k894 in k891 in k888 in k885 in k869 in k845 in k838 in k835 in a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[59]))(3,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2]);}

/* k903 in k900 in k897 in k894 in k891 in k888 in k885 in k869 in k845 in k838 in k835 in a832 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_905,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[42],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[58],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k829 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[41]))(5,*((C_word*)lf[41]+1),((C_word*)t0)[2],lf[57],C_SCHEME_END_OF_LIST,t1);}

/* k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_757,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_759,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t3,t4);}

/* a758 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_759,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_763,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t5,lf[48],t2,lf[56]);}

/* k761 in a758 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
((C_proc3)C_retrieve_symbol_proc(lf[54]))(3,*((C_word*)lf[54]+1),t2,lf[55]);}

/* k764 in k761 in a758 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_766,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_776,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* r148 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[53]);}

/* k774 in k764 in k761 in a758 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_792,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* r148 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[52]);}

/* k790 in k774 in k764 in k761 in a758 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_792,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
t4=t3;
f_812(2,t4,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[49]+1)))(3,*((C_word*)lf[49]+1),t3,((C_word*)t0)[2]);}
else{
/* syntax-error */
((C_proc5)C_retrieve_symbol_proc(lf[50]))(5,*((C_word*)lf[50]+1),t3,lf[48],lf[51],((C_word*)t0)[2]);}}}

/* k810 in k790 in k774 in k764 in k761 in a758 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_812,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k755 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[41]))(5,*((C_word*)lf[41]+1),((C_word*)t0)[2],lf[48],C_SCHEME_END_OF_LIST,t1);}

/* k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_728,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_730,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t3,t4);}

/* a729 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_730,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_734,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t5,lf[42],t2,lf[46]);}

/* k732 in a729 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_749,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k747 in k732 in a729 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_749,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[42],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[43],t3));}

/* k726 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[41]))(5,*((C_word*)lf[41]+1),((C_word*)t0)[2],lf[42],C_SCHEME_END_OF_LIST,t1);}

/* k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_361,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-subset */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t2,((C_word*)t0)[2]);}

/* k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_361,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! chicken-ffi-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_365,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_699,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_709,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_717,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_721,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 48   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t7,lf[39]);}

/* k719 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[36]);
/* chicken.scm: 48   string-split */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],t2);}

/* k715 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 46   remove */
((C_proc4)C_retrieve_symbol_proc(lf[35]))(4,*((C_word*)lf[35]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a708 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_709,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[34]));}

/* k697 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_707,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 49   argv */
((C_proc2)C_retrieve_symbol_proc(lf[33]))(2,*((C_word*)lf[33]+1),t2);}

/* k705 in k697 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(t1);
/* chicken.scm: 45   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[32]+1)))(4,*((C_word*)lf[32]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_365,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! compiler-arguments ...) */,t1);
t3=C_mutate((C_word*)lf[2]+1 /* (set! process-command-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_367,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_474,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_482,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_494,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_494,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_498,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_506,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_506(t9,t5,((C_word*)t4)[1]);}

/* loop in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_fcall f_506(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_506,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[10],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_528,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* chicken.scm: 82   string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[21],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_604,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
/* chicken.scm: 105  string->number */
C_string_to_number(3,0,t7,t8);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[25])))){
/* chicken.scm: 112  loop */
t15=t1;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[26])))){
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_cdr(t4);
/* chicken.scm: 115  loop */
t15=t1;
t16=t7;
t1=t15;
t2=t16;
goto loop;}
else{
/* chicken.scm: 116  quit */
((C_proc4)C_retrieve_symbol_proc(lf[27]))(4,*((C_word*)lf[27]+1),t1,lf[28],t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_682,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_689,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
t9=t8;
f_689(2,t9,t3);}
else{
/* chicken.scm: 120  conc */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t8,lf[31],t3);}}}}}}}

/* k687 in loop in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 118  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[22]))(5,*((C_word*)lf[22]+1),((C_word*)t0)[2],lf[23],lf[29],t1);}

/* k680 in loop in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 121  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_506(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k602 in loop in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_607,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_621,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 107  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[12]))(5,*((C_word*)lf[12]+1),t3,lf[20],lf[17],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[17],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_607(2,t5,t4);
case C_fix(2):
t3=t2;
f_607(2,t3,C_SCHEME_FALSE);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 110  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[22]))(5,*((C_word*)lf[22]+1),t2,lf[23],lf[24],t3);}}

/* k619 in k602 in loop in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_607(2,t3,t2);}

/* k605 in k602 in loop in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 111  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_506(t3,((C_word*)t0)[2],t2);}

/* k526 in loop in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_531,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_531(t3,C_SCHEME_FALSE);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[11],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_531(t5,t4);
case C_fix(2):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_561,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 89   cons* */
((C_proc5)C_retrieve_symbol_proc(lf[12]))(5,*((C_word*)lf[12]+1),t3,lf[11],lf[13],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_571,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 92   cons* */
((C_proc6)C_retrieve_symbol_proc(lf[12]))(6,*((C_word*)lf[12]+1),t3,lf[11],lf[13],lf[14],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(4):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_581,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 95   cons* */
((C_proc7)C_retrieve_symbol_proc(lf[12]))(7,*((C_word*)lf[12]+1),t3,lf[11],lf[13],lf[14],lf[15],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(5)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_591,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 99   cons* */
((C_proc11)C_retrieve_symbol_proc(lf[12]))(11,*((C_word*)lf[12]+1),t4,lf[16],lf[17],lf[15],lf[18],lf[11],lf[19],lf[20],lf[13],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_531(t4,C_SCHEME_UNDEFINED);}}}

/* k589 in k526 in loop in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_531(t3,t2);}

/* k579 in k526 in loop in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_531(t3,t2);}

/* k569 in k526 in loop in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_531(t3,t2);}

/* k559 in k526 in loop in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_531(t3,t2);}

/* k529 in k526 in loop in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_fcall f_531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 103  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_506(t3,((C_word*)t0)[2],t2);}

/* k496 in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_501,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[9]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k499 in k496 in a493 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 123  exit */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),((C_word*)t0)[2]);}

/* a481 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_489,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 76   user-options-pass */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}

/* k487 in a481 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[2]));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[1]));}

/* k472 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_477,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_480,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),t3);}

/* k478 in k472 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k475 in k472 in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_367,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_373,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_373(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_fcall f_373(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_373,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_387,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 61   reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_408,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_408(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_408(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
/* chicken.scm: 70   loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
/* chicken.scm: 71   loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k406 in loop in ##compiler#process-command-line in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_fcall f_408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_408,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm: 67   loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_373(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_430,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_434,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 68   substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k432 in k406 in loop in ##compiler#process-command-line in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 68   string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),((C_word*)t0)[2],t1);}

/* k428 in k406 in loop in ##compiler#process-command-line in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_430,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm: 68   loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_373(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k385 in loop in ##compiler#process-command-line in k363 in k359 in k356 in k353 in k350 in k347 in k344 in k341 in k338 in k334 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 */
static void C_ccall f_387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 61   values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[132] = {
{"toplevel:chicken_scm",(void*)C_toplevel},
{"f_273:chicken_scm",(void*)f_273},
{"f_276:chicken_scm",(void*)f_276},
{"f_279:chicken_scm",(void*)f_279},
{"f_282:chicken_scm",(void*)f_282},
{"f_285:chicken_scm",(void*)f_285},
{"f_288:chicken_scm",(void*)f_288},
{"f_291:chicken_scm",(void*)f_291},
{"f_294:chicken_scm",(void*)f_294},
{"f_297:chicken_scm",(void*)f_297},
{"f_300:chicken_scm",(void*)f_300},
{"f_303:chicken_scm",(void*)f_303},
{"f_306:chicken_scm",(void*)f_306},
{"f_309:chicken_scm",(void*)f_309},
{"f_312:chicken_scm",(void*)f_312},
{"f_315:chicken_scm",(void*)f_315},
{"f_318:chicken_scm",(void*)f_318},
{"f_321:chicken_scm",(void*)f_321},
{"f_324:chicken_scm",(void*)f_324},
{"f_327:chicken_scm",(void*)f_327},
{"f_330:chicken_scm",(void*)f_330},
{"f_333:chicken_scm",(void*)f_333},
{"f_336:chicken_scm",(void*)f_336},
{"f_340:chicken_scm",(void*)f_340},
{"f_1210:chicken_scm",(void*)f_1210},
{"f_1217:chicken_scm",(void*)f_1217},
{"f_1220:chicken_scm",(void*)f_1220},
{"f_1223:chicken_scm",(void*)f_1223},
{"f_1328:chicken_scm",(void*)f_1328},
{"f_1341:chicken_scm",(void*)f_1341},
{"f_1439:chicken_scm",(void*)f_1439},
{"f_1437:chicken_scm",(void*)f_1437},
{"f_1401:chicken_scm",(void*)f_1401},
{"f_1425:chicken_scm",(void*)f_1425},
{"f_1409:chicken_scm",(void*)f_1409},
{"f_1413:chicken_scm",(void*)f_1413},
{"f_1229:chicken_scm",(void*)f_1229},
{"f_1239:chicken_scm",(void*)f_1239},
{"f_1313:chicken_scm",(void*)f_1313},
{"f_1293:chicken_scm",(void*)f_1293},
{"f_1263:chicken_scm",(void*)f_1263},
{"f_1259:chicken_scm",(void*)f_1259},
{"f_1208:chicken_scm",(void*)f_1208},
{"f_343:chicken_scm",(void*)f_343},
{"f_1069:chicken_scm",(void*)f_1069},
{"f_1073:chicken_scm",(void*)f_1073},
{"f_1085:chicken_scm",(void*)f_1085},
{"f_1185:chicken_scm",(void*)f_1185},
{"f_1088:chicken_scm",(void*)f_1088},
{"f_1095:chicken_scm",(void*)f_1095},
{"f_1165:chicken_scm",(void*)f_1165},
{"f_1181:chicken_scm",(void*)f_1181},
{"f_1145:chicken_scm",(void*)f_1145},
{"f_1119:chicken_scm",(void*)f_1119},
{"f_1115:chicken_scm",(void*)f_1115},
{"f_1067:chicken_scm",(void*)f_1067},
{"f_346:chicken_scm",(void*)f_346},
{"f_919:chicken_scm",(void*)f_919},
{"f_923:chicken_scm",(void*)f_923},
{"f_932:chicken_scm",(void*)f_932},
{"f_1055:chicken_scm",(void*)f_1055},
{"f_1063:chicken_scm",(void*)f_1063},
{"f_935:chicken_scm",(void*)f_935},
{"f_1031:chicken_scm",(void*)f_1031},
{"f_946:chicken_scm",(void*)f_946},
{"f_1029:chicken_scm",(void*)f_1029},
{"f_956:chicken_scm",(void*)f_956},
{"f_954:chicken_scm",(void*)f_954},
{"f_917:chicken_scm",(void*)f_917},
{"f_349:chicken_scm",(void*)f_349},
{"f_833:chicken_scm",(void*)f_833},
{"f_837:chicken_scm",(void*)f_837},
{"f_840:chicken_scm",(void*)f_840},
{"f_847:chicken_scm",(void*)f_847},
{"f_871:chicken_scm",(void*)f_871},
{"f_887:chicken_scm",(void*)f_887},
{"f_890:chicken_scm",(void*)f_890},
{"f_893:chicken_scm",(void*)f_893},
{"f_896:chicken_scm",(void*)f_896},
{"f_909:chicken_scm",(void*)f_909},
{"f_899:chicken_scm",(void*)f_899},
{"f_902:chicken_scm",(void*)f_902},
{"f_905:chicken_scm",(void*)f_905},
{"f_831:chicken_scm",(void*)f_831},
{"f_352:chicken_scm",(void*)f_352},
{"f_759:chicken_scm",(void*)f_759},
{"f_763:chicken_scm",(void*)f_763},
{"f_766:chicken_scm",(void*)f_766},
{"f_776:chicken_scm",(void*)f_776},
{"f_792:chicken_scm",(void*)f_792},
{"f_812:chicken_scm",(void*)f_812},
{"f_757:chicken_scm",(void*)f_757},
{"f_355:chicken_scm",(void*)f_355},
{"f_730:chicken_scm",(void*)f_730},
{"f_734:chicken_scm",(void*)f_734},
{"f_749:chicken_scm",(void*)f_749},
{"f_728:chicken_scm",(void*)f_728},
{"f_358:chicken_scm",(void*)f_358},
{"f_361:chicken_scm",(void*)f_361},
{"f_721:chicken_scm",(void*)f_721},
{"f_717:chicken_scm",(void*)f_717},
{"f_709:chicken_scm",(void*)f_709},
{"f_699:chicken_scm",(void*)f_699},
{"f_707:chicken_scm",(void*)f_707},
{"f_365:chicken_scm",(void*)f_365},
{"f_494:chicken_scm",(void*)f_494},
{"f_506:chicken_scm",(void*)f_506},
{"f_689:chicken_scm",(void*)f_689},
{"f_682:chicken_scm",(void*)f_682},
{"f_604:chicken_scm",(void*)f_604},
{"f_621:chicken_scm",(void*)f_621},
{"f_607:chicken_scm",(void*)f_607},
{"f_528:chicken_scm",(void*)f_528},
{"f_591:chicken_scm",(void*)f_591},
{"f_581:chicken_scm",(void*)f_581},
{"f_571:chicken_scm",(void*)f_571},
{"f_561:chicken_scm",(void*)f_561},
{"f_531:chicken_scm",(void*)f_531},
{"f_498:chicken_scm",(void*)f_498},
{"f_501:chicken_scm",(void*)f_501},
{"f_482:chicken_scm",(void*)f_482},
{"f_489:chicken_scm",(void*)f_489},
{"f_474:chicken_scm",(void*)f_474},
{"f_480:chicken_scm",(void*)f_480},
{"f_477:chicken_scm",(void*)f_477},
{"f_367:chicken_scm",(void*)f_367},
{"f_373:chicken_scm",(void*)f_373},
{"f_408:chicken_scm",(void*)f_408},
{"f_434:chicken_scm",(void*)f_434},
{"f_430:chicken_scm",(void*)f_430},
{"f_387:chicken_scm",(void*)f_387},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
