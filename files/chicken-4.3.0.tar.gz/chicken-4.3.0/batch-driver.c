/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: batch-driver.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[401];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1046)
static void C_ccall f_1046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1049)
static void C_ccall f_1049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1065)
static void C_ccall f_1065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1069)
static void C_ccall f_1069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_fcall f_3683(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3642)
static void C_ccall f_3642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_fcall f_1136(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_fcall f_1586(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_fcall f_1589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3566)
static void C_ccall f_3566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_fcall f_1607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_fcall f_1610(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1613)
static void C_fcall f_1613(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_fcall f_1619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_fcall f_1625(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_fcall f_1628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_fcall f_1631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_fcall f_1634(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_fcall f_1637(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_fcall f_1644(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1647)
static void C_fcall f_1647(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_fcall f_1650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_fcall f_1653(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_fcall f_1656(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_fcall f_1659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1662)
static void C_fcall f_1662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1665)
static void C_fcall f_1665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1668)
static void C_fcall f_1668(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1671)
static void C_fcall f_1671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1677)
static void C_fcall f_1677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_fcall f_1683(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1701)
static void C_ccall f_1701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1717)
static void C_fcall f_1717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_fcall f_1720(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_fcall f_1723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_fcall f_1726(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3217)
static void C_fcall f_3217(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3262)
static void C_ccall f_3262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3138)
static void C_fcall f_3138(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_fcall f_3096(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_fcall f_3063(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3029)
static void C_ccall f_3029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_fcall f_1778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_fcall f_1812(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_fcall f_1842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_fcall f_2807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2885)
static void C_ccall f_2885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_fcall f_2862(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_fcall f_1918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_fcall f_1927(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_fcall f_2611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_fcall f_2553(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2429)
static void C_ccall f_2429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_fcall f_2465(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_fcall f_1986(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_fcall f_1989(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_fcall f_2339(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_fcall f_2307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2320)
static void C_ccall f_2320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_fcall f_2027(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_ccall f_2041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_fcall f_2233(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1507)
static void C_fcall f_1507(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1537)
static void C_fcall f_1537(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1532)
static void C_fcall f_1532(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1509)
static void C_fcall f_1509(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1521)
static void C_ccall f_1521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_fcall f_1501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1472)
static void C_fcall f_1472(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1479)
static void C_ccall f_1479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1482)
static void C_ccall f_1482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1488)
static void C_ccall f_1488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static C_word C_fcall f_1462(C_word t0);
C_noret_decl(f_1432)
static void C_fcall f_1432(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1438)
static void C_fcall f_1438(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_fcall f_1352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1362)
static void C_ccall f_1362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1349)
static void C_ccall f_1349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_fcall f_1313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1268)
static void C_fcall f_1268(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1280)
static void C_fcall f_1280(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1244)
static void C_fcall f_1244(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1222)
static void C_fcall f_1222(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1198)
static void C_fcall f_1198(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1211)
static void C_ccall f_1211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1217)
static void C_ccall f_1217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_fcall f_1183(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1078)
static void C_fcall f_1078(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3683)
static void C_fcall trf_3683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3683(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3683(t0,t1);}

C_noret_decl(trf_1136)
static void C_fcall trf_1136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1136(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1136(t0,t1);}

C_noret_decl(trf_1586)
static void C_fcall trf_1586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1586(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1586(t0,t1);}

C_noret_decl(trf_1589)
static void C_fcall trf_1589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1589(t0,t1);}

C_noret_decl(trf_1607)
static void C_fcall trf_1607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1607(t0,t1);}

C_noret_decl(trf_1610)
static void C_fcall trf_1610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1610(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1610(t0,t1);}

C_noret_decl(trf_1613)
static void C_fcall trf_1613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1613(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1613(t0,t1);}

C_noret_decl(trf_1619)
static void C_fcall trf_1619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1619(t0,t1);}

C_noret_decl(trf_1625)
static void C_fcall trf_1625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1625(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1625(t0,t1);}

C_noret_decl(trf_1628)
static void C_fcall trf_1628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1628(t0,t1);}

C_noret_decl(trf_1631)
static void C_fcall trf_1631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1631(t0,t1);}

C_noret_decl(trf_1634)
static void C_fcall trf_1634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1634(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1634(t0,t1);}

C_noret_decl(trf_1637)
static void C_fcall trf_1637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1637(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1637(t0,t1);}

C_noret_decl(trf_1644)
static void C_fcall trf_1644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1644(t0,t1);}

C_noret_decl(trf_1647)
static void C_fcall trf_1647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1647(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1647(t0,t1);}

C_noret_decl(trf_1650)
static void C_fcall trf_1650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1650(t0,t1);}

C_noret_decl(trf_1653)
static void C_fcall trf_1653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1653(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1653(t0,t1);}

C_noret_decl(trf_1656)
static void C_fcall trf_1656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1656(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1656(t0,t1);}

C_noret_decl(trf_1659)
static void C_fcall trf_1659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1659(t0,t1);}

C_noret_decl(trf_1662)
static void C_fcall trf_1662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1662(t0,t1);}

C_noret_decl(trf_1665)
static void C_fcall trf_1665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1665(t0,t1);}

C_noret_decl(trf_1668)
static void C_fcall trf_1668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1668(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1668(t0,t1);}

C_noret_decl(trf_1671)
static void C_fcall trf_1671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1671(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1671(t0,t1);}

C_noret_decl(trf_1677)
static void C_fcall trf_1677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1677(t0,t1);}

C_noret_decl(trf_1683)
static void C_fcall trf_1683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1683(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1683(t0,t1);}

C_noret_decl(trf_1717)
static void C_fcall trf_1717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1717(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1717(t0,t1);}

C_noret_decl(trf_1720)
static void C_fcall trf_1720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1720(t0,t1);}

C_noret_decl(trf_1723)
static void C_fcall trf_1723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1723(t0,t1);}

C_noret_decl(trf_1726)
static void C_fcall trf_1726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1726(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1726(t0,t1);}

C_noret_decl(trf_3217)
static void C_fcall trf_3217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3217(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3217(t0,t1,t2);}

C_noret_decl(trf_3138)
static void C_fcall trf_3138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3138(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3138(t0,t1,t2);}

C_noret_decl(trf_3096)
static void C_fcall trf_3096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3096(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3096(t0,t1,t2);}

C_noret_decl(trf_3063)
static void C_fcall trf_3063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3063(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3063(t0,t1,t2);}

C_noret_decl(trf_1778)
static void C_fcall trf_1778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1778(t0,t1);}

C_noret_decl(trf_1812)
static void C_fcall trf_1812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1812(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1812(t0,t1);}

C_noret_decl(trf_1842)
static void C_fcall trf_1842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1842(t0,t1);}

C_noret_decl(trf_2807)
static void C_fcall trf_2807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2807(t0,t1,t2);}

C_noret_decl(trf_2862)
static void C_fcall trf_2862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2862(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2862(t0,t1,t2);}

C_noret_decl(trf_1918)
static void C_fcall trf_1918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1918(t0,t1);}

C_noret_decl(trf_1927)
static void C_fcall trf_1927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1927(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1927(t0,t1);}

C_noret_decl(trf_2611)
static void C_fcall trf_2611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2611(t0,t1);}

C_noret_decl(trf_2553)
static void C_fcall trf_2553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2553(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2553(t0,t1,t2);}

C_noret_decl(trf_2465)
static void C_fcall trf_2465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2465(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2465(t0,t1,t2);}

C_noret_decl(trf_1986)
static void C_fcall trf_1986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1986(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1986(t0,t1);}

C_noret_decl(trf_1989)
static void C_fcall trf_1989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1989(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1989(t0,t1);}

C_noret_decl(trf_2339)
static void C_fcall trf_2339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2339(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2339(t0,t1,t2);}

C_noret_decl(trf_2307)
static void C_fcall trf_2307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2307(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2307(t0,t1,t2);}

C_noret_decl(trf_2027)
static void C_fcall trf_2027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2027(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2027(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2233)
static void C_fcall trf_2233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2233(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2233(t0,t1);}

C_noret_decl(trf_1507)
static void C_fcall trf_1507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1507(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1507(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1537)
static void C_fcall trf_1537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1537(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1537(t0,t1);}

C_noret_decl(trf_1532)
static void C_fcall trf_1532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1532(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1532(t0,t1,t2);}

C_noret_decl(trf_1509)
static void C_fcall trf_1509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1509(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1509(t0,t1,t2,t3);}

C_noret_decl(trf_1501)
static void C_fcall trf_1501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1501(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1501(t0,t1,t2);}

C_noret_decl(trf_1472)
static void C_fcall trf_1472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1472(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1472(t0,t1,t2);}

C_noret_decl(trf_1432)
static void C_fcall trf_1432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1432(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1432(t0,t1,t2);}

C_noret_decl(trf_1438)
static void C_fcall trf_1438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1438(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1438(t0,t1,t2);}

C_noret_decl(trf_1352)
static void C_fcall trf_1352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1352(t0,t1);}

C_noret_decl(trf_1313)
static void C_fcall trf_1313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1313(t0,t1);}

C_noret_decl(trf_1268)
static void C_fcall trf_1268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1268(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1268(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1280)
static void C_fcall trf_1280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1280(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1280(t0,t1,t2);}

C_noret_decl(trf_1244)
static void C_fcall trf_1244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1244(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1244(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1222)
static void C_fcall trf_1222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1222(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1222(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1198)
static void C_fcall trf_1198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1198(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1198(t0,t1,t2,t3);}

C_noret_decl(trf_1183)
static void C_fcall trf_1183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1183(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1183(t0,t1,t2,t3);}

C_noret_decl(trf_1078)
static void C_fcall trf_1078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1078(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1078(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3113)){
C_save(t1);
C_rereclaim2(3113*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,401);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],17,"user-options-pass");
lf[3]=C_h_intern(&lf[3],14,"user-read-pass");
lf[4]=C_h_intern(&lf[4],22,"user-preprocessor-pass");
lf[5]=C_h_intern(&lf[5],9,"user-pass");
lf[6]=C_h_intern(&lf[6],23,"user-post-analysis-pass");
lf[7]=C_h_intern(&lf[7],19,"compile-source-file");
lf[8]=C_h_intern(&lf[8],4,"quit");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[11]=C_h_intern(&lf[11],12,"explicit-use");
lf[12]=C_h_intern(&lf[12],26,"\010compilerexplicit-use-flag");
lf[13]=C_h_intern(&lf[13],12,"\004coredeclare");
lf[14]=C_h_intern(&lf[14],7,"verbose");
lf[15]=C_h_intern(&lf[15],11,"output-file");
lf[16]=C_h_intern(&lf[16],36,"\010compilerdefault-optimization-passes");
lf[17]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[18]=C_h_intern(&lf[18],7,"profile");
lf[19]=C_h_intern(&lf[19],12,"profile-name");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[21]=C_h_intern(&lf[21],9,"heap-size");
lf[22]=C_h_intern(&lf[22],17,"heap-initial-size");
lf[23]=C_h_intern(&lf[23],11,"heap-growth");
lf[24]=C_h_intern(&lf[24],14,"heap-shrinkage");
lf[25]=C_h_intern(&lf[25],13,"keyword-style");
lf[26]=C_h_intern(&lf[26],4,"unit");
lf[27]=C_h_intern(&lf[27],12,"analyze-only");
lf[28]=C_h_intern(&lf[28],7,"dynamic");
lf[29]=C_h_intern(&lf[29],7,"nursery");
lf[30]=C_h_intern(&lf[30],10,"stack-size");
lf[31]=C_h_intern(&lf[31],19,"\003sysstandard-output");
lf[32]=C_h_intern(&lf[32],16,"\003sysflush-output");
lf[33]=C_h_intern(&lf[33],19,"\003syswrite-char/port");
lf[34]=C_h_intern(&lf[34],7,"fprintf");
lf[35]=C_h_intern(&lf[35],26,"\010compilerdebugging-chicken");
lf[36]=C_h_intern(&lf[36],7,"display");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\010pass: ~a");
lf[38]=C_h_intern(&lf[38],19,"\010compilerdump-nodes");
lf[39]=C_h_intern(&lf[39],12,"pretty-print");
lf[40]=C_h_intern(&lf[40],30,"\010compilerbuild-expression-tree");
lf[41]=C_h_intern(&lf[41],34,"\010compilerdisplay-analysis-database");
lf[42]=C_h_intern(&lf[42],5,"write");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\013(iteration ");
lf[44]=C_h_intern(&lf[44],19,"\003syshash-table-set!");
lf[45]=C_h_intern(&lf[45],24,"\003sysline-number-database");
lf[46]=C_h_intern(&lf[46],10,"alist-cons");
lf[47]=C_h_intern(&lf[47],18,"\003syshash-table-ref");
lf[48]=C_h_intern(&lf[48],9,"list-info");
lf[49]=C_h_intern(&lf[49],26,"\003sysdefault-read-info-hook");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[51]=C_h_intern(&lf[51],9,"substring");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\003: \011");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\030milliseconds needed for ");
lf[54]=C_h_intern(&lf[54],8,"\003sysread");
lf[55]=C_h_intern(&lf[55],12,"\010compilerget");
lf[56]=C_h_intern(&lf[56],13,"\010compilerput!");
lf[57]=C_h_intern(&lf[57],27,"\010compileranalyze-expression");
lf[58]=C_h_intern(&lf[58],9,"\003syserror");
lf[59]=C_h_intern(&lf[59],1,"D");
lf[60]=C_h_intern(&lf[60],25,"\010compilerimport-libraries");
lf[61]=C_h_intern(&lf[61],26,"\010compilerdisabled-warnings");
lf[62]=C_h_intern(&lf[62],16,"emit-inline-file");
lf[63]=C_h_intern(&lf[63],12,"inline-limit");
lf[64]=C_h_intern(&lf[64],21,"\010compilerverbose-mode");
lf[65]=C_h_intern(&lf[65],31,"\003sysread-error-with-line-number");
lf[66]=C_h_intern(&lf[66],21,"\003sysinclude-pathnames");
lf[67]=C_h_intern(&lf[67],19,"\000compiler-extension");
lf[68]=C_h_intern(&lf[68],12,"\003sysfeatures");
lf[69]=C_h_intern(&lf[69],10,"\000compiling");
lf[70]=C_h_intern(&lf[70],28,"\003sysexplicit-library-modules");
lf[71]=C_h_intern(&lf[71],25,"\010compilertarget-heap-size");
lf[72]=C_h_intern(&lf[72],33,"\010compilertarget-initial-heap-size");
lf[73]=C_h_intern(&lf[73],27,"\010compilertarget-heap-growth");
lf[74]=C_h_intern(&lf[74],30,"\010compilertarget-heap-shrinkage");
lf[75]=C_h_intern(&lf[75],26,"\010compilertarget-stack-size");
lf[76]=C_h_intern(&lf[76],8,"no-trace");
lf[77]=C_h_intern(&lf[77],24,"\010compileremit-trace-info");
lf[78]=C_h_intern(&lf[78],29,"disable-stack-overflow-checks");
lf[79]=C_h_intern(&lf[79],40,"\010compilerdisable-stack-overflow-checking");
lf[80]=C_h_intern(&lf[80],7,"version");
lf[81]=C_h_intern(&lf[81],7,"newline");
lf[82]=C_h_intern(&lf[82],22,"\010compilerprint-version");
lf[83]=C_h_intern(&lf[83],4,"help");
lf[84]=C_h_intern(&lf[84],20,"\010compilerprint-usage");
lf[85]=C_h_intern(&lf[85],7,"release");
lf[86]=C_h_intern(&lf[86],15,"chicken-version");
lf[87]=C_h_intern(&lf[87],24,"\010compilersource-filename");
lf[88]=C_h_intern(&lf[88],28,"\010compilerprofile-lambda-list");
lf[89]=C_h_intern(&lf[89],31,"\010compilerline-number-database-2");
lf[90]=C_h_intern(&lf[90],4,"node");
lf[91]=C_h_intern(&lf[91],6,"lambda");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[93]=C_h_intern(&lf[93],23,"\010compilerconstant-table");
lf[94]=C_h_intern(&lf[94],21,"\010compilerinline-table");
lf[95]=C_h_intern(&lf[95],23,"\010compilerfirst-analysis");
lf[96]=C_h_intern(&lf[96],41,"\010compilerperform-high-level-optimizations");
lf[97]=C_h_intern(&lf[97],37,"\010compilerinline-substitutions-enabled");
lf[98]=C_h_intern(&lf[98],22,"optimize-leaf-routines");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[100]=C_h_intern(&lf[100],34,"\010compilertransform-direct-lambdas!");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[102]=C_h_intern(&lf[102],4,"leaf");
lf[103]=C_h_intern(&lf[103],18,"\010compilerdebugging");
lf[104]=C_h_intern(&lf[104],1,"p");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[107]=C_h_intern(&lf[107],1,"5");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[110]=C_h_intern(&lf[110],36,"\010compilerprepare-for-code-generation");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\025compilation finished.");
lf[112]=C_h_intern(&lf[112],30,"\010compilercompiler-cleanup-hook");
lf[113]=C_h_intern(&lf[113],1,"t");
lf[114]=C_h_intern(&lf[114],17,"\003sysdisplay-times");
lf[115]=C_h_intern(&lf[115],14,"\003sysstop-timer");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[117]=C_h_intern(&lf[117],17,"close-output-port");
lf[118]=C_h_intern(&lf[118],22,"\010compilergenerate-code");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\023generating `~A\047 ...");
lf[120]=C_h_intern(&lf[120],16,"open-output-file");
lf[121]=C_h_intern(&lf[121],19,"current-output-port");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[124]=C_h_intern(&lf[124],1,"9");
lf[125]=C_h_intern(&lf[125],4,"exit");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[127]=C_h_intern(&lf[127],20,"\003syswarnings-enabled");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[129]=C_h_intern(&lf[129],1,"8");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[131]=C_h_intern(&lf[131],35,"\010compilerperform-closure-conversion");
lf[132]=C_h_intern(&lf[132],27,"\010compilerinline-output-file");
lf[133]=C_h_intern(&lf[133],32,"\010compileremit-global-inline-file");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000&Generating global inline file `~a\047 ...");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[136]=C_h_intern(&lf[136],1,"7");
lf[137]=C_h_intern(&lf[137],1,"s");
lf[138]=C_h_intern(&lf[138],33,"\010compilerprint-program-statistics");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[140]=C_h_intern(&lf[140],1,"4");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[142]=C_h_intern(&lf[142],1,"v");
lf[143]=C_h_intern(&lf[143],25,"\010compilerdump-global-refs");
lf[144]=C_h_intern(&lf[144],1,"d");
lf[145]=C_h_intern(&lf[145],29,"\010compilerdump-defined-globals");
lf[146]=C_h_intern(&lf[146],1,"u");
lf[147]=C_h_intern(&lf[147],31,"\010compilerdump-undefined-globals");
lf[148]=C_h_intern(&lf[148],3,"opt");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[150]=C_h_intern(&lf[150],1,"3");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[152]=C_h_intern(&lf[152],31,"\010compilerperform-cps-conversion");
lf[153]=C_h_intern(&lf[153],6,"unsafe");
lf[154]=C_h_intern(&lf[154],34,"\010compilerscan-toplevel-assignments");
lf[155]=C_h_intern(&lf[155],24,"\010compilerinline-globally");
lf[156]=C_h_intern(&lf[156],23,"\010compilerinline-locally");
lf[157]=C_h_intern(&lf[157],25,"\010compilerload-inline-file");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[159]=C_h_intern(&lf[159],19,"consult-inline-file");
lf[160]=C_h_intern(&lf[160],28,"\010compilerenable-inline-files");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[162]=C_h_intern(&lf[162],12,"file-exists\077");
lf[163]=C_h_intern(&lf[163],28,"\003sysresolve-include-filename");
lf[164]=C_h_intern(&lf[164],13,"make-pathname");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[166]=C_h_intern(&lf[166],14,"symbol->string");
lf[167]=C_h_intern(&lf[167],11,"concatenate");
lf[168]=C_h_intern(&lf[168],7,"\003sysmap");
lf[169]=C_h_intern(&lf[169],3,"cdr");
lf[170]=C_h_intern(&lf[170],2,"pp");
lf[171]=C_h_intern(&lf[171],1,"M");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[173]=C_h_intern(&lf[173],12,"vector->list");
lf[174]=C_h_intern(&lf[174],26,"\010compilerfile-requirements");
lf[175]=C_h_intern(&lf[175],26,"\010compilerdo-lambda-lifting");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[177]=C_h_intern(&lf[177],1,"L");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[179]=C_h_intern(&lf[179],32,"\010compilerperform-lambda-lifting!");
lf[180]=C_h_intern(&lf[180],22,"\010compilerdo-scrutinize");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\032pre-analysis (lambda-lift)");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[183]=C_h_intern(&lf[183],1,"0");
lf[184]=C_h_intern(&lf[184],4,"lift");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\010scrutiny");
lf[186]=C_h_intern(&lf[186],19,"\010compilerscrutinize");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\023performing scrutiny");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[190]=C_h_intern(&lf[190],8,"scrutiny");
lf[191]=C_h_intern(&lf[191],27,"\010compilerload-type-database");
lf[192]=C_h_intern(&lf[192],5,"types");
lf[193]=C_h_intern(&lf[193],17,"ignore-repository");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\010types.db");
lf[195]=C_h_intern(&lf[195],37,"\010compilerinitialize-analysis-database");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\021initial node tree");
lf[197]=C_h_intern(&lf[197],1,"T");
lf[198]=C_h_intern(&lf[198],25,"\010compilerbuild-node-graph");
lf[199]=C_h_intern(&lf[199],32,"\010compilercanonicalize-begin-body");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\014User pass...");
lf[202]=C_h_intern(&lf[202],12,"check-syntax");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[204]=C_h_intern(&lf[204],1,"2");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[206]=C_h_intern(&lf[206],25,"\010compilercompiler-warning");
lf[207]=C_h_intern(&lf[207],5,"style");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000Icompiling extensions in unsafe mode is bad practice and should be avoided");
lf[209]=C_h_intern(&lf[209],8,"feature\077");
lf[210]=C_h_intern(&lf[210],19,"compiling-extension");
lf[211]=C_h_intern(&lf[211],18,"\010compilerunit-name");
lf[212]=C_h_intern(&lf[212],5,"usage");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[214]=C_h_intern(&lf[214],37,"\010compilerdisplay-line-number-database");
lf[215]=C_h_intern(&lf[215],1,"n");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[217]=C_h_intern(&lf[217],32,"\010compilerdisplay-real-name-table");
lf[218]=C_h_intern(&lf[218],1,"N");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\002\011\011");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[222]=C_h_intern(&lf[222],35,"\010compilercompiler-syntax-statistics");
lf[223]=C_h_intern(&lf[223],1,"S");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\030applied compiler syntax:");
lf[225]=C_h_intern(&lf[225],6,"append");
lf[226]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[227]=C_h_intern(&lf[227],5,"quote");
lf[228]=C_h_intern(&lf[228],33,"\010compilerprofile-info-vector-name");
lf[229]=C_h_intern(&lf[229],28,"\003sysset-profile-info-vector!");
lf[230]=C_h_intern(&lf[230],21,"\010compileremit-profile");
lf[231]=C_h_intern(&lf[231],25,"\003sysregister-profile-info");
lf[232]=C_h_intern(&lf[232],4,"set!");
lf[233]=C_h_intern(&lf[233],13,"\004corecallunit");
lf[234]=C_h_intern(&lf[234],19,"\010compilerused-units");
lf[235]=C_h_intern(&lf[235],28,"\010compilerimmutable-constants");
lf[236]=C_h_intern(&lf[236],6,"gensym");
lf[237]=C_h_intern(&lf[237],32,"\010compilercanonicalize-expression");
lf[238]=C_h_intern(&lf[238],4,"uses");
lf[239]=C_h_intern(&lf[239],7,"declare");
lf[240]=C_h_intern(&lf[240],10,"\003sysappend");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[242]=C_h_intern(&lf[242],1,"1");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\032User preprocessing pass...");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\021User read pass...");
lf[245]=C_h_intern(&lf[245],21,"\010compilerstring->expr");
lf[246]=C_h_intern(&lf[246],7,"reverse");
lf[247]=C_h_intern(&lf[247],27,"\003syscurrent-source-filename");
lf[248]=C_h_intern(&lf[248],33,"\010compilerclose-checked-input-file");
lf[249]=C_h_intern(&lf[249],16,"\003sysdynamic-wind");
lf[250]=C_h_intern(&lf[250],34,"\010compilercheck-and-open-input-file");
lf[251]=C_h_intern(&lf[251],8,"epilogue");
lf[252]=C_h_intern(&lf[252],8,"prologue");
lf[253]=C_h_intern(&lf[253],8,"postlude");
lf[254]=C_h_intern(&lf[254],7,"prelude");
lf[255]=C_h_intern(&lf[255],11,"make-vector");
lf[256]=C_h_intern(&lf[256],34,"\010compilerline-number-database-size");
lf[257]=C_h_intern(&lf[257],1,"r");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\022compiling `~a\047 ...");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[264]=C_h_intern(&lf[264],5,"-help");
lf[265]=C_h_intern(&lf[265],1,"h");
lf[266]=C_h_intern(&lf[266],2,"-h");
lf[267]=C_h_intern(&lf[267],33,"\010compilerload-identifier-database");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[269]=C_h_intern(&lf[269],18,"accumulate-profile");
lf[270]=C_h_intern(&lf[270],28,"\010compilerprofiled-procedures");
lf[271]=C_h_intern(&lf[271],3,"all");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\024Generating ~aprofile");
lf[275]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[276]=C_h_intern(&lf[276],39,"\010compilerdefault-profiling-declarations");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\022debugging info: ~A");
lf[280]=C_h_intern(&lf[280],21,"no-usual-integrations");
lf[281]=C_h_intern(&lf[281],17,"standard-bindings");
lf[282]=C_h_intern(&lf[282],34,"\010compilerdefault-standard-bindings");
lf[283]=C_h_intern(&lf[283],17,"extended-bindings");
lf[284]=C_h_intern(&lf[284],34,"\010compilerdefault-extended-bindings");
lf[285]=C_h_intern(&lf[285],1,"m");
lf[286]=C_h_intern(&lf[286],14,"set-gc-report!");
lf[287]=C_h_intern(&lf[287],42,"\010compilerdefault-default-target-stack-size");
lf[288]=C_h_intern(&lf[288],41,"\010compilerdefault-default-target-heap-size");
lf[289]=C_h_intern(&lf[289],14,"compile-syntax");
lf[290]=C_h_intern(&lf[290],25,"\003sysenable-runtime-macros");
lf[291]=C_h_intern(&lf[291],22,"\004corerequire-extension");
lf[292]=C_h_intern(&lf[292],14,"string->symbol");
lf[293]=C_h_intern(&lf[293],17,"require-extension");
lf[294]=C_h_intern(&lf[294],16,"static-extension");
lf[295]=C_h_intern(&lf[295],28,"\010compilerpostponed-initforms");
lf[296]=C_h_intern(&lf[296],6,"delete");
lf[297]=C_h_intern(&lf[297],3,"eq\077");
lf[298]=C_h_intern(&lf[298],4,"load");
lf[299]=C_h_intern(&lf[299],12,"load-verbose");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\036Loading compiler extensions...");
lf[301]=C_h_intern(&lf[301],6,"extend");
lf[302]=C_h_intern(&lf[302],17,"register-feature!");
lf[303]=C_h_intern(&lf[303],12,"string-split");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[305]=C_h_intern(&lf[305],10,"append-map");
lf[306]=C_h_intern(&lf[306],7,"feature");
lf[307]=C_h_intern(&lf[307],38,"no-procedure-checks-for-usual-bindings");
lf[308]=C_h_intern(&lf[308],8,"\003sysput!");
lf[309]=C_h_intern(&lf[309],21,"\010compileralways-bound");
lf[310]=C_h_intern(&lf[310],34,"\010compileralways-bound-to-procedure");
lf[311]=C_h_intern(&lf[311],19,"no-procedure-checks");
lf[312]=C_h_intern(&lf[312],28,"\010compilerno-procedure-checks");
lf[313]=C_h_intern(&lf[313],15,"no-bound-checks");
lf[314]=C_h_intern(&lf[314],24,"\010compilerno-bound-checks");
lf[315]=C_h_intern(&lf[315],14,"no-argc-checks");
lf[316]=C_h_intern(&lf[316],23,"\010compilerno-argc-checks");
lf[317]=C_h_intern(&lf[317],20,"keep-shadowed-macros");
lf[318]=C_h_intern(&lf[318],33,"\010compilerundefine-shadowed-macros");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[320]=C_h_intern(&lf[320],23,"\010compilerchop-separator");
lf[321]=C_h_intern(&lf[321],12,"include-path");
lf[322]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[323]=C_h_intern(&lf[323],13,"symbol-escape");
lf[324]=C_h_intern(&lf[324],20,"parentheses-synonyms");
lf[325]=C_h_intern(&lf[325],5,"\000none");
lf[326]=C_h_intern(&lf[326],14,"case-sensitive");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000.Disabled the Chicken extensions to R5RS syntax");
lf[328]=C_h_intern(&lf[328],16,"no-symbol-escape");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000$Disabled support for escaped symbols");
lf[330]=C_h_intern(&lf[330],23,"no-parenthesis-synonyms");
lf[331]=C_h_intern(&lf[331],20,"parenthesis-synonyms");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000)Disabled support for parenthesis synonyms");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[334]=C_h_intern(&lf[334],7,"\000prefix");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[337]=C_h_intern(&lf[337],7,"\000suffix");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[339]=C_h_intern(&lf[339],17,"compress-literals");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[341]=C_h_intern(&lf[341],16,"case-insensitive");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000,Identifiers and symbols are case insensitive");
lf[343]=C_h_intern(&lf[343],24,"\010compilerinline-max-size");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[345]=C_h_intern(&lf[345],26,"\010compilerlocal-definitions");
lf[346]=C_h_intern(&lf[346],6,"inline");
lf[347]=C_h_intern(&lf[347],30,"emit-external-prototypes-first");
lf[348]=C_h_intern(&lf[348],30,"\010compilerexternal-protos-first");
lf[349]=C_h_intern(&lf[349],5,"block");
lf[350]=C_h_intern(&lf[350],26,"\010compilerblock-compilation");
lf[351]=C_h_intern(&lf[351],17,"fixnum-arithmetic");
lf[352]=C_h_intern(&lf[352],11,"number-type");
lf[353]=C_h_intern(&lf[353],6,"fixnum");
lf[354]=C_h_intern(&lf[354],18,"disable-interrupts");
lf[355]=C_h_intern(&lf[355],28,"\010compilerinsert-timer-checks");
lf[356]=C_h_intern(&lf[356],10,"setup-mode");
lf[357]=C_h_intern(&lf[357],14,"\003syssetup-mode");
lf[358]=C_h_intern(&lf[358],16,"unsafe-libraries");
lf[359]=C_h_intern(&lf[359],27,"\010compileremit-unsafe-marker");
lf[360]=C_h_intern(&lf[360],11,"no-warnings");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\025Warnings are disabled");
lf[362]=C_h_intern(&lf[362],15,"disable-warning");
lf[363]=C_h_intern(&lf[363],13,"inline-global");
lf[364]=C_h_intern(&lf[364],5,"local");
lf[365]=C_h_intern(&lf[365],18,"no-compiler-syntax");
lf[366]=C_h_intern(&lf[366],32,"\010compilercompiler-syntax-enabled");
lf[367]=C_h_intern(&lf[367],14,"no-lambda-info");
lf[368]=C_h_intern(&lf[368],26,"\010compileremit-closure-info");
lf[369]=C_h_intern(&lf[369],3,"raw");
lf[370]=C_h_intern(&lf[370],12,"emit-exports");
lf[371]=C_h_intern(&lf[371],7,"warning");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[373]=C_h_intern(&lf[373],1,"b");
lf[374]=C_h_intern(&lf[374],15,"\003sysstart-timer");
lf[375]=C_h_intern(&lf[375],10,"scrutinize");
lf[376]=C_h_intern(&lf[376],11,"lambda-lift");
lf[377]=C_h_intern(&lf[377],25,"emit-all-import-libraries");
lf[378]=C_h_intern(&lf[378],29,"\010compilerall-import-libraries");
lf[379]=C_h_intern(&lf[379],13,"string-append");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[381]=C_h_intern(&lf[381],19,"emit-import-library");
lf[382]=C_h_intern(&lf[382],16,"\003sysstring->list");
lf[383]=C_h_intern(&lf[383],5,"debug");
lf[384]=C_h_intern(&lf[384],18,"\003sysdload-disabled");
lf[385]=C_h_intern(&lf[385],15,"repository-path");
lf[386]=C_h_intern(&lf[386],30,"\010compilerstandalone-executable");
lf[387]=C_h_intern(&lf[387],29,"\010compilerstring->c-identifier");
lf[388]=C_h_intern(&lf[388],18,"\010compilerstringify");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[391]=C_h_intern(&lf[391],24,"get-environment-variable");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[393]=C_h_intern(&lf[393],9,"to-stdout");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[395]=C_h_intern(&lf[395],13,"pathname-file");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[397]=C_h_intern(&lf[397],29,"\010compilerdefault-declarations");
lf[398]=C_h_intern(&lf[398],30,"\010compilerunits-used-by-default");
lf[399]=C_h_intern(&lf[399],28,"\010compilerinitialize-compiler");
lf[400]=C_h_intern(&lf[400],14,"make-parameter");
C_register_lf2(lf,401,create_ptable());
t2=C_mutate(&lf[0] /* (set! c301 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1037,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1035 */
static void C_ccall f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1038 in k1035 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1041 in k1038 in k1035 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1049,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1052,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1057,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 38   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[400]))(3,*((C_word*)lf[400]+1),t2,C_SCHEME_FALSE);}

/* k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1057,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1061,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 39   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[400]))(3,*((C_word*)lf[400]+1),t3,C_SCHEME_FALSE);}

/* k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1061,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1065,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 40   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[400]))(3,*((C_word*)lf[400]+1),t3,C_SCHEME_FALSE);}

/* k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1065,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1069,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 41   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[400]))(3,*((C_word*)lf[400]+1),t3,C_SCHEME_FALSE);}

/* k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1069,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1073,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 42   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[400]))(3,*((C_word*)lf[400]+1),t3,C_SCHEME_FALSE);}

/* k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1073,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate((C_word*)lf[7]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1075,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1075r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1075r(t0,t1,t2,t3);}}

static void C_ccall f_1075r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1078,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1111,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 55   initialize-compiler */
((C_proc2)C_retrieve_symbol_proc(lf[399]))(2,*((C_word*)lf[399]+1),t5);}

/* k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
t2=(C_word)C_i_memq(lf[11],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[12]+1 /* (set! explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3679,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3683,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[12]))){
t7=t6;
f_3683(t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3694,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t8=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[398]),C_SCHEME_END_OF_LIST);}}

/* k3692 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3694,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[238],t1);
t3=((C_word*)t0)[2];
f_3683(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k3681 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_3683(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 58   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),((C_word*)t0)[2],C_retrieve(lf[397]),t1);}

/* k3677 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3675,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[13],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[14],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[15],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3642,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 66   option-arg */
f_1078(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[393],((C_word*)t0)[5]))){
t9=t8;
f_1127(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3664,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 71   pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[395]))(3,*((C_word*)lf[395]+1),t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_3664(2,t10,lf[396]);}}}}

/* k3662 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 71   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[164]))(5,*((C_word*)lf[164]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[394]);}

/* k3640 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
/* batch-driver.scm: 68   symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_1127(2,t2,t1);}}

/* k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1130,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3632,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3636,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 72   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[391]))(3,*((C_word*)lf[391]+1),t4,lf[392]);}

/* k3634 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[389]);
/* batch-driver.scm: 72   string-split */
((C_proc4)C_retrieve_symbol_proc(lf[303]))(4,*((C_word*)lf[303]+1),((C_word*)t0)[2],t2,lf[390]);}

/* k3630 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[320]),t1);}

/* k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1130,2,t0,t1);}
t2=C_retrieve(lf[16]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[17];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[18],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1136,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1136(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[269],((C_word*)t0)[8]);
t14=t12;
f_1136(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[19],((C_word*)t0)[8])));}}

/* k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1136(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[92],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1136,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[19],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[20]);
t5=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[28],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_FALSE;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=(C_word)C_i_memq(lf[29],((C_word*)t0)[13]);
t22=(C_truep(t21)?t21:(C_word)C_i_memq(lf[30],((C_word*)t0)[13]));
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1183,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1198,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1222,a[2]=t24,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1244,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1268,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1303,tmp=(C_word)a,a+=2,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1352,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1432,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1462,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1501,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1507,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t29,a[11]=t22,a[12]=t1,a[13]=t33,a[14]=((C_word*)t0)[3],a[15]=t4,a[16]=((C_word*)t0)[4],a[17]=t27,a[18]=t30,a[19]=t26,a[20]=t13,a[21]=t14,a[22]=((C_word*)t0)[5],a[23]=t23,a[24]=t25,a[25]=t34,a[26]=t32,a[27]=t31,a[28]=t18,a[29]=((C_word*)t0)[6],a[30]=((C_word*)t0)[7],a[31]=((C_word*)t0)[8],a[32]=t20,a[33]=t11,a[34]=((C_word*)t0)[12],a[35]=((C_word*)t0)[13],a[36]=t16,tmp=(C_word)a,a+=37,tmp);
if(C_truep(t12)){
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3605,a[2]=t35,tmp=(C_word)a,a+=3,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3609,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 169  option-arg */
f_1078(t38,t12);}
else{
t36=t35;
f_1586(t36,C_SCHEME_UNDEFINED);}}

/* k3611 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 169  stringify */
((C_proc3)C_retrieve_symbol_proc(lf[388]))(3,*((C_word*)lf[388]+1),((C_word*)t0)[2],t1);}

/* k3607 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 169  string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[387]))(3,*((C_word*)lf[387]+1),((C_word*)t0)[2],t1);}

/* k3603 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[211]+1 /* (set! unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1586(t3,t2);}

/* k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1586(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1586,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=C_retrieve(lf[211]);
t4=(C_truep(t3)?t3:((C_word*)t0)[21]);
if(C_truep(t4)){
t5=C_set_block_item(lf[386] /* standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_1589(t6,t5);}
else{
t5=t2;
f_1589(t5,C_SCHEME_UNDEFINED);}}

/* k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1589,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[193],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[384] /* dload-disabled */,0,C_SCHEME_TRUE);
/* batch-driver.scm: 174  repository-path */
((C_proc3)C_retrieve_symbol_proc(lf[385]))(3,*((C_word*)lf[385]+1),t2,C_SCHEME_FALSE);}
else{
t3=t2;
f_1592(2,t3,C_SCHEME_UNDEFINED);}}

/* k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3568,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3590,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 180  collect-options */
t5=((C_word*)t0)[18];
f_1432(t5,t4,lf[383]);}

/* k3588 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 176  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[305]))(4,*((C_word*)lf[305]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3567 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3568,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3574,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3586,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t5=C_retrieve(lf[382]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3584 in a3567 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3573 in a3567 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3574,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* batch-driver.scm: 178  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[292]+1)))(3,*((C_word*)lf[292]+1),t1,t3);}

/* k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1596,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1 /* (set! debugging-chicken ...) */,t1);
t3=(C_word)C_i_memq(lf[59],C_retrieve(lf[35]));
t4=C_mutate(((C_word *)((C_word*)t0)[36])+1,t3);
t5=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3550,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3566,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 186  collect-options */
t8=((C_word*)t0)[18];
f_1432(t8,t7,lf[381]);}

/* k3564 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3549 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3550,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3558,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 184  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[292]+1)))(3,*((C_word*)lf[292]+1),t3,t2);}

/* k3556 in a3549 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3562,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 185  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[379]+1)))(4,*((C_word*)lf[379]+1),t2,((C_word*)t0)[2],lf[380]);}

/* k3560 in k3556 in a3549 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3562,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1604,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1 /* (set! import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t4=(C_word)C_i_memq(lf[377],((C_word*)t0)[35]);
t5=(C_truep(t4)?(C_word)C_i_not(((C_word*)t0)[20]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_set_block_item(lf[378] /* all-import-libraries */,0,C_SCHEME_TRUE);
t7=t3;
f_1607(t7,t6);}
else{
t6=t3;
f_1607(t6,C_SCHEME_UNDEFINED);}}

/* k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1607,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[376],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[175] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t4=t2;
f_1610(t4,t3);}
else{
t3=t2;
f_1610(t3,C_SCHEME_UNDEFINED);}}

/* k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1610,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[375],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[180] /* do-scrutinize */,0,C_SCHEME_TRUE);
t4=t2;
f_1613(t4,t3);}
else{
t3=t2;
f_1613(t3,C_SCHEME_UNDEFINED);}}

/* k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1613(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1613,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[113],C_retrieve(lf[35])))){
/* batch-driver.scm: 192  ##sys#start-timer */
t3=*((C_word*)lf[374]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_1616(2,t3,C_SCHEME_UNDEFINED);}}

/* k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[373],C_retrieve(lf[35])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_1619(t4,t3);}
else{
t3=t2;
f_1619(t3,C_SCHEME_UNDEFINED);}}

/* k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1619,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[370],((C_word*)t0)[34]))){
/* batch-driver.scm: 195  warning */
((C_proc3)C_retrieve_symbol_proc(lf[371]))(3,*((C_word*)lf[371]+1),t2,lf[372]);}
else{
t3=t2;
f_1622(2,t3,C_SCHEME_UNDEFINED);}}

/* k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[369],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[12] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[30],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_1625(t6,t5);}
else{
t3=t2;
f_1625(t3,C_SCHEME_UNDEFINED);}}

/* k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1625(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1625,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[367],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[368] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_1628(t4,t3);}
else{
t3=t2;
f_1628(t3,C_SCHEME_UNDEFINED);}}

/* k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1628,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[365],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[366] /* compiler-syntax-enabled */,0,C_SCHEME_FALSE);
t4=t2;
f_1631(t4,t3);}
else{
t3=t2;
f_1631(t3,C_SCHEME_UNDEFINED);}}

/* k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1631,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[364],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[345] /* local-definitions */,0,C_SCHEME_TRUE);
t4=t2;
f_1634(t4,t3);}
else{
t3=t2;
f_1634(t3,C_SCHEME_UNDEFINED);}}

/* k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1634(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1634,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[363],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[160] /* enable-inline-files */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[156] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[155] /* inline-globally */,0,C_SCHEME_TRUE);
t6=t2;
f_1637(t6,t5);}
else{
t3=t2;
f_1637(t3,C_SCHEME_UNDEFINED);}}

/* k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1637(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1637,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3490,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 210  collect-options */
t4=((C_word*)t0)[17];
f_1432(t4,t3,lf[362]);}

/* k3488 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[292]+1),t1);}

/* k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1641,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! disabled-warnings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[360],((C_word*)t0)[34]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3485,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 212  dribble */
t5=((C_word*)t0)[22];
f_1183(t5,t4,lf[361],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_1644(t4,C_SCHEME_UNDEFINED);}}

/* k3483 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[127] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_1644(t3,t2);}

/* k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1644(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1644,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[98],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[98] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_1647(t4,t3);}
else{
t3=t2;
f_1647(t3,C_SCHEME_UNDEFINED);}}

/* k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1647(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1647,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[153],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[153] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_1650(t4,t3);}
else{
t3=t2;
f_1650(t3,C_SCHEME_UNDEFINED);}}

/* k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1650,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(C_truep(((C_word*)t0)[20])?(C_word)C_i_memq(lf[358],((C_word*)t0)[34]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[359] /* emit-unsafe-marker */,0,C_SCHEME_TRUE);
t5=t2;
f_1653(t5,t4);}
else{
t4=t2;
f_1653(t4,C_SCHEME_UNDEFINED);}}

/* k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1653(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1653,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[356],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[357] /* setup-mode */,0,C_SCHEME_TRUE);
t4=t2;
f_1656(t4,t3);}
else{
t3=t2;
f_1656(t3,C_SCHEME_UNDEFINED);}}

/* k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1656(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1656,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[354],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[355] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_1659(t4,t3);}
else{
t3=t2;
f_1659(t3,C_SCHEME_UNDEFINED);}}

/* k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1659,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[351],((C_word*)t0)[34]))){
t3=C_mutate((C_word*)lf[352]+1 /* (set! number-type ...) */,lf[353]);
t4=t2;
f_1662(t4,t3);}
else{
t3=t2;
f_1662(t3,C_SCHEME_UNDEFINED);}}

/* k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1662,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[349],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[350] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_1665(t4,t3);}
else{
t3=t2;
f_1665(t3,C_SCHEME_UNDEFINED);}}

/* k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1665,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[347],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[348] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_1668(t4,t3);}
else{
t3=t2;
f_1668(t3,C_SCHEME_UNDEFINED);}}

/* k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1668(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1668,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[346],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[156] /* inline-locally */,0,C_SCHEME_TRUE);
t4=t2;
f_1671(t4,t3);}
else{
t3=t2;
f_1671(t3,C_SCHEME_UNDEFINED);}}

/* k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1671(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1671,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[62],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=C_set_block_item(lf[156] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[345] /* local-definitions */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3440,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 230  option-arg */
f_1078(t6,t2);}
else{
t4=t3;
f_1677(t4,C_SCHEME_FALSE);}}

/* k3438 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[132]+1 /* (set! inline-output-file ...) */,t1);
t3=((C_word*)t0)[2];
f_1677(t3,t2);}

/* k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1677,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[63],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[34],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3425,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 233  option-arg */
f_1078(t4,t2);}
else{
t4=t3;
f_1683(t4,C_SCHEME_FALSE);}}

/* k3423 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3428,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 234  string->number */
C_string_to_number(3,0,t2,t1);}

/* k3426 in k3423 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3431,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_3431(2,t3,t1);}
else{
/* batch-driver.scm: 235  quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t2,lf[344],((C_word*)t0)[2]);}}

/* k3429 in k3426 in k3423 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[343]+1 /* (set! inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_1683(t3,t2);}

/* k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1683(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1683,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[341],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3415,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 237  dribble */
t4=((C_word*)t0)[22];
f_1183(t4,t3,lf[342],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1686(2,t3,C_SCHEME_UNDEFINED);}}

/* k3413 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 238  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[302]))(3,*((C_word*)lf[302]+1),t2,lf[341]);}

/* k3416 in k3413 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 239  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[326]))(3,*((C_word*)lf[326]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[339],((C_word*)t0)[30]))){
/* batch-driver.scm: 241  compiler-warning */
((C_proc4)C_retrieve_symbol_proc(lf[206]))(4,*((C_word*)lf[206]+1),t2,lf[212],lf[340]);}
else{
t3=t2;
f_1689(2,t3,C_SCHEME_UNDEFINED);}}

/* k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1692,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3373,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 243  option-arg */
f_1078(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_1692(2,t3,C_SCHEME_UNDEFINED);}}

/* k3371 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[333],t1))){
/* batch-driver.scm: 244  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[334]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[335],t1))){
/* batch-driver.scm: 245  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[325]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[336],t1))){
/* batch-driver.scm: 246  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[337]);}
else{
/* batch-driver.scm: 247  quit */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[338]);}}}}

/* k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[330],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3367,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 249  dribble */
t4=((C_word*)t0)[21];
f_1183(t4,t3,lf[332],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1695(2,t3,C_SCHEME_UNDEFINED);}}

/* k3365 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 250  parenthesis-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[331]))(3,*((C_word*)lf[331]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[328],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3358,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 252  dribble */
t4=((C_word*)t0)[21];
f_1183(t4,t3,lf[329],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1698(2,t3,C_SCHEME_UNDEFINED);}}

/* k3356 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 253  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[323]))(3,*((C_word*)lf[323]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[322],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3340,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 255  dribble */
t4=((C_word*)t0)[21];
f_1183(t4,t3,lf[327],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1701(2,t3,C_SCHEME_UNDEFINED);}}

/* k3338 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 256  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[326]))(3,*((C_word*)lf[326]+1),t2,C_SCHEME_FALSE);}

/* k3341 in k3338 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 257  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t2,lf[325]);}

/* k3344 in k3341 in k3338 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 258  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[324]))(3,*((C_word*)lf[324]+1),t2,C_SCHEME_FALSE);}

/* k3347 in k3344 in k3341 in k3338 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 259  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[323]))(3,*((C_word*)lf[323]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1701,2,t0,t1);}
t2=C_mutate((C_word*)lf[64]+1 /* (set! verbose-mode ...) */,((C_word*)t0)[33]);
t3=C_set_block_item(lf[65] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1707,a[2]=((C_word*)t0)[33],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3330,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3334,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 263  collect-options */
t7=((C_word*)t0)[16];
f_1432(t7,t6,lf[321]);}

/* k3332 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[320]),t1);}

/* k3328 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 263  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[225]+1)))(5,*((C_word*)lf[225]+1),((C_word*)t0)[3],t1,C_retrieve(lf[66]),((C_word*)t0)[2]);}

/* k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1707,2,t0,t1);}
t2=C_mutate((C_word*)lf[66]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t4=(C_truep(((C_word*)t0)[20])?(C_truep(((C_word*)t0)[27])?(C_word)C_i_string_equal_p(((C_word*)t0)[20],((C_word*)t0)[27]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
/* batch-driver.scm: 267  quit */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),t3,lf[319]);}
else{
t5=t3;
f_1710(2,t5,C_SCHEME_UNDEFINED);}}

/* k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3314,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 268  collect-options */
t4=((C_word*)t0)[16];
f_1432(t4,t3,lf[238]);}

/* k3312 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[292]+1),t1);}

/* k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1714,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[32],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[317],((C_word*)t0)[29]))){
t4=C_set_block_item(lf[318] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_1717(t5,t4);}
else{
t4=t3;
f_1717(t4,C_SCHEME_UNDEFINED);}}

/* k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1717,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[315],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[316] /* no-argc-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1720(t4,t3);}
else{
t3=t2;
f_1720(t3,C_SCHEME_UNDEFINED);}}

/* k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1720,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[313],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[314] /* no-bound-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1723(t4,t3);}
else{
t3=t2;
f_1723(t3,C_SCHEME_UNDEFINED);}}

/* k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1723,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[311],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[312] /* no-procedure-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1726(t4,t3);}
else{
t3=t2;
f_1726(t3,C_SCHEME_UNDEFINED);}}

/* k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1726(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1726,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[307],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3133,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3217,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3217(t7,t3,C_retrieve(lf[282]));}
else{
t3=t2;
f_1729(2,t3,C_SCHEME_UNDEFINED);}}

/* loop427 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_3217(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3217,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3257,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3232,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_3232(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_3232(2,t8,(C_word)C_i_car(t5));}
else{
/* ##sys#error */
t8=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3230 in loop427 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[308]))(5,*((C_word*)lf[308]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[310],t1);}

/* k3255 in loop427 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3287,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3262,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3262(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3262(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3260 in k3255 in loop427 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[308]))(5,*((C_word*)lf[308]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[309],t1);}

/* k3285 in k3255 in loop427 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3217(t3,((C_word*)t0)[2],t2);}

/* k3131 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3138,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3138(t5,((C_word*)t0)[2],C_retrieve(lf[284]));}

/* loop468 in k3131 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_3138(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3138,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3178,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3153,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_3153(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_3153(2,t8,(C_word)C_i_car(t5));}
else{
/* ##sys#error */
t8=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3151 in loop468 in k3131 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[308]))(5,*((C_word*)lf[308]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[310],t1);}

/* k3176 in loop468 in k3131 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3208,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3183,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3183(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3183(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3181 in k3176 in loop468 in k3131 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[308]))(5,*((C_word*)lf[308]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[309],t1);}

/* k3206 in k3176 in loop468 in k3131 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3138(t3,((C_word*)t0)[2],t2);}

/* k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3094,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3119,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3127,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 292  collect-options */
t6=((C_word*)t0)[17];
f_1432(t6,t5,lf[306]);}

/* k3125 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 292  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[305]))(4,*((C_word*)lf[305]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3118 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3119,3,t0,t1,t2);}
/* string-split */
((C_proc4)C_retrieve_symbol_proc(lf[303]))(4,*((C_word*)lf[303]+1),t1,t2,lf[304]);}

/* k3092 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3094,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3096,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3096(t5,((C_word*)t0)[2],t1);}

/* loop510 in k3092 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_3096(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3096,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3106,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[302]))(3,*((C_word*)lf[302]+1),t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3104 in loop510 in k3092 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3096(t3,((C_word*)t0)[2],t2);}

/* k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[67],C_retrieve(lf[68]));
t3=C_mutate((C_word*)lf[68]+1 /* (set! features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 296  collect-options */
t5=((C_word*)t0)[17];
f_1432(t5,t4,lf[301]);}

/* k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1742,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 297  dribble */
t3=((C_word*)t0)[22];
f_1183(t3,t2,lf[300],C_SCHEME_END_OF_LIST);}

/* k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 298  load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[299]))(3,*((C_word*)lf[299]+1),t2,C_SCHEME_TRUE);}
else{
t3=t2;
f_1745(2,t3,C_SCHEME_UNDEFINED);}}

/* k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3063,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3063(t6,t2,((C_word*)t0)[2]);}

/* loop529 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_3063(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3063,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3076,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3087,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 300  ##sys#resolve-include-filename */
((C_proc5)C_retrieve_symbol_proc(lf[163]))(5,*((C_word*)lf[163]+1),t5,t3,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3085 in loop529 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 300  load */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),((C_word*)t0)[2],t1);}

/* k3074 in loop529 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3063(t3,((C_word*)t0)[2],t2);}

/* k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 302  delete */
((C_proc5)C_retrieve_symbol_proc(lf[296]))(5,*((C_word*)lf[296]+1),t2,lf[67],C_retrieve(lf[68]),*((C_word*)lf[297]+1));}

/* k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1752,2,t0,t1);}
t2=C_mutate((C_word*)lf[68]+1 /* (set! features ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[69],C_retrieve(lf[68]));
t4=C_mutate((C_word*)lf[68]+1 /* (set! features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 305  user-post-analysis-pass */
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),t5);}

/* k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1760,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm: 308  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),t3,((C_word*)((C_word*)t0)[30])[1],C_retrieve(lf[295]));}

/* k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[30])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3061,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 310  collect-options */
t5=((C_word*)t0)[16];
f_1432(t5,t4,lf[294]);}

/* k3059 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[292]+1),t1);}

/* k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[49],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1771,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],tmp=(C_word)a,a+=32,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[30],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3029,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3049,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3053,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3057,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 316  collect-options */
t8=((C_word*)t0)[16];
f_1432(t8,t7,lf[293]);}

/* k3055 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[292]+1),t1);}

/* k3051 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 316  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3047 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3028 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3029,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[291],t5));}

/* k3025 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 313  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1771,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[31],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm: 320  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),t3,C_retrieve(lf[70]),((C_word*)t0)[2]);}

/* k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1775,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
if(C_truep((C_word)C_i_memq(lf[289],((C_word*)t0)[30]))){
t4=C_set_block_item(lf[290] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_1778(t5,t4);}
else{
t4=t3;
f_1778(t4,C_SCHEME_UNDEFINED);}}

/* k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1778,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3006,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 326  option-arg */
f_1078(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[288]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1782(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1782(2,t4,C_SCHEME_FALSE);}}}

/* k3004 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 326  arg-val */
f_1352(((C_word*)t0)[2],t1);}

/* k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* (set! target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2999,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 330  option-arg */
f_1078(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1786(2,t4,C_SCHEME_FALSE);}}

/* k2997 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 330  arg-val */
f_1352(((C_word*)t0)[2],t1);}

/* k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1786,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1 /* (set! target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2992,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 331  option-arg */
f_1078(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1790(2,t4,C_SCHEME_FALSE);}}

/* k2990 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 331  arg-val */
f_1352(((C_word*)t0)[2],t1);}

/* k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1790,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* (set! target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1794,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2985,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 332  option-arg */
f_1078(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1794(2,t4,C_SCHEME_FALSE);}}

/* k2983 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 332  arg-val */
f_1352(((C_word*)t0)[2],t1);}

/* k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1794,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2965,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 335  option-arg */
f_1078(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[287]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1798(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1798(2,t5,C_SCHEME_FALSE);}}}

/* k2963 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 335  arg-val */
f_1352(((C_word*)t0)[2],t1);}

/* k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1798,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! target-stack-size ...) */,t1);
t3=(C_word)C_i_memq(lf[76],((C_word*)t0)[23]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[77]+1 /* (set! emit-trace-info ...) */,t4);
t6=(C_word)C_i_memq(lf[78],((C_word*)t0)[23]);
t7=C_mutate((C_word*)lf[79]+1 /* (set! disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[285],C_retrieve(lf[35])))){
/* batch-driver.scm: 341  set-gc-report! */
((C_proc3)C_retrieve_symbol_proc(lf[286]))(3,*((C_word*)lf[286]+1),t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1809(2,t9,C_SCHEME_UNDEFINED);}}

/* k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[280],((C_word*)t0)[23]))){
t3=t2;
f_1812(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[281]+1 /* (set! standard-bindings ...) */,C_retrieve(lf[282]));
t4=C_mutate((C_word*)lf[283]+1 /* (set! extended-bindings ...) */,C_retrieve(lf[284]));
t5=t2;
f_1812(t5,t4);}}

/* k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1812(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1812,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(C_truep(C_retrieve(lf[77]))?lf[277]:lf[278]);
/* batch-driver.scm: 345  dribble */
t4=((C_word*)t0)[15];
f_1183(t4,t2,lf[279],(C_word)C_a_i_list(&a,1,t3));}

/* k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[269],t3);
t5=C_set_block_item(lf[230] /* emit-profile */,0,C_SCHEME_TRUE);
t6=C_mutate((C_word*)lf[270]+1 /* (set! profiled-procedures ...) */,lf[271]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2924,a[2]=t2,a[3]=((C_word*)t0)[15],a[4]=t4,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t8=(C_truep(t4)?lf[275]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 354  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[225]+1)))(5,*((C_word*)lf[225]+1),t7,((C_word*)((C_word*)t0)[6])[1],C_retrieve(lf[276]),t8);}
else{
t3=t2;
f_1818(2,t3,C_SCHEME_UNDEFINED);}}

/* k2922 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_truep(((C_word*)t0)[4])?lf[272]:lf[273]);
/* batch-driver.scm: 360  dribble */
t4=((C_word*)t0)[3];
f_1183(t4,((C_word*)t0)[2],lf[274],(C_word)C_a_i_list(&a,1,t3));}

/* k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 363  load-identifier-database */
((C_proc3)C_retrieve_symbol_proc(lf[267]))(3,*((C_word*)lf[267]+1),t2,lf[268]);}

/* k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1821,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[80],((C_word*)t0)[22]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[21],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 366  print-version */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[83],((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t2)){
t4=t3;
f_1842(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[264],((C_word*)t0)[22]);
if(C_truep(t4)){
t5=t3;
f_1842(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[265],((C_word*)t0)[22]);
t6=t3;
f_1842(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[266],((C_word*)t0)[22])));}}}}

/* k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1842,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 369  print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[84]))(2,*((C_word*)lf[84]+1),((C_word*)t0)[22]);}
else{
if(C_truep((C_word)C_i_memq(lf[85],((C_word*)t0)[21]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1861,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 371  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[86]))(2,*((C_word*)lf[86]+1),t3);}
else{
t2=((C_word*)t0)[20];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[21],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[22],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 379  dribble */
t4=((C_word*)t0)[14];
f_1183(t4,t3,lf[262],(C_word)C_a_i_list(&a,1,((C_word*)t0)[20]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 374  print-version */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t3,C_SCHEME_TRUE);}}}}

/* k1868 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 375  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],lf[263]);}

/* k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! source-filename ...) */,((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[22],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 381  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[103]))(5,*((C_word*)lf[103]+1),t3,lf[257],lf[261],((C_word*)t0)[9]);}

/* k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 382  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[103]))(5,*((C_word*)lf[103]+1),t2,lf[257],lf[260],C_retrieve(lf[35]));}

/* k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 383  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[103]))(5,*((C_word*)lf[103]+1),t2,lf[257],lf[259],C_retrieve(lf[71]));}

/* k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 384  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[103]))(5,*((C_word*)lf[103]+1),t2,lf[257],lf[258],C_retrieve(lf[75]));}

/* k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(6));
t3=C_mutate(((C_word *)((C_word*)t0)[22])+1,t2);
t4=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[22],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 388  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[255]+1)))(4,*((C_word*)lf[255]+1),t4,C_retrieve(lf[256]),C_SCHEME_END_OF_LIST);}

/* k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 389  collect-options */
t4=((C_word*)t0)[10];
f_1432(t4,t3,lf[254]);}

/* k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 390  collect-options */
t3=((C_word*)t0)[10];
f_1432(t3,t2,lf[253]);}

/* k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[11],a[3]=t2,a[4]=((C_word*)t0)[17],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 392  collect-options */
t4=((C_word*)t0)[11];
f_1432(t4,t3,lf[252]);}

/* k2890 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2900,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 394  collect-options */
t4=((C_word*)t0)[2];
f_1432(t4,t3,lf[251]);}

/* k2898 in k2890 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 391  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[225]+1)))(5,*((C_word*)lf[225]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
/* batch-driver.scm: 396  user-read-pass */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}

/* k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],a[21]=((C_word*)t0)[25],tmp=(C_word)a,a+=22,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 398  dribble */
t4=((C_word*)t0)[21];
f_1183(t4,t3,lf[244],C_SCHEME_END_OF_LIST);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2807,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2807(t6,t2,((C_word*)t0)[4]);}}

/* doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_2807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2807,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2818,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[245]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 408  check-and-open-input-file */
((C_proc3)C_retrieve_symbol_proc(lf[250]))(3,*((C_word*)lf[250]+1),t4,t3);}}

/* k2834 in doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2836,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2839,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2848,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2885,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[249]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2884 in k2834 in doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2885,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[247]));
t3=C_mutate((C_word*)lf[247]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2852 in k2834 in doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2857,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 410  read-form */
t3=((C_word*)t0)[2];
f_1501(t3,t2,((C_word*)t0)[5]);}

/* k2855 in a2852 in k2834 in doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2857,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2862,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2862(t5,((C_word*)t0)[2],t1);}

/* doloop627 in k2855 in a2852 in k2834 in doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_2862(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2862,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* batch-driver.scm: 413  close-checked-input-file */
((C_proc4)C_retrieve_symbol_proc(lf[248]))(4,*((C_word*)lf[248]+1),t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2883,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 411  read-form */
t6=((C_word*)t0)[2];
f_1501(t6,t5,((C_word*)t0)[6]);}}

/* k2881 in doloop627 in k2855 in a2852 in k2834 in doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2862(t2,((C_word*)t0)[2],t1);}

/* a2847 in k2834 in doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[247]));
t3=C_mutate((C_word*)lf[247]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2837 in k2834 in doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2807(t3,((C_word*)t0)[2],t2);}

/* k2820 in doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 405  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[246]+1)))(3,*((C_word*)lf[246]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2824 in k2820 in doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2830,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[245]),((C_word*)t0)[2]);}

/* k2828 in k2824 in k2820 in doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 404  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[225]+1)))(5,*((C_word*)lf[225]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2816 in doloop608 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2796 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 399  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2800 in k2796 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1912(2,t3,t2);}

/* k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm: 417  user-preprocessor-pass */
((C_proc2)C_retrieve_symbol_proc(lf[4]))(2,*((C_word*)lf[4]+1),t2);}

/* k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2791,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 419  dribble */
t4=((C_word*)t0)[17];
f_1183(t4,t3,lf[243],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1918(t3,C_SCHEME_UNDEFINED);}}

/* k2789 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2793 in k2789 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1918(t3,t2);}

/* k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1918,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm: 422  print-expr */
t3=((C_word*)t0)[7];
f_1268(t3,t2,lf[241],lf[242],((C_word*)((C_word*)t0)[3])[1]);}

/* k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1921,2,t0,t1);}
t2=f_1462(((C_word*)t0)[21]);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1927(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 425  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),t4,C_retrieve(lf[70]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k2766 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2768,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k2786 in k2766 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[238],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[239],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1927(t7,t6);}

/* k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1927(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1927,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2761,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 427  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2759 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[237]),t1);}

/* k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 428  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[236]))(2,*((C_word*)lf[236]+1),t2);}

/* k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[88]));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],tmp=(C_word)a,a+=17,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2729,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[235]));}

/* a2728 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2729,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[227],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[232],t8));}

/* k2601 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2719,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[234]));}

/* a2718 in k2601 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2719,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[233],t3));}

/* k2605 in k2601 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[230]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[227],t3);
t5=(C_truep(C_retrieve(lf[211]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[227],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t4,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[231],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[228]),t11);
t13=(C_word)C_a_i_cons(&a,2,lf[232],t12);
t14=t2;
f_2611(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_2611(t3,C_SCHEME_END_OF_LIST);}}

/* k2609 in k2605 in k2601 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_2611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2611,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2615,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2630,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[88]));}

/* a2629 in k2609 in k2605 in k2601 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2630,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[227],t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[227],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[228]),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[229],t11));}

/* k2613 in k2609 in k2605 in k2601 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[211]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 430  append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[225]+1)))(9,*((C_word*)lf[225]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[226]);}

/* k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1939,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2548,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[222])))){
/* batch-driver.scm: 452  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t5,lf[223],lf[224]);}
else{
t6=t5;
f_2548(2,t6,C_SCHEME_FALSE);}}

/* k2546 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2548,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2553,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2553(t5,((C_word*)t0)[2],C_retrieve(lf[222]));}
else{
t2=((C_word*)t0)[2];
f_1942(2,t2,C_SCHEME_UNDEFINED);}}

/* loop681 in k2546 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_2553(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2553,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=*((C_word*)lf[31]+1);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2566,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t5,lf[221],t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2564 in loop681 in k2546 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,t3,((C_word*)t0)[3]);}

/* k2567 in k2564 in loop681 in k2546 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,lf[220],((C_word*)t0)[3]);}

/* k2570 in k2567 in k2564 in loop681 in k2546 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,t3,((C_word*)t0)[3]);}

/* k2573 in k2570 in k2567 in k2564 in loop681 in k2546 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2578,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2576 in k2573 in k2570 in k2567 in k2564 in loop681 in k2546 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2553(t3,((C_word*)t0)[2],t2);}

/* k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2542,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 456  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t3,lf[218],lf[219]);}

/* k2540 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 457  display-real-name-table */
((C_proc2)C_retrieve_symbol_proc(lf[217]))(2,*((C_word*)lf[217]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1945(2,t2,C_SCHEME_UNDEFINED);}}

/* k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2536,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 458  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t3,lf[215],lf[216]);}

/* k2534 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 459  display-line-number-database */
((C_proc2)C_retrieve_symbol_proc(lf[214]))(2,*((C_word*)lf[214]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1948(2,t2,C_SCHEME_UNDEFINED);}}

/* k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(C_truep(C_retrieve(lf[211]))?((C_word*)t0)[10]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 462  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[206]))(5,*((C_word*)lf[206]+1),t2,lf[212],lf[213],C_retrieve(lf[211]));}
else{
t4=t2;
f_1951(2,t4,C_SCHEME_UNDEFINED);}}

/* k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2521,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[153]))){
/* batch-driver.scm: 464  feature? */
((C_proc3)C_retrieve_symbol_proc(lf[209]))(3,*((C_word*)lf[209]+1),t3,lf[210]);}
else{
t4=t3;
f_2521(2,t4,C_SCHEME_FALSE);}}

/* k2519 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 465  compiler-warning */
((C_proc4)C_retrieve_symbol_proc(lf[206]))(4,*((C_word*)lf[206]+1),((C_word*)t0)[2],lf[207],lf[208]);}
else{
t2=((C_word*)t0)[2];
f_1954(2,t2,C_SCHEME_UNDEFINED);}}

/* k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! line-number-database ...) */,C_retrieve(lf[89]));
t3=C_set_block_item(lf[89] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 472  end-time */
t5=((C_word*)t0)[16];
f_1472(t5,t4,lf[205]);}

/* k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 473  print-expr */
t3=((C_word*)t0)[2];
f_1268(t3,t2,lf[203],lf[204],((C_word*)((C_word*)t0)[3])[1]);}

/* k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep((C_word)C_i_memq(lf[202],((C_word*)t0)[3]))){
/* batch-driver.scm: 475  exit */
((C_proc2)C_retrieve_symbol_proc(lf[125]))(2,*((C_word*)lf[125]+1),t2);}
else{
t3=t2;
f_1965(2,t3,C_SCHEME_UNDEFINED);}}

/* k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 477  user-pass */
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),t2);}

/* k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2502,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 479  dribble */
t4=((C_word*)t0)[12];
f_1183(t4,t3,lf[201],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1971(2,t3,C_SCHEME_UNDEFINED);}}

/* k2500 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2502,2,t0,t1);}
t2=f_1462(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k2507 in k2500 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 482  end-time */
t3=((C_word*)t0)[3];
f_1472(t3,((C_word*)t0)[2],lf[200]);}

/* k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2499,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 487  canonicalize-begin-body */
((C_proc3)C_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2497 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 486  build-node-graph */
((C_proc3)C_retrieve_symbol_proc(lf[198]))(3,*((C_word*)lf[198]+1),((C_word*)t0)[2],t1);}

/* k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2495,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[90],lf[91],lf[92],t2);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 490  print-node */
t7=((C_word*)t0)[12];
f_1222(t7,t6,lf[196],lf[197],t3);}

/* k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 491  initialize-analysis-database */
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t2);}

/* k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[180]))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2429,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[16],a[7]=t2,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[17],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_memq(lf[193],((C_word*)t0)[2]))){
t4=t3;
f_2429(2,t4,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 496  load-type-database */
((C_proc3)C_retrieve_symbol_proc(lf[191]))(3,*((C_word*)lf[191]+1),t3,lf[194]);}}
else{
t3=t2;
f_1986(t3,C_SCHEME_UNDEFINED);}}

/* k2427 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2463,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 497  collect-options */
t4=((C_word*)t0)[2];
f_1432(t4,t3,lf[192]);}

/* k2461 in k2427 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2463,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2465,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2465(t5,((C_word*)t0)[2],t1);}

/* loop727 in k2461 in k2427 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_2465(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2465,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2478,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##compiler#load-type-database */
((C_proc4)C_retrieve_symbol_proc(lf[191]))(4,*((C_word*)lf[191]+1),t4,t3,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2476 in loop727 in k2461 in k2427 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2465(t3,((C_word*)t0)[2],t2);}

/* k2430 in k2427 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2432,2,t0,t1);}
t2=f_1462(((C_word*)t0)[8]);
t3=C_set_block_item(lf[95] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 500  analyze */
t5=((C_word*)t0)[2];
f_1507(t5,t4,lf[190],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* k2438 in k2430 in k2427 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2440,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2443,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 501  print-db */
t4=((C_word*)t0)[2];
f_1244(t4,t3,lf[189],lf[183],((C_word*)((C_word*)t0)[7])[1],C_fix(0));}

/* k2441 in k2438 in k2430 in k2427 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 502  end-time */
t3=((C_word*)t0)[4];
f_1472(t3,t2,lf[188]);}

/* k2444 in k2441 in k2438 in k2430 in k2427 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2446,2,t0,t1);}
t2=f_1462(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 504  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t3,lf[104],lf[187]);}

/* k2450 in k2444 in k2441 in k2438 in k2430 in k2427 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 505  scrutinize */
((C_proc4)C_retrieve_symbol_proc(lf[186]))(4,*((C_word*)lf[186]+1),t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2453 in k2450 in k2444 in k2441 in k2438 in k2430 in k2427 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 506  end-time */
t3=((C_word*)t0)[2];
f_1472(t3,t2,lf[185]);}

/* k2456 in k2453 in k2450 in k2444 in k2441 in k2438 in k2430 in k2427 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[95] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1986(t3,t2);}

/* k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1986(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1986,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1989,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[175]))){
t3=f_1462(((C_word*)t0)[16]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[13],a[6]=t2,a[7]=((C_word*)t0)[16],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[180]))){
t5=t4;
f_2402(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=C_set_block_item(lf[95] /* first-analysis */,0,C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2420,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 513  analyze */
t7=((C_word*)t0)[14];
f_1507(t7,t6,lf[184],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}
else{
t3=t2;
f_1989(t3,C_SCHEME_UNDEFINED);}}

/* k2418 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2420,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 514  print-db */
t4=((C_word*)t0)[2];
f_1244(t4,t3,lf[182],lf[183],((C_word*)((C_word*)t0)[5])[1],C_fix(0));}

/* k2421 in k2418 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 515  end-time */
t2=((C_word*)t0)[3];
f_1472(t2,((C_word*)t0)[2],lf[181]);}

/* k2400 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=f_1462(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2408,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 517  perform-lambda-lifting! */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2406 in k2400 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 518  end-time */
t3=((C_word*)t0)[2];
f_1472(t3,t2,lf[178]);}

/* k2409 in k2406 in k2400 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 519  print-node */
t3=((C_word*)t0)[3];
f_1222(t3,t2,lf[176],lf[177],((C_word*)t0)[2]);}

/* k2412 in k2409 in k2406 in k2400 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[95] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1989(t3,t2);}

/* k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1989(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1989,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2396,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 522  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[173]+1)))(3,*((C_word*)lf[173]+1),t3,C_retrieve(lf[174]));}

/* k2394 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 522  concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),((C_word*)t0)[2],t1);}

/* k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1995,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2389,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 523  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t3,lf[171],lf[172]);}

/* k2387 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 524  pp */
((C_proc3)C_retrieve_symbol_proc(lf[170]))(3,*((C_word*)lf[170]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1995(2,t2,C_SCHEME_UNDEFINED);}}

/* k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[160]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2337,a[2]=t2,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2386,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[169]+1),((C_word*)t0)[2]);}
else{
t3=t2;
f_1998(2,t3,C_SCHEME_UNDEFINED);}}

/* k2384 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 534  concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),((C_word*)t0)[2],t1);}

/* k2335 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2339,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2339(t5,((C_word*)t0)[2],t1);}

/* loop772 in k2335 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_2339(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2339,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2378,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2382,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 529  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2380 in loop772 in k2335 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 529  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[164]))(5,*((C_word*)lf[164]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[165]);}

/* k2376 in loop772 in k2335 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 528  ##sys#resolve-include-filename */
((C_proc5)C_retrieve_symbol_proc(lf[163]))(5,*((C_word*)lf[163]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2350 in loop772 in k2335 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2355,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 531  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[162]))(3,*((C_word*)lf[162]+1),t3,t1);}
else{
t3=t2;
f_2355(2,t3,C_SCHEME_FALSE);}}

/* k2366 in k2350 in loop772 in k2335 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 532  dribble */
t3=((C_word*)t0)[2];
f_1183(t3,t2,lf[161],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t2=((C_word*)t0)[4];
f_2355(2,t2,C_SCHEME_FALSE);}}

/* k2369 in k2366 in k2350 in loop772 in k2335 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 533  load-inline-file */
((C_proc3)C_retrieve_symbol_proc(lf[157]))(3,*((C_word*)lf[157]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2353 in k2350 in loop772 in k2335 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2339(t3,((C_word*)t0)[2],t2);}

/* k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 535  collect-options */
t3=((C_word*)t0)[2];
f_1432(t3,t2,lf[159]);}

/* k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_2004(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(lf[155] /* inline-globally */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[156] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[10],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2307(t8,t2,t1);}}

/* loop790 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_2307(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2307,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2320,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 541  dribble */
t5=((C_word*)t0)[2];
f_1183(t5,t4,lf[158],(C_word)C_a_i_list(&a,1,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2318 in loop790 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2323,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 542  load-inline-file */
((C_proc3)C_retrieve_symbol_proc(lf[157]))(3,*((C_word*)lf[157]+1),t2,((C_word*)t0)[2]);}

/* k2321 in k2318 in loop790 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2307(t3,((C_word*)t0)[2],t2);}

/* k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=C_set_block_item(lf[45] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[93] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[94] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[153]))){
t6=t5;
f_2010(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
t7=(C_word)C_i_car(t6);
/* batch-driver.scm: 549  scan-toplevel-assignments */
((C_proc3)C_retrieve_symbol_proc(lf[154]))(3,*((C_word*)lf[154]+1),t5,t7);}}

/* k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2010,2,t0,t1);}
t2=f_1462(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 552  perform-cps-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),t3,((C_word*)t0)[2]);}

/* k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2019,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 553  end-time */
t3=((C_word*)t0)[12];
f_1472(t3,t2,lf[151]);}

/* k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 554  print-node */
t3=((C_word*)t0)[11];
f_1222(t3,t2,lf[149],lf[150],((C_word*)t0)[2]);}

/* k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2022,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t3,a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp));
t5=((C_word*)t3)[1];
f_2027(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_2027(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2027,NULL,5,t0,t1,t2,t3,t4);}
t5=f_1462(((C_word*)t0)[13]);
t6=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=t3,a[16]=((C_word*)t0)[13],a[17]=t4,tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 560  analyze */
t7=((C_word*)t0)[10];
f_1507(t7,t6,lf[148],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t1,a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
if(C_truep(C_retrieve(lf[95]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2262,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[146],C_retrieve(lf[35])))){
/* batch-driver.scm: 563  dump-undefined-globals */
((C_proc3)C_retrieve_symbol_proc(lf[147]))(3,*((C_word*)lf[147]+1),t3,t1);}
else{
t4=t3;
f_2262(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2037(2,t3,C_SCHEME_UNDEFINED);}}

/* k2260 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[144],C_retrieve(lf[35])))){
/* batch-driver.scm: 565  dump-defined-globals */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2265(2,t3,C_SCHEME_UNDEFINED);}}

/* k2263 in k2260 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(lf[142],C_retrieve(lf[35])))){
/* batch-driver.scm: 567  dump-global-refs */
((C_proc3)C_retrieve_symbol_proc(lf[143]))(3,*((C_word*)lf[143]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2037(2,t2,C_SCHEME_UNDEFINED);}}

/* k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2037,2,t0,t1);}
t2=C_set_block_item(lf[95] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 569  end-time */
t4=((C_word*)t0)[12];
f_1472(t4,t3,lf[141]);}

/* k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 570  print-db */
t3=((C_word*)t0)[2];
f_1244(t3,t2,lf[139],lf[140],((C_word*)t0)[15],((C_word*)t0)[14]);}

/* k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_memq(lf[137],C_retrieve(lf[35])))){
/* batch-driver.scm: 572  print-program-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[138]))(3,*((C_word*)lf[138]+1),t2,((C_word*)t0)[15]);}
else{
t3=t2;
f_2047(2,t3,C_SCHEME_UNDEFINED);}}

/* k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2047,2,t0,t1);}
if(C_truep(((C_word*)t0)[18])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2053,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[16],a[10]=((C_word*)t0)[17],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 575  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[103]))(5,*((C_word*)lf[103]+1),t2,lf[104],lf[109],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 599  print-node */
t3=((C_word*)t0)[10];
f_1222(t3,t2,lf[135],lf[136],((C_word*)t0)[16]);}}

/* k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[132]))){
t3=C_retrieve(lf[132]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2250,a[2]=((C_word*)t0)[14],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 603  dribble */
t5=((C_word*)t0)[13];
f_1183(t5,t4,lf[134],(C_word)C_a_i_list(&a,1,t3));}
else{
t3=t2;
f_2142(2,t3,C_SCHEME_UNDEFINED);}}

/* k2248 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 604  emit-global-inline-file */
((C_proc4)C_retrieve_symbol_proc(lf[133]))(4,*((C_word*)lf[133]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
t2=f_1462(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 607  perform-closure-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[131]))(4,*((C_word*)lf[131]+1),t3,((C_word*)t0)[2],((C_word*)t0)[14]);}

/* k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t1,a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 608  end-time */
t3=((C_word*)t0)[11];
f_1472(t3,t2,lf[130]);}

/* k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2154,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 609  print-db */
t3=((C_word*)t0)[3];
f_1244(t3,t2,lf[128],lf[129],((C_word*)t0)[13],((C_word*)t0)[2]);}

/* k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2233,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[127]))){
t4=(C_word)C_fudge(C_fix(6));
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_2233(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_2233(t4,C_SCHEME_FALSE);}}

/* k2231 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_2233(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 611  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],lf[126]);}
else{
t2=((C_word*)t0)[2];
f_2157(2,t2,C_SCHEME_UNDEFINED);}}

/* k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 612  exit */
((C_proc3)C_retrieve_symbol_proc(lf[125]))(3,*((C_word*)lf[125]+1),t2,C_fix(0));}
else{
t3=t2;
f_2160(2,t3,C_SCHEME_UNDEFINED);}}

/* k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 613  print-node */
t3=((C_word*)t0)[2];
f_1222(t3,t2,lf[123],lf[124],((C_word*)t0)[10]);}

/* k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2163,2,t0,t1);}
t2=f_1462(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2176 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2177,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm: 618  end-time */
t7=((C_word*)t0)[6];
f_1472(t7,t6,lf[122]);}

/* k2179 in a2176 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2181,2,t0,t1);}
t2=f_1462(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[8])){
/* batch-driver.scm: 621  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[120]+1)))(3,*((C_word*)lf[120]+1),t3,((C_word*)t0)[8]);}
else{
/* batch-driver.scm: 621  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[121]+1)))(2,*((C_word*)lf[121]+1),t3);}}

/* k2185 in k2179 in a2176 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm: 622  dribble */
t3=((C_word*)t0)[11];
f_1183(t3,t2,lf[119],(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]));}

/* k2188 in k2185 in k2179 in a2176 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 623  generate-code */
((C_proc9)C_retrieve_symbol_proc(lf[118]))(9,*((C_word*)lf[118]+1),t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2191 in k2188 in k2185 in k2179 in a2176 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2196,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 624  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[117]+1)))(3,*((C_word*)lf[117]+1),t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2196(2,t3,C_SCHEME_UNDEFINED);}}

/* k2194 in k2191 in k2188 in k2185 in k2179 in a2176 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 625  end-time */
t3=((C_word*)t0)[2];
f_1472(t3,t2,lf[116]);}

/* k2197 in k2194 in k2191 in k2188 in k2185 in k2179 in a2176 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[113],C_retrieve(lf[35])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2218,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 626  ##sys#stop-timer */
t4=*((C_word*)lf[115]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2202(2,t3,C_SCHEME_UNDEFINED);}}

/* k2216 in k2197 in k2194 in k2191 in k2188 in k2185 in k2179 in a2176 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 626  ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),((C_word*)t0)[2],t1);}

/* k2200 in k2197 in k2194 in k2191 in k2188 in k2185 in k2179 in a2176 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 627  compiler-cleanup-hook */
((C_proc2)C_retrieve_symbol_proc(lf[112]))(2,*((C_word*)lf[112]+1),t2);}

/* k2203 in k2200 in k2197 in k2194 in k2191 in k2188 in k2185 in k2179 in a2176 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 628  dribble */
t2=((C_word*)t0)[3];
f_1183(t2,((C_word*)t0)[2],lf[111],C_SCHEME_END_OF_LIST);}

/* a2170 in k2161 in k2158 in k2155 in k2152 in k2149 in k2146 in k2140 in k2137 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2171,2,t0,t1);}
/* batch-driver.scm: 617  prepare-for-code-generation */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2051 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2053,2,t0,t1);}
t2=f_1462(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2066 in k2051 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2067,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 580  end-time */
t5=((C_word*)t0)[4];
f_1472(t5,t4,lf[108]);}

/* k2069 in a2066 in k2051 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 581  print-node */
t3=((C_word*)t0)[2];
f_1222(t3,t2,lf[106],lf[107],((C_word*)t0)[6]);}

/* k2072 in k2069 in a2066 in k2051 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2074,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 583  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2027(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[97]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[98]))){
t3=f_1462(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 590  analyze */
t5=((C_word*)t0)[2];
f_1507(t5,t4,lf[102],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 596  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2027(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 585  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t3,lf[104],lf[105]);}}}

/* k2091 in k2072 in k2069 in a2066 in k2051 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[97] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 587  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2027(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2108 in k2072 in k2069 in a2066 in k2051 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2113,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 591  end-time */
t3=((C_word*)t0)[2];
f_1472(t3,t2,lf[101]);}

/* k2111 in k2108 in k2072 in k2069 in a2066 in k2051 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2113,2,t0,t1);}
t2=f_1462(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 593  transform-direct-lambdas! */
((C_proc4)C_retrieve_symbol_proc(lf[100]))(4,*((C_word*)lf[100]+1),t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2117 in k2111 in k2108 in k2072 in k2069 in a2066 in k2051 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2122,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 594  end-time */
t3=((C_word*)t0)[2];
f_1472(t3,t2,lf[99]);}

/* k2120 in k2117 in k2111 in k2108 in k2072 in k2069 in a2066 in k2051 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 595  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2027(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2060 in k2051 in k2045 in k2042 in k2039 in k2035 in k2032 in loop in k2020 in k2017 in k2014 in k2008 in k2002 in k1999 in k1996 in k1993 in k1990 in k1987 in k1984 in k1981 in k1978 in k2493 in k1969 in k1966 in k1963 in k1960 in k1957 in k1952 in k1949 in k1946 in k1943 in k1940 in k1937 in k1931 in k1928 in k1925 in k1919 in k1916 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1887 in k1884 in k1881 in k1878 in k1874 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
/* batch-driver.scm: 579  perform-high-level-optimizations */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1859 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 371  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],t1);}

/* k1852 in k1840 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 372  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[81]+1)))(2,*((C_word*)lf[81]+1),((C_word*)t0)[2]);}

/* k1828 in k1819 in k1816 in k1813 in k1810 in k1807 in k1796 in k1792 in k1788 in k1784 in k1780 in k1776 in k1773 in k1769 in k1765 in k1762 in k1758 in k1750 in k1746 in k1743 in k1740 in k1737 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1708 in k1705 in k1699 in k1696 in k1693 in k1690 in k1687 in k1684 in k1681 in k1675 in k1669 in k1666 in k1663 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 in k1611 in k1608 in k1605 in k1602 in k1594 in k1590 in k1587 in k1584 in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 367  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[81]+1)))(2,*((C_word*)lf[81]+1),((C_word*)t0)[2]);}

/* analyze in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1507(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1507,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1509,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1532,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1537,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-no258296 */
t8=t7;
f_1537(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-contf259294 */
t10=t6;
f_1532(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body256264 */
t12=t5;
f_1509(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-no258 in analyze in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1537,NULL,2,t0,t1);}
/* def-contf259294 */
t2=((C_word*)t0)[2];
f_1532(t2,t1,C_fix(0));}

/* def-contf259 in analyze in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1532(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1532,NULL,3,t0,t1,t2);}
/* body256264 */
t3=((C_word*)t0)[2];
f_1509(t3,t1,t2,C_SCHEME_TRUE);}

/* body256 in analyze in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1509(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1509,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1513,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 160  analyze-expression */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t4,((C_word*)t0)[2]);}

/* k1511 in body256 in analyze in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1516,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1521,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1527,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 162  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_1516(2,t3,C_SCHEME_UNDEFINED);}}

/* a1526 in k1511 in body256 in analyze in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1527,5,t0,t1,t2,t3,t4);}
/* ##compiler#put! */
((C_proc6)C_retrieve_symbol_proc(lf[56]))(6,*((C_word*)lf[56]+1),t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1520 in k1511 in body256 in analyze in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1521,4,t0,t1,t2,t3);}
/* ##compiler#get */
((C_proc5)C_retrieve_symbol_proc(lf[55]))(5,*((C_word*)lf[55]+1),t1,((C_word*)t0)[2],t2,t3);}

/* k1514 in k1511 in body256 in analyze in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1501,NULL,3,t0,t1,t2);}
/* batch-driver.scm: 156  ##sys#read */
((C_proc4)C_retrieve_symbol_proc(lf[54]))(4,*((C_word*)lf[54]+1),t1,t2,((C_word*)t0)[2]);}

/* end-time in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1472(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1472,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=*((C_word*)lf[31]+1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1479,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t4,lf[53],t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1477 in end-time in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1482,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k1480 in k1477 in end-time in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,lf[52],((C_word*)t0)[3]);}

/* k1483 in k1480 in k1477 in end-time in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1488,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fudge(C_fix(6));
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[42]+1)))(4,*((C_word*)lf[42]+1),t2,t4,((C_word*)t0)[3]);}

/* k1486 in k1483 in k1480 in k1477 in end-time in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* begin-time in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static C_word C_fcall f_1462(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t1=(C_word)C_fudge(C_fix(6));
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1432(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1432,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1438,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1438(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1438(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1438,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1452,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 145  option-arg */
f_1078(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k1450 in loop in collect-options in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1456,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 145  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1438(t4,t2,t3);}

/* k1454 in k1450 in loop in collect-options in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1352(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1352,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1362,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 136  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1393,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1401,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 138  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1417,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1421,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 139  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 140  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k1419 in arg-val in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 139  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1415 in arg-val in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1362(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k1399 in arg-val in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 138  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1391 in arg-val in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1362(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k1360 in arg-val in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* batch-driver.scm: 141  quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[50],((C_word*)t0)[2]);}}

/* infohook in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1303,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1307,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[49]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1349,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_1349 in infohook in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1349,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k1305 in infohook in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1310,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[48],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_1313(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_1313(t5,C_SCHEME_FALSE);}}

/* k1311 in k1305 in infohook in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1313,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1324,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm: 128  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t4,C_retrieve(lf[45]),t5);}
else{
t2=((C_word*)t0)[3];
f_1310(2,t2,C_SCHEME_UNDEFINED);}}

/* k1326 in k1311 in k1305 in infohook in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 127  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[46]))(5,*((C_word*)lf[46]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1322 in k1311 in k1305 in infohook in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 124  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[3],C_retrieve(lf[45]),((C_word*)t0)[2],t1);}

/* k1308 in k1305 in infohook in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1268(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1268,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1275,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 118  print-header */
t6=((C_word*)t0)[2];
f_1198(t6,t5,t2,t3);}

/* k1273 in print-expr in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1275,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1280,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1280(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop169 in k1273 in print-expr in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1280(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1280,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1290,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1288 in loop169 in k1273 in print-expr in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1280(t3,((C_word*)t0)[2],t2);}

/* print-db in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1244(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1244,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1251,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 113  print-header */
t7=((C_word*)t0)[2];
f_1198(t7,t6,t2,t3);}

/* k1249 in print-db in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1251,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[31]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1254,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t3,lf[43],t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1252 in k1249 in print-db in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1257,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[42]+1)))(4,*((C_word*)lf[42]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1255 in k1252 in k1249 in print-db in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[2]);}

/* k1258 in k1255 in k1252 in k1249 in print-db in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1261 in k1258 in k1255 in k1252 in k1249 in print-db in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 115  display-analysis-database */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1222(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1222,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1229,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 107  print-header */
t6=((C_word*)t0)[2];
f_1198(t6,t5,t2,t3);}

/* k1227 in print-node in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1229,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 109  dump-nodes */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1242,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 110  build-expression-tree */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1240 in k1227 in print-node in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 110  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t1);}

/* print-header in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1198(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1198,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1202,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 100  dribble */
t5=((C_word*)t0)[2];
f_1183(t5,t4,lf[37],(C_word)C_a_i_list(&a,1,t2));}

/* k1200 in print-header in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1202,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[35])))){
t2=*((C_word*)lf[31]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1211,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(91),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1209 in k1200 in print-header in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1212 in k1209 in k1200 in print-header in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(93),((C_word*)t0)[2]);}

/* k1215 in k1212 in k1209 in k1200 in print-header in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1220,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1218 in k1215 in k1212 in k1209 in k1200 in print-header in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* dribble in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1183(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1183,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
t4=*((C_word*)lf[31]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1190,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t5,C_retrieve(lf[34]),t4,t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1188 in dribble in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1191 in k1188 in dribble in k1134 in k1128 in k1125 in k3673 in k1109 in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#flush-output */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* option-arg in compile-source-file in k1071 in k1067 in k1063 in k1059 in k1055 in k1050 in k1047 in k1044 in k1041 in k1038 in k1035 */
static void C_fcall f_1078(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1078,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
/* batch-driver.scm: 50   quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t1,lf[9],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
/* batch-driver.scm: 53   quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t1,lf[10],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[365] = {
{"toplevel:batch_driver_scm",(void*)C_driver_toplevel},
{"f_1037:batch_driver_scm",(void*)f_1037},
{"f_1040:batch_driver_scm",(void*)f_1040},
{"f_1043:batch_driver_scm",(void*)f_1043},
{"f_1046:batch_driver_scm",(void*)f_1046},
{"f_1049:batch_driver_scm",(void*)f_1049},
{"f_1052:batch_driver_scm",(void*)f_1052},
{"f_1057:batch_driver_scm",(void*)f_1057},
{"f_1061:batch_driver_scm",(void*)f_1061},
{"f_1065:batch_driver_scm",(void*)f_1065},
{"f_1069:batch_driver_scm",(void*)f_1069},
{"f_1073:batch_driver_scm",(void*)f_1073},
{"f_1075:batch_driver_scm",(void*)f_1075},
{"f_1111:batch_driver_scm",(void*)f_1111},
{"f_3694:batch_driver_scm",(void*)f_3694},
{"f_3683:batch_driver_scm",(void*)f_3683},
{"f_3679:batch_driver_scm",(void*)f_3679},
{"f_3675:batch_driver_scm",(void*)f_3675},
{"f_3664:batch_driver_scm",(void*)f_3664},
{"f_3642:batch_driver_scm",(void*)f_3642},
{"f_1127:batch_driver_scm",(void*)f_1127},
{"f_3636:batch_driver_scm",(void*)f_3636},
{"f_3632:batch_driver_scm",(void*)f_3632},
{"f_1130:batch_driver_scm",(void*)f_1130},
{"f_1136:batch_driver_scm",(void*)f_1136},
{"f_3613:batch_driver_scm",(void*)f_3613},
{"f_3609:batch_driver_scm",(void*)f_3609},
{"f_3605:batch_driver_scm",(void*)f_3605},
{"f_1586:batch_driver_scm",(void*)f_1586},
{"f_1589:batch_driver_scm",(void*)f_1589},
{"f_1592:batch_driver_scm",(void*)f_1592},
{"f_3590:batch_driver_scm",(void*)f_3590},
{"f_3568:batch_driver_scm",(void*)f_3568},
{"f_3586:batch_driver_scm",(void*)f_3586},
{"f_3574:batch_driver_scm",(void*)f_3574},
{"f_1596:batch_driver_scm",(void*)f_1596},
{"f_3566:batch_driver_scm",(void*)f_3566},
{"f_3550:batch_driver_scm",(void*)f_3550},
{"f_3558:batch_driver_scm",(void*)f_3558},
{"f_3562:batch_driver_scm",(void*)f_3562},
{"f_1604:batch_driver_scm",(void*)f_1604},
{"f_1607:batch_driver_scm",(void*)f_1607},
{"f_1610:batch_driver_scm",(void*)f_1610},
{"f_1613:batch_driver_scm",(void*)f_1613},
{"f_1616:batch_driver_scm",(void*)f_1616},
{"f_1619:batch_driver_scm",(void*)f_1619},
{"f_1622:batch_driver_scm",(void*)f_1622},
{"f_1625:batch_driver_scm",(void*)f_1625},
{"f_1628:batch_driver_scm",(void*)f_1628},
{"f_1631:batch_driver_scm",(void*)f_1631},
{"f_1634:batch_driver_scm",(void*)f_1634},
{"f_1637:batch_driver_scm",(void*)f_1637},
{"f_3490:batch_driver_scm",(void*)f_3490},
{"f_1641:batch_driver_scm",(void*)f_1641},
{"f_3485:batch_driver_scm",(void*)f_3485},
{"f_1644:batch_driver_scm",(void*)f_1644},
{"f_1647:batch_driver_scm",(void*)f_1647},
{"f_1650:batch_driver_scm",(void*)f_1650},
{"f_1653:batch_driver_scm",(void*)f_1653},
{"f_1656:batch_driver_scm",(void*)f_1656},
{"f_1659:batch_driver_scm",(void*)f_1659},
{"f_1662:batch_driver_scm",(void*)f_1662},
{"f_1665:batch_driver_scm",(void*)f_1665},
{"f_1668:batch_driver_scm",(void*)f_1668},
{"f_1671:batch_driver_scm",(void*)f_1671},
{"f_3440:batch_driver_scm",(void*)f_3440},
{"f_1677:batch_driver_scm",(void*)f_1677},
{"f_3425:batch_driver_scm",(void*)f_3425},
{"f_3428:batch_driver_scm",(void*)f_3428},
{"f_3431:batch_driver_scm",(void*)f_3431},
{"f_1683:batch_driver_scm",(void*)f_1683},
{"f_3415:batch_driver_scm",(void*)f_3415},
{"f_3418:batch_driver_scm",(void*)f_3418},
{"f_1686:batch_driver_scm",(void*)f_1686},
{"f_1689:batch_driver_scm",(void*)f_1689},
{"f_3373:batch_driver_scm",(void*)f_3373},
{"f_1692:batch_driver_scm",(void*)f_1692},
{"f_3367:batch_driver_scm",(void*)f_3367},
{"f_1695:batch_driver_scm",(void*)f_1695},
{"f_3358:batch_driver_scm",(void*)f_3358},
{"f_1698:batch_driver_scm",(void*)f_1698},
{"f_3340:batch_driver_scm",(void*)f_3340},
{"f_3343:batch_driver_scm",(void*)f_3343},
{"f_3346:batch_driver_scm",(void*)f_3346},
{"f_3349:batch_driver_scm",(void*)f_3349},
{"f_1701:batch_driver_scm",(void*)f_1701},
{"f_3334:batch_driver_scm",(void*)f_3334},
{"f_3330:batch_driver_scm",(void*)f_3330},
{"f_1707:batch_driver_scm",(void*)f_1707},
{"f_1710:batch_driver_scm",(void*)f_1710},
{"f_3314:batch_driver_scm",(void*)f_3314},
{"f_1714:batch_driver_scm",(void*)f_1714},
{"f_1717:batch_driver_scm",(void*)f_1717},
{"f_1720:batch_driver_scm",(void*)f_1720},
{"f_1723:batch_driver_scm",(void*)f_1723},
{"f_1726:batch_driver_scm",(void*)f_1726},
{"f_3217:batch_driver_scm",(void*)f_3217},
{"f_3232:batch_driver_scm",(void*)f_3232},
{"f_3257:batch_driver_scm",(void*)f_3257},
{"f_3262:batch_driver_scm",(void*)f_3262},
{"f_3287:batch_driver_scm",(void*)f_3287},
{"f_3133:batch_driver_scm",(void*)f_3133},
{"f_3138:batch_driver_scm",(void*)f_3138},
{"f_3153:batch_driver_scm",(void*)f_3153},
{"f_3178:batch_driver_scm",(void*)f_3178},
{"f_3183:batch_driver_scm",(void*)f_3183},
{"f_3208:batch_driver_scm",(void*)f_3208},
{"f_1729:batch_driver_scm",(void*)f_1729},
{"f_3127:batch_driver_scm",(void*)f_3127},
{"f_3119:batch_driver_scm",(void*)f_3119},
{"f_3094:batch_driver_scm",(void*)f_3094},
{"f_3096:batch_driver_scm",(void*)f_3096},
{"f_3106:batch_driver_scm",(void*)f_3106},
{"f_1732:batch_driver_scm",(void*)f_1732},
{"f_1739:batch_driver_scm",(void*)f_1739},
{"f_1742:batch_driver_scm",(void*)f_1742},
{"f_1745:batch_driver_scm",(void*)f_1745},
{"f_3063:batch_driver_scm",(void*)f_3063},
{"f_3087:batch_driver_scm",(void*)f_3087},
{"f_3076:batch_driver_scm",(void*)f_3076},
{"f_1748:batch_driver_scm",(void*)f_1748},
{"f_1752:batch_driver_scm",(void*)f_1752},
{"f_1760:batch_driver_scm",(void*)f_1760},
{"f_1764:batch_driver_scm",(void*)f_1764},
{"f_3061:batch_driver_scm",(void*)f_3061},
{"f_1767:batch_driver_scm",(void*)f_1767},
{"f_3057:batch_driver_scm",(void*)f_3057},
{"f_3053:batch_driver_scm",(void*)f_3053},
{"f_3049:batch_driver_scm",(void*)f_3049},
{"f_3029:batch_driver_scm",(void*)f_3029},
{"f_3027:batch_driver_scm",(void*)f_3027},
{"f_1771:batch_driver_scm",(void*)f_1771},
{"f_1775:batch_driver_scm",(void*)f_1775},
{"f_1778:batch_driver_scm",(void*)f_1778},
{"f_3006:batch_driver_scm",(void*)f_3006},
{"f_1782:batch_driver_scm",(void*)f_1782},
{"f_2999:batch_driver_scm",(void*)f_2999},
{"f_1786:batch_driver_scm",(void*)f_1786},
{"f_2992:batch_driver_scm",(void*)f_2992},
{"f_1790:batch_driver_scm",(void*)f_1790},
{"f_2985:batch_driver_scm",(void*)f_2985},
{"f_1794:batch_driver_scm",(void*)f_1794},
{"f_2965:batch_driver_scm",(void*)f_2965},
{"f_1798:batch_driver_scm",(void*)f_1798},
{"f_1809:batch_driver_scm",(void*)f_1809},
{"f_1812:batch_driver_scm",(void*)f_1812},
{"f_1815:batch_driver_scm",(void*)f_1815},
{"f_2924:batch_driver_scm",(void*)f_2924},
{"f_1818:batch_driver_scm",(void*)f_1818},
{"f_1821:batch_driver_scm",(void*)f_1821},
{"f_1842:batch_driver_scm",(void*)f_1842},
{"f_1870:batch_driver_scm",(void*)f_1870},
{"f_1876:batch_driver_scm",(void*)f_1876},
{"f_1880:batch_driver_scm",(void*)f_1880},
{"f_1883:batch_driver_scm",(void*)f_1883},
{"f_1886:batch_driver_scm",(void*)f_1886},
{"f_1889:batch_driver_scm",(void*)f_1889},
{"f_1897:batch_driver_scm",(void*)f_1897},
{"f_1900:batch_driver_scm",(void*)f_1900},
{"f_1903:batch_driver_scm",(void*)f_1903},
{"f_2892:batch_driver_scm",(void*)f_2892},
{"f_2900:batch_driver_scm",(void*)f_2900},
{"f_1906:batch_driver_scm",(void*)f_1906},
{"f_1909:batch_driver_scm",(void*)f_1909},
{"f_2807:batch_driver_scm",(void*)f_2807},
{"f_2836:batch_driver_scm",(void*)f_2836},
{"f_2885:batch_driver_scm",(void*)f_2885},
{"f_2853:batch_driver_scm",(void*)f_2853},
{"f_2857:batch_driver_scm",(void*)f_2857},
{"f_2862:batch_driver_scm",(void*)f_2862},
{"f_2883:batch_driver_scm",(void*)f_2883},
{"f_2848:batch_driver_scm",(void*)f_2848},
{"f_2839:batch_driver_scm",(void*)f_2839},
{"f_2822:batch_driver_scm",(void*)f_2822},
{"f_2826:batch_driver_scm",(void*)f_2826},
{"f_2830:batch_driver_scm",(void*)f_2830},
{"f_2818:batch_driver_scm",(void*)f_2818},
{"f_2798:batch_driver_scm",(void*)f_2798},
{"f_2802:batch_driver_scm",(void*)f_2802},
{"f_1912:batch_driver_scm",(void*)f_1912},
{"f_1915:batch_driver_scm",(void*)f_1915},
{"f_2791:batch_driver_scm",(void*)f_2791},
{"f_2795:batch_driver_scm",(void*)f_2795},
{"f_1918:batch_driver_scm",(void*)f_1918},
{"f_1921:batch_driver_scm",(void*)f_1921},
{"f_2768:batch_driver_scm",(void*)f_2768},
{"f_2788:batch_driver_scm",(void*)f_2788},
{"f_1927:batch_driver_scm",(void*)f_1927},
{"f_2761:batch_driver_scm",(void*)f_2761},
{"f_1930:batch_driver_scm",(void*)f_1930},
{"f_1933:batch_driver_scm",(void*)f_1933},
{"f_2729:batch_driver_scm",(void*)f_2729},
{"f_2603:batch_driver_scm",(void*)f_2603},
{"f_2719:batch_driver_scm",(void*)f_2719},
{"f_2607:batch_driver_scm",(void*)f_2607},
{"f_2611:batch_driver_scm",(void*)f_2611},
{"f_2630:batch_driver_scm",(void*)f_2630},
{"f_2615:batch_driver_scm",(void*)f_2615},
{"f_1939:batch_driver_scm",(void*)f_1939},
{"f_2548:batch_driver_scm",(void*)f_2548},
{"f_2553:batch_driver_scm",(void*)f_2553},
{"f_2566:batch_driver_scm",(void*)f_2566},
{"f_2569:batch_driver_scm",(void*)f_2569},
{"f_2572:batch_driver_scm",(void*)f_2572},
{"f_2575:batch_driver_scm",(void*)f_2575},
{"f_2578:batch_driver_scm",(void*)f_2578},
{"f_1942:batch_driver_scm",(void*)f_1942},
{"f_2542:batch_driver_scm",(void*)f_2542},
{"f_1945:batch_driver_scm",(void*)f_1945},
{"f_2536:batch_driver_scm",(void*)f_2536},
{"f_1948:batch_driver_scm",(void*)f_1948},
{"f_1951:batch_driver_scm",(void*)f_1951},
{"f_2521:batch_driver_scm",(void*)f_2521},
{"f_1954:batch_driver_scm",(void*)f_1954},
{"f_1959:batch_driver_scm",(void*)f_1959},
{"f_1962:batch_driver_scm",(void*)f_1962},
{"f_1965:batch_driver_scm",(void*)f_1965},
{"f_1968:batch_driver_scm",(void*)f_1968},
{"f_2502:batch_driver_scm",(void*)f_2502},
{"f_2509:batch_driver_scm",(void*)f_2509},
{"f_1971:batch_driver_scm",(void*)f_1971},
{"f_2499:batch_driver_scm",(void*)f_2499},
{"f_2495:batch_driver_scm",(void*)f_2495},
{"f_1980:batch_driver_scm",(void*)f_1980},
{"f_1983:batch_driver_scm",(void*)f_1983},
{"f_2429:batch_driver_scm",(void*)f_2429},
{"f_2463:batch_driver_scm",(void*)f_2463},
{"f_2465:batch_driver_scm",(void*)f_2465},
{"f_2478:batch_driver_scm",(void*)f_2478},
{"f_2432:batch_driver_scm",(void*)f_2432},
{"f_2440:batch_driver_scm",(void*)f_2440},
{"f_2443:batch_driver_scm",(void*)f_2443},
{"f_2446:batch_driver_scm",(void*)f_2446},
{"f_2452:batch_driver_scm",(void*)f_2452},
{"f_2455:batch_driver_scm",(void*)f_2455},
{"f_2458:batch_driver_scm",(void*)f_2458},
{"f_1986:batch_driver_scm",(void*)f_1986},
{"f_2420:batch_driver_scm",(void*)f_2420},
{"f_2423:batch_driver_scm",(void*)f_2423},
{"f_2402:batch_driver_scm",(void*)f_2402},
{"f_2408:batch_driver_scm",(void*)f_2408},
{"f_2411:batch_driver_scm",(void*)f_2411},
{"f_2414:batch_driver_scm",(void*)f_2414},
{"f_1989:batch_driver_scm",(void*)f_1989},
{"f_2396:batch_driver_scm",(void*)f_2396},
{"f_1992:batch_driver_scm",(void*)f_1992},
{"f_2389:batch_driver_scm",(void*)f_2389},
{"f_1995:batch_driver_scm",(void*)f_1995},
{"f_2386:batch_driver_scm",(void*)f_2386},
{"f_2337:batch_driver_scm",(void*)f_2337},
{"f_2339:batch_driver_scm",(void*)f_2339},
{"f_2382:batch_driver_scm",(void*)f_2382},
{"f_2378:batch_driver_scm",(void*)f_2378},
{"f_2352:batch_driver_scm",(void*)f_2352},
{"f_2368:batch_driver_scm",(void*)f_2368},
{"f_2371:batch_driver_scm",(void*)f_2371},
{"f_2355:batch_driver_scm",(void*)f_2355},
{"f_1998:batch_driver_scm",(void*)f_1998},
{"f_2001:batch_driver_scm",(void*)f_2001},
{"f_2307:batch_driver_scm",(void*)f_2307},
{"f_2320:batch_driver_scm",(void*)f_2320},
{"f_2323:batch_driver_scm",(void*)f_2323},
{"f_2004:batch_driver_scm",(void*)f_2004},
{"f_2010:batch_driver_scm",(void*)f_2010},
{"f_2016:batch_driver_scm",(void*)f_2016},
{"f_2019:batch_driver_scm",(void*)f_2019},
{"f_2022:batch_driver_scm",(void*)f_2022},
{"f_2027:batch_driver_scm",(void*)f_2027},
{"f_2034:batch_driver_scm",(void*)f_2034},
{"f_2262:batch_driver_scm",(void*)f_2262},
{"f_2265:batch_driver_scm",(void*)f_2265},
{"f_2037:batch_driver_scm",(void*)f_2037},
{"f_2041:batch_driver_scm",(void*)f_2041},
{"f_2044:batch_driver_scm",(void*)f_2044},
{"f_2047:batch_driver_scm",(void*)f_2047},
{"f_2139:batch_driver_scm",(void*)f_2139},
{"f_2250:batch_driver_scm",(void*)f_2250},
{"f_2142:batch_driver_scm",(void*)f_2142},
{"f_2148:batch_driver_scm",(void*)f_2148},
{"f_2151:batch_driver_scm",(void*)f_2151},
{"f_2154:batch_driver_scm",(void*)f_2154},
{"f_2233:batch_driver_scm",(void*)f_2233},
{"f_2157:batch_driver_scm",(void*)f_2157},
{"f_2160:batch_driver_scm",(void*)f_2160},
{"f_2163:batch_driver_scm",(void*)f_2163},
{"f_2177:batch_driver_scm",(void*)f_2177},
{"f_2181:batch_driver_scm",(void*)f_2181},
{"f_2187:batch_driver_scm",(void*)f_2187},
{"f_2190:batch_driver_scm",(void*)f_2190},
{"f_2193:batch_driver_scm",(void*)f_2193},
{"f_2196:batch_driver_scm",(void*)f_2196},
{"f_2199:batch_driver_scm",(void*)f_2199},
{"f_2218:batch_driver_scm",(void*)f_2218},
{"f_2202:batch_driver_scm",(void*)f_2202},
{"f_2205:batch_driver_scm",(void*)f_2205},
{"f_2171:batch_driver_scm",(void*)f_2171},
{"f_2053:batch_driver_scm",(void*)f_2053},
{"f_2067:batch_driver_scm",(void*)f_2067},
{"f_2071:batch_driver_scm",(void*)f_2071},
{"f_2074:batch_driver_scm",(void*)f_2074},
{"f_2093:batch_driver_scm",(void*)f_2093},
{"f_2110:batch_driver_scm",(void*)f_2110},
{"f_2113:batch_driver_scm",(void*)f_2113},
{"f_2119:batch_driver_scm",(void*)f_2119},
{"f_2122:batch_driver_scm",(void*)f_2122},
{"f_2061:batch_driver_scm",(void*)f_2061},
{"f_1861:batch_driver_scm",(void*)f_1861},
{"f_1854:batch_driver_scm",(void*)f_1854},
{"f_1830:batch_driver_scm",(void*)f_1830},
{"f_1507:batch_driver_scm",(void*)f_1507},
{"f_1537:batch_driver_scm",(void*)f_1537},
{"f_1532:batch_driver_scm",(void*)f_1532},
{"f_1509:batch_driver_scm",(void*)f_1509},
{"f_1513:batch_driver_scm",(void*)f_1513},
{"f_1527:batch_driver_scm",(void*)f_1527},
{"f_1521:batch_driver_scm",(void*)f_1521},
{"f_1516:batch_driver_scm",(void*)f_1516},
{"f_1501:batch_driver_scm",(void*)f_1501},
{"f_1472:batch_driver_scm",(void*)f_1472},
{"f_1479:batch_driver_scm",(void*)f_1479},
{"f_1482:batch_driver_scm",(void*)f_1482},
{"f_1485:batch_driver_scm",(void*)f_1485},
{"f_1488:batch_driver_scm",(void*)f_1488},
{"f_1462:batch_driver_scm",(void*)f_1462},
{"f_1432:batch_driver_scm",(void*)f_1432},
{"f_1438:batch_driver_scm",(void*)f_1438},
{"f_1452:batch_driver_scm",(void*)f_1452},
{"f_1456:batch_driver_scm",(void*)f_1456},
{"f_1352:batch_driver_scm",(void*)f_1352},
{"f_1421:batch_driver_scm",(void*)f_1421},
{"f_1417:batch_driver_scm",(void*)f_1417},
{"f_1401:batch_driver_scm",(void*)f_1401},
{"f_1393:batch_driver_scm",(void*)f_1393},
{"f_1362:batch_driver_scm",(void*)f_1362},
{"f_1303:batch_driver_scm",(void*)f_1303},
{"f_1349:batch_driver_scm",(void*)f_1349},
{"f_1307:batch_driver_scm",(void*)f_1307},
{"f_1313:batch_driver_scm",(void*)f_1313},
{"f_1328:batch_driver_scm",(void*)f_1328},
{"f_1324:batch_driver_scm",(void*)f_1324},
{"f_1310:batch_driver_scm",(void*)f_1310},
{"f_1268:batch_driver_scm",(void*)f_1268},
{"f_1275:batch_driver_scm",(void*)f_1275},
{"f_1280:batch_driver_scm",(void*)f_1280},
{"f_1290:batch_driver_scm",(void*)f_1290},
{"f_1244:batch_driver_scm",(void*)f_1244},
{"f_1251:batch_driver_scm",(void*)f_1251},
{"f_1254:batch_driver_scm",(void*)f_1254},
{"f_1257:batch_driver_scm",(void*)f_1257},
{"f_1260:batch_driver_scm",(void*)f_1260},
{"f_1263:batch_driver_scm",(void*)f_1263},
{"f_1222:batch_driver_scm",(void*)f_1222},
{"f_1229:batch_driver_scm",(void*)f_1229},
{"f_1242:batch_driver_scm",(void*)f_1242},
{"f_1198:batch_driver_scm",(void*)f_1198},
{"f_1202:batch_driver_scm",(void*)f_1202},
{"f_1211:batch_driver_scm",(void*)f_1211},
{"f_1214:batch_driver_scm",(void*)f_1214},
{"f_1217:batch_driver_scm",(void*)f_1217},
{"f_1220:batch_driver_scm",(void*)f_1220},
{"f_1183:batch_driver_scm",(void*)f_1183},
{"f_1190:batch_driver_scm",(void*)f_1190},
{"f_1193:batch_driver_scm",(void*)f_1193},
{"f_1078:batch_driver_scm",(void*)f_1078},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
