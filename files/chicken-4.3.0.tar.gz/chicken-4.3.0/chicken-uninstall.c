/* Generated from chicken-uninstall.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: chicken-uninstall.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -ignore-repository -output-file chicken-uninstall.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 posix data_structures utils ports regex srfi_13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[54];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_291)
static void C_ccall f_291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_294)
static void C_ccall f_294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_297)
static void C_ccall f_297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_300)
static void C_ccall f_300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_303)
static void C_ccall f_303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_306)
static void C_ccall f_306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_309)
static void C_ccall f_309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_312)
static void C_ccall f_312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_315)
static void C_ccall f_315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_318)
static void C_ccall f_318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_321)
static void C_ccall f_321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_324)
static void C_ccall f_324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_327)
static void C_ccall f_327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_330)
static void C_ccall f_330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_333)
static void C_ccall f_333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_735)
static void C_ccall f_735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_532)
static void C_fcall f_532(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_567)
static void C_fcall f_567(C_word t0,C_word t1) C_noret;
C_noret_decl(f_628)
static void C_fcall f_628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_675)
static void C_ccall f_675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_637)
static void C_ccall f_637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_671)
static void C_ccall f_671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_660)
static void C_ccall f_660(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_654)
static void C_ccall f_654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_650)
static void C_ccall f_650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_615)
static void C_ccall f_615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_589)
static void C_ccall f_589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_582)
static void C_ccall f_582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_546)
static void C_ccall f_546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_369)
static void C_ccall f_369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_365)
static void C_ccall f_365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_361)
static void C_ccall f_361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_340)
static void C_ccall f_340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_353)
static void C_ccall f_353(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_351)
static void C_ccall f_351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_347)
static void C_ccall f_347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_462)
static void C_ccall f_462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_416)
static void C_ccall f_416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_446)
static void C_ccall f_446(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_446)
static void C_ccall f_446r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_452)
static void C_ccall f_452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_422)
static void C_ccall f_422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_440)
static void C_ccall f_440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_438)
static void C_ccall f_438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_434)
static void C_ccall f_434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_430)
static void C_ccall f_430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_375)
static void C_ccall f_375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_387)
static void C_ccall f_387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_482)
static void C_fcall f_482(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_495)
static void C_ccall f_495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_725)
static void C_ccall f_725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_728)
static void C_ccall f_728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_516)
static void C_fcall f_516(C_word t0,C_word t1) C_noret;
C_noret_decl(f_520)
static void C_ccall f_520(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_532)
static void C_fcall trf_532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_532(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_532(t0,t1,t2,t3);}

C_noret_decl(trf_567)
static void C_fcall trf_567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_567(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_567(t0,t1);}

C_noret_decl(trf_628)
static void C_fcall trf_628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_628(t0,t1);}

C_noret_decl(trf_482)
static void C_fcall trf_482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_482(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_482(t0,t1,t2);}

C_noret_decl(trf_516)
static void C_fcall trf_516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_516(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_516(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(332)){
C_save(t1);
C_rereclaim2(332*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,54);
lf[2]=C_h_intern(&lf[2],4,"exit");
lf[3]=C_h_intern(&lf[3],5,"print");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\001#usage: chicken-uninstall [OPTION | PATTERN] ...\012\012  -h   -help              "
"      show this message and exit\012  -v   -version                 show version an"
"d exit\012       -force                   don\047t ask, delete whatever matches\012  -s  "
" -sudo                    use sudo(1) for deleting files");
lf[5]=C_h_intern(&lf[5],25,"\003sysimplicit-exit-handler");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\022nothing to remove.");
lf[7]=C_h_intern(&lf[7],26,"setup-api#remove-extension");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\011removing ");
lf[9]=C_h_intern(&lf[9],7,"aborted");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\010aborted.");
lf[11]=C_h_intern(&lf[11],6,"signal");
lf[12]=C_h_intern(&lf[12],20,"setup-api#yes-or-no\077");
lf[13]=C_h_intern(&lf[13],8,"\000default");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[15]=C_h_intern(&lf[15],18,"string-concatenate");
lf[16]=C_h_intern(&lf[16],6,"append");
lf[17]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000+About to delete the following extensions:\012\012\376\377\016");
lf[18]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030\012Do you want to proceed\077\376\377\016");
lf[19]=C_h_intern(&lf[19],13,"string-append");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[22]=C_h_intern(&lf[22],7,"\003sysmap");
lf[23]=C_h_intern(&lf[23],22,"with-exception-handler");
lf[24]=C_h_intern(&lf[24],30,"call-with-current-continuation");
lf[25]=C_h_intern(&lf[25],17,"delete-duplicates");
lf[26]=C_h_intern(&lf[26],8,"string=\077");
lf[27]=C_h_intern(&lf[27],11,"concatenate");
lf[28]=C_h_intern(&lf[28],4,"grep");
lf[29]=C_h_intern(&lf[29],13,"pathname-file");
lf[30]=C_h_intern(&lf[30],4,"glob");
lf[31]=C_h_intern(&lf[31],13,"make-pathname");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[34]=C_h_intern(&lf[34],15,"repository-path");
lf[35]=C_h_intern(&lf[35],7,"reverse");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[39]=C_h_intern(&lf[39],15,"chicken-version");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[43]=C_h_intern(&lf[43],22,"setup-api#sudo-install");
lf[44]=C_h_intern(&lf[44],17,"lset-intersection");
lf[45]=C_h_intern(&lf[45],3,"eq\077");
lf[46]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\377\016");
lf[47]=C_h_intern(&lf[47],16,"\003sysstring->list");
lf[48]=C_h_intern(&lf[48],9,"substring");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[51]=C_h_intern(&lf[51],22,"command-line-arguments");
lf[52]=C_h_intern(&lf[52],11,"\003sysrequire");
lf[53]=C_h_intern(&lf[53],9,"setup-api");
C_register_lf2(lf,54,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_291,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k289 */
static void C_ccall f_291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k292 in k289 */
static void C_ccall f_294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_297,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k295 in k292 in k289 */
static void C_ccall f_297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k298 in k295 in k292 in k289 */
static void C_ccall f_300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[52]))(3,*((C_word*)lf[52]+1),t2,lf[53]);}

/* k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_333,2,t0,t1);}
t2=lf[0] /* main#*force* */ =C_SCHEME_FALSE;;
t3=C_mutate(&lf[1] /* (set! main#usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_516,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_735,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 117  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[51]))(2,*((C_word*)lf[51]+1),t5);}

/* k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_735,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_532,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_532(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_fcall f_532(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_532,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_546,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* chicken-uninstall.scm: 92   usage */
f_516(t4,C_fix(1));}
else{
/* chicken-uninstall.scm: 92   reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),t4,t3);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[36]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_567,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_567(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[49]);
t8=t6;
f_567(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[50])));}}}

/* k565 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_fcall f_567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_567,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-uninstall.scm: 97   usage */
f_516(((C_word*)t0)[6],C_fix(0));}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[37]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[38]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_582,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_589,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 99   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[39]))(2,*((C_word*)lf[39]+1),t5);}
else{
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[40]))){
t4=lf[0] /* main#*force* */ =C_SCHEME_TRUE;;
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-uninstall.scm: 103  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_532(t6,((C_word*)t0)[6],t5,((C_word*)t0)[2]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[41]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[42]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-uninstall.scm: 105  setup-api#sudo-install */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t6,C_SCHEME_TRUE);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_628,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_string_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_positivep(t7))){
t8=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t9=t6;
f_628(t9,(C_word)C_eqp(C_make_character(45),t8));}
else{
t8=t6;
f_628(t8,C_SCHEME_FALSE);}}}}}}

/* k626 in k565 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_fcall f_628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_628,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_675,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 110  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
/* chicken-uninstall.scm: 114  usage */
f_516(((C_word*)t0)[4],C_fix(1));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[3]);
/* chicken-uninstall.scm: 115  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_532(t4,((C_word*)t0)[4],t2,t3);}}

/* k673 in k626 in k565 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k635 in k626 in k565 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_671,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-uninstall.scm: 111  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),t2,*((C_word*)lf[45]+1),lf[46],t1);}

/* k669 in k635 in k626 in k565 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_671,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_650,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_654,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_660,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
/* chicken-uninstall.scm: 113  usage */
f_516(((C_word*)t0)[5],C_fix(1));}}

/* a659 in k669 in k635 in k626 in k565 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_660(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_660,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k652 in k669 in k635 in k626 in k565 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-uninstall.scm: 112  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),((C_word*)t0)[2],t1,t2);}

/* k648 in k669 in k635 in k626 in k565 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 112  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_532(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k613 in k565 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-uninstall.scm: 106  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_532(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k587 in k565 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 99   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),((C_word*)t0)[2],t1);}

/* k580 in k565 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 100  exit */
((C_proc3)C_retrieve_symbol_proc(lf[2]))(3,*((C_word*)lf[2]+1),((C_word*)t0)[2],C_fix(0));}

/* k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_546,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_462,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_340,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_361,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_365,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_369,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 42   repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[34]))(2,*((C_word*)lf[34]+1),t7);}

/* k367 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 42   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),((C_word*)t0)[2],t1,lf[32],lf[33]);}

/* k363 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 42   glob */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),((C_word*)t0)[2],t1);}

/* k359 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[29]),t1);}

/* k338 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_347,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_351,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_353,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a352 in k338 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_353(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_353,3,t0,t1,t2);}
/* grep */
((C_proc4)C_retrieve_symbol_proc(lf[28]))(4,*((C_word*)lf[28]+1),t1,t2,((C_word*)t0)[2]);}

/* k349 in k338 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 44   concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),((C_word*)t0)[2],t1);}

/* k345 in k338 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 43   delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1,*((C_word*)lf[26]+1));}

/* k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_462,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-uninstall.scm: 67   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),((C_word*)t0)[3],lf[6]);}
else{
t2=C_retrieve2(lf[0],"main#*force*");
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_477,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_477(2,t4,t2);}
else{
t4=(C_word)C_i_equalp(t1,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_477(2,t5,t4);}
else{
t5=t1;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_387,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[24]+1)))(3,*((C_word*)lf[24]+1),t6,t7);}}}}

/* a388 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_389,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_395,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_416,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),t1,t3,t4);}

/* a415 in a388 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_422,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_446,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a445 in a415 in a388 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_446(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_446r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_446r(t0,t1,t2);}}

static void C_ccall f_446r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_452,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k169172 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a451 in a445 in a415 in a388 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_452,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a421 in a415 in a388 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_430,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_434,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_438,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_440,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a439 in a421 in a415 in a388 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_440,3,t0,t1,t2);}
/* string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[19]+1)))(5,*((C_word*)lf[19]+1),t1,lf[20],t2,lf[21]);}

/* k436 in a421 in a415 in a388 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 58   append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[16]+1)))(5,*((C_word*)lf[16]+1),((C_word*)t0)[2],lf[17],t1,lf[18]);}

/* k432 in a421 in a415 in a388 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 57   string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),((C_word*)t0)[2],t1);}

/* k428 in a421 in a415 in a388 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 56   setup-api#yes-or-no? */
((C_proc5)C_retrieve_symbol_proc(lf[12]))(5,*((C_word*)lf[12]+1),((C_word*)t0)[2],t1,lf[13],lf[14]);}

/* a394 in a388 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_395,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k169172 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a400 in a394 in a388 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_401,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[9]);
if(C_truep(t2)){
t3=t1;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_375,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 48   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t4,lf[10]);}
else{
/* chicken-uninstall.scm: 55   signal */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t1,((C_word*)t0)[2]);}}

/* k373 in a400 in a394 in a388 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 49   exit */
((C_proc3)C_retrieve_symbol_proc(lf[2]))(3,*((C_word*)lf[2]+1),((C_word*)t0)[2],C_fix(1));}

/* k385 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k475 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_477,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_482,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_482(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop203 in k475 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_fcall f_482(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_482,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_495,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-uninstall.scm: 71   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t4,lf[8],t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k493 in loop203 in k475 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_498,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-uninstall.scm: 72   setup-api#remove-extension */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k496 in k493 in loop203 in k475 in k460 in k544 in loop in k733 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_482(t3,((C_word*)t0)[2],t2);}

/* k723 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_731,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),t3);}

/* k729 in k723 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k726 in k723 in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#usage in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_fcall f_516(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_516,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_520,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-uninstall.scm: 76   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t3,lf[4]);}

/* k518 in main#usage in k331 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 */
static void C_ccall f_520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 85   exit */
((C_proc3)C_retrieve_symbol_proc(lf[2]))(3,*((C_word*)lf[2]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[61] = {
{"toplevel:chicken_uninstall_scm",(void*)C_toplevel},
{"f_291:chicken_uninstall_scm",(void*)f_291},
{"f_294:chicken_uninstall_scm",(void*)f_294},
{"f_297:chicken_uninstall_scm",(void*)f_297},
{"f_300:chicken_uninstall_scm",(void*)f_300},
{"f_303:chicken_uninstall_scm",(void*)f_303},
{"f_306:chicken_uninstall_scm",(void*)f_306},
{"f_309:chicken_uninstall_scm",(void*)f_309},
{"f_312:chicken_uninstall_scm",(void*)f_312},
{"f_315:chicken_uninstall_scm",(void*)f_315},
{"f_318:chicken_uninstall_scm",(void*)f_318},
{"f_321:chicken_uninstall_scm",(void*)f_321},
{"f_324:chicken_uninstall_scm",(void*)f_324},
{"f_327:chicken_uninstall_scm",(void*)f_327},
{"f_330:chicken_uninstall_scm",(void*)f_330},
{"f_333:chicken_uninstall_scm",(void*)f_333},
{"f_735:chicken_uninstall_scm",(void*)f_735},
{"f_532:chicken_uninstall_scm",(void*)f_532},
{"f_567:chicken_uninstall_scm",(void*)f_567},
{"f_628:chicken_uninstall_scm",(void*)f_628},
{"f_675:chicken_uninstall_scm",(void*)f_675},
{"f_637:chicken_uninstall_scm",(void*)f_637},
{"f_671:chicken_uninstall_scm",(void*)f_671},
{"f_660:chicken_uninstall_scm",(void*)f_660},
{"f_654:chicken_uninstall_scm",(void*)f_654},
{"f_650:chicken_uninstall_scm",(void*)f_650},
{"f_615:chicken_uninstall_scm",(void*)f_615},
{"f_589:chicken_uninstall_scm",(void*)f_589},
{"f_582:chicken_uninstall_scm",(void*)f_582},
{"f_546:chicken_uninstall_scm",(void*)f_546},
{"f_369:chicken_uninstall_scm",(void*)f_369},
{"f_365:chicken_uninstall_scm",(void*)f_365},
{"f_361:chicken_uninstall_scm",(void*)f_361},
{"f_340:chicken_uninstall_scm",(void*)f_340},
{"f_353:chicken_uninstall_scm",(void*)f_353},
{"f_351:chicken_uninstall_scm",(void*)f_351},
{"f_347:chicken_uninstall_scm",(void*)f_347},
{"f_462:chicken_uninstall_scm",(void*)f_462},
{"f_389:chicken_uninstall_scm",(void*)f_389},
{"f_416:chicken_uninstall_scm",(void*)f_416},
{"f_446:chicken_uninstall_scm",(void*)f_446},
{"f_452:chicken_uninstall_scm",(void*)f_452},
{"f_422:chicken_uninstall_scm",(void*)f_422},
{"f_440:chicken_uninstall_scm",(void*)f_440},
{"f_438:chicken_uninstall_scm",(void*)f_438},
{"f_434:chicken_uninstall_scm",(void*)f_434},
{"f_430:chicken_uninstall_scm",(void*)f_430},
{"f_395:chicken_uninstall_scm",(void*)f_395},
{"f_401:chicken_uninstall_scm",(void*)f_401},
{"f_375:chicken_uninstall_scm",(void*)f_375},
{"f_387:chicken_uninstall_scm",(void*)f_387},
{"f_477:chicken_uninstall_scm",(void*)f_477},
{"f_482:chicken_uninstall_scm",(void*)f_482},
{"f_495:chicken_uninstall_scm",(void*)f_495},
{"f_498:chicken_uninstall_scm",(void*)f_498},
{"f_725:chicken_uninstall_scm",(void*)f_725},
{"f_731:chicken_uninstall_scm",(void*)f_731},
{"f_728:chicken_uninstall_scm",(void*)f_728},
{"f_516:chicken_uninstall_scm",(void*)f_516},
{"f_520:chicken_uninstall_scm",(void*)f_520},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
