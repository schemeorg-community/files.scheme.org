/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:03
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: lolevel.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file ulolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[126];
static double C_possibly_force_alignment;


/* from k2673 */
static C_word C_fcall stub829(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub829(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from f_2421 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static C_word C_fcall stub719(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub719(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k2990 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub596(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub596(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_ret:
#undef return

return C_r;}

/* from k3000 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub589(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub589(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_ret:
#undef return

return C_r;}

/* from k3010 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub582(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub582(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3020 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub575(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub575(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3030 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub569(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub569(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_ret:
#undef return

return C_r;}

/* from k3040 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub563(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub563(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_ret:
#undef return

return C_r;}

/* from k3050 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub557(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub557(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((signed char *)p));
C_ret:
#undef return

return C_r;}

/* from k3060 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub551(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub551(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_ret:
#undef return

return C_r;}

/* from k1979 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub544(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub544(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1969 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub536(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub536(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1959 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub528(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub528(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1949 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub520(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub520(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1939 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub512(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub512(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1929 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub504(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub504(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1919 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub496(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub496(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1909 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub488(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub488(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from align */
static C_word C_fcall stub405(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub405(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k1735 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub396(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub396(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

/* from object->pointer in k1045 in k1042 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub382(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub382(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k1660 */
static C_word C_fcall stub353(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub353(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from allocate in k1045 in k1042 */
static C_word C_fcall stub348(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub348(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1244 */
static C_word C_fcall stub147(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub147(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1231 */
static C_word C_fcall stub131(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub131(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1218 */
static C_word C_fcall stub115(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub115(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1202 */
static C_word C_fcall stub99(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub99(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1077)
static void C_fcall f_1077(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1102)
static void C_ccall f_1102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_fcall f_2776(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_fcall f_2847(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_fcall f_2689(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_fcall f_2723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2597)
static void C_fcall f_2597(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2642)
static void C_fcall f_2642(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2431)
static void C_fcall f_2431(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_fcall f_2445(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_fcall f_2470(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_fcall f_2488(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2320)
static void C_ccall f_2320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_fcall f_2325(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2335)
static void C_ccall f_2335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_fcall f_2351(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_fcall f_2366(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2387)
static void C_ccall f_2387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static C_word C_fcall f_2284(C_word t0,C_word t1);
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1151)
static void C_fcall f_1151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2072)
static void C_ccall f_2072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1727)
static void C_ccall f_1727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1579)
static void C_fcall f_1579(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_fcall f_1624(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1252)
static void C_ccall f_1252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1252)
static void C_ccall f_1252r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1513)
static void C_fcall f_1513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_fcall f_1508(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1503)
static void C_fcall f_1503(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1254)
static void C_fcall f_1254(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_fcall f_1320(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1482)
static void C_ccall f_1482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1398)
static void C_ccall f_1398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_fcall f_1285(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1292)
static void C_fcall f_1292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1269)
static void C_fcall f_1269(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1263)
static void C_fcall f_1263(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1257)
static void C_fcall f_1257(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static void C_fcall f_1247(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1122)
static void C_fcall f_1122(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1049)
static void C_fcall f_1049(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_1077)
static void C_fcall trf_1077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1077(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1077(t0,t1,t2);}

C_noret_decl(trf_2776)
static void C_fcall trf_2776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2776(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2776(t0,t1,t2);}

C_noret_decl(trf_2847)
static void C_fcall trf_2847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2847(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2847(t0,t1,t2);}

C_noret_decl(trf_2689)
static void C_fcall trf_2689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2689(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2689(t0,t1,t2);}

C_noret_decl(trf_2723)
static void C_fcall trf_2723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2723(t0,t1,t2);}

C_noret_decl(trf_2597)
static void C_fcall trf_2597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2597(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2597(t0,t1,t2);}

C_noret_decl(trf_2642)
static void C_fcall trf_2642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2642(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2642(t0,t1,t2);}

C_noret_decl(trf_2431)
static void C_fcall trf_2431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2431(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2431(t0,t1);}

C_noret_decl(trf_2445)
static void C_fcall trf_2445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2445(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2445(t0,t1,t2);}

C_noret_decl(trf_2470)
static void C_fcall trf_2470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2470(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2470(t0,t1);}

C_noret_decl(trf_2488)
static void C_fcall trf_2488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2488(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2488(t0,t1,t2);}

C_noret_decl(trf_2325)
static void C_fcall trf_2325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2325(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2325(t0,t1,t2);}

C_noret_decl(trf_2351)
static void C_fcall trf_2351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2351(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2351(t0,t1);}

C_noret_decl(trf_2366)
static void C_fcall trf_2366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2366(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2366(t0,t1,t2);}

C_noret_decl(trf_1151)
static void C_fcall trf_1151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1151(t0,t1);}

C_noret_decl(trf_1579)
static void C_fcall trf_1579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1579(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1579(t0,t1,t2);}

C_noret_decl(trf_1624)
static void C_fcall trf_1624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1624(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1624(t0,t1,t2);}

C_noret_decl(trf_1513)
static void C_fcall trf_1513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1513(t0,t1);}

C_noret_decl(trf_1508)
static void C_fcall trf_1508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1508(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1508(t0,t1,t2);}

C_noret_decl(trf_1503)
static void C_fcall trf_1503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1503(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1503(t0,t1,t2,t3);}

C_noret_decl(trf_1254)
static void C_fcall trf_1254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1254(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1254(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1320)
static void C_fcall trf_1320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1320(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1320(t0,t1,t2,t3);}

C_noret_decl(trf_1285)
static void C_fcall trf_1285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1285(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1285(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1292)
static void C_fcall trf_1292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1292(t0,t1);}

C_noret_decl(trf_1269)
static void C_fcall trf_1269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1269(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1269(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1263)
static void C_fcall trf_1263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1263(t0,t1,t2);}

C_noret_decl(trf_1257)
static void C_fcall trf_1257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1257(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1257(t0,t1);}

C_noret_decl(trf_1247)
static void C_fcall trf_1247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1247(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1247(t0,t1);}

C_noret_decl(trf_1122)
static void C_fcall trf_1122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1122(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1122(t0,t1,t2);}

C_noret_decl(trf_1049)
static void C_fcall trf_1049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1049(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1049(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1237)){
C_save(t1);
C_rereclaim2(1237*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,126);
lf[1]=C_h_intern(&lf[1],14,"\003syserror-hook");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],11,"\000type-error");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a structure");
lf[6]=C_h_intern(&lf[6],17,"\003syscheck-pointer");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[8]=C_h_intern(&lf[8],12,"move-memory!");
lf[9]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[10]=C_h_intern(&lf[10],9,"\003syserror");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[13]=C_h_intern(&lf[13],15,"\003sysbytevector\077");
lf[14]=C_h_intern(&lf[14],11,"object-copy");
lf[15]=C_h_intern(&lf[15],15,"\003sysmake-vector");
lf[16]=C_h_intern(&lf[16],8,"allocate");
lf[17]=C_h_intern(&lf[17],4,"free");
lf[18]=C_h_intern(&lf[18],8,"pointer\077");
lf[19]=C_h_intern(&lf[19],13,"pointer-like\077");
lf[20]=C_h_intern(&lf[20],16,"address->pointer");
lf[21]=C_h_intern(&lf[21],20,"\003sysaddress->pointer");
lf[22]=C_h_intern(&lf[22],17,"\003syscheck-integer");
lf[23]=C_h_intern(&lf[23],16,"pointer->address");
lf[24]=C_h_intern(&lf[24],20,"\003syspointer->address");
lf[25]=C_h_intern(&lf[25],17,"\003syscheck-special");
lf[26]=C_h_intern(&lf[26],12,"null-pointer");
lf[27]=C_h_intern(&lf[27],16,"\003sysnull-pointer");
lf[28]=C_h_intern(&lf[28],13,"null-pointer\077");
lf[29]=C_h_intern(&lf[29],15,"object->pointer");
lf[30]=C_h_intern(&lf[30],15,"pointer->object");
lf[31]=C_h_intern(&lf[31],9,"pointer=\077");
lf[32]=C_h_intern(&lf[32],14,"pointer-offset");
lf[33]=C_h_intern(&lf[33],13,"align-to-word");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a pointer or integer");
lf[35]=C_h_intern(&lf[35],11,"tag-pointer");
lf[36]=C_h_intern(&lf[36],23,"\003sysmake-tagged-pointer");
lf[37]=C_h_intern(&lf[37],15,"tagged-pointer\077");
lf[38]=C_h_intern(&lf[38],11,"pointer-tag");
lf[39]=C_h_intern(&lf[39],13,"make-locative");
lf[40]=C_h_intern(&lf[40],17,"\003sysmake-locative");
lf[41]=C_h_intern(&lf[41],18,"make-weak-locative");
lf[42]=C_h_intern(&lf[42],13,"locative-set!");
lf[43]=C_h_intern(&lf[43],12,"locative-ref");
lf[44]=C_h_intern(&lf[44],16,"locative->object");
lf[45]=C_h_intern(&lf[45],9,"locative\077");
lf[46]=C_h_intern(&lf[46],15,"pointer-u8-set!");
lf[47]=C_h_intern(&lf[47],15,"pointer-s8-set!");
lf[48]=C_h_intern(&lf[48],16,"pointer-u16-set!");
lf[49]=C_h_intern(&lf[49],16,"pointer-s16-set!");
lf[50]=C_h_intern(&lf[50],16,"pointer-u32-set!");
lf[51]=C_h_intern(&lf[51],16,"pointer-s32-set!");
lf[52]=C_h_intern(&lf[52],16,"pointer-f32-set!");
lf[53]=C_h_intern(&lf[53],16,"pointer-f64-set!");
lf[54]=C_h_intern(&lf[54],14,"pointer-u8-ref");
lf[55]=C_h_intern(&lf[55],14,"pointer-s8-ref");
lf[56]=C_h_intern(&lf[56],15,"pointer-u16-ref");
lf[57]=C_h_intern(&lf[57],15,"pointer-s16-ref");
lf[58]=C_h_intern(&lf[58],15,"pointer-u32-ref");
lf[59]=C_h_intern(&lf[59],15,"pointer-s32-ref");
lf[60]=C_h_intern(&lf[60],15,"pointer-f32-ref");
lf[61]=C_h_intern(&lf[61],15,"pointer-f64-ref");
lf[62]=C_h_intern(&lf[62],8,"extended");
lf[64]=C_h_intern(&lf[64],16,"extend-procedure");
lf[65]=C_h_intern(&lf[65],19,"\003sysdecorate-lambda");
lf[66]=C_h_intern(&lf[66],17,"\003syscheck-closure");
lf[67]=C_h_intern(&lf[67],19,"extended-procedure\077");
lf[68]=C_h_intern(&lf[68],21,"\003syslambda-decoration");
lf[69]=C_h_intern(&lf[69],14,"procedure-data");
lf[70]=C_h_intern(&lf[70],19,"set-procedure-data!");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[72]=C_h_intern(&lf[72],10,"block-set!");
lf[73]=C_h_intern(&lf[73],14,"\003sysblock-set!");
lf[74]=C_h_intern(&lf[74],9,"block-ref");
lf[75]=C_h_intern(&lf[75],15,"number-of-slots");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a vector-like object");
lf[77]=C_h_intern(&lf[77],15,"number-of-bytes");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\0002cannot compute number of bytes of immediate object");
lf[79]=C_h_intern(&lf[79],20,"make-record-instance");
lf[80]=C_h_intern(&lf[80],18,"\003sysmake-structure");
lf[81]=C_h_intern(&lf[81],16,"record-instance\077");
lf[82]=C_h_intern(&lf[82],20,"record-instance-type");
lf[83]=C_h_intern(&lf[83],22,"record-instance-length");
lf[84]=C_h_intern(&lf[84],25,"record-instance-slot-set!");
lf[85]=C_h_intern(&lf[85],15,"\003syscheck-range");
lf[86]=C_h_intern(&lf[86],20,"record-instance-slot");
lf[87]=C_h_intern(&lf[87],14,"record->vector");
lf[88]=C_h_intern(&lf[88],15,"object-evicted\077");
lf[89]=C_h_intern(&lf[89],12,"object-evict");
lf[90]=C_h_intern(&lf[90],15,"hash-table-set!");
lf[91]=C_h_intern(&lf[91],19,"\003sysundefined-value");
lf[92]=C_h_intern(&lf[92],22,"hash-table-ref/default");
lf[93]=C_h_intern(&lf[93],15,"make-hash-table");
lf[94]=C_h_intern(&lf[94],3,"eq\077");
lf[95]=C_h_intern(&lf[95],24,"object-evict-to-location");
lf[96]=C_h_intern(&lf[96],24,"\003sysset-pointer-address!");
lf[97]=C_h_intern(&lf[97],6,"signal");
lf[98]=C_h_intern(&lf[98],24,"make-composite-condition");
lf[99]=C_h_intern(&lf[99],23,"make-property-condition");
lf[100]=C_h_intern(&lf[100],5,"evict");
lf[101]=C_h_intern(&lf[101],5,"limit");
lf[102]=C_h_intern(&lf[102],3,"exn");
lf[103]=C_h_intern(&lf[103],8,"location");
lf[104]=C_h_intern(&lf[104],7,"message");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000$cannot evict object - limit exceeded");
lf[106]=C_h_intern(&lf[106],9,"arguments");
lf[107]=C_h_intern(&lf[107],14,"object-release");
lf[108]=C_h_intern(&lf[108],11,"object-size");
lf[109]=C_h_intern(&lf[109],14,"object-unevict");
lf[110]=C_h_intern(&lf[110],15,"\003sysmake-string");
lf[111]=C_h_intern(&lf[111],14,"object-become!");
lf[112]=C_h_intern(&lf[112],11,"\003sysbecome!");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000:bad argument type - not an a-list of non-immediate objects");
lf[114]=C_h_intern(&lf[114],16,"mutate-procedure");
lf[115]=C_h_intern(&lf[115],10,"global-ref");
lf[116]=C_h_intern(&lf[116],11,"global-set!");
lf[117]=C_h_intern(&lf[117],13,"global-bound\077");
lf[118]=C_h_intern(&lf[118],32,"\003syssymbol-has-toplevel-binding\077");
lf[119]=C_h_intern(&lf[119],20,"global-make-unbound!");
lf[120]=C_h_intern(&lf[120],28,"\003sysarbitrary-unbound-symbol");
lf[121]=C_h_intern(&lf[121],18,"getter-with-setter");
lf[122]=C_h_intern(&lf[122],13,"\003sysblock-ref");
lf[123]=C_h_intern(&lf[123],15,"pointer-s6-set!");
lf[124]=C_h_intern(&lf[124],17,"register-feature!");
lf[125]=C_h_intern(&lf[125],7,"lolevel");
C_register_lf2(lf,126,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1044,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1042 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1047,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 75   register-feature! */
t3=*((C_word*)lf[124]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[125]);}

/* k1045 in k1042 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[55],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1047,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! check-block ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1049,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[2] /* (set! check-generic-structure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1122,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! check-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1173,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1247,tmp=(C_word)a,a+=2,tmp);
t6=lf[9];
t7=C_mutate((C_word*)lf[8]+1 /* (set! move-memory! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1252,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=C_mutate((C_word*)lf[14]+1 /* (set! object-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1573,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[16]+1 /* (set! allocate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1654,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[17]+1 /* (set! free ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1657,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[18]+1 /* (set! pointer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1667,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[19]+1 /* (set! pointer-like? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1673,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[20]+1 /* (set! address->pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1679,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[23]+1 /* (set! pointer->address ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1688,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[26]+1 /* (set! null-pointer ...) */,*((C_word*)lf[27]+1));
t16=C_mutate((C_word*)lf[28]+1 /* (set! null-pointer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1698,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[29]+1 /* (set! object->pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1711,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[30]+1 /* (set! pointer->object ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1717,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[31]+1 /* (set! pointer=? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1723,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[32]+1 /* (set! pointer-offset ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1732,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[33]+1 /* (set! align-to-word ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1744,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[35]+1 /* (set! tag-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1776,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[37]+1 /* (set! tagged-pointer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1791,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[38]+1 /* (set! pointer-tag ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1828,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[39]+1 /* (set! make-locative ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1846,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[41]+1 /* (set! make-weak-locative ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1868,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[42]+1 /* (set! locative-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1890,tmp=(C_word)a,a+=2,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)C_locative_ref,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 345  getter-with-setter */
t30=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t30+1)))(4,t30,t28,t29,*((C_word*)lf[42]+1));}

/* k1893 in k1045 in k1042 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1 /* (set! locative-ref ...) */,t1);
t3=C_mutate((C_word*)lf[44]+1 /* (set! locative->object ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1897,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[45]+1 /* (set! locative? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1900,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[46]+1 /* (set! pointer-u8-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1906,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[47]+1 /* (set! pointer-s8-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1916,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[48]+1 /* (set! pointer-u16-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1926,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[49]+1 /* (set! pointer-s16-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1936,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[50]+1 /* (set! pointer-u32-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1946,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[51]+1 /* (set! pointer-s32-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1956,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[52]+1 /* (set! pointer-f32-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1966,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[53]+1 /* (set! pointer-f64-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1976,tmp=(C_word)a,a+=2,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3057,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 362  getter-with-setter */
t15=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,*((C_word*)lf[46]+1));}

/* a3056 in k1893 in k1045 in k1042 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3057,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub551(C_SCHEME_UNDEFINED,t3));}

/* k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=C_mutate((C_word*)lf[54]+1 /* (set! pointer-u8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3047,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 367  getter-with-setter */
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[47]+1));}

/* a3046 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3047,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub557(C_SCHEME_UNDEFINED,t3));}

/* k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1 /* (set! pointer-s8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3037,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 372  getter-with-setter */
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[48]+1));}

/* a3036 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3037,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub563(C_SCHEME_UNDEFINED,t3));}

/* k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1 /* (set! pointer-u16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3027,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 377  getter-with-setter */
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[123]+1));}

/* a3026 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3027,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub569(C_SCHEME_UNDEFINED,t3));}

/* k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! pointer-s16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2004,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3017,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 382  getter-with-setter */
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[50]+1));}

/* a3016 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3017,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub575(t3,t4));}

/* k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! pointer-u32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3007,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 387  getter-with-setter */
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[51]+1));}

/* a3006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3007,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub582(t3,t4));}

/* k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=C_mutate((C_word*)lf[59]+1 /* (set! pointer-s32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2997,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 392  getter-with-setter */
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[52]+1));}

/* a2996 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2997,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub589(t3,t4));}

/* k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1 /* (set! pointer-f32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2987,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 397  getter-with-setter */
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[53]+1));}

/* a2986 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2987,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub596(t3,t4));}

/* k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2016,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! pointer-f64-ref ...) */,t1);
t3=(C_word)C_a_i_vector(&a,1,lf[62]);
t4=C_mutate(&lf[63] /* (set! xproc-tag ...) */,t3);
t5=C_mutate((C_word*)lf[64]+1 /* (set! extend-procedure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2022,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[67]+1 /* (set! extended-procedure? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2057,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[69]+1 /* (set! procedure-data ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2088,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[64]+1);
t9=C_mutate((C_word*)lf[70]+1 /* (set! set-procedure-data! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2122,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[72]+1 /* (set! block-set! ...) */,*((C_word*)lf[73]+1));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 441  getter-with-setter */
t12=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[122]+1),*((C_word*)lf[73]+1));}

/* k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2140,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! block-ref ...) */,t1);
t3=C_mutate((C_word*)lf[75]+1 /* (set! number-of-slots ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2142,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[77]+1 /* (set! number-of-bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2151,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[79]+1 /* (set! make-record-instance ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2173,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[81]+1 /* (set! record-instance? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2182,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[82]+1 /* (set! record-instance-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2219,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[83]+1 /* (set! record-instance-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2228,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[84]+1 /* (set! record-instance-slot-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2241,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2963,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 488  getter-with-setter */
t12=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,*((C_word*)lf[84]+1));}

/* a2962 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2963,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2967,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 490  ##sys#check-generic-structure */
f_1122(t4,t2,(C_word)C_a_i_list(&a,1,lf[86]));}

/* k2965 in a2962 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 491  ##sys#check-range */
t5=*((C_word*)lf[85]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,((C_word*)t0)[4],C_fix(0),t4,lf[86]);}

/* k2968 in k2965 in a2962 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2267,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* (set! record-instance-slot ...) */,t1);
t3=C_mutate((C_word*)lf[87]+1 /* (set! record->vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2269,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[88]+1 /* (set! object-evicted? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2307,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[89]+1 /* (set! object-evict ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2310,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[95]+1 /* (set! object-evict-to-location ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2424,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[107]+1 /* (set! object-release ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2588,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[108]+1 /* (set! object-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2680,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[109]+1 /* (set! object-unevict ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2764,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[111]+1 /* (set! object-become! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2886,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[114]+1 /* (set! mutate-procedure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2895,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[115]+1 /* (set! global-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2926,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[116]+1 /* (set! global-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2932,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[117]+1 /* (set! global-bound? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2941,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[119]+1 /* (set! global-make-unbound! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2950,tmp=(C_word)a,a+=2,tmp));
t16=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2950,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[119]);
t4=(C_word)C_slot(lf[120],C_fix(0));
t5=(C_word)C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2941,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[117]);
/* lolevel.scm: 659  ##sys#symbol-has-toplevel-binding? */
t4=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* global-set! in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2932,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[116]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2926,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[115]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_retrieve(t2));}

/* mutate-procedure in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2895,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2899,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 638  ##sys#check-closure */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[114]);}

/* k2897 in mutate-procedure in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 639  ##sys#check-closure */
t3=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[114]);}

/* k2900 in k2897 in mutate-procedure in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2902,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 642  ##sys#make-vector */
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k2907 in k2900 in k2897 in mutate-procedure in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2909,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2912,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2924,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 643  proc */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2922 in k2907 in k2900 in k2897 in mutate-procedure in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* lolevel.scm: 643  ##sys#become! */
t4=*((C_word*)lf[112]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k2910 in k2907 in k2900 in k2897 in mutate-procedure in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2886,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2890,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_i_check_list_2(t4,lf[111]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1077,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1077(t9,t3,t4);}

/* loop in object-become! in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_1077(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1077,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_pair_2(t4,lf[111]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1099,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_u_i_car(t4);
/* lolevel.scm: 116  ##sys#check-block */
f_1049(t6,t7,(C_word)C_a_i_list(&a,1,lf[111]));}
else{
/* lolevel.scm: 120  ##sys#signal-hook */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[4],lf[111],lf[113],((C_word*)t0)[2]);}}}

/* k1097 in loop in object-become! in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* lolevel.scm: 117  ##sys#check-block */
f_1049(t2,t3,(C_word)C_a_i_list(&a,1,lf[111]));}

/* k1100 in k1097 in loop in object-become! in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_1102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* lolevel.scm: 118  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1077(t3,((C_word*)t0)[2],t2);}

/* k2888 in object-become! in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 635  ##sys#become! */
t2=*((C_word*)lf[112]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2764r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2764r(t0,t1,t2,t3);}}

static void C_ccall f_2764r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2771,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 606  make-hash-table */
t7=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[94]+1));}

/* k2769 in object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2771,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2776,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2776(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2769 in object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2776(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2776,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 610  hash-table-ref/default */
t4=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2790 in copy in k2769 in object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2792,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 613  ##sys#make-string */
t4=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2821,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lolevel.scm: 618  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 623  ##sys#make-vector */
t4=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k2833 in k2790 in copy in k2769 in object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2835,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 624  hash-table-set! */
t4=*((C_word*)lf[90]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2836 in k2833 in k2790 in copy in k2769 in object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2847(t7,t2,t3);}

/* doloop921 in k2836 in k2833 in k2790 in copy in k2769 in object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2847(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2847,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2868,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 627  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2776(t5,t3,t4);}}

/* k2866 in doloop921 in k2836 in k2833 in k2790 in copy in k2769 in object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2847(t4,((C_word*)t0)[2],t3);}

/* k2839 in k2836 in k2833 in k2790 in copy in k2769 in object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2819 in k2790 in copy in k2769 in object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2824,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 619  hash-table-set! */
t3=*((C_word*)lf[90]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2822 in k2819 in k2790 in copy in k2769 in object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2803 in k2790 in copy in k2769 in object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2805,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2808,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 614  hash-table-set! */
t4=*((C_word*)lf[90]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k2806 in k2803 in k2790 in copy in k2769 in object-unevict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2680,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2684,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 589  make-hash-table */
t4=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[94]+1));}

/* k2682 in object-size in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2689,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2689(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2682 in object-size in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2689(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2689,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 592  hash-table-ref/default */
t4=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2700 in evict in k2682 in object-size in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2702,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
/* lolevel.scm: 596  align-to-word */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_2759(2,t4,(C_word)C_bytes(t2));}}}

/* k2757 in k2700 in evict in k2682 in object-size in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2759,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 598  hash-table-set! */
t6=*((C_word*)lf[90]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k2709 in k2757 in k2700 in evict in k2682 in object-size in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2714,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2714(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2723(t9,t2,t5);}}

/* doloop871 in k2709 in k2757 in k2700 in evict in k2682 in object-size in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2723,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2745,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 602  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2689(t5,t3,t4);}}

/* k2743 in doloop871 in k2709 in k2757 in k2700 in evict in k2682 in object-size in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_u_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2723(t5,((C_word*)t0)[2],t4);}

/* k2712 in k2709 in k2757 in k2700 in evict in k2682 in object-size in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-release in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2588r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2588r(t0,t1,t2,t3);}}

static void C_ccall f_2588r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2670,tmp=(C_word)a,a+=2,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2597,a[2]=t9,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2597(t11,t1,t2);}

/* release in object-release in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2597(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2597,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
if(C_truep((C_word)C_u_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2626,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t7=t6;
f_2626(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2642(t11,t6,t7);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* doloop845 in release in object-release in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2642(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2642,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2652,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 585  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2597(t5,t3,t4);}}

/* k2650 in doloop845 in release in object-release in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2642(t3,((C_word*)t0)[2],t2);}

/* k2624 in release in object-release in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2633,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 586  ##sys#address->pointer */
t3=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k2631 in k2624 in release in object-release in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 586  free */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_2670 in object-release in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2670,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub829(C_SCHEME_UNDEFINED,t3));}

/* object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2424r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2424r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2424r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2428,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 533  ##sys#check-special */
t6=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[95]);}

/* k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t4=(C_word)C_i_check_exact_2(t3,lf[95]);
t5=t2;
f_2431(t5,t3);}
else{
t3=t2;
f_2431(t3,C_SCHEME_FALSE);}}

/* k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2431(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2431,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2577,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 538  ##sys#pointer->address */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2575 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 538  ##sys#address->pointer */
t2=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 539  make-hash-table */
t3=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[94]+1));}

/* k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2445,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2445(t6,t2,((C_word*)t0)[2]);}

/* evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2445(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2445,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 543  hash-table-ref/default */
t4=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 547  align-to-word */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_2570(2,t4,(C_word)C_bytes(t2));}}}

/* k2568 in k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2467,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2554,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
/* lolevel.scm: 554  make-property-condition */
t9=*((C_word*)lf[99]+1);
((C_proc9)(void*)(*((C_word*)t9+1)))(9,t9,t7,lf[102],lf[103],lf[95],lf[104],lf[105],lf[106],t8);}
else{
t6=t3;
f_2467(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2467(2,t4,C_SCHEME_UNDEFINED);}}

/* k2556 in k2568 in k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2562,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 558  make-property-condition */
t3=*((C_word*)lf[99]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[100],lf[101],((C_word*)((C_word*)t0)[2])[1]);}

/* k2560 in k2556 in k2568 in k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 553  make-composite-condition */
t2=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2552 in k2568 in k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 552  signal */
t2=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2465 in k2568 in k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[8]))){
t4=*((C_word*)lf[91]+1);
t5=t3;
f_2470(t5,(C_word)C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2470(t4,C_SCHEME_UNDEFINED);}}

/* k2468 in k2465 in k2568 in k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2470(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2470,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2473,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 561  ##sys#pointer->address */
t4=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2525 in k2468 in k2465 in k2568 in k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2527,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 561  ##sys#set-pointer-address! */
t3=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2471 in k2468 in k2465 in k2568 in k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 562  hash-table-set! */
t3=*((C_word*)lf[90]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2474 in k2471 in k2468 in k2465 in k2568 in k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2479(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2488(t9,t2,t5);}}

/* doloop804 in k2474 in k2471 in k2468 in k2465 in k2568 in k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2488(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2488,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2509,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 566  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2445(t5,t3,t4);}}

/* k2507 in doloop804 in k2474 in k2471 in k2468 in k2465 in k2568 in k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2488(t4,((C_word*)t0)[2],t3);}

/* k2477 in k2474 in k2471 in k2468 in k2465 in k2568 in k2453 in evict in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2438 in k2435 in k2432 in k2429 in k2426 in object-evict-to-location in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 568  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2310r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2310r(t0,t1,t2,t3);}}

static void C_ccall f_2310r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2421,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2317,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 514  make-hash-table */
t7=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[94]+1));}

/* k2315 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 515  ##sys#check-closure */
t3=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[89]);}

/* k2318 in k2315 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2320,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2325,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2325(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2318 in k2315 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2325,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 518  hash-table-ref/default */
t4=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2333 in evict in k2318 in k2315 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2335,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
/* lolevel.scm: 521  align-to-word */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_2344(2,t4,(C_word)C_bytes(t2));}}}

/* k2342 in k2333 in evict in k2318 in k2315 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
/* lolevel.scm: 522  allocator */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k2346 in k2342 in k2333 in evict in k2318 in k2315 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2348,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
t4=*((C_word*)lf[91]+1);
t5=t3;
f_2351(t5,(C_word)C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2351(t4,C_SCHEME_UNDEFINED);}}

/* k2349 in k2346 in k2342 in k2333 in evict in k2318 in k2315 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2351(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2351,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 524  hash-table-set! */
t3=*((C_word*)lf[90]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2352 in k2349 in k2346 in k2342 in k2333 in evict in k2318 in k2315 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2357(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2366(t9,t2,t5);}}

/* doloop744 in k2352 in k2349 in k2346 in k2342 in k2333 in evict in k2318 in k2315 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_2366(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2366,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2387,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 529  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2325(t5,t3,t4);}}

/* k2385 in doloop744 in k2352 in k2349 in k2346 in k2342 in k2333 in evict in k2318 in k2315 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2366(t4,((C_word*)t0)[2],t3);}

/* k2355 in k2352 in k2349 in k2346 in k2342 in k2333 in evict in k2318 in k2315 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2421 in object-evict in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2421,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub719(t3,t2));}

/* object-evicted? in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2307,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* record->vector in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2269,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2273,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 496  ##sys#check-generic-structure */
f_1122(t3,t2,(C_word)C_a_i_list(&a,1,lf[87]));}

/* k2271 in record->vector in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2273,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 498  ##sys#make-vector */
t4=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2277 in k2271 in record->vector in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2284,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2284(t2,C_fix(0)));}

/* doloop703 in k2277 in k2271 in record->vector in k2265 in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static C_word C_fcall f_2284(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* record-instance-slot-set! in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2241,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2245,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 483  ##sys#check-generic-structure */
f_1122(t5,t2,(C_word)C_a_i_list(&a,1,lf[84]));}

/* k2243 in record-instance-slot-set! in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 484  ##sys#check-range */
t5=*((C_word*)lf[85]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,((C_word*)t0)[5],C_fix(0),t4,lf[84]);}

/* k2246 in k2243 in record-instance-slot-set! in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[3],t2,((C_word*)t0)[2]));}

/* record-instance-length in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2228,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2232,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 479  ##sys#check-generic-structure */
f_1122(t3,t2,(C_word)C_a_i_list(&a,1,lf[83]));}

/* k2230 in record-instance-length in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_difference(t2,C_fix(1)));}

/* record-instance-type in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2219,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2223,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 475  ##sys#check-generic-structure */
f_1122(t3,t2,(C_word)C_a_i_list(&a,1,lf[82]));}

/* k2221 in record-instance-type in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* record-instance? in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2182r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2182r(t0,t1,t2,t3);}}

static void C_ccall f_2182r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=t2;
t7=(C_truep((C_word)C_blockp(t6))?(C_word)C_structurep(t6):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_i_not(t5);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_eqp(t5,t9));}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* make-record-instance in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2173r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2173r(t0,t1,t2,t3);}}

static void C_ccall f_2173r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_word)C_i_check_symbol_2(t2,lf[79]);
C_apply(5,0,t1,*((C_word*)lf[80]+1),t2,t3);}

/* number-of-bytes in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2151,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_w2b(t3));}}
else{
/* lolevel.scm: 449  ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[4],lf[77],lf[78],t2);}}

/* number-of-slots in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2142,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2146,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_list(&a,1,lf[75]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1151,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_blockp(t4))){
t7=(C_word)C_specialp(t4);
t8=(C_truep(t7)?t7:(C_word)C_byteblockp(t4));
t9=t6;
f_1151(t9,(C_word)C_i_not(t8));}
else{
t7=t6;
f_1151(t7,C_SCHEME_FALSE);}}

/* k1149 in number-of-slots in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_fcall f_1151(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2146(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_i_pairp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[3]):C_SCHEME_FALSE);
/* lolevel.scm: 134  ##sys#signal-hook */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[4],t3,lf[76],((C_word*)t0)[2]);}}

/* k2144 in number-of-slots in k2138 in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* set-procedure-data! in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2122,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2126,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 430  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k2124 in set-procedure-data! in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
/* lolevel.scm: 433  ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[4],lf[70],lf[71],((C_word*)t0)[3]);}}

/* procedure-data in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2088,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2098,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2106,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 415  ##sys#lambda-decoration */
t6=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t3,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2105 in procedure-data in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2106,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[63],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2096 in procedure-data in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2057,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2070,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2072,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 415  ##sys#lambda-decoration */
t6=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t3,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2071 in extended-procedure? in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2072,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[63],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2068 in extended-procedure? in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2022,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2026,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 408  ##sys#check-closure */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[64]);}

/* k2024 in extend-procedure in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2031,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2047,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 409  ##sys#decorate-lambda */
t4=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2046 in k2024 in extend-procedure in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2047,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[63],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a2030 in k2024 in extend-procedure in k2014 in k2010 in k2006 in k2002 in k1998 in k1994 in k1990 in k1986 in k1893 in k1045 in k1042 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2031,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[63],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-f64-set! in k1893 in k1045 in k1042 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1976,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub544(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-f32-set! in k1893 in k1045 in k1042 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1966,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub536(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-s32-set! in k1893 in k1045 in k1042 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1956,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub528(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-u32-set! in k1893 in k1045 in k1042 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1946,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub520(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-s16-set! in k1893 in k1045 in k1042 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1936,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub512(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-u16-set! in k1893 in k1045 in k1042 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1926,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub504(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-s8-set! in k1893 in k1045 in k1042 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1916,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub496(C_SCHEME_UNDEFINED,t4,t3));}

/* pointer-u8-set! in k1893 in k1045 in k1042 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1906,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub488(C_SCHEME_UNDEFINED,t4,t3));}

/* locative? in k1893 in k1045 in k1042 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1900,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_locativep(t2):C_SCHEME_FALSE));}

/* locative->object in k1893 in k1045 in k1042 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1897,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k1045 in k1042 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1890,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k1045 in k1042 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1868r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1868r(t0,t1,t2,t3);}}

static void C_ccall f_1868r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(0):(C_word)C_slot(t3,C_fix(0)));
/* lolevel.scm: 342  ##sys#make-locative */
t6=*((C_word*)lf[40]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t5,C_SCHEME_TRUE,lf[41]);}

/* make-locative in k1045 in k1042 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1846r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1846r(t0,t1,t2,t3);}}

static void C_ccall f_1846r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(0):(C_word)C_slot(t3,C_fix(0)));
/* lolevel.scm: 339  ##sys#make-locative */
t6=*((C_word*)lf[40]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t5,C_SCHEME_FALSE,lf[39]);}

/* pointer-tag in k1045 in k1042 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1828,3,t0,t1,t2);}
t3=t2;
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep((C_word)C_taggedpointerp(t2))?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 316  ##sys#error-hook */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[38],t2);}}

/* tagged-pointer? in k1045 in k1042 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1791r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1791r(t0,t1,t2,t3);}}

static void C_ccall f_1791r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_equalp(t5,t7));}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* tag-pointer in k1045 in k1042 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1776,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1780,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 301  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1778 in tag-pointer in k1045 in k1042 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1783,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_1783(2,t5,(C_word)C_copy_pointer(((C_word*)t0)[2],t1));}
else{
/* lolevel.scm: 304  ##sys#error-hook */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[35],((C_word*)t0)[2]);}}

/* k1781 in k1778 in tag-pointer in k1045 in k1042 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* align-to-word in k1045 in k1042 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1744,3,t0,t1,t2);}
if(C_truep((C_word)C_i_integerp(t2))){
t3=t1;
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub405(t5,t4));}
else{
t3=t2;
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1771,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 291  ##sys#pointer->address */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* lolevel.scm: 293  ##sys#signal-hook */
t5=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[4],lf[33],lf[34],t2);}}}

/* k1769 in align-to-word in k1045 in k1042 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1771,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t3=(C_word)stub405(t2,t1);
/* lolevel.scm: 291  ##sys#address->pointer */
t4=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* pointer-offset in k1045 in k1042 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1732,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub396(t4,t5,t3));}

/* pointer=? in k1045 in k1042 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1723,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1727,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 277  ##sys#check-special */
t5=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[31]);}

/* k1725 in pointer=? in k1045 in k1042 */
static void C_ccall f_1727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 278  ##sys#check-special */
t3=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[31]);}

/* k1728 in k1725 in pointer=? in k1045 in k1042 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k1045 in k1042 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1717,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1721,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 273  ##sys#check-pointer */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[30]);}

/* k1719 in pointer->object in k1045 in k1042 */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k1045 in k1042 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1711,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=t2;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub382(t4,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* null-pointer? in k1045 in k1042 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1698,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1702,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 265  ##sys#check-special */
t4=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[28]);}

/* k1700 in null-pointer? in k1045 in k1042 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 266  ##sys#pointer->address */
t3=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1707 in k1700 in null-pointer? in k1045 in k1042 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k1045 in k1042 */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1688,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1692,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 259  ##sys#check-special */
t4=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[23]);}

/* k1690 in pointer->address in k1045 in k1042 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 260  ##sys#pointer->address */
t2=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k1045 in k1042 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1679,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1683,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 255  ##sys#check-integer */
t4=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[20]);}

/* k1681 in address->pointer in k1045 in k1042 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 256  ##sys#address->pointer */
t2=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer-like? in k1045 in k1042 */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1673,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE));}

/* pointer? in k1045 in k1042 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1667,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_anypointerp(t2):C_SCHEME_FALSE));}

/* free in k1045 in k1042 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1657,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub353(C_SCHEME_UNDEFINED,t3));}

/* allocate in k1045 in k1042 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1654,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub348(t3,t2));}

/* object-copy in k1045 in k1042 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1573,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1579,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1579(t6,t1,t2);}

/* copy in object-copy in k1045 in k1042 */
static void C_fcall f_1579(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1579,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 233  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 237  ##sys#make-vector */
t6=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1607 in copy in object-copy in k1045 in k1042 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1612,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=t3;
f_1612(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_1624(t10,t3,t6);}}

/* doloop338 in k1607 in copy in object-copy in k1045 in k1042 */
static void C_fcall f_1624(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1624,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1645,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 241  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1579(t5,t3,t4);}}

/* k1643 in doloop338 in k1607 in copy in object-copy in k1045 in k1042 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1624(t4,((C_word*)t0)[2],t3);}

/* k1610 in k1607 in copy in object-copy in k1045 in k1042 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* move-memory! in k1045 in k1042 */
static void C_ccall f_1252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_1252r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1252r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1252r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(15);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1503,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1508,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1513,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-n179309 */
t9=t8;
f_1513(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-foffset180307 */
t11=t7;
f_1508(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-toffset181304 */
t13=t6;
f_1503(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body177186 */
t15=t5;
f_1254(t15,t1,t9,t11,t13);}}}}

/* def-n179 in move-memory! in k1045 in k1042 */
static void C_fcall f_1513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1513,NULL,2,t0,t1);}
/* def-foffset180307 */
t2=((C_word*)t0)[2];
f_1508(t2,t1,C_SCHEME_FALSE);}

/* def-foffset180 in move-memory! in k1045 in k1042 */
static void C_fcall f_1508(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1508,NULL,3,t0,t1,t2);}
/* def-toffset181304 */
t3=((C_word*)t0)[2];
f_1503(t3,t1,t2,C_fix(0));}

/* def-toffset181 in move-memory! in k1045 in k1042 */
static void C_fcall f_1503(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1503,NULL,4,t0,t1,t2,t3);}
/* body177186 */
t4=((C_word*)t0)[2];
f_1254(t4,t1,t2,t3,C_fix(0));}

/* body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1254(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1254,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1257,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1263,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1269,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1285,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t8,a[6]=t7,a[7]=t5,a[8]=t3,a[9]=t4,a[10]=t2,a[11]=((C_word*)t0)[2],a[12]=((C_word*)t0)[3],tmp=(C_word)a,a+=13,tmp);
/* lolevel.scm: 197  ##sys#check-block */
f_1049(t9,((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,lf[8]));}

/* k1310 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* lolevel.scm: 198  ##sys#check-block */
f_1049(t2,((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,lf[8]));}

/* k1313 in k1310 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=t3,a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_1320(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* move in k1313 in k1310 in body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1320(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1320,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_u_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 202  move */
t19=t1;
t20=t5;
t21=t3;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
/* lolevel.scm: 203  typerr */
f_1247(t1,t2);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_u_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 206  move */
t19=t1;
t20=t2;
t21=t5;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
/* lolevel.scm: 207  typerr */
f_1247(t1,t3);}}
else{
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:(C_word)C_locativep(t4));
if(C_truep(t6)){
t7=t3;
t8=(C_truep((C_word)C_blockp(t7))?(C_word)C_anypointerp(t7):C_SCHEME_FALSE);
t9=(C_truep(t8)?t8:(C_word)C_locativep(t7));
if(C_truep(t9)){
t10=((C_word*)t0)[7];
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1398,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t10)){
t12=t11;
f_1398(2,t12,t10);}
else{
/* lolevel.scm: 210  nosizerr */
t12=((C_word*)t0)[4];
f_1257(t12,t11);}}
else{
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1407,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 211  ##sys#bytevector? */
t11=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 215  ##sys#bytevector? */
t8=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}}}}

/* k1438 in move in k1313 in k1310 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[10]);
t4=((C_word*)t0)[9];
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:(C_word)C_locativep(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1462,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[5];
t9=(C_truep(t8)?t8:t3);
/* lolevel.scm: 218  checkn1 */
t10=((C_word*)t0)[4];
f_1269(t10,t7,t9,t3,((C_word*)t0)[6]);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 219  ##sys#bytevector? */
t8=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[9]);}}
else{
/* lolevel.scm: 225  typerr */
f_1247(((C_word*)t0)[8],((C_word*)t0)[10]);}}

/* k1470 in k1438 in move in k1313 in k1310 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1472,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1482,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(C_truep(t4)?t4:((C_word*)t0)[4]);
t6=(C_word)C_block_size(((C_word*)t0)[10]);
/* lolevel.scm: 220  checkn2 */
t7=((C_word*)t0)[3];
f_1285(t7,t3,t5,((C_word*)t0)[4],t6,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* lolevel.scm: 223  typerr */
f_1247(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1480 in k1470 in k1438 in move in k1313 in k1310 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?t3:C_SCHEME_FALSE);
t8=(C_truep(t4)?t4:C_SCHEME_FALSE);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub147(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}

/* k1460 in k1438 in move in k1313 in k1310 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?t4:C_SCHEME_FALSE);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub115(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}

/* k1405 in move in k1313 in k1310 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1407,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1417,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_1421(2,t6,t4);}
else{
/* lolevel.scm: 212  nosizerr */
t6=((C_word*)t0)[3];
f_1257(t6,t5);}}
else{
/* lolevel.scm: 214  typerr */
f_1247(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1419 in k1405 in move in k1313 in k1310 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 212  checkn1 */
t3=((C_word*)t0)[4];
f_1269(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k1415 in k1405 in move in k1313 in k1310 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?t3:C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub131(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}

/* k1396 in move in k1313 in k1310 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub99(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}

/* checkn2 in body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1285(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1285,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1292,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_u_fixnum_difference(t3,t5);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t8))){
t9=(C_word)C_u_fixnum_difference(t4,t6);
t10=t7;
f_1292(t10,(C_word)C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_1292(t9,C_SCHEME_FALSE);}}

/* k1290 in checkn2 in body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1292,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
/* lolevel.scm: 195  sizerr */
t2=((C_word*)t0)[4];
f_1263(t2,((C_word*)t0)[6],(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* checkn1 in body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1269(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1269,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t3,t4);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
/* lolevel.scm: 190  sizerr */
t6=((C_word*)t0)[2];
f_1263(t6,t1,(C_word)C_a_i_list(&a,2,t2,t3));}}

/* sizerr in body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1263,NULL,3,t0,t1,t2);}
C_apply(8,0,t1,*((C_word*)lf[10]+1),lf[8],lf[12],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* nosizerr in body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1257(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1257,NULL,2,t0,t1);}
/* lolevel.scm: 182  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[8],lf[11],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* typerr in k1045 in k1042 */
static void C_fcall f_1247(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1247,NULL,2,t1,t2);}
/* lolevel.scm: 173  ##sys#error-hook */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[8],t2);}

/* ##sys#check-pointer in k1045 in k1042 */
static void C_ccall f_1173(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1173r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1173r(t0,t1,t2,t3);}}

static void C_ccall f_1173r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
/* lolevel.scm: 140  ##sys#error-hook */
t8=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),t7,lf[7],t2);}}

/* ##sys#check-generic-structure in k1045 in k1042 */
static void C_fcall f_1122(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1122,NULL,3,t1,t2,t3);}
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_structurep(t4):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_pairp(t3);
t7=(C_truep(t6)?(C_word)C_u_i_car(t3):C_SCHEME_FALSE);
/* lolevel.scm: 126  ##sys#signal-hook */
t8=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,lf[4],t7,lf[5],t2);}}

/* ##sys#check-block in k1045 in k1042 */
static void C_fcall f_1049(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1049,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_car(t3):C_SCHEME_FALSE);
/* lolevel.scm: 105  ##sys#error-hook */
t6=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR),t5,t2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[203] = {
{"toplevel:lolevel_scm",(void*)C_lolevel_toplevel},
{"f_1044:lolevel_scm",(void*)f_1044},
{"f_1047:lolevel_scm",(void*)f_1047},
{"f_1895:lolevel_scm",(void*)f_1895},
{"f_3057:lolevel_scm",(void*)f_3057},
{"f_1988:lolevel_scm",(void*)f_1988},
{"f_3047:lolevel_scm",(void*)f_3047},
{"f_1992:lolevel_scm",(void*)f_1992},
{"f_3037:lolevel_scm",(void*)f_3037},
{"f_1996:lolevel_scm",(void*)f_1996},
{"f_3027:lolevel_scm",(void*)f_3027},
{"f_2000:lolevel_scm",(void*)f_2000},
{"f_3017:lolevel_scm",(void*)f_3017},
{"f_2004:lolevel_scm",(void*)f_2004},
{"f_3007:lolevel_scm",(void*)f_3007},
{"f_2008:lolevel_scm",(void*)f_2008},
{"f_2997:lolevel_scm",(void*)f_2997},
{"f_2012:lolevel_scm",(void*)f_2012},
{"f_2987:lolevel_scm",(void*)f_2987},
{"f_2016:lolevel_scm",(void*)f_2016},
{"f_2140:lolevel_scm",(void*)f_2140},
{"f_2963:lolevel_scm",(void*)f_2963},
{"f_2967:lolevel_scm",(void*)f_2967},
{"f_2970:lolevel_scm",(void*)f_2970},
{"f_2267:lolevel_scm",(void*)f_2267},
{"f_2950:lolevel_scm",(void*)f_2950},
{"f_2941:lolevel_scm",(void*)f_2941},
{"f_2932:lolevel_scm",(void*)f_2932},
{"f_2926:lolevel_scm",(void*)f_2926},
{"f_2895:lolevel_scm",(void*)f_2895},
{"f_2899:lolevel_scm",(void*)f_2899},
{"f_2902:lolevel_scm",(void*)f_2902},
{"f_2909:lolevel_scm",(void*)f_2909},
{"f_2924:lolevel_scm",(void*)f_2924},
{"f_2912:lolevel_scm",(void*)f_2912},
{"f_2886:lolevel_scm",(void*)f_2886},
{"f_1077:lolevel_scm",(void*)f_1077},
{"f_1099:lolevel_scm",(void*)f_1099},
{"f_1102:lolevel_scm",(void*)f_1102},
{"f_2890:lolevel_scm",(void*)f_2890},
{"f_2764:lolevel_scm",(void*)f_2764},
{"f_2771:lolevel_scm",(void*)f_2771},
{"f_2776:lolevel_scm",(void*)f_2776},
{"f_2792:lolevel_scm",(void*)f_2792},
{"f_2835:lolevel_scm",(void*)f_2835},
{"f_2838:lolevel_scm",(void*)f_2838},
{"f_2847:lolevel_scm",(void*)f_2847},
{"f_2868:lolevel_scm",(void*)f_2868},
{"f_2841:lolevel_scm",(void*)f_2841},
{"f_2821:lolevel_scm",(void*)f_2821},
{"f_2824:lolevel_scm",(void*)f_2824},
{"f_2805:lolevel_scm",(void*)f_2805},
{"f_2808:lolevel_scm",(void*)f_2808},
{"f_2680:lolevel_scm",(void*)f_2680},
{"f_2684:lolevel_scm",(void*)f_2684},
{"f_2689:lolevel_scm",(void*)f_2689},
{"f_2702:lolevel_scm",(void*)f_2702},
{"f_2759:lolevel_scm",(void*)f_2759},
{"f_2711:lolevel_scm",(void*)f_2711},
{"f_2723:lolevel_scm",(void*)f_2723},
{"f_2745:lolevel_scm",(void*)f_2745},
{"f_2714:lolevel_scm",(void*)f_2714},
{"f_2588:lolevel_scm",(void*)f_2588},
{"f_2597:lolevel_scm",(void*)f_2597},
{"f_2642:lolevel_scm",(void*)f_2642},
{"f_2652:lolevel_scm",(void*)f_2652},
{"f_2626:lolevel_scm",(void*)f_2626},
{"f_2633:lolevel_scm",(void*)f_2633},
{"f_2670:lolevel_scm",(void*)f_2670},
{"f_2424:lolevel_scm",(void*)f_2424},
{"f_2428:lolevel_scm",(void*)f_2428},
{"f_2431:lolevel_scm",(void*)f_2431},
{"f_2577:lolevel_scm",(void*)f_2577},
{"f_2434:lolevel_scm",(void*)f_2434},
{"f_2437:lolevel_scm",(void*)f_2437},
{"f_2445:lolevel_scm",(void*)f_2445},
{"f_2455:lolevel_scm",(void*)f_2455},
{"f_2570:lolevel_scm",(void*)f_2570},
{"f_2558:lolevel_scm",(void*)f_2558},
{"f_2562:lolevel_scm",(void*)f_2562},
{"f_2554:lolevel_scm",(void*)f_2554},
{"f_2467:lolevel_scm",(void*)f_2467},
{"f_2470:lolevel_scm",(void*)f_2470},
{"f_2527:lolevel_scm",(void*)f_2527},
{"f_2473:lolevel_scm",(void*)f_2473},
{"f_2476:lolevel_scm",(void*)f_2476},
{"f_2488:lolevel_scm",(void*)f_2488},
{"f_2509:lolevel_scm",(void*)f_2509},
{"f_2479:lolevel_scm",(void*)f_2479},
{"f_2440:lolevel_scm",(void*)f_2440},
{"f_2310:lolevel_scm",(void*)f_2310},
{"f_2317:lolevel_scm",(void*)f_2317},
{"f_2320:lolevel_scm",(void*)f_2320},
{"f_2325:lolevel_scm",(void*)f_2325},
{"f_2335:lolevel_scm",(void*)f_2335},
{"f_2344:lolevel_scm",(void*)f_2344},
{"f_2348:lolevel_scm",(void*)f_2348},
{"f_2351:lolevel_scm",(void*)f_2351},
{"f_2354:lolevel_scm",(void*)f_2354},
{"f_2366:lolevel_scm",(void*)f_2366},
{"f_2387:lolevel_scm",(void*)f_2387},
{"f_2357:lolevel_scm",(void*)f_2357},
{"f_2421:lolevel_scm",(void*)f_2421},
{"f_2307:lolevel_scm",(void*)f_2307},
{"f_2269:lolevel_scm",(void*)f_2269},
{"f_2273:lolevel_scm",(void*)f_2273},
{"f_2279:lolevel_scm",(void*)f_2279},
{"f_2284:lolevel_scm",(void*)f_2284},
{"f_2241:lolevel_scm",(void*)f_2241},
{"f_2245:lolevel_scm",(void*)f_2245},
{"f_2248:lolevel_scm",(void*)f_2248},
{"f_2228:lolevel_scm",(void*)f_2228},
{"f_2232:lolevel_scm",(void*)f_2232},
{"f_2219:lolevel_scm",(void*)f_2219},
{"f_2223:lolevel_scm",(void*)f_2223},
{"f_2182:lolevel_scm",(void*)f_2182},
{"f_2173:lolevel_scm",(void*)f_2173},
{"f_2151:lolevel_scm",(void*)f_2151},
{"f_2142:lolevel_scm",(void*)f_2142},
{"f_1151:lolevel_scm",(void*)f_1151},
{"f_2146:lolevel_scm",(void*)f_2146},
{"f_2122:lolevel_scm",(void*)f_2122},
{"f_2126:lolevel_scm",(void*)f_2126},
{"f_2088:lolevel_scm",(void*)f_2088},
{"f_2106:lolevel_scm",(void*)f_2106},
{"f_2098:lolevel_scm",(void*)f_2098},
{"f_2057:lolevel_scm",(void*)f_2057},
{"f_2072:lolevel_scm",(void*)f_2072},
{"f_2070:lolevel_scm",(void*)f_2070},
{"f_2022:lolevel_scm",(void*)f_2022},
{"f_2026:lolevel_scm",(void*)f_2026},
{"f_2047:lolevel_scm",(void*)f_2047},
{"f_2031:lolevel_scm",(void*)f_2031},
{"f_1976:lolevel_scm",(void*)f_1976},
{"f_1966:lolevel_scm",(void*)f_1966},
{"f_1956:lolevel_scm",(void*)f_1956},
{"f_1946:lolevel_scm",(void*)f_1946},
{"f_1936:lolevel_scm",(void*)f_1936},
{"f_1926:lolevel_scm",(void*)f_1926},
{"f_1916:lolevel_scm",(void*)f_1916},
{"f_1906:lolevel_scm",(void*)f_1906},
{"f_1900:lolevel_scm",(void*)f_1900},
{"f_1897:lolevel_scm",(void*)f_1897},
{"f_1890:lolevel_scm",(void*)f_1890},
{"f_1868:lolevel_scm",(void*)f_1868},
{"f_1846:lolevel_scm",(void*)f_1846},
{"f_1828:lolevel_scm",(void*)f_1828},
{"f_1791:lolevel_scm",(void*)f_1791},
{"f_1776:lolevel_scm",(void*)f_1776},
{"f_1780:lolevel_scm",(void*)f_1780},
{"f_1783:lolevel_scm",(void*)f_1783},
{"f_1744:lolevel_scm",(void*)f_1744},
{"f_1771:lolevel_scm",(void*)f_1771},
{"f_1732:lolevel_scm",(void*)f_1732},
{"f_1723:lolevel_scm",(void*)f_1723},
{"f_1727:lolevel_scm",(void*)f_1727},
{"f_1730:lolevel_scm",(void*)f_1730},
{"f_1717:lolevel_scm",(void*)f_1717},
{"f_1721:lolevel_scm",(void*)f_1721},
{"f_1711:lolevel_scm",(void*)f_1711},
{"f_1698:lolevel_scm",(void*)f_1698},
{"f_1702:lolevel_scm",(void*)f_1702},
{"f_1709:lolevel_scm",(void*)f_1709},
{"f_1688:lolevel_scm",(void*)f_1688},
{"f_1692:lolevel_scm",(void*)f_1692},
{"f_1679:lolevel_scm",(void*)f_1679},
{"f_1683:lolevel_scm",(void*)f_1683},
{"f_1673:lolevel_scm",(void*)f_1673},
{"f_1667:lolevel_scm",(void*)f_1667},
{"f_1657:lolevel_scm",(void*)f_1657},
{"f_1654:lolevel_scm",(void*)f_1654},
{"f_1573:lolevel_scm",(void*)f_1573},
{"f_1579:lolevel_scm",(void*)f_1579},
{"f_1609:lolevel_scm",(void*)f_1609},
{"f_1624:lolevel_scm",(void*)f_1624},
{"f_1645:lolevel_scm",(void*)f_1645},
{"f_1612:lolevel_scm",(void*)f_1612},
{"f_1252:lolevel_scm",(void*)f_1252},
{"f_1513:lolevel_scm",(void*)f_1513},
{"f_1508:lolevel_scm",(void*)f_1508},
{"f_1503:lolevel_scm",(void*)f_1503},
{"f_1254:lolevel_scm",(void*)f_1254},
{"f_1312:lolevel_scm",(void*)f_1312},
{"f_1315:lolevel_scm",(void*)f_1315},
{"f_1320:lolevel_scm",(void*)f_1320},
{"f_1440:lolevel_scm",(void*)f_1440},
{"f_1472:lolevel_scm",(void*)f_1472},
{"f_1482:lolevel_scm",(void*)f_1482},
{"f_1462:lolevel_scm",(void*)f_1462},
{"f_1407:lolevel_scm",(void*)f_1407},
{"f_1421:lolevel_scm",(void*)f_1421},
{"f_1417:lolevel_scm",(void*)f_1417},
{"f_1398:lolevel_scm",(void*)f_1398},
{"f_1285:lolevel_scm",(void*)f_1285},
{"f_1292:lolevel_scm",(void*)f_1292},
{"f_1269:lolevel_scm",(void*)f_1269},
{"f_1263:lolevel_scm",(void*)f_1263},
{"f_1257:lolevel_scm",(void*)f_1257},
{"f_1247:lolevel_scm",(void*)f_1247},
{"f_1173:lolevel_scm",(void*)f_1173},
{"f_1122:lolevel_scm",(void*)f_1122},
{"f_1049:lolevel_scm",(void*)f_1049},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
