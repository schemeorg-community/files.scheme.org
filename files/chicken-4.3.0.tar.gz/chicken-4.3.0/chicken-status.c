/* Generated from chicken-status.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: chicken-status.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -ignore-repository -output-file chicken-status.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 posix data_structures utils ports regex files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[54];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_311)
static void C_ccall f_311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_314)
static void C_ccall f_314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_317)
static void C_ccall f_317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_320)
static void C_ccall f_320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_323)
static void C_ccall f_323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_326)
static void C_ccall f_326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_329)
static void C_ccall f_329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_332)
static void C_ccall f_332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_335)
static void C_ccall f_335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_338)
static void C_ccall f_338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_341)
static void C_ccall f_341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_344)
static void C_ccall f_344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_347)
static void C_ccall f_347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_350)
static void C_ccall f_350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_845)
static void C_ccall f_845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_649)
static void C_fcall f_649(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_693)
static void C_fcall f_693(C_word t0,C_word t1) C_noret;
C_noret_decl(f_738)
static void C_fcall f_738(C_word t0,C_word t1) C_noret;
C_noret_decl(f_785)
static void C_ccall f_785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_747)
static void C_ccall f_747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_781)
static void C_ccall f_781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_770)
static void C_ccall f_770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_760)
static void C_ccall f_760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_732)
static void C_ccall f_732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_725)
static void C_ccall f_725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_385)
static void C_ccall f_385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_381)
static void C_ccall f_381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_377)
static void C_ccall f_377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_356)
static void C_ccall f_356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_369)
static void C_ccall f_369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_367)
static void C_ccall f_367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_363)
static void C_ccall f_363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_659)
static void C_ccall f_659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_841)
static void C_ccall f_841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_838)
static void C_ccall f_838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_633)
static void C_fcall f_633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_637)
static void C_ccall f_637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_580)
static void C_ccall f_580(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_617)
static void C_ccall f_617(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_631)
static void C_ccall f_631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_615)
static void C_ccall f_615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_588)
static void C_ccall f_588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_590)
static void C_fcall f_590(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_600)
static void C_ccall f_600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_500)
static void C_ccall f_500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_471)
static void C_ccall f_471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_494)
static void C_ccall f_494(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_494)
static void C_ccall f_494r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_488)
static void C_ccall f_488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_480)
static void C_ccall f_480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_578)
static void C_fcall f_578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_504)
static void C_ccall f_504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_511)
static void C_ccall f_511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_513)
static void C_fcall f_513(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_570)
static void C_ccall f_570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_543)
static void C_ccall f_543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_555)
static void C_ccall f_555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_551)
static void C_ccall f_551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_547)
static void C_ccall f_547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_529)
static void C_ccall f_529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_387)
static void C_fcall f_387(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_419)
static void C_fcall f_419(C_word t0,C_word t1) C_noret;
C_noret_decl(f_414)
static void C_fcall f_414(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_389)
static void C_fcall f_389(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_396)
static void C_ccall f_396(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_649)
static void C_fcall trf_649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_649(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_649(t0,t1,t2,t3);}

C_noret_decl(trf_693)
static void C_fcall trf_693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_693(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_693(t0,t1);}

C_noret_decl(trf_738)
static void C_fcall trf_738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_738(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_738(t0,t1);}

C_noret_decl(trf_633)
static void C_fcall trf_633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_633(t0,t1);}

C_noret_decl(trf_590)
static void C_fcall trf_590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_590(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_590(t0,t1,t2);}

C_noret_decl(trf_578)
static void C_fcall trf_578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_578(t0,t1);}

C_noret_decl(trf_513)
static void C_fcall trf_513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_513(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_513(t0,t1,t2);}

C_noret_decl(trf_387)
static void C_fcall trf_387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_387(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_387(t0,t1,t2,t3);}

C_noret_decl(trf_419)
static void C_fcall trf_419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_419(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_419(t0,t1);}

C_noret_decl(trf_414)
static void C_fcall trf_414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_414(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_414(t0,t1,t2);}

C_noret_decl(trf_389)
static void C_fcall trf_389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_389(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_389(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(349)){
C_save(t1);
C_rereclaim2(349*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,54);
lf[1]=C_h_intern(&lf[1],13,"string-append");
lf[2]=C_h_intern(&lf[2],11,"make-string");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[6]=C_h_intern(&lf[6],7,"version");
lf[7]=C_h_intern(&lf[7],5,"print");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\012 version: ");
lf[9]=C_h_intern(&lf[9],8,"->string");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[11]=C_h_intern(&lf[11],19,"setup-api#read-info");
lf[12]=C_h_intern(&lf[12],4,"sort");
lf[13]=C_h_intern(&lf[13],8,"string<\077");
lf[14]=C_h_intern(&lf[14],13,"terminal-size");
lf[15]=C_h_intern(&lf[15],14,"terminal-port\077");
lf[16]=C_h_intern(&lf[16],19,"current-output-port");
lf[18]=C_h_intern(&lf[18],5,"files");
lf[19]=C_h_intern(&lf[19],10,"append-map");
lf[21]=C_h_intern(&lf[21],4,"exit");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\312usage: chicken-status [OPTION | PATTERN] ...\012\012  -h   -help                 "
"   show this message\012  -v   -version                 show version and exit\012  -f "
"  -files                   list installed files");
lf[23]=C_h_intern(&lf[23],25,"\003sysimplicit-exit-handler");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\006(none)");
lf[25]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002.*\376\377\016");
lf[26]=C_h_intern(&lf[26],17,"delete-duplicates");
lf[27]=C_h_intern(&lf[27],8,"string=\077");
lf[28]=C_h_intern(&lf[28],11,"concatenate");
lf[29]=C_h_intern(&lf[29],4,"grep");
lf[30]=C_h_intern(&lf[30],7,"\003sysmap");
lf[31]=C_h_intern(&lf[31],13,"pathname-file");
lf[32]=C_h_intern(&lf[32],4,"glob");
lf[33]=C_h_intern(&lf[33],13,"make-pathname");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[36]=C_h_intern(&lf[36],15,"repository-path");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\002-f");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\006-files");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[42]=C_h_intern(&lf[42],15,"chicken-version");
lf[43]=C_h_intern(&lf[43],6,"append");
lf[44]=C_h_intern(&lf[44],17,"lset-intersection");
lf[45]=C_h_intern(&lf[45],3,"eq\077");
lf[46]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000f\376\377\016");
lf[47]=C_h_intern(&lf[47],16,"\003sysstring->list");
lf[48]=C_h_intern(&lf[48],9,"substring");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[51]=C_h_intern(&lf[51],22,"command-line-arguments");
lf[52]=C_h_intern(&lf[52],11,"\003sysrequire");
lf[53]=C_h_intern(&lf[53],9,"setup-api");
C_register_lf2(lf,54,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_311,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k309 */
static void C_ccall f_311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k312 in k309 */
static void C_ccall f_314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_317,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k315 in k312 in k309 */
static void C_ccall f_317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k318 in k315 in k312 in k309 */
static void C_ccall f_320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_323,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_329,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[52]))(3,*((C_word*)lf[52]+1),t2,lf[53]);}

/* k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_350,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_387,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[5] /* (set! main#list-installed-eggs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_500,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[17] /* (set! main#list-installed-files ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_580,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[20] /* (set! main#usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_633,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_835,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_845,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 129  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[51]))(2,*((C_word*)lf[51]+1),t7);}

/* k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_845,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_649,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_649(t7,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_fcall f_649(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_649,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_659,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?lf[25]:t3);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_356,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_377,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_381,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_385,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 38   repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[36]))(2,*((C_word*)lf[36]+1),t10);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[37]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_693,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_693(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[49]);
t8=t6;
f_693(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[50])));}}}

/* k691 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_fcall f_693(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_693,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-status.scm: 112  usage */
f_633(((C_word*)t0)[7],C_fix(0));}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[38]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[39]));
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-status.scm: 115  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_649(t6,((C_word*)t0)[7],t5,((C_word*)t0)[2]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[40]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[41]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_725,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_732,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 117  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[42]))(2,*((C_word*)lf[42]+1),t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_738,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_positivep(t7))){
t8=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t9=t6;
f_738(t9,(C_word)C_eqp(C_make_character(45),t8));}
else{
t8=t6;
f_738(t8,C_SCHEME_FALSE);}}}}}

/* k736 in k691 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_fcall f_738(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_738,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_785,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 122  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
/* chicken-status.scm: 126  usage */
f_633(((C_word*)t0)[4],C_fix(1));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[3]);
/* chicken-status.scm: 127  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_649(t4,((C_word*)t0)[4],t2,t3);}}

/* k783 in k736 in k691 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k745 in k736 in k691 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_781,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-status.scm: 123  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),t2,*((C_word*)lf[45]+1),lf[46],t1);}

/* k779 in k745 in k736 in k691 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_781,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_760,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_764,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_770,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
/* chicken-status.scm: 125  usage */
f_633(((C_word*)t0)[5],C_fix(1));}}

/* a769 in k779 in k745 in k736 in k691 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_770,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k762 in k779 in k745 in k736 in k691 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-status.scm: 124  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[43]+1)))(4,*((C_word*)lf[43]+1),((C_word*)t0)[2],t1,t2);}

/* k758 in k779 in k745 in k736 in k691 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 124  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_649(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k730 in k691 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 117  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],t1);}

/* k723 in k691 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 118  exit */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),((C_word*)t0)[2],C_fix(0));}

/* k383 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 38   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[33]))(5,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1,lf[34],lf[35]);}

/* k379 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 38   glob */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),((C_word*)t0)[2],t1);}

/* k375 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[31]),t1);}

/* k354 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_363,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_367,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_369,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a368 in k354 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_369,3,t0,t1,t2);}
/* grep */
((C_proc4)C_retrieve_symbol_proc(lf[29]))(4,*((C_word*)lf[29]+1),t1,t2,((C_word*)t0)[2]);}

/* k365 in k354 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 40   concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),((C_word*)t0)[2],t1);}

/* k361 in k354 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 39   delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[26]))(4,*((C_word*)lf[26]+1),((C_word*)t0)[2],t1,*((C_word*)lf[27]+1));}

/* k657 in loop in k843 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-status.scm: 105  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],lf[24]);}
else{
t2=(C_truep(((C_word*)((C_word*)t0)[2])[1])?C_retrieve2(lf[17],"main#list-installed-files"):C_retrieve2(lf[5],"main#list-installed-eggs"));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t1);}}

/* k833 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_838,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_841,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t3);}

/* k839 in k833 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k836 in k833 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#usage in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_fcall f_633(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_633,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_637,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 87   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t3,lf[22]);}

/* k635 in main#usage in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 95   exit */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* main#list-installed-files in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_580(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_580,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_588,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_615,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_617,tmp=(C_word)a,a+=2,tmp);
/* chicken-status.scm: 77   append-map */
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t4,t5,t2);}

/* a616 in main#list-installed-files in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_617(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_617,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_631,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 79   setup-api#read-info */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t2);}

/* k629 in a616 in main#list-installed-files in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(lf[18],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_END_OF_LIST));}

/* k613 in main#list-installed-files in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 76   sort */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),((C_word*)t0)[2],t1,*((C_word*)lf[13]+1));}

/* k586 in main#list-installed-files in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_588,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_590,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_590(t5,((C_word*)t0)[2],t1);}

/* loop221 in k586 in main#list-installed-files in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_fcall f_590(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_590,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_600,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k598 in loop221 in k586 in main#list-installed-files in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_590(t3,((C_word*)t0)[2],t2);}

/* main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_500,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_504,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_578,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_471,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 53   current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[16]+1)))(2,*((C_word*)lf[16]+1),t5);}

/* k469 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_477,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 54   terminal-port? */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t1);}

/* k475 in k469 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_477,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_480,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_488,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_494,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}
else{
t2=((C_word*)t0)[3];
f_578(t2,C_fix(80));}}

/* a493 in k475 in k469 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_494(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_494r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_494r(t0,t1,t2);}}

static void C_ccall f_494r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a487 in k475 in k469 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_488,2,t0,t1);}
/* chicken-status.scm: 55   terminal-size */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t1,((C_word*)t0)[2]);}

/* k478 in k475 in k469 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_zerop(t1);
t3=((C_word*)t0)[2];
f_578(t3,(C_truep(t2)?C_fix(80):t1));}

/* k576 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_fcall f_578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_578,NULL,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,t1,C_fix(2));
C_quotient(4,0,((C_word*)t0)[2],t2,C_fix(2));}

/* k502 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_511,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 71   sort */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),t2,((C_word*)t0)[2],*((C_word*)lf[13]+1));}

/* k509 in k502 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_511,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_513,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_513(t5,((C_word*)t0)[2],t1);}

/* loop208 in k509 in k502 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_fcall f_513(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_513,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_570,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-status.scm: 63   setup-api#read-info */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k568 in loop208 in k509 in k502 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_570,2,t0,t1);}
t2=(C_word)C_i_assq(lf[6],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_529,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_543,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_563,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 66   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t5,((C_word*)t0)[2],lf[10]);}
else{
/* chicken-status.scm: 70   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t3,((C_word*)t0)[2]);}}

/* k561 in k568 in loop208 in k509 in k502 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_563,2,t0,t1);}
/* chicken-status.scm: 66   format-string */
f_387(((C_word*)t0)[3],t1,((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,C_make_character(46)));}

/* k541 in k568 in loop208 in k509 in k502 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_547,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_551,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_555,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-status.scm: 68   ->string */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t4,t5);}

/* k553 in k541 in k568 in loop208 in k509 in k502 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 68   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[8],t1);}

/* k549 in k541 in k568 in loop208 in k509 in k502 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_551,2,t0,t1);}
/* chicken-status.scm: 67   format-string */
f_387(((C_word*)t0)[3],t1,((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,C_make_character(46)));}

/* k545 in k541 in k568 in loop208 in k509 in k502 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 65   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k527 in k568 in loop208 in k509 in k502 in main#list-installed-eggs in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_513(t3,((C_word*)t0)[2],t2);}

/* main#format-string in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_fcall f_387(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_387,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_389,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_414,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_419,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-right177191 */
t8=t7;
f_419(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-padc178189 */
t10=t6;
f_414(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body175183 */
t12=t5;
f_389(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[4],t11);}}}}

/* def-right177 in main#format-string in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_fcall f_419(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_419,NULL,2,t0,t1);}
/* def-padc178189 */
t2=((C_word*)t0)[2];
f_414(t2,t1,C_SCHEME_FALSE);}

/* def-padc178 in main#format-string in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_fcall f_414(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_414,NULL,3,t0,t1,t2);}
/* body175183 */
t3=((C_word*)t0)[2];
f_389(t3,t1,t2,C_make_character(32));}

/* body175 in main#format-string in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_fcall f_389(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_389,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_396,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[2],t4);
t7=(C_word)C_i_fixnum_max(C_fix(0),t6);
/* chicken-status.scm: 45   make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[2]+1)))(4,*((C_word*)lf[2]+1),t5,t7,t3);}

/* k394 in body175 in main#format-string in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in k318 in k315 in k312 in k309 */
static void C_ccall f_396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* chicken-status.scm: 47   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* chicken-status.scm: 48   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[70] = {
{"toplevel:chicken_status_scm",(void*)C_toplevel},
{"f_311:chicken_status_scm",(void*)f_311},
{"f_314:chicken_status_scm",(void*)f_314},
{"f_317:chicken_status_scm",(void*)f_317},
{"f_320:chicken_status_scm",(void*)f_320},
{"f_323:chicken_status_scm",(void*)f_323},
{"f_326:chicken_status_scm",(void*)f_326},
{"f_329:chicken_status_scm",(void*)f_329},
{"f_332:chicken_status_scm",(void*)f_332},
{"f_335:chicken_status_scm",(void*)f_335},
{"f_338:chicken_status_scm",(void*)f_338},
{"f_341:chicken_status_scm",(void*)f_341},
{"f_344:chicken_status_scm",(void*)f_344},
{"f_347:chicken_status_scm",(void*)f_347},
{"f_350:chicken_status_scm",(void*)f_350},
{"f_845:chicken_status_scm",(void*)f_845},
{"f_649:chicken_status_scm",(void*)f_649},
{"f_693:chicken_status_scm",(void*)f_693},
{"f_738:chicken_status_scm",(void*)f_738},
{"f_785:chicken_status_scm",(void*)f_785},
{"f_747:chicken_status_scm",(void*)f_747},
{"f_781:chicken_status_scm",(void*)f_781},
{"f_770:chicken_status_scm",(void*)f_770},
{"f_764:chicken_status_scm",(void*)f_764},
{"f_760:chicken_status_scm",(void*)f_760},
{"f_732:chicken_status_scm",(void*)f_732},
{"f_725:chicken_status_scm",(void*)f_725},
{"f_385:chicken_status_scm",(void*)f_385},
{"f_381:chicken_status_scm",(void*)f_381},
{"f_377:chicken_status_scm",(void*)f_377},
{"f_356:chicken_status_scm",(void*)f_356},
{"f_369:chicken_status_scm",(void*)f_369},
{"f_367:chicken_status_scm",(void*)f_367},
{"f_363:chicken_status_scm",(void*)f_363},
{"f_659:chicken_status_scm",(void*)f_659},
{"f_835:chicken_status_scm",(void*)f_835},
{"f_841:chicken_status_scm",(void*)f_841},
{"f_838:chicken_status_scm",(void*)f_838},
{"f_633:chicken_status_scm",(void*)f_633},
{"f_637:chicken_status_scm",(void*)f_637},
{"f_580:chicken_status_scm",(void*)f_580},
{"f_617:chicken_status_scm",(void*)f_617},
{"f_631:chicken_status_scm",(void*)f_631},
{"f_615:chicken_status_scm",(void*)f_615},
{"f_588:chicken_status_scm",(void*)f_588},
{"f_590:chicken_status_scm",(void*)f_590},
{"f_600:chicken_status_scm",(void*)f_600},
{"f_500:chicken_status_scm",(void*)f_500},
{"f_471:chicken_status_scm",(void*)f_471},
{"f_477:chicken_status_scm",(void*)f_477},
{"f_494:chicken_status_scm",(void*)f_494},
{"f_488:chicken_status_scm",(void*)f_488},
{"f_480:chicken_status_scm",(void*)f_480},
{"f_578:chicken_status_scm",(void*)f_578},
{"f_504:chicken_status_scm",(void*)f_504},
{"f_511:chicken_status_scm",(void*)f_511},
{"f_513:chicken_status_scm",(void*)f_513},
{"f_570:chicken_status_scm",(void*)f_570},
{"f_563:chicken_status_scm",(void*)f_563},
{"f_543:chicken_status_scm",(void*)f_543},
{"f_555:chicken_status_scm",(void*)f_555},
{"f_551:chicken_status_scm",(void*)f_551},
{"f_547:chicken_status_scm",(void*)f_547},
{"f_529:chicken_status_scm",(void*)f_529},
{"f_387:chicken_status_scm",(void*)f_387},
{"f_419:chicken_status_scm",(void*)f_419},
{"f_414:chicken_status_scm",(void*)f_414},
{"f_389:chicken_status_scm",(void*)f_389},
{"f_396:chicken_status_scm",(void*)f_396},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
