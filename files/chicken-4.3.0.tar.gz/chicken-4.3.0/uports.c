/* Generated from ports.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:03
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: ports.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file uports.c
   unit: ports
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[40];
static double C_possibly_force_alignment;


C_noret_decl(C_ports_toplevel)
C_externexport void C_ccall C_ports_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_313)
static void C_ccall f_313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_903)
static void C_ccall f_903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_903)
static void C_ccall f_903r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_916)
static void C_ccall f_916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_919)
static void C_ccall f_919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_946)
static void C_ccall f_946(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_937)
static void C_ccall f_937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_941)
static void C_ccall f_941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_931)
static void C_ccall f_931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_929)
static void C_ccall f_929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_760)
static void C_ccall f_760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_760)
static void C_ccall f_760r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_843)
static void C_fcall f_843(C_word t0,C_word t1) C_noret;
C_noret_decl(f_838)
static void C_fcall f_838(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_833)
static void C_fcall f_833(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_762)
static void C_fcall f_762(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_772)
static void C_ccall f_772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_775)
static void C_ccall f_775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_828)
static void C_ccall f_828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_819)
static void C_ccall f_819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_823)
static void C_ccall f_823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_798)
static void C_ccall f_798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_814)
static void C_ccall f_814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_732)
static void C_ccall f_732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_736)
static void C_ccall f_736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_755)
static void C_ccall f_755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_746)
static void C_ccall f_746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_741)
static void C_ccall f_741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_707)
static void C_ccall f_707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_711)
static void C_ccall f_711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_721)
static void C_ccall f_721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_716)
static void C_ccall f_716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_695)
static void C_ccall f_695(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_699)
static void C_ccall f_699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_702)
static void C_ccall f_702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_686)
static void C_ccall f_686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_661)
static void C_ccall f_661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_665)
static void C_ccall f_665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_681)
static void C_ccall f_681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_675)
static void C_ccall f_675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_670)
static void C_ccall f_670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_636)
static void C_ccall f_636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_640)
static void C_ccall f_640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_656)
static void C_ccall f_656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_650)
static void C_ccall f_650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_645)
static void C_ccall f_645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_611)
static void C_ccall f_611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_615)
static void C_ccall f_615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_631)
static void C_ccall f_631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_625)
static void C_ccall f_625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_620)
static void C_ccall f_620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_459)
static void C_ccall f_459(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_459)
static void C_ccall f_459r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_558)
static void C_ccall f_558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_564)
static void C_fcall f_564(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_580)
static void C_ccall f_580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_583)
static void C_fcall f_583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_523)
static void C_ccall f_523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_529)
static void C_fcall f_529(C_word t0,C_word t1) C_noret;
C_noret_decl(f_539)
static void C_ccall f_539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_503)
static void C_ccall f_503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_468)
static void C_ccall f_468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_fcall f_474(C_word t0,C_word t1) C_noret;
C_noret_decl(f_484)
static void C_ccall f_484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_396)
static void C_ccall f_396(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_396)
static void C_ccall f_396r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_430)
static void C_ccall f_430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_436)
static void C_fcall f_436(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_446)
static void C_ccall f_446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_402)
static void C_ccall f_402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_408)
static void C_fcall f_408(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_421)
static void C_ccall f_421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_371)
static void C_ccall f_371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_377)
static void C_fcall f_377(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_381)
static void C_ccall f_381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_394)
static void C_ccall f_394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_339)
static void C_ccall f_339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_345)
static void C_fcall f_345(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_349)
static void C_ccall f_349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_369)
static void C_ccall f_369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_315)
static void C_ccall f_315(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_321)
static void C_fcall f_321(C_word t0,C_word t1) C_noret;
C_noret_decl(f_325)
static void C_ccall f_325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_334)
static void C_ccall f_334(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_843)
static void C_fcall trf_843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_843(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_843(t0,t1);}

C_noret_decl(trf_838)
static void C_fcall trf_838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_838(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_838(t0,t1,t2);}

C_noret_decl(trf_833)
static void C_fcall trf_833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_833(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_833(t0,t1,t2,t3);}

C_noret_decl(trf_762)
static void C_fcall trf_762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_762(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_762(t0,t1,t2,t3,t4);}

C_noret_decl(trf_564)
static void C_fcall trf_564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_564(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_564(t0,t1,t2,t3);}

C_noret_decl(trf_583)
static void C_fcall trf_583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_583(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_583(t0,t1);}

C_noret_decl(trf_529)
static void C_fcall trf_529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_529(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_529(t0,t1);}

C_noret_decl(trf_474)
static void C_fcall trf_474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_474(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_474(t0,t1);}

C_noret_decl(trf_436)
static void C_fcall trf_436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_436(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_436(t0,t1,t2);}

C_noret_decl(trf_408)
static void C_fcall trf_408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_408(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_408(t0,t1,t2);}

C_noret_decl(trf_377)
static void C_fcall trf_377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_377(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_377(t0,t1,t2);}

C_noret_decl(trf_345)
static void C_fcall trf_345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_345(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_345(t0,t1,t2);}

C_noret_decl(trf_321)
static void C_fcall trf_321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_321(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_ports_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_ports_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("ports_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(380)){
C_save(t1);
C_rereclaim2(380*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,40);
lf[0]=C_h_intern(&lf[0],13,"port-for-each");
lf[1]=C_h_intern(&lf[1],7,"reverse");
lf[2]=C_h_intern(&lf[2],8,"port-map");
lf[3]=C_h_intern(&lf[3],9,"port-fold");
lf[4]=C_h_intern(&lf[4],19,"make-broadcast-port");
lf[5]=C_h_intern(&lf[5],12,"write-string");
lf[6]=C_h_intern(&lf[6],12,"flush-output");
lf[7]=C_h_intern(&lf[7],16,"make-output-port");
lf[8]=C_h_intern(&lf[8],4,"noop");
lf[9]=C_h_intern(&lf[9],22,"make-concatenated-port");
lf[10]=C_h_intern(&lf[10],18,"\003sysread-char/port");
lf[11]=C_h_intern(&lf[11],11,"char-ready\077");
lf[12]=C_h_intern(&lf[12],9,"peek-char");
lf[13]=C_h_intern(&lf[13],12,"read-string!");
lf[14]=C_h_intern(&lf[14],15,"make-input-port");
lf[15]=C_h_intern(&lf[15],20,"with-input-from-port");
lf[16]=C_h_intern(&lf[16],18,"\003sysstandard-input");
lf[17]=C_h_intern(&lf[17],16,"\003sysdynamic-wind");
lf[18]=C_h_intern(&lf[18],14,"\003syscheck-port");
lf[19]=C_h_intern(&lf[19],19,"with-output-to-port");
lf[20]=C_h_intern(&lf[20],19,"\003sysstandard-output");
lf[21]=C_h_intern(&lf[21],21,"with-output-from-port");
lf[22]=C_h_intern(&lf[22],25,"with-error-output-to-port");
lf[23]=C_h_intern(&lf[23],18,"\003sysstandard-error");
lf[24]=C_h_intern(&lf[24],27,"with-error-output-from-port");
lf[25]=C_h_intern(&lf[25],17,"open-input-string");
lf[26]=C_h_intern(&lf[26],22,"call-with-input-string");
lf[27]=C_h_intern(&lf[27],18,"open-output-string");
lf[28]=C_h_intern(&lf[28],17,"get-output-string");
lf[29]=C_h_intern(&lf[29],23,"call-with-output-string");
lf[30]=C_h_intern(&lf[30],22,"with-input-from-string");
lf[31]=C_h_intern(&lf[31],21,"with-output-to-string");
lf[32]=C_h_intern(&lf[32],18,"\003sysset-port-data!");
lf[33]=C_h_intern(&lf[33],13,"\003sysmake-port");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\010(custom)");
lf[35]=C_h_intern(&lf[35],6,"custom");
lf[36]=C_h_intern(&lf[36],6,"string");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\010(custom)");
lf[38]=C_h_intern(&lf[38],17,"register-feature!");
lf[39]=C_h_intern(&lf[39],5,"ports");
C_register_lf2(lf,40,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_313,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ports.scm: 72   register-feature! */
t3=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[39]);}

/* k311 */
static void C_ccall f_313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_313,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! port-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_315,tmp=(C_word)a,a+=2,tmp));
t3=*((C_word*)lf[1]+1);
t4=C_mutate((C_word*)lf[2]+1 /* (set! port-map ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_339,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[3]+1 /* (set! port-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_371,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[4]+1 /* (set! make-broadcast-port ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_396,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[9]+1 /* (set! make-concatenated-port ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_459,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[15]+1 /* (set! with-input-from-port ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_611,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[19]+1 /* (set! with-output-to-port ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_636,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[22]+1 /* (set! with-error-output-to-port ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_661,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[25]+1);
t12=C_mutate((C_word*)lf[26]+1 /* (set! call-with-input-string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_686,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[27]+1);
t14=*((C_word*)lf[28]+1);
t15=C_mutate((C_word*)lf[29]+1 /* (set! call-with-output-string ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_695,a[2]=t13,a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=*((C_word*)lf[25]+1);
t17=C_mutate((C_word*)lf[30]+1 /* (set! with-input-from-string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_707,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t18=*((C_word*)lf[27]+1);
t19=*((C_word*)lf[28]+1);
t20=C_mutate((C_word*)lf[31]+1 /* (set! with-output-to-string ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_732,a[2]=t18,a[3]=t19,tmp=(C_word)a,a+=4,tmp));
t21=C_mutate((C_word*)lf[14]+1 /* (set! make-input-port ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_760,tmp=(C_word)a,a+=2,tmp));
t22=*((C_word*)lf[36]+1);
t23=C_mutate((C_word*)lf[7]+1 /* (set! make-output-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_903,a[2]=t22,tmp=(C_word)a,a+=3,tmp));
t24=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,C_SCHEME_UNDEFINED);}

/* make-output-port in k311 */
static void C_ccall f_903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+29)){
C_save_and_reclaim((void*)tr4rv,(void*)f_903r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_903r(t0,t1,t2,t3,t4);}}

static void C_ccall f_903r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(29);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_921,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_931,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_937,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_946,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_vector(&a,9,C_SCHEME_FALSE,C_SCHEME_FALSE,t7,t8,t9,t10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t12=(C_word)C_a_i_vector(&a,1,C_SCHEME_FALSE);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_916,a[2]=t12,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 252  ##sys#make-port */
t14=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,C_SCHEME_FALSE,t11,lf[37],lf[35]);}

/* k914 in make-output-port in k311 */
static void C_ccall f_916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_919,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 253  ##sys#set-port-data! */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k917 in k914 in make-output-port in k311 */
static void C_ccall f_919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a945 in make-output-port in k311 */
static void C_ccall f_946(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_946,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* ports.scm: 247  flush */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a936 in make-output-port in k311 */
static void C_ccall f_937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_937,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_941,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 244  close */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k939 in a936 in make-output-port in k311 */
static void C_ccall f_941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(8),C_SCHEME_TRUE));}

/* a930 in make-output-port in k311 */
static void C_ccall f_931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_931,4,t0,t1,t2,t3);}
/* ports.scm: 242  write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a920 in make-output-port in k311 */
static void C_ccall f_921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_921,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_929,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 240  string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k927 in a920 in make-output-port in k311 */
static void C_ccall f_929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm: 240  write */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* make-input-port in k311 */
static void C_ccall f_760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr5r,(void*)f_760r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_760r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_760r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(14);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_762,a[2]=t3,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_833,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_838,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_843,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-peek211254 */
t10=t9;
f_843(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-read-string212252 */
t12=t8;
f_838(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
if(C_truep((C_word)C_i_nullp(t13))){
/* def-read-line213249 */
t14=t7;
f_833(t14,t1,t10,t12);}
else{
t14=(C_word)C_u_i_car(t13);
t15=(C_word)C_slot(t13,C_fix(1));
/* body209218 */
t16=t6;
f_762(t16,t1,t10,t12,t14);}}}}

/* def-peek211 in make-input-port in k311 */
static void C_fcall f_843(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_843,NULL,2,t0,t1);}
/* def-read-string212252 */
t2=((C_word*)t0)[2];
f_838(t2,t1,C_SCHEME_FALSE);}

/* def-read-string212 in make-input-port in k311 */
static void C_fcall f_838(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_838,NULL,3,t0,t1,t2);}
/* def-read-line213249 */
t3=((C_word*)t0)[2];
f_833(t3,t1,t2,C_SCHEME_FALSE);}

/* def-read-line213 in make-input-port in k311 */
static void C_fcall f_833(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_833,NULL,4,t0,t1,t2,t3);}
/* body209218 */
t4=((C_word*)t0)[2];
f_762(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body209 in make-input-port in k311 */
static void C_fcall f_762(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_762,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_777,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_798,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_819,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_828,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_vector(&a,9,t5,t6,C_SCHEME_FALSE,C_SCHEME_FALSE,t7,C_SCHEME_FALSE,t8,t3,t4);
t10=(C_word)C_a_i_vector(&a,1,C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_772,a[2]=t10,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 228  ##sys#make-port */
t12=*((C_word*)lf[33]+1);
((C_proc6)(void*)(*((C_word*)t12+1)))(6,t12,t11,C_SCHEME_TRUE,t9,lf[34],lf[35]);}

/* k770 in body209 in make-input-port in k311 */
static void C_ccall f_772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_775,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 229  ##sys#set-port-data! */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k773 in k770 in body209 in make-input-port in k311 */
static void C_ccall f_775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a827 in body209 in make-input-port in k311 */
static void C_ccall f_828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_828,3,t0,t1,t2);}
/* ports.scm: 224  ready? */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a818 in body209 in make-input-port in k311 */
static void C_ccall f_819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_819,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_823,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 220  close */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k821 in a818 in body209 in make-input-port in k311 */
static void C_ccall f_823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(8),C_SCHEME_TRUE));}

/* a797 in body209 in make-input-port in k311 */
static void C_ccall f_798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_798,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(10));
if(C_truep(((C_word*)t0)[3])){
/* ports.scm: 211  peek */
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_814,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 214  read */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

/* k812 in a797 in body209 in make-input-port in k311 */
static void C_ccall f_814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(10),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a776 in body209 in make-input-port in k311 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_777,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(10));
if(C_truep(((C_word*)t0)[3])){
/* ports.scm: 204  read */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
if(C_truep(t3)){
t4=(C_word)C_i_set_i_slot(t2,C_fix(10),C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* ports.scm: 208  read */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}}}

/* with-output-to-string in k311 */
static void C_ccall f_732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_732,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_736,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ports.scm: 187  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k734 in with-output-to-string in k311 */
static void C_ccall f_736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_736,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_741,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_746,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_755,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a754 in k734 in with-output-to-string in k311 */
static void C_ccall f_755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_755,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[20]+1));
t3=C_mutate((C_word*)lf[20]+1 /* (set! standard-output ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a745 in k734 in with-output-to-string in k311 */
static void C_ccall f_746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_750,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 188  thunk */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k748 in a745 in k734 in with-output-to-string in k311 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm: 189  get-output-string */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[20]+1));}

/* a740 in k734 in with-output-to-string in k311 */
static void C_ccall f_741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_741,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[20]+1));
t3=C_mutate((C_word*)lf[20]+1 /* (set! standard-output ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* with-input-from-string in k311 */
static void C_ccall f_707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_707,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_711,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 180  open-input-string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k709 in with-input-from-string in k311 */
static void C_ccall f_711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_711,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_716,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_721,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_727,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a726 in k709 in with-input-from-string in k311 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_727,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[16]+1));
t3=C_mutate((C_word*)lf[16]+1 /* (set! standard-input ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a720 in k709 in with-input-from-string in k311 */
static void C_ccall f_721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_721,2,t0,t1);}
/* ports.scm: 181  thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a715 in k709 in with-input-from-string in k311 */
static void C_ccall f_716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_716,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[16]+1));
t3=C_mutate((C_word*)lf[16]+1 /* (set! standard-input ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* call-with-output-string in k311 */
static void C_ccall f_695(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_695,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_699,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ports.scm: 173  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k697 in call-with-output-string in k311 */
static void C_ccall f_699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_702,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ports.scm: 174  proc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k700 in k697 in call-with-output-string in k311 */
static void C_ccall f_702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm: 175  get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-input-string in k311 */
static void C_ccall f_686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_686,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_690,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 166  open-input-string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k688 in call-with-input-string in k311 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm: 167  proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* with-error-output-to-port in k311 */
static void C_ccall f_661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_661,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_665,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ports.scm: 157  ##sys#check-port */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[24]);}

/* k663 in with-error-output-to-port in k311 */
static void C_ccall f_665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_665,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_670,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_675,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_681,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a680 in k663 in with-error-output-to-port in k311 */
static void C_ccall f_681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_681,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[23]+1));
t3=C_mutate((C_word*)lf[23]+1 /* (set! standard-error ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a674 in k663 in with-error-output-to-port in k311 */
static void C_ccall f_675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_675,2,t0,t1);}
/* ports.scm: 159  thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a669 in k663 in with-error-output-to-port in k311 */
static void C_ccall f_670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_670,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[23]+1));
t3=C_mutate((C_word*)lf[23]+1 /* (set! standard-error ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* with-output-to-port in k311 */
static void C_ccall f_636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_636,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_640,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ports.scm: 152  ##sys#check-port */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[21]);}

/* k638 in with-output-to-port in k311 */
static void C_ccall f_640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_640,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_645,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_650,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_656,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a655 in k638 in with-output-to-port in k311 */
static void C_ccall f_656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_656,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[20]+1));
t3=C_mutate((C_word*)lf[20]+1 /* (set! standard-output ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a649 in k638 in with-output-to-port in k311 */
static void C_ccall f_650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_650,2,t0,t1);}
/* ports.scm: 154  thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a644 in k638 in with-output-to-port in k311 */
static void C_ccall f_645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_645,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[20]+1));
t3=C_mutate((C_word*)lf[20]+1 /* (set! standard-output ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* with-input-from-port in k311 */
static void C_ccall f_611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_611,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_615,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ports.scm: 147  ##sys#check-port */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[15]);}

/* k613 in with-input-from-port in k311 */
static void C_ccall f_615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_615,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_620,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_625,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_631,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a630 in k613 in with-input-from-port in k311 */
static void C_ccall f_631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_631,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[16]+1));
t3=C_mutate((C_word*)lf[16]+1 /* (set! standard-input ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a624 in k613 in with-input-from-port in k311 */
static void C_ccall f_625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_625,2,t0,t1);}
/* ports.scm: 149  thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a619 in k613 in with-input-from-port in k311 */
static void C_ccall f_620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_620,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[16]+1));
t3=C_mutate((C_word*)lf[16]+1 /* (set! standard-input ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* make-concatenated-port in k311 */
static void C_ccall f_459(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_459r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_459r(t0,t1,t2,t3);}}

static void C_ccall f_459r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(17);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_468,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_503,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_523,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_558,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ports.scm: 110  make-input-port */
t11=*((C_word*)lf[14]+1);
((C_proc7)(void*)(*((C_word*)t11+1)))(7,t11,t1,t7,t8,*((C_word*)lf[8]+1),t9,t10);}

/* a557 in make-concatenated-port in k311 */
static void C_ccall f_558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_558,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_564,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_564(t9,t1,t3,C_fix(0));}

/* loop in a557 in make-concatenated-port in k311 */
static void C_fcall f_564(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_564,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[5])[1]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_580,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[5])[1]);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t3);
/* ports.scm: 138  read-string! */
t7=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,t2,((C_word*)t0)[2],t5,t6);}}}

/* k578 in loop in a557 in make-concatenated-port in k311 */
static void C_ccall f_580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_583(t5,t4);}
else{
t3=t2;
f_583(t3,C_SCHEME_UNDEFINED);}}

/* k581 in k578 in loop in a557 in make-concatenated-port in k311 */
static void C_fcall f_583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],((C_word*)t0)[5]);
/* ports.scm: 141  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_564(t4,((C_word*)t0)[2],t2,t3);}

/* a522 in make-concatenated-port in k311 */
static void C_ccall f_523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_523,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_529,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_529(t5,t1);}

/* loop in a522 in make-concatenated-port in k311 */
static void C_fcall f_529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_529,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_539,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* ports.scm: 128  peek-char */
t4=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* k537 in loop in a522 in make-concatenated-port in k311 */
static void C_ccall f_539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_slot(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* ports.scm: 131  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_529(t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* a502 in make-concatenated-port in k311 */
static void C_ccall f_503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_503,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* ports.scm: 122  char-ready? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}}

/* a467 in make-concatenated-port in k311 */
static void C_ccall f_468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_468,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_474,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_474(t5,t1);}

/* loop in a467 in make-concatenated-port in k311 */
static void C_fcall f_474(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_474,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_484,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* read-char/port */
t4=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* k482 in loop in a467 in make-concatenated-port in k311 */
static void C_ccall f_484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_slot(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* ports.scm: 118  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_474(t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* make-broadcast-port in k311 */
static void C_ccall f_396(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_396r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_396r(t0,t1,t2);}}

static void C_ccall f_396r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_402,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_430,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ports.scm: 103  make-output-port */
t5=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t3,*((C_word*)lf[8]+1),t4);}

/* a429 in make-broadcast-port in k311 */
static void C_ccall f_430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_430,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_436,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_436(t5,t1,((C_word*)t0)[2]);}

/* loop54 in a429 in make-broadcast-port in k311 */
static void C_fcall f_436(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_436,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_446,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* flush-output */
t5=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k444 in loop54 in a429 in make-broadcast-port in k311 */
static void C_ccall f_446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_436(t3,((C_word*)t0)[2],t2);}

/* a401 in make-broadcast-port in k311 */
static void C_ccall f_402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_402,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_408,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_408(t6,t1,((C_word*)t0)[2]);}

/* loop38 in a401 in make-broadcast-port in k311 */
static void C_fcall f_408(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_408,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_421,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* write-string */
t5=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],C_SCHEME_FALSE,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k419 in loop38 in a401 in make-broadcast-port in k311 */
static void C_ccall f_421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_408(t3,((C_word*)t0)[2],t2);}

/* port-fold in k311 */
static void C_ccall f_371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_371,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_377,a[2]=t4,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_377(t8,t1,t3);}

/* loop in port-fold in k311 */
static void C_fcall f_377(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_377,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_381,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ports.scm: 95   thunk */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k379 in loop in port-fold in k311 */
static void C_ccall f_381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_381,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_394,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 98   fn */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[4]);}}

/* k392 in k379 in loop in port-fold in k311 */
static void C_ccall f_394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm: 98   loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_377(t2,((C_word*)t0)[2],t1);}

/* port-map in k311 */
static void C_ccall f_339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_339,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_345,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_345(t7,t1,C_SCHEME_END_OF_LIST);}

/* loop in port-map in k311 */
static void C_fcall f_345(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_345,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_349,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ports.scm: 88   thunk */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k347 in loop in port-map in k311 */
static void C_ccall f_349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_349,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* ports.scm: 90   reverse */
t2=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_369,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ports.scm: 91   fn */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k367 in k347 in loop in port-map in k311 */
static void C_ccall f_369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_369,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* ports.scm: 91   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_345(t3,((C_word*)t0)[2],t2);}

/* port-for-each in k311 */
static void C_ccall f_315(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_315,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_321,a[2]=t3,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_321(t7,t1);}

/* loop in port-for-each in k311 */
static void C_fcall f_321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_321,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_325,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ports.scm: 79   thunk */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k323 in loop in port-for-each in k311 */
static void C_ccall f_325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_325,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_334,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm: 81   fn */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k332 in k323 in loop in port-for-each in k311 */
static void C_ccall f_334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm: 82   loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_321(t2,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[87] = {
{"toplevel:ports_scm",(void*)C_ports_toplevel},
{"f_313:ports_scm",(void*)f_313},
{"f_903:ports_scm",(void*)f_903},
{"f_916:ports_scm",(void*)f_916},
{"f_919:ports_scm",(void*)f_919},
{"f_946:ports_scm",(void*)f_946},
{"f_937:ports_scm",(void*)f_937},
{"f_941:ports_scm",(void*)f_941},
{"f_931:ports_scm",(void*)f_931},
{"f_921:ports_scm",(void*)f_921},
{"f_929:ports_scm",(void*)f_929},
{"f_760:ports_scm",(void*)f_760},
{"f_843:ports_scm",(void*)f_843},
{"f_838:ports_scm",(void*)f_838},
{"f_833:ports_scm",(void*)f_833},
{"f_762:ports_scm",(void*)f_762},
{"f_772:ports_scm",(void*)f_772},
{"f_775:ports_scm",(void*)f_775},
{"f_828:ports_scm",(void*)f_828},
{"f_819:ports_scm",(void*)f_819},
{"f_823:ports_scm",(void*)f_823},
{"f_798:ports_scm",(void*)f_798},
{"f_814:ports_scm",(void*)f_814},
{"f_777:ports_scm",(void*)f_777},
{"f_732:ports_scm",(void*)f_732},
{"f_736:ports_scm",(void*)f_736},
{"f_755:ports_scm",(void*)f_755},
{"f_746:ports_scm",(void*)f_746},
{"f_750:ports_scm",(void*)f_750},
{"f_741:ports_scm",(void*)f_741},
{"f_707:ports_scm",(void*)f_707},
{"f_711:ports_scm",(void*)f_711},
{"f_727:ports_scm",(void*)f_727},
{"f_721:ports_scm",(void*)f_721},
{"f_716:ports_scm",(void*)f_716},
{"f_695:ports_scm",(void*)f_695},
{"f_699:ports_scm",(void*)f_699},
{"f_702:ports_scm",(void*)f_702},
{"f_686:ports_scm",(void*)f_686},
{"f_690:ports_scm",(void*)f_690},
{"f_661:ports_scm",(void*)f_661},
{"f_665:ports_scm",(void*)f_665},
{"f_681:ports_scm",(void*)f_681},
{"f_675:ports_scm",(void*)f_675},
{"f_670:ports_scm",(void*)f_670},
{"f_636:ports_scm",(void*)f_636},
{"f_640:ports_scm",(void*)f_640},
{"f_656:ports_scm",(void*)f_656},
{"f_650:ports_scm",(void*)f_650},
{"f_645:ports_scm",(void*)f_645},
{"f_611:ports_scm",(void*)f_611},
{"f_615:ports_scm",(void*)f_615},
{"f_631:ports_scm",(void*)f_631},
{"f_625:ports_scm",(void*)f_625},
{"f_620:ports_scm",(void*)f_620},
{"f_459:ports_scm",(void*)f_459},
{"f_558:ports_scm",(void*)f_558},
{"f_564:ports_scm",(void*)f_564},
{"f_580:ports_scm",(void*)f_580},
{"f_583:ports_scm",(void*)f_583},
{"f_523:ports_scm",(void*)f_523},
{"f_529:ports_scm",(void*)f_529},
{"f_539:ports_scm",(void*)f_539},
{"f_503:ports_scm",(void*)f_503},
{"f_468:ports_scm",(void*)f_468},
{"f_474:ports_scm",(void*)f_474},
{"f_484:ports_scm",(void*)f_484},
{"f_396:ports_scm",(void*)f_396},
{"f_430:ports_scm",(void*)f_430},
{"f_436:ports_scm",(void*)f_436},
{"f_446:ports_scm",(void*)f_446},
{"f_402:ports_scm",(void*)f_402},
{"f_408:ports_scm",(void*)f_408},
{"f_421:ports_scm",(void*)f_421},
{"f_371:ports_scm",(void*)f_371},
{"f_377:ports_scm",(void*)f_377},
{"f_381:ports_scm",(void*)f_381},
{"f_394:ports_scm",(void*)f_394},
{"f_339:ports_scm",(void*)f_339},
{"f_345:ports_scm",(void*)f_345},
{"f_349:ports_scm",(void*)f_349},
{"f_369:ports_scm",(void*)f_369},
{"f_315:ports_scm",(void*)f_315},
{"f_321:ports_scm",(void*)f_321},
{"f_325:ports_scm",(void*)f_325},
{"f_334:ports_scm",(void*)f_334},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
