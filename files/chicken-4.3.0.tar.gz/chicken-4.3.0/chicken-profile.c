/* Generated from chicken-profile.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:03
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: chicken-profile.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -output-file chicken-profile.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 srfi_13 srfi_69 posix utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[91];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_216)
static void C_ccall f_216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_219)
static void C_ccall f_219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_222)
static void C_ccall f_222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_225)
static void C_ccall f_225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_228)
static void C_ccall f_228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_231)
static void C_ccall f_231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_234)
static void C_ccall f_234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_237)
static void C_ccall f_237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_240)
static void C_ccall f_240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_243)
static void C_ccall f_243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_246)
static void C_ccall f_246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_302)
static void C_fcall f_302(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_504)
static void C_fcall f_504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_694)
static void C_ccall f_694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_655)
static void C_fcall f_655(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_665)
static void C_ccall f_665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_457)
static void C_ccall f_457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_440)
static void C_ccall f_440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_433)
static void C_ccall f_433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_424)
static void C_ccall f_424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_417)
static void C_ccall f_417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_399)
static void C_ccall f_399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_376)
static void C_fcall f_376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_396)
static void C_ccall f_396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_357)
static void C_fcall f_357(C_word t0,C_word t1) C_noret;
C_noret_decl(f_319)
static void C_ccall f_319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_337)
static void C_ccall f_337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_345)
static void C_ccall f_345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_349)
static void C_ccall f_349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_335)
static void C_ccall f_335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_322)
static void C_ccall f_322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_312)
static void C_fcall f_312(C_word t0,C_word t1) C_noret;
C_noret_decl(f_914)
static void C_ccall f_914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_920)
static void C_ccall f_920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1144)
static void C_fcall f_1144(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1151)
static void C_fcall f_1151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1124)
static void C_ccall f_1124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1112)
static void C_ccall f_1112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1116)
static void C_ccall f_1116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_926)
static void C_fcall f_926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1056)
static void C_ccall f_1056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_930)
static void C_ccall f_930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_942)
static void C_ccall f_942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_992)
static void C_ccall f_992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_962)
static void C_ccall f_962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_967)
static void C_fcall f_967(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_944)
static void C_fcall f_944(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_956)
static void C_ccall f_956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1189)
static void C_ccall f_1189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_854)
static void C_fcall f_854(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_865)
static void C_ccall f_865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_873)
static void C_ccall f_873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_774)
static void C_ccall f_774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_774)
static void C_ccall f_774r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_806)
static void C_fcall f_806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_801)
static void C_fcall f_801(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_776)
static void C_fcall f_776(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_783)
static void C_ccall f_783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_707)
static void C_ccall f_707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_711)
static void C_ccall f_711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_721)
static void C_ccall f_721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_723)
static void C_fcall f_723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_748)
static void C_ccall f_748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_733)
static void C_ccall f_733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_714)
static void C_ccall f_714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_623)
static void C_ccall f_623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_631)
static void C_ccall f_631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_635)
static void C_ccall f_635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_594)
static void C_ccall f_594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_565)
static void C_ccall f_565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_530)
static void C_ccall f_530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_255)
static void C_fcall f_255(C_word t0) C_noret;
C_noret_decl(f_266)
static void C_ccall f_266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_259)
static void C_ccall f_259(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_302)
static void C_fcall trf_302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_302(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_302(t0,t1,t2);}

C_noret_decl(trf_504)
static void C_fcall trf_504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_504(t0,t1);}

C_noret_decl(trf_655)
static void C_fcall trf_655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_655(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_655(t0,t1,t2);}

C_noret_decl(trf_376)
static void C_fcall trf_376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_376(t0,t1);}

C_noret_decl(trf_357)
static void C_fcall trf_357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_357(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_357(t0,t1);}

C_noret_decl(trf_312)
static void C_fcall trf_312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_312(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_312(t0,t1);}

C_noret_decl(trf_1144)
static void C_fcall trf_1144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1144(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1144(t0,t1);}

C_noret_decl(trf_1151)
static void C_fcall trf_1151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1151(t0,t1);}

C_noret_decl(trf_926)
static void C_fcall trf_926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_926(t0,t1);}

C_noret_decl(trf_967)
static void C_fcall trf_967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_967(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_967(t0,t1,t2);}

C_noret_decl(trf_944)
static void C_fcall trf_944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_944(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_944(t0,t1,t2);}

C_noret_decl(trf_854)
static void C_fcall trf_854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_854(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_854(t0,t1,t2);}

C_noret_decl(trf_806)
static void C_fcall trf_806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_806(t0,t1);}

C_noret_decl(trf_801)
static void C_fcall trf_801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_801(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_801(t0,t1,t2);}

C_noret_decl(trf_776)
static void C_fcall trf_776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_776(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_776(t0,t1,t2,t3);}

C_noret_decl(trf_723)
static void C_fcall trf_723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_723(t0,t1,t2);}

C_noret_decl(trf_255)
static void C_fcall trf_255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_255(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_255(t0);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(386)){
C_save(t1);
C_rereclaim2(386*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,91);
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],7,"display");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\001\242)\012 -no-unused                remove procedures that are never called\012 -top "
"N                    display only the top N entries\012 -help                     s"
"how this text and exit\012 -version                  show version and exit\012 -releas"
"e                  show release number and exit\012\012 FILENAME defaults to the `PROF"
"ILE.<number>\047, selecting the one with\012 the highest modification time, in case mu"
"ltiple profiles exist.\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\001\315Usage: chicken-profile [FILENAME | OPTION] ...\012\012 -sort-by-calls            "
"sort output by call frequency\012 -sort-by-time             sort output by procedur"
"e execution time\012 -sort-by-avg              sort output by average procedure exe"
"cution time\012 -sort-by-name             sort output alphabetically by procedure n"
"ame\012 -decimals DDD             set number of decimals for seconds, average and\012 "
"                          percent columns (three digits, default: ");
lf[14]=C_h_intern(&lf[14],19,"\003sysprint-to-string");
lf[19]=C_h_intern(&lf[19],8,"string<\077");
lf[20]=C_h_intern(&lf[20],14,"symbol->string");
lf[22]=C_h_intern(&lf[22],17,"hash-table->alist");
lf[23]=C_h_intern(&lf[23],4,"read");
lf[24]=C_h_intern(&lf[24],15,"hash-table-set!");
lf[25]=C_h_intern(&lf[25],3,"map");
lf[26]=C_h_intern(&lf[26],22,"hash-table-ref/default");
lf[27]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\000\376\377\016");
lf[28]=C_h_intern(&lf[28],15,"make-hash-table");
lf[29]=C_h_intern(&lf[29],3,"eq\077");
lf[31]=C_h_intern(&lf[31],13,"string-append");
lf[32]=C_h_intern(&lf[32],11,"make-string");
lf[33]=C_h_intern(&lf[33],9,"\003syserror");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_h_intern(&lf[38],9,"substring");
lf[39]=C_h_intern(&lf[39],8,"truncate");
lf[40]=C_h_intern(&lf[40],4,"expt");
lf[41]=C_h_intern(&lf[41],25,"\003sysimplicit-exit-handler");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\011procedure");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005calls");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\007seconds");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\007average");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\007percent");
lf[47]=C_h_intern(&lf[47],5,"print");
lf[48]=C_h_intern(&lf[48],11,"string-join");
lf[49]=C_h_intern(&lf[49],6,"reduce");
lf[50]=C_h_intern(&lf[50],1,"+");
lf[51]=C_h_intern(&lf[51],3,"max");
lf[52]=C_h_intern(&lf[52],7,"\003sysmap");
lf[53]=C_h_intern(&lf[53],13,"string-length");
lf[54]=C_h_intern(&lf[54],4,"fold");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\010overflow");
lf[56]=C_h_intern(&lf[56],28,"\003syssymbol->qualified-string");
lf[57]=C_h_intern(&lf[57],6,"remove");
lf[58]=C_h_intern(&lf[58],4,"take");
lf[59]=C_h_intern(&lf[59],4,"sort");
lf[60]=C_h_intern(&lf[60],6,"append");
lf[61]=C_h_intern(&lf[61],20,"with-input-from-file");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\011reading `");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\006\047 ...\012");
lf[64]=C_h_intern(&lf[64],5,"error");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\021no PROFILEs found");
lf[66]=C_h_intern(&lf[66],22,"file-modification-time");
lf[67]=C_h_intern(&lf[67],4,"glob");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\011PROFILE.*");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\032missing argument to option");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid argument to option");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\032chicken-profile - Version ");
lf[77]=C_h_intern(&lf[77],15,"chicken-version");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\012-no-unused");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\004-top");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\016-sort-by-calls");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-time");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\014-sort-by-avg");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-name");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\011-decimals");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[90]=C_h_intern(&lf[90],22,"command-line-arguments");
C_register_lf2(lf,91,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_216,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k214 */
static void C_ccall f_216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k217 in k214 */
static void C_ccall f_219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_222,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k220 in k217 in k214 */
static void C_ccall f_222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_225,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k223 in k220 in k217 in k214 */
static void C_ccall f_225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_228,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_231,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_234,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_237,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_240,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_243,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_246,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_246,2,t0,t1);}
t2=lf[0] /* sort-by */ =C_SCHEME_FALSE;;
t3=lf[1] /* file */ =C_SCHEME_FALSE;;
t4=lf[2] /* no-unused */ =C_SCHEME_FALSE;;
t5=lf[3] /* seconds-digits */ =C_fix(3);;
t6=lf[4] /* average-digits */ =C_fix(3);;
t7=lf[5] /* percent-digits */ =C_fix(3);;
t8=lf[6] /* top */ =C_fix(0);;
t9=C_mutate(&lf[7] /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_255,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[15] /* (set! sort-by-calls ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_530,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[16] /* (set! sort-by-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_565,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[17] /* (set! sort-by-avg ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_594,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[18] /* (set! sort-by-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_623,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[0] /* (set! sort-by ...) */,C_retrieve2(lf[16],"sort-by-time"));
t15=C_mutate(&lf[21] /* (set! read-profile ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_707,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[30] /* (set! format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_774,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[35] /* (set! format-real ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_854,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1186,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1196,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 234  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[90]))(2,*((C_word*)lf[90]+1),t19);}

/* k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1196,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_302,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_302(t5,((C_word*)t0)[2],t1);}

/* loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_302(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_302,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_312,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[1],"file"))){
t4=t3;
f_312(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_319,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 73   glob */
((C_proc3)C_retrieve_symbol_proc(lf[67]))(3,*((C_word*)lf[67]+1),t4,lf[68]);}}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_357,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_376,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_399,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[71]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[72]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[73]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
/* chicken-profile.scm: 93   print-usage */
f_255(t9);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[74]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[75]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_417,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_424,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 95   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t11);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[78]))){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_433,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_440,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 98   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t11);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[79]))){
t10=lf[2] /* no-unused */ =C_SCHEME_TRUE;;
t11=t9;
f_399(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[80]))){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_457,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 101  next-number */
t11=t8;
f_376(t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[81]))){
t10=C_mutate(&lf[0] /* (set! sort-by ...) */,C_retrieve2(lf[15],"sort-by-calls"));
t11=t9;
f_399(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[82]))){
t10=C_mutate(&lf[0] /* (set! sort-by ...) */,C_retrieve2(lf[16],"sort-by-time"));
t11=t9;
f_399(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[83]))){
t10=C_mutate(&lf[0] /* (set! sort-by ...) */,C_retrieve2(lf[17],"sort-by-avg"));
t11=t9;
f_399(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[84]))){
t10=C_mutate(&lf[0] /* (set! sort-by ...) */,C_retrieve2(lf[18],"sort-by-name"));
t11=t9;
f_399(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[85]))){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_498,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 106  next-arg */
t11=t7;
f_357(t11,t10);}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_504,a[2]=t3,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_string_length(t3);
if(C_truep((C_word)C_i_greaterp(t11,C_fix(1)))){
t12=(C_word)C_i_string_ref(t3,C_fix(0));
t13=t10;
f_504(t13,(C_word)C_eqp(C_make_character(45),t12));}
else{
t12=t10;
f_504(t12,C_SCHEME_FALSE);}}}}}}}}}}}}}

/* k502 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* chicken-profile.scm: 108  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[3],lf[89],((C_word*)t0)[2]);}
else{
if(C_truep(C_retrieve2(lf[1],"file"))){
/* chicken-profile.scm: 109  print-usage */
f_255(((C_word*)t0)[3]);}
else{
t2=C_mutate(&lf[1] /* (set! file ...) */,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_399(2,t3,t2);}}}

/* k496 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_498,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_nequalp(t2,C_fix(3)))){
t3=C_mutate(&lf[86] /* (set! arg-digit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_655,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_690,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 148  arg-digit */
t5=C_retrieve2(lf[86],"arg-digit");
f_655(t5,t4,C_fix(0));}
else{
/* chicken-profile.scm: 151  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[2],lf[88],t1);}}

/* k688 in k496 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_690,2,t0,t1);}
t2=C_mutate(&lf[3] /* (set! seconds-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_694,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 149  arg-digit */
t4=C_retrieve2(lf[86],"arg-digit");
f_655(t4,t3,C_fix(1));}

/* k692 in k688 in k496 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_694,2,t0,t1);}
t2=C_mutate(&lf[4] /* (set! average-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_698,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 150  arg-digit */
t4=C_retrieve2(lf[86],"arg-digit");
f_655(t4,t3,C_fix(2));}

/* k696 in k692 in k688 in k496 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[5] /* (set! percent-digits ...) */,t1);
t3=((C_word*)t0)[2];
f_399(2,t3,t2);}

/* arg-digit in k496 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_655(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_655,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(48));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_665,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 145  <= */
C_less_or_equal_p(5,0,t6,C_fix(0),t5,C_fix(9));}

/* k663 in arg-digit in k496 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_nequalp(((C_word*)t0)[4],C_fix(9));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_fix(8):((C_word*)t0)[4]));}
else{
/* chicken-profile.scm: 147  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[3],lf[87],((C_word*)t0)[2]);}}

/* k455 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[6] /* (set! top ...) */,t1);
t3=((C_word*)t0)[2];
f_399(2,t3,t2);}

/* k438 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 98   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* k431 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 99   exit */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),((C_word*)t0)[2]);}

/* k422 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 95   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[47]+1)))(4,*((C_word*)lf[47]+1),((C_word*)t0)[2],lf[76],t1);}

/* k415 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 96   exit */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),((C_word*)t0)[2]);}

/* k397 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 111  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_302(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* next-number in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_376,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_380,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_396,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 90   next-arg */
t4=((C_word*)t0)[2];
f_357(t4,t3);}

/* k394 in next-number in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 90   string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k378 in next-number in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_greaterp(t1,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* chicken-profile.scm: 91   error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[3],lf[70],((C_word*)t0)[2]);}}

/* next-arg in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_357(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_357,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* chicken-profile.scm: 85   error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t1,lf[69],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k317 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-profile.scm: 75   error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[64]+1)))(3,*((C_word*)lf[64]+1),t2,lf[65]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_335,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_337,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 76   sort */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),t3,t1,t4);}}

/* a336 in k317 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_337,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_345,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 78   file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t4,t2);}

/* k343 in a336 in k317 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_349,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 79   file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k347 in k343 in a336 in k317 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_greaterp(((C_word*)t0)[2],t1));}

/* k333 in k317 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_322(2,t2,(C_word)C_i_car(t1));}

/* k320 in k317 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[1] /* (set! file ...) */,t1);
t3=((C_word*)t0)[2];
f_312(t3,t2);}

/* k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_312(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_312,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_914,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 184  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[47]+1)))(5,*((C_word*)lf[47]+1),t3,lf[62],C_retrieve2(lf[1],"file"),lf[63]);}

/* k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 185  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t2,C_retrieve2(lf[1],"file"),C_retrieve2(lf[21],"read-profile"));}

/* k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_920,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1175,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 186  fold */
((C_proc5)C_retrieve_symbol_proc(lf[54]))(5,*((C_word*)lf[54]+1),t2,t3,C_fix(0),t1);}

/* a1174 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1175,4,t0,t1,t2,t3);}
t4=(C_word)C_i_caddr(t2);
/* chicken-profile.scm: 187  max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),t1,t4,t3);}

/* k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_923,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1124,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1126,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1125 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1126,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_caddr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1144,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_greaterp(t3,C_fix(0));
t7=t5;
f_1144(t7,(C_truep(t6)?(C_word)C_a_i_divide(&a,2,t4,t3):C_SCHEME_FALSE));}
else{
t6=t5;
f_1144(t6,C_SCHEME_FALSE);}}

/* k1142 in a1125 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_1144(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1144,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1151,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
t4=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t5=t3;
f_1151(t5,(C_word)C_a_i_times(&a,2,t4,C_fix(100)));}
else{
t4=t3;
f_1151(t4,C_SCHEME_FALSE);}}

/* k1149 in k1142 in a1125 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_1151(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1151,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t2);
/* chicken-profile.scm: 191  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[60]+1)))(4,*((C_word*)lf[60]+1),((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1122 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 190  sort */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[0],"sort-by"));}

/* k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_923,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_926,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1112,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_length(((C_word*)t3)[1]);
/* chicken-profile.scm: 200  < */
C_lessp(5,0,t5,C_fix(0),C_retrieve2(lf[6],"top"),t6);}

/* k1110 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1112,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 201  take */
((C_proc4)C_retrieve_symbol_proc(lf[58]))(4,*((C_word*)lf[58]+1),t2,((C_word*)((C_word*)t0)[3])[1],C_retrieve2(lf[6],"top"));}
else{
t2=((C_word*)t0)[2];
f_926(t2,C_SCHEME_UNDEFINED);}}

/* k1114 in k1110 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_926(t3,t2);}

/* k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_926,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1032,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1090,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1092,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 212  remove */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t4,t5,((C_word*)((C_word*)t0)[3])[1]);}

/* a1091 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1092,3,t0,t1,t2);}
if(C_truep((C_word)C_i_cadr(t2))){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_zerop(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_retrieve2(lf[2],"no-unused"):C_SCHEME_FALSE));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1088 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1031 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1032,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_caddr(t2);
t5=(C_word)C_i_cadddr(t2);
t6=(C_word)C_i_list_ref(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1052,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
/* chicken-profile.scm: 207  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[56]))(3,*((C_word*)lf[56]+1),t7,t8);}

/* k1050 in a1031 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1056,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
/* chicken-profile.scm: 208  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1056(2,t3,lf[55]);}}

/* k1054 in k1050 in a1031 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm: 209  format-real */
f_854(t2,t3,C_retrieve2(lf[3],"seconds-digits"));}

/* k1058 in k1054 in k1050 in a1031 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1064,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm: 210  format-real */
f_854(t2,t3,C_retrieve2(lf[4],"average-digits"));}

/* k1062 in k1058 in k1054 in k1050 in a1031 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1068,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm: 211  format-real */
f_854(t2,((C_word*)t0)[2],C_retrieve2(lf[5],"percent-digits"));}

/* k1066 in k1062 in k1058 in k1054 in k1050 in a1031 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1068,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_930,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_a_i_list(&a,5,lf[42],lf[43],lf[44],lf[45],lf[46]);
t4=(C_word)C_a_i_list(&a,5,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_939,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 220  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[32]+1)))(4,*((C_word*)lf[32]+1),t5,C_fix(2),C_make_character(32));}

/* k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1014,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_a_i_list(&a,5,C_fix(0),C_fix(0),C_fix(0),C_fix(0),C_fix(0));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
/* chicken-profile.scm: 221  fold */
((C_proc5)C_retrieve_symbol_proc(lf[54]))(5,*((C_word*)lf[54]+1),t2,t3,t4,t5);}

/* a1013 in k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1014,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1022,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[53]+1),t2);}

/* k1020 in a1013 in k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 223  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[25]+1)))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],*((C_word*)lf[51]+1),t1,((C_word*)t0)[2]);}

/* k940 in k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_944,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_959,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm: 228  print-row */
t4=t2;
f_944(t4,t3,((C_word*)t0)[2]);}

/* k957 in k940 in k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_962,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_992,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1000,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 229  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[49]))(5,*((C_word*)lf[49]+1),t4,*((C_word*)lf[50]+1),C_fix(0),((C_word*)t0)[2]);}

/* k998 in k957 in k940 in k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1000,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t4=(C_word)C_a_i_times(&a,2,C_fix(2),t3);
t5=(C_word)C_a_i_plus(&a,2,t1,t4);
/* chicken-profile.scm: 229  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[32]+1)))(4,*((C_word*)lf[32]+1),((C_word*)t0)[2],t5,C_make_character(45));}

/* k990 in k957 in k940 in k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 229  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* k960 in k957 in k940 in k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_962,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_967,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_967(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* loop164 in k960 in k957 in k940 in k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_967(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_967,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_977,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* print-row160 */
t5=((C_word*)t0)[2];
f_944(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k975 in loop164 in k960 in k957 in k940 in k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_967(t3,((C_word*)t0)[2],t2);}

/* print-row in k940 in k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_944(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_944,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_952,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_956,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 227  map */
((C_proc6)C_retrieve_proc(*((C_word*)lf[25]+1)))(6,*((C_word*)lf[25]+1),t4,C_retrieve2(lf[30],"format-string"),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k954 in print-row in k940 in k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 227  string-join */
((C_proc4)C_retrieve_symbol_proc(lf[48]))(4,*((C_word*)lf[48]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k950 in print-row in k940 in k937 in k928 in k924 in k921 in k918 in k915 in k912 in k310 in loop in k1194 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 227  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* k1184 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1189,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1192,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[41]))(2,*((C_word*)lf[41]+1),t3);}

/* k1190 in k1184 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1187 in k1184 in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_1189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format-real in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_854(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_854,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_908,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 172  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),t4,t2);}

/* k906 in format-real in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_908,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_865,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 174  number->string */
C_number_to_string(3,0,t3,t2);}

/* k863 in k906 in format-real in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_865,2,t0,t1);}
t2=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(0));
t3=(C_truep(t2)?lf[36]:lf[37]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_873,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_877,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_889,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_897,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 180  - */
C_minus(5,0,t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(-1));}

/* k895 in k863 in k906 in format-real in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_901,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 180  expt */
((C_proc4)C_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t2,C_fix(10),((C_word*)t0)[2]);}

/* k899 in k895 in k863 in k906 in format-real in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_901,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],t1);
/* chicken-profile.scm: 179  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t2);}

/* k887 in k863 in k906 in format-real in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(t1);
/* chicken-profile.scm: 177  number->string */
C_number_to_string(3,0,((C_word*)t0)[2],t2);}

/* k875 in k863 in k906 in format-real in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_877,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* chicken-profile.scm: 176  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[38]+1)))(5,*((C_word*)lf[38]+1),((C_word*)t0)[2],t1,C_fix(1),t2);}

/* k871 in k863 in k906 in format-real in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 173  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[31]+1)))(5,*((C_word*)lf[31]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* format-string in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_774r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_774r(t0,t1,t2,t3,t4);}}

static void C_ccall f_774r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_776,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_801,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_806,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-right94108 */
t8=t7;
f_806(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-padc95106 */
t10=t6;
f_801(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body92100 */
t12=t5;
f_776(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[34],t11);}}}}

/* def-right94 in format-string in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_806,NULL,2,t0,t1);}
/* def-padc95106 */
t2=((C_word*)t0)[2];
f_801(t2,t1,C_SCHEME_FALSE);}

/* def-padc95 in format-string in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_801(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_801,NULL,3,t0,t1,t2);}
/* body92100 */
t3=((C_word*)t0)[2];
f_776(t3,t1,t2,C_make_character(32));}

/* body92 in format-string in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_776(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_776,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_783,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[2],t4);
t7=(C_word)C_i_fixnum_max(C_fix(0),t6);
/* chicken-profile.scm: 166  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[32]+1)))(4,*((C_word*)lf[32]+1),t5,t7,t3);}

/* k781 in body92 in format-string in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* chicken-profile.scm: 168  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* chicken-profile.scm: 169  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

/* read-profile in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_711,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 154  make-hash-table */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t2,*((C_word*)lf[29]+1));}

/* k709 in read-profile in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_714,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_721,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 155  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t3);}

/* k719 in k709 in read-profile in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_721,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_723,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_723(t5,((C_word*)t0)[2],t1);}

/* doloop63 in k719 in k709 in read-profile in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_723,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_733,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_748,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_750,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_764,a[2]=t6,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_car(t2);
/* chicken-profile.scm: 160  hash-table-ref/default */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t7,((C_word*)t0)[2],t8,lf[27]);}}

/* k762 in doloop63 in k719 in k709 in read-profile in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-profile.scm: 159  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[25]+1)))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* a749 in doloop63 in k719 in k709 in read-profile in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_750,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t2)?(C_truep(t3)?(C_word)C_a_i_plus(&a,2,t2,t3):C_SCHEME_FALSE):C_SCHEME_FALSE));}

/* k746 in doloop63 in k719 in k709 in read-profile in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 157  hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k731 in doloop63 in k719 in k709 in read-profile in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 155  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t2);}

/* k738 in k731 in doloop63 in k719 in k709 in read-profile in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_723(t2,((C_word*)t0)[2],t1);}

/* k712 in k709 in read-profile in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 162  hash-table->alist */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* sort-by-name in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_623,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_631,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-profile.scm: 135  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t4,t5);}

/* k629 in sort-by-name in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_635,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-profile.scm: 135  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,t3);}

/* k633 in k629 in sort-by-name in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 135  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[19]+1)))(4,*((C_word*)lf[19]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sort-by-avg in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_594,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadddr(t2);
t5=(C_word)C_i_cadddr(t3);
if(C_truep((C_word)C_i_eqvp(t4,t5))){
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_greaterp(t4,t5));}}

/* sort-by-time in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_565,4,t0,t1,t2,t3);}
t4=(C_word)C_i_caddr(t2);
t5=(C_word)C_i_caddr(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_i_cadr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_greaterp(t4,t5));}}

/* sort-by-calls in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_530,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_cadr(t3);
if(C_truep((C_word)C_i_eqvp(t4,t5))){
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t4)?(C_truep(t5)?(C_word)C_i_greaterp(t4,t5):C_SCHEME_TRUE):C_SCHEME_TRUE));}}

/* print-usage in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_fcall f_255(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_255,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_259,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_266,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[10],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[5],"percent-digits"),t4);
t6=(C_word)C_a_i_cons(&a,2,lf[11],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[4],"average-digits"),t6);
t8=(C_word)C_a_i_cons(&a,2,lf[12],t7);
t9=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[3],"seconds-digits"),t8);
t10=(C_word)C_a_i_cons(&a,2,lf[13],t9);
/* chicken-profile.scm: 45   ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,t10);}

/* k264 in print-usage in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 45   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),((C_word*)t0)[2],t1);}

/* k257 in print-usage in k244 in k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 */
static void C_ccall f_259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 65   exit */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[108] = {
{"toplevel:chicken_profile_scm",(void*)C_toplevel},
{"f_216:chicken_profile_scm",(void*)f_216},
{"f_219:chicken_profile_scm",(void*)f_219},
{"f_222:chicken_profile_scm",(void*)f_222},
{"f_225:chicken_profile_scm",(void*)f_225},
{"f_228:chicken_profile_scm",(void*)f_228},
{"f_231:chicken_profile_scm",(void*)f_231},
{"f_234:chicken_profile_scm",(void*)f_234},
{"f_237:chicken_profile_scm",(void*)f_237},
{"f_240:chicken_profile_scm",(void*)f_240},
{"f_243:chicken_profile_scm",(void*)f_243},
{"f_246:chicken_profile_scm",(void*)f_246},
{"f_1196:chicken_profile_scm",(void*)f_1196},
{"f_302:chicken_profile_scm",(void*)f_302},
{"f_504:chicken_profile_scm",(void*)f_504},
{"f_498:chicken_profile_scm",(void*)f_498},
{"f_690:chicken_profile_scm",(void*)f_690},
{"f_694:chicken_profile_scm",(void*)f_694},
{"f_698:chicken_profile_scm",(void*)f_698},
{"f_655:chicken_profile_scm",(void*)f_655},
{"f_665:chicken_profile_scm",(void*)f_665},
{"f_457:chicken_profile_scm",(void*)f_457},
{"f_440:chicken_profile_scm",(void*)f_440},
{"f_433:chicken_profile_scm",(void*)f_433},
{"f_424:chicken_profile_scm",(void*)f_424},
{"f_417:chicken_profile_scm",(void*)f_417},
{"f_399:chicken_profile_scm",(void*)f_399},
{"f_376:chicken_profile_scm",(void*)f_376},
{"f_396:chicken_profile_scm",(void*)f_396},
{"f_380:chicken_profile_scm",(void*)f_380},
{"f_357:chicken_profile_scm",(void*)f_357},
{"f_319:chicken_profile_scm",(void*)f_319},
{"f_337:chicken_profile_scm",(void*)f_337},
{"f_345:chicken_profile_scm",(void*)f_345},
{"f_349:chicken_profile_scm",(void*)f_349},
{"f_335:chicken_profile_scm",(void*)f_335},
{"f_322:chicken_profile_scm",(void*)f_322},
{"f_312:chicken_profile_scm",(void*)f_312},
{"f_914:chicken_profile_scm",(void*)f_914},
{"f_917:chicken_profile_scm",(void*)f_917},
{"f_1175:chicken_profile_scm",(void*)f_1175},
{"f_920:chicken_profile_scm",(void*)f_920},
{"f_1126:chicken_profile_scm",(void*)f_1126},
{"f_1144:chicken_profile_scm",(void*)f_1144},
{"f_1151:chicken_profile_scm",(void*)f_1151},
{"f_1124:chicken_profile_scm",(void*)f_1124},
{"f_923:chicken_profile_scm",(void*)f_923},
{"f_1112:chicken_profile_scm",(void*)f_1112},
{"f_1116:chicken_profile_scm",(void*)f_1116},
{"f_926:chicken_profile_scm",(void*)f_926},
{"f_1092:chicken_profile_scm",(void*)f_1092},
{"f_1090:chicken_profile_scm",(void*)f_1090},
{"f_1032:chicken_profile_scm",(void*)f_1032},
{"f_1052:chicken_profile_scm",(void*)f_1052},
{"f_1056:chicken_profile_scm",(void*)f_1056},
{"f_1060:chicken_profile_scm",(void*)f_1060},
{"f_1064:chicken_profile_scm",(void*)f_1064},
{"f_1068:chicken_profile_scm",(void*)f_1068},
{"f_930:chicken_profile_scm",(void*)f_930},
{"f_939:chicken_profile_scm",(void*)f_939},
{"f_1014:chicken_profile_scm",(void*)f_1014},
{"f_1022:chicken_profile_scm",(void*)f_1022},
{"f_942:chicken_profile_scm",(void*)f_942},
{"f_959:chicken_profile_scm",(void*)f_959},
{"f_1000:chicken_profile_scm",(void*)f_1000},
{"f_992:chicken_profile_scm",(void*)f_992},
{"f_962:chicken_profile_scm",(void*)f_962},
{"f_967:chicken_profile_scm",(void*)f_967},
{"f_977:chicken_profile_scm",(void*)f_977},
{"f_944:chicken_profile_scm",(void*)f_944},
{"f_956:chicken_profile_scm",(void*)f_956},
{"f_952:chicken_profile_scm",(void*)f_952},
{"f_1186:chicken_profile_scm",(void*)f_1186},
{"f_1192:chicken_profile_scm",(void*)f_1192},
{"f_1189:chicken_profile_scm",(void*)f_1189},
{"f_854:chicken_profile_scm",(void*)f_854},
{"f_908:chicken_profile_scm",(void*)f_908},
{"f_865:chicken_profile_scm",(void*)f_865},
{"f_897:chicken_profile_scm",(void*)f_897},
{"f_901:chicken_profile_scm",(void*)f_901},
{"f_889:chicken_profile_scm",(void*)f_889},
{"f_877:chicken_profile_scm",(void*)f_877},
{"f_873:chicken_profile_scm",(void*)f_873},
{"f_774:chicken_profile_scm",(void*)f_774},
{"f_806:chicken_profile_scm",(void*)f_806},
{"f_801:chicken_profile_scm",(void*)f_801},
{"f_776:chicken_profile_scm",(void*)f_776},
{"f_783:chicken_profile_scm",(void*)f_783},
{"f_707:chicken_profile_scm",(void*)f_707},
{"f_711:chicken_profile_scm",(void*)f_711},
{"f_721:chicken_profile_scm",(void*)f_721},
{"f_723:chicken_profile_scm",(void*)f_723},
{"f_764:chicken_profile_scm",(void*)f_764},
{"f_750:chicken_profile_scm",(void*)f_750},
{"f_748:chicken_profile_scm",(void*)f_748},
{"f_733:chicken_profile_scm",(void*)f_733},
{"f_740:chicken_profile_scm",(void*)f_740},
{"f_714:chicken_profile_scm",(void*)f_714},
{"f_623:chicken_profile_scm",(void*)f_623},
{"f_631:chicken_profile_scm",(void*)f_631},
{"f_635:chicken_profile_scm",(void*)f_635},
{"f_594:chicken_profile_scm",(void*)f_594},
{"f_565:chicken_profile_scm",(void*)f_565},
{"f_530:chicken_profile_scm",(void*)f_530},
{"f_255:chicken_profile_scm",(void*)f_255},
{"f_266:chicken_profile_scm",(void*)f_266},
{"f_259:chicken_profile_scm",(void*)f_259},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
