/* Generated from scrutinizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: scrutinizer.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file scrutinizer.c
   unit: scrutinizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[188];
static double C_possibly_force_alignment;


C_noret_decl(C_scrutinizer_toplevel)
C_externexport void C_ccall C_scrutinizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1280)
static void C_ccall f_1280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1286)
static void C_ccall f_1286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5086)
static void C_ccall f_5086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5165)
static void C_ccall f_5165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5095)
static void C_ccall f_5095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5104)
static void C_fcall f_5104(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5139)
static void C_fcall f_5139(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5129)
static void C_ccall f_5129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4430)
static void C_fcall f_4430(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5037)
static void C_fcall f_5037(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4951)
static void C_ccall f_4951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4983)
static void C_ccall f_4983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4993)
static void C_ccall f_4993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4855)
static void C_fcall f_4855(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_fcall f_4842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_fcall f_4651(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4672)
static void C_ccall f_4672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4510)
static void C_ccall f_4510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_fcall f_4525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4552)
static void C_fcall f_4552(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4528)
static void C_ccall f_4528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4459)
static void C_fcall f_4459(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3741)
static void C_fcall f_3741(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_fcall f_4028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_fcall f_3872(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4369)
static void C_fcall f_4369(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_fcall f_4332(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_fcall f_3744(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_fcall f_3770(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_fcall f_4137(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4269)
static void C_fcall f_4269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_fcall f_4172(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4233)
static void C_fcall f_4233(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_fcall f_4202(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_fcall f_3455(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_fcall f_3060(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_fcall f_2850(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2915)
static void C_fcall f_2915(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_fcall f_2856(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_fcall f_2888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2578)
static void C_fcall f_2578(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2665)
static void C_fcall f_2665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_fcall f_2684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_fcall f_2721(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2569)
static void C_fcall f_2569(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2503)
static void C_fcall f_2503(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_fcall f_2301(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_fcall f_2397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2336)
static void C_fcall f_2336(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_fcall f_1841(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_fcall f_2138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2038)
static void C_fcall f_2038(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_fcall f_2239(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_fcall f_2262(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static C_word C_fcall f_2279(C_word t0);
C_noret_decl(f_3115)
static void C_fcall f_3115(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3222)
static void C_fcall f_3222(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_fcall f_3238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_fcall f_3243(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1780)
static void C_fcall f_1780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1734)
static void C_fcall f_1734(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_fcall f_1635(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_ccall f_1651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_fcall f_1548(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_fcall f_3721(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_fcall f_3667(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_fcall f_3676(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3711)
static void C_ccall f_3711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1523)
static void C_fcall f_1523(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_fcall f_1448(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_fcall f_1455(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_fcall f_1411(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1431)
static void C_ccall f_1431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3536)
static void C_fcall f_3536(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_fcall f_3546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3612)
static void C_fcall f_3612(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_fcall f_3549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_5104)
static void C_fcall trf_5104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5104(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5104(t0,t1,t2);}

C_noret_decl(trf_5139)
static void C_fcall trf_5139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5139(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5139(t0,t1);}

C_noret_decl(trf_4430)
static void C_fcall trf_4430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4430(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4430(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5037)
static void C_fcall trf_5037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5037(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5037(t0,t1,t2);}

C_noret_decl(trf_4855)
static void C_fcall trf_4855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4855(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4855(t0,t1);}

C_noret_decl(trf_4842)
static void C_fcall trf_4842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4842(t0,t1);}

C_noret_decl(trf_4651)
static void C_fcall trf_4651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4651(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4651(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4525)
static void C_fcall trf_4525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4525(t0,t1);}

C_noret_decl(trf_4552)
static void C_fcall trf_4552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4552(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4552(t0,t1);}

C_noret_decl(trf_4459)
static void C_fcall trf_4459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4459(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4459(t0,t1);}

C_noret_decl(trf_3741)
static void C_fcall trf_3741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3741(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3741(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4028)
static void C_fcall trf_4028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4028(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4028(t0,t1);}

C_noret_decl(trf_3872)
static void C_fcall trf_3872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3872(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3872(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4369)
static void C_fcall trf_4369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4369(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4369(t0,t1);}

C_noret_decl(trf_4332)
static void C_fcall trf_4332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4332(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4332(t0,t1,t2);}

C_noret_decl(trf_3744)
static void C_fcall trf_3744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3744(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3744(t0,t1);}

C_noret_decl(trf_3770)
static void C_fcall trf_3770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3770(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3770(t0,t1);}

C_noret_decl(trf_4137)
static void C_fcall trf_4137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4137(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4137(t0,t1,t2,t3);}

C_noret_decl(trf_4269)
static void C_fcall trf_4269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4269(t0,t1);}

C_noret_decl(trf_4172)
static void C_fcall trf_4172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4172(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4172(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4233)
static void C_fcall trf_4233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4233(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4233(t0,t1);}

C_noret_decl(trf_4202)
static void C_fcall trf_4202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4202(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4202(t0,t1);}

C_noret_decl(trf_3455)
static void C_fcall trf_3455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3455(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3455(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3060)
static void C_fcall trf_3060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3060(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3060(t0,t1,t2,t3);}

C_noret_decl(trf_2850)
static void C_fcall trf_2850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2850(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2850(t0,t1,t2,t3);}

C_noret_decl(trf_2915)
static void C_fcall trf_2915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2915(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2915(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2856)
static void C_fcall trf_2856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2856(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2856(t0,t1,t2,t3);}

C_noret_decl(trf_2888)
static void C_fcall trf_2888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2888(t0,t1);}

C_noret_decl(trf_2578)
static void C_fcall trf_2578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2578(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2578(t0,t1,t2,t3);}

C_noret_decl(trf_2665)
static void C_fcall trf_2665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2665(t0,t1);}

C_noret_decl(trf_2684)
static void C_fcall trf_2684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2684(t0,t1);}

C_noret_decl(trf_2721)
static void C_fcall trf_2721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2721(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2721(t0,t1);}

C_noret_decl(trf_2569)
static void C_fcall trf_2569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2569(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2569(t0,t1,t2,t3);}

C_noret_decl(trf_2503)
static void C_fcall trf_2503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2503(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2503(t0,t1,t2,t3);}

C_noret_decl(trf_2301)
static void C_fcall trf_2301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2301(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2301(t0,t1,t2,t3);}

C_noret_decl(trf_2397)
static void C_fcall trf_2397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2397(t0,t1);}

C_noret_decl(trf_2336)
static void C_fcall trf_2336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2336(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2336(t0,t1);}

C_noret_decl(trf_1841)
static void C_fcall trf_1841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1841(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1841(t0,t1,t2);}

C_noret_decl(trf_2138)
static void C_fcall trf_2138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2138(t0,t1);}

C_noret_decl(trf_2038)
static void C_fcall trf_2038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2038(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2038(t0,t1,t2,t3);}

C_noret_decl(trf_2239)
static void C_fcall trf_2239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2239(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2239(t0,t1);}

C_noret_decl(trf_2262)
static void C_fcall trf_2262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2262(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2262(t0,t1);}

C_noret_decl(trf_3115)
static void C_fcall trf_3115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3115(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3115(t0,t1,t2,t3);}

C_noret_decl(trf_3222)
static void C_fcall trf_3222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3222(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3222(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3238)
static void C_fcall trf_3238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3238(t0,t1);}

C_noret_decl(trf_3243)
static void C_fcall trf_3243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3243(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3243(t0,t1,t2,t3);}

C_noret_decl(trf_1780)
static void C_fcall trf_1780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1780(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1780(t0,t1,t2);}

C_noret_decl(trf_1734)
static void C_fcall trf_1734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1734(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1734(t0,t1,t2);}

C_noret_decl(trf_1635)
static void C_fcall trf_1635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1635(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1635(t0,t1);}

C_noret_decl(trf_1548)
static void C_fcall trf_1548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1548(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1548(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3721)
static void C_fcall trf_3721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3721(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3721(t0,t1,t2);}

C_noret_decl(trf_3667)
static void C_fcall trf_3667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3667(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3667(t0,t1);}

C_noret_decl(trf_3676)
static void C_fcall trf_3676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3676(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3676(t0,t1,t2,t3);}

C_noret_decl(trf_1523)
static void C_fcall trf_1523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1523(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1523(t0,t1);}

C_noret_decl(trf_1448)
static void C_fcall trf_1448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1448(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1448(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1455)
static void C_fcall trf_1455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1455(t0,t1);}

C_noret_decl(trf_1411)
static void C_fcall trf_1411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1411(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1411(t0,t1,t2,t3);}

C_noret_decl(trf_3536)
static void C_fcall trf_3536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3536(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3536(t0,t1,t2,t3);}

C_noret_decl(trf_3546)
static void C_fcall trf_3546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3546(t0,t1,t2);}

C_noret_decl(trf_3612)
static void C_fcall trf_3612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3612(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3612(t0,t1,t2);}

C_noret_decl(trf_3549)
static void C_fcall trf_3549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3549(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_scrutinizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_scrutinizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("scrutinizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1483)){
C_save(t1);
C_rereclaim2(1483*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,188);
lf[0]=C_h_intern(&lf[0],1,"d");
lf[1]=C_h_intern(&lf[1],19,"\003sysstandard-output");
lf[2]=C_h_intern(&lf[2],19,"\003syswrite-char/port");
lf[3]=C_h_intern(&lf[3],7,"fprintf");
lf[4]=C_h_intern(&lf[4],7,"display");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\010[debug] ");
lf[6]=C_h_intern(&lf[6],19,"\010compilerscrutinize");
lf[7]=C_h_intern(&lf[7],17,"get-output-string");
lf[8]=C_h_intern(&lf[8],18,"\010compilerreal-name");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\013procedure `");
lf[10]=C_h_intern(&lf[10],18,"open-output-string");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\021unknown procedure");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\017at toplevel:\012  ");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\004:\012  ");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\014in toplevel ");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\004,\012  ");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\011in local ");
lf[17]=C_h_intern(&lf[17],25,"\010compilercompiler-warning");
lf[18]=C_h_intern(&lf[18],8,"scrutiny");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[20]=C_h_intern(&lf[20],10,"deprecated");
lf[21]=C_h_intern(&lf[21],1,"*");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\047use of deprecated toplevel identifier `");
lf[23]=C_h_intern(&lf[23],7,"\003sysget");
lf[24]=C_h_intern(&lf[24],9,"\004coretype");
lf[25]=C_h_intern(&lf[25],9,"undefined");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\036\047 which has an undefined value");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\024access to variable `");
lf[28]=C_h_intern(&lf[28],18,"\004coredeclared-type");
lf[29]=C_h_intern(&lf[29],12,"\010compilerget");
lf[30]=C_h_intern(&lf[30],8,"assigned");
lf[31]=C_h_intern(&lf[31],5,"every");
lf[32]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\011undefined\376\003\000\000\002\376\001\000\000\010noreturn\376\377\016");
lf[33]=C_h_intern(&lf[33],2,"or");
lf[34]=C_h_intern(&lf[34],3,"...");
lf[35]=C_h_intern(&lf[35],7,"\003sysmap");
lf[36]=C_h_intern(&lf[36],4,"take");
lf[37]=C_h_intern(&lf[37],3,"min");
lf[38]=C_h_intern(&lf[38],30,"\010compilerbuild-expression-tree");
lf[39]=C_h_intern(&lf[39],12,"string-chomp");
lf[40]=C_h_intern(&lf[40],2,"pp");
lf[41]=C_h_intern(&lf[41],21,"with-output-to-string");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\027\047 which is always true:");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000Nexpected value of type boolean in conditional but were given a value of\012typ"
"e `");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\010anything");
lf[45]=C_h_intern(&lf[45],4,"char");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\011character");
lf[47]=C_h_intern(&lf[47],14,"symbol->string");
lf[48]=C_h_intern(&lf[48],9,"procedure");
lf[49]=C_h_intern(&lf[49],8,"->string");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\013 returning ");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\021a procedure with ");
lf[52]=C_h_intern(&lf[52],18,"string-intersperse");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\004 OR ");
lf[54]=C_h_intern(&lf[54],6,"struct");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\024a structure of type ");
lf[56]=C_h_intern(&lf[56],13,"\010compilerbomb");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid type: ~a");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid type: ~a");
lf[59]=C_h_intern(&lf[59],3,"len");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\016zero arguments");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\010 of type");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\011 argument");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\033an unknown number of values");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\013zero values");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\010 of type");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\006 value");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011undefined\376\377\016");
lf[70]=C_h_intern(&lf[70],4,"list");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004null\376\003\000\000\002\376\001\000\000\004pair\376\377\016");
lf[72]=C_h_intern(&lf[72],6,"number");
lf[73]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[74]=C_h_intern(&lf[74],10,"#!optional");
lf[75]=C_h_intern(&lf[75],6,"#!rest");
lf[76]=C_h_intern(&lf[76],6,"values");
lf[77]=C_h_intern(&lf[77],19,"\003sysundefined-value");
lf[78]=C_h_intern(&lf[78],6,"append");
lf[79]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[80]=C_h_intern(&lf[80],6,"reduce");
lf[81]=C_h_intern(&lf[81],3,"any");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\377\016");
lf[83]=C_h_intern(&lf[83],10,"\003sysappend");
lf[84]=C_h_intern(&lf[84],7,"reverse");
lf[85]=C_h_intern(&lf[85],10,"append-map");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[87]=C_h_intern(&lf[87],7,"call/cc");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[92]=C_h_intern(&lf[92],8,"noreturn");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006number\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006number\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[95]=C_h_intern(&lf[95],4,"pair");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004pair\376\003\000\000\002\376\001\000\000\004list\376\377\016");
lf[97]=C_h_intern(&lf[97],4,"null");
lf[98]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004null\376\003\000\000\002\376\001\000\000\004list\376\377\016");
lf[99]=C_h_intern(&lf[99],5,"break");
lf[100]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[101]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000- a single result, but were given zero results");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\011expected ");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\007 result");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000! a single result, but were given ");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\011expected ");
lf[107]=C_h_intern(&lf[107],4,"cons");
lf[108]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[109]=C_h_intern(&lf[109],9,"make-list");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\024not a procedure type");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\007 (line ");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[113]=C_h_intern(&lf[113],26,"\010compilersource-info->line");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[115]=C_h_intern(&lf[115],5,"write");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\026in procedure call to `");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\030not a procedure type: ~a");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\047, but where given an argument of type `");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\002\047 ");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\012 of type `");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\023expected argument #");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\011 argument");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\022, but where given ");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\011 argument");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\011expected ");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000#\047, but were given a value of type `");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\022 a value of type `");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\011expected ");
lf[130]=C_h_intern(&lf[130],5,"quote");
lf[131]=C_h_intern(&lf[131],6,"string");
lf[132]=C_h_intern(&lf[132],6,"symbol");
lf[133]=C_h_intern(&lf[133],6,"fixnum");
lf[134]=C_h_intern(&lf[134],5,"float");
lf[135]=C_h_intern(&lf[135],7,"boolean");
lf[136]=C_h_intern(&lf[136],3,"eof");
lf[137]=C_h_intern(&lf[137],6,"vector");
lf[138]=C_h_intern(&lf[138],22,"\003sysgeneric-structure\077");
lf[139]=C_h_intern(&lf[139],14,"\004coreundefined");
lf[140]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\377\016");
lf[141]=C_h_intern(&lf[141],9,"\004coreproc");
lf[142]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[143]=C_h_intern(&lf[143],15,"\004coreglobal-ref");
lf[144]=C_h_intern(&lf[144],13,"\004corevariable");
lf[145]=C_h_intern(&lf[145],2,"if");
lf[146]=C_h_intern(&lf[146],3,"map");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000Cbranches in conditional expression differ in the number of results:");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\016in conditional");
lf[149]=C_h_intern(&lf[149],3,"let");
lf[150]=C_h_intern(&lf[150],10,"alist-cons");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\025in `let\047 binding of `");
lf[152]=C_h_intern(&lf[152],11,"\004corelambda");
lf[153]=C_h_intern(&lf[153],6,"lambda");
lf[154]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[155]=C_h_intern(&lf[155],7,"butlast");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[157]=C_h_intern(&lf[157],30,"\010compilerdecompose-lambda-list");
lf[158]=C_h_intern(&lf[158],4,"set!");
lf[159]=C_h_intern(&lf[159],9,"\004coreset!");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011undefined\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000 \047 does not match declared type `");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\030\047 to toplevel variable `");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\035assignment of value of type `");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\022in assignment to `");
lf[165]=C_h_intern(&lf[165],14,"\004coreprimitive");
lf[166]=C_h_intern(&lf[166],15,"\004coreinline_ref");
lf[167]=C_h_intern(&lf[167],9,"\004corecall");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\024 of procedure call `");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\021operator position");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\012argument #");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\003in ");
lf[172]=C_h_intern(&lf[172],4,"iota");
lf[173]=C_h_intern(&lf[173],11,"\004coreswitch");
lf[174]=C_h_intern(&lf[174],9,"\004corecond");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\031unexpected node class: ~a");
lf[176]=C_h_intern(&lf[176],27,"\010compilerload-type-database");
lf[177]=C_h_intern(&lf[177],8,"\003sysput!");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000Ytype-definition `~a\047 for toplevel binding `~a\047 conflicts with previously lo"
"aded type `~a\047");
lf[179]=C_h_intern(&lf[179],9,"read-file");
lf[180]=C_h_intern(&lf[180],21,"\010compilerverbose-mode");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\026loading type database ");
lf[183]=C_h_intern(&lf[183],12,"file-exists\077");
lf[184]=C_h_intern(&lf[184],13,"make-pathname");
lf[185]=C_h_intern(&lf[185],15,"repository-path");
lf[186]=C_h_intern(&lf[186],9,"\003syserror");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
C_register_lf2(lf,188,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1271,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1269 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1274,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1272 in k1269 */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1275 in k1272 in k1269 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1280,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1283,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1286,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! d ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1288,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[6]+1 /* (set! scrutinize ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1306,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[176]+1 /* (set! load-type-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5082,tmp=(C_word)a,a+=2,tmp));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5082(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5082r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5082r(t0,t1,t2,t3);}}

static void C_ccall f_5082r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5086,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* scrutinizer.scm: 613  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[185]))(2,*((C_word*)lf[185]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5086(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[186]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[187],t3);}}}

/* k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5089,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5165,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 614  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t3,t1,((C_word*)t0)[2]);}

/* k5163 in k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 614  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[183]))(3,*((C_word*)lf[183]+1),((C_word*)t0)[2],t1);}

/* k5087 in k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5089,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5095,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[180]))){
t3=*((C_word*)lf[1]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5152,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t4,lf[182],t3);}
else{
t3=t2;
f_5095(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5150 in k5087 in k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5153 in k5150 in k5087 in k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[181],((C_word*)t0)[2]);}

/* k5156 in k5153 in k5150 in k5087 in k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k5093 in k5087 in k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5102,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 628  read-file */
((C_proc3)C_retrieve_symbol_proc(lf[179]))(3,*((C_word*)lf[179]+1),t2,((C_word*)t0)[2]);}

/* k5100 in k5093 in k5087 in k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5102,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5104,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5104(t5,((C_word*)t0)[2],t1);}

/* loop1237 in k5100 in k5093 in k5087 in k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_5104(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5104,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5120,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* scrutinizer.scm: 620  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),t5,t4,lf[24]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5118 in loop1237 in k5100 in k5093 in k5087 in k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5120,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5126,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5139,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t5=(C_word)C_i_equalp(t1,t2);
t6=t4;
f_5139(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_5139(t5,C_SCHEME_FALSE);}}

/* k5137 in k5118 in loop1237 in k5100 in k5093 in k5087 in k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_5139(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* scrutinizer.scm: 623  compiler-warning */
((C_proc7)C_retrieve_symbol_proc(lf[17]))(7,*((C_word*)lf[17]+1),((C_word*)t0)[5],lf[18],lf[178],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_5126(2,t2,C_SCHEME_UNDEFINED);}}

/* k5124 in k5118 in loop1237 in k5100 in k5093 in k5087 in k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5129,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 627  ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[177]))(5,*((C_word*)lf[177]+1),t2,((C_word*)t0)[3],lf[24],((C_word*)t0)[2]);}

/* k5127 in k5124 in k5118 in loop1237 in k5100 in k5093 in k5087 in k5084 in ##compiler#load-type-database in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5104(t3,((C_word*)t0)[2],t2);}

/* ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word ab[150],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1306,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3546,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3536,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1411,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1448,a[2]=t8,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1516,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3667,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1548,a[2]=t11,a[3]=t14,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1589,a[2]=t17,a[3]=t19,a[4]=t21,tmp=(C_word)a,a+=5,tmp));
t23=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1734,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t24=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1780,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4095,a[2]=t26,tmp=(C_word)a,a+=3,tmp));
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3115,a[2]=t29,tmp=(C_word)a,a+=3,tmp));
t31=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2279,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2239,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_set_block_item(t34,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1832,a[2]=t36,tmp=(C_word)a,a+=3,tmp));
t42=C_set_block_item(t36,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1841,a[2]=t26,a[3]=t29,a[4]=t32,a[5]=t38,a[6]=t40,a[7]=t34,tmp=(C_word)a,a+=8,tmp));
t43=C_set_block_item(t38,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2301,a[2]=t38,a[3]=t34,a[4]=t31,tmp=(C_word)a,a+=5,tmp));
t44=C_set_block_item(t40,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2503,a[2]=t34,a[3]=t40,tmp=(C_word)a,a+=4,tmp));
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_set_block_item(t46,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2569,a[2]=t48,tmp=(C_word)a,a+=3,tmp));
t54=C_set_block_item(t48,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2578,a[2]=t32,a[3]=t50,a[4]=t52,a[5]=t46,tmp=(C_word)a,a+=6,tmp));
t55=C_set_block_item(t50,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2850,a[2]=t31,a[3]=t46,tmp=(C_word)a,a+=4,tmp));
t56=C_set_block_item(t52,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3060,a[2]=t46,a[3]=t52,tmp=(C_word)a,a+=4,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3455,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t58=*((C_word*)lf[107]+1);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4137,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
t60=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3741,a[2]=t26,a[3]=t46,a[4]=t7,a[5]=t59,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_set_block_item(t62,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4398,a[2]=t62,tmp=(C_word)a,a+=3,tmp));
t64=C_SCHEME_UNDEFINED;
t65=(*a=C_VECTOR_TYPE|1,a[1]=t64,tmp=(C_word)a,a+=2,tmp);
t66=C_set_block_item(t65,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4430,a[2]=t13,a[3]=t60,a[4]=t46,a[5]=t58,a[6]=t57,a[7]=t15,a[8]=t65,a[9]=t62,a[10]=t14,a[11]=t7,a[12]=t34,a[13]=t9,a[14]=t8,tmp=(C_word)a,a+=15,tmp));
t67=(C_word)C_slot(t2,C_fix(3));
t68=(C_word)C_i_car(t67);
/* scrutinizer.scm: 611  walk */
t69=((C_word*)t65)[1];
f_4430(t69,t1,t68,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4430(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4430,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=C_retrieve(lf[77]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4446,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_eqp(t11,lf[130]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4459,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t16=(C_word)C_i_car(t9);
if(C_truep((C_word)C_i_stringp(t16))){
t17=t15;
f_4459(t17,lf[131]);}
else{
if(C_truep((C_word)C_i_symbolp(t16))){
t17=t15;
f_4459(t17,lf[132]);}
else{
if(C_truep((C_word)C_fixnump(t16))){
t17=t15;
f_4459(t17,lf[133]);}
else{
if(C_truep((C_word)C_i_flonump(t16))){
t17=t15;
f_4459(t17,lf[134]);}
else{
if(C_truep((C_word)C_i_numberp(t16))){
t17=t15;
f_4459(t17,lf[72]);}
else{
if(C_truep((C_word)C_booleanp(t16))){
t17=t15;
f_4459(t17,lf[135]);}
else{
if(C_truep((C_word)C_i_listp(t16))){
t17=t15;
f_4459(t17,lf[70]);}
else{
if(C_truep((C_word)C_i_pairp(t16))){
t17=t15;
f_4459(t17,lf[95]);}
else{
if(C_truep((C_word)C_eofp(t16))){
t17=t15;
f_4459(t17,lf[136]);}
else{
if(C_truep((C_word)C_i_vectorp(t16))){
t17=t15;
f_4459(t17,lf[137]);}
else{
t17=(C_word)C_immp(t16);
t18=(C_truep(t17)?C_SCHEME_FALSE:(C_truep(*((C_word*)lf[138]+1))?t16:C_SCHEME_FALSE));
if(C_truep(t18)){
t19=(C_word)C_slot(t16,C_fix(0));
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=t15;
f_4459(t21,(C_word)C_a_i_cons(&a,2,lf[54],t20));}
else{
if(C_truep((C_word)C_i_nullp(t16))){
t19=t15;
f_4459(t19,lf[97]);}
else{
t19=(C_word)C_charp(t16);
t20=t15;
f_4459(t20,(C_truep(t19)?lf[45]:lf[21]));}}}}}}}}}}}}}
else{
t15=(C_word)C_eqp(t11,lf[139]);
if(C_truep(t15)){
t16=t13;
f_4446(2,t16,lf[140]);}
else{
t16=(C_word)C_eqp(t11,lf[141]);
if(C_truep(t16)){
t17=t13;
f_4446(2,t17,lf[142]);}
else{
t17=(C_word)C_eqp(t11,lf[143]);
if(C_truep(t17)){
t18=(C_word)C_i_car(t9);
/* scrutinizer.scm: 525  global-result */
t19=((C_word*)t0)[14];
f_1411(t19,t13,t18,t4);}
else{
t18=(C_word)C_eqp(t11,lf[144]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
/* scrutinizer.scm: 526  variable-result */
t20=((C_word*)t0)[13];
f_1448(t20,t13,t19,t3,t4);}
else{
t19=(C_word)C_eqp(t11,lf[145]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4510,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=t3,a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[10],a[10]=t4,a[11]=((C_word*)t0)[11],a[12]=t13,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4636,a[2]=t4,a[3]=t20,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t22=(C_word)C_i_car(t7);
/* scrutinizer.scm: 527  walk */
t55=t21;
t56=t22;
t57=t3;
t58=t4;
t59=t5;
t1=t55;
t2=t56;
t3=t57;
t4=t58;
t5=t59;
goto loop;}
else{
t20=(C_word)C_eqp(t11,lf[149]);
if(C_truep(t20)){
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4651,a[2]=((C_word*)t0)[6],a[3]=t22,a[4]=t3,a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t24=((C_word*)t22)[1];
f_4651(t24,t13,t9,t7,C_SCHEME_END_OF_LIST);}
else{
t21=(C_word)C_eqp(t11,lf[152]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(t11,lf[153]));
if(C_truep(t22)){
t23=(C_word)C_i_car(t9);
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4745,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 553  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[157]))(4,*((C_word*)lf[157]+1),t13,t23,t24);}
else{
t23=(C_word)C_eqp(t11,lf[158]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[159]));
if(C_truep(t24)){
t25=(C_word)C_i_car(t9);
t26=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4827,a[2]=((C_word*)t0)[8],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[11],a[8]=t13,a[9]=t3,a[10]=t25,tmp=(C_word)a,a+=11,tmp);
/* scrutinizer.scm: 573  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),t26,t25,lf[24]);}
else{
t25=(C_word)C_eqp(t11,lf[165]);
t26=(C_truep(t25)?t25:(C_word)C_eqp(t11,lf[166]));
if(C_truep(t26)){
t27=t13;
f_4446(2,t27,lf[21]);}
else{
t27=(C_word)C_eqp(t11,lf[167]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4951,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=t9,a[6]=t4,a[7]=t13,a[8]=((C_word*)t0)[3],a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* scrutinizer.scm: 592  fragment */
f_3667(t28,t2);}
else{
t28=(C_word)C_eqp(t11,lf[173]);
t29=(C_truep(t28)?t28:(C_word)C_eqp(t11,lf[174]));
if(C_truep(t29)){
/* scrutinizer.scm: 605  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t13,lf[175],t11);}
else{
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5035,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_set_block_item(t32,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5037,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t32,tmp=(C_word)a,a+=6,tmp));
t34=((C_word*)t32)[1];
f_5037(t34,t30,t7);}}}}}}}}}}}}}

/* loop1163 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_5037(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5037,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5050,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 607  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4430(t5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5048 in loop1163 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5037(t3,((C_word*)t0)[2],t2);}

/* k5033 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4446(2,t2,lf[21]);}

/* k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4954,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4963,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5016,a[2]=((C_word*)t0)[9],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[9]);
/* scrutinizer.scm: 602  iota */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t4,t5);}

/* k5014 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 593  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[146]+1)))(5,*((C_word*)lf[146]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4963,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4971,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t4);}

/* k4969 in a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[171],t1);}

/* k4972 in k4969 in a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4977,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4997,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t4)){
t5=t3;
f_4997(2,t5,lf[169]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t5);}}

/* k5001 in k4972 in k4969 in a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5006,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[170],t1);}

/* k5004 in k5001 in k4972 in k4969 in a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5007 in k5004 in k5001 in k4972 in k4969 in a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4995 in k4972 in k4969 in a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4975 in k4972 in k4969 in a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[168],((C_word*)t0)[3]);}

/* k4978 in k4975 in k4972 in k4969 in a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4981 in k4978 in k4975 in k4972 in k4969 in a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4993,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 601  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4430(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k4991 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in a4962 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 594  single */
t2=((C_word*)t0)[5];
f_3455(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4952 in k4949 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* scrutinizer.scm: 603  call-result */
t3=((C_word*)t0)[5];
f_3741(t3,((C_word*)t0)[4],t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t3);}

/* k4911 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4916,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[164],t1);}

/* k4914 in k4911 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4917 in k4914 in k4911 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k4920 in k4917 in k4914 in k4911 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k4923 in k4920 in k4917 in k4914 in k4911 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4929,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* scrutinizer.scm: 576  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4430(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k4927 in k4923 in k4920 in k4917 in k4914 in k4911 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 574  single */
t2=((C_word*)t0)[5];
f_3455(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4830,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4855,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(t2)){
t5=t4;
f_4855(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[3],lf[20]);
if(C_truep(t5)){
t6=t4;
f_4855(t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4905,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 581  match */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2569(t7,t6,((C_word*)t0)[3],t1);}}}
else{
t5=t4;
f_4855(t5,C_SCHEME_FALSE);}}

/* k4903 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4855(t2,(C_word)C_i_not(t1));}

/* k4853 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4855(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4855,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t2);}
else{
t2=((C_word*)t0)[6];
f_4836(2,t2,C_SCHEME_UNDEFINED);}}

/* k4860 in k4853 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[163],t1);}

/* k4863 in k4860 in k4853 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k4866 in k4863 in k4860 in k4853 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[162],((C_word*)t0)[4]);}

/* k4869 in k4866 in k4863 in k4860 in k4853 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k4872 in k4869 in k4866 in k4863 in k4860 in k4853 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[161],((C_word*)t0)[3]);}

/* k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4853 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4853 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4853 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k4884 in k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4853 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 582  report */
t2=((C_word*)t0)[4];
f_3536(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4834 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_4842(t4,(C_word)C_eqp(lf[25],t3));}
else{
t3=t2;
f_4842(t3,C_SCHEME_FALSE);}}

/* k4840 in k4834 in k4828 in k4825 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_set_cdr(((C_word*)t0)[4],((C_word*)t0)[3]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
f_4446(2,t3,lf[160]);}

/* a4744 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4745,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]):C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4752,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4805,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 557  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t7,t3,lf[21]);}

/* k4803 in a4744 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[3])?lf[156]:C_SCHEME_END_OF_LIST);
/* scrutinizer.scm: 557  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[78]+1)))(4,*((C_word*)lf[78]+1),((C_word*)t0)[2],t1,t2);}

/* k4750 in a4744 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4788,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4790,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4798,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* scrutinizer.scm: 559  butlast */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),t5,((C_word*)t0)[2]);}
else{
t6=t5;
f_4798(2,t6,((C_word*)t0)[2]);}}

/* k4796 in k4750 in a4744 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4789 in k4750 in a4744 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4790(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4790,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,lf[21]));}

/* k4786 in k4750 in a4744 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 558  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[78]+1)))(4,*((C_word*)lf[78]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4753 in k4750 in a4744 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* scrutinizer.scm: 562  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[150]))(5,*((C_word*)lf[150]+1),t4,((C_word*)t0)[2],lf[70],t1);}
else{
t5=t4;
f_4777(2,t5,t1);}}

/* k4775 in k4753 in k4750 in a4744 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4781,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 563  add-loc */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4779 in k4775 in k4753 in k4750 in a4744 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 561  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4430(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k4756 in k4753 in k4750 in a4744 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4765,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* scrutinizer.scm: 566  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[78]+1)))(6,*((C_word*)lf[78]+1),t2,lf[154],((C_word*)t0)[2],t3,t1);}

/* k4763 in k4756 in k4753 in k4750 in a4744 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4765,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* loop in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4651(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4651,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* scrutinizer.scm: 547  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[78]+1)))(4,*((C_word*)lf[78]+1),t6,t4,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4672,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4695,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t5,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t6);}}

/* k4693 in loop in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4698,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[151],t1);}

/* k4696 in k4693 in loop in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4723,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* scrutinizer.scm: 549  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),t3,t4);}

/* k4721 in k4696 in k4693 in loop in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4699 in k4696 in k4693 in loop in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k4702 in k4699 in k4696 in k4693 in loop in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4707,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k4705 in k4702 in k4699 in k4696 in k4693 in loop in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4711,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
/* scrutinizer.scm: 550  walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4430(t5,t2,t3,((C_word*)t0)[2],((C_word*)t0)[6],t4);}

/* k4709 in k4705 in k4702 in k4699 in k4696 in k4693 in loop in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 548  single */
t2=((C_word*)t0)[5];
f_3455(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4670 in loop in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4672,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4687,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
/* scrutinizer.scm: 551  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[150]))(5,*((C_word*)lf[150]+1),t4,t5,t1,((C_word*)t0)[2]);}

/* k4685 in k4670 in loop in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 551  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4651(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4667 in loop in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 547  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4430(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4634 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 527  single */
t2=((C_word*)t0)[4];
f_3455(t2,((C_word*)t0)[3],lf[148],t1,((C_word*)t0)[2]);}

/* k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* scrutinizer.scm: 528  always-true */
t3=((C_word*)t0)[2];
f_1548(t3,t2,t1,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm: 529  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4430(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t1,a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* scrutinizer.scm: 530  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4430(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[21]);
if(C_truep(t3)){
t4=t2;
f_4525(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(lf[21],t1);
t5=t2;
f_4525(t5,(C_word)C_i_not(t4));}}

/* k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4525,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4528,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4552,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 533  any */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t4,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[8]);}
else{
t2=((C_word*)t0)[9];
f_4446(2,t2,lf[21]);}}

/* k4608 in k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4610,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4552(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 534  any */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t2,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k4604 in k4608 in k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4552(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_eqp(t2,t3);
t5=((C_word*)t0)[4];
f_4552(t5,(C_word)C_i_not(t4));}}

/* k4550 in k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4552(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4552,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t2);}
else{
t2=((C_word*)t0)[5];
f_4528(2,t2,C_SCHEME_UNDEFINED);}}

/* k4557 in k4550 in k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[147],t1);}

/* k4560 in k4557 in k4550 in k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k4563 in k4560 in k4557 in k4550 in k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k4566 in k4563 in k4560 in k4557 in k4550 in k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4571,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 540  pp-fragment */
t4=((C_word*)t0)[3];
f_3721(t4,t3,((C_word*)t0)[2]);}

/* k4576 in k4566 in k4563 in k4560 in k4557 in k4550 in k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4569 in k4566 in k4563 in k4560 in k4557 in k4550 in k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k4572 in k4569 in k4566 in k4563 in k4560 in k4557 in k4550 in k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 536  report */
t2=((C_word*)t0)[4];
f_3536(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4526 in k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 541  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[146]+1)))(5,*((C_word*)lf[146]+1),((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4532 in k4526 in k4523 in k4517 in k4514 in k4511 in k4508 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4533,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=(C_word)C_a_i_cons(&a,2,lf[33],t5);
/* scrutinizer.scm: 541  simplify */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1832(3,t7,t1,t6);}

/* k4457 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4459(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4459,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4446(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k4444 in walk in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[77]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* noreturn-type? in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4398,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[92],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[33],t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 514  any */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t1,((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3741(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3741,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3744,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_retrieve(lf[77]);
t8=(C_word)C_i_car(t2);
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4085,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t8,a[10]=((C_word*)t0)[5],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
/* scrutinizer.scm: 434  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t11,t10,lf[21]);}

/* k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4085,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[21],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[48],t3);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=t5,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4077,a[2]=((C_word*)t0)[9],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 435  procedure-type? */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4095(3,t8,t7,((C_word*)t0)[9]);}

/* k4075 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4077,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4028(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 436  match */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2569(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4071 in k4075 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4028(t2,(C_word)C_i_not(t1));}

/* k4026 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4028(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4028,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t2);}
else{
t2=((C_word*)t0)[6];
f_3827(2,t2,C_SCHEME_UNDEFINED);}}

/* k4033 in k4026 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[129],t1);}

/* k4036 in k4033 in k4026 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4063,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 441  pname */
t4=((C_word*)t0)[2];
f_3744(t4,t3);}

/* k4061 in k4036 in k4033 in k4026 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4039 in k4036 in k4033 in k4026 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[128],((C_word*)t0)[4]);}

/* k4042 in k4039 in k4036 in k4033 in k4026 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k4045 in k4042 in k4039 in k4036 in k4033 in k4026 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[127],((C_word*)t0)[3]);}

/* k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4026 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4026 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4026 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4026 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 437  report */
t2=((C_word*)t0)[4];
f_3536(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3832,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3846,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[77]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3853,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_i_length(t2);
t7=(C_word)C_eqp(t6,((C_word*)t0)[2]);
if(C_truep(t7)){
t8=t5;
f_3853(2,t8,C_SCHEME_UNDEFINED);}
else{
t8=(C_word)C_i_length(t2);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3976,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t9);}}

/* k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[126],t1);}

/* k3977 in k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 452  pname */
t4=((C_word*)t0)[2];
f_3744(t4,t3);}

/* k4019 in k3977 in k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3980 in k3977 in k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k3983 in k3980 in k3977 in k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k3986 in k3983 in k3980 in k3977 in k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[125],((C_word*)t0)[4]);}

/* k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(1));
t4=(C_truep(t3)?lf[60]:lf[61]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,t4,((C_word*)t0)[4]);}

/* k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[124],((C_word*)t0)[3]);}

/* k3995 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3998 in k3995 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[123],((C_word*)t0)[3]);}

/* k4001 in k3998 in k3995 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(1));
t4=(C_truep(t3)?lf[60]:lf[61]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,t4,((C_word*)t0)[3]);}

/* k4004 in k4001 in k3998 in k3995 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k4007 in k4004 in k4001 in k3998 in k3995 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 448  report */
t2=((C_word*)t0)[4];
f_3536(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3856,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3872(t7,t2,t3,((C_word*)t0)[2],C_fix(1));}

/* doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3872(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3872,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?t5:(C_word)C_i_nullp(t3));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3885,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3903,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_i_car(t2);
/* scrutinizer.scm: 458  match */
t11=((C_word*)((C_word*)t0)[2])[1];
f_2569(t11,t8,t9,t10);}}

/* k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3903,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
f_3885(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t2);}}

/* k3908 in k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[122],t1);}

/* k3911 in k3908 in k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k3914 in k3911 in k3908 in k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[121],((C_word*)t0)[5]);}

/* k3917 in k3914 in k3911 in k3908 in k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,t3,((C_word*)t0)[5]);}

/* k3920 in k3917 in k3914 in k3911 in k3908 in k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[120],((C_word*)t0)[4]);}

/* k3923 in k3920 in k3917 in k3914 in k3911 in k3908 in k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 463  pname */
t4=((C_word*)t0)[2];
f_3744(t4,t3);}

/* k3946 in k3923 in k3920 in k3917 in k3914 in k3911 in k3908 in k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3926 in k3923 in k3920 in k3917 in k3914 in k3911 in k3908 in k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[119],((C_word*)t0)[3]);}

/* k3929 in k3926 in k3923 in k3920 in k3917 in k3914 in k3911 in k3908 in k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,t3,((C_word*)t0)[3]);}

/* k3932 in k3929 in k3926 in k3923 in k3920 in k3917 in k3914 in k3911 in k3908 in k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k3935 in k3932 in k3929 in k3926 in k3923 in k3920 in k3917 in k3914 in k3911 in k3908 in k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3920 in k3917 in k3914 in k3911 in k3908 in k3901 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 459  report */
t2=((C_word*)t0)[4];
f_3536(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3883 in doloop876 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_3872(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k3854 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3859,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
if(C_truep(t4)){
t5=t2;
f_3859(2,t5,t3);}
else{
t5=(C_word)C_i_memq(((C_word*)t0)[2],lf[117]);
t6=(C_truep(t5)?t5:(C_word)C_i_not_pair_p(((C_word*)t0)[2]));
if(C_truep(t6)){
t7=t2;
f_3859(2,t7,lf[21]);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[2]);
t8=(C_word)C_eqp(lf[48],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 501  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[87]+1)))(3,*((C_word*)lf[87]+1),t2,t9);}
else{
/* scrutinizer.scm: 509  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t2,lf[118],((C_word*)t0)[2]);}}}}

/* a4321 in k3854 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4322,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=(C_word)C_i_stringp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4369,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4369(t6,t4);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
t7=t5;
f_4369(t7,(C_word)C_i_symbolp(t6));}}

/* k4367 in a4321 in k3854 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4369(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4369,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cdddr(((C_word*)t0)[4]):(C_word)C_i_cddr(((C_word*)t0)[4]));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4332,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4332(t6,((C_word*)t0)[2],t2);}

/* loop in k4367 in a4321 in k3854 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4332(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4332,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_eqp(lf[21],t2);
if(C_truep(t3)){
/* scrutinizer.scm: 507  return */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,lf[21]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4359,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 508  loop */
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k4357 in loop in k4367 in a4321 in k3854 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4359,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3857 in k3854 in k3851 in a3845 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[77]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3831 in k3825 in k4083 in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3832,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_i_length(t2);
/* scrutinizer.scm: 444  procedure-argument-types */
t4=((C_word*)t0)[3];
f_4137(t4,t1,((C_word*)t0)[2],t3);}

/* pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3744(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3744,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t2);}

/* k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[116],t1);}

/* k3749 in k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3754,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3812,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 424  fragment */
f_3667(t3,((C_word*)t0)[2]);}

/* k3810 in k3749 in k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3752 in k3749 in k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[3]);}

/* k3755 in k3752 in k3749 in k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3767,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
t6=t4;
f_3770(t6,(C_word)C_i_pairp(t5));}
else{
t5=t4;
f_3770(t5,C_SCHEME_FALSE);}}

/* k3768 in k3755 in k3752 in k3749 in k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3770,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3773,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* scrutinizer.scm: 426  source-info->line */
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
f_3767(2,t2,lf[114]);}}

/* k3771 in k3768 in k3755 in k3752 in k3749 in k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3773,2,t0,t1);}
if(C_truep((C_word)C_i_numberp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3782,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_3767(2,t2,lf[112]);}}

/* k3780 in k3771 in k3768 in k3755 in k3752 in k3749 in k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3785,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[111],t1);}

/* k3783 in k3780 in k3771 in k3768 in k3755 in k3752 in k3749 in k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3786 in k3783 in k3780 in k3771 in k3768 in k3755 in k3752 in k3749 in k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[2]);}

/* k3789 in k3786 in k3783 in k3780 in k3771 in k3768 in k3755 in k3752 in k3749 in k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3765 in k3755 in k3752 in k3749 in k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3758 in k3755 in k3752 in k3749 in k3746 in pname in call-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* procedure-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4137(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4137,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,lf[108]);
t5=(C_truep(t4)?t4:(C_word)C_i_not_pair_p(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4154,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 476  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t6,t3,lf[21]);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(lf[48],t6);
if(C_truep(t7)){
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4163,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_i_stringp(t11);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4269,a[2]=t3,a[3]=t10,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_4269(t14,t12);}
else{
t14=(C_word)C_i_cadr(t2);
t15=t13;
f_4269(t15,(C_word)C_i_symbolp(t14));}}
else{
/* scrutinizer.scm: 494  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t1,lf[110],t2);}}}

/* k4267 in procedure-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4269,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4172(t6,((C_word*)t0)[3],t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* loop in k4267 in procedure-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4172(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4172,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(lf[74],t5);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 487  loop */
t16=t1;
t17=t7;
t18=t3;
t19=C_SCHEME_TRUE;
t1=t16;
t2=t17;
t3=t18;
t4=t19;
goto loop;}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(lf[75],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4202,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cadr(t2);
t12=t9;
f_4202(t12,(C_word)C_eqp(lf[76],t11));}
else{
t11=t9;
f_4202(t11,C_SCHEME_FALSE);}}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4233,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t10=t3;
t11=t9;
f_4233(t11,(C_word)C_fixnum_less_or_equal_p(t10,C_fix(0)));}
else{
t10=t9;
f_4233(t10,C_SCHEME_FALSE);}}}}}

/* k4231 in loop in k4267 in procedure-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4233(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4233,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4244,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* scrutinizer.scm: 492  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4172(t6,t3,t4,t5,((C_word*)t0)[2]);}}

/* k4242 in k4231 in loop in k4267 in procedure-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4244,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4200 in loop in k4267 in procedure-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_4202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=f_2279(t3);
/* scrutinizer.scm: 490  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k4161 in procedure-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 493  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4152 in procedure-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 476  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3455(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3455,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(lf[21],t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[21]);}
else{
t6=(C_word)C_i_length(t3);
t7=(C_word)C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t3));}
else{
t8=(C_word)C_eqp(t6,C_fix(0));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3483,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3487,a[2]=t2,a[3]=t4,a[4]=t9,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t10);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3502,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3509,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=t9,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t10);}}}}

/* k3507 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[106],t1);}

/* k3510 in k3507 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k3513 in k3510 in k3507 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[105],((C_word*)t0)[3]);}

/* k3516 in k3513 in k3510 in k3507 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3519 in k3516 in k3513 in k3510 in k3507 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[104],((C_word*)t0)[3]);}

/* k3522 in k3519 in k3516 in k3513 in k3510 in k3507 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(1));
t4=(C_truep(t3)?lf[60]:lf[61]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,t4,((C_word*)t0)[3]);}

/* k3525 in k3522 in k3519 in k3516 in k3513 in k3510 in k3507 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k3528 in k3525 in k3522 in k3519 in k3516 in k3513 in k3510 in k3507 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 383  report */
t2=((C_word*)t0)[4];
f_3536(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3500 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(((C_word*)t0)[2]));}

/* k3485 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3490,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[103],t1);}

/* k3488 in k3485 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3493,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3491 in k3488 in k3485 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[102],((C_word*)t0)[2]);}

/* k3494 in k3491 in k3488 in k3485 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3499,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k3497 in k3494 in k3491 in k3488 in k3485 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 378  report */
t2=((C_word*)t0)[4];
f_3536(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3481 in single in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[25]);}

/* match-results in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3060(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3060,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not_pair_p(t3));}
else{
t4=(C_word)C_eqp(lf[21],t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eqp(lf[21],t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3094,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
/* scrutinizer.scm: 326  match */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2569(t9,t6,t7,t8);}}}}}

/* k3092 in match-results in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm: 327  match-results */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3060(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match-args in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2850(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2850,NULL,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[77]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2915,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2915(t9,t1,t2,t3,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* loop in match-args in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2915(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2915,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_retrieve(lf[77]);
if(C_truep((C_word)C_i_nullp(t2))){
t7=t5;
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(C_word)C_i_nullp(t3);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(C_word)C_i_car(t3);
t10=t1;
t11=t10;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_i_memq(t9,lf[100]));}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t7=t4;
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(C_word)C_i_car(t2);
t9=t1;
t10=t9;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_memq(t8,lf[101]));}}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(lf[74],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 312  loop */
t32=t1;
t33=t9;
t34=t3;
t35=C_SCHEME_TRUE;
t36=t5;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
t5=t36;
goto loop;}
else{
t9=(C_word)C_i_car(t3);
t10=(C_word)C_eqp(lf[74],t9);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t3);
/* scrutinizer.scm: 314  loop */
t32=t1;
t33=t2;
t34=t11;
t35=t4;
t36=C_SCHEME_TRUE;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
t5=t36;
goto loop;}
else{
t11=(C_word)C_i_car(t2);
t12=(C_word)C_eqp(lf[75],t11);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t2);
t14=f_2279(t13);
/* scrutinizer.scm: 316  match-rest */
t15=((C_word*)t0)[3];
f_2856(t15,t1,t14,t3);}
else{
t13=(C_word)C_i_car(t3);
t14=(C_word)C_eqp(lf[75],t13);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t3);
t16=f_2279(t15);
/* scrutinizer.scm: 318  match-rest */
t17=((C_word*)t0)[3];
f_2856(t17,t1,t16,t2);}
else{
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3023,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t16=(C_word)C_i_car(t2);
t17=(C_word)C_i_car(t3);
/* scrutinizer.scm: 319  match */
t18=((C_word*)((C_word*)t0)[2])[1];
f_2569(t18,t15,t16,t17);}}}}}}}

/* k3021 in loop in match-args in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 319  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2915(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match-rest in match-args in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2856(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2856,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2862,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2873 in match-rest in match-args in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2874,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2881,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 298  every */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t4,t5,t2);}

/* a2899 in a2873 in match-rest in match-args in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2900,3,t0,t1,t2);}
/* match87 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2569(t3,t1,((C_word*)t0)[2],t2);}

/* k2879 in a2873 in match-rest in match-args in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2881,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 299  rest-type */
t4=t2;
f_2888(t4,f_2279(t3));}
else{
t3=t2;
f_2888(t3,lf[21]);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2886 in k2879 in a2873 in match-rest in match-args in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 299  match */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2569(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2861 in match-rest in match-args in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2868,tmp=(C_word)a,a+=2,tmp);
/* scrutinizer.scm: 297  break */
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t1,t2,((C_word*)t0)[2]);}

/* a2867 in a2861 in match-rest in match-args in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2868,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[75],t2));}

/* match1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2578(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2578,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eqp(t2,lf[21]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_eqp(t3,lf[21]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[92]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[92]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[72]);
t10=(C_truep(t9)?(C_word)C_i_memq(t3,lf[93]):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[72]);
t12=(C_truep(t11)?(C_word)C_i_memq(t2,lf[94]):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t13=(C_word)C_eqp(lf[48],t2);
if(C_truep(t13)){
if(C_truep((C_word)C_i_pairp(t3))){
t14=(C_word)C_i_car(t3);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_eqp(lf[48],t14));}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(lf[48],t3);
if(C_truep(t14)){
if(C_truep((C_word)C_i_pairp(t2))){
t15=(C_word)C_i_car(t2);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_eqp(lf[48],t15));}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t16=(C_word)C_i_car(t2);
t17=t15;
f_2665(t17,(C_word)C_eqp(lf[33],t16));}
else{
t16=t15;
f_2665(t16,C_SCHEME_FALSE);}}}}}}}}}}}

/* k2663 in match1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2665,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 278  any */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[5],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_2684(t4,(C_word)C_eqp(lf[33],t3));}
else{
t3=t2;
f_2684(t3,C_SCHEME_FALSE);}}}

/* k2682 in k2663 in match1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2684,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 279  any */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[5],t2,t3);}
else{
t2=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[95]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[70]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(((C_word*)t0)[6],lf[96]));}
else{
t3=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[97]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[70]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(((C_word*)t0)[6],lf[98]));}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
t7=t4;
f_2721(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t4;
f_2721(t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2721(t5,C_SCHEME_FALSE);}}}}}

/* k2719 in k2682 in k2663 in match1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2721(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2721,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,lf[48]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 285  named? */
f_2239(t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(t2,lf[54]);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_i_equalp(((C_word*)t0)[7],((C_word*)t0)[6]):C_SCHEME_FALSE));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2779 in k2719 in k2682 in k2663 in match1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[7]):(C_word)C_i_cadr(((C_word*)t0)[7]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 286  named? */
f_2239(t3,((C_word*)t0)[6]);}

/* k2770 in k2779 in k2719 in k2682 in k2663 in match1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[8]):(C_word)C_i_cadr(((C_word*)t0)[8]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* scrutinizer.scm: 287  named? */
f_2239(t3,((C_word*)t0)[7]);}

/* k2761 in k2770 in k2779 in k2719 in k2682 in k2663 in match1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cdddr(((C_word*)t0)[9]):(C_word)C_i_cddr(((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2754,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 288  named? */
f_2239(t3,((C_word*)t0)[8]);}

/* k2752 in k2761 in k2770 in k2779 in k2719 in k2682 in k2663 in match1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2754,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2748,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 289  match-args */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2850(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2746 in k2752 in k2761 in k2770 in k2779 in k2719 in k2682 in k2663 in match1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* scrutinizer.scm: 290  match-results */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3060(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a2688 in k2682 in k2663 in match1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2689,3,t0,t1,t2);}
/* match87 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2569(t3,t1,((C_word*)t0)[2],t2);}

/* a2669 in k2663 in match1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2670,3,t0,t1,t2);}
/* match87 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2569(t3,t1,t2,((C_word*)t0)[2]);}

/* match in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2569(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2569,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2573,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 265  match1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2578(t5,t4,t2,t3);}

/* k2571 in match in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[77]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* merge-result-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2503(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2503,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_not_pair_p(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_not_pair_p(t3));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[21]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t7,t9);
t11=(C_word)C_a_i_cons(&a,2,lf[33],t10);
/* scrutinizer.scm: 262  simplify */
t12=((C_word*)((C_word*)t0)[2])[1];
f_1832(3,t12,t6,t11);}}}}

/* k2530 in merge-result-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2536,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 263  merge-result-types */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2503(t5,t2,t3,t4);}

/* k2534 in k2530 in merge-result-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2536,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* merge-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2301(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2301,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_memq(t4,lf[88]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t3:lf[89]));}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[75],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2336,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t7=(C_word)C_i_car(t3);
t8=t6;
f_2336(t8,(C_word)C_eqp(lf[75],t7));}
else{
t7=t6;
f_2336(t7,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(lf[74],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t9=(C_word)C_i_car(t3);
t10=t8;
f_2397(t10,(C_word)C_eqp(lf[74],t9));}
else{
t9=t8;
f_2397(t9,C_SCHEME_FALSE);}}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2461,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_car(t3);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[33],t12);
/* scrutinizer.scm: 256  simplify */
t14=((C_word*)((C_word*)t0)[3])[1];
f_1832(3,t14,t8,t13);}}}}

/* k2459 in merge-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2465,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 257  merge-argument-types */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2301(t5,t2,t3,t4);}

/* k2463 in k2459 in merge-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2465,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2395 in merge-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2397,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2408,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[33],t6);
/* scrutinizer.scm: 253  simplify */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1832(3,t8,t2,t7);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[91]);}}

/* k2406 in k2395 in merge-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2412,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* scrutinizer.scm: 254  merge-argument-types */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2301(t6,t3,t4,t5);}

/* k2414 in k2406 in k2395 in merge-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2410 in k2406 in k2395 in merge-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2412,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[74],t2));}

/* k2334 in merge-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2336(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2336,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2347,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=f_2279(t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=f_2279(t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[33],t8);
/* scrutinizer.scm: 246  simplify */
t10=((C_word*)((C_word*)t0)[2])[1];
f_1832(3,t10,t2,t9);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[90]);}}

/* k2345 in k2334 in merge-argument-types in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2347,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[75],t2));}

/* simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_1841(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1841,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 172  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[87]+1)))(3,*((C_word*)lf[87]+1),t1,t3);}

/* a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1847,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[8]))){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
t4=(C_word)C_eqp(t3,lf[33]);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[8]);
t6=(C_word)C_eqp(C_fix(2),t5);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* scrutinizer.scm: 177  simplify */
t8=((C_word*)((C_word*)t0)[7])[1];
f_1832(3,t8,t1,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* scrutinizer.scm: 178  every */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t7,((C_word*)((C_word*)t0)[2])[1],t8);}}
else{
t5=(C_word)C_eqp(t3,lf[48]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 219  named? */
f_2239(t6,((C_word*)t0)[8]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[8]);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[8]);}}

/* k2232 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2234,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdddr(((C_word*)t0)[4]):(C_word)C_i_cddr(((C_word*)t0)[4]));
t4=(C_truep(t2)?(C_word)C_a_i_list(&a,1,t2):C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(C_truep(t2)?(C_word)C_i_caddr(((C_word*)t0)[4]):(C_word)C_i_cadr(((C_word*)t0)[4]));
/* map */
t7=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k2210 in k2232 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2202,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[21],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=t3;
f_2202(2,t5,lf[21]);}
else{
/* map */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k2200 in k2210 in k2232 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 221  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[78]+1)))(6,*((C_word*)lf[78]+1),((C_word*)t0)[4],lf[86],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1985,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm: 179  any */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t2,t3,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm: 197  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t2,t3,t4);}}

/* a2127 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2128,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 199  simplify */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1832(3,t4,t3,t2);}

/* k2130 in a2127 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2138,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
t4=t2;
f_2138(t4,(C_word)C_eqp(lf[33],t3));}
else{
t3=t2;
f_2138(t3,C_SCHEME_FALSE);}}

/* k2136 in k2130 in a2127 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2138,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[3]));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[25]);
if(C_truep(t2)){
/* scrutinizer.scm: 203  return */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],lf[25]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}}}

/* k1994 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2038,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2038(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k1994 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2038(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2038,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* scrutinizer.scm: 207  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[21],t4);
if(C_truep(t5)){
/* scrutinizer.scm: 208  return */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,lf[21]);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 209  any */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t6,t7,t8);}}}

/* a2109 in loop in k1994 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2110,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* type<=?91 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3115(t4,t1,t3,t2);}

/* k2061 in loop in k1994 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2063,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 210  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2038(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2100,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 211  any */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t2,t3,((C_word*)t0)[3]);}}

/* a2099 in k2061 in loop in k1994 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2100,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* type<=?91 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3115(t4,t1,t3,t2);}

/* k2074 in k2061 in loop in k1994 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2076,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm: 212  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2038(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* scrutinizer.scm: 213  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2038(t5,((C_word*)t0)[3],t2,t4);}}

/* k1997 in k1994 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1999,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t1,t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=C_retrieve(lf[77]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2026,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2028,tmp=(C_word)a,a+=2,tmp);
/* scrutinizer.scm: 217  any */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t5,t6,t1);}}

/* a2027 in k1997 in k1994 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2028,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,lf[21]));}

/* k2024 in k1997 in k1994 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[82]:((C_word*)t0)[3]);
/* ##sys#append */
t3=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* k2017 in k1997 in k1994 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2019,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[33],t1);
/* scrutinizer.scm: 217  simplify */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1832(3,t3,((C_word*)t0)[2],t2);}

/* a1984 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1985,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[48],t2));}

/* k1886 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[48]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* scrutinizer.scm: 181  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[80]))(5,*((C_word*)lf[80]+1),((C_word*)t0)[6],t2,C_SCHEME_FALSE,t3);}}

/* a1892 in k1886 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1893,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 183  named? */
f_2239(t4,t2);}

/* k1974 in a1892 in k1886 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[7]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_caddr(((C_word*)t0)[7]):(C_word)C_i_cadr(((C_word*)t0)[7]));
t4=(C_truep(t2)?(C_word)C_i_cdddr(((C_word*)t0)[7]):(C_word)C_i_cddr(((C_word*)t0)[7]));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1958,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 186  named? */
f_2239(t5,((C_word*)t0)[6]);}

/* k1956 in k1974 in a1892 in k1886 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[8]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_caddr(((C_word*)t0)[8]):(C_word)C_i_cadr(((C_word*)t0)[8]));
t4=(C_truep(t2)?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t5=(C_truep(((C_word*)t0)[7])?(C_truep(t2)?(C_word)C_eqp(((C_word*)t0)[7],t2):C_SCHEME_FALSE):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]):C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1931,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* scrutinizer.scm: 192  merge-argument-types */
t8=((C_word*)((C_word*)t0)[3])[1];
f_2301(t8,t7,((C_word*)t0)[2],t3);}

/* k1929 in k1956 in k1974 in a1892 in k1886 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1927,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 193  merge-result-types */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2503(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1925 in k1929 in k1956 in k1974 in a1892 in k1886 in k1880 in a1846 in simplify1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 189  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[78]+1)))(6,*((C_word*)lf[78]+1),((C_word*)t0)[4],lf[79],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* simplify in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1832,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1836,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 168  simplify1 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1841(t4,t3,t2);}

/* k1834 in simplify in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[77]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* named? in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2239(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2239,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[48],t3);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_nullp(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2262,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_2262(t8,t6);}
else{
t8=(C_word)C_i_cadr(t2);
t9=t7;
f_2262(t9,(C_word)C_i_pairp(t8));}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2260 in named? in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_2262(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* rest-type in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static C_word C_fcall f_2279(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(lf[21]);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(lf[76],t2);
return((C_truep(t3)?lf[21]:(C_word)C_i_car(t1)));}}

/* type<=? in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3115(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3115,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_memq(t3,lf[69]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=t3;
t7=(C_word)C_eqp(t6,lf[70]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_memq(t2,lf[71]));}
else{
t8=(C_word)C_eqp(t6,lf[48]);
if(C_truep(t8)){
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_car(t2);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_eqp(lf[48],t9));}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[72]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_memq(t2,lf[73]));}
else{
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_eqp(t10,lf[33]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3191,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 339  every */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t1,t12,t13);}
else{
t12=(C_word)C_eqp(t10,lf[48]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_pairp(t13);
t15=(C_truep(t14)?(C_word)C_i_cadr(t2):(C_word)C_i_caddr(t2));
t16=(C_word)C_i_cadr(t3);
t17=(C_word)C_i_pairp(t16);
t18=(C_truep(t17)?(C_word)C_i_cadr(t3):(C_word)C_i_caddr(t3));
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_pairp(t19);
t21=(C_truep(t20)?(C_word)C_i_cddr(t2):(C_word)C_i_cdddr(t2));
t22=(C_word)C_i_cadr(t3);
t23=(C_word)C_i_pairp(t22);
t24=(C_truep(t23)?(C_word)C_i_cddr(t3):(C_word)C_i_cdddr(t3));
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3222,a[2]=t26,a[3]=t24,a[4]=t21,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t28=((C_word*)t26)[1];
f_3222(t28,t1,t15,t18,C_fix(0),C_fix(0));}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}}}}}}

/* loop1 in type<=? in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3222(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3222,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_i_nullp(t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_3238(t8,t6);}
else{
t8=t5;
t9=t7;
f_3238(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[74]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 360  loop1 */
t25=t1;
t26=t8;
t27=t3;
t28=C_fix(1);
t29=t5;
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_eqp(t8,lf[74]);
if(C_truep(t9)){
t10=(C_word)C_i_cdr(t3);
/* scrutinizer.scm: 362  loop1 */
t25=t1;
t26=t2;
t27=t10;
t28=t4;
t29=C_fix(1);
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t10=(C_word)C_i_car(t2);
t11=(C_word)C_eqp(t10,lf[75]);
if(C_truep(t11)){
t12=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 364  loop1 */
t25=t1;
t26=t12;
t27=t3;
t28=C_fix(2);
t29=t5;
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t12=(C_word)C_i_car(t3);
t13=(C_word)C_eqp(t12,lf[75]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t3);
/* scrutinizer.scm: 366  loop1 */
t25=t1;
t26=t2;
t27=t14;
t28=t4;
t29=C_fix(2);
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3357,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_car(t3);
/* scrutinizer.scm: 367  type<=? */
t17=((C_word*)((C_word*)t0)[5])[1];
f_3115(t17,t14,t15,t16);}}}}}}}

/* k3355 in loop1 in type<=? in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 368  loop1 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3222(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3236 in loop1 in type<=? in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3238,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3243(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k3236 in loop1 in type<=? in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3243(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3243,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(lf[21],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_nullp(t2));}
else{
t5=(C_word)C_eqp(lf[21],t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3271,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
/* scrutinizer.scm: 355  type<=? */
t9=((C_word*)((C_word*)t0)[2])[1];
f_3115(t9,t6,t7,t8);}}}}

/* k3269 in loop2 in k3236 in loop1 in type<=? in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm: 356  loop2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3243(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3190 in type<=? in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3191,3,t0,t1,t2);}
/* type<=?91 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3115(t3,t1,t2,((C_word*)t0)[2]);}

/* procedure-type? in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4095,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[48],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[48],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(lf[33],t6);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 472  every */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t1,((C_word*)((C_word*)t0)[2])[1],t8);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* result-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_1780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1780,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[21],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[65]);}
else{
t4=(C_word)C_i_length(t2);
t5=C_retrieve(lf[59]);
t6=(C_word)C_eqp(t5,C_fix(1));
t7=(C_truep(t6)?lf[60]:lf[61]);
t8=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[66]);}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1802,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t9);}}}

/* k1800 in result-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],t1);}

/* k1803 in k1800 in result-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[68],((C_word*)t0)[5]);}

/* k1806 in k1803 in k1800 in result-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k1809 in k1806 in k1803 in k1800 in result-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[67],((C_word*)t0)[5]);}

/* k1812 in k1809 in k1806 in k1803 in k1800 in result-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in result-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in result-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1823,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k1828 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in result-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in result-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* argument-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_1734(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1734,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
t4=C_retrieve(lf[59]);
t5=(C_word)C_eqp(t4,C_fix(1));
t6=(C_truep(t5)?lf[60]:lf[61]);
t7=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[62]);}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1750,a[2]=t3,a[3]=t6,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t8);}}

/* k1748 in argument-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],t1);}

/* k1751 in k1748 in argument-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[64],((C_word*)t0)[5]);}

/* k1754 in k1751 in k1748 in argument-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k1757 in k1754 in k1751 in k1748 in argument-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[63],((C_word*)t0)[5]);}

/* k1760 in k1757 in k1754 in k1751 in k1748 in argument-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k1763 in k1760 in k1757 in k1754 in k1751 in k1748 in argument-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k1766 in k1763 in k1760 in k1757 in k1754 in k1751 in k1748 in argument-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1771,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k1776 in k1766 in k1763 in k1760 in k1757 in k1754 in k1751 in k1748 in argument-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1769 in k1766 in k1763 in k1760 in k1757 in k1754 in k1751 in k1748 in argument-string in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1589,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[21]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[44]);}
else{
t5=(C_word)C_eqp(t3,lf[45]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[46]);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* scrutinizer.scm: 130  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[48]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_i_stringp(t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1635,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t9)){
t11=t10;
f_1635(t11,t9);}
else{
t11=(C_word)C_i_cadr(t2);
t12=t10;
f_1635(t12,(C_word)C_i_symbolp(t11));}}
else{
t8=(C_word)C_eqp(t6,lf[33]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1700,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[2])[1],t10);}
else{
t9=(C_word)C_eqp(t6,lf[54]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1713,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t10);}
else{
/* scrutinizer.scm: 145  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t1,lf[57],t2);}}}}
else{
/* scrutinizer.scm: 146  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t1,lf[58],t2);}}}}}

/* k1711 in typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[55],t1);}

/* k1714 in k1711 in typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1719,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,t3,((C_word*)t0)[3]);}

/* k1717 in k1714 in k1711 in typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1698 in typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 140  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[52]))(4,*((C_word*)lf[52]+1),((C_word*)t0)[2],t1,lf[53]);}

/* k1633 in typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_1635(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1635,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm: 135  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),((C_word*)t0)[4],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t2);}}

/* k1643 in k1633 in typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[51],t1);}

/* k1646 in k1643 in k1633 in typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1651,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* scrutinizer.scm: 137  argument-string */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1734(t5,t3,t4);}

/* k1670 in k1646 in k1643 in k1633 in typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1649 in k1646 in k1643 in k1633 in typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[50],((C_word*)t0)[4]);}

/* k1652 in k1649 in k1646 in k1643 in k1633 in typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* scrutinizer.scm: 138  result-string */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1780(t5,t3,t4);}

/* k1662 in k1652 in k1649 in k1646 in k1643 in k1633 in typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1655 in k1652 in k1649 in k1646 in k1643 in k1633 in typename in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* always-true in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_1548(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1548,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1552,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 116  always-true1 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1516(3,t6,t5,t2);}

/* k1550 in always-true in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1555,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t3);}
else{
t3=t2;
f_1555(2,t3,C_SCHEME_UNDEFINED);}}

/* k1560 in k1550 in always-true in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[43],t1);}

/* k1563 in k1560 in k1550 in always-true in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k1566 in k1563 in k1560 in k1550 in always-true in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[42],((C_word*)t0)[4]);}

/* k1569 in k1566 in k1563 in k1560 in k1550 in always-true in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k1572 in k1569 in k1566 in k1563 in k1560 in k1550 in always-true in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k1575 in k1572 in k1569 in k1566 in k1563 in k1560 in k1550 in always-true in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1580,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1587,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 123  pp-fragment */
t4=((C_word*)t0)[3];
f_3721(t4,t3,((C_word*)t0)[2]);}

/* k1585 in k1575 in k1572 in k1569 in k1566 in k1563 in k1560 in k1550 in always-true in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1578 in k1575 in k1572 in k1569 in k1566 in k1563 in k1560 in k1550 in always-true in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1563 in k1560 in k1550 in always-true in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 118  report */
t2=((C_word*)t0)[4];
f_3536(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1553 in k1550 in always-true in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pp-fragment in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3721(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3721,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3729,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3731,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 417  with-output-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,t4);}

/* a3730 in pp-fragment in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3739,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 419  fragment */
f_3667(t2,((C_word*)t0)[2]);}

/* k3737 in a3730 in pp-fragment in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 419  pp */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),((C_word*)t0)[2],t1);}

/* k3727 in pp-fragment in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 416  string-chomp */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t1);}

/* fragment in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3667(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3667,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3671,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 408  build-expression-tree */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t3,t2);}

/* k3669 in fragment in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3671,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3676,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3676(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* walk in k3669 in fragment in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3676(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3676,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=t3;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(3)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[34]);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t5=(C_word)C_fixnum_increase(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3703,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3711,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3715,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_length(t2);
/* scrutinizer.scm: 413  min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t8,C_fix(5),t9);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}}}

/* k3713 in walk in k3669 in fragment in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 413  take */
((C_proc4)C_retrieve_symbol_proc(lf[36]))(4,*((C_word*)lf[36]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3709 in walk in k3669 in fragment in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3699 in walk in k3669 in fragment in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3703,3,t0,t1,t2);}
/* g785786792 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3676(t3,t1,t2,((C_word*)t0)[2]);}

/* always-true1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1516,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_1523(t5,(C_word)C_eqp(lf[33],t4));}
else{
t4=t3;
f_1523(t4,C_SCHEME_FALSE);}}

/* k1521 in always-true1 in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_1523(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm: 112  every */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}
else{
t2=(C_word)C_i_memq(((C_word*)t0)[4],lf[32]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:C_SCHEME_TRUE));}}

/* variable-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_1448(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1448,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1507,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 97   get */
((C_proc5)C_retrieve_symbol_proc(lf[29]))(5,*((C_word*)lf[29]+1),t6,((C_word*)t0)[3],t2,lf[30]);}

/* k1505 in variable-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1507,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1514,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 98   ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),t2,((C_word*)t0)[2],lf[28]);}
else{
t2=((C_word*)t0)[3];
f_1455(t2,C_SCHEME_FALSE);}}

/* k1512 in k1505 in variable-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1455(t2,(C_word)C_i_not(t1));}

/* k1453 in variable-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_1455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1455,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[21]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(lf[25],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1470,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t6);}
else{
t5=(C_word)C_i_cdr(t2);
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,1,t5));}}
else{
/* scrutinizer.scm: 109  global-result */
t3=((C_word*)t0)[2];
f_1411(t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4]);}}}

/* k1472 in k1453 in variable-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[27],t1);}

/* k1475 in k1472 in k1453 in variable-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1480,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1490,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 106  real-name */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1488 in k1475 in k1472 in k1453 in variable-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1478 in k1475 in k1472 in k1453 in variable-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[26],((C_word*)t0)[2]);}

/* k1481 in k1478 in k1475 in k1472 in k1453 in variable-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k1484 in k1481 in k1478 in k1475 in k1472 in k1453 in variable-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 103  report */
t2=((C_word*)t0)[4];
f_3536(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1468 in k1453 in variable-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[21]);}

/* global-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_1411(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1411,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1415,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 83   ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),t4,t2,lf[24]);}

/* k1413 in global-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1415,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,lf[20]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1427,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,t1));}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[21]);}}

/* k1429 in k1413 in global-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1434,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[22],t1);}

/* k1432 in k1429 in k1413 in global-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1435 in k1432 in k1429 in k1413 in global-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k1438 in k1435 in k1432 in k1429 in k1413 in global-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t2,((C_word*)t0)[2]);}

/* k1441 in k1438 in k1435 in k1432 in k1429 in k1413 in global-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 90   report */
t2=((C_word*)t0)[4];
f_3536(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1425 in k1413 in global-result in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[21]);}

/* report in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3536(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3536,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3544,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 392  location-name */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3546(t5,t4,t2);}

/* k3542 in report in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 389  compiler-warning */
((C_proc6)C_retrieve_symbol_proc(lf[17]))(6,*((C_word*)lf[17]+1),((C_word*)t0)[3],lf[18],lf[19],t1,((C_word*)t0)[2]);}

/* location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3546(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3546,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3549,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[12]);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3587,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3612,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3612(t8,t1,t2);}}}

/* rec in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3612(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3612,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
/* scrutinizer.scm: 404  location-name */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3546(t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t4);}}

/* k3623 in rec in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[16],t1);}

/* k3626 in k3623 in rec in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3652,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
/* scrutinizer.scm: 405  lname */
f_3549(t3,t4);}

/* k3650 in k3626 in k3623 in rec in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3629 in k3626 in k3623 in rec in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[15],((C_word*)t0)[4]);}

/* k3632 in k3629 in k3626 in k3623 in rec in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3644,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 405  rec */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3612(t5,t3,t4);}

/* k3642 in k3632 in k3629 in k3626 in k3623 in rec in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3635 in k3632 in k3629 in k3626 in k3623 in rec in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3585 in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[14],t1);}

/* k3588 in k3585 in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3593,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3603,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
/* scrutinizer.scm: 400  lname */
f_3549(t3,t4);}

/* k3601 in k3588 in k3585 in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3591 in k3588 in k3585 in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[13],((C_word*)t0)[2]);}

/* k3594 in k3591 in k3588 in k3585 in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lname in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_fcall f_3549(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3549,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3556,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[11]);}}

/* k3554 in lname in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3559,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,lf[9],t1);}

/* k3557 in k3554 in lname in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3572,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 396  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),t3,((C_word*)t0)[2]);}

/* k3570 in k3557 in k3554 in lname in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3560 in k3557 in k3554 in lname in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k3563 in k3560 in k3557 in k3554 in lname in location-name in ##compiler#scrutinize in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* d in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1288r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1288r(t0,t1,t2,t3);}}

static void C_ccall f_1288r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
if(C_truep((C_word)C_fudge(C_fix(13)))){
t4=*((C_word*)lf[1]+1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1298,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t5,lf[5],t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1296 in d in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1301,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t2,C_retrieve(lf[3]),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1299 in k1296 in d in k1284 in k1281 in k1278 in k1275 in k1272 in k1269 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[375] = {
{"toplevel:scrutinizer_scm",(void*)C_scrutinizer_toplevel},
{"f_1271:scrutinizer_scm",(void*)f_1271},
{"f_1274:scrutinizer_scm",(void*)f_1274},
{"f_1277:scrutinizer_scm",(void*)f_1277},
{"f_1280:scrutinizer_scm",(void*)f_1280},
{"f_1283:scrutinizer_scm",(void*)f_1283},
{"f_1286:scrutinizer_scm",(void*)f_1286},
{"f_5082:scrutinizer_scm",(void*)f_5082},
{"f_5086:scrutinizer_scm",(void*)f_5086},
{"f_5165:scrutinizer_scm",(void*)f_5165},
{"f_5089:scrutinizer_scm",(void*)f_5089},
{"f_5152:scrutinizer_scm",(void*)f_5152},
{"f_5155:scrutinizer_scm",(void*)f_5155},
{"f_5158:scrutinizer_scm",(void*)f_5158},
{"f_5095:scrutinizer_scm",(void*)f_5095},
{"f_5102:scrutinizer_scm",(void*)f_5102},
{"f_5104:scrutinizer_scm",(void*)f_5104},
{"f_5120:scrutinizer_scm",(void*)f_5120},
{"f_5139:scrutinizer_scm",(void*)f_5139},
{"f_5126:scrutinizer_scm",(void*)f_5126},
{"f_5129:scrutinizer_scm",(void*)f_5129},
{"f_1306:scrutinizer_scm",(void*)f_1306},
{"f_4430:scrutinizer_scm",(void*)f_4430},
{"f_5037:scrutinizer_scm",(void*)f_5037},
{"f_5050:scrutinizer_scm",(void*)f_5050},
{"f_5035:scrutinizer_scm",(void*)f_5035},
{"f_4951:scrutinizer_scm",(void*)f_4951},
{"f_5016:scrutinizer_scm",(void*)f_5016},
{"f_4963:scrutinizer_scm",(void*)f_4963},
{"f_4971:scrutinizer_scm",(void*)f_4971},
{"f_4974:scrutinizer_scm",(void*)f_4974},
{"f_5003:scrutinizer_scm",(void*)f_5003},
{"f_5006:scrutinizer_scm",(void*)f_5006},
{"f_5009:scrutinizer_scm",(void*)f_5009},
{"f_4997:scrutinizer_scm",(void*)f_4997},
{"f_4977:scrutinizer_scm",(void*)f_4977},
{"f_4980:scrutinizer_scm",(void*)f_4980},
{"f_4983:scrutinizer_scm",(void*)f_4983},
{"f_4986:scrutinizer_scm",(void*)f_4986},
{"f_4989:scrutinizer_scm",(void*)f_4989},
{"f_4993:scrutinizer_scm",(void*)f_4993},
{"f_4954:scrutinizer_scm",(void*)f_4954},
{"f_4827:scrutinizer_scm",(void*)f_4827},
{"f_4913:scrutinizer_scm",(void*)f_4913},
{"f_4916:scrutinizer_scm",(void*)f_4916},
{"f_4919:scrutinizer_scm",(void*)f_4919},
{"f_4922:scrutinizer_scm",(void*)f_4922},
{"f_4925:scrutinizer_scm",(void*)f_4925},
{"f_4929:scrutinizer_scm",(void*)f_4929},
{"f_4830:scrutinizer_scm",(void*)f_4830},
{"f_4905:scrutinizer_scm",(void*)f_4905},
{"f_4855:scrutinizer_scm",(void*)f_4855},
{"f_4862:scrutinizer_scm",(void*)f_4862},
{"f_4865:scrutinizer_scm",(void*)f_4865},
{"f_4868:scrutinizer_scm",(void*)f_4868},
{"f_4871:scrutinizer_scm",(void*)f_4871},
{"f_4874:scrutinizer_scm",(void*)f_4874},
{"f_4877:scrutinizer_scm",(void*)f_4877},
{"f_4880:scrutinizer_scm",(void*)f_4880},
{"f_4883:scrutinizer_scm",(void*)f_4883},
{"f_4886:scrutinizer_scm",(void*)f_4886},
{"f_4836:scrutinizer_scm",(void*)f_4836},
{"f_4842:scrutinizer_scm",(void*)f_4842},
{"f_4745:scrutinizer_scm",(void*)f_4745},
{"f_4805:scrutinizer_scm",(void*)f_4805},
{"f_4752:scrutinizer_scm",(void*)f_4752},
{"f_4798:scrutinizer_scm",(void*)f_4798},
{"f_4790:scrutinizer_scm",(void*)f_4790},
{"f_4788:scrutinizer_scm",(void*)f_4788},
{"f_4755:scrutinizer_scm",(void*)f_4755},
{"f_4777:scrutinizer_scm",(void*)f_4777},
{"f_4781:scrutinizer_scm",(void*)f_4781},
{"f_4758:scrutinizer_scm",(void*)f_4758},
{"f_4765:scrutinizer_scm",(void*)f_4765},
{"f_4651:scrutinizer_scm",(void*)f_4651},
{"f_4695:scrutinizer_scm",(void*)f_4695},
{"f_4698:scrutinizer_scm",(void*)f_4698},
{"f_4723:scrutinizer_scm",(void*)f_4723},
{"f_4701:scrutinizer_scm",(void*)f_4701},
{"f_4704:scrutinizer_scm",(void*)f_4704},
{"f_4707:scrutinizer_scm",(void*)f_4707},
{"f_4711:scrutinizer_scm",(void*)f_4711},
{"f_4672:scrutinizer_scm",(void*)f_4672},
{"f_4687:scrutinizer_scm",(void*)f_4687},
{"f_4669:scrutinizer_scm",(void*)f_4669},
{"f_4636:scrutinizer_scm",(void*)f_4636},
{"f_4510:scrutinizer_scm",(void*)f_4510},
{"f_4513:scrutinizer_scm",(void*)f_4513},
{"f_4516:scrutinizer_scm",(void*)f_4516},
{"f_4519:scrutinizer_scm",(void*)f_4519},
{"f_4525:scrutinizer_scm",(void*)f_4525},
{"f_4610:scrutinizer_scm",(void*)f_4610},
{"f_4606:scrutinizer_scm",(void*)f_4606},
{"f_4552:scrutinizer_scm",(void*)f_4552},
{"f_4559:scrutinizer_scm",(void*)f_4559},
{"f_4562:scrutinizer_scm",(void*)f_4562},
{"f_4565:scrutinizer_scm",(void*)f_4565},
{"f_4568:scrutinizer_scm",(void*)f_4568},
{"f_4578:scrutinizer_scm",(void*)f_4578},
{"f_4571:scrutinizer_scm",(void*)f_4571},
{"f_4574:scrutinizer_scm",(void*)f_4574},
{"f_4528:scrutinizer_scm",(void*)f_4528},
{"f_4533:scrutinizer_scm",(void*)f_4533},
{"f_4459:scrutinizer_scm",(void*)f_4459},
{"f_4446:scrutinizer_scm",(void*)f_4446},
{"f_4398:scrutinizer_scm",(void*)f_4398},
{"f_3741:scrutinizer_scm",(void*)f_3741},
{"f_4085:scrutinizer_scm",(void*)f_4085},
{"f_4077:scrutinizer_scm",(void*)f_4077},
{"f_4073:scrutinizer_scm",(void*)f_4073},
{"f_4028:scrutinizer_scm",(void*)f_4028},
{"f_4035:scrutinizer_scm",(void*)f_4035},
{"f_4038:scrutinizer_scm",(void*)f_4038},
{"f_4063:scrutinizer_scm",(void*)f_4063},
{"f_4041:scrutinizer_scm",(void*)f_4041},
{"f_4044:scrutinizer_scm",(void*)f_4044},
{"f_4047:scrutinizer_scm",(void*)f_4047},
{"f_4050:scrutinizer_scm",(void*)f_4050},
{"f_4053:scrutinizer_scm",(void*)f_4053},
{"f_4056:scrutinizer_scm",(void*)f_4056},
{"f_4059:scrutinizer_scm",(void*)f_4059},
{"f_3827:scrutinizer_scm",(void*)f_3827},
{"f_3846:scrutinizer_scm",(void*)f_3846},
{"f_3976:scrutinizer_scm",(void*)f_3976},
{"f_3979:scrutinizer_scm",(void*)f_3979},
{"f_4021:scrutinizer_scm",(void*)f_4021},
{"f_3982:scrutinizer_scm",(void*)f_3982},
{"f_3985:scrutinizer_scm",(void*)f_3985},
{"f_3988:scrutinizer_scm",(void*)f_3988},
{"f_3991:scrutinizer_scm",(void*)f_3991},
{"f_3994:scrutinizer_scm",(void*)f_3994},
{"f_3997:scrutinizer_scm",(void*)f_3997},
{"f_4000:scrutinizer_scm",(void*)f_4000},
{"f_4003:scrutinizer_scm",(void*)f_4003},
{"f_4006:scrutinizer_scm",(void*)f_4006},
{"f_4009:scrutinizer_scm",(void*)f_4009},
{"f_3853:scrutinizer_scm",(void*)f_3853},
{"f_3872:scrutinizer_scm",(void*)f_3872},
{"f_3903:scrutinizer_scm",(void*)f_3903},
{"f_3910:scrutinizer_scm",(void*)f_3910},
{"f_3913:scrutinizer_scm",(void*)f_3913},
{"f_3916:scrutinizer_scm",(void*)f_3916},
{"f_3919:scrutinizer_scm",(void*)f_3919},
{"f_3922:scrutinizer_scm",(void*)f_3922},
{"f_3925:scrutinizer_scm",(void*)f_3925},
{"f_3948:scrutinizer_scm",(void*)f_3948},
{"f_3928:scrutinizer_scm",(void*)f_3928},
{"f_3931:scrutinizer_scm",(void*)f_3931},
{"f_3934:scrutinizer_scm",(void*)f_3934},
{"f_3937:scrutinizer_scm",(void*)f_3937},
{"f_3940:scrutinizer_scm",(void*)f_3940},
{"f_3885:scrutinizer_scm",(void*)f_3885},
{"f_3856:scrutinizer_scm",(void*)f_3856},
{"f_4322:scrutinizer_scm",(void*)f_4322},
{"f_4369:scrutinizer_scm",(void*)f_4369},
{"f_4332:scrutinizer_scm",(void*)f_4332},
{"f_4359:scrutinizer_scm",(void*)f_4359},
{"f_3859:scrutinizer_scm",(void*)f_3859},
{"f_3832:scrutinizer_scm",(void*)f_3832},
{"f_3744:scrutinizer_scm",(void*)f_3744},
{"f_3748:scrutinizer_scm",(void*)f_3748},
{"f_3751:scrutinizer_scm",(void*)f_3751},
{"f_3812:scrutinizer_scm",(void*)f_3812},
{"f_3754:scrutinizer_scm",(void*)f_3754},
{"f_3757:scrutinizer_scm",(void*)f_3757},
{"f_3770:scrutinizer_scm",(void*)f_3770},
{"f_3773:scrutinizer_scm",(void*)f_3773},
{"f_3782:scrutinizer_scm",(void*)f_3782},
{"f_3785:scrutinizer_scm",(void*)f_3785},
{"f_3788:scrutinizer_scm",(void*)f_3788},
{"f_3791:scrutinizer_scm",(void*)f_3791},
{"f_3767:scrutinizer_scm",(void*)f_3767},
{"f_3760:scrutinizer_scm",(void*)f_3760},
{"f_4137:scrutinizer_scm",(void*)f_4137},
{"f_4269:scrutinizer_scm",(void*)f_4269},
{"f_4172:scrutinizer_scm",(void*)f_4172},
{"f_4233:scrutinizer_scm",(void*)f_4233},
{"f_4244:scrutinizer_scm",(void*)f_4244},
{"f_4202:scrutinizer_scm",(void*)f_4202},
{"f_4163:scrutinizer_scm",(void*)f_4163},
{"f_4154:scrutinizer_scm",(void*)f_4154},
{"f_3455:scrutinizer_scm",(void*)f_3455},
{"f_3509:scrutinizer_scm",(void*)f_3509},
{"f_3512:scrutinizer_scm",(void*)f_3512},
{"f_3515:scrutinizer_scm",(void*)f_3515},
{"f_3518:scrutinizer_scm",(void*)f_3518},
{"f_3521:scrutinizer_scm",(void*)f_3521},
{"f_3524:scrutinizer_scm",(void*)f_3524},
{"f_3527:scrutinizer_scm",(void*)f_3527},
{"f_3530:scrutinizer_scm",(void*)f_3530},
{"f_3502:scrutinizer_scm",(void*)f_3502},
{"f_3487:scrutinizer_scm",(void*)f_3487},
{"f_3490:scrutinizer_scm",(void*)f_3490},
{"f_3493:scrutinizer_scm",(void*)f_3493},
{"f_3496:scrutinizer_scm",(void*)f_3496},
{"f_3499:scrutinizer_scm",(void*)f_3499},
{"f_3483:scrutinizer_scm",(void*)f_3483},
{"f_3060:scrutinizer_scm",(void*)f_3060},
{"f_3094:scrutinizer_scm",(void*)f_3094},
{"f_2850:scrutinizer_scm",(void*)f_2850},
{"f_2915:scrutinizer_scm",(void*)f_2915},
{"f_3023:scrutinizer_scm",(void*)f_3023},
{"f_2856:scrutinizer_scm",(void*)f_2856},
{"f_2874:scrutinizer_scm",(void*)f_2874},
{"f_2900:scrutinizer_scm",(void*)f_2900},
{"f_2881:scrutinizer_scm",(void*)f_2881},
{"f_2888:scrutinizer_scm",(void*)f_2888},
{"f_2862:scrutinizer_scm",(void*)f_2862},
{"f_2868:scrutinizer_scm",(void*)f_2868},
{"f_2578:scrutinizer_scm",(void*)f_2578},
{"f_2665:scrutinizer_scm",(void*)f_2665},
{"f_2684:scrutinizer_scm",(void*)f_2684},
{"f_2721:scrutinizer_scm",(void*)f_2721},
{"f_2781:scrutinizer_scm",(void*)f_2781},
{"f_2772:scrutinizer_scm",(void*)f_2772},
{"f_2763:scrutinizer_scm",(void*)f_2763},
{"f_2754:scrutinizer_scm",(void*)f_2754},
{"f_2748:scrutinizer_scm",(void*)f_2748},
{"f_2689:scrutinizer_scm",(void*)f_2689},
{"f_2670:scrutinizer_scm",(void*)f_2670},
{"f_2569:scrutinizer_scm",(void*)f_2569},
{"f_2573:scrutinizer_scm",(void*)f_2573},
{"f_2503:scrutinizer_scm",(void*)f_2503},
{"f_2532:scrutinizer_scm",(void*)f_2532},
{"f_2536:scrutinizer_scm",(void*)f_2536},
{"f_2301:scrutinizer_scm",(void*)f_2301},
{"f_2461:scrutinizer_scm",(void*)f_2461},
{"f_2465:scrutinizer_scm",(void*)f_2465},
{"f_2397:scrutinizer_scm",(void*)f_2397},
{"f_2408:scrutinizer_scm",(void*)f_2408},
{"f_2416:scrutinizer_scm",(void*)f_2416},
{"f_2412:scrutinizer_scm",(void*)f_2412},
{"f_2336:scrutinizer_scm",(void*)f_2336},
{"f_2347:scrutinizer_scm",(void*)f_2347},
{"f_1841:scrutinizer_scm",(void*)f_1841},
{"f_1847:scrutinizer_scm",(void*)f_1847},
{"f_2234:scrutinizer_scm",(void*)f_2234},
{"f_2212:scrutinizer_scm",(void*)f_2212},
{"f_2202:scrutinizer_scm",(void*)f_2202},
{"f_1882:scrutinizer_scm",(void*)f_1882},
{"f_2128:scrutinizer_scm",(void*)f_2128},
{"f_2132:scrutinizer_scm",(void*)f_2132},
{"f_2138:scrutinizer_scm",(void*)f_2138},
{"f_1996:scrutinizer_scm",(void*)f_1996},
{"f_2038:scrutinizer_scm",(void*)f_2038},
{"f_2110:scrutinizer_scm",(void*)f_2110},
{"f_2063:scrutinizer_scm",(void*)f_2063},
{"f_2100:scrutinizer_scm",(void*)f_2100},
{"f_2076:scrutinizer_scm",(void*)f_2076},
{"f_1999:scrutinizer_scm",(void*)f_1999},
{"f_2028:scrutinizer_scm",(void*)f_2028},
{"f_2026:scrutinizer_scm",(void*)f_2026},
{"f_2019:scrutinizer_scm",(void*)f_2019},
{"f_1985:scrutinizer_scm",(void*)f_1985},
{"f_1888:scrutinizer_scm",(void*)f_1888},
{"f_1893:scrutinizer_scm",(void*)f_1893},
{"f_1976:scrutinizer_scm",(void*)f_1976},
{"f_1958:scrutinizer_scm",(void*)f_1958},
{"f_1931:scrutinizer_scm",(void*)f_1931},
{"f_1927:scrutinizer_scm",(void*)f_1927},
{"f_1832:scrutinizer_scm",(void*)f_1832},
{"f_1836:scrutinizer_scm",(void*)f_1836},
{"f_2239:scrutinizer_scm",(void*)f_2239},
{"f_2262:scrutinizer_scm",(void*)f_2262},
{"f_2279:scrutinizer_scm",(void*)f_2279},
{"f_3115:scrutinizer_scm",(void*)f_3115},
{"f_3222:scrutinizer_scm",(void*)f_3222},
{"f_3357:scrutinizer_scm",(void*)f_3357},
{"f_3238:scrutinizer_scm",(void*)f_3238},
{"f_3243:scrutinizer_scm",(void*)f_3243},
{"f_3271:scrutinizer_scm",(void*)f_3271},
{"f_3191:scrutinizer_scm",(void*)f_3191},
{"f_4095:scrutinizer_scm",(void*)f_4095},
{"f_1780:scrutinizer_scm",(void*)f_1780},
{"f_1802:scrutinizer_scm",(void*)f_1802},
{"f_1805:scrutinizer_scm",(void*)f_1805},
{"f_1808:scrutinizer_scm",(void*)f_1808},
{"f_1811:scrutinizer_scm",(void*)f_1811},
{"f_1814:scrutinizer_scm",(void*)f_1814},
{"f_1817:scrutinizer_scm",(void*)f_1817},
{"f_1820:scrutinizer_scm",(void*)f_1820},
{"f_1830:scrutinizer_scm",(void*)f_1830},
{"f_1823:scrutinizer_scm",(void*)f_1823},
{"f_1734:scrutinizer_scm",(void*)f_1734},
{"f_1750:scrutinizer_scm",(void*)f_1750},
{"f_1753:scrutinizer_scm",(void*)f_1753},
{"f_1756:scrutinizer_scm",(void*)f_1756},
{"f_1759:scrutinizer_scm",(void*)f_1759},
{"f_1762:scrutinizer_scm",(void*)f_1762},
{"f_1765:scrutinizer_scm",(void*)f_1765},
{"f_1768:scrutinizer_scm",(void*)f_1768},
{"f_1778:scrutinizer_scm",(void*)f_1778},
{"f_1771:scrutinizer_scm",(void*)f_1771},
{"f_1589:scrutinizer_scm",(void*)f_1589},
{"f_1713:scrutinizer_scm",(void*)f_1713},
{"f_1716:scrutinizer_scm",(void*)f_1716},
{"f_1719:scrutinizer_scm",(void*)f_1719},
{"f_1700:scrutinizer_scm",(void*)f_1700},
{"f_1635:scrutinizer_scm",(void*)f_1635},
{"f_1645:scrutinizer_scm",(void*)f_1645},
{"f_1648:scrutinizer_scm",(void*)f_1648},
{"f_1672:scrutinizer_scm",(void*)f_1672},
{"f_1651:scrutinizer_scm",(void*)f_1651},
{"f_1654:scrutinizer_scm",(void*)f_1654},
{"f_1664:scrutinizer_scm",(void*)f_1664},
{"f_1657:scrutinizer_scm",(void*)f_1657},
{"f_1548:scrutinizer_scm",(void*)f_1548},
{"f_1552:scrutinizer_scm",(void*)f_1552},
{"f_1562:scrutinizer_scm",(void*)f_1562},
{"f_1565:scrutinizer_scm",(void*)f_1565},
{"f_1568:scrutinizer_scm",(void*)f_1568},
{"f_1571:scrutinizer_scm",(void*)f_1571},
{"f_1574:scrutinizer_scm",(void*)f_1574},
{"f_1577:scrutinizer_scm",(void*)f_1577},
{"f_1587:scrutinizer_scm",(void*)f_1587},
{"f_1580:scrutinizer_scm",(void*)f_1580},
{"f_1583:scrutinizer_scm",(void*)f_1583},
{"f_1555:scrutinizer_scm",(void*)f_1555},
{"f_3721:scrutinizer_scm",(void*)f_3721},
{"f_3731:scrutinizer_scm",(void*)f_3731},
{"f_3739:scrutinizer_scm",(void*)f_3739},
{"f_3729:scrutinizer_scm",(void*)f_3729},
{"f_3667:scrutinizer_scm",(void*)f_3667},
{"f_3671:scrutinizer_scm",(void*)f_3671},
{"f_3676:scrutinizer_scm",(void*)f_3676},
{"f_3715:scrutinizer_scm",(void*)f_3715},
{"f_3711:scrutinizer_scm",(void*)f_3711},
{"f_3703:scrutinizer_scm",(void*)f_3703},
{"f_1516:scrutinizer_scm",(void*)f_1516},
{"f_1523:scrutinizer_scm",(void*)f_1523},
{"f_1448:scrutinizer_scm",(void*)f_1448},
{"f_1507:scrutinizer_scm",(void*)f_1507},
{"f_1514:scrutinizer_scm",(void*)f_1514},
{"f_1455:scrutinizer_scm",(void*)f_1455},
{"f_1474:scrutinizer_scm",(void*)f_1474},
{"f_1477:scrutinizer_scm",(void*)f_1477},
{"f_1490:scrutinizer_scm",(void*)f_1490},
{"f_1480:scrutinizer_scm",(void*)f_1480},
{"f_1483:scrutinizer_scm",(void*)f_1483},
{"f_1486:scrutinizer_scm",(void*)f_1486},
{"f_1470:scrutinizer_scm",(void*)f_1470},
{"f_1411:scrutinizer_scm",(void*)f_1411},
{"f_1415:scrutinizer_scm",(void*)f_1415},
{"f_1431:scrutinizer_scm",(void*)f_1431},
{"f_1434:scrutinizer_scm",(void*)f_1434},
{"f_1437:scrutinizer_scm",(void*)f_1437},
{"f_1440:scrutinizer_scm",(void*)f_1440},
{"f_1443:scrutinizer_scm",(void*)f_1443},
{"f_1427:scrutinizer_scm",(void*)f_1427},
{"f_3536:scrutinizer_scm",(void*)f_3536},
{"f_3544:scrutinizer_scm",(void*)f_3544},
{"f_3546:scrutinizer_scm",(void*)f_3546},
{"f_3612:scrutinizer_scm",(void*)f_3612},
{"f_3625:scrutinizer_scm",(void*)f_3625},
{"f_3628:scrutinizer_scm",(void*)f_3628},
{"f_3652:scrutinizer_scm",(void*)f_3652},
{"f_3631:scrutinizer_scm",(void*)f_3631},
{"f_3634:scrutinizer_scm",(void*)f_3634},
{"f_3644:scrutinizer_scm",(void*)f_3644},
{"f_3637:scrutinizer_scm",(void*)f_3637},
{"f_3587:scrutinizer_scm",(void*)f_3587},
{"f_3590:scrutinizer_scm",(void*)f_3590},
{"f_3603:scrutinizer_scm",(void*)f_3603},
{"f_3593:scrutinizer_scm",(void*)f_3593},
{"f_3596:scrutinizer_scm",(void*)f_3596},
{"f_3549:scrutinizer_scm",(void*)f_3549},
{"f_3556:scrutinizer_scm",(void*)f_3556},
{"f_3559:scrutinizer_scm",(void*)f_3559},
{"f_3572:scrutinizer_scm",(void*)f_3572},
{"f_3562:scrutinizer_scm",(void*)f_3562},
{"f_3565:scrutinizer_scm",(void*)f_3565},
{"f_1288:scrutinizer_scm",(void*)f_1288},
{"f_1298:scrutinizer_scm",(void*)f_1298},
{"f_1301:scrutinizer_scm",(void*)f_1301},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
