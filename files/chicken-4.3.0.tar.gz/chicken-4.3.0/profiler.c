/* Generated from profiler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:02
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: profiler.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -output-file profiler.c
   unit: profiler
*/

#include "chicken.h"

#if !defined(_MSC_VER)
# include <unistd.h>
#endif

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[20];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,6),40,97,49,51,52,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,15),40,97,49,52,51,32,46,32,97,114,103,115,49,49,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,112,114,111,102,105,108,101,45,105,110,102,111,32,115,105,122,101,53,32,102,105,108,101,110,97,109,101,54,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,46),40,35,35,115,121,115,35,115,101,116,45,112,114,111,102,105,108,101,45,105,110,102,111,45,118,101,99,116,111,114,33,32,118,101,99,50,48,32,105,50,49,32,120,50,50,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,112,114,111,102,105,108,101,45,101,110,116,114,121,32,105,110,100,101,120,50,52,32,118,101,99,50,53,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,112,114,111,102,105,108,101,45,101,120,105,116,32,105,110,100,101,120,52,52,32,118,101,99,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,14),40,100,111,108,111,111,112,55,48,32,105,55,52,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,54,51,32,108,115,116,54,52,54,55,41};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,6),40,97,50,57,53,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,22),40,35,35,115,121,115,35,102,105,110,105,115,104,45,112,114,111,102,105,108,101,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_profiler_toplevel)
C_externexport void C_ccall C_profiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_287)
static void C_ccall f_287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_291)
static void C_ccall f_291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_296)
static void C_ccall f_296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_302)
static void C_fcall f_302(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_327)
static void C_fcall f_327(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_337)
static void C_ccall f_337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_340)
static void C_ccall f_340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_343)
static void C_ccall f_343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_346)
static void C_ccall f_346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_349)
static void C_ccall f_349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_352)
static void C_ccall f_352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_355)
static void C_ccall f_355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_358)
static void C_ccall f_358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_318)
static void C_ccall f_318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_230)
static void C_ccall f_230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_170)
static void C_ccall f_170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_216)
static void C_fcall f_216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_195)
static void C_fcall f_195(C_word t0,C_word t1) C_noret;
C_noret_decl(f_157)
static void C_ccall f_157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_102)
static void C_ccall f_102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_155)
static void C_ccall f_155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_121)
static void C_ccall f_121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_124)
static void C_ccall f_124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_127)
static void C_ccall f_127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_144)
static void C_ccall f_144(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_144)
static void C_ccall f_144r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_148)
static void C_ccall f_148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_130)
static void C_ccall f_130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_135)
static void C_ccall f_135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_139)
static void C_ccall f_139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_106)
static void C_ccall f_106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_109)
static void C_ccall f_109(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_302)
static void C_fcall trf_302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_302(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_302(t0,t1,t2);}

C_noret_decl(trf_327)
static void C_fcall trf_327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_327(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_327(t0,t1,t2);}

C_noret_decl(trf_216)
static void C_fcall trf_216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_216(t0,t1);}

C_noret_decl(trf_195)
static void C_fcall trf_195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_195(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_195(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_profiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_profiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("profiler_toplevel"));
C_check_nursery_minimum(20);
if(!C_demand(20)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(163)){
C_save(t1);
C_rereclaim2(163*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(20);
C_initialize_lf(lf,20);
lf[2]=C_h_intern(&lf[2],23,"\003sysprofile-append-mode");
lf[3]=C_h_intern(&lf[3],11,"make-vector");
lf[4]=C_h_intern(&lf[4],25,"\003sysregister-profile-info");
lf[5]=C_h_intern(&lf[5],18,"\003sysfinish-profile");
lf[6]=C_h_intern(&lf[6],25,"\003sysimplicit-exit-handler");
lf[7]=C_h_intern(&lf[7],16,"\003sysexit-handler");
lf[8]=C_h_intern(&lf[8],13,"string-append");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[10]=C_h_intern(&lf[10],28,"\003sysset-profile-info-vector!");
lf[11]=C_h_intern(&lf[11],17,"\003sysprofile-entry");
lf[12]=C_h_intern(&lf[12],16,"\003sysprofile-exit");
lf[13]=C_h_intern(&lf[13],19,"with-output-to-file");
lf[14]=C_h_intern(&lf[14],10,"write-char");
lf[15]=C_h_intern(&lf[15],5,"write");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007\000append\376\377\016");
lf[17]=C_h_intern(&lf[17],9,"\003sysprint");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\033[debug] writing profile...\012");
lf[19]=C_h_intern(&lf[19],19,"\003sysstandard-output");
C_register_lf2(lf,20,create_ptable());
t2=lf[0] /* profile-vector-list */ =C_SCHEME_END_OF_LIST;;
t3=lf[1] /* profile-name */ =C_SCHEME_FALSE;;
t4=C_set_block_item(lf[2] /* profile-append-mode */,0,C_SCHEME_FALSE);
t5=*((C_word*)lf[3]+1);
t6=C_mutate((C_word*)lf[4]+1 /* (set! register-profile-info ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_102,a[2]=t5,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[10]+1 /* (set! set-profile-info-vector! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_157,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t8=(C_word)C_fudge(C_fix(21));
t9=C_mutate((C_word*)lf[11]+1 /* (set! profile-entry ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_170,a[2]=t8,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[12]+1 /* (set! profile-exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_230,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[13]+1);
t12=*((C_word*)lf[14]+1);
t13=*((C_word*)lf[15]+1);
t14=C_mutate((C_word*)lf[5]+1 /* (set! finish-profile ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_287,a[2]=t11,a[3]=t13,a[4]=t12,a[5]=((C_word)li9),tmp=(C_word)a,a+=6,tmp));
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_UNDEFINED);}

/* ##sys#finish-profile */
static void C_ccall f_287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_291,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fudge(C_fix(13)))){
/* profiler.scm: 129  ##sys#print */
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[18],C_SCHEME_FALSE,*((C_word*)lf[19]+1));}
else{
t3=t2;
f_291(2,t3,C_SCHEME_UNDEFINED);}}

/* k289 in ##sys#finish-profile */
static void C_ccall f_291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_296,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(*((C_word*)lf[2]+1))?lf[16]:C_SCHEME_END_OF_LIST);
C_apply(6,0,((C_word*)t0)[3],((C_word*)t0)[2],lf[1],t2,t3);}

/* a295 in k289 in ##sys#finish-profile */
static void C_ccall f_296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_296,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li7),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_302(t5,t1,lf[0]);}

/* loop63 in a295 in k289 in ##sys#finish-profile */
static void C_fcall f_302(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_302,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_318,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_327,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t4,a[7]=((C_word)li6),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_327(t9,t5,C_fix(0));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* doloop70 in loop63 in a295 in k289 in ##sys#finish-profile */
static void C_fcall f_327(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_327,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* profiler.scm: 138  write-char */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_make_character(40));}}

/* k335 in doloop70 in loop63 in a295 in k289 in ##sys#finish-profile */
static void C_ccall f_337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],((C_word*)t0)[7]);
/* profiler.scm: 139  write */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k338 in k335 in doloop70 in loop63 in a295 in k289 in ##sys#finish-profile */
static void C_ccall f_340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* profiler.scm: 140  write-char */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(32));}

/* k341 in k338 in k335 in doloop70 in loop63 in a295 in k289 in ##sys#finish-profile */
static void C_ccall f_343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_slot(((C_word*)t0)[3],t3);
/* profiler.scm: 141  write */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k344 in k341 in k338 in k335 in doloop70 in loop63 in a295 in k289 in ##sys#finish-profile */
static void C_ccall f_346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* profiler.scm: 142  write-char */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(32));}

/* k347 in k344 in k341 in k338 in k335 in doloop70 in loop63 in a295 in k289 in ##sys#finish-profile */
static void C_ccall f_349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_352,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[3],t3);
/* profiler.scm: 143  write */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k350 in k347 in k344 in k341 in k338 in k335 in doloop70 in loop63 in a295 in k289 in ##sys#finish-profile */
static void C_ccall f_352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* profiler.scm: 144  write-char */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}

/* k353 in k350 in k347 in k344 in k341 in k338 in k335 in doloop70 in loop63 in a295 in k289 in ##sys#finish-profile */
static void C_ccall f_355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_358,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* profiler.scm: 145  write-char */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(10));}

/* k356 in k353 in k350 in k347 in k344 in k341 in k338 in k335 in doloop70 in loop63 in a295 in k289 in ##sys#finish-profile */
static void C_ccall f_358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(5));
t3=((C_word*)((C_word*)t0)[3])[1];
f_327(t3,((C_word*)t0)[2],t2);}

/* k316 in loop63 in a295 in k289 in ##sys#finish-profile */
static void C_ccall f_318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_302(t3,((C_word*)t0)[2],t2);}

/* ##sys#profile-exit */
static void C_ccall f_230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_230,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_times(t2,C_fix(5));
t5=(C_word)C_fixnum_plus(t4,C_fix(2));
t6=(C_word)C_fixnum_plus(t4,C_fix(3));
t7=(C_word)C_fixnum_plus(t4,C_fix(4));
t8=(C_word)C_slot(t3,t7);
t9=(C_word)C_fixnum_decrease(t8);
t10=(C_word)C_i_set_i_slot(t3,t7,t9);
t11=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t11)){
t12=(C_word)C_slot(t3,t6);
t13=(C_word)C_fudge(C_fix(6));
t14=(C_word)C_slot(t3,t5);
t15=(C_word)C_fixnum_difference(t13,t14);
t16=(C_word)C_fixnum_plus(t12,t15);
t17=(C_word)C_i_set_i_slot(t3,t6,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_i_set_i_slot(t3,t5,C_fix(0)));}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}}

/* ##sys#profile-entry */
static void C_ccall f_170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_170,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_times(t2,C_fix(5));
t5=(C_word)C_fixnum_increase(t4);
t6=(C_word)C_slot(t3,t5);
t7=(C_word)C_fixnum_plus(t4,C_fix(2));
t8=(C_word)C_fixnum_plus(t4,C_fix(4));
t9=(C_word)C_slot(t3,t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_216,a[2]=t7,a[3]=t8,a[4]=t1,a[5]=t9,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t11=(C_word)C_eqp(((C_word*)t0)[2],t6);
t12=t10;
f_216(t12,(C_truep(t11)?C_SCHEME_FALSE:(C_word)C_fixnum_increase(t6)));}
else{
t11=t10;
f_216(t11,C_SCHEME_FALSE);}}

/* k214 in ##sys#profile-entry */
static void C_fcall f_216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_216,NULL,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[7],((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_fudge(C_fix(6));
t6=t3;
f_195(t6,(C_word)C_i_set_i_slot(((C_word*)t0)[7],((C_word*)t0)[2],t5));}
else{
t5=t3;
f_195(t5,C_SCHEME_UNDEFINED);}}

/* k193 in k214 in ##sys#profile-entry */
static void C_fcall f_195(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* ##sys#set-profile-info-vector! */
static void C_ccall f_157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_157,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_times(t3,C_fix(5));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(t2,t5,t4));}

/* ##sys#register-profile-info */
static void C_ccall f_102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_102,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_106,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_121,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_155,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* profiler.scm: 69   number->string */
C_number_to_string(3,0,t6,C_fix((C_word)getpid()));}
else{
t5=t4;
f_106(2,t5,C_SCHEME_UNDEFINED);}}

/* k153 in ##sys#register-profile-info */
static void C_ccall f_155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* profiler.scm: 69   string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[9],t1);}

/* k119 in ##sys#register-profile-info */
static void C_ccall f_121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_121,2,t0,t1);}
t2=C_mutate(&lf[1] /* (set! profile-name ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_124,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* profiler.scm: 70   ##sys#exit-handler */
((C_proc2)C_retrieve_proc(*((C_word*)lf[7]+1)))(2,*((C_word*)lf[7]+1),t3);}

/* k122 in k119 in ##sys#register-profile-info */
static void C_ccall f_124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_127,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* profiler.scm: 71   ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_proc(*((C_word*)lf[6]+1)))(2,*((C_word*)lf[6]+1),t2);}

/* k125 in k122 in k119 in ##sys#register-profile-info */
static void C_ccall f_127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_130,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_144,a[2]=((C_word*)t0)[2],a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp);
/* profiler.scm: 72   ##sys#exit-handler */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t2,t3);}

/* a143 in k125 in k122 in k119 in ##sys#register-profile-info */
static void C_ccall f_144(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_144r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_144r(t0,t1,t2);}}

static void C_ccall f_144r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_148,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* profiler.scm: 74   ##sys#finish-profile */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t3);}

/* k146 in a143 in k125 in k122 in k119 in ##sys#register-profile-info */
static void C_ccall f_148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k128 in k125 in k122 in k119 in ##sys#register-profile-info */
static void C_ccall f_130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_135,a[2]=((C_word*)t0)[3],a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp);
/* profiler.scm: 76   ##sys#implicit-exit-handler */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),((C_word*)t0)[2],t2);}

/* a134 in k128 in k125 in k122 in k119 in ##sys#register-profile-info */
static void C_ccall f_135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_139,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* profiler.scm: 78   ##sys#finish-profile */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t2);}

/* k137 in a134 in k128 in k125 in k122 in k119 in ##sys#register-profile-info */
static void C_ccall f_139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* profiler.scm: 79   oldieh */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k104 in ##sys#register-profile-info */
static void C_ccall f_106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_109,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_fixnum_times(((C_word*)t0)[3],C_fix(5));
/* profiler.scm: 81   make-vector */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_fix(0));}

/* k107 in k104 in ##sys#register-profile-info */
static void C_ccall f_109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_109,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,lf[0]);
t3=C_mutate(&lf[0] /* (set! profile-vector-list ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[33] = {
{"toplevel:profiler_scm",(void*)C_profiler_toplevel},
{"f_287:profiler_scm",(void*)f_287},
{"f_291:profiler_scm",(void*)f_291},
{"f_296:profiler_scm",(void*)f_296},
{"f_302:profiler_scm",(void*)f_302},
{"f_327:profiler_scm",(void*)f_327},
{"f_337:profiler_scm",(void*)f_337},
{"f_340:profiler_scm",(void*)f_340},
{"f_343:profiler_scm",(void*)f_343},
{"f_346:profiler_scm",(void*)f_346},
{"f_349:profiler_scm",(void*)f_349},
{"f_352:profiler_scm",(void*)f_352},
{"f_355:profiler_scm",(void*)f_355},
{"f_358:profiler_scm",(void*)f_358},
{"f_318:profiler_scm",(void*)f_318},
{"f_230:profiler_scm",(void*)f_230},
{"f_170:profiler_scm",(void*)f_170},
{"f_216:profiler_scm",(void*)f_216},
{"f_195:profiler_scm",(void*)f_195},
{"f_157:profiler_scm",(void*)f_157},
{"f_102:profiler_scm",(void*)f_102},
{"f_155:profiler_scm",(void*)f_155},
{"f_121:profiler_scm",(void*)f_121},
{"f_124:profiler_scm",(void*)f_124},
{"f_127:profiler_scm",(void*)f_127},
{"f_144:profiler_scm",(void*)f_144},
{"f_148:profiler_scm",(void*)f_148},
{"f_130:profiler_scm",(void*)f_130},
{"f_135:profiler_scm",(void*)f_135},
{"f_139:profiler_scm",(void*)f_139},
{"f_106:profiler_scm",(void*)f_106},
{"f_109:profiler_scm",(void*)f_109},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
