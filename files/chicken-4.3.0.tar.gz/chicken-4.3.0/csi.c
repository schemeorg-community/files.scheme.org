/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: csi.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -output-file csi.c -extend ./private-namespace.scm
   used units: library eval data_structures ports extras srfi_69 chicken_syntax srfi_69 ports extras
*/

#include "chicken.h"

#if (defined(_MSC_VER) && defined(_WIN32)) || defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[346];
static double C_possibly_force_alignment;


/* from k1279 */
static C_word C_fcall stub75(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub75(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1096)
static void C_ccall f_1096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1102)
static void C_ccall f_1102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1108)
static void C_ccall f_1108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_fcall f_2053(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4673)
static void C_ccall f_4673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_fcall f_4620(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_fcall f_3840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_fcall f_3846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_fcall f_4007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_fcall f_4016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4504)
static void C_ccall f_4504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_fcall f_4022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4498)
static void C_ccall f_4498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_ccall f_4486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4457)
static void C_ccall f_4457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4459)
static void C_fcall f_4459(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_fcall f_4432(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4308)
static void C_ccall f_4308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_fcall f_4058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4250)
static void C_fcall f_4250(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4112)
static void C_ccall f_4112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3937)
static void C_fcall f_3937(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3953)
static void C_fcall f_3953(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3857)
static void C_fcall f_3857(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3863)
static void C_fcall f_3863(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_fcall f_3679(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_fcall f_3685(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3707)
static void C_fcall f_3707(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3746)
static void C_ccall f_3746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3736)
static void C_ccall f_3736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static C_word C_fcall f_3796(C_word t0);
C_noret_decl(f_3622)
static void C_fcall f_3622(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3628)
static void C_fcall f_3628(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3640)
static void C_fcall f_3640(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_fcall f_3572(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3531)
static void C_fcall f_3531(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3348)
static void C_fcall f_3348(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_fcall f_3433(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_fcall f_3470(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_fcall f_3382(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_fcall f_3319(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3268)
static void C_fcall f_3268(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_fcall f_3263(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3157)
static void C_fcall f_3157(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_fcall f_3225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3160)
static void C_fcall f_3160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2320)
static void C_ccall f_2320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_fcall f_2962(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_fcall f_2991(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_fcall f_2810(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_fcall f_2715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_fcall f_2651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_fcall f_2600(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2334)
static void C_fcall f_2334(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_fcall f_2366(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_fcall f_2231(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_fcall f_2256(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_fcall f_2110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1592)
static void C_fcall f_1592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_fcall f_1779(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_fcall f_1737(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1526)
static void C_ccall f_1526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1479)
static void C_ccall f_1479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_fcall f_1450(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1394)
static void C_fcall f_1394(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1404)
static void C_ccall f_1404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1362)
static void C_ccall f_1362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static C_word C_fcall f_1313(C_word t0,C_word t1);
C_noret_decl(f_1286)
static void C_fcall f_1286(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1293)
static void C_ccall f_1293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1296)
static void C_ccall f_1296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1240)
static void C_ccall f_1240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_fcall f_1249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1222)
static void C_ccall f_1222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1198)
static void C_ccall f_1198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1165)
static void C_ccall f_1165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1168)
static void C_ccall f_1168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1137)
static void C_ccall f_1137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2053)
static void C_fcall trf_2053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2053(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2053(t0,t1,t2,t3);}

C_noret_decl(trf_4620)
static void C_fcall trf_4620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4620(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4620(t0,t1);}

C_noret_decl(trf_3840)
static void C_fcall trf_3840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3840(t0,t1);}

C_noret_decl(trf_3846)
static void C_fcall trf_3846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3846(t0,t1);}

C_noret_decl(trf_4007)
static void C_fcall trf_4007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4007(t0,t1);}

C_noret_decl(trf_4016)
static void C_fcall trf_4016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4016(t0,t1);}

C_noret_decl(trf_4022)
static void C_fcall trf_4022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4022(t0,t1);}

C_noret_decl(trf_4459)
static void C_fcall trf_4459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4459(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4459(t0,t1,t2);}

C_noret_decl(trf_4432)
static void C_fcall trf_4432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4432(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4432(t0,t1,t2);}

C_noret_decl(trf_4058)
static void C_fcall trf_4058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4058(t0,t1,t2);}

C_noret_decl(trf_4250)
static void C_fcall trf_4250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4250(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4250(t0,t1);}

C_noret_decl(trf_3937)
static void C_fcall trf_3937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3937(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3937(t0,t1,t2);}

C_noret_decl(trf_3953)
static void C_fcall trf_3953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3953(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3953(t0,t1,t2);}

C_noret_decl(trf_3857)
static void C_fcall trf_3857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3857(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3857(t0,t1,t2);}

C_noret_decl(trf_3863)
static void C_fcall trf_3863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3863(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3863(t0,t1,t2);}

C_noret_decl(trf_3679)
static void C_fcall trf_3679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3679(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3679(t0,t1);}

C_noret_decl(trf_3685)
static void C_fcall trf_3685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3685(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3685(t0,t1,t2);}

C_noret_decl(trf_3707)
static void C_fcall trf_3707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3707(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3707(t0,t1);}

C_noret_decl(trf_3622)
static void C_fcall trf_3622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3622(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3622(t0,t1,t2);}

C_noret_decl(trf_3628)
static void C_fcall trf_3628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3628(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3628(t0,t1,t2);}

C_noret_decl(trf_3640)
static void C_fcall trf_3640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3640(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3640(t0,t1,t2);}

C_noret_decl(trf_3572)
static void C_fcall trf_3572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3572(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3572(t0,t1,t2);}

C_noret_decl(trf_3531)
static void C_fcall trf_3531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3531(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3531(t0,t1,t2);}

C_noret_decl(trf_3348)
static void C_fcall trf_3348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3348(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3348(t0,t1,t2);}

C_noret_decl(trf_3433)
static void C_fcall trf_3433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3433(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3433(t0,t1,t2,t3);}

C_noret_decl(trf_3470)
static void C_fcall trf_3470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3470(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3470(t0,t1,t2);}

C_noret_decl(trf_3382)
static void C_fcall trf_3382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3382(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3382(t0,t1,t2,t3);}

C_noret_decl(trf_3319)
static void C_fcall trf_3319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3319(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3319(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3268)
static void C_fcall trf_3268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3268(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3268(t0,t1);}

C_noret_decl(trf_3263)
static void C_fcall trf_3263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3263(t0,t1,t2);}

C_noret_decl(trf_3157)
static void C_fcall trf_3157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3157(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3157(t0,t1,t2,t3);}

C_noret_decl(trf_3225)
static void C_fcall trf_3225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3225(t0,t1);}

C_noret_decl(trf_3160)
static void C_fcall trf_3160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3160(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3160(t0,t1,t2);}

C_noret_decl(trf_2962)
static void C_fcall trf_2962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2962(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2962(t0,t1,t2);}

C_noret_decl(trf_2991)
static void C_fcall trf_2991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2991(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2991(t0,t1,t2);}

C_noret_decl(trf_2810)
static void C_fcall trf_2810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2810(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2810(t0,t1);}

C_noret_decl(trf_2715)
static void C_fcall trf_2715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2715(t0,t1);}

C_noret_decl(trf_2651)
static void C_fcall trf_2651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2651(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2651(t0,t1);}

C_noret_decl(trf_2600)
static void C_fcall trf_2600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2600(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2600(t0,t1,t2);}

C_noret_decl(trf_2334)
static void C_fcall trf_2334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2334(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2334(t0,t1,t2);}

C_noret_decl(trf_2366)
static void C_fcall trf_2366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2366(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2366(t0,t1,t2,t3);}

C_noret_decl(trf_2231)
static void C_fcall trf_2231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2231(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2231(t0,t1,t2);}

C_noret_decl(trf_2256)
static void C_fcall trf_2256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2256(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2256(t0,t1,t2);}

C_noret_decl(trf_2110)
static void C_fcall trf_2110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2110(t0,t1);}

C_noret_decl(trf_1592)
static void C_fcall trf_1592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1592(t0,t1);}

C_noret_decl(trf_1779)
static void C_fcall trf_1779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1779(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1779(t0,t1,t2);}

C_noret_decl(trf_1737)
static void C_fcall trf_1737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1737(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1737(t0,t1,t2);}

C_noret_decl(trf_1450)
static void C_fcall trf_1450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1450(t0,t1);}

C_noret_decl(trf_1394)
static void C_fcall trf_1394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1394(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1394(t0,t1,t2);}

C_noret_decl(trf_1286)
static void C_fcall trf_1286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1286(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1286(t0,t1);}

C_noret_decl(trf_1249)
static void C_fcall trf_1249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1249(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2389)){
C_save(t1);
C_rereclaim2(2389*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,346);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[4]=C_h_intern(&lf[4],27,"\003sysrepl-print-length-limit");
lf[5]=C_h_intern(&lf[5],4,"\000csi");
lf[6]=C_h_intern(&lf[6],12,"\003sysfeatures");
lf[7]=C_h_intern(&lf[7],15,"\003csiprint-usage");
lf[8]=C_h_intern(&lf[8],7,"display");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\004V    -b  -batch                    terminate after command-line processing\012 "
"   -w  -no-warnings              disable all warnings\012    -k  -keyword-style STY"
"LE      enable alternative keyword-syntax\012                                   (pr"
"efix, suffix or none)\012        -no-parentheses-synonyms  disables list delimiter "
"synonyms\012        -no-symbol-escape         disables support for escaped symbols\012"
"        -r5rs-syntax              disables the Chicken extensions to\012           "
"                        R5RS syntax\012    -s  -script PATHNAME          use interp"
"reter for shell scripts\012        -ss PATHNAME              shell script with `mai"
"n\047 procedure\012        -sx PATHNAME              same as `-s\047, but print each expr"
"ession\012                                   as it is evaluated\012        -setup-mode"
"               prefer the current directory when locating extensions\012    -R  -re"
"quire-extension NAME   require extension and import before\012                     "
"              executing code\012    -I  -include-path PATHNAME    add PATHNAME to i"
"nclude path\012    --                            ignore all following options\012");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\003 \047\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000D    -n  -no-init                  do not load initialization file ` ");
lf[12]=C_h_intern(&lf[12],19,"\003sysprint-to-string");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\002\344usage: csi [FILENAME | OPTION ...]\012\012  `csi\047 is the CHICKEN interpreter.\012  \012"
"  FILENAME is a Scheme source file name with optional extension. OPTION may be\012 "
" one of the following:\012\012    -h  -help  --help             display this text and "
"exit\012    -v  -version                  display version and exit\012        -release"
"                  print release number and exit\012    -i  -case-insensitive       "
"  enable case-insensitive reading\012    -e  -eval EXPRESSION          evaluate giv"
"en expression\012    -p  -print EXPRESSION         evaluate and print result(s)\012   "
" -P  -pretty-print EXPRESSION  evaluate and print result(s) prettily\012    -D  -fe"
"ature SYMBOL           register feature identifier\012    -q  -quiet               "
"     do not print banner\012");
lf[14]=C_h_intern(&lf[14],16,"\003csiprint-banner");
lf[15]=C_h_intern(&lf[15],5,"print");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2009 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[18]=C_h_intern(&lf[18],15,"chicken-version");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\007CHICKEN");
lf[20]=C_h_intern(&lf[20],7,"newline");
lf[21]=C_h_intern(&lf[21],9,"read-char");
lf[22]=C_h_intern(&lf[22],4,"read");
lf[23]=C_h_intern(&lf[23],18,"\003sysuser-read-hook");
lf[24]=C_h_intern(&lf[24],5,"quote");
lf[25]=C_h_intern(&lf[25],17,"\003csihistory-count");
lf[26]=C_h_intern(&lf[26],15,"\003csihistory-ref");
lf[27]=C_h_intern(&lf[27],21,"\003syssharp-number-hook");
lf[29]=C_h_intern(&lf[29],9,"substring");
lf[30]=C_h_intern(&lf[30],18,"\003csichop-separator");
lf[31]=C_h_intern(&lf[31],4,"sub1");
lf[32]=C_h_intern(&lf[32],1,"@");
lf[33]=C_h_intern(&lf[33],12,"file-exists\077");
lf[34]=C_h_intern(&lf[34],13,"string-append");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[36]=C_h_intern(&lf[36],22,"\003csilookup-script-file");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[38]=C_h_intern(&lf[38],25,"\003syspeek-nonnull-c-string");
lf[39]=C_h_intern(&lf[39],12,"string-split");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[42]=C_h_intern(&lf[42],24,"get-environment-variable");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[44]=C_h_intern(&lf[44],16,"\003csihistory-list");
lf[45]=C_h_intern(&lf[45],13,"vector-resize");
lf[46]=C_h_intern(&lf[46],15,"\003csihistory-add");
lf[47]=C_h_intern(&lf[47],19,"\003sysundefined-value");
lf[48]=C_h_intern(&lf[48],9,"\003syserror");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[50]=C_h_intern(&lf[50],14,"\003csitty-input\077");
lf[51]=C_h_intern(&lf[51],13,"\003systty-port\077");
lf[52]=C_h_intern(&lf[52],18,"\003sysstandard-input");
lf[53]=C_h_intern(&lf[53],18,"\003sysbreak-on-error");
lf[54]=C_h_intern(&lf[54],20,"\003sysread-prompt-hook");
lf[56]=C_h_intern(&lf[56],16,"toplevel-command");
lf[57]=C_h_intern(&lf[57],19,"\003syshash-table-set!");
lf[58]=C_h_intern(&lf[58],4,"eval");
lf[59]=C_h_intern(&lf[59],12,"load-noisily");
lf[60]=C_h_intern(&lf[60],9,"read-line");
lf[61]=C_h_intern(&lf[61],6,"length");
lf[62]=C_h_intern(&lf[62],5,"write");
lf[63]=C_h_intern(&lf[63],6,"printf");
lf[64]=C_h_intern(&lf[64],6,"expand");
lf[65]=C_h_intern(&lf[65],12,"pretty-print");
lf[66]=C_h_intern(&lf[66],8,"integer\077");
lf[67]=C_h_intern(&lf[67],6,"values");
lf[68]=C_h_intern(&lf[68],18,"\003sysrepl-eval-hook");
lf[69]=C_h_intern(&lf[69],4,"exit");
lf[70]=C_h_intern(&lf[70],1,"x");
lf[71]=C_h_intern(&lf[71],16,"\003sysstrip-syntax");
lf[72]=C_h_intern(&lf[72],1,"p");
lf[73]=C_h_intern(&lf[73],1,"d");
lf[74]=C_h_intern(&lf[74],12,"\003csidescribe");
lf[75]=C_h_intern(&lf[75],2,"du");
lf[76]=C_h_intern(&lf[76],8,"\003csidump");
lf[77]=C_h_intern(&lf[77],3,"dur");
lf[78]=C_h_intern(&lf[78],1,"r");
lf[79]=C_h_intern(&lf[79],10,"\003csireport");
lf[80]=C_h_intern(&lf[80],1,"q");
lf[81]=C_h_intern(&lf[81],1,"l");
lf[82]=C_h_intern(&lf[82],4,"load");
lf[83]=C_h_intern(&lf[83],2,"ln");
lf[84]=C_h_intern(&lf[84],6,"print*");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[86]=C_h_intern(&lf[86],8,"\000printer");
lf[87]=C_h_intern(&lf[87],1,"t");
lf[88]=C_h_intern(&lf[88],17,"\003sysdisplay-times");
lf[89]=C_h_intern(&lf[89],14,"\003sysstop-timer");
lf[90]=C_h_intern(&lf[90],15,"\003sysstart-timer");
lf[91]=C_h_intern(&lf[91],3,"exn");
lf[92]=C_h_intern(&lf[92],18,"\003syslast-exception");
lf[93]=C_h_intern(&lf[93],1,"s");
lf[94]=C_h_intern(&lf[94],6,"system");
lf[95]=C_h_intern(&lf[95],1,"\077");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[97]=C_h_intern(&lf[97],23,"\003syshash-table-for-each");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\002\220Toplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,s TEXT ...   "
"    Execute shell-command\012 ,exn              Describe last exception\012 ,t EXP    "
"        Evaluate form and print elapsed time\012 ,x EXP            Pretty print exp"
"anded expression EXP\012");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\0005Undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[100]=C_h_intern(&lf[100],18,"\003syshash-table-ref");
lf[101]=C_h_intern(&lf[101],7,"unquote");
lf[102]=C_h_intern(&lf[102],4,"chop");
lf[103]=C_h_intern(&lf[103],4,"sort");
lf[104]=C_h_intern(&lf[104],19,"with-output-to-port");
lf[105]=C_h_intern(&lf[105],19,"current-output-port");
lf[106]=C_h_intern(&lf[106],8,"truncate");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[109]=C_h_intern(&lf[109],16,"\003syswrite-char-0");
lf[110]=C_h_intern(&lf[110],19,"\003sysstandard-output");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\002\001~%~\012                   Machine type:    \011~A ~A~%~\012                   Softwa"
"re type:   \011~A~%~\012                   Software version:\011~A~%~\012                   "
"Build platform:  \011~A~%~\012                   Include path:    \011~A~%~\012             "
"      Symbol-table load:\011~S~%  ~\012                     Avg bucket length:\011~S~%  ~"
"\012                     Total symbol count:\011~S~%~\012                   Memory:\011heap "
"size is ~S bytes~A with ~S bytes currently in use~%~  \012                     nurs"
"ery size is ~S bytes, stack grows ~A~%");
lf[118]=C_h_intern(&lf[118],21,"\003sysinclude-pathnames");
lf[119]=C_h_intern(&lf[119],14,"build-platform");
lf[120]=C_h_intern(&lf[120],16,"software-version");
lf[121]=C_h_intern(&lf[121],13,"software-type");
lf[122]=C_h_intern(&lf[122],12,"machine-type");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[124]=C_h_intern(&lf[124],11,"make-string");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[126]=C_h_intern(&lf[126],8,"string<\077");
lf[127]=C_h_intern(&lf[127],7,"\003sysmap");
lf[128]=C_h_intern(&lf[128],15,"keyword->string");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[130]=C_h_intern(&lf[130],17,"memory-statistics");
lf[131]=C_h_intern(&lf[131],21,"\003syssymbol-table-info");
lf[132]=C_h_intern(&lf[132],2,"gc");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[136]=C_h_intern(&lf[136],7,"sprintf");
lf[137]=C_h_intern(&lf[137],7,"fprintf");
lf[138]=C_h_intern(&lf[138],8,"list-ref");
lf[139]=C_h_intern(&lf[139],10,"string-ref");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\042exact integer ~S, #x~X, #o~O, #b~B");
lf[154]=C_h_intern(&lf[154],28,"\003sysarbitrary-unbound-symbol");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[158]=C_h_intern(&lf[158],8,"\003syssize");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[160]=C_h_intern(&lf[160],8,"\003sysslot");
lf[161]=C_h_intern(&lf[161],27,"\003syswith-print-length-limit");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\005  ~s\011");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\020  \012properties:\012\012");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\013uninterned ");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\027~asymbol with name ~S~%");
lf[167]=C_h_intern(&lf[167],18,"\003syssymbol->string");
lf[168]=C_h_intern(&lf[168],20,"\003sysinterned-symbol\077");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\010keyword ");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[171]=C_h_intern(&lf[171],32,"\003syssymbol-has-toplevel-binding\077");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\035pair with car ~S and cdr ~S~%");
lf[174]=C_h_intern(&lf[174],15,"describe-object");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\036procedure with code pointer ~X");
lf[176]=C_h_intern(&lf[176],25,"\003syspeek-unsigned-integer");
lf[177]=C_h_intern(&lf[177],9,"\000tinyclos");
lf[178]=C_h_intern(&lf[178],19,"\010tinyclosentity-tag");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[194]=C_h_intern(&lf[194],11,"\003csihexdump");
lf[195]=C_h_intern(&lf[195],8,"\003sysbyte");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[198]=C_h_intern(&lf[198],23,"\003syslambda-info->string");
lf[199]=C_h_intern(&lf[199],10,"hash-table");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[201]=C_h_intern(&lf[201],15,"hash-table-walk");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[206]=C_h_intern(&lf[206],9,"condition");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\011\011~s: ~s~%");
lf[208]=C_h_intern(&lf[208],4,"cdar");
lf[209]=C_h_intern(&lf[209],4,"caar");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[212]=C_h_intern(&lf[212],6,"unveil");
lf[213]=C_h_intern(&lf[213],6,"append");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[216]=C_h_intern(&lf[216],15,"meroon-instance");
lf[217]=C_h_intern(&lf[217],9,"provided\077");
lf[218]=C_h_intern(&lf[218],6,"meroon");
lf[219]=C_h_intern(&lf[219],15,"\003sysbytevector\077");
lf[220]=C_h_intern(&lf[220],13,"\003syslocative\077");
lf[221]=C_h_intern(&lf[221],9,"instance\077");
lf[222]=C_h_intern(&lf[222],5,"port\077");
lf[223]=C_h_intern(&lf[223],11,"\003sysnumber\077");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[225]=C_h_intern(&lf[225],17,"\003sysblock-address");
lf[226]=C_h_intern(&lf[226],14,"set-describer!");
lf[227]=C_h_intern(&lf[227],16,"\003syscheck-symbol");
lf[228]=C_h_intern(&lf[228],6,"symbol");
lf[229]=C_h_intern(&lf[229],3,"min");
lf[230]=C_h_intern(&lf[230],4,"dump");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot dump immediate object");
lf[232]=C_h_intern(&lf[232],13,"\003syspeek-byte");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot dump object");
lf[234]=C_h_intern(&lf[234],10,"write-char");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[236]=C_h_intern(&lf[236],5,"fxmod");
lf[237]=C_h_intern(&lf[237],7,"\003csidel");
lf[238]=C_h_intern(&lf[238],11,"\003csideldups");
lf[239]=C_h_intern(&lf[239],6,"equal\077");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[248]=C_h_intern(&lf[248],16,"\003sysstring->list");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000"
"\002\376B\000\000\006--help\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-case-insensitive\376\003\000\000\002\376B\000"
"\000\016-keyword-style\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000"
"\000\002\376B\000\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\022-require-extension\376\003\000\000\002\376B\000\000\006-b"
"atch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\015-include-p"
"ath\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-print\376\003\000\000\002\376B\000\000\002--\376\377\016");
lf[250]=C_h_intern(&lf[250],7,"\003csirun");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[252]=C_h_intern(&lf[252],8,"\003syslist");
lf[253]=C_h_intern(&lf[253],17,"open-input-string");
lf[254]=C_h_intern(&lf[254],4,"repl");
lf[255]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\002-n"
"\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-"
"insensitive\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000\000\002\376B\000"
"\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B"
"\000\000\007-script\376\377\016");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[264]=C_h_intern(&lf[264],22,"\004corerequire-extension");
lf[265]=C_h_intern(&lf[265],14,"string->symbol");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[270]=C_h_intern(&lf[270],8,"for-each");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[274]=C_h_intern(&lf[274],4,"main");
lf[275]=C_h_intern(&lf[275],22,"command-line-arguments");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[277]=C_h_intern(&lf[277],18,"\003sysstandard-error");
lf[278]=C_h_intern(&lf[278],8,"\003sysload");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[282]=C_h_intern(&lf[282],17,"\003sysstring-append");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[284]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[285]=C_h_intern(&lf[285],13,"symbol-escape");
lf[286]=C_h_intern(&lf[286],20,"parentheses-synonyms");
lf[287]=C_h_intern(&lf[287],13,"keyword-style");
lf[288]=C_h_intern(&lf[288],5,"\000none");
lf[289]=C_h_intern(&lf[289],14,"case-sensitive");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000/Disabled the Chicken extensions to R5RS syntax\012");
lf[291]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000%Disabled support for escaped symbols\012");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\377\016");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000*Disabled support for parentheses synonyms\012");
lf[295]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\377\016");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[297]=C_h_intern(&lf[297],7,"\000prefix");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[300]=C_h_intern(&lf[300],7,"\000suffix");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[302]=C_h_intern(&lf[302],8,"string=\077");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[305]=C_h_intern(&lf[305],17,"register-feature!");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[308]=C_h_intern(&lf[308],16,"case-insensitive");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[310]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[311]=C_h_intern(&lf[311],12,"load-verbose");
lf[312]=C_h_intern(&lf[312],20,"\003syswarnings-enabled");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[314]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[317]=C_h_intern(&lf[317],14,"\003syssetup-mode");
lf[318]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-v\376\003\000\000\002\376B\000\000\010-version\376\377\016");
lf[319]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[320]=C_h_intern(&lf[320],20,"\003syseval-debug-level");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[324]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[325]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[326]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[327]=C_h_intern(&lf[327],20,"\003syswindows-platform");
lf[328]=C_h_intern(&lf[328],6,"script");
lf[329]=C_h_intern(&lf[329],12,"program-name");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[332]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[333]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-k\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[335]=C_h_intern(&lf[335],17,"get-output-string");
lf[336]=C_h_intern(&lf[336],18,"open-output-string");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[338]=C_h_intern(&lf[338],7,"reverse");
lf[339]=C_h_intern(&lf[339],22,"with-exception-handler");
lf[340]=C_h_intern(&lf[340],30,"call-with-current-continuation");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[342]=C_h_intern(&lf[342],25,"\003sysimplicit-exit-handler");
lf[343]=C_h_intern(&lf[343],11,"make-vector");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\006#;~A> ");
lf[345]=C_h_intern(&lf[345],11,"repl-prompt");
C_register_lf2(lf,346,create_ptable());
t2=C_mutate(&lf[0] /* (set! c172 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1096,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1094 */
static void C_ccall f_1096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1099,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1097 in k1094 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1102,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1100 in k1097 in k1094 */
static void C_ccall f_1102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1105,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1108,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1111,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1123,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! constant23 ...) */,lf[3]);
t3=C_set_block_item(lf[4] /* repl-print-length-limit */,0,C_fix(2048));
t4=(C_word)C_a_i_cons(&a,2,lf[5],C_retrieve(lf[6]));
t5=C_mutate((C_word*)lf[6]+1 /* (set! features ...) */,t4);
t6=C_mutate((C_word*)lf[7]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1133,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[14]+1 /* (set! print-banner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1161,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[21]+1);
t9=*((C_word*)lf[22]+1);
t10=C_retrieve(lf[23]);
t11=C_mutate((C_word*)lf[23]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1177,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[27]+1 /* (set! sharp-number-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1210,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[28] /* (set! dirseparator? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1224,tmp=(C_word)a,a+=2,tmp));
t14=*((C_word*)lf[29]+1);
t15=C_mutate((C_word*)lf[30]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1236,a[2]=t14,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(lf[32] /* @ */,0,C_SCHEME_FALSE);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1267,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 178  make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t17,C_fix(256));}

/* k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1286,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[36]+1 /* (set! lookup-script-file ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1334,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(C_word)C_a_i_vector(&a,32,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4);
t6=C_mutate((C_word*)lf[44]+1 /* (set! history-list ...) */,t5);
t7=C_set_block_item(lf[25] /* history-count */,0,C_fix(1));
t8=C_retrieve(lf[45]);
t9=C_mutate((C_word*)lf[46]+1 /* (set! history-add ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[26]+1 /* (set! history-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1479,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1504,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=*((C_word*)lf[136]+1);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4695,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 230  repl-prompt */
((C_proc3)C_retrieve_symbol_proc(lf[345]))(3,*((C_word*)lf[345]+1),t11,t13);}

/* a4694 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4695,2,t0,t1);}
/* csi.scm: 233  sprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[344],C_retrieve(lf[25]));}

/* k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1504,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1 /* (set! tty-input? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1506,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[53] /* break-on-error */,0,C_SCHEME_FALSE);
t4=C_retrieve(lf[54]);
t5=C_mutate((C_word*)lf[54]+1 /* (set! read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1519,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1533,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 245  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[343]+1)))(4,*((C_word*)lf[343]+1),t6,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1533,2,t0,t1);}
t2=C_mutate(&lf[55] /* (set! command-table ...) */,t1);
t3=C_mutate((C_word*)lf[56]+1 /* (set! toplevel-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1535,tmp=(C_word)a,a+=2,tmp));
t4=C_retrieve(lf[58]);
t5=C_retrieve(lf[59]);
t6=*((C_word*)lf[22]+1);
t7=C_retrieve(lf[60]);
t8=*((C_word*)lf[61]+1);
t9=*((C_word*)lf[8]+1);
t10=*((C_word*)lf[62]+1);
t11=C_retrieve(lf[39]);
t12=*((C_word*)lf[63]+1);
t13=C_retrieve(lf[64]);
t14=C_retrieve(lf[65]);
t15=*((C_word*)lf[66]+1);
t16=*((C_word*)lf[67]+1);
t17=C_mutate((C_word*)lf[68]+1 /* (set! repl-eval-hook ...) */,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1576,a[2]=t12,a[3]=t9,a[4]=t16,a[5]=t5,a[6]=t7,a[7]=t11,a[8]=t4,a[9]=t6,a[10]=t13,a[11]=t14,tmp=(C_word)a,a+=12,tmp));
t18=*((C_word*)lf[63]+1);
t19=C_retrieve(lf[102]);
t20=C_retrieve(lf[103]);
t21=C_retrieve(lf[104]);
t22=*((C_word*)lf[105]+1);
t23=C_mutate((C_word*)lf[79]+1 /* (set! report ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2088,a[2]=t22,a[3]=t21,a[4]=t20,a[5]=t19,a[6]=t18,tmp=(C_word)a,a+=7,tmp));
t24=C_mutate(&lf[133] /* (set! bytevector-data ...) */,lf[134]);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 446  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[343]+1)))(4,*((C_word*)lf[343]+1),t25,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2314,2,t0,t1);}
t2=C_mutate(&lf[135] /* (set! describer-table ...) */,t1);
t3=*((C_word*)lf[136]+1);
t4=*((C_word*)lf[63]+1);
t5=C_retrieve(lf[137]);
t6=*((C_word*)lf[61]+1);
t7=*((C_word*)lf[138]+1);
t8=*((C_word*)lf[139]+1);
t9=C_mutate((C_word*)lf[74]+1 /* (set! describe ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2316,a[2]=t3,a[3]=t7,a[4]=t6,a[5]=t8,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t10=C_mutate((C_word*)lf[226]+1 /* (set! set-describer! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3146,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[76]+1 /* (set! dump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3155,tmp=(C_word)a,a+=2,tmp));
t12=*((C_word*)lf[8]+1);
t13=*((C_word*)lf[34]+1);
t14=*((C_word*)lf[124]+1);
t15=*((C_word*)lf[234]+1);
t16=C_mutate((C_word*)lf[194]+1 /* (set! hexdump ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3316,a[2]=t12,a[3]=t15,a[4]=t14,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t17=C_mutate((C_word*)lf[237]+1 /* (set! del ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3525,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[238]+1 /* (set! deldups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3563,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[240] /* (set! member* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3622,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[241] /* (set! canonicalize-args ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3679,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[250]+1 /* (set! run ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3824,tmp=(C_word)a,a+=2,tmp));
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4687,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 862  run */
((C_proc2)C_retrieve_symbol_proc(lf[250]))(2,*((C_word*)lf[250]+1),t22);}

/* k4685 in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4690,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4693,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[342]))(2,*((C_word*)lf[342]+1),t3);}

/* k4691 in k4685 in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4688 in k4685 in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3828,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4681,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 723  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),t3,lf[341]);}

/* k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[334]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1989,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 364  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t3,t2);}

/* k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1994,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2017,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2019,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[340]+1)))(3,*((C_word*)lf[340]+1),t4,t5);}

/* a2018 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2019,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2025,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2037,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[339]))(4,*((C_word*)lf[339]+1),t1,t3,t4);}

/* a2036 in a2018 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2043,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2075 in a2036 in a2018 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2076r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2076r(t0,t1,t2);}}

static void C_ccall f_2076r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2082,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k301304 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2081 in a2075 in a2036 in a2018 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2082,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2042 in a2036 in a2018 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2051,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 372  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,((C_word*)t0)[2]);}

/* k2049 in a2042 in a2036 in a2018 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2051,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2053,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2053(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop306 in k2049 in a2042 in a2036 in a2018 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_2053(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2053,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 374  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[338]+1)))(3,*((C_word*)lf[338]+1),t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2070,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 372  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t4,((C_word*)t0)[2]);}}

/* k2068 in doloop306 in k2049 in a2042 in a2036 in a2018 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2070,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2053(t3,((C_word*)t0)[2],t1,t2);}

/* a2024 in a2018 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2025,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2031,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* k301304 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2030 in a2024 in a2018 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2031,2,t0,t1);}
/* csi.scm: 371  ##sys#error */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[337],((C_word*)t0)[2]);}

/* k2015 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2012 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1993 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1994,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2004,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 368  open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[336]))(2,*((C_word*)lf[336]+1),t3);}}

/* k2002 in a1993 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 369  write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),t2,((C_word*)t0)[2],t1);}

/* k2005 in k2002 in a1993 in k1987 in k4679 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 370  get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3831,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4677,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 724  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[275]))(2,*((C_word*)lf[275]+1),t3);}

/* k4675 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 724  canonicalize-args */
f_3679(((C_word*)t0)[2],t1);}

/* k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3831,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 726  member* */
f_3622(t4,lf[333],((C_word*)t3)[1]);}

/* k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3837,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 727  member* */
f_3622(t2,lf[332],((C_word*)((C_word*)t0)[4])[1]);}

/* k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4570,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_i_pairp(t4);
t6=(C_word)C_i_not(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4620,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_4620(t8,t6);}
else{
t8=(C_word)C_i_cadr(t1);
t9=(C_word)C_i_string_length(t8);
t10=(C_word)C_i_zerop(t9);
if(C_truep(t10)){
t11=t7;
f_4620(t11,t10);}
else{
t11=(C_word)C_i_cadr(t1);
t12=(C_word)C_i_string_ref(t11,C_fix(0));
t13=t7;
f_4620(t13,(C_word)C_eqp(C_make_character(45),t12));}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4660,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4673,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 741  canonicalize-args */
f_3679(t4,((C_word*)t0)[2]);}}

/* k4671 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 741  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[213]+1)))(4,*((C_word*)lf[213]+1),((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4658 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_i_member(lf[331],((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
f_3840(t4,(C_truep(t3)?(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k4618 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_4620(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 732  ##sys#error */
t2=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[330]);}
else{
t2=((C_word*)t0)[2];
f_4570(2,t2,C_SCHEME_UNDEFINED);}}

/* k4568 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 733  program-name */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),t2,t3);}

/* k4571 in k4568 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* csi.scm: 734  command-line-arguments */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t2,t3);}

/* k4574 in k4571 in k4568 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 735  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[305]))(3,*((C_word*)lf[305]+1),t2,lf[328]);}

/* k4577 in k4574 in k4571 in k4568 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4579,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[327]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 738  lookup-script-file */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),t4,t5);}
else{
t4=((C_word*)t0)[2];
f_3840(t4,C_SCHEME_UNDEFINED);}}

/* k4586 in k4577 in k4574 in k4571 in k4568 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3840(t3,(C_word)C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[2];
f_3840(t2,C_SCHEME_FALSE);}}

/* k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3840(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3840,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 744  member* */
f_3622(t2,lf[326],((C_word*)((C_word*)t0)[4])[1]);}

/* k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3846(t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4564,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 745  member* */
f_3622(t3,lf[325],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4562 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3846(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3846,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 746  member* */
f_3622(t2,lf[324],((C_word*)((C_word*)t0)[4])[1]);}

/* k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?((C_word*)t0)[7]:(C_truep(t1)?t1:((C_word*)t0)[6]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3855,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4551,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4555,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 748  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),t5,lf[323]);}

/* k4553 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[321]);
/* csi.scm: 748  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[39]))(4,*((C_word*)lf[39]+1),((C_word*)t0)[2],t2,lf[322]);}

/* k4549 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[30]),t1);}

/* k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3857,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3937,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4007,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=C_set_block_item(lf[320] /* eval-debug-level */,0,C_fix(0));
t6=t4;
f_4007(t6,t5);}
else{
t5=t4;
f_4007(t5,C_SCHEME_UNDEFINED);}}

/* k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_4007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4007,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4540,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 771  member* */
f_3622(t3,lf[319],((C_word*)((C_word*)t0)[6])[1]);}

/* k4538 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4540,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4543,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 772  print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_4010(2,t2,C_SCHEME_UNDEFINED);}}

/* k4541 in k4538 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 773  exit */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],C_fix(0));}

/* k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4531,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 774  member* */
f_3622(t3,lf[318],((C_word*)((C_word*)t0)[6])[1]);}

/* k4529 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4531,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4534,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 775  print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_4013(2,t2,C_SCHEME_UNDEFINED);}}

/* k4532 in k4529 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 776  exit */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],C_fix(0));}

/* k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[316],((C_word*)((C_word*)t0)[6])[1]))){
t3=C_set_block_item(lf[317] /* setup-mode */,0,C_SCHEME_TRUE);
t4=t2;
f_4016(t4,t3);}
else{
t3=t2;
f_4016(t3,C_SCHEME_UNDEFINED);}}

/* k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_4016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4016,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[315],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4517,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4524,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 780  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[18]))(2,*((C_word*)lf[18]+1),t4);}
else{
t3=t2;
f_4019(2,t3,C_SCHEME_UNDEFINED);}}

/* k4522 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 780  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),((C_word*)t0)[2],t1);}

/* k4515 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 781  exit */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],C_fix(0));}

/* k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4504,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 782  member* */
f_3622(t3,lf[314],((C_word*)((C_word*)t0)[6])[1]);}

/* k4502 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4504,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4507,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4507(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 783  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[313]);}}
else{
t2=((C_word*)t0)[3];
f_4022(t2,C_SCHEME_UNDEFINED);}}

/* k4505 in k4502 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[312] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_4022(t3,t2);}

/* k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_4022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4022,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4025(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4498,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 786  load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[311]))(3,*((C_word*)lf[311]+1),t3,C_SCHEME_TRUE);}}

/* k4496 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 787  print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4483,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 788  member* */
f_3622(t3,lf[310],((C_word*)((C_word*)t0)[6])[1]);}

/* k4481 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4483,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4486,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4486(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 789  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[309]);}}
else{
t2=((C_word*)t0)[3];
f_4028(2,t2,C_SCHEME_UNDEFINED);}}

/* k4484 in k4481 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4489,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 790  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[305]))(3,*((C_word*)lf[305]+1),t2,lf[308]);}

/* k4487 in k4484 in k4481 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 791  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[289]))(3,*((C_word*)lf[289]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4457,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 792  collect-options */
t4=((C_word*)t0)[2];
f_3857(t4,t3,lf[307]);}

/* k4455 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4457,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4459,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4459(t5,((C_word*)t0)[2],t1);}

/* loop883 in k4455 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_4459(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4459,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4469,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[305]))(3,*((C_word*)lf[305]+1),t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4467 in loop883 in k4455 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4459(t3,((C_word*)t0)[2],t2);}

/* k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4430,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 793  collect-options */
t4=((C_word*)t0)[2];
f_3857(t4,t3,lf[306]);}

/* k4428 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4430,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4432,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4432(t5,((C_word*)t0)[2],t1);}

/* loop892 in k4428 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_4432(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4432,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4442,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[305]))(3,*((C_word*)lf[305]+1),t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4440 in loop892 in k4428 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4432(t3,((C_word*)t0)[2],t2);}

/* k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4410,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4426,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 796  collect-options */
t6=((C_word*)t0)[2];
f_3857(t6,t5,lf[304]);}

/* k4424 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[30]),t1);}

/* k4412 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4418,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4422,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 797  collect-options */
t4=((C_word*)t0)[2];
f_3857(t4,t3,lf[303]);}

/* k4420 in k4412 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[30]),t1);}

/* k4416 in k4412 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 796  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[213]+1)))(6,*((C_word*)lf[213]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,C_retrieve(lf[118]),((C_word*)t0)[2]);}

/* k4408 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 795  deldups */
((C_proc4)C_retrieve_symbol_proc(lf[238]))(4,*((C_word*)lf[238]+1),((C_word*)t0)[2],t1,*((C_word*)lf[302]+1));}

/* k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
t2=C_mutate((C_word*)lf[118]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[296],t5))){
/* csi.scm: 805  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),t3,lf[297]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[298],t6))){
/* csi.scm: 807  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),t3,lf[288]);}
else{
t7=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[299],t7))){
/* csi.scm: 809  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),t3,lf[300]);}
else{
t8=t3;
f_4041(2,t8,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm: 803  ##sys#error */
t5=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,lf[301]);}}
else{
t4=t3;
f_4041(2,t4,C_SCHEME_UNDEFINED);}}

/* k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 810  member* */
f_3622(t3,lf[295],((C_word*)((C_word*)t0)[3])[1]);}

/* k4339 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4341,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4344(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 811  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[294]);}}
else{
t2=((C_word*)t0)[3];
f_4044(2,t2,C_SCHEME_UNDEFINED);}}

/* k4342 in k4339 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 812  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[286]))(3,*((C_word*)lf[286]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4329,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 813  member* */
f_3622(t3,lf[293],((C_word*)((C_word*)t0)[3])[1]);}

/* k4327 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4332,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4332(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 814  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[292]);}}
else{
t2=((C_word*)t0)[3];
f_4047(2,t2,C_SCHEME_UNDEFINED);}}

/* k4330 in k4327 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 815  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[285]))(3,*((C_word*)lf[285]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4308,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 816  member* */
f_3622(t3,lf[291],((C_word*)((C_word*)t0)[3])[1]);}

/* k4306 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4308,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4311(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 817  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[290]);}}
else{
t2=((C_word*)t0)[3];
f_4050(2,t2,C_SCHEME_UNDEFINED);}}

/* k4309 in k4306 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 818  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[289]))(3,*((C_word*)lf[289]+1),t2,C_SCHEME_FALSE);}

/* k4312 in k4309 in k4306 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 819  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),t2,lf[288]);}

/* k4315 in k4312 in k4309 in k4306 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 820  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[286]))(3,*((C_word*)lf[286]+1),t2,C_SCHEME_FALSE);}

/* k4318 in k4315 in k4312 in k4309 in k4306 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 821  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[285]))(3,*((C_word*)lf[285]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4299,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 822  member* */
f_3622(t3,lf[284],((C_word*)((C_word*)t0)[2])[1]);}

/* k4297 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4299,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_4053(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 758  ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[282]))(4,*((C_word*)lf[282]+1),t3,lf[283],lf[2]);}}

/* k3902 in k4297 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3910,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 759  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),t2,t1);}

/* k3908 in k3902 in k4297 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3910,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 760  load */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3932,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 761  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),t3,lf[281]);}}

/* k3930 in k3908 in k3902 in k4297 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[280]);
/* csi.scm: 761  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),((C_word*)t0)[2],t2);}

/* k3914 in k3908 in k3902 in k4297 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 762  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[34]+1)))(5,*((C_word*)lf[34]+1),t2,t1,lf[279],lf[2]);}

/* k3917 in k3914 in k3908 in k3902 in k4297 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3925,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 763  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),t2,t1);}

/* k3923 in k3917 in k3914 in k3908 in k3902 in k4297 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 764  load */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4053(2,t2,C_SCHEME_UNDEFINED);}}

/* k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4053,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4058(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_4058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4058,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[5])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4071,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 826  repl */
((C_proc2)C_retrieve_symbol_proc(lf[254]))(2,*((C_word*)lf[254]+1),t4);}}
else{
t4=(C_word)C_i_car(((C_word*)t3)[1]);
t5=(C_word)C_i_member(t4,lf[255]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4083,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4083(2,t7,t5);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t4,lf[256]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[257]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[258]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[259]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[260]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[261]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t7=(C_word)C_i_cdr(((C_word*)t3)[1]);
t8=C_set_block_item(t3,0,t7);
t9=t6;
f_4083(2,t9,t8);}
else{
t7=(C_word)C_i_string_equal_p(lf[262],t4);
t8=(C_truep(t7)?t7:(C_word)C_i_string_equal_p(lf[263],t4));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4112,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4136,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 833  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[265]+1)))(3,*((C_word*)lf[265]+1),t10,t11);}
else{
t9=(C_word)C_i_string_equal_p(lf[266],t4);
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(lf[267],t4));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4152,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 836  evalstring */
f_3937(t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_i_string_equal_p(lf[268],t4);
t12=(C_truep(t11)?t11:(C_word)C_i_string_equal_p(lf[269],t4));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4172,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_cadr(((C_word*)t3)[1]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4182,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 839  evalstring */
f_3937(t13,t14,(C_word)C_a_i_list(&a,1,t15));}
else{
t13=(C_word)C_i_string_equal_p(lf[271],t4);
t14=(C_truep(t13)?t13:(C_word)C_i_string_equal_p(lf[272],t4));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4198,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_cadr(((C_word*)t3)[1]);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4208,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 842  evalstring */
f_3937(t15,t16,(C_word)C_a_i_list(&a,1,t17));}
else{
t15=(C_truep(((C_word*)t0)[2])?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4218,a[2]=t6,a[3]=t15,tmp=(C_word)a,a+=4,tmp);
t17=(C_word)C_i_equalp(lf[276],t15);
t18=(C_truep(t17)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4271,tmp=(C_word)a,a+=2,tmp):C_SCHEME_FALSE);
/* csi.scm: 846  ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[278]))(5,*((C_word*)lf[278]+1),t16,t4,t18,C_SCHEME_FALSE);}}}}}}}}

/* f_4271 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4271,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4275,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 850  pretty-print */
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t3,t2,*((C_word*)lf[277]+1));}

/* k4273 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 851  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,*((C_word*)lf[277]+1));}

/* k4276 in k4273 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 852  eval */
((C_proc3)C_retrieve_symbol_proc(lf[58]))(3,*((C_word*)lf[58]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4216 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4218,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(lf[273],((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4229,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4239,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 855  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4083(2,t2,C_SCHEME_UNDEFINED);}}

/* a4238 in k4216 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4239r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4239r(t0,t1,t2);}}

static void C_ccall f_4239r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4250,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_4250(t5,(C_word)C_fixnump(t4));}
else{
t4=t3;
f_4250(t4,C_SCHEME_FALSE);}}

/* k4248 in a4238 in k4216 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_4250(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_fix(0));
/* csi.scm: 857  exit */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],t2);}

/* a4228 in k4216 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4237,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 855  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[275]))(2,*((C_word*)lf[275]+1),t2);}

/* k4235 in a4228 in k4216 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main */
((C_proc3)C_retrieve_symbol_proc(lf[274]))(3,*((C_word*)lf[274]+1),((C_word*)t0)[2],t1);}

/* a4207 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4208(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4208r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4208r(t0,t1,t2);}}

static void C_ccall f_4208r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[270]+1),C_retrieve(lf[65]),t2);}

/* k4196 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4083(2,t4,t3);}

/* a4181 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4182r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4182r(t0,t1,t2);}}

static void C_ccall f_4182r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[270]+1),*((C_word*)lf[15]+1),t2);}

/* k4170 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4083(2,t4,t3);}

/* k4150 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4083(2,t4,t3);}

/* k4134 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4136,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[264],t4);
/* csi.scm: 833  eval */
((C_proc3)C_retrieve_symbol_proc(lf[58]))(3,*((C_word*)lf[58]+1),((C_word*)t0)[2],t5);}

/* k4110 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4083(2,t4,t3);}

/* k4081 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4058(t3,((C_word*)t0)[2],t2);}

/* k4069 in doloop932 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 827  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[110]+1));}

/* evalstring in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3937(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3937,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3941,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3941(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3984,tmp=(C_word)a,a+=2,tmp));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3941(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* f_3984 in evalstring in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3984,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k3939 in evalstring in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 766  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t2,((C_word*)t0)[2]);}

/* k3942 in k3939 in evalstring in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 767  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,t1);}

/* k3949 in k3942 in k3939 in evalstring in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3953(t5,((C_word*)t0)[2],t1);}

/* doloop847 in k3949 in k3942 in k3939 in evalstring in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3953(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3953,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3974,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3976,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[252]+1));}}

/* a3975 in doloop847 in k3949 in k3942 in k3939 in evalstring in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3976,2,t0,t1);}
/* csi.scm: 769  eval */
((C_proc3)C_retrieve_symbol_proc(lf[58]))(3,*((C_word*)lf[58]+1),t1,((C_word*)t0)[2]);}

/* k3972 in doloop847 in k3949 in k3942 in k3939 in evalstring in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 769  rec */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3961 in doloop847 in k3949 in k3942 in k3939 in evalstring in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 767  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,((C_word*)t0)[2]);}

/* k3968 in k3961 in doloop847 in k3949 in k3942 in k3939 in evalstring in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_3953(t2,((C_word*)t0)[2],t1);}

/* collect-options in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3857(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3857,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3863,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3863(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3863(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3863,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_member(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
/* csi.scm: 754  ##sys#error */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[251],((C_word*)t0)[3]);}
else{
t5=(C_word)C_i_cadr(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3890,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cddr(t3);
/* csi.scm: 755  loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k3888 in loop in collect-options in k3853 in k3847 in k3844 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 in ##csi#run in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3890,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* canonicalize-args in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3679(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3679,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3685,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3685(t6,t1,t2);}

/* loop in canonicalize-args in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3685(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3685,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[242]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[243]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[244]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[245]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[246]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3707,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(2)))){
t6=(C_word)C_eqp(C_make_character(45),(C_word)C_subchar(t3,C_fix(0)));
if(C_truep(t6)){
t7=(C_word)C_i_member(t3,lf[249]);
t8=t4;
f_3707(t8,(C_word)C_i_not(t7));}
else{
t7=t4;
f_3707(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_3707(t6,C_SCHEME_FALSE);}}}}

/* k3705 in loop in canonicalize-args in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3707(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3707,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(C_make_character(58),(C_word)C_subchar(((C_word*)t0)[5],C_fix(1)));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 700  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3685(t4,((C_word*)t0)[2],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 701  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[29]+1)))(4,*((C_word*)lf[29]+1),t4,((C_word*)t0)[5],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 705  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3685(t4,t2,t3);}}

/* k3762 in k3705 in loop in canonicalize-args in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3764,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3755 in k3705 in loop in canonicalize-args in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[248]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3721 in k3705 in loop in canonicalize-args in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3723,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3796,tmp=(C_word)a,a+=2,tmp);
t4=f_3796(t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3736,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3746,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
/* csi.scm: 704  ##sys#error */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[247],((C_word*)t0)[2]);}}

/* a3745 in k3721 in k3705 in loop in canonicalize-args in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3746,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k3734 in k3721 in k3705 in loop in canonicalize-args in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3740,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 703  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3685(t4,t2,t3);}

/* k3738 in k3734 in k3721 in k3705 in loop in canonicalize-args in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 703  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[213]+1)))(4,*((C_word*)lf[213]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k3721 in k3705 in loop in canonicalize-args in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static C_word C_fcall f_3796(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* member* in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3622(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3622,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3628,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3628(t7,t1,t3);}

/* loop in member* in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3628(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3628,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3640,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_3640(t6,t1,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* find in loop in member* in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3640(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3640,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 676  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3628(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_i_cdr(t2);
/* csi.scm: 678  find */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##csi#deldups in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3563r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3563r(t0,t1,t2,t3);}}

static void C_ccall f_3563r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3567,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3567(2,t5,*((C_word*)lf[239]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3567(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3565 in ##csi#deldups in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3567,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3572,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3572(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* recur in k3565 in ##csi#deldups in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3572(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3572,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3588,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3601,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 669  del */
((C_proc5)C_retrieve_symbol_proc(lf[237]))(5,*((C_word*)lf[237]+1),t6,t3,t4,((C_word*)t0)[2]);}}

/* k3599 in recur in k3565 in ##csi#deldups in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 669  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3572(t2,((C_word*)t0)[2],t1);}

/* k3586 in recur in k3565 in ##csi#deldups in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3588,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* ##csi#del in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3525,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3531,a[2]=t2,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3531(t8,t1,t3);}

/* loop in ##csi#del in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3531(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3531,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3547,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 659  tst */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k3545 in loop in ##csi#del in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3547,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 661  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3531(t4,t2,t3);}}

/* k3555 in k3545 in loop in ##csi#del in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3557,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3316,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3348,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t8,a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_3348(t10,t1,C_fix(0));}

/* doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3348(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3348,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3523,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 628  justify */
t5=((C_word*)t0)[2];
f_3319(t5,t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k3521 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 628  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 629  write-char */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(58),((C_word*)t0)[8]);}

/* k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3364,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3433(t6,t2,C_fix(0),((C_word*)t0)[11]);}

/* doloop575 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3433(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3433,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]));
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3452,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 634  fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[236]+1)))(4,*((C_word*)lf[236]+1),t6,((C_word*)t0)[9],C_fix(16));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 639  write-char */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_make_character(32),((C_word*)t0)[7]);}}

/* k3492 in doloop575 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3497,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3512,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3516,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 640  ref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[9]);}

/* k3514 in k3492 in doloop575 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 640  justify */
t2=((C_word*)t0)[3];
f_3319(t2,((C_word*)t0)[2],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k3510 in k3492 in doloop575 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 640  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3495 in k3492 in doloop575 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3433(t4,((C_word*)t0)[2],t2,t3);}

/* k3450 in doloop575 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3452,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_fixnum_difference(C_fix(16),t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3470(t7,((C_word*)t0)[4],t3);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* doloop590 in k3450 in doloop575 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3470(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3470,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3480,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 638  display */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[235],((C_word*)t0)[2]);}}

/* k3478 in doloop590 in k3450 in doloop575 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3470(t3,((C_word*)t0)[2],t2);}

/* k3362 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 641  write-char */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(32),((C_word*)t0)[6]);}

/* k3365 in k3362 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3382(t6,t2,C_fix(0),((C_word*)t0)[9]);}

/* doloop600 in k3365 in k3362 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3382(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3382,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[7]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3395,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 645  ref */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t3);}}

/* k3393 in doloop600 in k3365 in k3362 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3398,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_make_character((C_word)C_unfix(t1));
/* csi.scm: 647  write-char */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,t5,((C_word*)t0)[2]);}
else{
/* csi.scm: 648  write-char */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(46),((C_word*)t0)[2]);}}

/* k3396 in k3393 in doloop600 in k3365 in k3362 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3382(t4,((C_word*)t0)[2],t2,t3);}

/* k3368 in k3365 in k3362 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 649  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t2,C_make_character(10),((C_word*)t0)[2]);}

/* k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in doloop562 in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3348(t3,((C_word*)t0)[2],t2);}

/* justify in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3319(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3319,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3323,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 620  number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k3321 in justify in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3323,2,t0,t1);}
t2=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3339,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[6],t2);
/* csi.scm: 623  make-string */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k3337 in k3321 in justify in ##csi#hexdump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 623  string-append */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##csi#dump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3155r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3155r(t0,t1,t2,t3);}}

static void C_ccall f_3155r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3157,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3263,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-len524549 */
t7=t6;
f_3268(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-out525547 */
t9=t5;
f_3263(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body522530 */
t11=t4;
f_3157(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-len524 in ##csi#dump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3268(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3268,NULL,2,t0,t1);}
/* def-out525547 */
t2=((C_word*)t0)[2];
f_3263(t2,t1,C_SCHEME_FALSE);}

/* def-out525 in ##csi#dump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3263,NULL,3,t0,t1,t2);}
/* body522530 */
t3=((C_word*)t0)[2];
f_3157(t3,t1,t2,*((C_word*)lf[110]+1));}

/* body522 in ##csi#dump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3157(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3157,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3160,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_immp(((C_word*)t0)[2]))){
/* csi.scm: 602  ##sys#error */
t5=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[230],lf[231],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3182,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 603  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[219]+1)))(3,*((C_word*)lf[219]+1),t5,((C_word*)t0)[2]);}}

/* k3180 in body522 in ##csi#dump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3182,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3189,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 603  bestlen */
t4=((C_word*)t0)[2];
f_3160(t4,t2,t3);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 604  bestlen */
t4=((C_word*)t0)[2];
f_3160(t4,t2,t3);}
else{
t2=(C_word)C_immp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_anypointerp(((C_word*)t0)[4]));
if(C_truep(t3)){
/* csi.scm: 606  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[194]))(6,*((C_word*)lf[194]+1),((C_word*)t0)[5],((C_word*)t0)[4],C_fix(32),*((C_word*)lf[232]+1),((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t6=t4;
f_3225(t6,(C_word)C_i_assq(t5,C_retrieve2(lf[133],"bytevector-data")));}
else{
t5=t4;
f_3225(t5,C_SCHEME_FALSE);}}}}}

/* k3223 in k3180 in body522 in ##csi#dump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3225,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 609  bestlen */
t5=((C_word*)t0)[2];
f_3160(t5,t3,t4);}
else{
/* csi.scm: 610  ##sys#error */
t2=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[230],lf[233],((C_word*)t0)[5]);}}

/* k3233 in k3223 in k3180 in body522 in ##csi#dump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 609  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[194]))(6,*((C_word*)lf[194]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[195]+1),((C_word*)t0)[2]);}

/* k3204 in k3180 in body522 in ##csi#dump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 604  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[194]))(6,*((C_word*)lf[194]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[195]+1),((C_word*)t0)[2]);}

/* k3187 in k3180 in body522 in ##csi#dump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 603  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[194]))(6,*((C_word*)lf[194]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[195]+1),((C_word*)t0)[2]);}

/* bestlen in body522 in ##csi#dump in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_3160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3160,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 601  min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[229]+1)))(4,*((C_word*)lf[229]+1),t1,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-describer! in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3146,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3150,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 590  ##sys#check-symbol */
((C_proc5)C_retrieve_proc(*((C_word*)lf[227]+1)))(5,*((C_word*)lf[227]+1),t4,t2,lf[228],lf[226]);}

/* k3148 in set-describer! in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 591  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),((C_word*)t0)[4],C_retrieve2(lf[135],"describer-table"),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_2316r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2316r(t0,t1,t2,t3);}}

static void C_ccall f_2316r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2320(2,t5,*((C_word*)lf[110]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2320(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2322,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[7]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3125,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 477  ##sys#block-address */
((C_proc3)C_retrieve_symbol_proc(lf[225]))(3,*((C_word*)lf[225]+1),t4,((C_word*)t0)[7]);}
else{
t4=t3;
f_2448(2,t4,C_SCHEME_UNDEFINED);}}

/* k3123 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 477  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[224],t1);}

/* k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2451,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[9]));
/* csi.scm: 480  fprintf */
t4=((C_word*)t0)[8];
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,((C_word*)t0)[7],lf[146],((C_word*)t0)[9],t3,t3,t3);}
else{
switch(((C_word*)t0)[9]){
case C_SCHEME_TRUE:
/* csi.scm: 481  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[147]);
case C_SCHEME_FALSE:
/* csi.scm: 482  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[148]);
default:
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[9]))){
/* csi.scm: 483  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[149]);}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[9]))){
/* csi.scm: 484  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[150]);}
else{
t3=C_retrieve(lf[47]);
t4=(C_word)C_eqp(t3,((C_word*)t0)[9]);
if(C_truep(t4)){
/* csi.scm: 485  fprintf */
t5=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[7],lf[151]);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 487  fprintf */
t6=((C_word*)t0)[8];
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,((C_word*)t0)[7],lf[153],((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[9]);}
else{
t5=(C_word)C_slot(lf[154],C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[9],t5);
if(C_truep(t6)){
/* csi.scm: 492  fprintf */
t7=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[7],lf[155]);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 493  ##sys#number? */
((C_proc3)C_retrieve_symbol_proc(lf[223]))(3,*((C_word*)lf[223]+1),t7,((C_word*)t0)[9]);}}}}}}}}

/* k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2547,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 493  fprintf */
t2=((C_word*)t0)[10];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],lf[156],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[7]))){
/* csi.scm: 494  descseq */
t2=((C_word*)t0)[6];
f_2322(6,t2,((C_word*)t0)[9],lf[157],*((C_word*)lf[158]+1),((C_word*)t0)[5],C_fix(0));}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
/* csi.scm: 495  descseq */
t2=((C_word*)t0)[6];
f_2322(6,t2,((C_word*)t0)[9],lf[159],*((C_word*)lf[158]+1),*((C_word*)lf[160]+1),C_fix(0));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 497  ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),t3,((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[7]))){
/* csi.scm: 514  descseq */
t2=((C_word*)t0)[6];
f_2322(6,t2,((C_word*)t0)[9],lf[172],((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* csi.scm: 515  fprintf */
t4=((C_word*)t0)[10];
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[9],((C_word*)t0)[8],lf[173],t2,t3);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[7]))){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(3)))){
if(C_truep((C_word)C_i_memq(lf[177],C_retrieve(lf[6])))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[7],t4);
t6=t3;
f_2715(t6,(C_word)C_eqp(C_retrieve(lf[178]),t5));}
else{
t4=t3;
f_2715(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2715(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2755,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 525  port? */
((C_proc3)C_retrieve_symbol_proc(lf[222]))(3,*((C_word*)lf[222]+1),t2,((C_word*)t0)[7]);}}}}}}}}

/* k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2755,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_truep(t2)?lf[179]:lf[180]);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(7));
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2774,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 531  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[176]))(4,*((C_word*)lf[176]+1),t6,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(lf[177],C_retrieve(lf[6])))){
/* csi.scm: 532  instance? */
((C_proc3)C_retrieve_symbol_proc(lf[221]))(3,*((C_word*)lf[221]+1),t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_2783(2,t3,C_SCHEME_FALSE);}}}

/* k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2783,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 533  describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 534  ##sys#locative? */
((C_proc3)C_retrieve_symbol_proc(lf[220]))(3,*((C_word*)lf[220]+1),t2,((C_word*)t0)[5]);}}

/* k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2792,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 536  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[176]))(4,*((C_word*)lf[176]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 549  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[176]))(4,*((C_word*)lf[176]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 550  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[219]+1)))(3,*((C_word*)lf[219]+1),t2,((C_word*)t0)[6]);}}}

/* k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 552  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],lf[196],t2);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2905,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 555  ##sys#lambda-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[198]))(3,*((C_word*)lf[198]+1),t2,((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[199]))){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[203]:lf[204]);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* csi.scm: 558  fprintf */
t7=((C_word*)t0)[3];
((C_proc7)C_retrieve_proc(t7))(7,t7,t3,((C_word*)t0)[4],lf[205],t2,t5,t6);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[206]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* csi.scm: 565  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[211],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[216]))){
/* csi.scm: 575  provided? */
((C_proc3)C_retrieve_symbol_proc(lf[217]))(3,*((C_word*)lf[217]+1),t2,lf[218]);}
else{
t3=t2;
f_3036(2,t3,C_SCHEME_FALSE);}}}}}}

/* k3034 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3036,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 576  unveil */
((C_proc4)C_retrieve_symbol_proc(lf[212]))(4,*((C_word*)lf[212]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 579  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[100]))(4,*((C_word*)lf[100]+1),t3,C_retrieve2(lf[135],"describer-table"),t2);}
else{
/* csi.scm: 586  fprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[4],lf[215]);}}}

/* k3049 in k3034 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3051,2,t0,t1);}
if(C_truep(t1)){
/* g502503504 */
t2=t1;
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[4],C_retrieve2(lf[133],"bytevector-data"));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3074,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* map */
t6=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[58]),t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3085,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
/* csi.scm: 584  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[5],lf[214],t4);}}}

/* k3083 in k3049 in k3034 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 585  descseq */
t2=((C_word*)t0)[3];
f_2322(6,t2,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[158]+1),*((C_word*)lf[160]+1),C_fix(1));}

/* k3072 in k3049 in k3034 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3074,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_fix(0));
/* csi.scm: 582  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[213]+1)))(4,*((C_word*)lf[213]+1),((C_word*)t0)[2],t1,t2);}

/* k3068 in k3049 in k3034 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2951 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2962(t6,((C_word*)t0)[2],t2);}

/* loop469 in k2951 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_2962(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2962,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 568  fprintf */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],lf[210],t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2973 in loop469 in k2951 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2991(t7,t2,t3);}

/* loop in k2973 in loop469 in k2951 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_2991(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2991,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3001,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3026,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 571  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[209]+1)))(3,*((C_word*)lf[209]+1),t4,t2);}}

/* k3024 in loop in k2973 in loop469 in k2951 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3026,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 572  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t3,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[3];
f_3001(2,t3,C_SCHEME_UNDEFINED);}}

/* k3016 in k3024 in loop in k2973 in loop469 in k2951 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* csi.scm: 572  fprintf */
t3=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[207],t1,t2);}

/* k2999 in loop in k2973 in loop469 in k2951 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* csi.scm: 573  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2991(t3,((C_word*)t0)[2],t2);}

/* k2976 in k2973 in loop469 in k2951 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2962(t3,((C_word*)t0)[2],t2);}

/* k2915 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm: 560  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[202],t3);}

/* k2918 in k2915 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2925,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 561  hash-table-walk */
((C_proc4)C_retrieve_symbol_proc(lf[201]))(4,*((C_word*)lf[201]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a2924 in k2918 in k2915 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2925,4,t0,t1,t2,t3);}
/* csi.scm: 563  fprintf */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],lf[200],t2,t3);}

/* k2903 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 555  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[197],t1);}

/* k2890 in k2884 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 553  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[194]))(6,*((C_word*)lf[194]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],*((C_word*)lf[195]+1),((C_word*)t0)[2]);}

/* k2878 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 549  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[193],t1);}

/* k2797 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2810,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_2810(t5,lf[183]);
case C_fix(1):
t5=t4;
f_2810(t5,lf[184]);
case C_fix(2):
t5=t4;
f_2810(t5,lf[185]);
case C_fix(3):
t5=t4;
f_2810(t5,lf[186]);
case C_fix(4):
t5=t4;
f_2810(t5,lf[187]);
case C_fix(5):
t5=t4;
f_2810(t5,lf[188]);
case C_fix(6):
t5=t4;
f_2810(t5,lf[189]);
case C_fix(7):
t5=t4;
f_2810(t5,lf[190]);
case C_fix(8):
t5=t4;
f_2810(t5,lf[191]);
default:
t5=(C_word)C_eqp(t3,C_fix(9));
t6=t4;
f_2810(t6,(C_truep(t5)?lf[192]:C_SCHEME_UNDEFINED));}}

/* k2808 in k2797 in k2790 in k2781 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_2810(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 535  fprintf */
t2=((C_word*)t0)[6];
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[182],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2772 in k2753 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 526  fprintf */
t2=((C_word*)t0)[7];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[181],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2713 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_2715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2715,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 521  describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2729,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 523  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[176]))(4,*((C_word*)lf[176]+1),t3,((C_word*)t0)[5],C_fix(0));}}

/* k2727 in k2713 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 523  sprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[175],t1);}

/* k2723 in k2713 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 522  descseq */
t2=((C_word*)t0)[3];
f_2322(6,t2,((C_word*)t0)[2],t1,*((C_word*)lf[158]+1),*((C_word*)lf[160]+1),C_fix(1));}

/* k2669 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2577(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 497  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[170],((C_word*)t0)[2]);}}

/* k2575 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_subbyte(t4,C_fix(0));
t6=t3;
f_2651(t6,(C_word)C_eqp(C_fix(0),t5));}
else{
t4=t3;
f_2651(t4,C_SCHEME_FALSE);}}

/* k2649 in k2575 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_2651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 499  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[169],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2580(2,t2,C_SCHEME_UNDEFINED);}}

/* k2578 in k2575 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2648,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 501  ##sys#interned-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[168]))(3,*((C_word*)lf[168]+1),t3,((C_word*)t0)[5]);}

/* k2646 in k2578 in k2575 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2648,2,t0,t1);}
t2=(C_truep(t1)?lf[164]:lf[165]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2645,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 502  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),t3,((C_word*)t0)[2]);}

/* k2643 in k2646 in k2578 in k2575 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 500  fprintf */
t2=((C_word*)t0)[5];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[166],((C_word*)t0)[2],t1);}

/* k2581 in k2578 in k2575 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2583,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[4];
f_2451(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2595,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 505  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),t3,lf[163],((C_word*)t0)[3]);}}

/* k2593 in k2581 in k2578 in k2575 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2595,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2600,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2600(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop435 in k2593 in k2581 in k2578 in k2575 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_2600(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2600,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* csi.scm: 508  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[3],lf[162],t4);}}

/* k2608 in doloop435 in k2593 in k2581 in k2578 in k2575 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 509  ##sys#with-print-length-limit */
((C_proc4)C_retrieve_symbol_proc(lf[161]))(4,*((C_word*)lf[161]+1),t2,C_fix(1000),t3);}

/* a2624 in k2608 in doloop435 in k2593 in k2581 in k2578 in k2575 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2625,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 512  write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),t1,t2,((C_word*)t0)[2]);}

/* k2611 in k2608 in doloop435 in k2593 in k2581 in k2578 in k2575 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 513  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,((C_word*)t0)[2]);}

/* k2614 in k2611 in k2608 in doloop435 in k2593 in k2581 in k2578 in k2575 in k2545 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2600(t3,((C_word*)t0)[2],t2);}

/* k2515 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2517,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2523,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[5],C_fix(65536)))){
/* csi.scm: 489  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[152],t2);}
else{
t4=t3;
f_2523(2,t4,C_SCHEME_UNDEFINED);}}

/* k2521 in k2515 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 490  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[110]+1));}

/* k2449 in k2446 in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* descseq in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2322,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2445,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 457  plen */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2443 in descseq in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2445,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2329,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 458  fprintf */
t4=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[6],lf[145],((C_word*)t0)[2],t2);}
else{
t4=t3;
f_2329(2,t4,C_SCHEME_UNDEFINED);}}

/* k2327 in k2443 in descseq in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2329,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2334,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_2334(t5,((C_word*)t0)[2],C_fix(0));}

/* loop1 in k2327 in k2443 in descseq in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_2334(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2334,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[8],t2);
/* csi.scm: 462  fprintf */
t5=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[6],lf[140],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2357,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],t2);
/* csi.scm: 464  pref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k2355 in loop1 in k2327 in k2443 in descseq in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_2366(t7,((C_word*)t0)[2],C_fix(1),t3);}

/* loop2 in k2355 in loop1 in k2327 in k2443 in descseq in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_2366(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2366,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[10]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 467  fprintf */
t5=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[6],lf[144],((C_word*)t0)[9],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 474  pref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k2428 in loop2 in k2355 in loop1 in k2327 in k2443 in descseq in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* csi.scm: 474  loop2 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2366(t5,((C_word*)t0)[3],t3,t4);}
else{
/* csi.scm: 475  loop2 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2366(t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k2374 in loop2 in k2355 in loop1 in k2327 in k2443 in descseq in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],C_fix(1)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(2));
t5=(C_truep(t4)?lf[141]:lf[142]);
/* csi.scm: 469  fprintf */
t6=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,((C_word*)t0)[2],lf[143],t3,t5);}
else{
/* csi.scm: 472  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,((C_word*)t0)[2]);}}

/* k2377 in k2374 in loop2 in k2355 in loop1 in k2327 in k2443 in descseq in k2318 in ##csi#describe in k2312 in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm: 473  loop1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2334(t3,((C_word*)t0)[2],t2);}

/* ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2088r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2088r(t0,t1,t2);}}

static void C_ccall f_2088r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2096,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_2096(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
/* csi.scm: 386  current-output-port */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 386  with-output-to-port */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 388  gc */
((C_proc2)C_retrieve_symbol_proc(lf[132]))(2,*((C_word*)lf[132]+1),t2);}

/* k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 389  ##sys#symbol-table-info */
((C_proc2)C_retrieve_symbol_proc(lf[131]))(2,*((C_word*)lf[131]+1),t2);}

/* k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 390  memory-statistics */
((C_proc2)C_retrieve_symbol_proc(lf[130]))(2,*((C_word*)lf[130]+1),t2);}

/* k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2110,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 392  printf */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[129]);}

/* k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2229,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2296,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2300,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[128]),C_retrieve(lf[6]));}

/* k2298 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 400  sort */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[126]+1));}

/* k2294 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 400  chop */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k2227 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2229,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2231(t5,((C_word*)t0)[2],t1);}

/* loop326 in k2227 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_2231(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2231,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2244,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 395  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t4,lf[125]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2242 in loop326 in k2227 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2247,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2256(t6,t2,((C_word*)t0)[2]);}

/* loop334 in k2242 in loop326 in k2227 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_2256(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2256,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2269,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2280,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_length(t3);
t7=(C_word)C_fixnum_difference(C_fix(16),t6);
t8=(C_word)C_i_fixnum_max(C_fix(1),t7);
/* csi.scm: 398  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t5,t8,C_make_character(32));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2278 in loop334 in k2242 in loop326 in k2227 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 398  printf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[123],((C_word*)t0)[2],t1);}

/* k2267 in loop334 in k2242 in loop326 in k2227 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2256(t3,((C_word*)t0)[2],t2);}

/* k2245 in k2242 in loop326 in k2227 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2231(t3,((C_word*)t0)[2],t2);}

/* k2126 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2131,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2156,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 412  machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[122]))(2,*((C_word*)lf[122]+1),t3);}

/* k2154 in k2126 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2156,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(3));
t3=(C_truep(t2)?lf[111]:lf[112]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2164,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 414  software-type */
((C_proc2)C_retrieve_symbol_proc(lf[121]))(2,*((C_word*)lf[121]+1),t4);}

/* k2162 in k2154 in k2126 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 415  software-version */
((C_proc2)C_retrieve_symbol_proc(lf[120]))(2,*((C_word*)lf[120]+1),t2);}

/* k2166 in k2162 in k2154 in k2126 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2172,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 416  build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[119]))(2,*((C_word*)lf[119]+1),t2);}

/* k2170 in k2166 in k2162 in k2154 in k2126 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
/* csi.scm: 418  shorten */
f_2110(t2,t3);}

/* k2174 in k2170 in k2166 in k2162 in k2154 in k2126 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2180,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(1));
/* csi.scm: 419  shorten */
f_2110(t2,t3);}

/* k2178 in k2174 in k2170 in k2166 in k2162 in k2154 in k2126 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(2));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
t4=(C_word)C_fudge(C_fix(17));
t5=(C_truep(t4)?lf[113]:lf[114]);
t6=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(2));
t8=(C_word)C_fudge(C_fix(18));
t9=(C_word)C_i_nequalp(C_fix(1),t8);
t10=(C_truep(t9)?lf[115]:lf[116]);
/* csi.scm: 401  printf */
t11=((C_word*)t0)[9];
((C_proc17)C_retrieve_proc(t11))(17,t11,((C_word*)t0)[8],lf[117],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_retrieve(lf[118]),((C_word*)t0)[2],t1,t2,t3,t5,t6,t7,t10);}

/* k2129 in k2126 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 426  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t2,C_make_character(10),*((C_word*)lf[110]+1));}

/* k2132 in k2129 in k2126 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2137,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(14)))){
/* csi.scm: 427  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[108]);}
else{
t3=t2;
f_2137(2,t3,C_SCHEME_UNDEFINED);}}

/* k2135 in k2132 in k2129 in k2126 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(15)))){
/* csi.scm: 428  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[107]);}
else{
t3=t2;
f_2140(2,t3,C_SCHEME_UNDEFINED);}}

/* k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* shorten in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_2110(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2110,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2118,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm: 391  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[106]+1)))(3,*((C_word*)lf[106]+1),t3,t4);}

/* k2116 in shorten in k2106 in k2103 in k2100 in a2097 in k2094 in ##csi#report in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2118,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_divide(&a,2,t1,C_fix(100)));}

/* ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1576,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 267  exit */
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1592(t5,(C_word)C_eqp(lf[101],t4));}
else{
t4=t3;
f_1592(t4,C_SCHEME_FALSE);}}}

/* k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_1592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1592,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1598,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* csi.scm: 271  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[100]))(4,*((C_word*)lf[100]+1),t3,C_retrieve2(lf[55],"command-table"),t2);}
else{
t4=t3;
f_1598(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1946,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[12],t2,t3);}}

/* a1951 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1952r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1952r(t0,t1,t2);}}

static void C_ccall f_1952r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1956,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 354  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t2);}

/* k1954 in a1951 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1945 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1946,2,t0,t1);}
/* csi.scm: 353  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1598,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1604,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(t1);
t4=t3;
((C_proc2)C_retrieve_proc(t4))(2,t4,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[13],lf[70]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 278  read */
t4=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[72]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 282  read */
t5=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[13],lf[73]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1660,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 287  read */
t6=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[13],lf[75]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 291  read */
t7=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[13],lf[77]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 295  read */
t8=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[13],lf[78]);
if(C_truep(t7)){
/* csi.scm: 300  report */
((C_proc2)C_retrieve_symbol_proc(lf[79]))(2,*((C_word*)lf[79]+1),((C_word*)t0)[14]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[13],lf[80]);
if(C_truep(t8)){
/* csi.scm: 301  exit */
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),((C_word*)t0)[14]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[13],lf[81]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1762,a[2]=t10,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 303  read-line */
t12=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[13],lf[83]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1771,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1812,a[2]=t11,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 307  read-line */
t13=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[13],lf[87]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1821,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 311  read */
t13=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[13],lf[91]);
if(C_truep(t12)){
if(C_truep(C_retrieve(lf[92]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_a_i_list(&a,1,C_retrieve(lf[92]));
/* csi.scm: 317  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t13,t14);}
else{
t13=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}}
else{
t13=(C_word)C_eqp(((C_word*)t0)[13],lf[93]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 320  read-line */
t15=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t15))(2,t15,t14);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[13],lf[95]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 325  display */
t16=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,lf[98]);}
else{
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 350  printf */
t16=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t16))(4,t16,t15,lf[99],((C_word*)t0)[2]);}}}}}}}}}}}}}}}

/* k1930 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k1906 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1916,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 341  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[97]))(4,*((C_word*)lf[97]+1),t2,t3,C_retrieve2(lf[55],"command-table"));}

/* a1915 in k1906 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1916,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep(t4)){
/* csi.scm: 345  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t1,C_make_character(32),t4);}
else{
/* csi.scm: 346  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t1,lf[96],t2);}}

/* k1909 in k1906 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k1887 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 321  system */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t2,t1);}

/* k1890 in k1887 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1895,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* csi.scm: 322  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t2,t3);}

/* k1893 in k1890 in k1887 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1871 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 318  describe */
((C_proc3)C_retrieve_symbol_proc(lf[74]))(3,*((C_word*)lf[74]+1),((C_word*)t0)[2],C_retrieve(lf[92]));}

/* k1819 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1826,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1853 in k1819 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1854r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1854r(t0,t1,t2);}}

static void C_ccall f_1854r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1858,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 313  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t2);}

/* k1856 in a1853 in k1819 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1825 in k1819 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1830,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1828 in a1825 in k1819 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1841,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1840 in k1828 in a1825 in k1819 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_1841r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1841r(t0,t1,t2);}}

static void C_ccall f_1841r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1845,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[89]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k1850 in a1840 in k1828 in a1825 in k1819 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[88]))(3,*((C_word*)lf[88]+1),((C_word*)t0)[2],t1);}

/* k1843 in a1840 in k1828 in a1825 in k1819 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1834 in k1828 in a1825 in k1819 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1835,2,t0,t1);}
/* csi.scm: 312  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1810 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 307  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1769 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1774,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1779(t6,t2,t1);}

/* loop248 in k1769 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_1779(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1779,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1792,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* load-noisily178 */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t3,lf[86],t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a1800 in loop248 in k1769 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1801,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 308  pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1803 in a1800 in loop248 in k1769 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 308  print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),((C_word*)t0)[2],lf[85]);}

/* k1790 in loop248 in k1769 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1779(t3,((C_word*)t0)[2],t2);}

/* k1772 in k1769 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k1760 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 303  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1727 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1732,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1737,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1737(t6,t2,t1);}

/* loop237 in k1727 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_1737(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1737,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1747,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* load */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1745 in loop237 in k1727 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1737(t3,((C_word*)t0)[2],t2);}

/* k1730 in k1727 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k1688 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1693,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 296  read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1691 in k1688 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1696,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 297  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1694 in k1691 in k1688 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1699,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 298  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1697 in k1694 in k1691 in k1688 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 299  dump */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1673 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1678,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 292  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1676 in k1673 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 293  dump */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k1658 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1663,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 288  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1661 in k1658 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 289  describe */
((C_proc3)C_retrieve_symbol_proc(lf[74]))(3,*((C_word*)lf[74]+1),((C_word*)t0)[2],t1);}

/* k1640 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 283  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1643 in k1640 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 284  pretty-print */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1646 in k1643 in k1640 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k1617 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1622,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1629,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1633,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 279  expand */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k1631 in k1617 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 279  ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[71]))(3,*((C_word*)lf[71]+1),((C_word*)t0)[2],t1);}

/* k1627 in k1617 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 279  pretty-print */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1620 in k1617 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k1602 in k1596 in k1590 in ##sys#repl-eval-hook in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* toplevel-command in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1535r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1535r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1535r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1539,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1539(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1539(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1537 in toplevel-command in k1531 in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1539,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[4],lf[56]);
t3=(C_truep(t1)?(C_word)C_i_check_string_2(t1,lf[56]):C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* csi.scm: 250  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),((C_word*)t0)[2],C_retrieve2(lf[55],"command-table"),((C_word*)t0)[4],t4);}

/* ##sys#read-prompt-hook in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1526,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 243  tty-input? */
((C_proc2)C_retrieve_symbol_proc(lf[50]))(2,*((C_word*)lf[50]+1),t2);}

/* k1524 in ##sys#read-prompt-hook in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 243  old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##csi#tty-input? in k1502 in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1506,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm: 236  ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[51]))(3,*((C_word*)lf[51]+1),t1,*((C_word*)lf[52]+1));}}

/* ##csi#history-ref in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1479,3,t0,t1,t2);}
t3=(C_word)C_i_inexact_to_exact(t2);
t4=(C_word)C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(t3,C_retrieve(lf[25])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_vector_ref(C_retrieve(lf[44]),t3));}
else{
/* csi.scm: 228  ##sys#error */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[49],t2);}}

/* ##csi#history-add in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1440,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_retrieve(lf[47]):(C_word)C_slot(t2,C_fix(0)));
t5=(C_word)C_block_size(C_retrieve(lf[44]));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1450,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_retrieve(lf[25]),t5))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1464,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_times(C_fix(2),t5);
/* csi.scm: 219  vector-resize */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve(lf[44]),t8);}
else{
t7=t6;
f_1450(t7,C_SCHEME_UNDEFINED);}}

/* k1462 in ##csi#history-add in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[44]+1 /* (set! history-list ...) */,t1);
t3=((C_word*)t0)[2];
f_1450(t3,t2);}

/* k1448 in ##csi#history-add in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_1450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_vector_set(C_retrieve(lf[44]),C_retrieve(lf[25]),((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(C_retrieve(lf[25]),C_fix(1));
t4=C_mutate((C_word*)lf[25]+1 /* (set! history-count ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1334,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1338,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 192  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),t3,lf[43]);}

/* k1336 in ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1338,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t4=(C_word)C_eqp(t3,C_make_character(92));
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,C_make_character(47)));
if(C_truep(t5)){
/* csi.scm: 194  addext */
f_1286(((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t6=C_retrieve2(lf[28],"dirseparator\077");
t7=((C_word*)t0)[5];
t8=(C_word)C_block_size(t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1313,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=f_1313(t9,C_fix(0));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1362,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t12=((C_word*)t0)[2];
t13=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t14=(C_truep(t12)?(C_word)C_i_foreign_block_argumentp(t12):C_SCHEME_FALSE);
t15=(C_word)C_i_foreign_fixnum_argumentp(C_fix(256));
t16=(C_word)stub75(t13,t14,t15);
/* ##sys#peek-nonnull-c-string */
t17=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t11,t16,C_fix(0));}
else{
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 198  addext */
f_1286(t11,((C_word*)t0)[5]);}}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1377 in k1336 in ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1379,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 200  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[34]+1)))(4,*((C_word*)lf[34]+1),t2,lf[41],((C_word*)t0)[2]);}}

/* k1383 in k1377 in k1336 in ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1392,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 201  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[39]))(4,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2],lf[40]);}

/* k1390 in k1383 in k1377 in k1336 in ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1392,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1394,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1394(t5,((C_word*)t0)[2],t1);}

/* loop in k1390 in k1383 in k1377 in k1336 in ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_1394(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1394,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1404,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 203  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1419 in loop in k1390 in k1383 in k1377 in k1336 in ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 203  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[34]+1)))(4,*((C_word*)lf[34]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1402 in loop in k1390 in k1383 in k1377 in k1336 in ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 204  addext */
f_1286(t2,t1);}

/* k1405 in k1402 in loop in k1390 in k1383 in k1377 in k1336 in ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 205  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1394(t3,((C_word*)t0)[4],t2);}}

/* k1360 in k1336 in ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1362,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1372,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 197  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),t3,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1374 in k1360 in k1336 in ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 197  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[34]+1)))(5,*((C_word*)lf[34]+1),((C_word*)t0)[3],t1,lf[37],((C_word*)t0)[2]);}

/* k1370 in k1360 in k1336 in ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 197  addext */
f_1286(((C_word*)t0)[2],t1);}

/* loop in k1336 in ##csi#lookup-script-file in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static C_word C_fcall f_1313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(47)));
if(C_truep(t4)){
return(t1);}
else{
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* addext in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_1286(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1286,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1293,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 181  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),t3,t2);}

/* k1291 in addext in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1293,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1296,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 183  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[34]+1)))(4,*((C_word*)lf[34]+1),t2,((C_word*)t0)[2],lf[35]);}}

/* k1294 in k1291 in addext in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1302,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 184  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),t2,t1);}

/* k1300 in k1294 in k1291 in addext in k1265 in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##csi#chop-separator in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1236,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1240,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 166  sub1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[31]+1)))(3,*((C_word*)lf[31]+1),t3,t4);}

/* k1238 in ##csi#chop-separator in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1240,2,t0,t1);}
t2=(C_word)C_i_string_ref(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1249,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(0)))){
t4=(C_word)C_eqp(t2,C_make_character(92));
t5=t3;
f_1249(t5,(C_truep(t4)?t4:(C_word)C_eqp(t2,C_make_character(47))));}
else{
t4=t3;
f_1249(t4,C_SCHEME_FALSE);}}

/* k1247 in k1238 in ##csi#chop-separator in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_fcall f_1249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 169  substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* dirseparator? in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1224,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(47))));}

/* ##sys#sharp-number-hook in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1210,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1222,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 155  history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t4,t3);}

/* k1220 in ##sys#sharp-number-hook in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1222,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[24],t2));}

/* ##sys#user-read-hook in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1177,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:(C_word)C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1198,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_difference(C_retrieve(lf[25]),C_fix(1));
/* csi.scm: 150  history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,t7);}
else{
/* csi.scm: 151  old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* k1196 in ##sys#user-read-hook in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1198,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[24],t2));}

/* ##csi#print-banner in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1165,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 120  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[20]+1)))(2,*((C_word*)lf[20]+1),t2);}

/* k1163 in ##csi#print-banner in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1168,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 138  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,lf[19]);}

/* k1166 in k1163 in ##csi#print-banner in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1175,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 139  chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,C_SCHEME_TRUE);}

/* k1173 in k1166 in k1163 in ##csi#print-banner in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 139  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[15]+1)))(5,*((C_word*)lf[15]+1),((C_word*)t0)[2],lf[16],t1,lf[17]);}

/* ##csi#print-usage in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1137,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 72   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[13]);}

/* k1135 in ##csi#print-usage in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1147,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[10],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[2],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[11],t5);
/* csi.scm: 92   ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),t3,t6);}

/* k1145 in k1135 in ##csi#print-usage in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 92   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],t1);}

/* k1138 in k1135 in ##csi#print-usage in k1121 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 97   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[9]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[383] = {
{"toplevel:csi_scm",(void*)C_toplevel},
{"f_1096:csi_scm",(void*)f_1096},
{"f_1099:csi_scm",(void*)f_1099},
{"f_1102:csi_scm",(void*)f_1102},
{"f_1105:csi_scm",(void*)f_1105},
{"f_1108:csi_scm",(void*)f_1108},
{"f_1111:csi_scm",(void*)f_1111},
{"f_1114:csi_scm",(void*)f_1114},
{"f_1117:csi_scm",(void*)f_1117},
{"f_1120:csi_scm",(void*)f_1120},
{"f_1123:csi_scm",(void*)f_1123},
{"f_1267:csi_scm",(void*)f_1267},
{"f_4695:csi_scm",(void*)f_4695},
{"f_1504:csi_scm",(void*)f_1504},
{"f_1533:csi_scm",(void*)f_1533},
{"f_2314:csi_scm",(void*)f_2314},
{"f_4687:csi_scm",(void*)f_4687},
{"f_4693:csi_scm",(void*)f_4693},
{"f_4690:csi_scm",(void*)f_4690},
{"f_3824:csi_scm",(void*)f_3824},
{"f_4681:csi_scm",(void*)f_4681},
{"f_1989:csi_scm",(void*)f_1989},
{"f_2019:csi_scm",(void*)f_2019},
{"f_2037:csi_scm",(void*)f_2037},
{"f_2076:csi_scm",(void*)f_2076},
{"f_2082:csi_scm",(void*)f_2082},
{"f_2043:csi_scm",(void*)f_2043},
{"f_2051:csi_scm",(void*)f_2051},
{"f_2053:csi_scm",(void*)f_2053},
{"f_2070:csi_scm",(void*)f_2070},
{"f_2025:csi_scm",(void*)f_2025},
{"f_2031:csi_scm",(void*)f_2031},
{"f_2017:csi_scm",(void*)f_2017},
{"f_2014:csi_scm",(void*)f_2014},
{"f_1994:csi_scm",(void*)f_1994},
{"f_2004:csi_scm",(void*)f_2004},
{"f_2007:csi_scm",(void*)f_2007},
{"f_3828:csi_scm",(void*)f_3828},
{"f_4677:csi_scm",(void*)f_4677},
{"f_3831:csi_scm",(void*)f_3831},
{"f_3834:csi_scm",(void*)f_3834},
{"f_3837:csi_scm",(void*)f_3837},
{"f_4673:csi_scm",(void*)f_4673},
{"f_4660:csi_scm",(void*)f_4660},
{"f_4620:csi_scm",(void*)f_4620},
{"f_4570:csi_scm",(void*)f_4570},
{"f_4573:csi_scm",(void*)f_4573},
{"f_4576:csi_scm",(void*)f_4576},
{"f_4579:csi_scm",(void*)f_4579},
{"f_4588:csi_scm",(void*)f_4588},
{"f_3840:csi_scm",(void*)f_3840},
{"f_3843:csi_scm",(void*)f_3843},
{"f_4564:csi_scm",(void*)f_4564},
{"f_3846:csi_scm",(void*)f_3846},
{"f_3849:csi_scm",(void*)f_3849},
{"f_4555:csi_scm",(void*)f_4555},
{"f_4551:csi_scm",(void*)f_4551},
{"f_3855:csi_scm",(void*)f_3855},
{"f_4007:csi_scm",(void*)f_4007},
{"f_4540:csi_scm",(void*)f_4540},
{"f_4543:csi_scm",(void*)f_4543},
{"f_4010:csi_scm",(void*)f_4010},
{"f_4531:csi_scm",(void*)f_4531},
{"f_4534:csi_scm",(void*)f_4534},
{"f_4013:csi_scm",(void*)f_4013},
{"f_4016:csi_scm",(void*)f_4016},
{"f_4524:csi_scm",(void*)f_4524},
{"f_4517:csi_scm",(void*)f_4517},
{"f_4019:csi_scm",(void*)f_4019},
{"f_4504:csi_scm",(void*)f_4504},
{"f_4507:csi_scm",(void*)f_4507},
{"f_4022:csi_scm",(void*)f_4022},
{"f_4498:csi_scm",(void*)f_4498},
{"f_4025:csi_scm",(void*)f_4025},
{"f_4483:csi_scm",(void*)f_4483},
{"f_4486:csi_scm",(void*)f_4486},
{"f_4489:csi_scm",(void*)f_4489},
{"f_4028:csi_scm",(void*)f_4028},
{"f_4457:csi_scm",(void*)f_4457},
{"f_4459:csi_scm",(void*)f_4459},
{"f_4469:csi_scm",(void*)f_4469},
{"f_4031:csi_scm",(void*)f_4031},
{"f_4430:csi_scm",(void*)f_4430},
{"f_4432:csi_scm",(void*)f_4432},
{"f_4442:csi_scm",(void*)f_4442},
{"f_4034:csi_scm",(void*)f_4034},
{"f_4426:csi_scm",(void*)f_4426},
{"f_4414:csi_scm",(void*)f_4414},
{"f_4422:csi_scm",(void*)f_4422},
{"f_4418:csi_scm",(void*)f_4418},
{"f_4410:csi_scm",(void*)f_4410},
{"f_4038:csi_scm",(void*)f_4038},
{"f_4041:csi_scm",(void*)f_4041},
{"f_4341:csi_scm",(void*)f_4341},
{"f_4344:csi_scm",(void*)f_4344},
{"f_4044:csi_scm",(void*)f_4044},
{"f_4329:csi_scm",(void*)f_4329},
{"f_4332:csi_scm",(void*)f_4332},
{"f_4047:csi_scm",(void*)f_4047},
{"f_4308:csi_scm",(void*)f_4308},
{"f_4311:csi_scm",(void*)f_4311},
{"f_4314:csi_scm",(void*)f_4314},
{"f_4317:csi_scm",(void*)f_4317},
{"f_4320:csi_scm",(void*)f_4320},
{"f_4050:csi_scm",(void*)f_4050},
{"f_4299:csi_scm",(void*)f_4299},
{"f_3904:csi_scm",(void*)f_3904},
{"f_3910:csi_scm",(void*)f_3910},
{"f_3932:csi_scm",(void*)f_3932},
{"f_3916:csi_scm",(void*)f_3916},
{"f_3919:csi_scm",(void*)f_3919},
{"f_3925:csi_scm",(void*)f_3925},
{"f_4053:csi_scm",(void*)f_4053},
{"f_4058:csi_scm",(void*)f_4058},
{"f_4271:csi_scm",(void*)f_4271},
{"f_4275:csi_scm",(void*)f_4275},
{"f_4278:csi_scm",(void*)f_4278},
{"f_4218:csi_scm",(void*)f_4218},
{"f_4239:csi_scm",(void*)f_4239},
{"f_4250:csi_scm",(void*)f_4250},
{"f_4229:csi_scm",(void*)f_4229},
{"f_4237:csi_scm",(void*)f_4237},
{"f_4208:csi_scm",(void*)f_4208},
{"f_4198:csi_scm",(void*)f_4198},
{"f_4182:csi_scm",(void*)f_4182},
{"f_4172:csi_scm",(void*)f_4172},
{"f_4152:csi_scm",(void*)f_4152},
{"f_4136:csi_scm",(void*)f_4136},
{"f_4112:csi_scm",(void*)f_4112},
{"f_4083:csi_scm",(void*)f_4083},
{"f_4071:csi_scm",(void*)f_4071},
{"f_3937:csi_scm",(void*)f_3937},
{"f_3984:csi_scm",(void*)f_3984},
{"f_3941:csi_scm",(void*)f_3941},
{"f_3944:csi_scm",(void*)f_3944},
{"f_3951:csi_scm",(void*)f_3951},
{"f_3953:csi_scm",(void*)f_3953},
{"f_3976:csi_scm",(void*)f_3976},
{"f_3974:csi_scm",(void*)f_3974},
{"f_3963:csi_scm",(void*)f_3963},
{"f_3970:csi_scm",(void*)f_3970},
{"f_3857:csi_scm",(void*)f_3857},
{"f_3863:csi_scm",(void*)f_3863},
{"f_3890:csi_scm",(void*)f_3890},
{"f_3679:csi_scm",(void*)f_3679},
{"f_3685:csi_scm",(void*)f_3685},
{"f_3707:csi_scm",(void*)f_3707},
{"f_3764:csi_scm",(void*)f_3764},
{"f_3757:csi_scm",(void*)f_3757},
{"f_3723:csi_scm",(void*)f_3723},
{"f_3746:csi_scm",(void*)f_3746},
{"f_3736:csi_scm",(void*)f_3736},
{"f_3740:csi_scm",(void*)f_3740},
{"f_3796:csi_scm",(void*)f_3796},
{"f_3622:csi_scm",(void*)f_3622},
{"f_3628:csi_scm",(void*)f_3628},
{"f_3640:csi_scm",(void*)f_3640},
{"f_3563:csi_scm",(void*)f_3563},
{"f_3567:csi_scm",(void*)f_3567},
{"f_3572:csi_scm",(void*)f_3572},
{"f_3601:csi_scm",(void*)f_3601},
{"f_3588:csi_scm",(void*)f_3588},
{"f_3525:csi_scm",(void*)f_3525},
{"f_3531:csi_scm",(void*)f_3531},
{"f_3547:csi_scm",(void*)f_3547},
{"f_3557:csi_scm",(void*)f_3557},
{"f_3316:csi_scm",(void*)f_3316},
{"f_3348:csi_scm",(void*)f_3348},
{"f_3523:csi_scm",(void*)f_3523},
{"f_3358:csi_scm",(void*)f_3358},
{"f_3361:csi_scm",(void*)f_3361},
{"f_3433:csi_scm",(void*)f_3433},
{"f_3494:csi_scm",(void*)f_3494},
{"f_3516:csi_scm",(void*)f_3516},
{"f_3512:csi_scm",(void*)f_3512},
{"f_3497:csi_scm",(void*)f_3497},
{"f_3452:csi_scm",(void*)f_3452},
{"f_3470:csi_scm",(void*)f_3470},
{"f_3480:csi_scm",(void*)f_3480},
{"f_3364:csi_scm",(void*)f_3364},
{"f_3367:csi_scm",(void*)f_3367},
{"f_3382:csi_scm",(void*)f_3382},
{"f_3395:csi_scm",(void*)f_3395},
{"f_3398:csi_scm",(void*)f_3398},
{"f_3370:csi_scm",(void*)f_3370},
{"f_3373:csi_scm",(void*)f_3373},
{"f_3319:csi_scm",(void*)f_3319},
{"f_3323:csi_scm",(void*)f_3323},
{"f_3339:csi_scm",(void*)f_3339},
{"f_3155:csi_scm",(void*)f_3155},
{"f_3268:csi_scm",(void*)f_3268},
{"f_3263:csi_scm",(void*)f_3263},
{"f_3157:csi_scm",(void*)f_3157},
{"f_3182:csi_scm",(void*)f_3182},
{"f_3225:csi_scm",(void*)f_3225},
{"f_3235:csi_scm",(void*)f_3235},
{"f_3206:csi_scm",(void*)f_3206},
{"f_3189:csi_scm",(void*)f_3189},
{"f_3160:csi_scm",(void*)f_3160},
{"f_3146:csi_scm",(void*)f_3146},
{"f_3150:csi_scm",(void*)f_3150},
{"f_2316:csi_scm",(void*)f_2316},
{"f_2320:csi_scm",(void*)f_2320},
{"f_3125:csi_scm",(void*)f_3125},
{"f_2448:csi_scm",(void*)f_2448},
{"f_2547:csi_scm",(void*)f_2547},
{"f_2755:csi_scm",(void*)f_2755},
{"f_2783:csi_scm",(void*)f_2783},
{"f_2792:csi_scm",(void*)f_2792},
{"f_2886:csi_scm",(void*)f_2886},
{"f_3036:csi_scm",(void*)f_3036},
{"f_3051:csi_scm",(void*)f_3051},
{"f_3085:csi_scm",(void*)f_3085},
{"f_3074:csi_scm",(void*)f_3074},
{"f_3070:csi_scm",(void*)f_3070},
{"f_2953:csi_scm",(void*)f_2953},
{"f_2962:csi_scm",(void*)f_2962},
{"f_2975:csi_scm",(void*)f_2975},
{"f_2991:csi_scm",(void*)f_2991},
{"f_3026:csi_scm",(void*)f_3026},
{"f_3018:csi_scm",(void*)f_3018},
{"f_3001:csi_scm",(void*)f_3001},
{"f_2978:csi_scm",(void*)f_2978},
{"f_2917:csi_scm",(void*)f_2917},
{"f_2920:csi_scm",(void*)f_2920},
{"f_2925:csi_scm",(void*)f_2925},
{"f_2905:csi_scm",(void*)f_2905},
{"f_2892:csi_scm",(void*)f_2892},
{"f_2880:csi_scm",(void*)f_2880},
{"f_2799:csi_scm",(void*)f_2799},
{"f_2810:csi_scm",(void*)f_2810},
{"f_2774:csi_scm",(void*)f_2774},
{"f_2715:csi_scm",(void*)f_2715},
{"f_2729:csi_scm",(void*)f_2729},
{"f_2725:csi_scm",(void*)f_2725},
{"f_2671:csi_scm",(void*)f_2671},
{"f_2577:csi_scm",(void*)f_2577},
{"f_2651:csi_scm",(void*)f_2651},
{"f_2580:csi_scm",(void*)f_2580},
{"f_2648:csi_scm",(void*)f_2648},
{"f_2645:csi_scm",(void*)f_2645},
{"f_2583:csi_scm",(void*)f_2583},
{"f_2595:csi_scm",(void*)f_2595},
{"f_2600:csi_scm",(void*)f_2600},
{"f_2610:csi_scm",(void*)f_2610},
{"f_2625:csi_scm",(void*)f_2625},
{"f_2613:csi_scm",(void*)f_2613},
{"f_2616:csi_scm",(void*)f_2616},
{"f_2517:csi_scm",(void*)f_2517},
{"f_2523:csi_scm",(void*)f_2523},
{"f_2451:csi_scm",(void*)f_2451},
{"f_2322:csi_scm",(void*)f_2322},
{"f_2445:csi_scm",(void*)f_2445},
{"f_2329:csi_scm",(void*)f_2329},
{"f_2334:csi_scm",(void*)f_2334},
{"f_2357:csi_scm",(void*)f_2357},
{"f_2366:csi_scm",(void*)f_2366},
{"f_2430:csi_scm",(void*)f_2430},
{"f_2376:csi_scm",(void*)f_2376},
{"f_2379:csi_scm",(void*)f_2379},
{"f_2088:csi_scm",(void*)f_2088},
{"f_2096:csi_scm",(void*)f_2096},
{"f_2098:csi_scm",(void*)f_2098},
{"f_2102:csi_scm",(void*)f_2102},
{"f_2105:csi_scm",(void*)f_2105},
{"f_2108:csi_scm",(void*)f_2108},
{"f_2125:csi_scm",(void*)f_2125},
{"f_2300:csi_scm",(void*)f_2300},
{"f_2296:csi_scm",(void*)f_2296},
{"f_2229:csi_scm",(void*)f_2229},
{"f_2231:csi_scm",(void*)f_2231},
{"f_2244:csi_scm",(void*)f_2244},
{"f_2256:csi_scm",(void*)f_2256},
{"f_2280:csi_scm",(void*)f_2280},
{"f_2269:csi_scm",(void*)f_2269},
{"f_2247:csi_scm",(void*)f_2247},
{"f_2128:csi_scm",(void*)f_2128},
{"f_2156:csi_scm",(void*)f_2156},
{"f_2164:csi_scm",(void*)f_2164},
{"f_2168:csi_scm",(void*)f_2168},
{"f_2172:csi_scm",(void*)f_2172},
{"f_2176:csi_scm",(void*)f_2176},
{"f_2180:csi_scm",(void*)f_2180},
{"f_2131:csi_scm",(void*)f_2131},
{"f_2134:csi_scm",(void*)f_2134},
{"f_2137:csi_scm",(void*)f_2137},
{"f_2140:csi_scm",(void*)f_2140},
{"f_2110:csi_scm",(void*)f_2110},
{"f_2118:csi_scm",(void*)f_2118},
{"f_1576:csi_scm",(void*)f_1576},
{"f_1592:csi_scm",(void*)f_1592},
{"f_1952:csi_scm",(void*)f_1952},
{"f_1956:csi_scm",(void*)f_1956},
{"f_1946:csi_scm",(void*)f_1946},
{"f_1598:csi_scm",(void*)f_1598},
{"f_1932:csi_scm",(void*)f_1932},
{"f_1908:csi_scm",(void*)f_1908},
{"f_1916:csi_scm",(void*)f_1916},
{"f_1911:csi_scm",(void*)f_1911},
{"f_1889:csi_scm",(void*)f_1889},
{"f_1892:csi_scm",(void*)f_1892},
{"f_1895:csi_scm",(void*)f_1895},
{"f_1873:csi_scm",(void*)f_1873},
{"f_1821:csi_scm",(void*)f_1821},
{"f_1854:csi_scm",(void*)f_1854},
{"f_1858:csi_scm",(void*)f_1858},
{"f_1826:csi_scm",(void*)f_1826},
{"f_1830:csi_scm",(void*)f_1830},
{"f_1841:csi_scm",(void*)f_1841},
{"f_1852:csi_scm",(void*)f_1852},
{"f_1845:csi_scm",(void*)f_1845},
{"f_1835:csi_scm",(void*)f_1835},
{"f_1812:csi_scm",(void*)f_1812},
{"f_1771:csi_scm",(void*)f_1771},
{"f_1779:csi_scm",(void*)f_1779},
{"f_1801:csi_scm",(void*)f_1801},
{"f_1805:csi_scm",(void*)f_1805},
{"f_1792:csi_scm",(void*)f_1792},
{"f_1774:csi_scm",(void*)f_1774},
{"f_1762:csi_scm",(void*)f_1762},
{"f_1729:csi_scm",(void*)f_1729},
{"f_1737:csi_scm",(void*)f_1737},
{"f_1747:csi_scm",(void*)f_1747},
{"f_1732:csi_scm",(void*)f_1732},
{"f_1690:csi_scm",(void*)f_1690},
{"f_1693:csi_scm",(void*)f_1693},
{"f_1696:csi_scm",(void*)f_1696},
{"f_1699:csi_scm",(void*)f_1699},
{"f_1675:csi_scm",(void*)f_1675},
{"f_1678:csi_scm",(void*)f_1678},
{"f_1660:csi_scm",(void*)f_1660},
{"f_1663:csi_scm",(void*)f_1663},
{"f_1642:csi_scm",(void*)f_1642},
{"f_1645:csi_scm",(void*)f_1645},
{"f_1648:csi_scm",(void*)f_1648},
{"f_1619:csi_scm",(void*)f_1619},
{"f_1633:csi_scm",(void*)f_1633},
{"f_1629:csi_scm",(void*)f_1629},
{"f_1622:csi_scm",(void*)f_1622},
{"f_1604:csi_scm",(void*)f_1604},
{"f_1535:csi_scm",(void*)f_1535},
{"f_1539:csi_scm",(void*)f_1539},
{"f_1519:csi_scm",(void*)f_1519},
{"f_1526:csi_scm",(void*)f_1526},
{"f_1506:csi_scm",(void*)f_1506},
{"f_1479:csi_scm",(void*)f_1479},
{"f_1440:csi_scm",(void*)f_1440},
{"f_1464:csi_scm",(void*)f_1464},
{"f_1450:csi_scm",(void*)f_1450},
{"f_1334:csi_scm",(void*)f_1334},
{"f_1338:csi_scm",(void*)f_1338},
{"f_1379:csi_scm",(void*)f_1379},
{"f_1385:csi_scm",(void*)f_1385},
{"f_1392:csi_scm",(void*)f_1392},
{"f_1394:csi_scm",(void*)f_1394},
{"f_1421:csi_scm",(void*)f_1421},
{"f_1404:csi_scm",(void*)f_1404},
{"f_1407:csi_scm",(void*)f_1407},
{"f_1362:csi_scm",(void*)f_1362},
{"f_1376:csi_scm",(void*)f_1376},
{"f_1372:csi_scm",(void*)f_1372},
{"f_1313:csi_scm",(void*)f_1313},
{"f_1286:csi_scm",(void*)f_1286},
{"f_1293:csi_scm",(void*)f_1293},
{"f_1296:csi_scm",(void*)f_1296},
{"f_1302:csi_scm",(void*)f_1302},
{"f_1236:csi_scm",(void*)f_1236},
{"f_1240:csi_scm",(void*)f_1240},
{"f_1249:csi_scm",(void*)f_1249},
{"f_1224:csi_scm",(void*)f_1224},
{"f_1210:csi_scm",(void*)f_1210},
{"f_1222:csi_scm",(void*)f_1222},
{"f_1177:csi_scm",(void*)f_1177},
{"f_1198:csi_scm",(void*)f_1198},
{"f_1161:csi_scm",(void*)f_1161},
{"f_1165:csi_scm",(void*)f_1165},
{"f_1168:csi_scm",(void*)f_1168},
{"f_1175:csi_scm",(void*)f_1175},
{"f_1133:csi_scm",(void*)f_1133},
{"f_1137:csi_scm",(void*)f_1137},
{"f_1147:csi_scm",(void*)f_1147},
{"f_1140:csi_scm",(void*)f_1140},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
