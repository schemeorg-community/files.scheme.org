/* Generated from chicken-bug.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: chicken-bug.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -output-file chicken-bug.c
   used units: library eval data_structures ports extras srfi_69 srfi_13 posix tcp data_structures utils extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[150];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_297)
static void C_ccall f_297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_300)
static void C_ccall f_300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_303)
static void C_ccall f_303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_306)
static void C_ccall f_306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_309)
static void C_ccall f_309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_312)
static void C_ccall f_312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_315)
static void C_ccall f_315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_318)
static void C_ccall f_318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_321)
static void C_ccall f_321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_324)
static void C_ccall f_324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_327)
static void C_ccall f_327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_330)
static void C_ccall f_330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1223)
static void C_ccall f_1223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1235)
static void C_fcall f_1235(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_ccall f_1330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_ccall f_1322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1215)
static void C_ccall f_1215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1170)
static void C_ccall f_1170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1137)
static void C_ccall f_1137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1091)
static void C_ccall f_1091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1098)
static void C_ccall f_1098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_841)
static void C_ccall f_841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_852)
static void C_fcall f_852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_856)
static void C_ccall f_856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_863)
static void C_fcall f_863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_871)
static void C_ccall f_871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_891)
static void C_ccall f_891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_875)
static void C_ccall f_875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_883)
static void C_ccall f_883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_879)
static void C_ccall f_879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_800)
static void C_ccall f_800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_818)
static void C_ccall f_818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_813)
static void C_ccall f_813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_660)
static void C_ccall f_660(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_741)
static void C_fcall f_741(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_798)
static void C_ccall f_798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_794)
static void C_ccall f_794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_773)
static void C_ccall f_773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_769)
static void C_ccall f_769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_754)
static void C_ccall f_754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_664)
static void C_ccall f_664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_739)
static void C_ccall f_739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_735)
static void C_ccall f_735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_667)
static void C_fcall f_667(C_word t0,C_word t1) C_noret;
C_noret_decl(f_670)
static void C_ccall f_670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_673)
static void C_ccall f_673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_723)
static void C_ccall f_723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_702)
static void C_ccall f_702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_708)
static void C_ccall f_708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_712)
static void C_ccall f_712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_706)
static void C_ccall f_706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_688)
static void C_ccall f_688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_641)
static void C_ccall f_641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_645)
static void C_ccall f_645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_594)
static void C_ccall f_594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_639)
static void C_ccall f_639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_632)
static void C_ccall f_632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_598)
static void C_ccall f_598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_603)
static void C_fcall f_603(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_607)
static void C_ccall f_607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_585)
static void C_ccall f_585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_589)
static void C_ccall f_589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_346)
static void C_ccall f_346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_350)
static void C_ccall f_350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_353)
static void C_ccall f_353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_583)
static void C_ccall f_583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_579)
static void C_ccall f_579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_356)
static void C_ccall f_356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_359)
static void C_ccall f_359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_575)
static void C_ccall f_575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_362)
static void C_ccall f_362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_365)
static void C_ccall f_365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_368)
static void C_ccall f_368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_371)
static void C_ccall f_371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_571)
static void C_ccall f_571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_374)
static void C_ccall f_374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_567)
static void C_ccall f_567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_377)
static void C_ccall f_377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_559)
static void C_ccall f_559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_383)
static void C_ccall f_383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_555)
static void C_ccall f_555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_551)
static void C_ccall f_551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_ccall f_404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_547)
static void C_ccall f_547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_543)
static void C_ccall f_543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_473)
static void C_ccall f_473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_475)
static void C_fcall f_475(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_488)
static void C_ccall f_488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_500)
static void C_fcall f_500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_513)
static void C_ccall f_513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_527)
static void C_ccall f_527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_516)
static void C_ccall f_516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_491)
static void C_ccall f_491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_407)
static void C_ccall f_407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_469)
static void C_ccall f_469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_455)
static void C_ccall f_455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_457)
static void C_ccall f_457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_416)
static void C_ccall f_416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_451)
static void C_ccall f_451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_425)
static void C_ccall f_425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_428)
static void C_ccall f_428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_433)
static void C_ccall f_433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_441)
static void C_ccall f_441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_419)
static void C_ccall f_419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_336)
static void C_ccall f_336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_344)
static void C_ccall f_344(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1235)
static void C_fcall trf_1235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1235(t0,t1,t2);}

C_noret_decl(trf_852)
static void C_fcall trf_852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_852(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_852(t0,t1);}

C_noret_decl(trf_863)
static void C_fcall trf_863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_863(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_863(t0,t1);}

C_noret_decl(trf_741)
static void C_fcall trf_741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_741(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_741(t0,t1,t2);}

C_noret_decl(trf_667)
static void C_fcall trf_667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_667(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_667(t0,t1);}

C_noret_decl(trf_603)
static void C_fcall trf_603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_603(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_603(t0,t1,t2);}

C_noret_decl(trf_475)
static void C_fcall trf_475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_475(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_475(t0,t1,t2);}

C_noret_decl(trf_500)
static void C_fcall trf_500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_500(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(680)){
C_save(t1);
C_rereclaim2(680*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,150);
lf[0]=C_h_intern(&lf[0],7,"user-id");
lf[1]=C_h_intern(&lf[1],16,"user-information");
lf[2]=C_h_intern(&lf[2],15,"current-user-id");
lf[3]=C_h_intern(&lf[3],12,"collect-info");
lf[4]=C_h_intern(&lf[4],19,"\003sysstandard-output");
lf[5]=C_h_intern(&lf[5],7,"newline");
lf[6]=C_h_intern(&lf[6],7,"display");
lf[7]=C_h_intern(&lf[7],8,"read-all");
lf[8]=C_h_intern(&lf[8],20,"with-input-from-pipe");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\013gcc -v 2>&1");
lf[10]=C_h_intern(&lf[10],5,"print");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\0000CC seems to be gcc, trying to obtain version...\012");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\003gcc");
lf[13]=C_h_intern(&lf[13],8,"feature\077");
lf[14]=C_h_intern(&lf[14],4,"unix");
lf[15]=C_h_intern(&lf[15],17,"\003syspeek-c-string");
lf[16]=C_h_intern(&lf[16],20,"with-input-from-file");
lf[17]=C_h_intern(&lf[17],13,"make-pathname");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-config.h");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\024\012\012chicken-config.h:\012");
lf[20]=C_h_intern(&lf[20],11,"make-string");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[22]=C_h_intern(&lf[22],4,"chop");
lf[23]=C_h_intern(&lf[23],4,"sort");
lf[24]=C_h_intern(&lf[24],8,"string<\077");
lf[25]=C_h_intern(&lf[25],7,"\003sysmap");
lf[26]=C_h_intern(&lf[26],15,"keyword->string");
lf[27]=C_h_intern(&lf[27],12,"\003sysfeatures");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[29]=C_h_intern(&lf[29],19,"\003syswrite-char/port");
lf[30]=C_h_intern(&lf[30],5,"write");
lf[31]=C_h_intern(&lf[31],21,"\003sysinclude-pathnames");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\016Include path:\011");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\020Home directory:\011");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[35]=C_h_intern(&lf[35],12,"chicken-home");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN version is:\012");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[38]=C_h_intern(&lf[38],15,"chicken-version");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\021\011build platform:\011");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[41]=C_h_intern(&lf[41],14,"build-platform");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\023\011software version:\011");
lf[43]=C_h_intern(&lf[43],16,"software-version");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\020\011software type:\011");
lf[45]=C_h_intern(&lf[45],13,"software-type");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\017\011machine type:\011");
lf[47]=C_h_intern(&lf[47],12,"machine-type");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\022Host information:\012");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\022User information:\011");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\006Date:\011");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[52]=C_h_intern(&lf[52],15,"seconds->string");
lf[53]=C_h_intern(&lf[53],15,"current-seconds");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\0002This is a bug report generated by chicken-bug(1).\012");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\0004\012--------------------------------------------------\012");
lf[56]=C_h_intern(&lf[56],5,"usage");
lf[57]=C_h_intern(&lf[57],4,"exit");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\0017usage: chicken-bug [FILENAME ...]\012\012  -help  -h            show this message"
"\012  -to-stdout           write bug report to standard output\012  -                 "
"   read description from standard input\012\012Generates a bug report file from user i"
"nput or alternatively\012from the contents of files given on the command line.\012");
lf[59]=C_h_intern(&lf[59],10,"user-input");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[61]=C_h_intern(&lf[61],26,"string-concatenate-reverse");
lf[62]=C_h_intern(&lf[62],9,"read-line");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\001jThis is the CHICKEN bug report generator. Please enter a detailed\012descripti"
"on of the problem you have encountered and enter CTRL-D (EOF)\012or a line consisti"
"ng only of \042.\042 to finish. Press CTRL-C to abort the program. You can\012also pass t"
"he description from a file (just abort now and re-invoke\012\042chicken-bug\042 with one "
"or more input files given on the command-line)\012");
lf[64]=C_h_intern(&lf[64],13,"\003systty-port\077");
lf[65]=C_h_intern(&lf[65],18,"current-input-port");
lf[66]=C_h_intern(&lf[66],7,"justify");
lf[67]=C_h_intern(&lf[67],13,"string-append");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[69]=C_h_intern(&lf[69],4,"main");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[71]=C_h_intern(&lf[71],8,"try-mail");
lf[72]=C_h_intern(&lf[72],21,"with-output-to-string");
lf[73]=C_h_intern(&lf[73],12,"mail-headers");
lf[74]=C_h_intern(&lf[74],7,"sprintf");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-bug-report.~a-~a-~a");
lf[76]=C_h_intern(&lf[76],19,"seconds->local-time");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\017\012\012User input:\012\012");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\012-to-stdout");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\016\012\012File added: ");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000!one of the following addresses:\012\012");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000Ochicken-janitors@nongnu.org\012chicken-hackers@nongnu.org\012chicken-users@nongnu"
".org");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000#\012A bug report has been written to `");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\025\047.  Please send it to");
lf[90]=C_h_intern(&lf[90],19,"with-output-to-file");
lf[91]=C_h_intern(&lf[91],9,"send-mail");
lf[92]=C_h_intern(&lf[92],13,"mail-date-str");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\006 +0000");
lf[97]=C_h_intern(&lf[97],10,"string-pad");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jan ");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\005 Feb ");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\005 Mar ");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\005 Apr ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\005 May ");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jun ");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jul ");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\005 Aug ");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\005 Sep ");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\005 Oct ");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\005 Nov ");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\005 Dec ");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\005Sun, ");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\005Mon, ");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\005Tue, ");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\005Wed, ");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\005Thu, ");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\005Fri, ");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\005Sat, ");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\006Date: ");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000;From: \042chicken-bug user\042 <chicken-bug-command@callcc.org>\015\012");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\0006To: \042Chicken Janitors\042 <chicken-janitors@nongnu.org>\015\012");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000)Subject: Automated chicken-bug output -- ");
lf[122]=C_h_intern(&lf[122],17,"seconds->utc-time");
lf[123]=C_h_intern(&lf[123],9,"mail-read");
lf[124]=C_h_intern(&lf[124],9,"substring");
lf[125]=C_h_intern(&lf[125],9,"condition");
lf[126]=C_h_intern(&lf[126],17,"close-output-port");
lf[127]=C_h_intern(&lf[127],16,"close-input-port");
lf[128]=C_h_intern(&lf[128],22,"with-exception-handler");
lf[129]=C_h_intern(&lf[129],30,"call-with-current-continuation");
lf[130]=C_h_intern(&lf[130],10,"mail-write");
lf[131]=C_h_intern(&lf[131],10,"mail-check");
lf[132]=C_h_intern(&lf[132],4,"add1");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\010 failed.");
lf[134]=C_h_intern(&lf[134],11,"tcp-connect");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000Vok.\012\012Bug report successfully mailed to the Chicken maintainers.\012Thank you v"
"ery much!\012\012");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\004QUIT");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\004\015\012\015\012");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\005\015\012.\015\012");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\006DATA\015\012");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\047RCPT TO:<chicken-janitors@nongnu.org>\015\012");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000,MAIL FROM:<chicken-bug-command@callcc.org>\015\012");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\021HELO callcc.org\015\012");
lf[143]=C_h_intern(&lf[143],6,"print*");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\016connecting to ");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\007, try #");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[147]=C_h_intern(&lf[147],7,"call/cc");
lf[148]=C_h_intern(&lf[148],25,"\003sysimplicit-exit-handler");
lf[149]=C_h_intern(&lf[149],22,"command-line-arguments");
C_register_lf2(lf,150,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_297,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k295 */
static void C_ccall f_297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k298 in k295 */
static void C_ccall f_300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k301 in k298 in k295 */
static void C_ccall f_303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k304 in k301 in k298 in k295 */
static void C_ccall f_306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_330,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! user-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_336,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! collect-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_346,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[56]+1 /* (set! usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_585,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[59]+1 /* (set! user-input ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_594,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[66]+1 /* (set! justify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_641,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[69]+1 /* (set! main ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_660,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[71]+1 /* (set! try-mail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_800,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[92]+1 /* (set! mail-date-str ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_841,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[73]+1 /* (set! mail-headers ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1029,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[123]+1 /* (set! mail-read ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1047,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[130]+1 /* (set! mail-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1133,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[131]+1 /* (set! mail-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1202,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[91]+1 /* (set! send-mail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1223,tmp=(C_word)a,a+=2,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1347,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 271  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[149]))(2,*((C_word*)lf[149]+1),t16);}

/* k1345 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 271  main */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],t1);}

/* k1335 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[148]))(2,*((C_word*)lf[148]+1),t3);}

/* k1341 in k1335 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1338 in k1335 in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1223,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1229,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 249  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[147]+1)))(3,*((C_word*)lf[147]+1),t1,t6);}

/* a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1229,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_1235(t6,t1,C_fix(1));}

/* doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_fcall f_1235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1235,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(3)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* chicken-bug.scm: 253  print* */
((C_proc7)C_retrieve_proc(*((C_word*)lf[143]+1)))(7,*((C_word*)lf[143]+1),t3,lf[144],((C_word*)t0)[6],lf[145],t2,lf[146]);}}

/* k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1248,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1260,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1266,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-bug.scm: 256  call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[129]+1)))(3,*((C_word*)lf[129]+1),t1,t4);}

/* a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1272,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1334,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 258  mail-read */
((C_proc4)C_retrieve_symbol_proc(lf[123]))(4,*((C_word*)lf[123]+1),t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k1332 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 258  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[131]))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(220),((C_word*)t0)[2]);}

/* k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1330,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 259  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[142]);}

/* k1328 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 259  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[131]))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 260  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[141]);}

/* k1324 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 260  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[131]))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1280 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1322,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 261  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[140]);}

/* k1320 in k1280 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 261  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[131]))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1283 in k1280 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 262  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[139]);}

/* k1316 in k1283 in k1280 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 262  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[131]))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(354),((C_word*)t0)[2]);}

/* k1286 in k1283 in k1280 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1310,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 263  string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[67]+1)))(7,*((C_word*)lf[67]+1),t4,((C_word*)t0)[4],((C_word*)t0)[3],lf[137],((C_word*)t0)[2],lf[138]);}

/* k1312 in k1286 in k1283 in k1280 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 263  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1308 in k1286 in k1283 in k1280 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 263  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[131]))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 264  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t2,lf[136],((C_word*)t0)[3]);}

/* k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 265  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t2,((C_word*)t0)[2]);}

/* k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 266  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 267  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[135]);}

/* k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in a1271 in a1265 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 268  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* a1259 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1260,2,t0,t1);}
/* chicken-bug.scm: 255  tcp-connect */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t1,((C_word*)t0)[2],C_fix(25));}

/* k1246 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 269  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[133]);}

/* k1249 in k1246 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1258,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 251  add1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[132]+1)))(3,*((C_word*)lf[132]+1),t2,((C_word*)t0)[2]);}

/* k1256 in k1249 in k1246 in k1243 in doloop237 in a1228 in send-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1235(t2,((C_word*)t0)[2],t1);}

/* mail-check in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1202,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t4)?(C_word)C_i_nequalp(t4,t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1212,a[2]=t3,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 244  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t8,t2);}}

/* k1210 in mail-check in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1215,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 245  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k1213 in k1210 in mail-check in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 246  k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* mail-write in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1133,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1137,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1146,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1148,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[129]+1)))(3,*((C_word*)lf[129]+1),t6,t7);}

/* a1147 in mail-write in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1148,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1154,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1178,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t1,t3,t4);}

/* a1177 in a1147 in mail-write in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1184,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1190,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1189 in a1177 in a1147 in mail-write in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1190r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1190r(t0,t1,t2);}}

static void C_ccall f_1190r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1196,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k203206 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1195 in a1189 in a1177 in a1147 in mail-write in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1196,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1183 in a1177 in a1147 in mail-write in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1184,2,t0,t1);}
/* chicken-bug.scm: 234  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1153 in a1147 in mail-write in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1154,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1160,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* k203206 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1159 in a1153 in a1147 in mail-write in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1160,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[125]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1167,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 235  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t4,((C_word*)t0)[2]);}

/* k1165 in a1159 in a1153 in a1147 in mail-write in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1170,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 235  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k1168 in k1165 in a1159 in a1153 in a1147 in mail-write in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1144 in mail-write in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1135 in mail-write in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 237  mail-read */
((C_proc4)C_retrieve_symbol_proc(lf[123]))(4,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1047,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1051,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1077,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1079,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[129]+1)))(3,*((C_word*)lf[129]+1),t5,t6);}

/* a1078 in mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1079,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1085,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1109,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t1,t3,t4);}

/* a1108 in a1078 in mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1115,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1121,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1120 in a1108 in a1078 in mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1121r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1121r(t0,t1,t2);}}

static void C_ccall f_1121r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1127,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k173176 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1126 in a1120 in a1108 in a1078 in mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1127,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1114 in a1108 in a1078 in mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1115,2,t0,t1);}
/* chicken-bug.scm: 225  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t1,((C_word*)t0)[2]);}

/* a1084 in a1078 in mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1085,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1091,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* k173176 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1090 in a1084 in a1078 in mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1091,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[125]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1098,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 226  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t4,((C_word*)t0)[2]);}

/* k1096 in a1090 in a1084 in a1078 in mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1101,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 226  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k1099 in k1096 in a1090 in a1084 in a1078 in mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1075 in mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1049 in mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1051,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(t1,C_fix(0));
if(C_truep((C_word)C_u_i_char_numericp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 229  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[124]+1)))(5,*((C_word*)lf[124]+1),t3,t1,C_fix(0),C_fix(3));}
else{
/* chicken-bug.scm: 230  mail-read */
((C_proc4)C_retrieve_symbol_proc(lf[123]))(4,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1065 in k1049 in mail-read in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 229  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* mail-headers in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1037,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1041,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1045,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 219  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t4);}

/* k1043 in mail-headers in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 219  seconds->utc-time */
((C_proc3)C_retrieve_symbol_proc(lf[122]))(3,*((C_word*)lf[122]+1),((C_word*)t0)[2],t1);}

/* k1039 in mail-headers in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 219  mail-date-str */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t1);}

/* k1035 in mail-headers in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 218  string-append */
((C_proc8)C_retrieve_proc(*((C_word*)lf[67]+1)))(8,*((C_word*)lf[67]+1),((C_word*)t0)[2],lf[117],t1,lf[118],lf[119],lf[120],lf[121]);}

/* mail-date-str in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_841,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_852,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_852(t5,lf[110]);
case C_fix(1):
t5=t4;
f_852(t5,lf[111]);
case C_fix(2):
t5=t4;
f_852(t5,lf[112]);
case C_fix(3):
t5=t4;
f_852(t5,lf[113]);
case C_fix(4):
t5=t4;
f_852(t5,lf[114]);
case C_fix(5):
t5=t4;
f_852(t5,lf[115]);
default:
t5=(C_word)C_eqp(t3,C_fix(6));
t6=t4;
f_852(t6,(C_truep(t5)?lf[116]:C_SCHEME_UNDEFINED));}}

/* k850 in mail-date-str in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_fcall f_852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_852,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_856,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_984,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(3));
/* chicken-bug.scm: 194  number->string */
C_number_to_string(3,0,t3,t4);}

/* k982 in k850 in mail-date-str in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 194  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[97]))(5,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k854 in k850 in mail-date-str in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_856,2,t0,t1);}
t2=(C_word)C_i_vector_ref(((C_word*)t0)[4],C_fix(4));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_863,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
switch(t2){
case C_fix(0):
t4=t3;
f_863(t4,lf[98]);
case C_fix(1):
t4=t3;
f_863(t4,lf[99]);
case C_fix(2):
t4=t3;
f_863(t4,lf[100]);
case C_fix(3):
t4=t3;
f_863(t4,lf[101]);
case C_fix(4):
t4=t3;
f_863(t4,lf[102]);
case C_fix(5):
t4=t3;
f_863(t4,lf[103]);
case C_fix(6):
t4=t3;
f_863(t4,lf[104]);
case C_fix(7):
t4=t3;
f_863(t4,lf[105]);
case C_fix(8):
t4=t3;
f_863(t4,lf[106]);
case C_fix(9):
t4=t3;
f_863(t4,lf[107]);
case C_fix(10):
t4=t3;
f_863(t4,lf[108]);
default:
t4=(C_word)C_eqp(t2,C_fix(11));
t5=t3;
f_863(t5,(C_truep(t4)?lf[109]:C_SCHEME_UNDEFINED));}}

/* k861 in k854 in k850 in mail-date-str in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_fcall f_863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_863,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_867,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(5));
t4=(C_word)C_a_i_plus(&a,2,C_fix(1900),t3);
/* chicken-bug.scm: 208  number->string */
C_number_to_string(3,0,t2,t4);}

/* k865 in k861 in k854 in k850 in mail-date-str in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_871,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_899,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(2));
/* chicken-bug.scm: 210  number->string */
C_number_to_string(3,0,t3,t4);}

/* k897 in k865 in k861 in k854 in k850 in mail-date-str in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 210  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[97]))(5,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k869 in k865 in k861 in k854 in k850 in mail-date-str in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_875,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_891,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(1));
/* chicken-bug.scm: 212  number->string */
C_number_to_string(3,0,t3,t4);}

/* k889 in k869 in k865 in k861 in k854 in k850 in mail-date-str in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 212  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[97]))(5,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k873 in k869 in k865 in k861 in k854 in k850 in mail-date-str in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_879,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_883,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* chicken-bug.scm: 214  number->string */
C_number_to_string(3,0,t3,t4);}

/* k881 in k873 in k869 in k865 in k861 in k854 in k850 in mail-date-str in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 214  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[97]))(5,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k877 in k873 in k869 in k865 in k861 in k854 in k850 in mail-date-str in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 185  string-append */
((C_proc13)C_retrieve_proc(*((C_word*)lf[67]+1)))(13,*((C_word*)lf[67]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[93],((C_word*)t0)[3],lf[94],((C_word*)t0)[2],lf[95],t1,lf[96]);}

/* try-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_800,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_810,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_818,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 175  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[90]))(4,*((C_word*)lf[90]+1),t6,t3,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_825,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_car(t2);
/* chicken-bug.scm: 181  send-mail */
((C_proc6)C_retrieve_symbol_proc(lf[91]))(6,*((C_word*)lf[91]+1),t6,t7,t5,t4,t3);}}

/* k823 in try-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-bug.scm: 182  try-mail */
((C_proc6)C_retrieve_symbol_proc(lf[71]))(6,*((C_word*)lf[71]+1),((C_word*)t0)[6],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a817 in try-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_818,2,t0,t1);}
/* chicken-bug.scm: 176  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t1,((C_word*)t0)[2]);}

/* k808 in try-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_813,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 179  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),t2,lf[88],((C_word*)t0)[2],lf[89]);}

/* k811 in k808 in try-mail in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 180  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[86],lf[87]);}

/* main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_660(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_660,3,t0,t1,t2);}
t3=lf[70];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_664,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_741,a[2]=t8,a[3]=t4,a[4]=t6,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_741(t13,t9,t2);}

/* loop108 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_fcall f_741(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_741,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_754,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_string_equal_p(lf[78],t3))){
t5=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_769,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_773,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 129  user-input */
((C_proc2)C_retrieve_symbol_proc(lf[59]))(2,*((C_word*)lf[59]+1),t7);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[80]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[81]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[82]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
/* chicken-bug.scm: 131  usage */
((C_proc3)C_retrieve_symbol_proc(lf[56]))(3,*((C_word*)lf[56]+1),t4,C_fix(0));}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[83],t3))){
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=t4;
f_754(2,t6,t5);}
else{
t5=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_794,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_798,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 140  read-all */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t7,t3);}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k796 in loop108 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 137  string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[67]+1)))(7,*((C_word*)lf[67]+1),((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],lf[84],((C_word*)t0)[2],lf[85],t1);}

/* k792 in loop108 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_754(2,t3,t2);}

/* k771 in loop108 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 129  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[67]+1)))(5,*((C_word*)lf[67]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[79],t1);}

/* k767 in loop108 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_754(2,t3,t2);}

/* k752 in loop108 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_741(t3,((C_word*)t0)[2],t2);}

/* k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_667,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=t2;
f_667(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_735,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_739,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 143  user-input */
((C_proc2)C_retrieve_symbol_proc(lf[59]))(2,*((C_word*)lf[59]+1),t4);}}

/* k737 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 143  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[67]+1)))(5,*((C_word*)lf[67]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[77],t1);}

/* k733 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_667(t3,t2);}

/* k665 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_fcall f_667(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_667,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 144  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t2);}

/* k668 in k665 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_731,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 145  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t3);}

/* k729 in k668 in k665 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 145  seconds->local-time */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k671 in k668 in k665 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_673,2,t0,t1);}
t2=(C_word)C_i_vector_ref(t1,C_fix(3));
t3=(C_word)C_i_vector_ref(t1,C_fix(4));
t4=(C_word)C_i_vector_ref(t1,C_fix(5));
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_688,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 151  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t5,((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1900),t4);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_723,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 155  justify */
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t7,t3);}}

/* k721 in k671 in k668 in k665 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_727,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 155  justify */
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k725 in k721 in k671 in k668 in k665 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 155  sprintf */
((C_proc6)C_retrieve_proc(*((C_word*)lf[74]+1)))(6,*((C_word*)lf[74]+1),((C_word*)t0)[4],lf[75],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k696 in k671 in k668 in k665 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_702,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 156  mail-headers */
((C_proc2)C_retrieve_symbol_proc(lf[73]))(2,*((C_word*)lf[73]+1),t2);}

/* k700 in k696 in k671 in k668 in k665 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_706,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_708,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 157  with-output-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),t2,t3);}

/* a707 in k700 in k696 in k671 in k668 in k665 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_712,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 159  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k710 in a707 in k700 in k696 in k671 in k668 in k665 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 160  collect-info */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k704 in k700 in k696 in k671 in k668 in k665 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 153  try-mail */
((C_proc6)C_retrieve_symbol_proc(lf[71]))(6,*((C_word*)lf[71]+1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k686 in k671 in k668 in k665 in k662 in main in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 152  collect-info */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* justify in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_641,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_645,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 116  number->string */
C_number_to_string(3,0,t3,t2);}

/* k643 in justify in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(1)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* chicken-bug.scm: 119  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[2],lf[68],t1);}}

/* user-input in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_598,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_632,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_639,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 99   current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[65]+1)))(2,*((C_word*)lf[65]+1),t4);}

/* k637 in user-input in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 99   ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),((C_word*)t0)[2],t1);}

/* k630 in user-input in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 100  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[63]);}
else{
t2=((C_word*)t0)[2];
f_598(2,t2,C_SCHEME_UNDEFINED);}}

/* k596 in user-input in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_598,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_603,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_603(t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k596 in user-input in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_fcall f_603(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_603,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_607,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 110  read-line */
((C_proc2)C_retrieve_symbol_proc(lf[62]))(2,*((C_word*)lf[62]+1),t3);}

/* k605 in loop in k596 in user-input in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_607,2,t0,t1);}
t2=(C_word)C_eofp(t1);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(lf[60],t1));
if(C_truep(t3)){
/* chicken-bug.scm: 112  string-concatenate-reverse */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* chicken-bug.scm: 113  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_603(t5,((C_word*)t0)[4],t4);}}

/* usage in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_585,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_589,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 84   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t3,lf[58]);}

/* k587 in usage in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 96   exit */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_350,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 50   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[55]);}

/* k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 51   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[54]);}

/* k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_356,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_579,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_583,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 52   current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t4);}

/* k581 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 52   seconds->string */
((C_proc3)C_retrieve_symbol_proc(lf[52]))(3,*((C_word*)lf[52]+1),((C_word*)t0)[2],t1);}

/* k577 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 52   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[50],t1,lf[51]);}

/* k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_356,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_359,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t3,lf[49],t2);}

/* k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_575,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 53   user-id */
((C_proc2)C_retrieve_symbol_proc(lf[0]))(2,*((C_word*)lf[0]+1),t3);}

/* k573 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[29]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_368,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[29]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_371,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 54   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[48]);}

/* k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_374,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_571,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 55   machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[47]))(2,*((C_word*)lf[47]+1),t3);}

/* k569 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 55   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[46],t1);}

/* k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_377,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_567,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 56   software-type */
((C_proc2)C_retrieve_symbol_proc(lf[45]))(2,*((C_word*)lf[45]+1),t3);}

/* k565 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 56   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[44],t1);}

/* k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_563,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 57   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[43]))(2,*((C_word*)lf[43]+1),t3);}

/* k561 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 57   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[42],t1);}

/* k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_559,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 58   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[41]))(2,*((C_word*)lf[41]+1),t3);}

/* k557 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 58   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[39],t1,lf[40]);}

/* k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_555,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 59   chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t3,C_SCHEME_TRUE);}

/* k553 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 59   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[36],t1,lf[37]);}

/* k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_551,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 60   chicken-home */
((C_proc2)C_retrieve_symbol_proc(lf[35]))(2,*((C_word*)lf[35]+1),t3);}

/* k549 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 60   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[33],t1,lf[34]);}

/* k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_392,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t3,lf[32],t2);}

/* k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),t2,C_retrieve(lf[31]),((C_word*)t0)[2]);}

/* k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[29]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[29]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 62   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[28]);}

/* k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_473,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_543,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_547,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[26]),C_retrieve(lf[27]));}

/* k545 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 70   sort */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1,*((C_word*)lf[24]+1));}

/* k541 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 70   chop */
((C_proc4)C_retrieve_symbol_proc(lf[22]))(4,*((C_word*)lf[22]+1),((C_word*)t0)[2],t1,C_fix(5));}

/* k471 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_473,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_475,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_475(t5,((C_word*)t0)[2],t1);}

/* loop30 in k471 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_fcall f_475(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_475,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_488,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 65   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t4,lf[21]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k486 in loop30 in k471 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_500,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_500(t6,t2,((C_word*)t0)[2]);}

/* loop38 in k486 in loop30 in k471 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_fcall f_500(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_500,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=*((C_word*)lf[4]+1);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_513,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k511 in loop38 in k486 in loop30 in k471 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_516,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_527,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_string_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* chicken-bug.scm: 68   make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[20]+1)))(4,*((C_word*)lf[20]+1),t3,t6,C_make_character(32));}

/* k525 in k511 in loop38 in k486 in loop30 in k471 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k514 in k511 in loop38 in k486 in loop30 in k471 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_500(t3,((C_word*)t0)[2],t2);}

/* k489 in k486 in loop30 in k471 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_475(t3,((C_word*)t0)[2],t2);}

/* k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_410,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 71   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[19]);}

/* k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_455,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_469,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}

/* k467 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 72   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),((C_word*)t0)[2],t1,lf[18]);}

/* k453 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_457,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 72   with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[16]))(4,*((C_word*)lf[16]+1),((C_word*)t0)[2],t1,t2);}

/* a456 in k453 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_465,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 74   read-all */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}

/* k463 in a456 in k453 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 74   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1);}

/* k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 75   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t2);}

/* k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_425,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_451,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k449 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(t1,lf[12]))){
/* chicken-bug.scm: 76   feature? */
((C_proc3)C_retrieve_symbol_proc(lf[13]))(3,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[14]);}
else{
t2=((C_word*)t0)[2];
f_425(2,t2,C_SCHEME_FALSE);}}

/* k423 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_425,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_428,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 77   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[11]);}
else{
t2=((C_word*)t0)[2];
f_419(2,t2,C_SCHEME_UNDEFINED);}}

/* k426 in k423 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_433,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 78   with-input-from-pipe */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[9],t2);}

/* a432 in k426 in k423 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_441,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 80   read-all */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}

/* k439 in a432 in k426 in k423 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 80   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1);}

/* k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in collect-info in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 81   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),((C_word*)t0)[2]);}

/* user-id in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_344,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 47   current-user-id */
((C_proc2)C_retrieve_symbol_proc(lf[2]))(2,*((C_word*)lf[2]+1),t2);}

/* k342 in user-id in k328 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 */
static void C_ccall f_344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 47   user-information */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[181] = {
{"toplevel:chicken_bug_scm",(void*)C_toplevel},
{"f_297:chicken_bug_scm",(void*)f_297},
{"f_300:chicken_bug_scm",(void*)f_300},
{"f_303:chicken_bug_scm",(void*)f_303},
{"f_306:chicken_bug_scm",(void*)f_306},
{"f_309:chicken_bug_scm",(void*)f_309},
{"f_312:chicken_bug_scm",(void*)f_312},
{"f_315:chicken_bug_scm",(void*)f_315},
{"f_318:chicken_bug_scm",(void*)f_318},
{"f_321:chicken_bug_scm",(void*)f_321},
{"f_324:chicken_bug_scm",(void*)f_324},
{"f_327:chicken_bug_scm",(void*)f_327},
{"f_330:chicken_bug_scm",(void*)f_330},
{"f_1347:chicken_bug_scm",(void*)f_1347},
{"f_1337:chicken_bug_scm",(void*)f_1337},
{"f_1343:chicken_bug_scm",(void*)f_1343},
{"f_1340:chicken_bug_scm",(void*)f_1340},
{"f_1223:chicken_bug_scm",(void*)f_1223},
{"f_1229:chicken_bug_scm",(void*)f_1229},
{"f_1235:chicken_bug_scm",(void*)f_1235},
{"f_1245:chicken_bug_scm",(void*)f_1245},
{"f_1266:chicken_bug_scm",(void*)f_1266},
{"f_1272:chicken_bug_scm",(void*)f_1272},
{"f_1334:chicken_bug_scm",(void*)f_1334},
{"f_1276:chicken_bug_scm",(void*)f_1276},
{"f_1330:chicken_bug_scm",(void*)f_1330},
{"f_1279:chicken_bug_scm",(void*)f_1279},
{"f_1326:chicken_bug_scm",(void*)f_1326},
{"f_1282:chicken_bug_scm",(void*)f_1282},
{"f_1322:chicken_bug_scm",(void*)f_1322},
{"f_1285:chicken_bug_scm",(void*)f_1285},
{"f_1318:chicken_bug_scm",(void*)f_1318},
{"f_1288:chicken_bug_scm",(void*)f_1288},
{"f_1314:chicken_bug_scm",(void*)f_1314},
{"f_1310:chicken_bug_scm",(void*)f_1310},
{"f_1291:chicken_bug_scm",(void*)f_1291},
{"f_1294:chicken_bug_scm",(void*)f_1294},
{"f_1297:chicken_bug_scm",(void*)f_1297},
{"f_1300:chicken_bug_scm",(void*)f_1300},
{"f_1303:chicken_bug_scm",(void*)f_1303},
{"f_1260:chicken_bug_scm",(void*)f_1260},
{"f_1248:chicken_bug_scm",(void*)f_1248},
{"f_1251:chicken_bug_scm",(void*)f_1251},
{"f_1258:chicken_bug_scm",(void*)f_1258},
{"f_1202:chicken_bug_scm",(void*)f_1202},
{"f_1212:chicken_bug_scm",(void*)f_1212},
{"f_1215:chicken_bug_scm",(void*)f_1215},
{"f_1133:chicken_bug_scm",(void*)f_1133},
{"f_1148:chicken_bug_scm",(void*)f_1148},
{"f_1178:chicken_bug_scm",(void*)f_1178},
{"f_1190:chicken_bug_scm",(void*)f_1190},
{"f_1196:chicken_bug_scm",(void*)f_1196},
{"f_1184:chicken_bug_scm",(void*)f_1184},
{"f_1154:chicken_bug_scm",(void*)f_1154},
{"f_1160:chicken_bug_scm",(void*)f_1160},
{"f_1167:chicken_bug_scm",(void*)f_1167},
{"f_1170:chicken_bug_scm",(void*)f_1170},
{"f_1146:chicken_bug_scm",(void*)f_1146},
{"f_1137:chicken_bug_scm",(void*)f_1137},
{"f_1047:chicken_bug_scm",(void*)f_1047},
{"f_1079:chicken_bug_scm",(void*)f_1079},
{"f_1109:chicken_bug_scm",(void*)f_1109},
{"f_1121:chicken_bug_scm",(void*)f_1121},
{"f_1127:chicken_bug_scm",(void*)f_1127},
{"f_1115:chicken_bug_scm",(void*)f_1115},
{"f_1085:chicken_bug_scm",(void*)f_1085},
{"f_1091:chicken_bug_scm",(void*)f_1091},
{"f_1098:chicken_bug_scm",(void*)f_1098},
{"f_1101:chicken_bug_scm",(void*)f_1101},
{"f_1077:chicken_bug_scm",(void*)f_1077},
{"f_1051:chicken_bug_scm",(void*)f_1051},
{"f_1067:chicken_bug_scm",(void*)f_1067},
{"f_1029:chicken_bug_scm",(void*)f_1029},
{"f_1045:chicken_bug_scm",(void*)f_1045},
{"f_1041:chicken_bug_scm",(void*)f_1041},
{"f_1037:chicken_bug_scm",(void*)f_1037},
{"f_841:chicken_bug_scm",(void*)f_841},
{"f_852:chicken_bug_scm",(void*)f_852},
{"f_984:chicken_bug_scm",(void*)f_984},
{"f_856:chicken_bug_scm",(void*)f_856},
{"f_863:chicken_bug_scm",(void*)f_863},
{"f_867:chicken_bug_scm",(void*)f_867},
{"f_899:chicken_bug_scm",(void*)f_899},
{"f_871:chicken_bug_scm",(void*)f_871},
{"f_891:chicken_bug_scm",(void*)f_891},
{"f_875:chicken_bug_scm",(void*)f_875},
{"f_883:chicken_bug_scm",(void*)f_883},
{"f_879:chicken_bug_scm",(void*)f_879},
{"f_800:chicken_bug_scm",(void*)f_800},
{"f_825:chicken_bug_scm",(void*)f_825},
{"f_818:chicken_bug_scm",(void*)f_818},
{"f_810:chicken_bug_scm",(void*)f_810},
{"f_813:chicken_bug_scm",(void*)f_813},
{"f_660:chicken_bug_scm",(void*)f_660},
{"f_741:chicken_bug_scm",(void*)f_741},
{"f_798:chicken_bug_scm",(void*)f_798},
{"f_794:chicken_bug_scm",(void*)f_794},
{"f_773:chicken_bug_scm",(void*)f_773},
{"f_769:chicken_bug_scm",(void*)f_769},
{"f_754:chicken_bug_scm",(void*)f_754},
{"f_664:chicken_bug_scm",(void*)f_664},
{"f_739:chicken_bug_scm",(void*)f_739},
{"f_735:chicken_bug_scm",(void*)f_735},
{"f_667:chicken_bug_scm",(void*)f_667},
{"f_670:chicken_bug_scm",(void*)f_670},
{"f_731:chicken_bug_scm",(void*)f_731},
{"f_673:chicken_bug_scm",(void*)f_673},
{"f_723:chicken_bug_scm",(void*)f_723},
{"f_727:chicken_bug_scm",(void*)f_727},
{"f_698:chicken_bug_scm",(void*)f_698},
{"f_702:chicken_bug_scm",(void*)f_702},
{"f_708:chicken_bug_scm",(void*)f_708},
{"f_712:chicken_bug_scm",(void*)f_712},
{"f_706:chicken_bug_scm",(void*)f_706},
{"f_688:chicken_bug_scm",(void*)f_688},
{"f_641:chicken_bug_scm",(void*)f_641},
{"f_645:chicken_bug_scm",(void*)f_645},
{"f_594:chicken_bug_scm",(void*)f_594},
{"f_639:chicken_bug_scm",(void*)f_639},
{"f_632:chicken_bug_scm",(void*)f_632},
{"f_598:chicken_bug_scm",(void*)f_598},
{"f_603:chicken_bug_scm",(void*)f_603},
{"f_607:chicken_bug_scm",(void*)f_607},
{"f_585:chicken_bug_scm",(void*)f_585},
{"f_589:chicken_bug_scm",(void*)f_589},
{"f_346:chicken_bug_scm",(void*)f_346},
{"f_350:chicken_bug_scm",(void*)f_350},
{"f_353:chicken_bug_scm",(void*)f_353},
{"f_583:chicken_bug_scm",(void*)f_583},
{"f_579:chicken_bug_scm",(void*)f_579},
{"f_356:chicken_bug_scm",(void*)f_356},
{"f_359:chicken_bug_scm",(void*)f_359},
{"f_575:chicken_bug_scm",(void*)f_575},
{"f_362:chicken_bug_scm",(void*)f_362},
{"f_365:chicken_bug_scm",(void*)f_365},
{"f_368:chicken_bug_scm",(void*)f_368},
{"f_371:chicken_bug_scm",(void*)f_371},
{"f_571:chicken_bug_scm",(void*)f_571},
{"f_374:chicken_bug_scm",(void*)f_374},
{"f_567:chicken_bug_scm",(void*)f_567},
{"f_377:chicken_bug_scm",(void*)f_377},
{"f_563:chicken_bug_scm",(void*)f_563},
{"f_380:chicken_bug_scm",(void*)f_380},
{"f_559:chicken_bug_scm",(void*)f_559},
{"f_383:chicken_bug_scm",(void*)f_383},
{"f_555:chicken_bug_scm",(void*)f_555},
{"f_386:chicken_bug_scm",(void*)f_386},
{"f_551:chicken_bug_scm",(void*)f_551},
{"f_389:chicken_bug_scm",(void*)f_389},
{"f_392:chicken_bug_scm",(void*)f_392},
{"f_395:chicken_bug_scm",(void*)f_395},
{"f_398:chicken_bug_scm",(void*)f_398},
{"f_401:chicken_bug_scm",(void*)f_401},
{"f_404:chicken_bug_scm",(void*)f_404},
{"f_547:chicken_bug_scm",(void*)f_547},
{"f_543:chicken_bug_scm",(void*)f_543},
{"f_473:chicken_bug_scm",(void*)f_473},
{"f_475:chicken_bug_scm",(void*)f_475},
{"f_488:chicken_bug_scm",(void*)f_488},
{"f_500:chicken_bug_scm",(void*)f_500},
{"f_513:chicken_bug_scm",(void*)f_513},
{"f_527:chicken_bug_scm",(void*)f_527},
{"f_516:chicken_bug_scm",(void*)f_516},
{"f_491:chicken_bug_scm",(void*)f_491},
{"f_407:chicken_bug_scm",(void*)f_407},
{"f_410:chicken_bug_scm",(void*)f_410},
{"f_469:chicken_bug_scm",(void*)f_469},
{"f_455:chicken_bug_scm",(void*)f_455},
{"f_457:chicken_bug_scm",(void*)f_457},
{"f_465:chicken_bug_scm",(void*)f_465},
{"f_413:chicken_bug_scm",(void*)f_413},
{"f_416:chicken_bug_scm",(void*)f_416},
{"f_451:chicken_bug_scm",(void*)f_451},
{"f_425:chicken_bug_scm",(void*)f_425},
{"f_428:chicken_bug_scm",(void*)f_428},
{"f_433:chicken_bug_scm",(void*)f_433},
{"f_441:chicken_bug_scm",(void*)f_441},
{"f_419:chicken_bug_scm",(void*)f_419},
{"f_336:chicken_bug_scm",(void*)f_336},
{"f_344:chicken_bug_scm",(void*)f_344},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
