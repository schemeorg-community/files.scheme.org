/* Generated from srfi-4.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:03
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: srfi-4.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file usrfi-4.c
   unit: srfi_4
*/

#include "chicken.h"

#define C_u8peek(b, i)         C_fix(((unsigned char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s8peek(b, i)         C_fix(((char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_u16peek(b, i)        C_fix(((unsigned short *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s16peek(b, i)        C_fix(((short *)C_data_pointer(b))[ C_unfix(i) ])
#ifdef C_SIXTY_FOUR
# define C_a_u32peek(ptr, d, b, i) C_fix(((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_fix(((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#else
# define C_a_u32peek(ptr, d, b, i) C_unsigned_int_to_num(ptr, ((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_int_to_num(ptr, ((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#endif
#define C_f32peek(b, i)        (C_temporary_flonum = ((float *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_f64peek(b, i)        (C_temporary_flonum = ((double *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_u8poke(b, i, x)      ((((unsigned char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s8poke(b, i, x)      ((((char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u16poke(b, i, x)     ((((unsigned short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s16poke(b, i, x)     ((((short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u32poke(b, i, x)     ((((C_u32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_unsigned_int(x)), C_SCHEME_UNDEFINED)
#define C_s32poke(b, i, x)     ((((C_s32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_int(x)), C_SCHEME_UNDEFINED)
#define C_f32poke(b, i, x)     ((((float *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_f64poke(b, i, x)     ((((double *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_copy_subvector(to, from, start_to, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to) + C_unfix(start_to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[174];
static double C_possibly_force_alignment;


/* from ext-free in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub196(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub196(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_ret:
#undef return

return C_r;}

/* from ext-alloc */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub191(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub191(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) return(C_SCHEME_FALSE);C_block_header(buf) = C_make_header(C_BYTEVECTOR_TYPE, bytes);return(buf);
C_ret:
#undef return

return C_r;}

C_noret_decl(C_srfi_4_toplevel)
C_externexport void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3505)
static void C_fcall f_3505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3500)
static void C_fcall f_3500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3438)
static void C_fcall f_3438(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_fcall f_3474(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_fcall f_3427(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3381)
static void C_fcall f_3381(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_fcall f_3376(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3331)
static void C_fcall f_3331(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_fcall f_3347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3269)
static void C_fcall f_3269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_fcall f_3264(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3255)
static void C_fcall f_3255(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3218)
static void C_fcall f_3218(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3233)
static void C_fcall f_3233(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3174)
static void C_ccall f_3174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3125)
static void C_fcall f_3125(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_fcall f_2746(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_fcall f_2717(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2699)
static void C_fcall f_2699(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_fcall f_2688(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2573)
static void C_fcall f_2573(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2584)
static void C_fcall f_2584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2455)
static void C_fcall f_2455(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_fcall f_2472(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2395)
static void C_fcall f_2395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_fcall f_2390(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2385)
static void C_fcall f_2385(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2333)
static void C_fcall f_2333(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2384)
static void C_ccall f_2384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_fcall f_2355(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static C_word C_fcall f_2360(C_word t0,C_word t1);
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2271)
static void C_fcall f_2271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_fcall f_2266(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2261)
static void C_fcall f_2261(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2209)
static void C_fcall f_2209(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_fcall f_2231(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static C_word C_fcall f_2236(C_word t0,C_word t1);
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2147)
static void C_fcall f_2147(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_fcall f_2142(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2137)
static void C_fcall f_2137(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2092)
static void C_fcall f_2092(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static C_word C_fcall f_2116(C_word t0,C_word t1);
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2030)
static void C_fcall f_2030(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_fcall f_2025(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2020)
static void C_fcall f_2020(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1975)
static void C_fcall f_1975(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static C_word C_fcall f_1999(C_word t0,C_word t1);
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1913)
static void C_fcall f_1913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_fcall f_1908(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1903)
static void C_fcall f_1903(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1858)
static void C_fcall f_1858(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static C_word C_fcall f_1882(C_word t0,C_word t1);
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1796)
static void C_fcall f_1796(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_fcall f_1791(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1786)
static void C_fcall f_1786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1741)
static void C_fcall f_1741(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1765)
static C_word C_fcall f_1765(C_word t0,C_word t1);
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1679)
static void C_fcall f_1679(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_fcall f_1674(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1669)
static void C_fcall f_1669(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1624)
static void C_fcall f_1624(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static C_word C_fcall f_1648(C_word t0,C_word t1);
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1562)
static void C_fcall f_1562(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_fcall f_1557(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1552)
static void C_fcall f_1552(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1507)
static void C_fcall f_1507(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1526)
static void C_ccall f_1526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static C_word C_fcall f_1531(C_word t0,C_word t1);
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1487)
static void C_fcall f_1487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_fcall f_1462(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1478)
static void C_ccall f_1478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1344)
static void C_ccall f_1344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1371)
static void C_fcall f_1371(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_fcall f_1282(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1265)
static void C_fcall f_1265(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_fcall f_1251(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_fcall f_1208(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1205)
static void C_ccall f_1205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1199)
static void C_ccall f_1199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1172)
static void C_ccall f_1172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;

C_noret_decl(trf_3505)
static void C_fcall trf_3505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3505(t0,t1);}

C_noret_decl(trf_3500)
static void C_fcall trf_3500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3500(t0,t1,t2);}

C_noret_decl(trf_3438)
static void C_fcall trf_3438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3438(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3438(t0,t1,t2,t3);}

C_noret_decl(trf_3474)
static void C_fcall trf_3474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3474(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3474(t0,t1);}

C_noret_decl(trf_3427)
static void C_fcall trf_3427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3427(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3427(t0,t1,t2);}

C_noret_decl(trf_3381)
static void C_fcall trf_3381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3381(t0,t1);}

C_noret_decl(trf_3376)
static void C_fcall trf_3376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3376(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3376(t0,t1,t2);}

C_noret_decl(trf_3331)
static void C_fcall trf_3331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3331(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3331(t0,t1,t2,t3);}

C_noret_decl(trf_3347)
static void C_fcall trf_3347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3347(t0,t1);}

C_noret_decl(trf_3269)
static void C_fcall trf_3269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3269(t0,t1);}

C_noret_decl(trf_3264)
static void C_fcall trf_3264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3264(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3264(t0,t1,t2);}

C_noret_decl(trf_3255)
static void C_fcall trf_3255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3255(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3255(t0,t1,t2,t3);}

C_noret_decl(trf_3218)
static void C_fcall trf_3218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3218(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3218(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3233)
static void C_fcall trf_3233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3233(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3233(t0,t1,t2);}

C_noret_decl(trf_3125)
static void C_fcall trf_3125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3125(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3125(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2746)
static void C_fcall trf_2746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2746(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2746(t0,t1,t2,t3);}

C_noret_decl(trf_2717)
static void C_fcall trf_2717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2717(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2717(t0,t1,t2,t3);}

C_noret_decl(trf_2699)
static void C_fcall trf_2699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2699(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2699(t0,t1,t2);}

C_noret_decl(trf_2688)
static void C_fcall trf_2688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2688(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2688(t0,t1,t2);}

C_noret_decl(trf_2573)
static void C_fcall trf_2573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2573(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2573(t0,t1,t2);}

C_noret_decl(trf_2584)
static void C_fcall trf_2584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2584(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2584(t0,t1,t2);}

C_noret_decl(trf_2455)
static void C_fcall trf_2455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2455(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2455(t0,t1,t2,t3);}

C_noret_decl(trf_2472)
static void C_fcall trf_2472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2472(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2472(t0,t1,t2,t3);}

C_noret_decl(trf_2395)
static void C_fcall trf_2395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2395(t0,t1);}

C_noret_decl(trf_2390)
static void C_fcall trf_2390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2390(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2390(t0,t1,t2);}

C_noret_decl(trf_2385)
static void C_fcall trf_2385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2385(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2385(t0,t1,t2,t3);}

C_noret_decl(trf_2333)
static void C_fcall trf_2333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2333(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2333(t0,t1,t2,t3);}

C_noret_decl(trf_2355)
static void C_fcall trf_2355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2355(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2355(t0,t1);}

C_noret_decl(trf_2271)
static void C_fcall trf_2271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2271(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2271(t0,t1);}

C_noret_decl(trf_2266)
static void C_fcall trf_2266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2266(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2266(t0,t1,t2);}

C_noret_decl(trf_2261)
static void C_fcall trf_2261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2261(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2261(t0,t1,t2,t3);}

C_noret_decl(trf_2209)
static void C_fcall trf_2209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2209(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2209(t0,t1,t2,t3);}

C_noret_decl(trf_2231)
static void C_fcall trf_2231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2231(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2231(t0,t1);}

C_noret_decl(trf_2147)
static void C_fcall trf_2147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2147(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2147(t0,t1);}

C_noret_decl(trf_2142)
static void C_fcall trf_2142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2142(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2142(t0,t1,t2);}

C_noret_decl(trf_2137)
static void C_fcall trf_2137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2137(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2137(t0,t1,t2,t3);}

C_noret_decl(trf_2092)
static void C_fcall trf_2092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2092(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2092(t0,t1,t2,t3);}

C_noret_decl(trf_2030)
static void C_fcall trf_2030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2030(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2030(t0,t1);}

C_noret_decl(trf_2025)
static void C_fcall trf_2025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2025(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2025(t0,t1,t2);}

C_noret_decl(trf_2020)
static void C_fcall trf_2020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2020(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2020(t0,t1,t2,t3);}

C_noret_decl(trf_1975)
static void C_fcall trf_1975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1975(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1975(t0,t1,t2,t3);}

C_noret_decl(trf_1913)
static void C_fcall trf_1913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1913(t0,t1);}

C_noret_decl(trf_1908)
static void C_fcall trf_1908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1908(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1908(t0,t1,t2);}

C_noret_decl(trf_1903)
static void C_fcall trf_1903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1903(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1903(t0,t1,t2,t3);}

C_noret_decl(trf_1858)
static void C_fcall trf_1858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1858(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1858(t0,t1,t2,t3);}

C_noret_decl(trf_1796)
static void C_fcall trf_1796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1796(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1796(t0,t1);}

C_noret_decl(trf_1791)
static void C_fcall trf_1791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1791(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1791(t0,t1,t2);}

C_noret_decl(trf_1786)
static void C_fcall trf_1786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1786(t0,t1,t2,t3);}

C_noret_decl(trf_1741)
static void C_fcall trf_1741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1741(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1741(t0,t1,t2,t3);}

C_noret_decl(trf_1679)
static void C_fcall trf_1679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1679(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1679(t0,t1);}

C_noret_decl(trf_1674)
static void C_fcall trf_1674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1674(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1674(t0,t1,t2);}

C_noret_decl(trf_1669)
static void C_fcall trf_1669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1669(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1669(t0,t1,t2,t3);}

C_noret_decl(trf_1624)
static void C_fcall trf_1624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1624(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1624(t0,t1,t2,t3);}

C_noret_decl(trf_1562)
static void C_fcall trf_1562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1562(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1562(t0,t1);}

C_noret_decl(trf_1557)
static void C_fcall trf_1557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1557(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1557(t0,t1,t2);}

C_noret_decl(trf_1552)
static void C_fcall trf_1552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1552(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1552(t0,t1,t2,t3);}

C_noret_decl(trf_1507)
static void C_fcall trf_1507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1507(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1507(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1487)
static void C_fcall trf_1487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1487(t0,t1);}

C_noret_decl(trf_1462)
static void C_fcall trf_1462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1462(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1462(t0,t1,t2,t3);}

C_noret_decl(trf_1371)
static void C_fcall trf_1371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1371(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1371(t0,t1,t2,t3);}

C_noret_decl(trf_1282)
static void C_fcall trf_1282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1282(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1282(t0,t1,t2,t3);}

C_noret_decl(trf_1265)
static void C_fcall trf_1265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1265(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1265(t0,t1,t2,t3);}

C_noret_decl(trf_1251)
static void C_fcall trf_1251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1251(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1251(t0,t1,t2,t3);}

C_noret_decl(trf_1208)
static void C_fcall trf_1208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1208(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1208(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_4_toplevel"));
C_check_nursery_minimum(42);
if(!C_demand(42)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1554)){
C_save(t1);
C_rereclaim2(1554*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(42);
C_initialize_lf(lf,174);
lf[0]=C_h_intern(&lf[0],24,"\003syscheck-exact-interval");
lf[1]=C_h_intern(&lf[1],9,"\003syserror");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[3]=C_h_intern(&lf[3],26,"\003syscheck-inexact-interval");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[12]=C_h_intern(&lf[12],15,"\003syscons-flonum");
lf[22]=C_h_intern(&lf[22],15,"u8vector-length");
lf[23]=C_h_intern(&lf[23],15,"s8vector-length");
lf[24]=C_h_intern(&lf[24],16,"u16vector-length");
lf[25]=C_h_intern(&lf[25],16,"s16vector-length");
lf[26]=C_h_intern(&lf[26],16,"u32vector-length");
lf[27]=C_h_intern(&lf[27],16,"s32vector-length");
lf[28]=C_h_intern(&lf[28],16,"f32vector-length");
lf[29]=C_h_intern(&lf[29],16,"f64vector-length");
lf[30]=C_h_intern(&lf[30],15,"\003syscheck-range");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[32]=C_h_intern(&lf[32],13,"u8vector-set!");
lf[33]=C_h_intern(&lf[33],13,"s8vector-set!");
lf[34]=C_h_intern(&lf[34],14,"u16vector-set!");
lf[35]=C_h_intern(&lf[35],14,"s16vector-set!");
lf[36]=C_h_intern(&lf[36],14,"u32vector-set!");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[39]=C_h_intern(&lf[39],14,"s32vector-set!");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[41]=C_h_intern(&lf[41],14,"f32vector-set!");
lf[42]=C_h_intern(&lf[42],14,"f64vector-set!");
lf[43]=C_h_intern(&lf[43],12,"u8vector-ref");
lf[44]=C_h_intern(&lf[44],12,"s8vector-ref");
lf[45]=C_h_intern(&lf[45],13,"u16vector-ref");
lf[46]=C_h_intern(&lf[46],13,"s16vector-ref");
lf[47]=C_h_intern(&lf[47],13,"u32vector-ref");
lf[48]=C_h_intern(&lf[48],13,"s32vector-ref");
lf[49]=C_h_intern(&lf[49],13,"f32vector-ref");
lf[50]=C_h_intern(&lf[50],13,"f64vector-ref");
lf[51]=C_h_intern(&lf[51],14,"set-finalizer!");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000:not enough memory - cannot allocate external number vector");
lf[53]=C_h_intern(&lf[53],19,"\003sysallocate-vector");
lf[54]=C_h_intern(&lf[54],21,"release-number-vector");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\047bad argument type - not a number vector");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376"
"\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[57]=C_h_intern(&lf[57],13,"make-u8vector");
lf[58]=C_h_intern(&lf[58],8,"u8vector");
lf[59]=C_h_intern(&lf[59],13,"make-s8vector");
lf[60]=C_h_intern(&lf[60],8,"s8vector");
lf[61]=C_h_intern(&lf[61],4,"fin\077");
lf[62]=C_h_intern(&lf[62],14,"make-u16vector");
lf[63]=C_h_intern(&lf[63],9,"u16vector");
lf[64]=C_h_intern(&lf[64],14,"make-s16vector");
lf[65]=C_h_intern(&lf[65],9,"s16vector");
lf[66]=C_h_intern(&lf[66],14,"make-u32vector");
lf[67]=C_h_intern(&lf[67],9,"u32vector");
lf[68]=C_h_intern(&lf[68],14,"make-s32vector");
lf[69]=C_h_intern(&lf[69],9,"s32vector");
lf[70]=C_h_intern(&lf[70],14,"make-f32vector");
lf[71]=C_h_intern(&lf[71],9,"f32vector");
lf[72]=C_h_intern(&lf[72],14,"make-f64vector");
lf[73]=C_h_intern(&lf[73],9,"f64vector");
lf[74]=C_h_intern(&lf[74],27,"\003syserror-not-a-proper-list");
lf[75]=C_h_intern(&lf[75],14,"list->u8vector");
lf[76]=C_h_intern(&lf[76],14,"list->s8vector");
lf[77]=C_h_intern(&lf[77],15,"list->u16vector");
lf[78]=C_h_intern(&lf[78],15,"list->s16vector");
lf[79]=C_h_intern(&lf[79],15,"list->u32vector");
lf[80]=C_h_intern(&lf[80],15,"list->s32vector");
lf[81]=C_h_intern(&lf[81],15,"list->f32vector");
lf[82]=C_h_intern(&lf[82],15,"list->f64vector");
lf[83]=C_h_intern(&lf[83],14,"u8vector->list");
lf[84]=C_h_intern(&lf[84],14,"s8vector->list");
lf[85]=C_h_intern(&lf[85],15,"u16vector->list");
lf[86]=C_h_intern(&lf[86],15,"s16vector->list");
lf[87]=C_h_intern(&lf[87],15,"u32vector->list");
lf[88]=C_h_intern(&lf[88],15,"s32vector->list");
lf[89]=C_h_intern(&lf[89],15,"f32vector->list");
lf[90]=C_h_intern(&lf[90],15,"f64vector->list");
lf[91]=C_h_intern(&lf[91],9,"u8vector\077");
lf[92]=C_h_intern(&lf[92],9,"s8vector\077");
lf[93]=C_h_intern(&lf[93],10,"u16vector\077");
lf[94]=C_h_intern(&lf[94],10,"s16vector\077");
lf[95]=C_h_intern(&lf[95],10,"u32vector\077");
lf[96]=C_h_intern(&lf[96],10,"s32vector\077");
lf[97]=C_h_intern(&lf[97],10,"f32vector\077");
lf[98]=C_h_intern(&lf[98],10,"f64vector\077");
lf[99]=C_h_intern(&lf[99],13,"\003sysmake-blob");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[102]=C_h_intern(&lf[102],21,"u8vector->blob/shared");
lf[103]=C_h_intern(&lf[103],21,"s8vector->blob/shared");
lf[104]=C_h_intern(&lf[104],22,"u16vector->blob/shared");
lf[105]=C_h_intern(&lf[105],22,"s16vector->blob/shared");
lf[106]=C_h_intern(&lf[106],22,"u32vector->blob/shared");
lf[107]=C_h_intern(&lf[107],22,"s32vector->blob/shared");
lf[108]=C_h_intern(&lf[108],22,"f32vector->blob/shared");
lf[109]=C_h_intern(&lf[109],22,"f64vector->blob/shared");
lf[110]=C_h_intern(&lf[110],14,"u8vector->blob");
lf[111]=C_h_intern(&lf[111],14,"s8vector->blob");
lf[112]=C_h_intern(&lf[112],15,"u16vector->blob");
lf[113]=C_h_intern(&lf[113],15,"s16vector->blob");
lf[114]=C_h_intern(&lf[114],15,"u32vector->blob");
lf[115]=C_h_intern(&lf[115],15,"s32vector->blob");
lf[116]=C_h_intern(&lf[116],15,"f32vector->blob");
lf[117]=C_h_intern(&lf[117],15,"f64vector->blob");
lf[118]=C_h_intern(&lf[118],21,"blob->u8vector/shared");
lf[119]=C_h_intern(&lf[119],21,"blob->s8vector/shared");
lf[120]=C_h_intern(&lf[120],22,"blob->u16vector/shared");
lf[121]=C_h_intern(&lf[121],22,"blob->s16vector/shared");
lf[122]=C_h_intern(&lf[122],22,"blob->u32vector/shared");
lf[123]=C_h_intern(&lf[123],22,"blob->s32vector/shared");
lf[124]=C_h_intern(&lf[124],22,"blob->f32vector/shared");
lf[125]=C_h_intern(&lf[125],22,"blob->f64vector/shared");
lf[126]=C_h_intern(&lf[126],14,"blob->u8vector");
lf[127]=C_h_intern(&lf[127],14,"blob->s8vector");
lf[128]=C_h_intern(&lf[128],15,"blob->u16vector");
lf[129]=C_h_intern(&lf[129],15,"blob->s16vector");
lf[130]=C_h_intern(&lf[130],15,"blob->u32vector");
lf[131]=C_h_intern(&lf[131],15,"blob->s32vector");
lf[132]=C_h_intern(&lf[132],15,"blob->f32vector");
lf[133]=C_h_intern(&lf[133],15,"blob->f64vector");
lf[134]=C_h_intern(&lf[134],18,"\003sysuser-read-hook");
lf[135]=C_h_intern(&lf[135],4,"read");
lf[136]=C_h_intern(&lf[136],2,"u8");
lf[137]=C_h_intern(&lf[137],2,"s8");
lf[138]=C_h_intern(&lf[138],3,"u16");
lf[139]=C_h_intern(&lf[139],3,"s16");
lf[140]=C_h_intern(&lf[140],3,"u32");
lf[141]=C_h_intern(&lf[141],3,"s32");
lf[142]=C_h_intern(&lf[142],3,"f32");
lf[143]=C_h_intern(&lf[143],3,"f64");
lf[144]=C_h_intern(&lf[144],1,"f");
lf[145]=C_h_intern(&lf[145],1,"F");
lf[146]=C_h_intern(&lf[146],14,"\003sysread-error");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal bytevector syntax");
lf[148]=C_h_intern(&lf[148],19,"\003sysuser-print-hook");
lf[149]=C_h_intern(&lf[149],9,"\003sysprint");
lf[151]=C_h_intern(&lf[151],11,"subu8vector");
lf[152]=C_h_intern(&lf[152],12,"subu16vector");
lf[153]=C_h_intern(&lf[153],12,"subu32vector");
lf[154]=C_h_intern(&lf[154],11,"subs8vector");
lf[155]=C_h_intern(&lf[155],12,"subs16vector");
lf[156]=C_h_intern(&lf[156],12,"subs32vector");
lf[157]=C_h_intern(&lf[157],12,"subf32vector");
lf[158]=C_h_intern(&lf[158],12,"subf64vector");
lf[159]=C_h_intern(&lf[159],14,"write-u8vector");
lf[160]=C_h_intern(&lf[160],16,"\003syswrite-char-0");
lf[161]=C_h_intern(&lf[161],14,"\003syscheck-port");
lf[162]=C_h_intern(&lf[162],19,"\003sysstandard-output");
lf[163]=C_h_intern(&lf[163],14,"read-u8vector!");
lf[164]=C_h_intern(&lf[164],16,"\003sysread-string!");
lf[165]=C_h_intern(&lf[165],18,"\003sysstandard-input");
lf[166]=C_h_intern(&lf[166],18,"open-output-string");
lf[167]=C_h_intern(&lf[167],17,"get-output-string");
lf[168]=C_h_intern(&lf[168],13,"read-u8vector");
lf[169]=C_h_intern(&lf[169],19,"\003syswrite-char/port");
lf[170]=C_h_intern(&lf[170],15,"\003sysread-char-0");
lf[171]=C_h_intern(&lf[171],17,"register-feature!");
lf[172]=C_h_intern(&lf[172],6,"srfi-4");
lf[173]=C_h_intern(&lf[173],18,"getter-with-setter");
C_register_lf2(lf,174,create_ptable());
t2=C_mutate((C_word*)lf[0]+1 /* (set! check-exact-interval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1118,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! check-inexact-interval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1133,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[5] /* (set! u8vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1154,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[6] /* (set! s8vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1157,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[7] /* (set! u16vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1160,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[8] /* (set! s16vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1163,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[9] /* (set! u32vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1166,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[10] /* (set! s32vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1169,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[11] /* (set! f32vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1172,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[13] /* (set! f64vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1178,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[14] /* (set! u8vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1184,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[15] /* (set! s8vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1187,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[16] /* (set! u16vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1190,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[17] /* (set! s16vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1193,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[18] /* (set! u32vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1196,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[19] /* (set! s32vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1199,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[20] /* (set! f32vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1202,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[21] /* (set! f64vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1205,tmp=(C_word)a,a+=2,tmp));
t20=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1208,tmp=(C_word)a,a+=2,tmp);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1221,a[2]=t20,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 141  len */
f_1208(t21,lf[58],C_SCHEME_FALSE,lf[22]);}

/* k1219 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1221,2,t0,t1);}
t2=C_mutate((C_word*)lf[22]+1 /* (set! u8vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 142  len */
f_1208(t3,lf[60],C_SCHEME_FALSE,lf[23]);}

/* k1223 in k1219 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1225,2,t0,t1);}
t2=C_mutate((C_word*)lf[23]+1 /* (set! s8vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 143  len */
f_1208(t3,lf[63],C_fix(1),lf[24]);}

/* k1227 in k1223 in k1219 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1229,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! u16vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 144  len */
f_1208(t3,lf[65],C_fix(1),lf[25]);}

/* k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1233,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1 /* (set! s16vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 145  len */
f_1208(t3,lf[67],C_fix(2),lf[26]);}

/* k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1237,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1 /* (set! u32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 146  len */
f_1208(t3,lf[69],C_fix(2),lf[27]);}

/* k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1241,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1 /* (set! s32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 147  len */
f_1208(t3,lf[71],C_fix(2),lf[28]);}

/* k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1245,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! f32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 148  len */
f_1208(t3,lf[73],C_fix(3),lf[29]);}

/* k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1249,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! f64vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1251,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1265,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1282,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1371,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1397,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 204  setu */
f_1282(t7,*((C_word*)lf[22]+1),lf[14],lf[32]);}

/* k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1397,2,t0,t1);}
t2=C_mutate((C_word*)lf[32]+1 /* (set! u8vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 205  set */
f_1265(t3,*((C_word*)lf[23]+1),lf[15],lf[33]);}

/* k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1401,2,t0,t1);}
t2=C_mutate((C_word*)lf[33]+1 /* (set! s8vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 206  setu */
f_1282(t3,*((C_word*)lf[24]+1),lf[16],lf[34]);}

/* k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1405,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1 /* (set! u16vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 207  set */
f_1265(t3,*((C_word*)lf[25]+1),lf[17],lf[35]);}

/* k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1409,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1 /* (set! s16vector-set! ...) */,t1);
t3=*((C_word*)lf[26]+1);
t4=lf[18];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1337,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=C_mutate((C_word*)lf[36]+1 /* (set! u32vector-set! ...) */,t5);
t7=*((C_word*)lf[27]+1);
t8=lf[19];
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1310,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t10=C_mutate((C_word*)lf[39]+1 /* (set! s32vector-set! ...) */,t9);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 210  setf */
f_1371(t11,*((C_word*)lf[28]+1),lf[20],lf[41]);}

/* k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1421,2,t0,t1);}
t2=C_mutate((C_word*)lf[41]+1 /* (set! f32vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 211  setf */
f_1371(t3,*((C_word*)lf[29]+1),lf[21],lf[42]);}

/* k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1425,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! f64vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3583,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 214  get */
f_1251(t4,*((C_word*)lf[22]+1),lf[5],lf[43]);}

/* k3581 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 214  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[32]+1));}

/* k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1429,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1 /* (set! u8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3579,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 217  get */
f_1251(t4,*((C_word*)lf[23]+1),lf[6],lf[44]);}

/* k3577 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 217  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[33]+1));}

/* k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1433,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1 /* (set! s8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3575,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 220  get */
f_1251(t4,*((C_word*)lf[24]+1),lf[7],lf[45]);}

/* k3573 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 220  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[34]+1));}

/* k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1437,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! u16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3571,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 223  get */
f_1251(t4,*((C_word*)lf[25]+1),lf[8],lf[46]);}

/* k3569 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 223  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[35]+1));}

/* k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1441,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1 /* (set! s16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3567,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 227  get */
f_1251(t4,*((C_word*)lf[26]+1),lf[9],lf[47]);}

/* k3565 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 226  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[36]+1));}

/* k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1445,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1 /* (set! u32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3563,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 231  get */
f_1251(t4,*((C_word*)lf[27]+1),lf[10],lf[48]);}

/* k3561 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 230  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[39]+1));}

/* k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1449,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1 /* (set! s32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3559,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 235  get */
f_1251(t4,*((C_word*)lf[28]+1),lf[11],lf[49]);}

/* k3557 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 234  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[41]+1));}

/* k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1453,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1 /* (set! f32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1457,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3555,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 239  get */
f_1251(t4,*((C_word*)lf[29]+1),lf[13],lf[50]);}

/* k3553 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 238  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[42]+1));}

/* k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1 /* (set! f64vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1460,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[51]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1462,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[54]+1 /* (set! release-number-vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1480,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[57]+1 /* (set! make-u8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1505,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=C_mutate((C_word*)lf[59]+1 /* (set! make-s8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1622,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t9=C_mutate((C_word*)lf[62]+1 /* (set! make-u16vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1739,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[64]+1 /* (set! make-s16vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1856,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[66]+1 /* (set! make-u32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1973,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t12=C_mutate((C_word*)lf[68]+1 /* (set! make-s32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2090,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t13=C_mutate((C_word*)lf[70]+1 /* (set! make-f32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2207,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t14=C_mutate((C_word*)lf[72]+1 /* (set! make-f64vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2331,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2455,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2495,a[2]=t15,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 398  init */
f_2455(t16,*((C_word*)lf[57]+1),*((C_word*)lf[32]+1),lf[75]);}

/* k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2495,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! list->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 399  init */
f_2455(t3,*((C_word*)lf[59]+1),*((C_word*)lf[33]+1),lf[76]);}

/* k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! list->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 400  init */
f_2455(t3,*((C_word*)lf[62]+1),*((C_word*)lf[34]+1),lf[77]);}

/* k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2503,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! list->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 401  init */
f_2455(t3,*((C_word*)lf[64]+1),*((C_word*)lf[35]+1),lf[78]);}

/* k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2507,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! list->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 402  init */
f_2455(t3,*((C_word*)lf[66]+1),*((C_word*)lf[36]+1),lf[79]);}

/* k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2511,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1 /* (set! list->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 403  init */
f_2455(t3,*((C_word*)lf[68]+1),*((C_word*)lf[39]+1),lf[80]);}

/* k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! list->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 404  init */
f_2455(t3,*((C_word*)lf[70]+1),*((C_word*)lf[41]+1),lf[81]);}

/* k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1 /* (set! list->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2523,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 405  init */
f_2455(t3,*((C_word*)lf[72]+1),*((C_word*)lf[42]+1),lf[82]);}

/* k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2523,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1 /* (set! list->f64vector ...) */,t1);
t3=*((C_word*)lf[75]+1);
t4=C_mutate((C_word*)lf[58]+1 /* (set! u8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2525,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[76]+1);
t6=C_mutate((C_word*)lf[60]+1 /* (set! s8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2531,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[77]+1);
t8=C_mutate((C_word*)lf[63]+1 /* (set! u16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2537,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[78]+1);
t10=C_mutate((C_word*)lf[65]+1 /* (set! s16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2543,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[79]+1);
t12=C_mutate((C_word*)lf[67]+1 /* (set! u32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2549,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[80]+1);
t14=C_mutate((C_word*)lf[69]+1 /* (set! s32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2555,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[81]+1);
t16=C_mutate((C_word*)lf[71]+1 /* (set! f32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2561,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[82]+1);
t18=C_mutate((C_word*)lf[73]+1 /* (set! f64vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2567,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2573,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2610,a[2]=t19,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 456  init */
f_2573(t20,*((C_word*)lf[22]+1),lf[5]);}

/* k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2610,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1 /* (set! u8vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 457  init */
f_2573(t3,*((C_word*)lf[23]+1),lf[6]);}

/* k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2614,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1 /* (set! s8vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 458  init */
f_2573(t3,*((C_word*)lf[24]+1),lf[7]);}

/* k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2618,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! u16vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 459  init */
f_2573(t3,*((C_word*)lf[25]+1),lf[8]);}

/* k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2622,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* (set! s16vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 460  init */
f_2573(t3,*((C_word*)lf[26]+1),lf[9]);}

/* k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! u32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 461  init */
f_2573(t3,*((C_word*)lf[27]+1),lf[10]);}

/* k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2630,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1 /* (set! s32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 462  init */
f_2573(t3,*((C_word*)lf[28]+1),lf[11]);}

/* k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* (set! f32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 463  init */
f_2573(t3,*((C_word*)lf[29]+1),lf[13]);}

/* k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* (set! f64vector->list ...) */,t1);
t3=C_mutate((C_word*)lf[91]+1 /* (set! u8vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2640,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[92]+1 /* (set! s8vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2646,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[93]+1 /* (set! u16vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2652,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[94]+1 /* (set! s16vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2658,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[95]+1 /* (set! u32vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2664,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[96]+1 /* (set! s32vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2670,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[97]+1 /* (set! f32vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2676,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[98]+1 /* (set! f64vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2682,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2688,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2699,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2717,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2746,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2780,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t14,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 515  pack */
f_2688(t15,lf[58],lf[102]);}

/* k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2780,2,t0,t1);}
t2=C_mutate((C_word*)lf[102]+1 /* (set! u8vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 516  pack */
f_2688(t3,lf[60],lf[103]);}

/* k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
t2=C_mutate((C_word*)lf[103]+1 /* (set! s8vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 517  pack */
f_2688(t3,lf[63],lf[104]);}

/* k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=C_mutate((C_word*)lf[104]+1 /* (set! u16vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 518  pack */
f_2688(t3,lf[65],lf[105]);}

/* k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2792,2,t0,t1);}
t2=C_mutate((C_word*)lf[105]+1 /* (set! s16vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 519  pack */
f_2688(t3,lf[67],lf[106]);}

/* k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=C_mutate((C_word*)lf[106]+1 /* (set! u32vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 520  pack */
f_2688(t3,lf[69],lf[107]);}

/* k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2800,2,t0,t1);}
t2=C_mutate((C_word*)lf[107]+1 /* (set! s32vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 521  pack */
f_2688(t3,lf[71],lf[108]);}

/* k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2804,2,t0,t1);}
t2=C_mutate((C_word*)lf[108]+1 /* (set! f32vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 522  pack */
f_2688(t3,lf[73],lf[109]);}

/* k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=C_mutate((C_word*)lf[109]+1 /* (set! f64vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 524  pack-copy */
f_2699(t3,lf[58],lf[110]);}

/* k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1 /* (set! u8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 525  pack-copy */
f_2699(t3,lf[60],lf[111]);}

/* k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2816,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1 /* (set! s8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 526  pack-copy */
f_2699(t3,lf[63],lf[112]);}

/* k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2820,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1 /* (set! u16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 527  pack-copy */
f_2699(t3,lf[65],lf[113]);}

/* k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! s16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 528  pack-copy */
f_2699(t3,lf[67],lf[114]);}

/* k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2828,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1 /* (set! u32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 529  pack-copy */
f_2699(t3,lf[69],lf[115]);}

/* k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2832,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1 /* (set! s32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 530  pack-copy */
f_2699(t3,lf[71],lf[116]);}

/* k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2836,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1 /* (set! f32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 531  pack-copy */
f_2699(t3,lf[73],lf[117]);}

/* k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2840,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1 /* (set! f64vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 533  unpack */
f_2717(t3,lf[58],C_SCHEME_TRUE,lf[118]);}

/* k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2844,2,t0,t1);}
t2=C_mutate((C_word*)lf[118]+1 /* (set! blob->u8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 534  unpack */
f_2717(t3,lf[60],C_SCHEME_TRUE,lf[119]);}

/* k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=C_mutate((C_word*)lf[119]+1 /* (set! blob->s8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 535  unpack */
f_2717(t3,lf[63],C_fix(2),lf[120]);}

/* k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2852,2,t0,t1);}
t2=C_mutate((C_word*)lf[120]+1 /* (set! blob->u16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 536  unpack */
f_2717(t3,lf[65],C_fix(2),lf[121]);}

/* k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2856,2,t0,t1);}
t2=C_mutate((C_word*)lf[121]+1 /* (set! blob->s16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 537  unpack */
f_2717(t3,lf[67],C_fix(4),lf[122]);}

/* k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1 /* (set! blob->u32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 538  unpack */
f_2717(t3,lf[69],C_fix(4),lf[123]);}

/* k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1 /* (set! blob->s32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 539  unpack */
f_2717(t3,lf[71],C_fix(4),lf[124]);}

/* k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
t2=C_mutate((C_word*)lf[124]+1 /* (set! blob->f32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 540  unpack */
f_2717(t3,lf[73],C_fix(8),lf[125]);}

/* k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=C_mutate((C_word*)lf[125]+1 /* (set! blob->f64vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 542  unpack-copy */
f_2746(t3,lf[58],C_SCHEME_TRUE,lf[126]);}

/* k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2876,2,t0,t1);}
t2=C_mutate((C_word*)lf[126]+1 /* (set! blob->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 543  unpack-copy */
f_2746(t3,lf[60],C_SCHEME_TRUE,lf[127]);}

/* k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2880,2,t0,t1);}
t2=C_mutate((C_word*)lf[127]+1 /* (set! blob->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 544  unpack-copy */
f_2746(t3,lf[63],C_fix(2),lf[128]);}

/* k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2884,2,t0,t1);}
t2=C_mutate((C_word*)lf[128]+1 /* (set! blob->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 545  unpack-copy */
f_2746(t3,lf[65],C_fix(2),lf[129]);}

/* k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2888,2,t0,t1);}
t2=C_mutate((C_word*)lf[129]+1 /* (set! blob->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 546  unpack-copy */
f_2746(t3,lf[67],C_fix(4),lf[130]);}

/* k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1 /* (set! blob->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 547  unpack-copy */
f_2746(t3,lf[69],C_fix(4),lf[131]);}

/* k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2896,2,t0,t1);}
t2=C_mutate((C_word*)lf[131]+1 /* (set! blob->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 548  unpack-copy */
f_2746(t3,lf[71],C_fix(4),lf[132]);}

/* k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=C_mutate((C_word*)lf[132]+1 /* (set! blob->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2904,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 549  unpack-copy */
f_2746(t3,lf[73],C_fix(8),lf[133]);}

/* k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[88],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2904,2,t0,t1);}
t2=C_mutate((C_word*)lf[133]+1 /* (set! blob->f64vector ...) */,t1);
t3=*((C_word*)lf[134]+1);
t4=*((C_word*)lf[135]+1);
t5=(C_word)C_a_i_list(&a,16,lf[136],*((C_word*)lf[75]+1),lf[137],*((C_word*)lf[76]+1),lf[138],*((C_word*)lf[77]+1),lf[139],*((C_word*)lf[78]+1),lf[140],*((C_word*)lf[79]+1),lf[141],*((C_word*)lf[80]+1),lf[142],*((C_word*)lf[81]+1),lf[143],*((C_word*)lf[82]+1));
t6=C_mutate((C_word*)lf[134]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2909,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=*((C_word*)lf[148]+1);
t8=C_mutate((C_word*)lf[148]+1 /* (set! user-print-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2965,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[150] /* (set! subvector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3125,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[151]+1 /* (set! subu8vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3168,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[152]+1 /* (set! subu16vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3174,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[153]+1 /* (set! subu32vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3180,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[154]+1 /* (set! subs8vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3186,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[155]+1 /* (set! subs16vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3192,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[156]+1 /* (set! subs32vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3198,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[157]+1 /* (set! subf32vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3204,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[158]+1 /* (set! subf64vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3210,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[159]+1 /* (set! write-u8vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3216,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[163]+1 /* (set! read-u8vector! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3329,tmp=(C_word)a,a+=2,tmp));
t20=*((C_word*)lf[166]+1);
t21=*((C_word*)lf[167]+1);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3427,tmp=(C_word)a,a+=2,tmp);
t23=C_mutate((C_word*)lf[168]+1 /* (set! read-u8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3436,a[2]=t20,a[3]=t21,a[4]=t22,tmp=(C_word)a,a+=5,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3551,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 671  register-feature! */
t25=*((C_word*)lf[171]+1);
((C_proc3)(void*)(*((C_word*)t25+1)))(3,t25,t24,lf[172]);}

/* k3549 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* read-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_3436r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3436r(t0,t1,t2);}}

static void C_ccall f_3436r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3500,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3505,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n10201051 */
t6=t5;
f_3505(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-p10211049 */
t8=t4;
f_3500(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body10181026 */
t10=t3;
f_3438(t10,t1,t6,t8);}}}

/* def-n1020 in read-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3505,NULL,2,t0,t1);}
/* def-p10211049 */
t2=((C_word*)t0)[2];
f_3500(t2,t1,C_SCHEME_FALSE);}

/* def-p1021 in read-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3500(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3500,NULL,3,t0,t1,t2);}
/* body10181026 */
t3=((C_word*)t0)[2];
f_3438(t3,t1,t2,*((C_word*)lf[165]+1));}

/* body1018 in read-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3438(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3438,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 651  ##sys#check-port */
t5=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[168]);}

/* k3440 in body1018 in read-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],lf[168]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 653  ##sys#allocate-vector */
t4=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[7],C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 660  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3467 in k3440 in body1018 in read-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3474(t5,((C_word*)t0)[2]);}

/* loop in k3467 in k3440 in body1018 in read-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3474(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3474,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 662  ##sys#read-char-0 */
t3=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3476 in loop in k3467 in k3440 in body1018 in read-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3478,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 664  get-output-string */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 668  ##sys#write-char/port */
t3=*((C_word*)lf[169]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}

/* k3494 in k3476 in loop in k3467 in k3440 in body1018 in read-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 669  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3474(t2,((C_word*)t0)[2]);}

/* k3485 in k3476 in loop in k3467 in k3440 in body1018 in read-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(t1);
/* srfi-4.scm: 666  wrap */
f_3427(((C_word*)t0)[2],t1,t2);}

/* k3449 in k3440 in body1018 in read-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 654  ##sys#read-string! */
t3=*((C_word*)lf[164]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],t1,((C_word*)t0)[2],C_fix(0));}

/* k3452 in k3449 in k3440 in body1018 in read-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[58],((C_word*)t0)[5]));}
else{
/* srfi-4.scm: 658  wrap */
f_3427(((C_word*)t0)[3],((C_word*)t0)[5],t1);}}

/* wrap in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3427(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3427,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3435,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 646  ##sys#allocate-vector */
t5=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3433 in wrap in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3435,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_substring_copy(((C_word*)t0)[4],t1,C_fix(0),((C_word*)t0)[3],C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[58],t1));}

/* read-u8vector! in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3329r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3329r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3329r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3331,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3376,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3381,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port972993 */
t9=t8;
f_3381(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start973991 */
t11=t7;
f_3376(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
/* body970978 */
t13=t6;
f_3331(t13,t1,t9,t11);}}}

/* def-port972 in read-u8vector! in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3381,NULL,2,t0,t1);}
/* def-start973991 */
t2=((C_word*)t0)[2];
f_3376(t2,t1,*((C_word*)lf[165]+1));}

/* def-start973 in read-u8vector! in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3376(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3376,NULL,3,t0,t1,t2);}
/* body970978 */
t3=((C_word*)t0)[2];
f_3331(t3,t1,t2,C_fix(0));}

/* body970 in read-u8vector! in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3331(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3331,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3335,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 630  ##sys#check-port */
t5=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[163]);}

/* k3333 in body970 in read-u8vector! in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[163]);
t3=(C_word)C_i_check_structure_2(((C_word*)t0)[5],lf[58],lf[163]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[3])[1],lf[163]);
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_word)C_block_size(t4);
if(C_truep((C_word)C_fixnum_greaterp(t7,t8))){
t9=(C_word)C_block_size(t4);
t10=(C_word)C_u_fixnum_difference(t9,((C_word*)t0)[6]);
t11=C_mutate(((C_word *)((C_word*)t0)[3])+1,t10);
t12=t5;
f_3347(t12,t11);}
else{
t9=t5;
f_3347(t9,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_3347(t6,C_SCHEME_UNDEFINED);}}

/* k3345 in k3333 in body970 in read-u8vector! in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 638  ##sys#read-string! */
t2=*((C_word*)lf[164]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_3216r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3216r(t0,t1,t2,t3);}}

static void C_ccall f_3216r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3218,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3255,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3264,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3269,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-port922948 */
t8=t7;
f_3269(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-from923946 */
t10=t6;
f_3264(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-to924943 */
t12=t5;
f_3255(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body920929 */
t14=t4;
f_3218(t14,t1,t8,t10,t12);}}}}

/* def-port922 in write-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3269,NULL,2,t0,t1);}
/* def-from923946 */
t2=((C_word*)t0)[2];
f_3264(t2,t1,*((C_word*)lf[162]+1));}

/* def-from923 in write-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3264(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3264,NULL,3,t0,t1,t2);}
/* def-to924943 */
t3=((C_word*)t0)[2];
f_3255(t3,t1,t2,C_fix(0));}

/* def-to924 in write-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3255(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3255,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_8vector_length(((C_word*)t0)[3]);
/* body920929 */
t5=((C_word*)t0)[2];
f_3218(t5,t1,t2,t3,t4);}

/* body920 in write-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3218(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3218,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(((C_word*)t0)[2],lf[58],lf[159]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3225,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 623  ##sys#check-port */
t7=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,lf[159]);}

/* k3223 in body920 in write-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3225,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3233,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3233(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop934 in k3223 in body920 in write-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3233(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3233,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3243,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_make_character((C_word)C_unfix((C_word)C_u8peek(((C_word*)t0)[3],t2)));
/* srfi-4.scm: 627  ##sys#write-char-0 */
t5=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* k3241 in doloop934 in k3223 in body920 in write-u8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3233(t3,((C_word*)t0)[2],t2);}

/* subf64vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3210,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 619  subvector */
f_3125(t1,t2,lf[73],C_fix(8),t3,t4,lf[158]);}

/* subf32vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3204,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 618  subvector */
f_3125(t1,t2,lf[71],C_fix(4),t3,t4,lf[157]);}

/* subs32vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3198,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 617  subvector */
f_3125(t1,t2,lf[69],C_fix(4),t3,t4,lf[156]);}

/* subs16vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3192,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 616  subvector */
f_3125(t1,t2,lf[65],C_fix(2),t3,t4,lf[155]);}

/* subs8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3186,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 615  subvector */
f_3125(t1,t2,lf[60],C_fix(1),t3,t4,lf[154]);}

/* subu32vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3180,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 614  subvector */
f_3125(t1,t2,lf[67],C_fix(4),t3,t4,lf[153]);}

/* subu16vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3174,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 613  subvector */
f_3125(t1,t2,lf[63],C_fix(2),t3,t4,lf[152]);}

/* subu8vector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3168,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 612  subvector */
f_3125(t1,t2,lf[58],C_fix(1),t3,t4,lf[151]);}

/* subvector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3125(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3125,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(C_word)C_i_check_structure_2(t2,t3,t7);
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_block_size(t9);
t11=(C_word)C_fixnum_divide(t10,t4);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3138,a[2]=t7,a[3]=t11,a[4]=t1,a[5]=t9,a[6]=t3,a[7]=t4,a[8]=t5,a[9]=t6,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_u_fixnum_plus(t11,C_fix(1));
/* srfi-4.scm: 603  ##sys#check-range */
t14=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t12,t5,C_fix(0),t13,t7);}

/* k3136 in subvector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3141,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 604  ##sys#check-range */
t4=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[9],C_fix(0),t3,((C_word*)t0)[2]);}

/* k3139 in k3136 in subvector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3141,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_fixnum_times(((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3147,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 606  ##sys#allocate-vector */
t5=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3145 in k3139 in k3136 in subvector in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3147,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_a_i_record(&a,2,((C_word*)t0)[7],t1);
t4=(C_word)C_fixnum_times(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_copy_subvector(t1,((C_word*)t0)[4],C_fix(0),t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* ##sys#user-print-hook in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[102],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2965,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[83]+1),C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[136],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[58],t6);
t8=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[84]+1),C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[137],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[60],t9);
t11=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[85]+1),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[138],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[63],t12);
t14=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[86]+1),C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[139],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[65],t15);
t17=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[87]+1),C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,lf[140],t17);
t19=(C_word)C_a_i_cons(&a,2,lf[67],t18);
t20=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[88]+1),C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,lf[141],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[69],t21);
t23=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[89]+1),C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,lf[142],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[71],t24);
t26=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[90]+1),C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[143],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[73],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,t25,t29);
t31=(C_word)C_a_i_cons(&a,2,t22,t30);
t32=(C_word)C_a_i_cons(&a,2,t19,t31);
t33=(C_word)C_a_i_cons(&a,2,t16,t32);
t34=(C_word)C_a_i_cons(&a,2,t13,t33);
t35=(C_word)C_a_i_cons(&a,2,t10,t34);
t36=(C_word)C_a_i_cons(&a,2,t7,t35);
t37=(C_word)C_u_i_assq((C_word)C_slot(t2,C_fix(0)),t36);
if(C_truep(t37)){
t38=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2975,a[2]=t2,a[3]=t37,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 590  ##sys#print */
t39=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t39+1)))(5,t39,t38,C_make_character(35),C_SCHEME_FALSE,t4);}
else{
/* srfi-4.scm: 593  old-hook */
t38=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t38+1)))(5,t38,t1,t2,t3,t4);}}

/* k2973 in ##sys#user-print-hook in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
/* srfi-4.scm: 591  ##sys#print */
t4=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k2976 in k2973 in ##sys#user-print-hook in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2985,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,((C_word*)t0)[2]);}

/* k2983 in k2976 in k2973 in ##sys#user-print-hook in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 592  ##sys#print */
t2=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2909,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2919,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 567  read */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* srfi-4.scm: 572  old-hook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k2917 in ##sys#user-read-hook in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=(C_word)C_eqp(t3,lf[144]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[145]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_u_i_memq(t3,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 570  read */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 571  ##sys#read-error */
t7=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[5],((C_word*)t0)[2],lf[147],t3);}}}

/* k2942 in k2917 in ##sys#user-read-hook in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2802 in k2798 in k2794 in k2790 in k2786 in k2782 in k2778 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t1);}

/* unpack-copy in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2746(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2746,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2748,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_2748 in unpack-copy in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2748,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2758,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 507  ##sys#make-blob */
t6=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k2756 */
static void C_ccall f_2758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2758,2,t0,t1);}
t2=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(((C_word*)t0)[6],((C_word*)t0)[7])));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,((C_word*)t0)[4],(C_word)C_copy_block(((C_word*)t0)[3],t1)));}
else{
/* srfi-4.scm: 513  ##sys#error */
t4=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[5],((C_word*)t0)[2],lf[101],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* unpack in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2717(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2717,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2719,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_2719 in unpack in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2719,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(t4,((C_word*)t0)[3])));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,2,((C_word*)t0)[2],t2));}
else{
/* srfi-4.scm: 501  ##sys#error */
t7=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,((C_word*)t0)[4],lf[100],((C_word*)t0)[2],t4,((C_word*)t0)[3]);}}

/* pack-copy in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2699(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2699,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2701,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_2701 in pack-copy in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2701,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2711,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_block_size(t4);
/* srfi-4.scm: 491  ##sys#make-blob */
t7=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k2709 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_copy_block(((C_word*)t0)[2],t1));}

/* pack in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2688(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2688,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2690,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_2690 in pack in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2690,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f64vector? in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2682,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[73]));}

/* f32vector? in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2676,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[71]));}

/* s32vector? in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2670,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[69]));}

/* u32vector? in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2664,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[67]));}

/* s16vector? in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2658,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[65]));}

/* u16vector? in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2652,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[63]));}

/* s8vector? in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2646,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[60]));}

/* u8vector? in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2640,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[58]));}

/* init in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2573(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2573,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2575,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_2575 in init in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2575,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2579,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 449  length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2577 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2579,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2584,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2584(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2577 */
static void C_fcall f_2584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2584,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 453  ref */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}}

/* k2596 in loop in k2577 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2602,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 454  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2584(t4,t2,t3);}

/* k2600 in k2596 in loop in k2577 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f64vector in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2567r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2567r(t0,t1,t2);}}

static void C_ccall f_2567r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 440  list->f64vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f32vector in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2561r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2561r(t0,t1,t2);}}

static void C_ccall f_2561r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 436  list->f32vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s32vector in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2555r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2555r(t0,t1,t2);}}

static void C_ccall f_2555r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 432  list->s32vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u32vector in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2549r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2549r(t0,t1,t2);}}

static void C_ccall f_2549r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 428  list->u32vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s16vector in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2543r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2543r(t0,t1,t2);}}

static void C_ccall f_2543r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 424  list->s16vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u16vector in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2537r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2537r(t0,t1,t2);}}

static void C_ccall f_2537r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 420  list->u16vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s8vector in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2531r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2531r(t0,t1,t2);}}

static void C_ccall f_2531r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 416  list->s8vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u8vector in k2521 in k2517 in k2513 in k2509 in k2505 in k2501 in k2497 in k2493 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2525r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2525r(t0,t1,t2);}}

static void C_ccall f_2525r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 412  list->u8vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* init in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2455(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2455,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2457,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_2457 in init in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2457,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2467,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 390  make */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k2465 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2472,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2472(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop670 in k2465 */
static void C_fcall f_2472(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2472,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2479,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* srfi-4.scm: 395  set */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[5],t3,(C_word)C_slot(t2,C_fix(0)));}
else{
/* srfi-4.scm: 396  ##sys#error-not-a-proper-list */
t6=*((C_word*)lf[74]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}}

/* k2477 in doloop670 in k2465 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2472(t2,((C_word*)t0)[4],(C_word)C_slot(((C_word*)t0)[3],C_fix(1)),(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2331r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2331r(t0,t1,t2,t3);}}

static void C_ccall f_2331r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2390,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2395,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init613647 */
t8=t7;
f_2395(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?614645 */
t10=t6;
f_2390(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin615642 */
t12=t5;
f_2385(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body611620 */
t14=t4;
f_2333(t14,t1,t8,t10);}}}}

/* def-init613 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2395,NULL,2,t0,t1);}
/* def-ext?614645 */
t2=((C_word*)t0)[2];
f_2390(t2,t1,C_SCHEME_FALSE);}

/* def-ext?614 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2390(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2390,NULL,3,t0,t1,t2);}
/* def-fin615642 */
t3=((C_word*)t0)[2];
f_2385(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin615 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2385(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2385,NULL,4,t0,t1,t2,t3);}
/* body611620 */
t4=((C_word*)t0)[2];
f_2333(t4,t1,t2,t3);}

/* body611 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2333(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2333,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[72]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2384,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 369  alloc */
f_1462(t6,lf[72],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(3)),t3);}

/* k2382 in body611 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2384,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 370  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2343(2,t5,C_SCHEME_UNDEFINED);}}

/* k2341 in k2382 in body611 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[72]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2355(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2374,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 376  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2372 in k2341 in k2382 in body611 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2355(t3,t2);}

/* k2353 in k2341 in k2382 in body611 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2355(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2355,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2360,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2360(t2,C_fix(0)));}

/* doloop631 in k2353 in k2341 in k2382 in body611 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_2360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_f64poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2207r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2207r(t0,t1,t2,t3);}}

static void C_ccall f_2207r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2261,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2266,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2271,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init556590 */
t8=t7;
f_2271(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?557588 */
t10=t6;
f_2266(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin558585 */
t12=t5;
f_2261(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body554563 */
t14=t4;
f_2209(t14,t1,t8,t10);}}}}

/* def-init556 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2271,NULL,2,t0,t1);}
/* def-ext?557588 */
t2=((C_word*)t0)[2];
f_2266(t2,t1,C_SCHEME_FALSE);}

/* def-ext?557 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2266(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2266,NULL,3,t0,t1,t2);}
/* def-fin558585 */
t3=((C_word*)t0)[2];
f_2261(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin558 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2261(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2261,NULL,4,t0,t1,t2,t3);}
/* body554563 */
t4=((C_word*)t0)[2];
f_2209(t4,t1,t2,t3);}

/* body554 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2209(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2209,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 354  alloc */
f_1462(t6,lf[70],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2258 in body554 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2260,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[71],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2219,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 355  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2219(2,t5,C_SCHEME_UNDEFINED);}}

/* k2217 in k2258 in body554 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2219,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[70]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2231(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2250,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 361  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2248 in k2217 in k2258 in body554 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2231(t3,t2);}

/* k2229 in k2217 in k2258 in body554 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2231(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2231,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2236(t2,C_fix(0)));}

/* doloop574 in k2229 in k2217 in k2258 in body554 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_2236(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_f32poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2090r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2090r(t0,t1,t2,t3);}}

static void C_ccall f_2090r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2137,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2142,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init502533 */
t8=t7;
f_2147(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?503531 */
t10=t6;
f_2142(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin504528 */
t12=t5;
f_2137(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body500509 */
t14=t4;
f_2092(t14,t1,t8,t10);}}}}

/* def-init502 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2147(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2147,NULL,2,t0,t1);}
/* def-ext?503531 */
t2=((C_word*)t0)[2];
f_2142(t2,t1,C_SCHEME_FALSE);}

/* def-ext?503 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2142(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2142,NULL,3,t0,t1,t2);}
/* def-fin504528 */
t3=((C_word*)t0)[2];
f_2137(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin504 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2137(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2137,NULL,4,t0,t1,t2,t3);}
/* body500509 */
t4=((C_word*)t0)[2];
f_2092(t4,t1,t2,t3);}

/* body500 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2092(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2092,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2136,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 341  alloc */
f_1462(t5,lf[68],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2134 in body500 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2136,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[69],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 342  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2102(2,t5,C_SCHEME_UNDEFINED);}}

/* k2100 in k2134 in body500 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2116,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2116(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* doloop518 in k2100 in k2134 in body500 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_2116(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_s32poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1973r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1973r(t0,t1,t2,t3);}}

static void C_ccall f_1973r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2020,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2025,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2030,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init448479 */
t8=t7;
f_2030(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?449477 */
t10=t6;
f_2025(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin450474 */
t12=t5;
f_2020(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body446455 */
t14=t4;
f_1975(t14,t1,t8,t10);}}}}

/* def-init448 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2030(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2030,NULL,2,t0,t1);}
/* def-ext?449477 */
t2=((C_word*)t0)[2];
f_2025(t2,t1,C_SCHEME_FALSE);}

/* def-ext?449 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2025(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2025,NULL,3,t0,t1,t2);}
/* def-fin450474 */
t3=((C_word*)t0)[2];
f_2020(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin450 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2020(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2020,NULL,4,t0,t1,t2,t3);}
/* body446455 */
t4=((C_word*)t0)[2];
f_1975(t4,t1,t2,t3);}

/* body446 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1975(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1975,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[66]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 328  alloc */
f_1462(t5,lf[66],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2017 in body446 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2019,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[67],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 329  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1985(2,t5,C_SCHEME_UNDEFINED);}}

/* k1983 in k2017 in body446 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1985,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[66]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1999(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* doloop464 in k1983 in k2017 in body446 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_1999(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_u32poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1856r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1856r(t0,t1,t2,t3);}}

static void C_ccall f_1856r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1903,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1913,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init394425 */
t8=t7;
f_1913(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?395423 */
t10=t6;
f_1908(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin396420 */
t12=t5;
f_1903(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body392401 */
t14=t4;
f_1858(t14,t1,t8,t10);}}}}

/* def-init394 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1913,NULL,2,t0,t1);}
/* def-ext?395423 */
t2=((C_word*)t0)[2];
f_1908(t2,t1,C_SCHEME_FALSE);}

/* def-ext?395 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1908(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1908,NULL,3,t0,t1,t2);}
/* def-fin396420 */
t3=((C_word*)t0)[2];
f_1903(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin396 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1903(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1903,NULL,4,t0,t1,t2,t3);}
/* body392401 */
t4=((C_word*)t0)[2];
f_1858(t4,t1,t2,t3);}

/* body392 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1858(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1858,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[64]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 315  alloc */
f_1462(t5,lf[64],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1900 in body392 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[65],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1868,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 316  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1868(2,t5,C_SCHEME_UNDEFINED);}}

/* k1866 in k1900 in body392 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1868,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 320  ##sys#check-exact-interval */
t4=*((C_word*)lf[0]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-32768),C_fix(32767),lf[64]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1875 in k1866 in k1900 in body392 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1882(t2,C_fix(0)));}

/* doloop410 in k1875 in k1866 in k1900 in body392 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_1882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_s16poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1739r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1739r(t0,t1,t2,t3);}}

static void C_ccall f_1739r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1786,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1796,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init340371 */
t8=t7;
f_1796(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?341369 */
t10=t6;
f_1791(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin342366 */
t12=t5;
f_1786(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body338347 */
t14=t4;
f_1741(t14,t1,t8,t10);}}}}

/* def-init340 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1796(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1796,NULL,2,t0,t1);}
/* def-ext?341369 */
t2=((C_word*)t0)[2];
f_1791(t2,t1,C_SCHEME_FALSE);}

/* def-ext?341 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1791(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1791,NULL,3,t0,t1,t2);}
/* def-fin342366 */
t3=((C_word*)t0)[2];
f_1786(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin342 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1786(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1786,NULL,4,t0,t1,t2,t3);}
/* body338347 */
t4=((C_word*)t0)[2];
f_1741(t4,t1,t2,t3);}

/* body338 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1741(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1741,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[62]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 302  alloc */
f_1462(t5,lf[62],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1783 in body338 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1785,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[63],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1751,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 303  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1751(2,t5,C_SCHEME_UNDEFINED);}}

/* k1749 in k1783 in body338 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1751,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 307  ##sys#check-exact-interval */
t4=*((C_word*)lf[0]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(65535),lf[62]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1758 in k1749 in k1783 in body338 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1765(t2,C_fix(0)));}

/* doloop356 in k1758 in k1749 in k1783 in body338 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_1765(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_u16poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1622r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1622r(t0,t1,t2,t3);}}

static void C_ccall f_1622r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1669,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1674,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1679,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init286317 */
t8=t7;
f_1679(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?287315 */
t10=t6;
f_1674(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin288312 */
t12=t5;
f_1669(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body284293 */
t14=t4;
f_1624(t14,t1,t8,t10);}}}}

/* def-init286 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1679(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1679,NULL,2,t0,t1);}
/* def-ext?287315 */
t2=((C_word*)t0)[2];
f_1674(t2,t1,C_SCHEME_FALSE);}

/* def-ext?287 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1674(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1674,NULL,3,t0,t1,t2);}
/* def-fin288312 */
t3=((C_word*)t0)[2];
f_1669(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin288 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1669(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1669,NULL,4,t0,t1,t2,t3);}
/* body284293 */
t4=((C_word*)t0)[2];
f_1624(t4,t1,t2,t3);}

/* body284 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1624(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1624,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[59]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1668,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 289  alloc */
f_1462(t5,lf[59],((C_word*)t0)[5],t3);}

/* k1666 in body284 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1668,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[60],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1634,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 290  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1634(2,t5,C_SCHEME_UNDEFINED);}}

/* k1632 in k1666 in body284 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1634,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 294  ##sys#check-exact-interval */
t4=*((C_word*)lf[0]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-128),C_fix(127),lf[59]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1641 in k1632 in k1666 in body284 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1648(t2,C_fix(0)));}

/* doloop302 in k1641 in k1632 in k1666 in body284 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_1648(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_s8poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1505r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1505r(t0,t1,t2,t3);}}

static void C_ccall f_1505r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1552,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1557,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1562,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init231262 */
t8=t7;
f_1562(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?232260 */
t10=t6;
f_1557(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin?233257 */
t12=t5;
f_1552(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body229238 */
t14=t4;
f_1507(t14,t1,t8,t10,t12);}}}}

/* def-init231 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1562(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1562,NULL,2,t0,t1);}
/* def-ext?232260 */
t2=((C_word*)t0)[2];
f_1557(t2,t1,C_SCHEME_FALSE);}

/* def-ext?232 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1557(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1557,NULL,3,t0,t1,t2);}
/* def-fin?233257 */
t3=((C_word*)t0)[2];
f_1552(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin?233 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1552(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1552,NULL,4,t0,t1,t2,t3);}
/* body229238 */
t4=((C_word*)t0)[2];
f_1507(t4,t1,t2,t3,C_SCHEME_TRUE);}

/* body229 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1507(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1507,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[57]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* srfi-4.scm: 276  alloc */
f_1462(t6,lf[57],((C_word*)t0)[5],t3);}

/* k1549 in body229 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1551,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[58],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1517,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 277  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1517(2,t5,C_SCHEME_UNDEFINED);}}

/* k1515 in k1549 in body229 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1517,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 281  ##sys#check-exact-interval */
t4=*((C_word*)lf[0]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(255),lf[57]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1524 in k1515 in k1549 in body229 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1531,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1531(t2,C_fix(0)));}

/* doloop247 in k1524 in k1515 in k1549 in body229 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_1531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_u8poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* release-number-vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1480,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1487,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1487(t5,(C_word)C_u_i_memq(t4,lf[56]));}
else{
t4=t3;
f_1487(t4,C_SCHEME_FALSE);}}

/* k1485 in release-number-vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1487(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub196(C_SCHEME_UNDEFINED,t3));}
else{
/* srfi-4.scm: 271  ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[54],lf[55],((C_word*)t0)[2]);}}

/* alloc in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1462(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1462,NULL,4,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=t3;
t6=(C_word)stub191(C_SCHEME_UNDEFINED,t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* srfi-4.scm: 261  ##sys#error */
t7=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,lf[52],t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1478,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 262  ##sys#allocate-vector */
t6=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}}

/* k1476 in alloc in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_string_to_bytevector(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* ext-free in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1460,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub196(C_SCHEME_UNDEFINED,t2));}

/* f_1310 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1310,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1314,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 179  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1312 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1317,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fits_in_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1317(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 181  ##sys#error */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[39],lf[40],((C_word*)t0)[2]);}}

/* k1315 in k1312 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 182  ##sys#check-range */
t3=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[39]);}

/* k1318 in k1315 in k1312 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_s32poke((C_word)C_slot(t3,C_fix(1)),t4,t5));}

/* f_1337 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1337,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1341,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 187  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1339 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1344,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_negativep(((C_word*)t0)[2]))){
/* srfi-4.scm: 189  ##sys#error */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[36],lf[37],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_fits_in_unsigned_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1344(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 191  ##sys#error */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[36],lf[38],((C_word*)t0)[2]);}}}

/* k1342 in k1339 */
static void C_ccall f_1344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1347,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 192  ##sys#check-range */
t3=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[36]);}

/* k1345 in k1342 in k1339 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u32poke((C_word)C_slot(t3,C_fix(1)),t4,t5));}

/* setf in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1371(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1371,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1373,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_1373 in setf in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1373,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1377,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 197  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1375 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1377,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1383,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 199  ##sys#check-range */
t4=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1381 in k1375 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)t0)[2]))){
t3=t2;
f_1390(2,t3,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 202  exact->inexact */
C_exact_to_inexact(3,0,t2,((C_word*)t0)[2]);}}

/* k1388 in k1381 in k1375 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 200  upd */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setu in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1282(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1282,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1284,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_1284 in setu in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1284,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1288,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 170  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1286 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1288,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[7],C_fix(0)))){
/* srfi-4.scm: 173  ##sys#error */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[6],lf[31],((C_word*)t0)[7]);}
else{
t4=t3;
f_1294(2,t4,C_SCHEME_UNDEFINED);}}

/* k1292 in k1286 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 174  ##sys#check-range */
t3=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1295 in k1292 in k1286 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 175  upd */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1265(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1265,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1267,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_1267 in set in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1267,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1271,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 163  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1269 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1271,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 165  ##sys#check-range */
t4=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1275 in k1269 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 166  upd */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* get in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1251(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1251,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1253,a[2]=t2,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp));}

/* f_1253 in get in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1253,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1257,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 157  length */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1255 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 158  ##sys#check-range */
t3=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),t1,((C_word*)t0)[2]);}

/* k1258 in k1255 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 159  acc */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* len */
static void C_fcall f_1208(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1208,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1210,a[2]=t3,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));}

/* f_1210 in len */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1210,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_block_size((C_word)C_slot(t2,C_fix(1)));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_shift_right(t4,((C_word*)t0)[2]):t4));}

/* ##sys#f64vector-set! */
static void C_ccall f_1205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1205,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f64poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f32vector-set! */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1202,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s32vector-set! */
static void C_ccall f_1199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1199,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u32vector-set! */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1196,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s16vector-set! */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1193,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u16vector-set! */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1190,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s8vector-set! */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1187,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u8vector-set! */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1184,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f64vector-ref */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1178,4,t0,t1,t2,t3);}
t4=(C_word)C_f64peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 117  ##sys#cons-flonum */
t5=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#f32vector-ref */
static void C_ccall f_1172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1172,4,t0,t1,t2,t3);}
t4=(C_word)C_f32peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 113  ##sys#cons-flonum */
t5=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#s32vector-ref */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1169,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_s32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u32vector-ref */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1166,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_u32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s16vector-ref */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1163,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u16vector-ref */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1160,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s8vector-ref */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1157,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u8vector-ref */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1154,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#check-inexact-interval */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1133,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_number_2(t2,t5);
t7=(C_word)C_i_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_i_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 99   ##sys#error */
t9=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,lf[4],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* ##sys#check-exact-interval */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1118,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_exact_2(t2,t5);
t7=(C_word)C_fixnum_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 93   ##sys#error */
t9=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t9+1)))(7,t9,t1,t5,lf[2],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[288] = {
{"toplevel:srfi_4_scm",(void*)C_srfi_4_toplevel},
{"f_1221:srfi_4_scm",(void*)f_1221},
{"f_1225:srfi_4_scm",(void*)f_1225},
{"f_1229:srfi_4_scm",(void*)f_1229},
{"f_1233:srfi_4_scm",(void*)f_1233},
{"f_1237:srfi_4_scm",(void*)f_1237},
{"f_1241:srfi_4_scm",(void*)f_1241},
{"f_1245:srfi_4_scm",(void*)f_1245},
{"f_1249:srfi_4_scm",(void*)f_1249},
{"f_1397:srfi_4_scm",(void*)f_1397},
{"f_1401:srfi_4_scm",(void*)f_1401},
{"f_1405:srfi_4_scm",(void*)f_1405},
{"f_1409:srfi_4_scm",(void*)f_1409},
{"f_1421:srfi_4_scm",(void*)f_1421},
{"f_1425:srfi_4_scm",(void*)f_1425},
{"f_3583:srfi_4_scm",(void*)f_3583},
{"f_1429:srfi_4_scm",(void*)f_1429},
{"f_3579:srfi_4_scm",(void*)f_3579},
{"f_1433:srfi_4_scm",(void*)f_1433},
{"f_3575:srfi_4_scm",(void*)f_3575},
{"f_1437:srfi_4_scm",(void*)f_1437},
{"f_3571:srfi_4_scm",(void*)f_3571},
{"f_1441:srfi_4_scm",(void*)f_1441},
{"f_3567:srfi_4_scm",(void*)f_3567},
{"f_1445:srfi_4_scm",(void*)f_1445},
{"f_3563:srfi_4_scm",(void*)f_3563},
{"f_1449:srfi_4_scm",(void*)f_1449},
{"f_3559:srfi_4_scm",(void*)f_3559},
{"f_1453:srfi_4_scm",(void*)f_1453},
{"f_3555:srfi_4_scm",(void*)f_3555},
{"f_1457:srfi_4_scm",(void*)f_1457},
{"f_2495:srfi_4_scm",(void*)f_2495},
{"f_2499:srfi_4_scm",(void*)f_2499},
{"f_2503:srfi_4_scm",(void*)f_2503},
{"f_2507:srfi_4_scm",(void*)f_2507},
{"f_2511:srfi_4_scm",(void*)f_2511},
{"f_2515:srfi_4_scm",(void*)f_2515},
{"f_2519:srfi_4_scm",(void*)f_2519},
{"f_2523:srfi_4_scm",(void*)f_2523},
{"f_2610:srfi_4_scm",(void*)f_2610},
{"f_2614:srfi_4_scm",(void*)f_2614},
{"f_2618:srfi_4_scm",(void*)f_2618},
{"f_2622:srfi_4_scm",(void*)f_2622},
{"f_2626:srfi_4_scm",(void*)f_2626},
{"f_2630:srfi_4_scm",(void*)f_2630},
{"f_2634:srfi_4_scm",(void*)f_2634},
{"f_2638:srfi_4_scm",(void*)f_2638},
{"f_2780:srfi_4_scm",(void*)f_2780},
{"f_2784:srfi_4_scm",(void*)f_2784},
{"f_2788:srfi_4_scm",(void*)f_2788},
{"f_2792:srfi_4_scm",(void*)f_2792},
{"f_2796:srfi_4_scm",(void*)f_2796},
{"f_2800:srfi_4_scm",(void*)f_2800},
{"f_2804:srfi_4_scm",(void*)f_2804},
{"f_2808:srfi_4_scm",(void*)f_2808},
{"f_2812:srfi_4_scm",(void*)f_2812},
{"f_2816:srfi_4_scm",(void*)f_2816},
{"f_2820:srfi_4_scm",(void*)f_2820},
{"f_2824:srfi_4_scm",(void*)f_2824},
{"f_2828:srfi_4_scm",(void*)f_2828},
{"f_2832:srfi_4_scm",(void*)f_2832},
{"f_2836:srfi_4_scm",(void*)f_2836},
{"f_2840:srfi_4_scm",(void*)f_2840},
{"f_2844:srfi_4_scm",(void*)f_2844},
{"f_2848:srfi_4_scm",(void*)f_2848},
{"f_2852:srfi_4_scm",(void*)f_2852},
{"f_2856:srfi_4_scm",(void*)f_2856},
{"f_2860:srfi_4_scm",(void*)f_2860},
{"f_2864:srfi_4_scm",(void*)f_2864},
{"f_2868:srfi_4_scm",(void*)f_2868},
{"f_2872:srfi_4_scm",(void*)f_2872},
{"f_2876:srfi_4_scm",(void*)f_2876},
{"f_2880:srfi_4_scm",(void*)f_2880},
{"f_2884:srfi_4_scm",(void*)f_2884},
{"f_2888:srfi_4_scm",(void*)f_2888},
{"f_2892:srfi_4_scm",(void*)f_2892},
{"f_2896:srfi_4_scm",(void*)f_2896},
{"f_2900:srfi_4_scm",(void*)f_2900},
{"f_2904:srfi_4_scm",(void*)f_2904},
{"f_3551:srfi_4_scm",(void*)f_3551},
{"f_3436:srfi_4_scm",(void*)f_3436},
{"f_3505:srfi_4_scm",(void*)f_3505},
{"f_3500:srfi_4_scm",(void*)f_3500},
{"f_3438:srfi_4_scm",(void*)f_3438},
{"f_3442:srfi_4_scm",(void*)f_3442},
{"f_3469:srfi_4_scm",(void*)f_3469},
{"f_3474:srfi_4_scm",(void*)f_3474},
{"f_3478:srfi_4_scm",(void*)f_3478},
{"f_3496:srfi_4_scm",(void*)f_3496},
{"f_3487:srfi_4_scm",(void*)f_3487},
{"f_3451:srfi_4_scm",(void*)f_3451},
{"f_3454:srfi_4_scm",(void*)f_3454},
{"f_3427:srfi_4_scm",(void*)f_3427},
{"f_3435:srfi_4_scm",(void*)f_3435},
{"f_3329:srfi_4_scm",(void*)f_3329},
{"f_3381:srfi_4_scm",(void*)f_3381},
{"f_3376:srfi_4_scm",(void*)f_3376},
{"f_3331:srfi_4_scm",(void*)f_3331},
{"f_3335:srfi_4_scm",(void*)f_3335},
{"f_3347:srfi_4_scm",(void*)f_3347},
{"f_3216:srfi_4_scm",(void*)f_3216},
{"f_3269:srfi_4_scm",(void*)f_3269},
{"f_3264:srfi_4_scm",(void*)f_3264},
{"f_3255:srfi_4_scm",(void*)f_3255},
{"f_3218:srfi_4_scm",(void*)f_3218},
{"f_3225:srfi_4_scm",(void*)f_3225},
{"f_3233:srfi_4_scm",(void*)f_3233},
{"f_3243:srfi_4_scm",(void*)f_3243},
{"f_3210:srfi_4_scm",(void*)f_3210},
{"f_3204:srfi_4_scm",(void*)f_3204},
{"f_3198:srfi_4_scm",(void*)f_3198},
{"f_3192:srfi_4_scm",(void*)f_3192},
{"f_3186:srfi_4_scm",(void*)f_3186},
{"f_3180:srfi_4_scm",(void*)f_3180},
{"f_3174:srfi_4_scm",(void*)f_3174},
{"f_3168:srfi_4_scm",(void*)f_3168},
{"f_3125:srfi_4_scm",(void*)f_3125},
{"f_3138:srfi_4_scm",(void*)f_3138},
{"f_3141:srfi_4_scm",(void*)f_3141},
{"f_3147:srfi_4_scm",(void*)f_3147},
{"f_2965:srfi_4_scm",(void*)f_2965},
{"f_2975:srfi_4_scm",(void*)f_2975},
{"f_2978:srfi_4_scm",(void*)f_2978},
{"f_2985:srfi_4_scm",(void*)f_2985},
{"f_2909:srfi_4_scm",(void*)f_2909},
{"f_2919:srfi_4_scm",(void*)f_2919},
{"f_2944:srfi_4_scm",(void*)f_2944},
{"f_2746:srfi_4_scm",(void*)f_2746},
{"f_2748:srfi_4_scm",(void*)f_2748},
{"f_2758:srfi_4_scm",(void*)f_2758},
{"f_2717:srfi_4_scm",(void*)f_2717},
{"f_2719:srfi_4_scm",(void*)f_2719},
{"f_2699:srfi_4_scm",(void*)f_2699},
{"f_2701:srfi_4_scm",(void*)f_2701},
{"f_2711:srfi_4_scm",(void*)f_2711},
{"f_2688:srfi_4_scm",(void*)f_2688},
{"f_2690:srfi_4_scm",(void*)f_2690},
{"f_2682:srfi_4_scm",(void*)f_2682},
{"f_2676:srfi_4_scm",(void*)f_2676},
{"f_2670:srfi_4_scm",(void*)f_2670},
{"f_2664:srfi_4_scm",(void*)f_2664},
{"f_2658:srfi_4_scm",(void*)f_2658},
{"f_2652:srfi_4_scm",(void*)f_2652},
{"f_2646:srfi_4_scm",(void*)f_2646},
{"f_2640:srfi_4_scm",(void*)f_2640},
{"f_2573:srfi_4_scm",(void*)f_2573},
{"f_2575:srfi_4_scm",(void*)f_2575},
{"f_2579:srfi_4_scm",(void*)f_2579},
{"f_2584:srfi_4_scm",(void*)f_2584},
{"f_2598:srfi_4_scm",(void*)f_2598},
{"f_2602:srfi_4_scm",(void*)f_2602},
{"f_2567:srfi_4_scm",(void*)f_2567},
{"f_2561:srfi_4_scm",(void*)f_2561},
{"f_2555:srfi_4_scm",(void*)f_2555},
{"f_2549:srfi_4_scm",(void*)f_2549},
{"f_2543:srfi_4_scm",(void*)f_2543},
{"f_2537:srfi_4_scm",(void*)f_2537},
{"f_2531:srfi_4_scm",(void*)f_2531},
{"f_2525:srfi_4_scm",(void*)f_2525},
{"f_2455:srfi_4_scm",(void*)f_2455},
{"f_2457:srfi_4_scm",(void*)f_2457},
{"f_2467:srfi_4_scm",(void*)f_2467},
{"f_2472:srfi_4_scm",(void*)f_2472},
{"f_2479:srfi_4_scm",(void*)f_2479},
{"f_2331:srfi_4_scm",(void*)f_2331},
{"f_2395:srfi_4_scm",(void*)f_2395},
{"f_2390:srfi_4_scm",(void*)f_2390},
{"f_2385:srfi_4_scm",(void*)f_2385},
{"f_2333:srfi_4_scm",(void*)f_2333},
{"f_2384:srfi_4_scm",(void*)f_2384},
{"f_2343:srfi_4_scm",(void*)f_2343},
{"f_2374:srfi_4_scm",(void*)f_2374},
{"f_2355:srfi_4_scm",(void*)f_2355},
{"f_2360:srfi_4_scm",(void*)f_2360},
{"f_2207:srfi_4_scm",(void*)f_2207},
{"f_2271:srfi_4_scm",(void*)f_2271},
{"f_2266:srfi_4_scm",(void*)f_2266},
{"f_2261:srfi_4_scm",(void*)f_2261},
{"f_2209:srfi_4_scm",(void*)f_2209},
{"f_2260:srfi_4_scm",(void*)f_2260},
{"f_2219:srfi_4_scm",(void*)f_2219},
{"f_2250:srfi_4_scm",(void*)f_2250},
{"f_2231:srfi_4_scm",(void*)f_2231},
{"f_2236:srfi_4_scm",(void*)f_2236},
{"f_2090:srfi_4_scm",(void*)f_2090},
{"f_2147:srfi_4_scm",(void*)f_2147},
{"f_2142:srfi_4_scm",(void*)f_2142},
{"f_2137:srfi_4_scm",(void*)f_2137},
{"f_2092:srfi_4_scm",(void*)f_2092},
{"f_2136:srfi_4_scm",(void*)f_2136},
{"f_2102:srfi_4_scm",(void*)f_2102},
{"f_2116:srfi_4_scm",(void*)f_2116},
{"f_1973:srfi_4_scm",(void*)f_1973},
{"f_2030:srfi_4_scm",(void*)f_2030},
{"f_2025:srfi_4_scm",(void*)f_2025},
{"f_2020:srfi_4_scm",(void*)f_2020},
{"f_1975:srfi_4_scm",(void*)f_1975},
{"f_2019:srfi_4_scm",(void*)f_2019},
{"f_1985:srfi_4_scm",(void*)f_1985},
{"f_1999:srfi_4_scm",(void*)f_1999},
{"f_1856:srfi_4_scm",(void*)f_1856},
{"f_1913:srfi_4_scm",(void*)f_1913},
{"f_1908:srfi_4_scm",(void*)f_1908},
{"f_1903:srfi_4_scm",(void*)f_1903},
{"f_1858:srfi_4_scm",(void*)f_1858},
{"f_1902:srfi_4_scm",(void*)f_1902},
{"f_1868:srfi_4_scm",(void*)f_1868},
{"f_1877:srfi_4_scm",(void*)f_1877},
{"f_1882:srfi_4_scm",(void*)f_1882},
{"f_1739:srfi_4_scm",(void*)f_1739},
{"f_1796:srfi_4_scm",(void*)f_1796},
{"f_1791:srfi_4_scm",(void*)f_1791},
{"f_1786:srfi_4_scm",(void*)f_1786},
{"f_1741:srfi_4_scm",(void*)f_1741},
{"f_1785:srfi_4_scm",(void*)f_1785},
{"f_1751:srfi_4_scm",(void*)f_1751},
{"f_1760:srfi_4_scm",(void*)f_1760},
{"f_1765:srfi_4_scm",(void*)f_1765},
{"f_1622:srfi_4_scm",(void*)f_1622},
{"f_1679:srfi_4_scm",(void*)f_1679},
{"f_1674:srfi_4_scm",(void*)f_1674},
{"f_1669:srfi_4_scm",(void*)f_1669},
{"f_1624:srfi_4_scm",(void*)f_1624},
{"f_1668:srfi_4_scm",(void*)f_1668},
{"f_1634:srfi_4_scm",(void*)f_1634},
{"f_1643:srfi_4_scm",(void*)f_1643},
{"f_1648:srfi_4_scm",(void*)f_1648},
{"f_1505:srfi_4_scm",(void*)f_1505},
{"f_1562:srfi_4_scm",(void*)f_1562},
{"f_1557:srfi_4_scm",(void*)f_1557},
{"f_1552:srfi_4_scm",(void*)f_1552},
{"f_1507:srfi_4_scm",(void*)f_1507},
{"f_1551:srfi_4_scm",(void*)f_1551},
{"f_1517:srfi_4_scm",(void*)f_1517},
{"f_1526:srfi_4_scm",(void*)f_1526},
{"f_1531:srfi_4_scm",(void*)f_1531},
{"f_1480:srfi_4_scm",(void*)f_1480},
{"f_1487:srfi_4_scm",(void*)f_1487},
{"f_1462:srfi_4_scm",(void*)f_1462},
{"f_1478:srfi_4_scm",(void*)f_1478},
{"f_1460:srfi_4_scm",(void*)f_1460},
{"f_1310:srfi_4_scm",(void*)f_1310},
{"f_1314:srfi_4_scm",(void*)f_1314},
{"f_1317:srfi_4_scm",(void*)f_1317},
{"f_1320:srfi_4_scm",(void*)f_1320},
{"f_1337:srfi_4_scm",(void*)f_1337},
{"f_1341:srfi_4_scm",(void*)f_1341},
{"f_1344:srfi_4_scm",(void*)f_1344},
{"f_1347:srfi_4_scm",(void*)f_1347},
{"f_1371:srfi_4_scm",(void*)f_1371},
{"f_1373:srfi_4_scm",(void*)f_1373},
{"f_1377:srfi_4_scm",(void*)f_1377},
{"f_1383:srfi_4_scm",(void*)f_1383},
{"f_1390:srfi_4_scm",(void*)f_1390},
{"f_1282:srfi_4_scm",(void*)f_1282},
{"f_1284:srfi_4_scm",(void*)f_1284},
{"f_1288:srfi_4_scm",(void*)f_1288},
{"f_1294:srfi_4_scm",(void*)f_1294},
{"f_1297:srfi_4_scm",(void*)f_1297},
{"f_1265:srfi_4_scm",(void*)f_1265},
{"f_1267:srfi_4_scm",(void*)f_1267},
{"f_1271:srfi_4_scm",(void*)f_1271},
{"f_1277:srfi_4_scm",(void*)f_1277},
{"f_1251:srfi_4_scm",(void*)f_1251},
{"f_1253:srfi_4_scm",(void*)f_1253},
{"f_1257:srfi_4_scm",(void*)f_1257},
{"f_1260:srfi_4_scm",(void*)f_1260},
{"f_1208:srfi_4_scm",(void*)f_1208},
{"f_1210:srfi_4_scm",(void*)f_1210},
{"f_1205:srfi_4_scm",(void*)f_1205},
{"f_1202:srfi_4_scm",(void*)f_1202},
{"f_1199:srfi_4_scm",(void*)f_1199},
{"f_1196:srfi_4_scm",(void*)f_1196},
{"f_1193:srfi_4_scm",(void*)f_1193},
{"f_1190:srfi_4_scm",(void*)f_1190},
{"f_1187:srfi_4_scm",(void*)f_1187},
{"f_1184:srfi_4_scm",(void*)f_1184},
{"f_1178:srfi_4_scm",(void*)f_1178},
{"f_1172:srfi_4_scm",(void*)f_1172},
{"f_1169:srfi_4_scm",(void*)f_1169},
{"f_1166:srfi_4_scm",(void*)f_1166},
{"f_1163:srfi_4_scm",(void*)f_1163},
{"f_1160:srfi_4_scm",(void*)f_1160},
{"f_1157:srfi_4_scm",(void*)f_1157},
{"f_1154:srfi_4_scm",(void*)f_1154},
{"f_1133:srfi_4_scm",(void*)f_1133},
{"f_1118:srfi_4_scm",(void*)f_1118},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
