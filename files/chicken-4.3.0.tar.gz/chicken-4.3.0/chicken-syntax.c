/* Generated from chicken-syntax.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:01
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: chicken-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -output-file chicken-syntax.c
   unit: chicken_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[244];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,28),40,97,49,52,48,49,32,102,111,114,109,49,50,49,55,32,114,49,50,49,56,32,99,49,50,49,57,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,32),40,97,49,52,52,55,32,110,97,109,101,49,50,49,53,32,116,114,97,110,115,102,111,114,109,101,114,49,50,49,54,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,20),40,97,49,52,53,55,32,116,101,109,112,49,49,55,52,49,50,49,51,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,20),40,97,49,52,55,49,32,116,101,109,112,49,49,55,52,49,50,49,49,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,49,54,57,32,108,49,49,54,52,49,49,57,50,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,52),40,97,49,52,49,49,32,105,110,112,117,116,49,49,54,51,49,49,55,54,32,114,101,110,97,109,101,49,49,55,50,49,49,55,55,32,99,111,109,112,97,114,101,49,49,54,48,49,49,55,56,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,52),40,97,49,53,53,56,32,105,110,112,117,116,49,49,49,54,49,49,50,57,32,114,101,110,97,109,101,49,49,50,53,49,49,51,48,32,99,111,109,112,97,114,101,49,49,49,51,49,49,51,49,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,25),40,97,49,54,57,48,32,120,49,49,48,51,32,114,49,49,48,52,32,99,49,49,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,28),40,97,49,55,49,53,32,102,111,114,109,49,48,57,53,32,114,49,48,57,54,32,99,49,48,57,55,41,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,28),40,97,49,55,53,50,32,102,111,114,109,49,48,56,49,32,114,49,48,56,50,32,99,49,48,56,51,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,37),40,108,111,111,112,32,115,49,48,51,55,32,100,49,48,51,56,32,99,115,49,48,51,57,32,101,120,112,111,114,116,115,49,48,52,48,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,28),40,97,49,56,53,54,32,102,111,114,109,49,48,50,56,32,114,49,48,50,57,32,99,49,48,51,48,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,47),40,108,111,111,112,32,120,115,49,48,48,51,32,118,97,114,115,49,48,48,52,32,98,115,49,48,48,53,32,118,97,108,115,49,48,48,54,32,114,101,115,116,49,48,48,55,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,25),40,97,50,49,51,55,32,102,111,114,109,57,57,52,32,114,57,57,53,32,99,57,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,36),40,108,111,111,112,32,120,115,57,54,55,32,118,97,114,115,57,54,56,32,118,97,108,115,57,54,57,32,114,101,115,116,57,55,48,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,97,50,51,54,56,32,102,111,114,109,57,53,56,32,114,57,53,57,32,99,57,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,115,108,111,116,115,57,50,55,32,105,57,50,56,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,16),40,97,50,57,50,57,32,115,110,97,109,101,57,50,53,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,25),40,97,50,53,54,56,32,102,111,114,109,57,48,52,32,114,57,48,53,32,99,57,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,12),40,97,51,49,50,49,32,107,56,56,53,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,19),40,112,97,114,115,101,45,99,108,97,117,115,101,32,99,56,54,50,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,25),40,97,50,57,55,48,32,102,111,114,109,56,52,55,32,114,56,52,56,32,99,56,52,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,25),40,97,51,51,50,52,32,102,111,114,109,56,51,50,32,114,56,51,51,32,99,56,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,25),40,97,51,53,51,56,32,102,111,114,109,56,48,54,32,114,56,48,55,32,99,56,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,51,48,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,14),40,103,101,110,118,97,114,115,32,110,55,50,56,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,7),40,97,51,55,57,51,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,25),40,98,117,105,108,100,32,118,97,114,115,50,55,55,54,32,118,114,101,115,116,55,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,25),40,97,51,56,48,51,32,118,97,114,115,49,55,55,50,32,118,97,114,115,50,55,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,31),40,97,51,55,54,49,32,118,97,114,115,55,53,52,32,97,114,103,99,55,53,53,32,114,101,115,116,55,53,54,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,20),40,97,51,55,53,49,32,99,55,53,50,32,98,111,100,121,55,53,51,41,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,31),40,97,52,48,52,54,32,118,97,114,115,55,51,53,32,97,114,103,99,55,51,54,32,114,101,115,116,55,51,55,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,12),40,97,52,48,51,54,32,99,55,51,52,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,25),40,97,51,54,52,48,32,102,111,114,109,55,50,52,32,114,55,50,53,32,99,55,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,97,114,103,115,55,48,50,32,118,97,114,100,101,102,115,55,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,25),40,97,52,49,48,53,32,102,111,114,109,54,56,53,32,114,54,56,54,32,99,54,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,25),40,97,52,52,49,57,32,102,111,114,109,54,54,54,32,114,54,54,55,32,99,54,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,54),40,114,101,99,117,114,32,118,97,114,115,54,49,48,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,54,49,49,32,100,101,102,115,54,49,50,32,110,101,120,116,45,103,117,121,54,49,51,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,100,101,102,97,117,108,116,45,112,114,111,99,115,32,118,97,114,115,54,48,52,32,98,111,100,121,45,112,114,111,99,54,48,53,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,54,48,54,32,100,101,102,115,54,48,55,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,45),40,114,101,99,117,114,32,118,97,114,115,54,50,54,32,100,101,102,97,117,108,116,101,114,115,54,50,55,32,110,111,110,45,100,101,102,97,117,108,116,115,54,50,56,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,57),40,109,97,107,101,45,105,102,45,116,114,101,101,32,118,97,114,115,54,50,48,32,100,101,102,97,117,108,116,101,114,115,54,50,49,32,98,111,100,121,45,112,114,111,99,54,50,50,32,114,101,115,116,54,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,29),40,112,114,101,102,105,120,45,115,121,109,32,112,114,101,102,105,120,54,52,50,32,115,121,109,54,52,51,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,14),40,97,53,48,53,53,32,118,97,114,54,53,48,41,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,12),40,97,53,48,54,53,32,118,54,52,53,41,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,25),40,97,52,54,52,52,32,102,111,114,109,53,57,51,32,114,53,57,52,32,99,53,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,97,53,50,50,55,32,120,53,56,49,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,19),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,53,55,48,41,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,25),40,97,53,48,57,57,32,102,111,114,109,53,53,53,32,114,53,53,54,32,99,53,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,12),40,102,111,108,100,32,98,115,53,50,55,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,25),40,97,53,50,54,53,32,102,111,114,109,53,49,57,32,114,53,50,48,32,99,53,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,26),40,113,117,111,116,105,102,121,45,112,114,111,99,32,120,115,52,57,53,32,105,100,52,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,25),40,97,53,52,50,56,32,102,111,114,109,52,57,48,32,114,52,57,49,32,99,52,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,25),40,97,53,53,51,51,32,102,111,114,109,52,56,48,32,114,52,56,49,32,99,52,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,13),40,108,111,111,107,117,112,32,118,52,53,57,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,12),40,97,53,55,49,48,32,118,52,55,48,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,13),40,97,53,54,55,50,32,118,98,52,54,53,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,12),40,97,53,55,52,56,32,118,52,54,52,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,12),40,97,53,55,53,52,32,118,52,53,55,41,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,12),40,97,53,55,55,50,32,120,52,53,53,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,25),40,97,53,54,49,54,32,102,111,114,109,52,52,54,32,114,52,52,55,32,99,52,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,19),40,102,111,108,100,32,118,98,105,110,100,105,110,103,115,52,51,53,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,25),40,97,53,55,56,50,32,102,111,114,109,52,50,55,32,114,52,50,56,32,99,52,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,97,112,112,101,110,100,42,32,105,108,51,53,51,32,108,51,53,52,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,19),40,109,97,112,42,32,112,114,111,99,51,53,53,32,108,51,53,54,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,13),40,108,111,111,107,117,112,32,118,51,56,50,41,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,12),40,97,53,57,57,54,32,118,52,49,49,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,35),40,102,111,108,100,32,108,108,105,115,116,115,51,57,56,32,101,120,112,115,51,57,57,32,108,108,105,115,116,115,50,52,48,48,41,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,12),40,97,54,49,51,50,32,120,52,50,51,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,51,56,53,32,97,99,99,51,56,54,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,12),40,97,54,49,56,52,32,118,51,56,48,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,51,54,55,32,97,99,99,51,54,56,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,25),40,97,53,56,53,52,32,102,111,114,109,51,52,52,32,114,51,52,53,32,99,51,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,51,50,52,32,108,115,116,51,50,53,51,50,56,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,25),40,97,54,50,52,50,32,102,111,114,109,51,49,57,32,114,51,50,48,32,99,51,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,17),40,97,54,52,49,53,32,118,51,49,50,32,97,51,49,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,25),40,97,54,51,48,48,32,102,111,114,109,50,56,55,32,114,50,56,56,32,99,50,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,25),40,97,54,52,52,53,32,102,111,114,109,50,55,57,32,114,50,56,48,32,99,50,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,25),40,97,54,52,57,56,32,102,111,114,109,50,55,49,32,114,50,55,50,32,99,50,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,18),40,97,54,54,53,57,32,97,50,54,52,32,97,50,50,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,12),40,97,54,55,50,49,32,122,50,53,57,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,12),40,97,54,55,51,49,32,122,50,53,55,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,25),40,97,54,53,52,51,32,102,111,114,109,50,52,53,32,114,50,52,54,32,99,50,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,115,50,49,55,41,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,25),40,97,54,55,52,53,32,102,111,114,109,49,57,57,32,114,50,48,48,32,99,50,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,19),40,97,54,57,54,52,32,105,100,49,57,50,32,111,116,49,57,51,41,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,19),40,97,54,57,55,56,32,110,116,49,56,54,32,105,100,49,56,55,41,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,19),40,97,55,48,50,56,32,105,100,49,56,48,32,110,116,49,56,49,41,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,19),40,97,55,48,52,50,32,111,116,49,55,52,32,105,100,49,55,53,41,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,49,55,50,41,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,12),40,97,55,49,48,48,32,120,49,54,52,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,12),40,97,55,49,49,48,32,120,49,54,50,41,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,25),40,97,54,56,54,54,32,102,111,114,109,49,53,52,32,114,49,53,53,32,99,49,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,25),40,97,55,49,50,52,32,102,111,114,109,49,51,54,32,114,49,51,55,32,99,49,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,25),40,97,55,50,54,49,32,102,111,114,109,49,49,56,32,114,49,49,57,32,99,49,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,7),40,97,55,51,57,50,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,22),40,100,111,108,111,111,112,49,48,55,32,120,49,49,49,32,120,115,49,49,50,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,7),40,97,55,51,57,55,41,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,7),40,97,55,52,51,48,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,7),40,97,55,51,56,54,41,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,22),40,97,55,51,54,48,32,102,111,114,109,56,54,32,114,56,55,32,99,56,56,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,22),40,97,55,52,52,57,32,102,111,114,109,55,57,32,114,56,48,32,99,56,49,41,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,22),40,97,55,52,54,55,32,102,111,114,109,54,57,32,114,55,48,32,99,55,49,41,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,22),40,97,55,53,54,54,32,102,111,114,109,51,57,32,114,52,48,32,99,52,49,41,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,22),40,109,97,112,115,108,111,116,115,32,115,108,111,116,115,49,57,32,105,50,48,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,16),40,97,55,55,48,57,32,120,49,32,114,50,32,99,51,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_chicken_syntax_toplevel)
C_externexport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7710)
static void C_ccall f_7710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7714)
static void C_ccall f_7714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7723)
static void C_ccall f_7723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7726)
static void C_ccall f_7726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7741)
static void C_ccall f_7741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8151)
static void C_ccall f_8151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8111)
static void C_ccall f_8111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8143)
static void C_ccall f_8143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8103)
static void C_ccall f_8103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8059)
static void C_ccall f_8059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7770)
static void C_fcall f_7770(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7780)
static void C_ccall f_7780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8047)
static void C_ccall f_8047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7783)
static void C_ccall f_7783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8043)
static void C_ccall f_8043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7786)
static void C_ccall f_7786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7833)
static void C_fcall f_7833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7797)
static void C_ccall f_7797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7768)
static void C_ccall f_7768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7764)
static void C_ccall f_7764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7708)
static void C_ccall f_7708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7567)
static void C_ccall f_7567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7571)
static void C_ccall f_7571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7574)
static void C_ccall f_7574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7577)
static void C_ccall f_7577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7613)
static void C_ccall f_7613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7628)
static void C_fcall f_7628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7682)
static void C_ccall f_7682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7643)
static void C_ccall f_7643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7606)
static void C_ccall f_7606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7565)
static void C_ccall f_7565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7475)
static void C_ccall f_7475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7478)
static void C_ccall f_7478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7557)
static void C_ccall f_7557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7466)
static void C_ccall f_7466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7450)
static void C_ccall f_7450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7458)
static void C_ccall f_7458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7448)
static void C_ccall f_7448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7365)
static void C_ccall f_7365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7371)
static void C_ccall f_7371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7374)
static void C_ccall f_7374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7387)
static void C_ccall f_7387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7398)
static void C_ccall f_7398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7406)
static void C_ccall f_7406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_fcall f_7408(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7425)
static void C_ccall f_7425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7393)
static void C_ccall f_7393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7385)
static void C_ccall f_7385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7381)
static void C_ccall f_7381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7262)
static void C_ccall f_7262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7266)
static void C_ccall f_7266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7275)
static void C_ccall f_7275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7278)
static void C_ccall f_7278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7281)
static void C_fcall f_7281(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7316)
static void C_ccall f_7316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7260)
static void C_ccall f_7260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7129)
static void C_ccall f_7129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7141)
static void C_ccall f_7141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7144)
static void C_ccall f_7144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7198)
static void C_fcall f_7198(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7194)
static void C_ccall f_7194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7123)
static void C_ccall f_7123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6871)
static void C_ccall f_6871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7111)
static void C_ccall f_7111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7119)
static void C_ccall f_7119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6886)
static void C_ccall f_6886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6889)
static void C_ccall f_6889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7099)
static void C_ccall f_7099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7077)
static void C_fcall f_7077(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7063)
static void C_ccall f_7063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6903)
static void C_ccall f_6903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7043)
static void C_ccall f_7043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7029)
static void C_ccall f_7029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7015)
static void C_ccall f_7015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7007)
static void C_ccall f_7007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6979)
static void C_ccall f_6979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6947)
static void C_ccall f_6947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6965)
static void C_ccall f_6965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6951)
static void C_ccall f_6951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6943)
static void C_ccall f_6943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6750)
static void C_ccall f_6750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6765)
static void C_ccall f_6765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6768)
static void C_ccall f_6768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6808)
static void C_fcall f_6808(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6831)
static void C_ccall f_6831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6838)
static void C_ccall f_6838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6821)
static void C_ccall f_6821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6771)
static void C_ccall f_6771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6744)
static void C_ccall f_6744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6548)
static void C_ccall f_6548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6557)
static void C_ccall f_6557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6560)
static void C_ccall f_6560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6563)
static void C_ccall f_6563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6566)
static void C_ccall f_6566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6569)
static void C_ccall f_6569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6732)
static void C_ccall f_6732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6572)
static void C_ccall f_6572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6722)
static void C_ccall f_6722(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6575)
static void C_ccall f_6575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6716)
static void C_ccall f_6716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6720)
static void C_ccall f_6720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6654)
static void C_ccall f_6654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6510)
static void C_ccall f_6510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6530)
static void C_ccall f_6530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6534)
static void C_ccall f_6534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6446)
static void C_ccall f_6446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6450)
static void C_ccall f_6450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6485)
static void C_ccall f_6485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6489)
static void C_ccall f_6489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_ccall f_6301(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6305)
static void C_ccall f_6305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6314)
static void C_ccall f_6314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6383)
static void C_ccall f_6383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6299)
static void C_ccall f_6299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6243)
static void C_ccall f_6243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6247)
static void C_ccall f_6247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6271)
static void C_fcall f_6271(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6295)
static void C_ccall f_6295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6284)
static void C_ccall f_6284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6250)
static void C_ccall f_6250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_ccall f_6257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6261)
static void C_ccall f_6261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6241)
static void C_ccall f_6241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5946)
static void C_ccall f_5946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_fcall f_6199(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6197)
static void C_ccall f_6197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6139)
static void C_fcall f_6139(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6179)
static void C_ccall f_6179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6155)
static void C_fcall f_6155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5973)
static void C_fcall f_5973(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6127)
static void C_ccall f_6127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6011)
static void C_fcall f_6011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6093)
static void C_ccall f_6093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6005)
static void C_ccall f_6005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5995)
static void C_ccall f_5995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5953)
static void C_ccall f_5953(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5904)
static void C_fcall f_5904(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5931)
static void C_ccall f_5931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5873)
static void C_fcall f_5873(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5894)
static void C_ccall f_5894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5853)
static void C_ccall f_5853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_fcall f_5804(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5822)
static void C_ccall f_5822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5781)
static void C_ccall f_5781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5633)
static void C_ccall f_5633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5771)
static void C_ccall f_5771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5767)
static void C_ccall f_5767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5763)
static void C_ccall f_5763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5749)
static void C_ccall f_5749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5701)
static void C_ccall f_5701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5711)
static void C_ccall f_5711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5727)
static void C_ccall f_5727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5709)
static void C_ccall f_5709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5667)
static void C_ccall f_5667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5663)
static void C_ccall f_5663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5615)
static void C_ccall f_5615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_ccall f_1330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_fcall f_5435(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5496)
static void C_ccall f_5496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_fcall f_5448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5460)
static void C_fcall f_5460(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5451)
static void C_ccall f_5451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5266)
static void C_ccall f_5266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_fcall f_5287(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5361)
static void C_ccall f_5361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5113)
static void C_ccall f_5113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5150)
static void C_fcall f_5150(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5179)
static void C_ccall f_5179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5090)
static void C_ccall f_5090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_fcall f_4974(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_fcall f_4766(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4772)
static void C_fcall f_4772(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_fcall f_4669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4687)
static void C_fcall f_4687(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4643)
static void C_ccall f_4643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4627)
static void C_ccall f_4627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_ccall f_4587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_fcall f_4158(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4386)
static void C_ccall f_4386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3766)
static void C_ccall f_3766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_fcall f_3780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3831)
static void C_fcall f_3831(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_fcall f_3647(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3653)
static void C_fcall f_3653(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1351)
static void C_ccall f_1351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3529)
static void C_ccall f_3529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3108)
static void C_ccall f_3108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3089)
static void C_ccall f_3089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_fcall f_3074(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_fcall f_3025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1360)
static void C_ccall f_1360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_fcall f_2641(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2667)
static void C_fcall f_2667(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_fcall f_2707(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2373)
static void C_ccall f_2373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_fcall f_2394(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1366)
static void C_ccall f_1366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_fcall f_2163(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_fcall f_1885(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2031)
static void C_fcall f_2031(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_fcall f_1895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1757)
static void C_ccall f_1757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1727)
static void C_ccall f_1727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_ccall f_1743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1691)
static void C_ccall f_1691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_fcall f_1619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1384)
static void C_ccall f_1384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1412)
static void C_ccall f_1412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1505)
static void C_fcall f_1505(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_fcall f_1527(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1422)
static void C_ccall f_1422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_ccall f_1402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1400)
static void C_ccall f_1400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_7770)
static void C_fcall trf_7770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7770(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7770(t0,t1,t2,t3);}

C_noret_decl(trf_7833)
static void C_fcall trf_7833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7833(t0,t1);}

C_noret_decl(trf_7628)
static void C_fcall trf_7628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7628(t0,t1);}

C_noret_decl(trf_7408)
static void C_fcall trf_7408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7408(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7408(t0,t1,t2,t3);}

C_noret_decl(trf_7281)
static void C_fcall trf_7281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7281(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7281(t0,t1);}

C_noret_decl(trf_7198)
static void C_fcall trf_7198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7198(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7198(t0,t1);}

C_noret_decl(trf_7077)
static void C_fcall trf_7077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7077(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7077(t0,t1,t2);}

C_noret_decl(trf_6808)
static void C_fcall trf_6808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6808(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6808(t0,t1,t2);}

C_noret_decl(trf_6271)
static void C_fcall trf_6271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6271(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6271(t0,t1,t2);}

C_noret_decl(trf_6199)
static void C_fcall trf_6199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6199(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6199(t0,t1,t2,t3);}

C_noret_decl(trf_6139)
static void C_fcall trf_6139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6139(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6139(t0,t1,t2,t3);}

C_noret_decl(trf_6155)
static void C_fcall trf_6155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6155(t0,t1);}

C_noret_decl(trf_5973)
static void C_fcall trf_5973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5973(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5973(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6011)
static void C_fcall trf_6011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6011(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6011(t0,t1);}

C_noret_decl(trf_5904)
static void C_fcall trf_5904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5904(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5904(t0,t1,t2,t3);}

C_noret_decl(trf_5873)
static void C_fcall trf_5873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5873(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5873(t0,t1,t2,t3);}

C_noret_decl(trf_5804)
static void C_fcall trf_5804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5804(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5804(t0,t1,t2);}

C_noret_decl(trf_5435)
static void C_fcall trf_5435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5435(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5435(t0,t1,t2,t3);}

C_noret_decl(trf_5448)
static void C_fcall trf_5448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5448(t0,t1);}

C_noret_decl(trf_5460)
static void C_fcall trf_5460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5460(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5460(t0,t1);}

C_noret_decl(trf_5287)
static void C_fcall trf_5287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5287(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5287(t0,t1,t2);}

C_noret_decl(trf_5150)
static void C_fcall trf_5150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5150(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5150(t0,t1,t2);}

C_noret_decl(trf_4974)
static void C_fcall trf_4974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4974(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4974(t0,t1,t2);}

C_noret_decl(trf_4766)
static void C_fcall trf_4766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4766(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4766(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4772)
static void C_fcall trf_4772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4772(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4772(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4669)
static void C_fcall trf_4669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4669(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4669(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4687)
static void C_fcall trf_4687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4687(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4687(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4158)
static void C_fcall trf_4158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4158(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4158(t0,t1,t2,t3);}

C_noret_decl(trf_3780)
static void C_fcall trf_3780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3780(t0,t1);}

C_noret_decl(trf_3831)
static void C_fcall trf_3831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3831(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3831(t0,t1,t2,t3);}

C_noret_decl(trf_3647)
static void C_fcall trf_3647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3647(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3647(t0,t1,t2);}

C_noret_decl(trf_3653)
static void C_fcall trf_3653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3653(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3653(t0,t1,t2);}

C_noret_decl(trf_3074)
static void C_fcall trf_3074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3074(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3074(t0,t1);}

C_noret_decl(trf_3025)
static void C_fcall trf_3025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3025(t0,t1);}

C_noret_decl(trf_2641)
static void C_fcall trf_2641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2641(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2641(t0,t1,t2,t3);}

C_noret_decl(trf_2667)
static void C_fcall trf_2667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2667(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2667(t0,t1);}

C_noret_decl(trf_2707)
static void C_fcall trf_2707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2707(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2707(t0,t1);}

C_noret_decl(trf_2394)
static void C_fcall trf_2394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2394(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2394(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2163)
static void C_fcall trf_2163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2163(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2163(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1885)
static void C_fcall trf_1885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1885(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1885(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2031)
static void C_fcall trf_2031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2031(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2031(t0,t1);}

C_noret_decl(trf_1895)
static void C_fcall trf_1895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1895(t0,t1);}

C_noret_decl(trf_1619)
static void C_fcall trf_1619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1619(t0,t1);}

C_noret_decl(trf_1505)
static void C_fcall trf_1505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1505(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1505(t0,t1,t2);}

C_noret_decl(trf_1527)
static void C_fcall trf_1527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1527(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1527(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_chicken_syntax_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("chicken_syntax_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3170)){
C_save(t1);
C_rereclaim2(3170*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,244);
lf[0]=C_h_intern(&lf[0],29,"\003syschicken-macro-environment");
lf[1]=C_h_intern(&lf[1],17,"register-feature!");
lf[2]=C_h_intern(&lf[2],6,"srfi-8");
lf[3]=C_h_intern(&lf[3],7,"srfi-16");
lf[4]=C_h_intern(&lf[4],7,"srfi-26");
lf[5]=C_h_intern(&lf[5],7,"srfi-31");
lf[6]=C_h_intern(&lf[6],7,"srfi-15");
lf[7]=C_h_intern(&lf[7],7,"srfi-11");
lf[8]=C_h_intern(&lf[8],16,"\003sysmacro-subset");
lf[9]=C_h_intern(&lf[9],29,"\003sysdefault-macro-environment");
lf[10]=C_h_intern(&lf[10],28,"\003sysextend-macro-environment");
lf[11]=C_h_intern(&lf[11],12,"define-macro");
lf[12]=C_h_intern(&lf[12],12,"syntax-error");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000<`define-macro\047 is not supported - please use `define-syntax\047");
lf[14]=C_h_intern(&lf[14],18,"\003syser-transformer");
lf[15]=C_h_intern(&lf[15],19,"let-compiler-syntax");
lf[16]=C_h_intern(&lf[16],9,"\003sysmap-n");
lf[17]=C_h_intern(&lf[17],24,"\004corelet-compiler-syntax");
lf[18]=C_h_intern(&lf[18],7,"\003sysmap");
lf[19]=C_h_intern(&lf[19],25,"\003syssyntax-rules-mismatch");
lf[20]=C_h_intern(&lf[20],9,"\003syslist\077");
lf[21]=C_h_intern(&lf[21],9,"\003sysnull\077");
lf[22]=C_h_intern(&lf[22],22,"define-compiler-syntax");
lf[23]=C_h_intern(&lf[23],6,"lambda");
lf[24]=C_h_intern(&lf[24],27,"\004coredefine-compiler-syntax");
lf[25]=C_h_intern(&lf[25],3,"use");
lf[26]=C_h_intern(&lf[26],22,"\004corerequire-extension");
lf[27]=C_h_intern(&lf[27],16,"\003syscheck-syntax");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[29]=C_h_intern(&lf[29],17,"define-for-syntax");
lf[30]=C_h_intern(&lf[30],10,"\003sysappend");
lf[31]=C_h_intern(&lf[31],6,"define");
lf[32]=C_h_intern(&lf[32],16,"begin-for-syntax");
lf[33]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[34]=C_h_intern(&lf[34],3,"rec");
lf[35]=C_h_intern(&lf[35],6,"letrec");
lf[36]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[37]=C_h_intern(&lf[37],16,"define-extension");
lf[38]=C_h_intern(&lf[38],22,"chicken-compile-shared");
lf[39]=C_h_intern(&lf[39],9,"compiling");
lf[40]=C_h_intern(&lf[40],4,"name");
lf[41]=C_h_intern(&lf[41],4,"unit");
lf[42]=C_h_intern(&lf[42],5,"quote");
lf[43]=C_h_intern(&lf[43],7,"provide");
lf[44]=C_h_intern(&lf[44],4,"else");
lf[45]=C_h_intern(&lf[45],3,"not");
lf[46]=C_h_intern(&lf[46],11,"cond-expand");
lf[47]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007unquote\376\003\000\000\002\376\001\000\000\006%begin\376\377\016\376\377\016");
lf[48]=C_h_intern(&lf[48],4,"cdar");
lf[49]=C_h_intern(&lf[49],6,"append");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[51]=C_h_intern(&lf[51],4,"caar");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[53]=C_h_intern(&lf[53],6,"export");
lf[54]=C_h_intern(&lf[54],7,"dynamic");
lf[55]=C_h_intern(&lf[55],6,"static");
lf[56]=C_h_intern(&lf[56],5,"begin");
lf[57]=C_h_intern(&lf[57],7,"declare");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_");
lf[59]=C_h_intern(&lf[59],5,"apply");
lf[60]=C_h_intern(&lf[60],4,"cute");
lf[61]=C_h_intern(&lf[61],6,"gensym");
lf[62]=C_h_intern(&lf[62],7,"reverse");
lf[63]=C_h_intern(&lf[63],5,"<...>");
lf[64]=C_h_intern(&lf[64],2,"<>");
lf[65]=C_h_intern(&lf[65],3,"let");
lf[66]=C_h_intern(&lf[66],19,"\003sysprimitive-alias");
lf[67]=C_h_intern(&lf[67],3,"cut");
lf[68]=C_h_intern(&lf[68],18,"getter-with-setter");
lf[69]=C_h_intern(&lf[69],18,"define-record-type");
lf[70]=C_h_intern(&lf[70],18,"\003sysmake-structure");
lf[71]=C_h_intern(&lf[71],14,"\003sysstructure\077");
lf[72]=C_h_intern(&lf[72],15,"\000record-setters");
lf[73]=C_h_intern(&lf[73],12,"\003sysfeatures");
lf[74]=C_h_intern(&lf[74],19,"\003syscheck-structure");
lf[75]=C_h_intern(&lf[75],10,"\004corecheck");
lf[76]=C_h_intern(&lf[76],13,"\003sysblock-ref");
lf[77]=C_h_intern(&lf[77],14,"\003sysblock-set!");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[79]=C_h_intern(&lf[79],3,"car");
lf[80]=C_h_intern(&lf[80],1,"y");
lf[81]=C_h_intern(&lf[81],1,"x");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\010variable\376\001\000"
"\000\001_");
lf[83]=C_h_intern(&lf[83],4,"memv");
lf[84]=C_h_intern(&lf[84],14,"condition-case");
lf[85]=C_h_intern(&lf[85],9,"condition");
lf[86]=C_h_intern(&lf[86],8,"\003sysslot");
lf[87]=C_h_intern(&lf[87],10,"\003syssignal");
lf[88]=C_h_intern(&lf[88],4,"cond");
lf[89]=C_h_intern(&lf[89],17,"handle-exceptions");
lf[90]=C_h_intern(&lf[90],3,"and");
lf[91]=C_h_intern(&lf[91],4,"kvar");
lf[92]=C_h_intern(&lf[92],5,"exvar");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[94]=C_h_intern(&lf[94],30,"call-with-current-continuation");
lf[95]=C_h_intern(&lf[95],22,"with-exception-handler");
lf[96]=C_h_intern(&lf[96],10,"\003sysvalues");
lf[97]=C_h_intern(&lf[97],9,"\003sysapply");
lf[98]=C_h_intern(&lf[98],20,"\003syscall-with-values");
lf[99]=C_h_intern(&lf[99],4,"args");
lf[100]=C_h_intern(&lf[100],1,"k");
lf[101]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[102]=C_h_intern(&lf[102],21,"define-record-printer");
lf[103]=C_h_intern(&lf[103],27,"\003sysregister-record-printer");
lf[104]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[106]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[107]=C_h_intern(&lf[107],2,">=");
lf[108]=C_h_intern(&lf[108],3,"cdr");
lf[109]=C_h_intern(&lf[109],3,"eq\077");
lf[110]=C_h_intern(&lf[110],11,"case-lambda");
lf[111]=C_h_intern(&lf[111],6,"length");
lf[112]=C_h_intern(&lf[112],9,"split-at!");
lf[113]=C_h_intern(&lf[113],4,"take");
lf[114]=C_h_intern(&lf[114],3,"map");
lf[115]=C_h_intern(&lf[115],4,"list");
lf[116]=C_h_intern(&lf[116],11,"lambda-list");
lf[117]=C_h_intern(&lf[117],25,"\003sysdecompose-lambda-list");
lf[118]=C_h_intern(&lf[118],10,"fold-right");
lf[119]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[120]=C_h_intern(&lf[120],2,"if");
lf[121]=C_h_intern(&lf[121],4,"lvar");
lf[122]=C_h_intern(&lf[122],4,"rvar");
lf[123]=C_h_intern(&lf[123],3,"min");
lf[124]=C_h_intern(&lf[124],7,"require");
lf[125]=C_h_intern(&lf[125],6,"srfi-1");
lf[126]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[127]=C_h_intern(&lf[127],5,"null\077");
lf[128]=C_h_intern(&lf[128],14,"let-optionals*");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[130]=C_h_intern(&lf[130],14,"\004coreimmutable");
lf[131]=C_h_intern(&lf[131],9,"\003syserror");
lf[132]=C_h_intern(&lf[132],4,"tmp2");
lf[133]=C_h_intern(&lf[133],3,"tmp");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[135]=C_h_intern(&lf[135],8,"optional");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[138]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[139]=C_h_intern(&lf[139],13,"let-optionals");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[141]=C_h_intern(&lf[141],14,"string->symbol");
lf[142]=C_h_intern(&lf[142],13,"string-append");
lf[143]=C_h_intern(&lf[143],14,"symbol->string");
lf[144]=C_h_intern(&lf[144],4,"let*");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[146]=C_h_intern(&lf[146],5,"%rest");
lf[147]=C_h_intern(&lf[147],4,"body");
lf[148]=C_h_intern(&lf[148],4,"cadr");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[150]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[151]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[152]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[153]=C_h_intern(&lf[153],6,"select");
lf[154]=C_h_intern(&lf[154],8,"\003syseqv\077");
lf[155]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[157]=C_h_intern(&lf[157],2,"or");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[159]=C_h_intern(&lf[159],8,"and-let*");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[161]=C_h_intern(&lf[161],13,"define-inline");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[163]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[164]=C_h_intern(&lf[164],18,"\004coredefine-inline");
lf[165]=C_h_intern(&lf[165],8,"list-ref");
lf[166]=C_h_intern(&lf[166],9,"nth-value");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[168]=C_h_intern(&lf[168],13,"letrec-values");
lf[169]=C_h_intern(&lf[169],9,"\004coreset!");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[172]=C_h_intern(&lf[172],11,"let*-values");
lf[173]=C_h_intern(&lf[173],10,"let-values");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[176]=C_h_intern(&lf[176],13,"define-values");
lf[177]=C_h_intern(&lf[177],11,"set!-values");
lf[178]=C_h_intern(&lf[178],19,"\003sysregister-export");
lf[179]=C_h_intern(&lf[179],18,"\003syscurrent-module");
lf[180]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[181]=C_h_intern(&lf[181],14,"\004coreundefined");
lf[182]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[183]=C_h_intern(&lf[183],6,"unless");
lf[184]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[185]=C_h_intern(&lf[185],4,"when");
lf[186]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[187]=C_h_intern(&lf[187],12,"parameterize");
lf[188]=C_h_intern(&lf[188],16,"\003sysdynamic-wind");
lf[189]=C_h_intern(&lf[189],1,"t");
lf[190]=C_h_intern(&lf[190],8,"\003syslist");
lf[191]=C_h_intern(&lf[191],4,"swap");
lf[192]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[193]=C_h_intern(&lf[193],9,"eval-when");
lf[194]=C_h_intern(&lf[194],10,"\000compiling");
lf[195]=C_h_intern(&lf[195],19,"\004corecompiletimetoo");
lf[196]=C_h_intern(&lf[196],20,"\004corecompiletimeonly");
lf[197]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[198]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[200]=C_h_intern(&lf[200],4,"load");
lf[201]=C_h_intern(&lf[201],7,"compile");
lf[202]=C_h_intern(&lf[202],4,"eval");
lf[203]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[204]=C_h_intern(&lf[204],9,"fluid-let");
lf[205]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[206]=C_h_intern(&lf[206],6,"ensure");
lf[207]=C_h_intern(&lf[207],11,"\000type-error");
lf[208]=C_h_intern(&lf[208],15,"\003syssignal-hook");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[210]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\003");
lf[211]=C_h_intern(&lf[211],6,"assert");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[213]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[214]=C_h_intern(&lf[214],7,"include");
lf[215]=C_h_intern(&lf[215],27,"\003syscurrent-source-filename");
lf[216]=C_h_intern(&lf[216],4,"read");
lf[217]=C_h_intern(&lf[217],20,"with-input-from-file");
lf[218]=C_h_intern(&lf[218],5,"print");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[221]=C_h_intern(&lf[221],12,"load-verbose");
lf[222]=C_h_intern(&lf[222],28,"\003sysresolve-include-filename");
lf[223]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[224]=C_h_intern(&lf[224],12,"\004coredeclare");
lf[225]=C_h_intern(&lf[225],4,"time");
lf[226]=C_h_intern(&lf[226],15,"\003sysstart-timer");
lf[227]=C_h_intern(&lf[227],14,"\003sysstop-timer");
lf[228]=C_h_intern(&lf[228],17,"\003sysdisplay-times");
lf[229]=C_h_intern(&lf[229],7,"receive");
lf[230]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[231]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[232]=C_h_intern(&lf[232],13,"define-record");
lf[233]=C_h_intern(&lf[233],3,"val");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[239]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[240]=C_h_intern(&lf[240],21,"\003sysmacro-environment");
lf[241]=C_h_intern(&lf[241],11,"\003sysprovide");
lf[242]=C_h_intern(&lf[242],19,"chicken-more-macros");
lf[243]=C_h_intern(&lf[243],14,"chicken-syntax");
C_register_lf2(lf,244,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1272,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 35   ##sys#provide */
t3=*((C_word*)lf[241]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[242],lf[243]);}

/* k1270 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1276,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 43   ##sys#macro-environment */
t3=*((C_word*)lf[240]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1274 in k1270 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1279,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7708,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7710,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 47   ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7709 in k1274 in k1270 */
static void C_ccall f_7710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7710,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7714,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 49   ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[232],t2,lf[239]);}

/* k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7714,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 52   symbol->string */
t5=*((C_word*)lf[143]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7726,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 53   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[42]);}

/* k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7726,2,t0,t1);}
t2=(C_word)C_i_memq(lf[72],*((C_word*)lf[73]+1));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 55   r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[56]);}

/* k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 56   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[31]);}

/* k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 57   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[68]);}

/* k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7741,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 58   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8151,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 61   string-append */
t4=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[238],((C_word*)t0)[2]);}

/* k8149 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_8151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 61   string->symbol */
t2=*((C_word*)lf[141]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_8111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8111,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
/* ##sys#append */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);}

/* k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_8143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8143,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[70],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t8);
t10=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8059,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t9,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8103,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 64   string-append */
t12=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],lf[237]);}

/* k8101 in k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_8103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 64   string->symbol */
t2=*((C_word*)lf[141]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8057 in k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_8059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8059,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[81],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[42],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[81],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[71],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t1,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7764,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7768,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t17,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[12],a[11]=((C_word)li103),tmp=(C_word)a,a+=12,tmp));
t19=((C_word*)t17)[1];
f_7770(t19,t15,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k8057 in k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_fcall f_7770(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7770,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* chicken-syntax.scm: 69   symbol->string */
t7=*((C_word*)lf[143]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k7778 in mapslots in k8057 in k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7783,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8047,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 70   string-append */
t4=*((C_word*)lf[142]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],lf[235],t1,lf[236]);}

/* k8045 in k7778 in mapslots in k8057 in k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_8047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 70   string->symbol */
t2=*((C_word*)lf[141]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7781 in k7778 in mapslots in k8057 in k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7786,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8043,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 71   string-append */
t4=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],lf[234],((C_word*)t0)[2]);}

/* k8041 in k7781 in k7778 in mapslots in k8057 in k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_8043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 71   string->symbol */
t2=*((C_word*)lf[141]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7784 in k7781 in k7778 in mapslots in k8057 in k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[124],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7786,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[81],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[74],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[75],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[81],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[77],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t10,t15);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t20);
t22=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7833,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t21,a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[3])){
t23=(C_word)C_a_i_cons(&a,2,lf[81],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[81],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[74],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[75],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[81],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[76],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36);
t38=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t37,t38);
t40=t22;
f_7833(t40,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t39));}
else{
t23=(C_word)C_a_i_cons(&a,2,lf[81],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[81],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[74],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[75],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[81],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[76],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=t22;
f_7833(t37,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36));}}

/* k7831 in k7784 in k7781 in k7778 in mapslots in k8057 in k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_fcall f_7833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7833,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7797,a[2]=t7,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t10=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm: 90   mapslots */
t11=((C_word*)((C_word*)t0)[2])[1];
f_7770(t11,t8,t9,t10);}

/* k7795 in k7831 in k7784 in k7781 in k7778 in mapslots in k8057 in k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7797,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7766 in k8057 in k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7762 in k8057 in k8141 in k8109 in k7739 in k7736 in k7733 in k7730 in k7724 in k7721 in k7712 in a7709 in k1274 in k1270 */
static void C_ccall f_7764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7764,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k7706 in k1274 in k1270 */
static void C_ccall f_7708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 45   ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[232],C_SCHEME_END_OF_LIST,t1);}

/* k1277 in k1274 in k1270 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7565,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7567,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 95   ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7566 in k1277 in k1274 in k1270 */
static void C_ccall f_7567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7567,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7571,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 97   r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[23]);}

/* k7569 in a7566 in k1277 in k1274 in k1270 */
static void C_ccall f_7571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7574,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 98   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k7572 in k7569 in a7566 in k1277 in k1274 in k1270 */
static void C_ccall f_7574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7577,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 99   ##sys#check-syntax */
t3=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[229],((C_word*)t0)[4],lf[231]);}

/* k7575 in k7572 in k7569 in a7566 in k1277 in k1274 in k1270 */
static void C_ccall f_7577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7577,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7613,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 103  ##sys#check-syntax */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[229],((C_word*)t0)[5],lf[230]);}}

/* k7611 in k7575 in k7572 in k7569 in a7566 in k1277 in k1274 in k1270 */
static void C_ccall f_7613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7613,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7628,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=t5;
f_7628(t7,(C_word)C_i_nullp(t6));}
else{
t6=t5;
f_7628(t6,C_SCHEME_FALSE);}}

/* k7626 in k7611 in k7575 in k7572 in k7569 in a7566 in k1277 in k1274 in k1270 */
static void C_fcall f_7628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7628,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7643,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t7=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7682,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* k7680 in k7626 in k7611 in k7575 in k7572 in k7569 in a7566 in k1277 in k1274 in k1270 */
static void C_ccall f_7682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7682,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[98],t5));}

/* k7641 in k7626 in k7611 in k7575 in k7572 in k7569 in a7566 in k1277 in k1274 in k1270 */
static void C_ccall f_7643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7643,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k7604 in k7575 in k7572 in k7569 in a7566 in k1277 in k1274 in k1270 */
static void C_ccall f_7606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7606,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[190],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[98],t5));}

/* k7563 in k1277 in k1274 in k1270 */
static void C_ccall f_7565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 92   ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[229],C_SCHEME_END_OF_LIST,t1);}

/* k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7466,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7468,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 115  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7467 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7468,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7472,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 117  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[189]);}

/* k7470 in a7467 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 118  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[56]);}

/* k7473 in k7470 in a7467 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7478,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 119  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k7476 in k7473 in k7470 in a7467 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7478,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[226],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k7555 in k7476 in k7473 in k7470 in a7467 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7557,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[227],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[228],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[96],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[97],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[98],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t17);
t19=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t18));}

/* k7464 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 113  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[225],C_SCHEME_END_OF_LIST,t1);}

/* k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7448,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7450,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 130  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7449 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7450,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7458,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k7456 in a7449 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7458,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[224],t1));}

/* k7446 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 128  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[57],C_SCHEME_END_OF_LIST,t1);}

/* k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7359,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7361,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 136  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7361,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7365,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 138  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[214],t2,lf[223]);}

/* k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7368,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 139  ##sys#resolve-include-filename */
t4=*((C_word*)lf[222]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7371,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 140  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[56]);}

/* k7369 in k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7374,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7437,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 141  load-verbose */
t4=*((C_word*)lf[221]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7435 in k7369 in k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-syntax.scm: 141  print */
t2=*((C_word*)lf[218]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[219],((C_word*)t0)[2],lf[220]);}
else{
t2=((C_word*)t0)[3];
f_7374(2,t2,C_SCHEME_UNDEFINED);}}

/* k7372 in k7369 in k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7381,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7385,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7387,a[2]=((C_word*)t0)[2],a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 143  with-input-from-file */
t5=*((C_word*)lf[217]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* a7386 in k7372 in k7369 in k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7387,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7393,a[2]=t3,a[3]=t5,a[4]=((C_word)li94),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7398,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7431,a[2]=t5,a[3]=t3,a[4]=((C_word)li97),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[188]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a7430 in a7386 in k7372 in k7369 in k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7431,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[215]+1));
t3=C_mutate((C_word*)lf[215]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a7397 in a7386 in k7372 in k7369 in k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7406,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 146  read */
t3=*((C_word*)lf[216]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7404 in a7397 in a7386 in k7372 in k7369 in k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7406,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7408,a[2]=t3,a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7408(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop107 in k7404 in a7397 in a7386 in k7372 in k7369 in k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_7408(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7408,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* chicken-syntax.scm: 149  reverse */
t4=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7425,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 146  read */
t5=*((C_word*)lf[216]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k7423 in doloop107 in k7404 in a7397 in a7386 in k7372 in k7369 in k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7425,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_7408(t3,((C_word*)t0)[2],t1,t2);}

/* a7392 in a7386 in k7372 in k7369 in k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7393,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[215]+1));
t3=C_mutate((C_word*)lf[215]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k7383 in k7372 in k7369 in k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7379 in k7372 in k7369 in k7366 in k7363 in a7360 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7381,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7357 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 134  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[214],C_SCHEME_END_OF_LIST,t1);}

/* k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7260,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7262,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 153  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7261 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7262,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7266,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 155  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[211],t2,lf[213]);}

/* k7264 in a7261 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7266,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7275,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 158  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[120]);}

/* k7273 in k7264 in a7261 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7278,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 159  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[42]);}

/* k7276 in k7273 in k7264 in a7261 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,lf[212],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[42],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t2;
f_7281(t7,(C_word)C_a_i_cons(&a,2,lf[130],t6));}
else{
t4=t2;
f_7281(t4,(C_word)C_i_car(((C_word*)t0)[2]));}}

/* k7279 in k7276 in k7273 in k7264 in a7261 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_7281(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7281,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[75],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[181],C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7316,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_length(((C_word*)t0)[2]);
t7=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_cdr(((C_word*)t0)[2]):C_SCHEME_END_OF_LIST);
/* ##sys#append */
t9=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t5,t8,C_SCHEME_END_OF_LIST);}

/* k7314 in k7279 in k7276 in k7273 in k7264 in a7261 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7316,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[131],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k7258 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 151  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[211],C_SCHEME_END_OF_LIST,t1);}

/* k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7123,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7125,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 174  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7124 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7125,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7129,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 176  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[206],t2,lf[210]);}

/* k7127 in a7124 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7129,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7141,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 180  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[133]);}

/* k7139 in k7127 in a7124 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 181  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k7142 in k7139 in k7127 in a7124 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7147,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 182  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[120]);}

/* k7145 in k7142 in k7139 in k7127 in a7124 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7147,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[75],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7194,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t1,a[6]=t8,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7198,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t11=t10;
f_7198(t11,((C_word*)t0)[2]);}
else{
t11=(C_word)C_a_i_cons(&a,2,lf[209],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[42],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[130],t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[42],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t17);
t19=t10;
f_7198(t19,(C_word)C_a_i_cons(&a,2,t14,t18));}}

/* k7196 in k7145 in k7142 in k7139 in k7127 in a7124 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_7198(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7192 in k7145 in k7142 in k7139 in k7127 in a7124 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7194,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[207],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[208],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k7121 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 171  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[206],C_SCHEME_END_OF_LIST,t1);}

/* k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6865,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6867,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 195  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6867,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6871,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 197  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[204],t2,lf[205]);}

/* k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6871,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6880,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 200  ##sys#map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[79]+1),t2);}

/* k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7111,a[2]=((C_word*)t0)[2],a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 201  ##sys#map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a7110 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7111,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7119,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 201  gensym */
t4=*((C_word*)lf[61]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7117 in a7110 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 201  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7101,a[2]=((C_word*)t0)[2],a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 202  ##sys#map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a7100 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7101,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7109,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 202  gensym */
t4=*((C_word*)lf[61]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7107 in a7100 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 202  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 203  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6892,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 204  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7099,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 205  ##sys#map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[148]+1),((C_word*)t0)[2]);}

/* k7097 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 205  map */
t2=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[190]+1),((C_word*)t0)[2],t1);}

/* k7057 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7063,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7067,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7071,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7077,a[2]=t7,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_7077(t9,t4,t5);}

/* loop in k7057 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_7077(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7077,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7091,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* chicken-syntax.scm: 210  loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k7089 in loop in k7057 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7091,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k7069 in k7057 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 206  map */
t2=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[190]+1),((C_word*)t0)[2],t1);}

/* k7065 in k7057 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7061 in k7057 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7043,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 213  map */
t5=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* a7042 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7043,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[169],t5));}

/* k7009 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7015,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7019,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7029,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 215  map */
t5=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7028 in k7009 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7029,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[169],t5));}

/* k7017 in k7009 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7019,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[181],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k7013 in k7009 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7005 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_7007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7007,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6999,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6997 in k7005 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6999,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6943,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6979,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 220  map */
t7=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a6978 in k6997 in k7005 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6979,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[169],t5));}

/* k6945 in k6997 in k7005 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6951,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6955,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6965,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 222  map */
t5=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6964 in k6945 in k6997 in k7005 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6965,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[169],t5));}

/* k6953 in k6945 in k6997 in k7005 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6955,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[181],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6949 in k6945 in k6997 in k7005 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6941 in k6997 in k7005 in k6901 in k6890 in k6887 in k6884 in k6881 in k6878 in k6869 in a6866 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6943,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[188],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k6863 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 193  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[204],C_SCHEME_END_OF_LIST,t1);}

/* k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6744,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6746,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 228  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6746,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6750,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 230  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[193],t2,lf[203]);}

/* k6748 in a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6750,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6756,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 232  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[56]);}

/* k6754 in k6748 in a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6855 in k6754 in k6748 in a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6857,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 234  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[202]);}

/* k6760 in k6855 in k6754 in k6748 in a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 235  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[201]);}

/* k6763 in k6760 in k6855 in k6754 in k6748 in a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6768,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 236  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[200]);}

/* k6766 in k6763 in k6760 in k6855 in k6754 in k6748 in a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6768,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6771,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6808,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t3,a[9]=t10,a[10]=((C_word)li82),tmp=(C_word)a,a+=11,tmp));
t12=((C_word*)t10)[1];
f_6808(t12,t8,((C_word*)t0)[2]);}

/* loop in k6766 in k6763 in k6760 in k6855 in k6754 in k6748 in a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_6808(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6808,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6821,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 243  c */
t6=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6829 in loop in k6766 in k6763 in k6760 in k6855 in k6754 in k6748 in a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6831,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
f_6821(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 244  c */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6836 in k6829 in loop in k6766 in k6763 in k6760 in k6855 in k6754 in k6748 in a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6838,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[7];
f_6821(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 245  c */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k6843 in k6836 in k6829 in loop in k6766 in k6763 in k6760 in k6855 in k6754 in k6748 in a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[3];
f_6821(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm: 246  ##sys#error */
t3=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],lf[199],t2);}}

/* k6819 in loop in k6766 in k6763 in k6760 in k6855 in k6754 in k6748 in a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* chicken-syntax.scm: 247  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6808(t3,((C_word*)t0)[2],t2);}

/* k6769 in k6766 in k6763 in k6760 in k6855 in k6754 in k6748 in a6745 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6771,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[194],*((C_word*)lf[73]+1)))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[195],t3));}
else{
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[196],t3));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[4]:lf[197]));}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[4]:lf[198]));}}

/* k6742 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 226  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[193],C_SCHEME_END_OF_LIST,t1);}

/* k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6542,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6544,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 259  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6544,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6548,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 261  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[187],t2,lf[192]);}

/* k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6548,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6557,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 264  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[191]);}

/* k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 265  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 266  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 267  ##sys#map */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[79]+1),((C_word*)t0)[2]);}

/* k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6569,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 268  ##sys#map */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[148]+1),((C_word*)t0)[2]);}

/* k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6732,a[2]=((C_word*)t0)[2],a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 269  ##sys#map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6731 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6732,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6740,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 269  gensym */
t4=*((C_word*)lf[61]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6738 in a6731 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 269  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6570 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6722,a[2]=((C_word*)t0)[2],a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 270  ##sys#map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6721 in k6570 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6722(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6722,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6730,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 270  gensym */
t4=*((C_word*)lf[61]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6728 in a6721 in k6570 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 270  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6573 in k6570 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6586,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6716,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 271  map */
t4=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[190]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k6714 in k6573 in k6570 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6720,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 271  map */
t3=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[190]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6718 in k6714 in k6573 in k6570 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 271  ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6584 in k6573 in k6570 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6654,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6658,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6660,a[2]=((C_word*)t0)[6],a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 273  map */
t5=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6659 in k6584 in k6573 in k6570 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6660,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[189],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[189],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[169],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t9,t13);
t15=(C_word)C_a_i_cons(&a,2,t7,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t15));}

/* k6656 in k6584 in k6573 in k6570 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6652 in k6584 in k6573 in k6570 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6654,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t8=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6632 in k6652 in k6584 in k6573 in k6570 in k6567 in k6564 in k6561 in k6558 in k6555 in k6546 in a6543 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6634,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[188],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12));}

/* k6540 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 257  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[187],C_SCHEME_END_OF_LIST,t1);}

/* k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6497,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6499,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 284  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6498 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6499,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6503,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 286  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[185],t2,lf[186]);}

/* k6501 in a6498 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 287  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[120]);}

/* k6508 in k6501 in a6498 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6510,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6530,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 288  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[56]);}

/* k6528 in k6508 in k6501 in a6498 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6534,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6532 in k6528 in k6508 in k6501 in a6498 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6534,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6495 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 282  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[185],C_SCHEME_END_OF_LIST,t1);}

/* k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6444,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6446,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 292  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6445 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6446,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6450,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 294  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[183],t2,lf[184]);}

/* k6448 in a6445 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 295  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[120]);}

/* k6455 in k6448 in a6445 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6457,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[181],C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6485,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 297  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[56]);}

/* k6483 in k6455 in k6448 in a6445 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6489,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6487 in k6483 in k6455 in k6448 in a6445 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6489,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k6442 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 290  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[183],C_SCHEME_END_OF_LIST,t1);}

/* k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6299,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6301,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 301  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6300 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6301(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6301,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6305,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 303  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[177],t2,lf[182]);}

/* k6303 in a6300 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6305,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6314,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 306  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[23]);}

/* k6312 in k6303 in a6300 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6314,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[181],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t6);
t8=(C_word)C_a_i_cons(&a,2,t1,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[98],t10));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[169],t5));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6383,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[61]+1),((C_word*)t0)[4]);}}}

/* k6381 in k6312 in k6303 in a6300 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6383,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6410,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6414,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6416,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 319  map */
t8=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a6415 in k6381 in k6312 in k6303 in a6300 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6416,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[169],t5));}

/* k6412 in k6381 in k6312 in k6303 in a6300 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6408 in k6381 in k6312 in k6303 in a6300 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6410,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[98],t5));}

/* k6297 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 299  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[177],C_SCHEME_END_OF_LIST,t1);}

/* k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6241,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6243,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 325  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6242 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6243,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6247,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 327  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[176],t2,lf[180]);}

/* k6245 in a6242 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6271,a[2]=t5,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6271(t7,t2,t3);}

/* loop324 in k6245 in a6242 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_6271(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6271,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6284,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6295,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 328  ##sys#current-module */
t6=*((C_word*)lf[179]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6293 in loop324 in k6245 in a6242 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#register-export */
t2=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6282 in loop324 in k6245 in a6242 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6271(t3,((C_word*)t0)[2],t2);}

/* k6248 in k6245 in a6242 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6257,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 329  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[177]);}

/* k6255 in k6248 in k6245 in a6242 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6261,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6259 in k6255 in k6248 in k6245 in a6242 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6261,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6239 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 323  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[176],C_SCHEME_END_OF_LIST,t1);}

/* k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5853,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5855,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 333  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5855,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5859,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 335  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[173],t2,lf[175]);}

/* k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5859,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5868,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 338  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[65]);}

/* k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 339  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5871,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5873,a[2]=t3,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5904,a[2]=t5,a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5946,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t9=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[79]+1),((C_word*)t0)[3]);}

/* k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5949,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6199,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li70),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6199(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_6199(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6199,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6212,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* chicken-syntax.scm: 355  append */
t6=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* chicken-syntax.scm: 356  append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5873(t6,t5,t4,t3);}
else{
t6=t5;
f_6212(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k6210 in loop in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 358  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6199(t3,((C_word*)t0)[2],t2,t1);}

/* k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5952,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6185,a[2]=((C_word*)t0)[2],a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a6184 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6185,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6193,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6197,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 359  gensym */
t5=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6195 in a6184 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 359  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6191 in a6184 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6193,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5953,a[2]=t1,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6139,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6139(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_6139(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6139,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken-syntax.scm: 363  reverse */
t4=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6155,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6179,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 367  map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_5904(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6172,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 366  lookup */
t7=((C_word*)t0)[2];
f_5953(3,t7,t6,t4);}}}

/* k6170 in loop in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6172,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6155(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6177 in loop in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6179,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6155(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6153 in loop in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_6155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 368  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6139(t3,((C_word*)t0)[2],t2,t1);}

/* k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5971,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6133,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6132 in k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6133,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k5969 in k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5971,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5973,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word)li66),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_5973(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k5969 in k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_5973(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5973,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5991,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5997,a[2]=((C_word*)t0)[5],a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6127,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 374  cdar */
t8=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}
else{
t7=t5;
f_6011(t7,C_SCHEME_FALSE);}}}

/* k6125 in fold in k5969 in k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6011(t2,(C_word)C_i_nullp(t1));}

/* k6009 in fold in k5969 in k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_6011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6011,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 375  caar */
t3=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6093,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
t9=(C_word)C_i_cdr(((C_word*)t0)[8]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 380  fold */
t11=((C_word*)((C_word*)t0)[3])[1];
f_5973(t11,t7,t8,t9,t10);}}

/* k6091 in k6009 in fold in k5969 in k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6093,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[98],t6));}

/* k6048 in k6009 in fold in k5969 in k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6050,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6030,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_cdr(((C_word*)t0)[7]);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 376  fold */
t10=((C_word*)((C_word*)t0)[2])[1];
f_5973(t10,t6,t7,t8,t9);}

/* k6028 in k6048 in k6009 in fold in k5969 in k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6030,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a5996 in fold in k5969 in k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5997,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6005,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 373  lookup */
t4=((C_word*)t0)[2];
f_5953(3,t4,t3,t2);}

/* k6003 in a5996 in fold in k5969 in k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_6005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6005,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k5989 in fold in k5969 in k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5993 in k5989 in fold in k5969 in k5962 in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5995,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k5950 in k5947 in k5944 in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5953(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5953,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_5904(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5904,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5927,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* chicken-syntax.scm: 348  proc */
t6=t2;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* chicken-syntax.scm: 347  proc */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}}

/* k5925 in map* in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5931,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 348  map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5904(t4,t2,((C_word*)t0)[2],t3);}

/* k5929 in k5925 in map* in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5931,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_5873(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5873,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5894,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken-syntax.scm: 344  append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k5892 in append* in k5869 in k5866 in k5857 in a5854 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5894,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5851 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 331  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[173],C_SCHEME_END_OF_LIST,t1);}

/* k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5781,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5783,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 384  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5782 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5783,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5787,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 386  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[172],t2,lf[174]);}

/* k5785 in a5782 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5787,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5796,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 389  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[65]);}

/* k5794 in k5785 in a5782 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 390  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[173]);}

/* k5797 in k5794 in k5785 in a5782 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5799,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5804,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li60),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5804(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k5797 in k5794 in k5785 in a5782 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_5804(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5804,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5822,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5841,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken-syntax.scm: 395  fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k5839 in fold in k5797 in k5794 in k5785 in a5782 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5841,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5820 in fold in k5797 in k5794 in k5785 in a5782 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5822,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5779 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 382  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[172],C_SCHEME_END_OF_LIST,t1);}

/* k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5615,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5617,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 399  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5617,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5621,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 401  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[168],t2,lf[171]);}

/* k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5621,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 404  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[65]);}

/* k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 405  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5771,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5773,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* a5772 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5773,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k5769 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[30]+1),t1);}

/* k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5639,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5755,a[2]=((C_word*)t0)[2],a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a5754 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5755,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5763,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5767,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 407  gensym */
t5=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5765 in a5754 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 407  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5761 in a5754 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5763,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5640,a[2]=t1,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5659,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5749,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5748 in k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5749,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[170]));}

/* k5657 in k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5663,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5667,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5673,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5672 in k5657 in k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5673,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5701,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
/* map */
t9=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}

/* k5699 in a5672 in k5657 in k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5705,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5709,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5711,a[2]=((C_word*)t0)[3],a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5710 in k5699 in a5672 in k5657 in k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5711,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5727,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 414  lookup */
t4=((C_word*)t0)[2];
f_5640(3,t4,t3,t2);}

/* k5725 in a5710 in k5699 in a5672 in k5657 in k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5727,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[169],t3));}

/* k5707 in k5699 in a5672 in k5657 in k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5703 in k5699 in a5672 in k5657 in k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5705,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[98],t5));}

/* k5665 in k5657 in k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5671,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5669 in k5665 in k5657 in k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5661 in k5657 in k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5663,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k5637 in k5634 in k5631 in k5628 in k5619 in a5616 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5640,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k5613 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 397  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[168],C_SCHEME_END_OF_LIST,t1);}

/* k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5611,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 420  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[165]);}

/* k5609 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5611,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[165],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5532,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5534,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 421  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a5533 in k5609 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5534,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5538,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 423  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[166],t2,lf[167]);}

/* k5536 in a5533 in k5609 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 424  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[133]);}

/* k5539 in k5536 in a5533 in k5609 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 425  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k5542 in k5539 in k5536 in a5533 in k5609 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5544,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5579,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 428  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[165]);}

/* k5577 in k5542 in k5539 in k5536 in a5533 in k5609 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5579,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[98],t10));}

/* k5530 in k5609 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 418  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[166],((C_word*)t0)[2],t1);}

/* k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5427,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5429,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 432  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5428 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5429,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5433,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 434  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[23]);}

/* k5431 in a5428 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5435,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li50),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5516,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5520,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 448  quotify-proc */
t6=t2;
f_5435(t6,t4,t5,lf[161]);}

/* k5518 in k5431 in a5428 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5514 in k5431 in a5428 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5516,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[164],t1));}

/* quotify-proc in k5431 in a5428 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_5435(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5435,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 437  ##sys#check-syntax */
t5=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t3,t2,lf[163]);}

/* k5437 in quotify-proc in k5431 in a5428 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5439,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5496,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t9=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t6=t5;
f_5448(t6,(C_word)C_i_cadr(((C_word*)t0)[5]));}}

/* k5494 in k5437 in quotify-proc in k5431 in a5428 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5496,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_5448(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5446 in k5437 in quotify-proc in k5431 in a5428 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_5448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5448,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5451,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5460,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_5460(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5470,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_car(t1);
/* chicken-syntax.scm: 443  c */
t8=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k5468 in k5446 in k5437 in quotify-proc in k5431 in a5428 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5460(t2,(C_word)C_i_not(t1));}

/* k5458 in k5446 in k5437 in quotify-proc in k5431 in a5428 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_5460(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-syntax.scm: 444  syntax-error */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[161],lf[162],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_5451(2,t2,C_SCHEME_UNDEFINED);}}

/* k5449 in k5446 in k5437 in quotify-proc in k5431 in a5428 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5451,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k5425 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 430  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[161],C_SCHEME_END_OF_LIST,t1);}

/* k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5264,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5266,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 452  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5265 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5266,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5270,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 454  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[159],t2,lf[160]);}

/* k5268 in a5265 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5270,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5279,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 457  r */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[120]);}

/* k5277 in k5268 in a5265 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 458  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k5280 in k5277 in k5268 in a5265 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5282,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5287,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li48),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5287(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k5280 in k5277 in k5268 in a5265 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_5287(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5287,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5301,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 461  r */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[56]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5361,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 465  fold */
t17=t7;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5399,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t10,a[5]=((C_word*)t0)[4],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 469  fold */
t17=t11;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5332,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 464  fold */
t17=t5;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}}

/* k5330 in fold in k5280 in k5277 in k5268 in a5265 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5332,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k5397 in fold in k5280 in k5277 in k5268 in a5265 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5399,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k5359 in fold in k5280 in k5277 in k5268 in a5265 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5361,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k5299 in fold in k5280 in k5277 in k5268 in a5265 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5305,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5303 in k5299 in fold in k5280 in k5277 in k5268 in a5265 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5305,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5262 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 450  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[159],C_SCHEME_END_OF_LIST,t1);}

/* k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5098,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5100,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 473  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5100,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5104,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 475  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[153],t2,lf[158]);}

/* k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5104,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5113,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 478  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[133]);}

/* k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 479  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[120]);}

/* k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 480  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[44]);}

/* k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 481  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[157]);}

/* k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 482  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[56]);}

/* k5123 in k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5132,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 483  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k5130 in k5123 in k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5132,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5148,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5150,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=t7,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word)li46),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_5150(t9,t5,((C_word*)t0)[2]);}

/* expand in k5130 in k5123 in k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_5150(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5150,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 489  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[153],t3,lf[155]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[156]);}}

/* k5164 in expand in k5130 in k5123 in k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5172,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm: 490  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k5170 in k5164 in expand in k5130 in k5123 in k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5172,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5179,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* ##sys#append */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5222,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5226,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5228,a[2]=((C_word*)t0)[2],a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
/* map */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a5227 in k5170 in k5164 in expand in k5130 in k5123 in k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5228,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[154],t4));}

/* k5224 in k5170 in k5164 in expand in k5130 in k5123 in k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5220 in k5170 in k5164 in expand in k5130 in k5123 in k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5222,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k5212 in k5220 in k5170 in k5164 in expand in k5130 in k5123 in k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5214,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5210,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 495  expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5150(t4,t3,((C_word*)t0)[2]);}

/* k5208 in k5212 in k5220 in k5170 in k5164 in expand in k5130 in k5123 in k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5210,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k5177 in k5170 in k5164 in expand in k5130 in k5123 in k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5179,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5146 in k5130 in k5123 in k5120 in k5117 in k5114 in k5111 in k5102 in a5099 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5148,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5096 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 471  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[153],C_SCHEME_END_OF_LIST,t1);}

/* k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5094,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 576  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[79]);}

/* k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5094,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[79],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5090,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 577  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[108]);}

/* k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5090,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[108],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4643,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4645,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 578  ##sys#er-transformer */
t7=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4645,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4649,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 580  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[139],t2,lf[152]);}

/* k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4649,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4661,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 584  r */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[120]);}

/* k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 585  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 586  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4669,a[2]=t1,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 624  ##sys#check-syntax */
t5=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[139],((C_word*)t0)[2],lf[151]);}

/* k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 625  ##sys#check-syntax */
t3=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[139],((C_word*)t0)[8],lf[150]);}

/* k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* map */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[79]+1),((C_word*)t0)[2]);}

/* k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4974,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5066,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a5065 in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5066,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5074,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 633  prefix-sym */
f_4974(t3,lf[149],t2);}

/* k5072 in a5065 in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 633  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4987 in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* map */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[148]+1),((C_word*)t0)[2]);}

/* k4990 in k4987 in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 637  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[147]);}

/* k4993 in k4990 in k4987 in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 640  r */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[146]);}

/* k4996 in k4993 in k4990 in k4987 in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[12]);}

/* a5055 in k4996 in k4993 in k4990 in k4987 in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5056,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5064,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 642  prefix-sym */
f_4974(t3,lf[145],t2);}

/* k5062 in a5055 in k4996 in k4993 in k4990 in k4987 in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 642  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4999 in k4996 in k4993 in k4990 in k4987 in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5004,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 645  make-default-procs */
t3=((C_word*)t0)[3];
f_4669(t3,t2,((C_word*)t0)[4],((C_word*)t0)[8],t1,((C_word*)t0)[2]);}

/* k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5007,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 647  make-if-tree */
t3=((C_word*)t0)[4];
f_4766(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[11]);}

/* k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5014,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 650  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[144]);}

/* k5012 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5014,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[4]);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,t1,t11));}

/* prefix-sym in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_4974(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4974,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4982,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4986,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 628  symbol->string */
t6=*((C_word*)lf[143]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k4984 in prefix-sym in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 628  string-append */
t2=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4980 in prefix-sym in k4971 in k4968 in k4965 in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 628  string->symbol */
t2=*((C_word*)lf[141]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* make-if-tree in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_4766(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4766,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4772,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t5,a[8]=((C_word)li39),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_4772(t9,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* recur in make-if-tree in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_4772(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4772,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4846,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 612  r */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[127]);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[127],t6);
t8=(C_word)C_i_car(t3);
t9=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4960,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=t7,a[10]=((C_word*)t0)[3],a[11]=t5,a[12]=((C_word*)t0)[7],a[13]=t8,tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 617  reverse */
t10=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}}

/* k4958 in recur in make-if-tree in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4960,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t1);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 618  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[79]);}

/* k4946 in k4958 in recur in make-if-tree in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4948,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t4);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4932,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t5,a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 619  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[108]);}

/* k4930 in k4946 in k4958 in recur in make-if-tree in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4932,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[6]);
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* chicken-syntax.scm: 620  recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_4772(t12,t8,t9,t10,t11);}

/* k4894 in k4930 in k4946 in k4958 in recur in make-if-tree in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k4844 in recur in make-if-tree in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4846,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[75],t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 613  reverse */
t7=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}

/* k4832 in k4844 in recur in make-if-tree in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4834,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[140],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[42],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[130],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[131],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t2,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t12));}

/* make-default-procs in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_4669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4669,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4677,a[2]=t4,a[3]=t5,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 592  reverse */
t7=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k4675 in make-default-procs in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 593  reverse */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4679 in k4675 in make-default-procs in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4685,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 594  reverse */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4683 in k4679 in k4675 in make-default-procs in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4685,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4687,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4687(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k4683 in k4679 in k4675 in make-default-procs in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_4687(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4687,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4740,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=((C_word*)t0)[3],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 599  reverse */
t9=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}}

/* k4738 in recur in k4683 in k4679 in k4675 in make-default-procs in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4756,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 600  reverse */
t4=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4754 in k4738 in recur in k4683 in k4679 in k4675 in make-default-procs in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4756,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k4750 in k4738 in recur in k4683 in k4679 in k4675 in make-default-procs in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4752,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4708,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm: 601  recur */
t12=((C_word*)((C_word*)t0)[3])[1];
f_4687(t12,t8,((C_word*)t0)[2],t9,t10,t11);}

/* k4706 in k4750 in k4738 in recur in k4683 in k4679 in k4675 in make-default-procs in k4665 in k4662 in k4659 in k4647 in a4644 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4641 in k5088 in k5092 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 574  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[139],((C_word*)t0)[2],t1);}

/* k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4635,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 670  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[127]);}

/* k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[127],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 671  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[79]);}

/* k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[79],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 672  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[108]);}

/* k4625 in k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4627,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[108],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4418,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4420,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 673  ##sys#er-transformer */
t8=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* a4419 in k4625 in k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4420,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4424,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 675  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[135],t2,lf[138]);}

/* k4422 in a4419 in k4625 in k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 676  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[133]);}

/* k4425 in k4422 in a4419 in k4625 in k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 677  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[120]);}

/* k4428 in k4425 in k4422 in a4419 in k4625 in k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 678  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k4435 in k4428 in k4425 in k4422 in a4419 in k4625 in k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4437,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 679  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[127]);}

/* k4585 in k4435 in k4428 in k4425 in k4422 in a4419 in k4625 in k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4587,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_4472(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4472(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[137],t4);}}}

/* k4470 in k4585 in k4435 in k4428 in k4425 in k4422 in a4419 in k4625 in k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 681  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[127]);}

/* k4546 in k4470 in k4585 in k4435 in k4428 in k4425 in k4422 in a4419 in k4625 in k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 681  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[108]);}

/* k4558 in k4546 in k4470 in k4585 in k4435 in k4428 in k4425 in k4422 in a4419 in k4625 in k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4560,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[75],t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t7,a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 682  r */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[79]);}

/* k4530 in k4558 in k4546 in k4470 in k4585 in k4435 in k4428 in k4425 in k4422 in a4419 in k4625 in k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4532,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[136],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[42],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[130],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[131],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t15);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t19);
t21=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t20));}

/* k4416 in k4625 in k4629 in k4633 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 668  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[135],((C_word*)t0)[2],t1);}

/* k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4410,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 705  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[127]);}

/* k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4410,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[127],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4104,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4106,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 706  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4106,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4110,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 708  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[128],t2,lf[134]);}

/* k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4110,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4122,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 712  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[65]);}

/* k4120 in k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 713  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[127]);}

/* k4123 in k4120 in k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 714  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[79]);}

/* k4126 in k4123 in k4120 in k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 715  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[108]);}

/* k4129 in k4126 in k4123 in k4120 in k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 716  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[120]);}

/* k4132 in k4129 in k4126 in k4123 in k4120 in k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 717  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[133]);}

/* k4135 in k4132 in k4129 in k4126 in k4123 in k4120 in k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4137,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4156,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],a[10]=((C_word)li34),tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_4158(t9,t5,t1,((C_word*)t0)[2]);}

/* loop in k4135 in k4132 in k4129 in k4126 in k4123 in k4120 in k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_4158(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4158,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[75],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4224,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t9=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4248,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 728  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[132]);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4386,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}}}

/* k4384 in loop in k4135 in k4132 in k4129 in k4126 in k4123 in k4120 in k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4386,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4246 in loop in k4135 in k4132 in k4129 in k4126 in k4123 in k4120 in k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[77],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4248,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t2,t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t14);
t16=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[42],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t18);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t17,t20);
t22=(C_word)C_a_i_cons(&a,2,t15,t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t1,t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t13,t26);
t28=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4267,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t29=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 735  loop */
t30=((C_word*)((C_word*)t0)[2])[1];
f_4158(t30,t28,t1,t29);}

/* k4265 in k4246 in loop in k4135 in k4132 in k4129 in k4126 in k4123 in k4120 in k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4267,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k4222 in loop in k4135 in k4132 in k4129 in k4126 in k4123 in k4120 in k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4224,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[129],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[42],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[130],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[131],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k4154 in k4135 in k4132 in k4129 in k4126 in k4123 in k4120 in k4108 in a4105 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4156,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k4102 in k4408 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 703  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[128],((C_word*)t0)[2],t1);}

/* k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4096,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 743  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[107]);}

/* k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4096,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[107],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 744  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[79]);}

/* k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4092,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[79],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 745  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[108]);}

/* k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4088,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[108],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 746  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[109]);}

/* k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4084,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[109],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3639,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3641,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 747  ##sys#er-transformer */
t9=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3641,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3645,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 749  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[110],t2,lf[126]);}

/* k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3647,a[2]=((C_word*)t0)[4],a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3682,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 755  require */
t4=*((C_word*)lf[124]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[125]);}

/* k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4035,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4037,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a4036 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4037,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4047,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 757  ##sys#decompose-lambda-list */
t5=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a4046 in a4036 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4047,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k4033 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[123]+1),t1);}

/* k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 761  genvars */
t3=((C_word*)t0)[2];
f_3647(t3,t2,t1);}

/* k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 762  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[122]);}

/* k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 763  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[121]);}

/* k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 764  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 765  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 766  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[107]);}

/* k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 767  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[109]);}

/* k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 768  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[79]);}

/* k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 769  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[108]);}

/* k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* chicken-syntax.scm: 770  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[120]);}

/* k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* chicken-syntax.scm: 771  append */
t3=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[8],((C_word*)t0)[14]);}

/* k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3726,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[111],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3750,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t1,a[5]=((C_word*)t0)[13],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3752,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word)li30),tmp=(C_word)a,a+=14,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 773  fold-right */
t10=*((C_word*)lf[118]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t8,lf[119],t9);}

/* a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3752,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t3,a[14]=((C_word*)t0)[12],a[15]=((C_word)li29),tmp=(C_word)a,a+=16,tmp);
/* chicken-syntax.scm: 775  ##sys#decompose-lambda-list */
t6=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t4,t5);}

/* a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3762,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],a[18]=t3,tmp=(C_word)a,a+=19,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm: 778  ##sys#check-syntax */
t7=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[110],t6,lf[116]);}

/* k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3766,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[18],((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3780,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[10])){
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t3;
f_3780(t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=t3;
f_3780(t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6));}}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=t3;
f_3780(t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}}

/* k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_3780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3780,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=t1,a[5]=((C_word*)t0)[15],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3794,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li28),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a3803 in k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3804,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3808,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3831,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word)li27),tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_3831(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a3803 in k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_3831(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3831,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3856,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* ##sys#append */
t9=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[6]));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3888,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* ##sys#append */
t7=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3979,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 793  gensym */
t6=*((C_word*)lf[61]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k3977 in build in a3803 in k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 793  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3897 in build in a3803 in k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3899,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t2,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t1,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3918,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t12,tmp=(C_word)a,a+=5,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken-syntax.scm: 797  build */
t16=((C_word*)((C_word*)t0)[2])[1];
f_3831(t16,t13,t15,t1);}
else{
/* chicken-syntax.scm: 798  build */
t15=((C_word*)((C_word*)t0)[2])[1];
f_3831(t15,t13,C_SCHEME_END_OF_LIST,t1);}}

/* k3916 in k3897 in build in a3803 in k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3918,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k3886 in build in a3803 in k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3888,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3854 in build in a3803 in k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3856,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3806 in a3803 in k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3808,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3825,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 801  map */
t3=*((C_word*)lf[114]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[115]+1),((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k3823 in k3806 in a3803 in k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3825,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a3793 in k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3802,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 786  take */
t3=*((C_word*)lf[113]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3800 in a3793 in k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 786  split-at! */
t2=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3786 in k3778 in k3764 in a3761 in a3751 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3788,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3748 in k3724 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3750,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* genvars in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_3647(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3647,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3653,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3653(t6,t1,C_fix(0));}

/* loop in genvars in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_3653(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3653,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3667,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3679,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 754  gensym */
t5=*((C_word*)lf[61]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3677 in loop in genvars in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 754  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3665 in loop in genvars in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3671,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm: 754  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3653(t4,t2,t3);}

/* k3669 in k3665 in loop in genvars in k3643 in a3640 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3671,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3637 in k4082 in k4086 in k4090 in k4094 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 741  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[110],((C_word*)t0)[2],t1);}

/* k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3537,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3539,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 811  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a3538 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3539,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3543,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 813  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[102],t2,lf[106]);}

/* k3541 in a3538 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3543,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken-syntax.scm: 817  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[102],t5,lf[104]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3608,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken-syntax.scm: 824  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[102],t5,lf[105]);}}

/* k3606 in k3541 in a3538 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3608,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[42],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3623,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3621 in k3606 in k3541 in a3538 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3623,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[103],t2));}

/* k3556 in k3541 in a3538 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3558,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[42],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3581,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 822  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[23]);}

/* k3579 in k3556 in k3541 in a3538 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3581,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3591 in k3579 in k3556 in k3541 in a3538 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3593,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[103],t5));}

/* k3535 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 809  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[102],C_SCHEME_END_OF_LIST,t1);}

/* k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3533,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 832  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[94]);}

/* k3531 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3533,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[94],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3529,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 833  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[95]);}

/* k3527 in k3531 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3529,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[95],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3323,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3325,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 834  ##sys#er-transformer */
t7=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a3324 in k3527 in k3531 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3325,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3329,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 836  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[89],t2,lf[101]);}

/* k3327 in a3324 in k3527 in k3531 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 837  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[100]);}

/* k3330 in k3327 in a3324 in k3527 in k3531 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 838  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[99]);}

/* k3333 in k3330 in k3327 in a3324 in k3527 in k3531 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 839  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k3336 in k3333 in k3330 in k3327 in a3324 in k3527 in k3531 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 840  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[94]);}

/* k3347 in k3336 in k3333 in k3330 in k3327 in a3324 in k3527 in k3531 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3349,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 842  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[95]);}

/* k3375 in k3347 in k3336 in k3333 in k3330 in k3327 in a3324 in k3527 in k3531 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3377,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_i_caddr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t12,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t14=(C_word)C_i_cdddr(((C_word*)t0)[8]);
/* ##sys#append */
t15=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}

/* k3467 in k3375 in k3347 in k3336 in k3333 in k3330 in k3327 in a3324 in k3527 in k3531 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[84],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[96],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[97],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[23],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=(C_word)C_a_i_cons(&a,2,lf[98],t16);
t18=(C_word)C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t18);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t24);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t27);
t29=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST));}

/* k3321 in k3527 in k3531 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 830  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[89],((C_word*)t0)[2],t1);}

/* k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3315,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 853  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[44]);}

/* k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[44],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 854  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[83]);}

/* k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[83],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2969,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2971,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 855  ##sys#er-transformer */
t7=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2971,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2975,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 857  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[84],t2,lf[93]);}

/* k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 858  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[92]);}

/* k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 859  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[91]);}

/* k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 860  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[90]);}

/* k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 861  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 862  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[42]);}

/* k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 863  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[83]);}

/* k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 864  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[44]);}

/* k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t1,a[9]=((C_word)li20),tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3171,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 878  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[89]);}

/* k3169 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3171,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[85],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[71],t5);
t7=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[86],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3211,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t15,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 881  r */
t17=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[88]);}

/* k3209 in k3169 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3215,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3219,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k3217 in k3209 in k3169 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3219,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[87],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t7=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t1,t6);}

/* k3213 in k3209 in k3169 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3215,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t5,t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* parse-clause in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2998,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3025,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[6],a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t13=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,t7,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[6],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t10=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t7,C_SCHEME_END_OF_LIST);}}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3116,a[2]=t7,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3120,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word)li19),tmp=(C_word)a,a+=6,tmp);
/* map */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t6);}}

/* a3121 in parse-clause in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3122,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k3118 in parse-clause in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3114 in parse-clause in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3116,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3074,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3089,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3108,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k3106 in k3114 in parse-clause in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3108,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_3074(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3087 in k3114 in parse-clause in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3089,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_3074(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3072 in k3114 in parse-clause in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_3074(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3074,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3057 in parse-clause in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_3025(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3038 in parse-clause in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_3025(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3023 in parse-clause in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in a2970 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_3025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3025,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2967 in k3309 in k3313 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 851  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[84],((C_word*)t0)[2],t1);}

/* k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[68],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[42],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[66],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[68],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2567,a[2]=t8,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2569,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 891  ##sys#er-transformer */
t11=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}

/* a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2569,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2573,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 893  ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[69],t2,lf[82]);}

/* k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2573,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cddddr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2588,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 898  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[56]);}

/* k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 899  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 900  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[31]);}

/* k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 901  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[42]);}

/* k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 902  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[68]);}

/* k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2600,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 904  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[81]);}

/* k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 905  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[80]);}

/* k2607 in k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* map */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[79]+1),((C_word*)t0)[3]);}

/* k2610 in k2607 in k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2612,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2928,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2930,a[2]=((C_word*)t0)[2],a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}

/* a2929 in k2610 in k2607 in k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2930,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[78]));}

/* k2926 in k2610 in k2607 in k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2922 in k2610 in k2607 in k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[67],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[70],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[71],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t8,t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t15);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t6,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t20,a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word)li16),tmp=(C_word)a,a+=11,tmp));
t22=((C_word*)t20)[1];
f_2641(t22,t18,((C_word*)t0)[2],C_fix(1));}

/* loop in k2922 in k2610 in k2607 in k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_2641(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2641,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[72],*((C_word*)lf[73]+1));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[74],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[75],t14);
t16=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[76],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t15,t19);
t21=(C_word)C_a_i_cons(&a,2,t8,t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2667,a[2]=((C_word*)t0)[3],a[3]=t22,a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[5],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t7)){
t24=(C_word)C_i_caddr(t4);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t25);
t27=(C_word)C_a_i_cons(&a,2,t24,t26);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t29=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t30);
t32=(C_word)C_a_i_cons(&a,2,lf[74],t31);
t33=(C_word)C_a_i_cons(&a,2,t32,C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[75],t33);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,t3,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t36);
t38=(C_word)C_a_i_cons(&a,2,lf[77],t37);
t39=(C_word)C_a_i_cons(&a,2,t38,C_SCHEME_END_OF_LIST);
t40=(C_word)C_a_i_cons(&a,2,t34,t39);
t41=(C_word)C_a_i_cons(&a,2,t27,t40);
t42=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t41);
t43=t23;
f_2667(t43,(C_word)C_a_i_cons(&a,2,t42,C_SCHEME_END_OF_LIST));}
else{
t24=t23;
f_2667(t24,C_SCHEME_END_OF_LIST);}}}

/* k2665 in loop in k2922 in k2610 in k2607 in k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_2667(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2667,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2707,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=t3;
f_2707(t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}
else{
t5=t3;
f_2707(t5,((C_word*)t0)[3]);}}

/* k2705 in k2665 in loop in k2922 in k2610 in k2607 in k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_2707(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2707,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2679,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2683,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* chicken-syntax.scm: 935  loop */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2641(t9,t6,t7,t8);}

/* k2681 in k2705 in k2665 in loop in k2922 in k2610 in k2607 in k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2677 in k2705 in k2665 in loop in k2922 in k2610 in k2607 in k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2679,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2637 in k2922 in k2610 in k2607 in k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2633 in k2922 in k2610 in k2607 in k2604 in k2598 in k2595 in k2592 in k2589 in k2586 in k2571 in a2568 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2635,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2565 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 888  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[69],((C_word*)t0)[2],t1);}

/* k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2559,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 942  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[59]);}

/* k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2559,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[59],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2367,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2369,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 943  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2369,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2373,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 945  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[64]);}

/* k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 946  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[63]);}

/* k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 947  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[59]);}

/* k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 948  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[56]);}

/* k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 949  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2385,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2394,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word)li14),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2394(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_2394(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2394,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2404,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 952  reverse */
t7=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_i_car(t2);
/* chicken-syntax.scm: 959  c */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k2495 in loop in k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2497,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2519,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 960  gensym */
t4=*((C_word*)lf[61]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2525,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm: 962  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k2523 in k2495 in loop in k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2525,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm: 962  loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2394(t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* chicken-syntax.scm: 963  loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2394(t5,((C_word*)t0)[5],t2,((C_word*)t0)[4],t4,C_SCHEME_FALSE);}}

/* k2517 in k2495 in loop in k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 960  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2498 in k2495 in loop in k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2500,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm: 961  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2394(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k2402 in loop in k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 953  reverse */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2405 in k2402 in loop in k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2407,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2456,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 955  gensym */
t4=*((C_word*)lf[61]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(t1);
/* ##sys#append */
t7=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}

/* k2477 in k2405 in k2402 in loop in k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k2454 in k2405 in k2402 in loop in k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 955  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2411 in k2405 in k2402 in loop in k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2424,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2422 in k2411 in k2405 in k2402 in loop in k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2424,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k2442 in k2422 in k2411 in k2405 in k2402 in loop in k2383 in k2380 in k2377 in k2374 in k2371 in a2368 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k2365 in k2557 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 940  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[67],((C_word*)t0)[2],t1);}

/* k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 967  ##sys#primitive-alias */
t4=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[59]);}

/* k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2359,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[59],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2136,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2138,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 968  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2138,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2142,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 970  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[65]);}

/* k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2145,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 971  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 972  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[59]);}

/* k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 973  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[64]);}

/* k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2154,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 974  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[63]);}

/* k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2154,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word)li12),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2163(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_2163(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2163,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2173,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t6,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 977  reverse */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_i_car(t2);
/* chicken-syntax.scm: 987  c */
t9=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k2280 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2282,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2304,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 988  gensym */
t4=*((C_word*)lf[61]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2310,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* chicken-syntax.scm: 990  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k2308 in k2280 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2310,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm: 990  loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2163(t2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2343,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 992  gensym */
t4=*((C_word*)lf[61]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2341 in k2308 in k2280 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 992  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2314 in k2308 in k2280 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2316,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-syntax.scm: 993  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2163(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k2302 in k2280 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 988  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2283 in k2280 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-syntax.scm: 989  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2163(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k2171 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 978  reverse */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2174 in k2171 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2182,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2237,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 980  gensym */
t4=*((C_word*)lf[61]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2272,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(t1);
/* ##sys#append */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k2270 in k2174 in k2171 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2272,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k2235 in k2174 in k2171 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 980  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2180 in k2174 in k2171 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2205,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2203 in k2180 in k2174 in k2171 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2205,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2225,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k2223 in k2203 in k2180 in k2174 in k2171 in loop in k2152 in k2149 in k2146 in k2143 in k2140 in a2137 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k2134 in k2357 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 965  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[60],((C_word*)t0)[2],t1);}

/* k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1855,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1857,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1003 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1857,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1861,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 1005 ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[37],t2,lf[58]);}

/* k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 1006 r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}

/* k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 1007 r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[56]);}

/* k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 1008 r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[55]);}

/* k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 1009 r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[54]);}

/* k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 1010 r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[53]);}

/* k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word)li10),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_1885(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2,C_SCHEME_FALSE);}

/* loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_1885(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1885,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1895,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[9],a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t8=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t5,C_SCHEME_END_OF_LIST);}
else{
t7=t6;
f_1895(t7,lf[47]);}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[5],a[10]=t2,a[11]=((C_word*)t0)[6],a[12]=t4,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_2031(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_2031(t7,C_SCHEME_FALSE);}}}

/* k2029 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_2031(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2031,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 1025 caar */
t3=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[12]);}
else{
/* chicken-syntax.scm: 1036 syntax-error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[8],lf[37],lf[52],((C_word*)t0)[12]);}}

/* k2032 in k2029 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2034,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2043,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 1027 c */
t4=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t1);}

/* k2041 in k2032 in k2029 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2043,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2062,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1028 cdar */
t4=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 1029 c */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k2066 in k2041 in k2032 in k2029 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2087,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1030 cdar */
t4=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 1031 c */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2091 in k2066 in k2041 in k2032 in k2029 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2100,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=(C_truep(t3)?t3:C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2108,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1032 cdar */
t6=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2115,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1034 caar */
t3=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k2113 in k2091 in k2066 in k2041 in k2032 in k2029 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1034 syntax-error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[37],lf[50],t1);}

/* k2106 in k2091 in k2066 in k2041 in k2032 in k2029 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1032 append */
t2=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2098 in k2091 in k2066 in k2041 in k2032 in k2029 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1032 loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1885(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2085 in k2066 in k2041 in k2032 in k2029 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2081 in k2066 in k2041 in k2032 in k2029 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2083,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken-syntax.scm: 1030 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1885(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2060 in k2041 in k2032 in k2029 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2056 in k2041 in k2032 in k2029 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2058,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken-syntax.scm: 1028 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1885(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2023 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2025,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
f_1895(t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1893 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_1895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1895,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 1016 r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[46]);}

/* k1900 in k1893 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k2008 in k1900 in k1893 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2010,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[38],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 1018 r */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[45]);}

/* k1996 in k2008 in k1900 in k1893 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1998,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[39],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1992 in k1996 in k2008 in k1900 in k1893 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1994,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 1019 r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[44]);}

/* k1928 in k1992 in k1996 in k2008 in k1900 in k1893 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[40]+1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[41],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=t5,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 1022 r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[43]);}

/* k1956 in k1928 in k1992 in k1996 in k2008 in k1900 in k1893 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 1022 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[42]);}

/* k1968 in k1956 in k1928 in k1992 in k1996 in k2008 in k1900 in k1893 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[40]+1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t7=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1952 in k1968 in k1956 in k1928 in k1992 in k1996 in k2008 in k1900 in k1893 in loop in k1874 in k1871 in k1868 in k1865 in k1862 in k1859 in a1856 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k1853 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1001 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[37],C_SCHEME_END_OF_LIST,t1);}

/* k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1751,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1753,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1045 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1752 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1753,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1757,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1047 ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[34],t2,lf[36]);}

/* k1755 in a1752 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1757,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 1049 r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[35]);}

/* k1761 in k1755 in a1752 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1763,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 1052 r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[23]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1847,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k1845 in k1761 in k1755 in a1752 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1847,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k1806 in k1761 in k1755 in a1752 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1808,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k1818 in k1806 in k1761 in k1755 in a1752 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k1749 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1043 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[34],C_SCHEME_END_OF_LIST,t1);}

/* k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1714,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1716,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1062 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1715 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1716,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1720,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1064 ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[29],t2,lf[33]);}

/* k1718 in a1715 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1065 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[32]);}

/* k1725 in k1718 in a1715 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1739,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1066 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[31]);}

/* k1737 in k1725 in k1718 in a1715 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1743,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k1741 in k1737 in k1725 in k1718 in a1715 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1743,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1712 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1060 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[29],C_SCHEME_END_OF_LIST,t1);}

/* k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1689,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1691,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1073 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1690 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1691,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1695,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1075 ##sys#check-syntax */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[25],t2,lf[28]);}

/* k1693 in a1690 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1695,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[26],t4));}

/* k1687 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1071 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[25],C_SCHEME_END_OF_LIST,t1);}

/* k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1557,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1559,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1083 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1558 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1559,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1569,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cdr(t5);
/* ##sys#list? */
t9=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t6,t8);}
else{
t8=t6;
f_1569(2,t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_1569(2,t7,C_SCHEME_FALSE);}}

/* k1567 in a1558 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1569,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t6,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* rename11251130 */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[22]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cdr(t3);
t5=t2;
f_1619(t5,(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST));}
else{
t4=t2;
f_1619(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_1619(t3,C_SCHEME_FALSE);}}}

/* k1617 in k1567 in a1558 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_1619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1619,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1632,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* rename11251130 */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[24]);}
else{
/* ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k1630 in k1617 in k1567 in a1558 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1632,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k1583 in k1567 in a1558 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1601,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* rename11251130 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[23]);}

/* k1599 in k1583 in k1567 in a1558 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1601,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k1555 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1081 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[22],C_SCHEME_END_OF_LIST,t1);}

/* k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1410,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1412,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1092 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1412,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1422,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1492,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_car(t5);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1505,a[2]=t10,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_1505(t12,t7,t8);}
else{
t7=t6;
f_1422(2,t7,C_SCHEME_FALSE);}}

/* loop1169 in a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_1505(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1505,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#null? */
t4=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1507 in loop1169 in a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1509,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cdr(t4);
t6=t3;
f_1527(t6,(C_word)C_eqp(t5,C_SCHEME_END_OF_LIST));}
else{
t5=t3;
f_1527(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_1527(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k1525 in k1507 in loop1169 in a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_fcall f_1527(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop11691191 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1505(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1490 in a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* ##sys#list? */
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
f_1422(2,t2,C_SCHEME_FALSE);}}

/* k1420 in a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1422,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1472,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* ##sys#map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
/* ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a1471 in k1420 in a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1472,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k1423 in k1420 in a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1428,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1458,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
/* ##sys#map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a1457 in k1423 in k1420 in a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1458,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t3));}

/* k1426 in k1423 in k1420 in a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1428,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1438,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* rename11721177 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[17]);}

/* k1436 in k1426 in k1423 in k1420 in a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1446,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1448,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
/* ##sys#map-n */
t4=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1447 in k1436 in k1426 in k1423 in k1420 in a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1448,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t2,t4));}

/* k1444 in k1436 in k1426 in k1423 in k1420 in a1411 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1446,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k1408 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1090 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[15],C_SCHEME_END_OF_LIST,t1);}

/* k1385 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1400,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1402,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1102 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1401 in k1385 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1402,5,t0,t1,t2,t3,t4);}
/* chicken-syntax.scm: 1104 syntax-error */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[11],lf[13]);}

/* k1398 in k1385 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1100 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[11],C_SCHEME_END_OF_LIST,t1);}

/* k1388 in k1385 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1393,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1107 ##sys#macro-subset */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],*((C_word*)lf[9]+1));}

/* k1391 in k1388 in k1385 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1393,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! chicken-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1112 register-feature! */
t4=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t3,lf[2],lf[3],lf[4],lf[5],lf[6],lf[7]);}

/* k1394 in k1391 in k1388 in k1385 in k1382 in k1379 in k1376 in k1373 in k1370 in k1367 in k1364 in k1361 in k1358 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 in k1274 in k1270 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[628] = {
{"toplevel:chicken_syntax_scm",(void*)C_chicken_syntax_toplevel},
{"f_1272:chicken_syntax_scm",(void*)f_1272},
{"f_1276:chicken_syntax_scm",(void*)f_1276},
{"f_7710:chicken_syntax_scm",(void*)f_7710},
{"f_7714:chicken_syntax_scm",(void*)f_7714},
{"f_7723:chicken_syntax_scm",(void*)f_7723},
{"f_7726:chicken_syntax_scm",(void*)f_7726},
{"f_7732:chicken_syntax_scm",(void*)f_7732},
{"f_7735:chicken_syntax_scm",(void*)f_7735},
{"f_7738:chicken_syntax_scm",(void*)f_7738},
{"f_7741:chicken_syntax_scm",(void*)f_7741},
{"f_8151:chicken_syntax_scm",(void*)f_8151},
{"f_8111:chicken_syntax_scm",(void*)f_8111},
{"f_8143:chicken_syntax_scm",(void*)f_8143},
{"f_8103:chicken_syntax_scm",(void*)f_8103},
{"f_8059:chicken_syntax_scm",(void*)f_8059},
{"f_7770:chicken_syntax_scm",(void*)f_7770},
{"f_7780:chicken_syntax_scm",(void*)f_7780},
{"f_8047:chicken_syntax_scm",(void*)f_8047},
{"f_7783:chicken_syntax_scm",(void*)f_7783},
{"f_8043:chicken_syntax_scm",(void*)f_8043},
{"f_7786:chicken_syntax_scm",(void*)f_7786},
{"f_7833:chicken_syntax_scm",(void*)f_7833},
{"f_7797:chicken_syntax_scm",(void*)f_7797},
{"f_7768:chicken_syntax_scm",(void*)f_7768},
{"f_7764:chicken_syntax_scm",(void*)f_7764},
{"f_7708:chicken_syntax_scm",(void*)f_7708},
{"f_1279:chicken_syntax_scm",(void*)f_1279},
{"f_7567:chicken_syntax_scm",(void*)f_7567},
{"f_7571:chicken_syntax_scm",(void*)f_7571},
{"f_7574:chicken_syntax_scm",(void*)f_7574},
{"f_7577:chicken_syntax_scm",(void*)f_7577},
{"f_7613:chicken_syntax_scm",(void*)f_7613},
{"f_7628:chicken_syntax_scm",(void*)f_7628},
{"f_7682:chicken_syntax_scm",(void*)f_7682},
{"f_7643:chicken_syntax_scm",(void*)f_7643},
{"f_7606:chicken_syntax_scm",(void*)f_7606},
{"f_7565:chicken_syntax_scm",(void*)f_7565},
{"f_1282:chicken_syntax_scm",(void*)f_1282},
{"f_7468:chicken_syntax_scm",(void*)f_7468},
{"f_7472:chicken_syntax_scm",(void*)f_7472},
{"f_7475:chicken_syntax_scm",(void*)f_7475},
{"f_7478:chicken_syntax_scm",(void*)f_7478},
{"f_7557:chicken_syntax_scm",(void*)f_7557},
{"f_7466:chicken_syntax_scm",(void*)f_7466},
{"f_1285:chicken_syntax_scm",(void*)f_1285},
{"f_7450:chicken_syntax_scm",(void*)f_7450},
{"f_7458:chicken_syntax_scm",(void*)f_7458},
{"f_7448:chicken_syntax_scm",(void*)f_7448},
{"f_1288:chicken_syntax_scm",(void*)f_1288},
{"f_7361:chicken_syntax_scm",(void*)f_7361},
{"f_7365:chicken_syntax_scm",(void*)f_7365},
{"f_7368:chicken_syntax_scm",(void*)f_7368},
{"f_7371:chicken_syntax_scm",(void*)f_7371},
{"f_7437:chicken_syntax_scm",(void*)f_7437},
{"f_7374:chicken_syntax_scm",(void*)f_7374},
{"f_7387:chicken_syntax_scm",(void*)f_7387},
{"f_7431:chicken_syntax_scm",(void*)f_7431},
{"f_7398:chicken_syntax_scm",(void*)f_7398},
{"f_7406:chicken_syntax_scm",(void*)f_7406},
{"f_7408:chicken_syntax_scm",(void*)f_7408},
{"f_7425:chicken_syntax_scm",(void*)f_7425},
{"f_7393:chicken_syntax_scm",(void*)f_7393},
{"f_7385:chicken_syntax_scm",(void*)f_7385},
{"f_7381:chicken_syntax_scm",(void*)f_7381},
{"f_7359:chicken_syntax_scm",(void*)f_7359},
{"f_1291:chicken_syntax_scm",(void*)f_1291},
{"f_7262:chicken_syntax_scm",(void*)f_7262},
{"f_7266:chicken_syntax_scm",(void*)f_7266},
{"f_7275:chicken_syntax_scm",(void*)f_7275},
{"f_7278:chicken_syntax_scm",(void*)f_7278},
{"f_7281:chicken_syntax_scm",(void*)f_7281},
{"f_7316:chicken_syntax_scm",(void*)f_7316},
{"f_7260:chicken_syntax_scm",(void*)f_7260},
{"f_1294:chicken_syntax_scm",(void*)f_1294},
{"f_7125:chicken_syntax_scm",(void*)f_7125},
{"f_7129:chicken_syntax_scm",(void*)f_7129},
{"f_7141:chicken_syntax_scm",(void*)f_7141},
{"f_7144:chicken_syntax_scm",(void*)f_7144},
{"f_7147:chicken_syntax_scm",(void*)f_7147},
{"f_7198:chicken_syntax_scm",(void*)f_7198},
{"f_7194:chicken_syntax_scm",(void*)f_7194},
{"f_7123:chicken_syntax_scm",(void*)f_7123},
{"f_1297:chicken_syntax_scm",(void*)f_1297},
{"f_6867:chicken_syntax_scm",(void*)f_6867},
{"f_6871:chicken_syntax_scm",(void*)f_6871},
{"f_6880:chicken_syntax_scm",(void*)f_6880},
{"f_7111:chicken_syntax_scm",(void*)f_7111},
{"f_7119:chicken_syntax_scm",(void*)f_7119},
{"f_6883:chicken_syntax_scm",(void*)f_6883},
{"f_7101:chicken_syntax_scm",(void*)f_7101},
{"f_7109:chicken_syntax_scm",(void*)f_7109},
{"f_6886:chicken_syntax_scm",(void*)f_6886},
{"f_6889:chicken_syntax_scm",(void*)f_6889},
{"f_6892:chicken_syntax_scm",(void*)f_6892},
{"f_7099:chicken_syntax_scm",(void*)f_7099},
{"f_7059:chicken_syntax_scm",(void*)f_7059},
{"f_7077:chicken_syntax_scm",(void*)f_7077},
{"f_7091:chicken_syntax_scm",(void*)f_7091},
{"f_7071:chicken_syntax_scm",(void*)f_7071},
{"f_7067:chicken_syntax_scm",(void*)f_7067},
{"f_7063:chicken_syntax_scm",(void*)f_7063},
{"f_6903:chicken_syntax_scm",(void*)f_6903},
{"f_7043:chicken_syntax_scm",(void*)f_7043},
{"f_7011:chicken_syntax_scm",(void*)f_7011},
{"f_7029:chicken_syntax_scm",(void*)f_7029},
{"f_7019:chicken_syntax_scm",(void*)f_7019},
{"f_7015:chicken_syntax_scm",(void*)f_7015},
{"f_7007:chicken_syntax_scm",(void*)f_7007},
{"f_6999:chicken_syntax_scm",(void*)f_6999},
{"f_6979:chicken_syntax_scm",(void*)f_6979},
{"f_6947:chicken_syntax_scm",(void*)f_6947},
{"f_6965:chicken_syntax_scm",(void*)f_6965},
{"f_6955:chicken_syntax_scm",(void*)f_6955},
{"f_6951:chicken_syntax_scm",(void*)f_6951},
{"f_6943:chicken_syntax_scm",(void*)f_6943},
{"f_6865:chicken_syntax_scm",(void*)f_6865},
{"f_1300:chicken_syntax_scm",(void*)f_1300},
{"f_6746:chicken_syntax_scm",(void*)f_6746},
{"f_6750:chicken_syntax_scm",(void*)f_6750},
{"f_6756:chicken_syntax_scm",(void*)f_6756},
{"f_6857:chicken_syntax_scm",(void*)f_6857},
{"f_6762:chicken_syntax_scm",(void*)f_6762},
{"f_6765:chicken_syntax_scm",(void*)f_6765},
{"f_6768:chicken_syntax_scm",(void*)f_6768},
{"f_6808:chicken_syntax_scm",(void*)f_6808},
{"f_6831:chicken_syntax_scm",(void*)f_6831},
{"f_6838:chicken_syntax_scm",(void*)f_6838},
{"f_6845:chicken_syntax_scm",(void*)f_6845},
{"f_6821:chicken_syntax_scm",(void*)f_6821},
{"f_6771:chicken_syntax_scm",(void*)f_6771},
{"f_6744:chicken_syntax_scm",(void*)f_6744},
{"f_1303:chicken_syntax_scm",(void*)f_1303},
{"f_6544:chicken_syntax_scm",(void*)f_6544},
{"f_6548:chicken_syntax_scm",(void*)f_6548},
{"f_6557:chicken_syntax_scm",(void*)f_6557},
{"f_6560:chicken_syntax_scm",(void*)f_6560},
{"f_6563:chicken_syntax_scm",(void*)f_6563},
{"f_6566:chicken_syntax_scm",(void*)f_6566},
{"f_6569:chicken_syntax_scm",(void*)f_6569},
{"f_6732:chicken_syntax_scm",(void*)f_6732},
{"f_6740:chicken_syntax_scm",(void*)f_6740},
{"f_6572:chicken_syntax_scm",(void*)f_6572},
{"f_6722:chicken_syntax_scm",(void*)f_6722},
{"f_6730:chicken_syntax_scm",(void*)f_6730},
{"f_6575:chicken_syntax_scm",(void*)f_6575},
{"f_6716:chicken_syntax_scm",(void*)f_6716},
{"f_6720:chicken_syntax_scm",(void*)f_6720},
{"f_6586:chicken_syntax_scm",(void*)f_6586},
{"f_6660:chicken_syntax_scm",(void*)f_6660},
{"f_6658:chicken_syntax_scm",(void*)f_6658},
{"f_6654:chicken_syntax_scm",(void*)f_6654},
{"f_6634:chicken_syntax_scm",(void*)f_6634},
{"f_6542:chicken_syntax_scm",(void*)f_6542},
{"f_1306:chicken_syntax_scm",(void*)f_1306},
{"f_6499:chicken_syntax_scm",(void*)f_6499},
{"f_6503:chicken_syntax_scm",(void*)f_6503},
{"f_6510:chicken_syntax_scm",(void*)f_6510},
{"f_6530:chicken_syntax_scm",(void*)f_6530},
{"f_6534:chicken_syntax_scm",(void*)f_6534},
{"f_6497:chicken_syntax_scm",(void*)f_6497},
{"f_1309:chicken_syntax_scm",(void*)f_1309},
{"f_6446:chicken_syntax_scm",(void*)f_6446},
{"f_6450:chicken_syntax_scm",(void*)f_6450},
{"f_6457:chicken_syntax_scm",(void*)f_6457},
{"f_6485:chicken_syntax_scm",(void*)f_6485},
{"f_6489:chicken_syntax_scm",(void*)f_6489},
{"f_6444:chicken_syntax_scm",(void*)f_6444},
{"f_1312:chicken_syntax_scm",(void*)f_1312},
{"f_6301:chicken_syntax_scm",(void*)f_6301},
{"f_6305:chicken_syntax_scm",(void*)f_6305},
{"f_6314:chicken_syntax_scm",(void*)f_6314},
{"f_6383:chicken_syntax_scm",(void*)f_6383},
{"f_6416:chicken_syntax_scm",(void*)f_6416},
{"f_6414:chicken_syntax_scm",(void*)f_6414},
{"f_6410:chicken_syntax_scm",(void*)f_6410},
{"f_6299:chicken_syntax_scm",(void*)f_6299},
{"f_1315:chicken_syntax_scm",(void*)f_1315},
{"f_6243:chicken_syntax_scm",(void*)f_6243},
{"f_6247:chicken_syntax_scm",(void*)f_6247},
{"f_6271:chicken_syntax_scm",(void*)f_6271},
{"f_6295:chicken_syntax_scm",(void*)f_6295},
{"f_6284:chicken_syntax_scm",(void*)f_6284},
{"f_6250:chicken_syntax_scm",(void*)f_6250},
{"f_6257:chicken_syntax_scm",(void*)f_6257},
{"f_6261:chicken_syntax_scm",(void*)f_6261},
{"f_6241:chicken_syntax_scm",(void*)f_6241},
{"f_1318:chicken_syntax_scm",(void*)f_1318},
{"f_5855:chicken_syntax_scm",(void*)f_5855},
{"f_5859:chicken_syntax_scm",(void*)f_5859},
{"f_5868:chicken_syntax_scm",(void*)f_5868},
{"f_5871:chicken_syntax_scm",(void*)f_5871},
{"f_5946:chicken_syntax_scm",(void*)f_5946},
{"f_6199:chicken_syntax_scm",(void*)f_6199},
{"f_6212:chicken_syntax_scm",(void*)f_6212},
{"f_5949:chicken_syntax_scm",(void*)f_5949},
{"f_6185:chicken_syntax_scm",(void*)f_6185},
{"f_6197:chicken_syntax_scm",(void*)f_6197},
{"f_6193:chicken_syntax_scm",(void*)f_6193},
{"f_5952:chicken_syntax_scm",(void*)f_5952},
{"f_6139:chicken_syntax_scm",(void*)f_6139},
{"f_6172:chicken_syntax_scm",(void*)f_6172},
{"f_6179:chicken_syntax_scm",(void*)f_6179},
{"f_6155:chicken_syntax_scm",(void*)f_6155},
{"f_5964:chicken_syntax_scm",(void*)f_5964},
{"f_6133:chicken_syntax_scm",(void*)f_6133},
{"f_5971:chicken_syntax_scm",(void*)f_5971},
{"f_5973:chicken_syntax_scm",(void*)f_5973},
{"f_6127:chicken_syntax_scm",(void*)f_6127},
{"f_6011:chicken_syntax_scm",(void*)f_6011},
{"f_6093:chicken_syntax_scm",(void*)f_6093},
{"f_6050:chicken_syntax_scm",(void*)f_6050},
{"f_6030:chicken_syntax_scm",(void*)f_6030},
{"f_5997:chicken_syntax_scm",(void*)f_5997},
{"f_6005:chicken_syntax_scm",(void*)f_6005},
{"f_5991:chicken_syntax_scm",(void*)f_5991},
{"f_5995:chicken_syntax_scm",(void*)f_5995},
{"f_5953:chicken_syntax_scm",(void*)f_5953},
{"f_5904:chicken_syntax_scm",(void*)f_5904},
{"f_5927:chicken_syntax_scm",(void*)f_5927},
{"f_5931:chicken_syntax_scm",(void*)f_5931},
{"f_5873:chicken_syntax_scm",(void*)f_5873},
{"f_5894:chicken_syntax_scm",(void*)f_5894},
{"f_5853:chicken_syntax_scm",(void*)f_5853},
{"f_1321:chicken_syntax_scm",(void*)f_1321},
{"f_5783:chicken_syntax_scm",(void*)f_5783},
{"f_5787:chicken_syntax_scm",(void*)f_5787},
{"f_5796:chicken_syntax_scm",(void*)f_5796},
{"f_5799:chicken_syntax_scm",(void*)f_5799},
{"f_5804:chicken_syntax_scm",(void*)f_5804},
{"f_5841:chicken_syntax_scm",(void*)f_5841},
{"f_5822:chicken_syntax_scm",(void*)f_5822},
{"f_5781:chicken_syntax_scm",(void*)f_5781},
{"f_1324:chicken_syntax_scm",(void*)f_1324},
{"f_5617:chicken_syntax_scm",(void*)f_5617},
{"f_5621:chicken_syntax_scm",(void*)f_5621},
{"f_5630:chicken_syntax_scm",(void*)f_5630},
{"f_5633:chicken_syntax_scm",(void*)f_5633},
{"f_5773:chicken_syntax_scm",(void*)f_5773},
{"f_5771:chicken_syntax_scm",(void*)f_5771},
{"f_5636:chicken_syntax_scm",(void*)f_5636},
{"f_5755:chicken_syntax_scm",(void*)f_5755},
{"f_5767:chicken_syntax_scm",(void*)f_5767},
{"f_5763:chicken_syntax_scm",(void*)f_5763},
{"f_5639:chicken_syntax_scm",(void*)f_5639},
{"f_5749:chicken_syntax_scm",(void*)f_5749},
{"f_5659:chicken_syntax_scm",(void*)f_5659},
{"f_5673:chicken_syntax_scm",(void*)f_5673},
{"f_5701:chicken_syntax_scm",(void*)f_5701},
{"f_5711:chicken_syntax_scm",(void*)f_5711},
{"f_5727:chicken_syntax_scm",(void*)f_5727},
{"f_5709:chicken_syntax_scm",(void*)f_5709},
{"f_5705:chicken_syntax_scm",(void*)f_5705},
{"f_5667:chicken_syntax_scm",(void*)f_5667},
{"f_5671:chicken_syntax_scm",(void*)f_5671},
{"f_5663:chicken_syntax_scm",(void*)f_5663},
{"f_5640:chicken_syntax_scm",(void*)f_5640},
{"f_5615:chicken_syntax_scm",(void*)f_5615},
{"f_1327:chicken_syntax_scm",(void*)f_1327},
{"f_5611:chicken_syntax_scm",(void*)f_5611},
{"f_5534:chicken_syntax_scm",(void*)f_5534},
{"f_5538:chicken_syntax_scm",(void*)f_5538},
{"f_5541:chicken_syntax_scm",(void*)f_5541},
{"f_5544:chicken_syntax_scm",(void*)f_5544},
{"f_5579:chicken_syntax_scm",(void*)f_5579},
{"f_5532:chicken_syntax_scm",(void*)f_5532},
{"f_1330:chicken_syntax_scm",(void*)f_1330},
{"f_5429:chicken_syntax_scm",(void*)f_5429},
{"f_5433:chicken_syntax_scm",(void*)f_5433},
{"f_5520:chicken_syntax_scm",(void*)f_5520},
{"f_5516:chicken_syntax_scm",(void*)f_5516},
{"f_5435:chicken_syntax_scm",(void*)f_5435},
{"f_5439:chicken_syntax_scm",(void*)f_5439},
{"f_5496:chicken_syntax_scm",(void*)f_5496},
{"f_5448:chicken_syntax_scm",(void*)f_5448},
{"f_5470:chicken_syntax_scm",(void*)f_5470},
{"f_5460:chicken_syntax_scm",(void*)f_5460},
{"f_5451:chicken_syntax_scm",(void*)f_5451},
{"f_5427:chicken_syntax_scm",(void*)f_5427},
{"f_1333:chicken_syntax_scm",(void*)f_1333},
{"f_5266:chicken_syntax_scm",(void*)f_5266},
{"f_5270:chicken_syntax_scm",(void*)f_5270},
{"f_5279:chicken_syntax_scm",(void*)f_5279},
{"f_5282:chicken_syntax_scm",(void*)f_5282},
{"f_5287:chicken_syntax_scm",(void*)f_5287},
{"f_5332:chicken_syntax_scm",(void*)f_5332},
{"f_5399:chicken_syntax_scm",(void*)f_5399},
{"f_5361:chicken_syntax_scm",(void*)f_5361},
{"f_5301:chicken_syntax_scm",(void*)f_5301},
{"f_5305:chicken_syntax_scm",(void*)f_5305},
{"f_5264:chicken_syntax_scm",(void*)f_5264},
{"f_1336:chicken_syntax_scm",(void*)f_1336},
{"f_5100:chicken_syntax_scm",(void*)f_5100},
{"f_5104:chicken_syntax_scm",(void*)f_5104},
{"f_5113:chicken_syntax_scm",(void*)f_5113},
{"f_5116:chicken_syntax_scm",(void*)f_5116},
{"f_5119:chicken_syntax_scm",(void*)f_5119},
{"f_5122:chicken_syntax_scm",(void*)f_5122},
{"f_5125:chicken_syntax_scm",(void*)f_5125},
{"f_5132:chicken_syntax_scm",(void*)f_5132},
{"f_5150:chicken_syntax_scm",(void*)f_5150},
{"f_5166:chicken_syntax_scm",(void*)f_5166},
{"f_5172:chicken_syntax_scm",(void*)f_5172},
{"f_5228:chicken_syntax_scm",(void*)f_5228},
{"f_5226:chicken_syntax_scm",(void*)f_5226},
{"f_5222:chicken_syntax_scm",(void*)f_5222},
{"f_5214:chicken_syntax_scm",(void*)f_5214},
{"f_5210:chicken_syntax_scm",(void*)f_5210},
{"f_5179:chicken_syntax_scm",(void*)f_5179},
{"f_5148:chicken_syntax_scm",(void*)f_5148},
{"f_5098:chicken_syntax_scm",(void*)f_5098},
{"f_1339:chicken_syntax_scm",(void*)f_1339},
{"f_5094:chicken_syntax_scm",(void*)f_5094},
{"f_5090:chicken_syntax_scm",(void*)f_5090},
{"f_4645:chicken_syntax_scm",(void*)f_4645},
{"f_4649:chicken_syntax_scm",(void*)f_4649},
{"f_4661:chicken_syntax_scm",(void*)f_4661},
{"f_4664:chicken_syntax_scm",(void*)f_4664},
{"f_4667:chicken_syntax_scm",(void*)f_4667},
{"f_4967:chicken_syntax_scm",(void*)f_4967},
{"f_4970:chicken_syntax_scm",(void*)f_4970},
{"f_4973:chicken_syntax_scm",(void*)f_4973},
{"f_5066:chicken_syntax_scm",(void*)f_5066},
{"f_5074:chicken_syntax_scm",(void*)f_5074},
{"f_4989:chicken_syntax_scm",(void*)f_4989},
{"f_4992:chicken_syntax_scm",(void*)f_4992},
{"f_4995:chicken_syntax_scm",(void*)f_4995},
{"f_4998:chicken_syntax_scm",(void*)f_4998},
{"f_5056:chicken_syntax_scm",(void*)f_5056},
{"f_5064:chicken_syntax_scm",(void*)f_5064},
{"f_5001:chicken_syntax_scm",(void*)f_5001},
{"f_5004:chicken_syntax_scm",(void*)f_5004},
{"f_5007:chicken_syntax_scm",(void*)f_5007},
{"f_5014:chicken_syntax_scm",(void*)f_5014},
{"f_4974:chicken_syntax_scm",(void*)f_4974},
{"f_4986:chicken_syntax_scm",(void*)f_4986},
{"f_4982:chicken_syntax_scm",(void*)f_4982},
{"f_4766:chicken_syntax_scm",(void*)f_4766},
{"f_4772:chicken_syntax_scm",(void*)f_4772},
{"f_4960:chicken_syntax_scm",(void*)f_4960},
{"f_4948:chicken_syntax_scm",(void*)f_4948},
{"f_4932:chicken_syntax_scm",(void*)f_4932},
{"f_4896:chicken_syntax_scm",(void*)f_4896},
{"f_4846:chicken_syntax_scm",(void*)f_4846},
{"f_4834:chicken_syntax_scm",(void*)f_4834},
{"f_4669:chicken_syntax_scm",(void*)f_4669},
{"f_4677:chicken_syntax_scm",(void*)f_4677},
{"f_4681:chicken_syntax_scm",(void*)f_4681},
{"f_4685:chicken_syntax_scm",(void*)f_4685},
{"f_4687:chicken_syntax_scm",(void*)f_4687},
{"f_4740:chicken_syntax_scm",(void*)f_4740},
{"f_4756:chicken_syntax_scm",(void*)f_4756},
{"f_4752:chicken_syntax_scm",(void*)f_4752},
{"f_4708:chicken_syntax_scm",(void*)f_4708},
{"f_4643:chicken_syntax_scm",(void*)f_4643},
{"f_1342:chicken_syntax_scm",(void*)f_1342},
{"f_4635:chicken_syntax_scm",(void*)f_4635},
{"f_4631:chicken_syntax_scm",(void*)f_4631},
{"f_4627:chicken_syntax_scm",(void*)f_4627},
{"f_4420:chicken_syntax_scm",(void*)f_4420},
{"f_4424:chicken_syntax_scm",(void*)f_4424},
{"f_4427:chicken_syntax_scm",(void*)f_4427},
{"f_4430:chicken_syntax_scm",(void*)f_4430},
{"f_4437:chicken_syntax_scm",(void*)f_4437},
{"f_4587:chicken_syntax_scm",(void*)f_4587},
{"f_4472:chicken_syntax_scm",(void*)f_4472},
{"f_4548:chicken_syntax_scm",(void*)f_4548},
{"f_4560:chicken_syntax_scm",(void*)f_4560},
{"f_4532:chicken_syntax_scm",(void*)f_4532},
{"f_4418:chicken_syntax_scm",(void*)f_4418},
{"f_1345:chicken_syntax_scm",(void*)f_1345},
{"f_4410:chicken_syntax_scm",(void*)f_4410},
{"f_4106:chicken_syntax_scm",(void*)f_4106},
{"f_4110:chicken_syntax_scm",(void*)f_4110},
{"f_4122:chicken_syntax_scm",(void*)f_4122},
{"f_4125:chicken_syntax_scm",(void*)f_4125},
{"f_4128:chicken_syntax_scm",(void*)f_4128},
{"f_4131:chicken_syntax_scm",(void*)f_4131},
{"f_4134:chicken_syntax_scm",(void*)f_4134},
{"f_4137:chicken_syntax_scm",(void*)f_4137},
{"f_4158:chicken_syntax_scm",(void*)f_4158},
{"f_4386:chicken_syntax_scm",(void*)f_4386},
{"f_4248:chicken_syntax_scm",(void*)f_4248},
{"f_4267:chicken_syntax_scm",(void*)f_4267},
{"f_4224:chicken_syntax_scm",(void*)f_4224},
{"f_4156:chicken_syntax_scm",(void*)f_4156},
{"f_4104:chicken_syntax_scm",(void*)f_4104},
{"f_1348:chicken_syntax_scm",(void*)f_1348},
{"f_4096:chicken_syntax_scm",(void*)f_4096},
{"f_4092:chicken_syntax_scm",(void*)f_4092},
{"f_4088:chicken_syntax_scm",(void*)f_4088},
{"f_4084:chicken_syntax_scm",(void*)f_4084},
{"f_3641:chicken_syntax_scm",(void*)f_3641},
{"f_3645:chicken_syntax_scm",(void*)f_3645},
{"f_3682:chicken_syntax_scm",(void*)f_3682},
{"f_4037:chicken_syntax_scm",(void*)f_4037},
{"f_4047:chicken_syntax_scm",(void*)f_4047},
{"f_4035:chicken_syntax_scm",(void*)f_4035},
{"f_3685:chicken_syntax_scm",(void*)f_3685},
{"f_3688:chicken_syntax_scm",(void*)f_3688},
{"f_3691:chicken_syntax_scm",(void*)f_3691},
{"f_3694:chicken_syntax_scm",(void*)f_3694},
{"f_3697:chicken_syntax_scm",(void*)f_3697},
{"f_3700:chicken_syntax_scm",(void*)f_3700},
{"f_3703:chicken_syntax_scm",(void*)f_3703},
{"f_3706:chicken_syntax_scm",(void*)f_3706},
{"f_3709:chicken_syntax_scm",(void*)f_3709},
{"f_3712:chicken_syntax_scm",(void*)f_3712},
{"f_3715:chicken_syntax_scm",(void*)f_3715},
{"f_3726:chicken_syntax_scm",(void*)f_3726},
{"f_3752:chicken_syntax_scm",(void*)f_3752},
{"f_3762:chicken_syntax_scm",(void*)f_3762},
{"f_3766:chicken_syntax_scm",(void*)f_3766},
{"f_3780:chicken_syntax_scm",(void*)f_3780},
{"f_3804:chicken_syntax_scm",(void*)f_3804},
{"f_3831:chicken_syntax_scm",(void*)f_3831},
{"f_3979:chicken_syntax_scm",(void*)f_3979},
{"f_3899:chicken_syntax_scm",(void*)f_3899},
{"f_3918:chicken_syntax_scm",(void*)f_3918},
{"f_3888:chicken_syntax_scm",(void*)f_3888},
{"f_3856:chicken_syntax_scm",(void*)f_3856},
{"f_3808:chicken_syntax_scm",(void*)f_3808},
{"f_3825:chicken_syntax_scm",(void*)f_3825},
{"f_3794:chicken_syntax_scm",(void*)f_3794},
{"f_3802:chicken_syntax_scm",(void*)f_3802},
{"f_3788:chicken_syntax_scm",(void*)f_3788},
{"f_3750:chicken_syntax_scm",(void*)f_3750},
{"f_3647:chicken_syntax_scm",(void*)f_3647},
{"f_3653:chicken_syntax_scm",(void*)f_3653},
{"f_3679:chicken_syntax_scm",(void*)f_3679},
{"f_3667:chicken_syntax_scm",(void*)f_3667},
{"f_3671:chicken_syntax_scm",(void*)f_3671},
{"f_3639:chicken_syntax_scm",(void*)f_3639},
{"f_1351:chicken_syntax_scm",(void*)f_1351},
{"f_3539:chicken_syntax_scm",(void*)f_3539},
{"f_3543:chicken_syntax_scm",(void*)f_3543},
{"f_3608:chicken_syntax_scm",(void*)f_3608},
{"f_3623:chicken_syntax_scm",(void*)f_3623},
{"f_3558:chicken_syntax_scm",(void*)f_3558},
{"f_3581:chicken_syntax_scm",(void*)f_3581},
{"f_3593:chicken_syntax_scm",(void*)f_3593},
{"f_3537:chicken_syntax_scm",(void*)f_3537},
{"f_1354:chicken_syntax_scm",(void*)f_1354},
{"f_3533:chicken_syntax_scm",(void*)f_3533},
{"f_3529:chicken_syntax_scm",(void*)f_3529},
{"f_3325:chicken_syntax_scm",(void*)f_3325},
{"f_3329:chicken_syntax_scm",(void*)f_3329},
{"f_3332:chicken_syntax_scm",(void*)f_3332},
{"f_3335:chicken_syntax_scm",(void*)f_3335},
{"f_3338:chicken_syntax_scm",(void*)f_3338},
{"f_3349:chicken_syntax_scm",(void*)f_3349},
{"f_3377:chicken_syntax_scm",(void*)f_3377},
{"f_3469:chicken_syntax_scm",(void*)f_3469},
{"f_3323:chicken_syntax_scm",(void*)f_3323},
{"f_1357:chicken_syntax_scm",(void*)f_1357},
{"f_3315:chicken_syntax_scm",(void*)f_3315},
{"f_3311:chicken_syntax_scm",(void*)f_3311},
{"f_2971:chicken_syntax_scm",(void*)f_2971},
{"f_2975:chicken_syntax_scm",(void*)f_2975},
{"f_2978:chicken_syntax_scm",(void*)f_2978},
{"f_2981:chicken_syntax_scm",(void*)f_2981},
{"f_2984:chicken_syntax_scm",(void*)f_2984},
{"f_2987:chicken_syntax_scm",(void*)f_2987},
{"f_2990:chicken_syntax_scm",(void*)f_2990},
{"f_2993:chicken_syntax_scm",(void*)f_2993},
{"f_2996:chicken_syntax_scm",(void*)f_2996},
{"f_3171:chicken_syntax_scm",(void*)f_3171},
{"f_3211:chicken_syntax_scm",(void*)f_3211},
{"f_3219:chicken_syntax_scm",(void*)f_3219},
{"f_3215:chicken_syntax_scm",(void*)f_3215},
{"f_2998:chicken_syntax_scm",(void*)f_2998},
{"f_3122:chicken_syntax_scm",(void*)f_3122},
{"f_3120:chicken_syntax_scm",(void*)f_3120},
{"f_3116:chicken_syntax_scm",(void*)f_3116},
{"f_3108:chicken_syntax_scm",(void*)f_3108},
{"f_3089:chicken_syntax_scm",(void*)f_3089},
{"f_3074:chicken_syntax_scm",(void*)f_3074},
{"f_3059:chicken_syntax_scm",(void*)f_3059},
{"f_3040:chicken_syntax_scm",(void*)f_3040},
{"f_3025:chicken_syntax_scm",(void*)f_3025},
{"f_2969:chicken_syntax_scm",(void*)f_2969},
{"f_1360:chicken_syntax_scm",(void*)f_1360},
{"f_2569:chicken_syntax_scm",(void*)f_2569},
{"f_2573:chicken_syntax_scm",(void*)f_2573},
{"f_2588:chicken_syntax_scm",(void*)f_2588},
{"f_2591:chicken_syntax_scm",(void*)f_2591},
{"f_2594:chicken_syntax_scm",(void*)f_2594},
{"f_2597:chicken_syntax_scm",(void*)f_2597},
{"f_2600:chicken_syntax_scm",(void*)f_2600},
{"f_2606:chicken_syntax_scm",(void*)f_2606},
{"f_2609:chicken_syntax_scm",(void*)f_2609},
{"f_2612:chicken_syntax_scm",(void*)f_2612},
{"f_2930:chicken_syntax_scm",(void*)f_2930},
{"f_2928:chicken_syntax_scm",(void*)f_2928},
{"f_2924:chicken_syntax_scm",(void*)f_2924},
{"f_2641:chicken_syntax_scm",(void*)f_2641},
{"f_2667:chicken_syntax_scm",(void*)f_2667},
{"f_2707:chicken_syntax_scm",(void*)f_2707},
{"f_2683:chicken_syntax_scm",(void*)f_2683},
{"f_2679:chicken_syntax_scm",(void*)f_2679},
{"f_2639:chicken_syntax_scm",(void*)f_2639},
{"f_2635:chicken_syntax_scm",(void*)f_2635},
{"f_2567:chicken_syntax_scm",(void*)f_2567},
{"f_1363:chicken_syntax_scm",(void*)f_1363},
{"f_2559:chicken_syntax_scm",(void*)f_2559},
{"f_2369:chicken_syntax_scm",(void*)f_2369},
{"f_2373:chicken_syntax_scm",(void*)f_2373},
{"f_2376:chicken_syntax_scm",(void*)f_2376},
{"f_2379:chicken_syntax_scm",(void*)f_2379},
{"f_2382:chicken_syntax_scm",(void*)f_2382},
{"f_2385:chicken_syntax_scm",(void*)f_2385},
{"f_2394:chicken_syntax_scm",(void*)f_2394},
{"f_2497:chicken_syntax_scm",(void*)f_2497},
{"f_2525:chicken_syntax_scm",(void*)f_2525},
{"f_2519:chicken_syntax_scm",(void*)f_2519},
{"f_2500:chicken_syntax_scm",(void*)f_2500},
{"f_2404:chicken_syntax_scm",(void*)f_2404},
{"f_2407:chicken_syntax_scm",(void*)f_2407},
{"f_2479:chicken_syntax_scm",(void*)f_2479},
{"f_2456:chicken_syntax_scm",(void*)f_2456},
{"f_2413:chicken_syntax_scm",(void*)f_2413},
{"f_2424:chicken_syntax_scm",(void*)f_2424},
{"f_2444:chicken_syntax_scm",(void*)f_2444},
{"f_2367:chicken_syntax_scm",(void*)f_2367},
{"f_1366:chicken_syntax_scm",(void*)f_1366},
{"f_2359:chicken_syntax_scm",(void*)f_2359},
{"f_2138:chicken_syntax_scm",(void*)f_2138},
{"f_2142:chicken_syntax_scm",(void*)f_2142},
{"f_2145:chicken_syntax_scm",(void*)f_2145},
{"f_2148:chicken_syntax_scm",(void*)f_2148},
{"f_2151:chicken_syntax_scm",(void*)f_2151},
{"f_2154:chicken_syntax_scm",(void*)f_2154},
{"f_2163:chicken_syntax_scm",(void*)f_2163},
{"f_2282:chicken_syntax_scm",(void*)f_2282},
{"f_2310:chicken_syntax_scm",(void*)f_2310},
{"f_2343:chicken_syntax_scm",(void*)f_2343},
{"f_2316:chicken_syntax_scm",(void*)f_2316},
{"f_2304:chicken_syntax_scm",(void*)f_2304},
{"f_2285:chicken_syntax_scm",(void*)f_2285},
{"f_2173:chicken_syntax_scm",(void*)f_2173},
{"f_2176:chicken_syntax_scm",(void*)f_2176},
{"f_2272:chicken_syntax_scm",(void*)f_2272},
{"f_2237:chicken_syntax_scm",(void*)f_2237},
{"f_2182:chicken_syntax_scm",(void*)f_2182},
{"f_2205:chicken_syntax_scm",(void*)f_2205},
{"f_2225:chicken_syntax_scm",(void*)f_2225},
{"f_2136:chicken_syntax_scm",(void*)f_2136},
{"f_1369:chicken_syntax_scm",(void*)f_1369},
{"f_1857:chicken_syntax_scm",(void*)f_1857},
{"f_1861:chicken_syntax_scm",(void*)f_1861},
{"f_1864:chicken_syntax_scm",(void*)f_1864},
{"f_1867:chicken_syntax_scm",(void*)f_1867},
{"f_1870:chicken_syntax_scm",(void*)f_1870},
{"f_1873:chicken_syntax_scm",(void*)f_1873},
{"f_1876:chicken_syntax_scm",(void*)f_1876},
{"f_1885:chicken_syntax_scm",(void*)f_1885},
{"f_2031:chicken_syntax_scm",(void*)f_2031},
{"f_2034:chicken_syntax_scm",(void*)f_2034},
{"f_2043:chicken_syntax_scm",(void*)f_2043},
{"f_2068:chicken_syntax_scm",(void*)f_2068},
{"f_2093:chicken_syntax_scm",(void*)f_2093},
{"f_2115:chicken_syntax_scm",(void*)f_2115},
{"f_2108:chicken_syntax_scm",(void*)f_2108},
{"f_2100:chicken_syntax_scm",(void*)f_2100},
{"f_2087:chicken_syntax_scm",(void*)f_2087},
{"f_2083:chicken_syntax_scm",(void*)f_2083},
{"f_2062:chicken_syntax_scm",(void*)f_2062},
{"f_2058:chicken_syntax_scm",(void*)f_2058},
{"f_2025:chicken_syntax_scm",(void*)f_2025},
{"f_1895:chicken_syntax_scm",(void*)f_1895},
{"f_1902:chicken_syntax_scm",(void*)f_1902},
{"f_2010:chicken_syntax_scm",(void*)f_2010},
{"f_1998:chicken_syntax_scm",(void*)f_1998},
{"f_1994:chicken_syntax_scm",(void*)f_1994},
{"f_1930:chicken_syntax_scm",(void*)f_1930},
{"f_1958:chicken_syntax_scm",(void*)f_1958},
{"f_1970:chicken_syntax_scm",(void*)f_1970},
{"f_1954:chicken_syntax_scm",(void*)f_1954},
{"f_1855:chicken_syntax_scm",(void*)f_1855},
{"f_1372:chicken_syntax_scm",(void*)f_1372},
{"f_1753:chicken_syntax_scm",(void*)f_1753},
{"f_1757:chicken_syntax_scm",(void*)f_1757},
{"f_1763:chicken_syntax_scm",(void*)f_1763},
{"f_1847:chicken_syntax_scm",(void*)f_1847},
{"f_1808:chicken_syntax_scm",(void*)f_1808},
{"f_1820:chicken_syntax_scm",(void*)f_1820},
{"f_1751:chicken_syntax_scm",(void*)f_1751},
{"f_1375:chicken_syntax_scm",(void*)f_1375},
{"f_1716:chicken_syntax_scm",(void*)f_1716},
{"f_1720:chicken_syntax_scm",(void*)f_1720},
{"f_1727:chicken_syntax_scm",(void*)f_1727},
{"f_1739:chicken_syntax_scm",(void*)f_1739},
{"f_1743:chicken_syntax_scm",(void*)f_1743},
{"f_1714:chicken_syntax_scm",(void*)f_1714},
{"f_1378:chicken_syntax_scm",(void*)f_1378},
{"f_1691:chicken_syntax_scm",(void*)f_1691},
{"f_1695:chicken_syntax_scm",(void*)f_1695},
{"f_1689:chicken_syntax_scm",(void*)f_1689},
{"f_1381:chicken_syntax_scm",(void*)f_1381},
{"f_1559:chicken_syntax_scm",(void*)f_1559},
{"f_1569:chicken_syntax_scm",(void*)f_1569},
{"f_1619:chicken_syntax_scm",(void*)f_1619},
{"f_1632:chicken_syntax_scm",(void*)f_1632},
{"f_1585:chicken_syntax_scm",(void*)f_1585},
{"f_1601:chicken_syntax_scm",(void*)f_1601},
{"f_1557:chicken_syntax_scm",(void*)f_1557},
{"f_1384:chicken_syntax_scm",(void*)f_1384},
{"f_1412:chicken_syntax_scm",(void*)f_1412},
{"f_1505:chicken_syntax_scm",(void*)f_1505},
{"f_1509:chicken_syntax_scm",(void*)f_1509},
{"f_1527:chicken_syntax_scm",(void*)f_1527},
{"f_1492:chicken_syntax_scm",(void*)f_1492},
{"f_1422:chicken_syntax_scm",(void*)f_1422},
{"f_1472:chicken_syntax_scm",(void*)f_1472},
{"f_1425:chicken_syntax_scm",(void*)f_1425},
{"f_1458:chicken_syntax_scm",(void*)f_1458},
{"f_1428:chicken_syntax_scm",(void*)f_1428},
{"f_1438:chicken_syntax_scm",(void*)f_1438},
{"f_1448:chicken_syntax_scm",(void*)f_1448},
{"f_1446:chicken_syntax_scm",(void*)f_1446},
{"f_1410:chicken_syntax_scm",(void*)f_1410},
{"f_1387:chicken_syntax_scm",(void*)f_1387},
{"f_1402:chicken_syntax_scm",(void*)f_1402},
{"f_1400:chicken_syntax_scm",(void*)f_1400},
{"f_1390:chicken_syntax_scm",(void*)f_1390},
{"f_1393:chicken_syntax_scm",(void*)f_1393},
{"f_1396:chicken_syntax_scm",(void*)f_1396},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
